import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '25mb' }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'RIFQ Mosque Mihrab Vision Verification Service',
    geminiReady: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Real AI Vision Verification endpoint for Mosque Mihrab
app.post('/api/verify-mihrab', async (req, res) => {
  try {
    const {
      imageBase64,
      mimeType = 'image/jpeg',
      prayerKey,
      prayerNameAr,
      sessionId,
    } = req.body;

    if (!imageBase64) {
      return res.status(400).json({
        success: false,
        isMosqueMihrab: false,
        confidence: 0,
        sessionId: sessionId || '',
        reasonAr: 'لم يتم استلام أي صورة من الكاميرا للتحقق.',
        detectedFeatures: [],
        prohibitedElementsDetected: [],
      });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        success: false,
        isMosqueMihrab: false,
        confidence: 0,
        sessionId: sessionId || '',
        reasonAr: 'مفتاح التحقق الذكي غير مهيأ في الخادم.',
        detectedFeatures: [],
        prohibitedElementsDetected: [],
      });
    }

    // Initialize GoogleGenAI SDK per guidelines
    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    // Strip data URI prefix if present
    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    const prompt = `أنت خبير رؤية حاسوبية معماري إسلامي صارم في تطبيق "رِفْق | RIFQ".
مهمتك: التحقق الدقيق والشرعي مما إذا كانت هذه الصورة الملتقطة بواسطة كاميرا المستخدم المباشرة تُظهر بالفعل "محراب مسجد" حقيقي (Mosque Mihrab / Prayer Niche) لأداء صلاة ${prayerNameAr || 'الفريضة'}.

معيار القبول الصارم (الحد الأدنى للثقة = 0.85):
1. ظهور محراب المسجد الحقيقي (التجويف المعماري النصف دائري أو المقوس في جدار القبلة المخصص للإمام).
2. أو صدر المسجد وجدار القبلة الذي يتوسطه المحراب الإسلامي بأقواسه، وزخارفه العربية أو الآيات القرآنية المنقوشة، أو منبر الخطيب، وسجاد المسجد المخطط لصفوف المصلين.
3. يجب أن تكون الصورة ملتقطة مباشرة من داخل مسجد حقيقي، ولا تُقبل إلا إذا كانت نسبة الثقة >= 0.85 وخالية تماماً من العناصر المحظورة.

العناصر المحظورة التي توجب الرفض الفوري (isMosqueMihrab = false):
1. شاشات رقمية (هاتف، حاسوب، تلفزيون) تعرض صورة محراب أو مسجد.
2. سجاد منزلي أو سجادة صلاة فردية مفروشة في منزل أو غرفة أو مكتب دون وجود بناء محراب المسجد وتجويف القبلة.
3. مصابيح منزلية، أثاث عادي، صالات، غرف نوم، مجالس منزلية، مطابخ، مكاتب، سيارات، شوارع.
4. جدران فارغة، أرضيات خالية، أسقف عادية، صور مظلمة أو غير واضحة.

أجب حصراً بصيغة JSON التالية بدون أي نصوص أو كود ماركداون:
{
  "isMosqueMihrab": true أو false,
  "confidence": رقم عشري دقيق من 0.0 إلى 1.0,
  "prohibitedElementsDetected": ["قائمة بأي عناصر محظورة تم رصدها كـ: شاشة، سجادة منزلية، غرفة نوم، إضاءة عادية، جدار فارغ... وتبقى فارغة [] إذا لم يوجد أي محظور"],
  "detectedFeatures": ["قائمة بأهم معالم المحراب والمسجد مثل: تجويف المحراب، قوس إسلامي، منبر، سجاد صفوف المسجد، نقوش قرآنية"],
  "reasonAr": "شرح واضح ودقيق بالعربية يوضح ما ظهر في الصورة وسبب القبول أو الرفض"
}`;

    // Generate content with retry for transient high-demand (503) spikes
    let response: any;
    let lastError: any = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: [
            {
              role: 'user',
              parts: [
                {
                  inlineData: {
                    mimeType,
                    data: cleanBase64,
                  },
                },
                {
                  text: prompt,
                },
              ],
            },
          ],
          config: {
            responseMimeType: 'application/json',
          },
        });
        if (response) break;
      } catch (err: any) {
        lastError = err;
        if (attempt < 3) {
          await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
        }
      }
    }

    if (!response) {
      throw lastError || new Error('فشل استلام الرد من الذكاء الاصطناعي.');
    }

    const responseText = response.text || '{}';
    let parsedResult: {
      isMosqueMihrab?: boolean;
      confidence?: number;
      prohibitedElementsDetected?: string[];
      detectedFeatures?: string[];
      reasonAr?: string;
    } = {};

    try {
      const cleaned = responseText.replace(/```json/gi, '').replace(/```/g, '').trim();
      parsedResult = JSON.parse(cleaned);
    } catch {
      parsedResult = {
        isMosqueMihrab: false,
        confidence: 0,
        prohibitedElementsDetected: ['تعذر قراءة التحليل'],
        detectedFeatures: [],
        reasonAr: 'تعذر قراءة التحليل البصري بدقة، يرجى إعادة المحاولة بزاوية أوضح للمحراب.',
      };
    }

    const MIHRAB_CONFIDENCE_THRESHOLD = 0.85;
    const rawConfidence = typeof parsedResult.confidence === 'number' ? parsedResult.confidence : 0;
    const prohibitedElements = Array.isArray(parsedResult.prohibitedElementsDetected)
      ? parsedResult.prohibitedElementsDetected
      : [];

    const passedThreshold =
      Boolean(parsedResult.isMosqueMihrab) &&
      rawConfidence >= MIHRAB_CONFIDENCE_THRESHOLD &&
      prohibitedElements.length === 0;

    let finalReasonAr = parsedResult.reasonAr || '';
    if (prohibitedElements.length > 0) {
      finalReasonAr = `تم رصد عناصر غير مطابقة أو محظورة: (${prohibitedElements.join(
        '، '
      )}). يرجى توجيه الكاميرا إلى محراب المسجد الفعلي.`;
    } else if (Boolean(parsedResult.isMosqueMihrab) && rawConfidence < MIHRAB_CONFIDENCE_THRESHOLD) {
      finalReasonAr = `نسبة التطابق (${Math.round(
        rawConfidence * 100
      )}%) أقل من الحد المعتمد (85%). يرجى الاقتراب وتحسين زاوية التصوير.`;
    }

    return res.json({
      success: true,
      sessionId: sessionId || '',
      isMosqueMihrab: passedThreshold,
      confidence: rawConfidence,
      threshold: MIHRAB_CONFIDENCE_THRESHOLD,
      passedThreshold,
      prohibitedElementsDetected: prohibitedElements,
      detectedFeatures: Array.isArray(parsedResult.detectedFeatures)
        ? parsedResult.detectedFeatures
        : [],
      reasonAr:
        finalReasonAr ||
        (passedThreshold
          ? 'تم التحقق من محراب المسجد بنجاح، تقبّل الله صلاتك وطاعتك.'
          : 'لم يتم التعرف على محراب مسجد حقيقي.'),
    });
  } catch (error: any) {
    console.error('Error in /api/verify-mihrab:', error);
    return res.status(500).json({
      success: false,
      isMosqueMihrab: false,
      confidence: 0,
      sessionId: req.body?.sessionId || '',
      reasonAr: 'حدث عطل مؤقت في معالجة التحقق الذكي، يرجى المحاولة مرة أخرى.',
      error: error?.message,
    });
  }
});

// Mounting Vite or static files
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[RIFQ Full-Stack] Server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
