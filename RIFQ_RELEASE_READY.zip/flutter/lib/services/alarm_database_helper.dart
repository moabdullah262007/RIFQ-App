import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class AlarmDatabaseHelper {
  static final AlarmDatabaseHelper _instance = AlarmDatabaseHelper._internal();
  factory AlarmDatabaseHelper() => _instance;
  AlarmDatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'rifq_alarms.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // 1. جدول المنبهات الذكية
    await db.execute('''
      CREATE TABLE alarms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hour INTEGER NOT NULL,
        minute INTEGER NOT NULL,
        days TEXT NOT NULL,
        sound TEXT NOT NULL,
        challenge_type TEXT NOT NULL,
        difficulty TEXT NOT NULL,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    // 2. جدول منبه الفجر
    await db.execute('''
      CREATE TABLE fajr_alarm (
        id INTEGER PRIMARY KEY,
        minutes_before INTEGER NOT NULL DEFAULT 10,
        sound TEXT NOT NULL DEFAULT 'adhan_fajr',
        gradual INTEGER NOT NULL DEFAULT 1,
        repeat_days TEXT NOT NULL DEFAULT 'all',
        is_active INTEGER NOT NULL DEFAULT 1
      )
    ''');

    // 3. جدول تذكير قبل النوم
    await db.execute('''
      CREATE TABLE sleep_reminder (
        id INTEGER PRIMARY KEY,
        hour INTEGER NOT NULL DEFAULT 22,
        minute INTEGER NOT NULL DEFAULT 0,
        content_type TEXT NOT NULL DEFAULT 'dhikr',
        sound TEXT NOT NULL DEFAULT 'gentle',
        repeat_days TEXT NOT NULL DEFAULT 'all',
        is_active INTEGER NOT NULL DEFAULT 1
      )
    ''');

    // 4. جدول سجل التحديات
    await db.execute('''
      CREATE TABLE challenge_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        alarm_id INTEGER,
        challenge_type TEXT NOT NULL,
        result TEXT NOT NULL,
        completed_at TEXT NOT NULL
      )
    ''');

    // إدراج إعدادات افتراضية لمنبه الفجر وتذكير النوم
    await db.insert('fajr_alarm', {
      'id': 1,
      'minutes_before': 10,
      'sound': 'adhan_fajr',
      'gradual': 1,
      'repeat_days': 'all',
      'is_active': 1,
    });

    await db.insert('sleep_reminder', {
      'id': 1,
      'hour': 22,
      'minute': 0,
      'content_type': 'dhikr',
      'sound': 'gentle',
      'repeat_days': 'all',
      'is_active': 1,
    });
  }

  // ── عمليات المنبهات الذكية ──
  Future<List<Map<String, dynamic>>> getAlarms() async {
    final db = await database;
    return await db.query('alarms', orderBy: 'hour ASC, minute ASC');
  }

  Future<int> insertAlarm(Map<String, dynamic> alarm) async {
    final db = await database;
    return await db.insert('alarms', alarm);
  }

  Future<int> updateAlarm(int id, Map<String, dynamic> alarm) async {
    final db = await database;
    return await db.update('alarms', alarm, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> toggleAlarm(int id, bool isActive) async {
    final db = await database;
    return await db.update(
      'alarms',
      {'is_active': isActive ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteAlarm(int id) async {
    final db = await database;
    return await db.delete('alarms', where: 'id = ?', whereArgs: [id]);
  }

  // ── عمليات منبه الفجر ──
  Future<Map<String, dynamic>> getFajrAlarm() async {
    final db = await database;
    final res = await db.query('fajr_alarm', where: 'id = ?', whereArgs: [1]);
    if (res.isNotEmpty) return res.first;
    return {
      'id': 1,
      'minutes_before': 10,
      'sound': 'adhan_fajr',
      'gradual': 1,
      'repeat_days': 'all',
      'is_active': 1,
    };
  }

  Future<void> saveFajrAlarm(Map<String, dynamic> settings) async {
    final db = await database;
    await db.insert(
      'fajr_alarm',
      {'id': 1, ...settings},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ── عمليات تذكير النوم ──
  Future<Map<String, dynamic>> getSleepReminder() async {
    final db = await database;
    final res = await db.query('sleep_reminder', where: 'id = ?', whereArgs: [1]);
    if (res.isNotEmpty) return res.first;
    return {
      'id': 1,
      'hour': 22,
      'minute': 0,
      'content_type': 'dhikr',
      'sound': 'gentle',
      'repeat_days': 'all',
      'is_active': 1,
    };
  }

  Future<void> saveSleepReminder(Map<String, dynamic> settings) async {
    final db = await database;
    await db.insert(
      'sleep_reminder',
      {'id': 1, ...settings},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ── عمليات سجل التحديات ──
  Future<void> logChallengeResult({
    required int? alarmId,
    required String challengeType,
    required String result,
  }) async {
    final db = await database;
    await db.insert('challenge_history', {
      'alarm_id': alarmId,
      'challenge_type': challengeType,
      'result': result,
      'completed_at': DateTime.now().toIso8601String(),
    });
  }
}
