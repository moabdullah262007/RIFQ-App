import 'dart:convert';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:shared_preferences/shared_preferences.dart';

class WasayaCategoryModel {
  final String id;
  final String name;
  final String icon;
  final String description;
  final List<String> topics;
  final int count;

  const WasayaCategoryModel({
    required this.id,
    required this.name,
    required this.icon,
    required this.description,
    required this.topics,
    this.count = 0,
  });
}

class WasiyaModel {
  final String id;
  final String categoryId;
  final String title;
  final String subtopic;
  final String text;
  final String source;
  final String book;
  final String narrator;
  final String hadithNumber;
  final String grade;
  final String explanation;
  final List<String> lessons;
  final int orderNumber;
  final bool isFavorite;

  const WasiyaModel({
    required this.id,
    required this.categoryId,
    required this.title,
    required this.subtopic,
    required this.text,
    required this.source,
    required this.book,
    required this.narrator,
    required this.hadithNumber,
    required this.grade,
    required this.explanation,
    required this.lessons,
    required this.orderNumber,
    this.isFavorite = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'category_id': categoryId,
      'title': title,
      'subtopic': subtopic,
      'text': text,
      'source': source,
      'book': book,
      'narrator': narrator,
      'hadith_number': hadithNumber,
      'grade': grade,
      'explanation': explanation,
      'lessons': jsonEncode(lessons),
      'order_number': orderNumber,
    };
  }
}

class WasayaSqliteService {
  static final WasayaSqliteService instance = WasayaSqliteService._init();
  static Database? _database;
  static const String _prefsFavoritesKey = 'rifq_wasaya_favorites_v1';

  WasayaSqliteService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('rifq_wasaya_v1.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT NOT NULL,
        description TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE wasaya (
        id TEXT PRIMARY KEY,
        category_id TEXT NOT NULL,
        title TEXT NOT NULL,
        subtopic TEXT NOT NULL,
        text TEXT NOT NULL,
        source TEXT NOT NULL,
        book TEXT NOT NULL,
        narrator TEXT NOT NULL,
        hadith_number TEXT NOT NULL,
        grade TEXT NOT NULL,
        explanation TEXT NOT NULL,
        lessons TEXT NOT NULL,
        order_number INTEGER NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE favorites (
        id TEXT PRIMARY KEY,
        wasiya_id TEXT NOT NULL UNIQUE,
        added_at TEXT NOT NULL
      )
    ''');

    final batch = db.batch();
    for (final cat in initialCategories) {
      batch.insert('categories', {
        'id': cat.id,
        'name': cat.name,
        'icon': cat.icon,
        'description': cat.description,
      });
    }
    for (final w in initialWasaya) {
      batch.insert('wasaya', w.toMap());
    }
    await batch.commit(noResult: true);
  }

  Future<Set<String>> getFavoriteIds() async {
    final db = await database;
    final rows = await db.query('favorites');
    final set = rows.map((r) => r['wasiya_id'] as String).toSet();

    final prefs = await SharedPreferences.getInstance();
    final savedList = prefs.getStringList(_prefsFavoritesKey) ?? [];
    set.addAll(savedList);
    return set;
  }

  Future<bool> toggleFavorite(String wasiyaId) async {
    final db = await database;
    final prefs = await SharedPreferences.getInstance();
    final currentFavs = await getFavoriteIds();
    bool isNowFav;

    if (currentFavs.contains(wasiyaId)) {
      await db.delete('favorites', where: 'wasiya_id = ?', whereArgs: [wasiyaId]);
      currentFavs.remove(wasiyaId);
      isNowFav = false;
    } else {
      await db.insert(
        'favorites',
        {
          'id': 'fav_$wasiyaId',
          'wasiya_id': wasiyaId,
          'added_at': DateTime.now().toIso8601String(),
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      currentFavs.add(wasiyaId);
      isNowFav = true;
    }

    await prefs.setStringList(_prefsFavoritesKey, currentFavs.toList());
    return isNowFav;
  }

  Future<List<WasayaCategoryModel>> getCategories() async {
    final db = await database;
    final wasayaRows = await db.query('wasaya');
    return initialCategories.map((c) {
      final count = wasayaRows.where((w) => w['category_id'] == c.id).length;
      return WasayaCategoryModel(
        id: c.id,
        name: c.name,
        icon: c.icon,
        description: c.description,
        topics: c.topics,
        count: count,
      );
    }).toList();
  }

  Future<List<WasiyaModel>> getAllWasaya() async {
    final db = await database;
    final favs = await getFavoriteIds();
    final rows = await db.query('wasaya', orderBy: 'order_number ASC');
    return rows.map((r) => _mapRowToModel(r, favs)).toList();
  }

  Future<List<WasiyaModel>> getWasayaByCategory(String categoryId) async {
    final db = await database;
    final favs = await getFavoriteIds();
    final rows = await db.query(
      'wasaya',
      where: 'category_id = ?',
      whereArgs: [categoryId],
      orderBy: 'order_number ASC',
    );
    return rows.map((r) => _mapRowToModel(r, favs)).toList();
  }

  WasiyaModel _mapRowToModel(Map<String, Object?> r, Set<String> favs) {
    final id = r['id'] as String;
    List<String> parsedLessons = [];
    try {
      final raw = jsonDecode(r['lessons'] as String) as List<dynamic>;
      parsedLessons = raw.map((e) => e.toString()).toList();
    } catch (_) {}

    return WasiyaModel(
      id: id,
      categoryId: r['category_id'] as String,
      title: r['title'] as String,
      subtopic: r['subtopic'] as String,
      text: r['text'] as String,
      source: r['source'] as String,
      book: r['book'] as String,
      narrator: r['narrator'] as String,
      hadithNumber: r['hadith_number'] as String,
      grade: r['grade'] as String,
      explanation: r['explanation'] as String,
      lessons: parsedLessons,
      orderNumber: r['order_number'] as int,
      isFavorite: favs.contains(id),
    );
  }

  static const List<WasayaCategoryModel> initialCategories = [
    WasayaCategoryModel(
      id: 'worship',
      name: 'وصايا في العبادة',
      icon: 'worship',
      description: 'وصايا النبي ﷺ في الصلاة والذكر والدعاء والقرآن والصيام',
      topics: ['الصلاة', 'الذكر', 'الدعاء', 'القرآن', 'الصيام'],
    ),
    WasayaCategoryModel(
      id: 'morals',
      name: 'وصايا في الأخلاق',
      icon: 'morals',
      description: 'وصايا نبوية جامعة في الصدق والأمانة والحياء والرحمة والعفو',
      topics: ['الصدق', 'الأمانة', 'الحياء', 'الرحمة', 'العفو'],
    ),
    WasayaCategoryModel(
      id: 'speech',
      name: 'وصايا في الكلام',
      icon: 'speech',
      description: 'هدي النبي ﷺ في حفظ اللسان والصمت والكلمة الطيبة واجتناب الغيبة والنميمة',
      topics: ['حفظ اللسان', 'الصمت', 'الكلمة الطيبة', 'الغيبة', 'النميمة'],
    ),
    WasayaCategoryModel(
      id: 'food',
      name: 'وصايا في الطعام',
      icon: 'food',
      description: 'وصايا السُّنة في آداب الطعام والاعتدال وطيب المطعم والشكر والضيافة',
      topics: ['آداب الطعام', 'الاعتدال', 'الحلال والحرام', 'الشكر', 'الضيافة'],
    ),
    WasayaCategoryModel(
      id: 'wealth',
      name: 'وصايا في المال',
      icon: 'wealth',
      description: 'ضوابط الكسب الحلال والصدق في التجارة والأمانة والصدقة والقناعة',
      topics: ['الصدق في التجارة', 'الأمانة', 'الصدقة', 'القناعة', 'الحرام'],
    ),
    WasayaCategoryModel(
      id: 'dealings',
      name: 'وصايا في التعامل',
      icon: 'dealings',
      description: 'وصايا النبي ﷺ ببر الوالدين وصلة الأرحام وإكرام الجيران وصحبة الأخيار',
      topics: ['الوالدين', 'الأرحام', 'الجيران', 'الأصدقاء', 'المعاملات'],
    ),
    WasayaCategoryModel(
      id: 'heart',
      name: 'وصايا في القلب',
      icon: 'heart',
      description: 'تزكية القلوب بالإخلاص والتوكل والخوف والرجاء والمحبة في الله والصبر',
      topics: ['الإخلاص', 'التوكل', 'الخوف والرجاء', 'الحب في الله', 'الصبر'],
    ),
    WasayaCategoryModel(
      id: 'occasions',
      name: 'وصايا في المناسبات',
      icon: 'occasions',
      description: 'وصايا نبوية لاغتنام مواسم الخيرات في رمضان والحج والعيد والجمعة والليل',
      topics: ['رمضان', 'الحج', 'العيد', 'الجمعة', 'الليل'],
    ),
    WasayaCategoryModel(
      id: 'tribulations',
      name: 'وصايا في الفتن',
      icon: 'tribulations',
      description: 'الهدي النبوي في الصبر على البلاء والثبات على الحق والاعتصام بالله عند الفتن',
      topics: ['الصبر على البلاء', 'الثبات', 'الابتعاد عن الفتن', 'الدعاء', 'التوكل'],
    ),
    WasayaCategoryModel(
      id: 'comprehensive',
      name: 'وصايا شاملة',
      icon: 'comprehensive',
      description: 'الوصايا الجامعة الكبرى في خطبة الوداع ووصايا النبي ﷺ لمعاذ وابن عباس وأبي ذر',
      topics: ['الوصايا العشر', 'خطبة الوداع', 'وصايا النبي ﷺ لمعاذ', 'وصايا لابن عباس', 'وصايا لأبي ذر'],
    ),
  ];

  static const List<WasiyaModel> initialWasaya = [
    WasiyaModel(
      id: 'w_comprehensive_1',
      categoryId: 'comprehensive',
      title: 'وصية التقوىوحسن الخلق',
      subtopic: 'الوصايا العشر',
      text: 'اتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن',
      source: 'سنن الترمذي (1987)',
      book: 'جامع الترمذي',
      narrator: 'عن أبي ذر رضي الله عنه',
      hadithNumber: '1987',
      grade: 'حسن صحيح',
      explanation: 'جمعت هذه الوصية النبوية الشريفة حقوق الله وحقوق العباد في ثلاث جمل محكمات: تقوى الله في السر والعلن، وإتباع السيئة بالحسنة لمحوها، ومعاملة الناس بخلق حسن.',
      lessons: [
        'مراقبة الله تعالى في السر والعلن.',
        'المبادرة بالحسنات عقب السيئات لمحو أثرها.',
        'حسن الخلق مع الناس من كمال التقوى.',
      ],
      orderNumber: 1,
    ),
    WasiyaModel(
      id: 'w_comprehensive_2',
      categoryId: 'comprehensive',
      title: 'وصية النبي ﷺ لابن عباس',
      subtopic: 'وصايا لابن عباس',
      text: 'يا غلام إني أعلمك كلمات: احفظ الله يحفظك، احفظ الله تجده تجاهك، إذا سألت فاسأل الله، وإذا استعنت فاستعن بالله',
      source: 'سنن الترمذي (2516)',
      book: 'جامع الترمذي',
      narrator: 'عن عبد الله بن عباس رضي الله عنهما',
      hadithNumber: '2516',
      grade: 'حسن صحيح',
      explanation: 'وصية عظيمة في حفظ حدود الله وإفراد الله بالسؤال والاستعانة واليقين بالقضاء والقدر.',
      lessons: [
        'من حفظ أوامر الله حفظه الله في دينه ودنياه.',
        'إفراد الله بالسؤال والاستعانة والتوكل.',
      ],
      orderNumber: 2,
    ),
    WasiyaModel(
      id: 'w_worship_1',
      categoryId: 'worship',
      title: 'وصية في الصلاة',
      subtopic: 'الصلاة',
      text: 'صلِّ صلاة مودع، ولا تكلم بكلام تعتذر منه غدًا، وأجمع اليأس مما في أيدي الناس',
      source: 'سنن ابن ماجه (4171)',
      book: 'سنن ابن ماجه',
      narrator: 'عن أبي أيوب الأنصاري رضي الله عنه',
      hadithNumber: '4171',
      grade: 'حسن صحيح',
      explanation: 'الإحسان والخشوع في الصلاة كأنها آخر صلاة في الحياة، مع حفظ اللسان والاستغناء بالله.',
      lessons: [
        'استحضار الخشوع في الصلاة كأنها صلاة مودع.',
        'حفظ اللسان عما يوجب الاعتذار.',
      ],
      orderNumber: 3,
    ),
    WasiyaModel(
      id: 'w_worship_2',
      categoryId: 'worship',
      title: 'وصية في الذكر',
      subtopic: 'الذكر',
      text: 'لا يزال لسانك رطبًا من ذكر الله',
      source: 'سنن الترمذي (3375)',
      book: 'جامع الترمذي',
      narrator: 'عن عبد الله بن بسر رضي الله عنه',
      hadithNumber: '3375',
      grade: 'صحيح',
      explanation: 'ملازمة ذكر الله تعالى في كل حال لأن الذكر حياة القلوب وحصن المؤمن.',
      lessons: [
        'مداومة الذكر في جميع الأوقات.',
        'الذكر يحفظ اللسان والقلب من الغفلة.',
      ],
      orderNumber: 4,
    ),
    WasiyaModel(
      id: 'w_speech_1',
      categoryId: 'speech',
      title: 'وصية في الكلام والصمت',
      subtopic: 'الصمت',
      text: 'من كان يؤمن بالله واليوم الآخر فليقل خيرًا أو ليصمت',
      source: 'صحيح البخاري (6018) — صحيح مسلم (47)',
      book: 'صحيح البخاري',
      narrator: 'عن أبي هريرة رضي الله عنه',
      hadithNumber: '6018',
      grade: 'متفق عليه',
      explanation: 'ضبط اللسان بقول الخير النافع أو التزام الصمت والنجاة.',
      lessons: [
        'وزن الكلام قبل النطق به.',
        'الصمت عن اللغو عبادة وأمان.',
      ],
      orderNumber: 5,
    ),
    WasiyaModel(
      id: 'w_dealings_1',
      categoryId: 'dealings',
      title: 'وصية للوالدين',
      subtopic: 'الوالدين',
      text: 'رضا الرب في رضا الوالد، وسخط الرب في سخط الوالد',
      source: 'سنن الترمذي (1899)',
      book: 'جامع الترمذي',
      narrator: 'عن عبد الله بن عمرو رضي الله عنهما',
      hadithNumber: '1899',
      grade: 'صحيح',
      explanation: 'قرن الله عز وجل رضاه برضا الوالدين والإحسان إليهما.',
      lessons: [
        'وجوب بر الوالدين وطاعتهما في المعروف.',
        'الحذر الشديد من عقوق الوالدين.',
      ],
      orderNumber: 6,
    ),
    WasiyaModel(
      id: 'w_morals_1',
      categoryId: 'morals',
      title: 'وصية في الصدق',
      subtopic: 'الصدق',
      text: 'عليكم بالصدق، فإن الصدق يهدي إلى البر، وإن البر يهدي إلى الجنة',
      source: 'صحيح مسلم (2607)',
      book: 'صحيح مسلم',
      narrator: 'عن عبد الله بن مسعود رضي الله عنه',
      hadithNumber: '2607',
      grade: 'متفق عليه',
      explanation: 'تحري الصدق في القول والعمل يوصل إلى البر والجنة ومرتبة الصديقية.',
      lessons: [
        'ملازمة الصدق في الأقوال والأفعال.',
        'اجتناب الكذب فإنه يهدي إلى الفجور.',
      ],
      orderNumber: 7,
    ),
    WasiyaModel(
      id: 'w_morals_2',
      categoryId: 'morals',
      title: 'وصية في الأمانة',
      subtopic: 'الأمانة',
      text: 'أدِّ الأمانة إلى من ائتمنك، ولا تخن من خانك',
      source: 'سنن أبي داود (3535)',
      book: 'سنن أبي داود',
      narrator: 'عن أبي هريرة رضي الله عنه',
      hadithNumber: '3535',
      grade: 'صحيح',
      explanation: 'وجوب رد الأمانات لأهلها وعدم مقابلة الخيانة بالخيانة.',
      lessons: [
        'أداء الأمانات والحقوق كاملة.',
        'التعامل بأخلاق الإسلام في كل الأحوال.',
      ],
      orderNumber: 8,
    ),
    WasiyaModel(
      id: 'w_morals_3',
      categoryId: 'morals',
      title: 'وصية في الرحمة',
      subtopic: 'الرحمة',
      text: 'الراحمون يرحمهم الرحمن، ارحموا من في الأرض يرحمكم من في السماء',
      source: 'سنن الترمذي (1924)',
      book: 'جامع الترمذي',
      narrator: 'عن عبد الله بن عمرو رضي الله عنهما',
      hadithNumber: '1924',
      grade: 'حسن صحيح',
      explanation: 'بذل الرحمة والرفق لجميع الخلق سبب لنيل رحمة الرحمن جل وعلا.',
      lessons: [
        'الرفق والرحمة بالناس وسائر الكائنات.',
        'الجزاء من جنس العمل.',
      ],
      orderNumber: 9,
    ),
    WasiyaModel(
      id: 'w_food_1',
      categoryId: 'food',
      title: 'وصية في الحلال وترك الريبة',
      subtopic: 'الحلال والحرام',
      text: 'دع ما يريبك إلى ما لا يريبك، فإن الصدق طمأنينة وإن الكذب ريبة',
      source: 'سنن الترمذي (2518)',
      book: 'جامع الترمذي',
      narrator: 'عن الحسن بن علي رضي الله عنهما',
      hadithNumber: '2518',
      grade: 'صحيح',
      explanation: 'ترك الشبهات في المطعم والمكسب والعدول إلى الحلال البين الذي يطمئن له القلب.',
      lessons: [
        'تحري الحلال الطيب واجتناب المشتبهات.',
        'طمأنينة القلب للحق والصدق.',
      ],
      orderNumber: 10,
    ),
    WasiyaModel(
      id: 'w_wealth_1',
      categoryId: 'wealth',
      title: 'وصية الصدق في التجارة والبيع',
      subtopic: 'الصدق في التجارة',
      text: 'البيعان بالخيار ما لم يتفرقا، فإن صدقا وبينا بورك لهما في بيعهما، وإن كتما وكذبا محقت بركة بيعهما',
      source: 'صحيح البخاري (2079) — صحيح مسلم (1532)',
      book: 'صحيح البخاري',
      narrator: 'عن حكيم بن حزام رضي الله عنه',
      hadithNumber: '2079',
      grade: 'متفق عليه',
      explanation: 'الصدق والبيان في المعاملات المالية يجلب البركة، والغش والكتمان يمحقها.',
      lessons: [
        'الصدق والأمانة في التجارة والبيع.',
        'اجتناب الغش وكتمان العيوب.',
      ],
      orderNumber: 11,
    ),
    WasiyaModel(
      id: 'w_heart_1',
      categoryId: 'heart',
      title: 'وصية الإخلاص والنية',
      subtopic: 'الإخلاص',
      text: 'إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى',
      source: 'صحيح البخاري (1) — صحيح مسلم (1907)',
      book: 'صحيح البخاري',
      narrator: 'عن عمر بن الخطاب رضي الله عنه',
      hadithNumber: '1',
      grade: 'متفق عليه',
      explanation: 'مدار قبول الأعمال ومضاعفة أجورها على إخلاص النية لله وحده.',
      lessons: [
        'إخلاص النية لله في كل عمل.',
        'احتساب العادات المباحة بالنية الصالحة.',
      ],
      orderNumber: 12,
    ),
    WasiyaModel(
      id: 'w_occasions_1',
      categoryId: 'occasions',
      title: 'وصية رمضان والقيام',
      subtopic: 'رمضان',
      text: 'من صام رمضان إيمانًا واحتسابًا غفر له ما تقدم من ذنبه، ومن قام ليلة القدر إيمانًا واحتسابًا غفر له ما تقدم من ذنبه',
      source: 'صحيح البخاري (38) — صحيح مسلم (760)',
      book: 'صحيح البخاري',
      narrator: 'عن أبي هريرة رضي الله عنه',
      hadithNumber: '38',
      grade: 'متفق عليه',
      explanation: 'اغتنام موسم رمضان وليلة القدر بالصيام والقيام إيمانًا واحتسابًا للأجر عند الله.',
      lessons: [
        'استحضار نية الإيمان والاحتساب في الصيام والقيام.',
        'تحري ليلة القدر بالعبادة والدعاء.',
      ],
      orderNumber: 13,
    ),
    WasiyaModel(
      id: 'w_tribulations_1',
      categoryId: 'tribulations',
      title: 'وصية الثبات عند الفتن',
      subtopic: 'الثبات',
      text: 'العبادة في الهرج كهجرة إليّ',
      source: 'صحيح مسلم (2948)',
      book: 'صحيح مسلم',
      narrator: 'عن معقل بن يسار رضي الله عنه',
      hadithNumber: '2948',
      grade: 'صحيح مسلم',
      explanation: 'الإقبال على العبادة وذكر الله عند اشتباه الفتن وغفلة الناس يعدل ثواب الهجرة إلى النبي ﷺ.',
      lessons: [
        'الاعتصام بالعبادة والذكر في أوقات الفتن.',
        'عظم أجر الثابت على طاعة الله.',
      ],
      orderNumber: 14,
    ),
  ];
}
