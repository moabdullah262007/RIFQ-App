import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:app_settings/app_settings.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;
import 'package:adhan/adhan.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// NotificationManager — المدير المركزي الحقيقي للإشعارات في تطبيق «رِفْق | RIFQ»
/// يدعم Android 10 / 11 / 12 / 13 / 14+ و iOS 14 / 15 / 16 / 17+
/// يدير الإشعارات الفورية + جميع الإشعارات التلقائية المجدولة:
/// - أوقات الصلاة الخمس والتنبيه قبل الأذان (الصلاة القادمة)
/// - أذكار الصباح والمساء والنوم وذكر اللحظة
/// - آية اليوم وفائدة اليوم والورد القرآني
/// - دعاء اليوم والتذكيرات اليومية
/// ══════════════════════════════════════════════════════════════════════════
class NotificationManager {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static bool _initialized = false;

  static const String generalChannelId = 'rifq_general';
  static const String adhanChannelId = 'rifq_adhan';
  static const String quranChannelId = 'rifq_quran';
  static const String azkarChannelId = 'rifq_azkar';
  static const String remindersChannelId = 'rifq_reminders';

  // معرفات ثابتة للإشعارات المجدولة لمنع التكرار ولسهولة الإلغاء والتحديث
  static const int idFajrAdhan = 101;
  static const int idDhuhrAdhan = 102;
  static const int idAsrAdhan = 103;
  static const int idMaghribAdhan = 104;
  static const int idIshaAdhan = 105;
  static const int idFajrPre = 111;
  static const int idDhuhrPre = 112;
  static const int idAsrPre = 113;
  static const int idMaghribPre = 114;
  static const int idIshaPre = 115;

  static const int idMorningAzkar = 201;
  static const int idEveningAzkar = 202;
  static const int idSleepAzkar = 203;
  static const int idDuhaDhikr = 204;

  static const int idAyahOfTheDay = 301;
  static const int idFaidaOfTheDay = 302;
  static const int idQuranWird = 303;

  static const int idDuaOfTheDay = 401;
  static const int idIstighfarReminder = 402;
  static const int idSalawatReminder = 403;

  static void Function(String payload)? onNotificationTapCallback;

  // ═══════════════════════════════════════════
  // 1. التهيئة ومزامنة الجداول التلقائية
  // ═══════════════════════════════════════════
  static Future<void> init() async {
    if (_initialized) return;

    tz_data.initializeTimeZones();

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: _onNotificationTap,
    );

    await _createAllChannels();
    _initialized = true;

    // مزامنة جميع الإشعارات المجدولة المفعلة عند بدء التطبيق
    await syncAllScheduledNotifications();
  }

  // ═══════════════════════════════════════════
  // 2. فحص حالة الصلاحية الحقيقية من النظام
  // ═══════════════════════════════════════════
  static Future<bool> areNotificationsEnabled() async {
    await init();

    if (Platform.isIOS) {
      final ios = _plugin.resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin>();
      final settings = await ios?.checkPermissions();
      return settings?.isEnabled ?? false;
    }

    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      final enabled = await android?.areNotificationsEnabled();
      return enabled ?? false;
    }

    return false;
  }

  static Future<bool> isPermanentlyBlockedInSystem() async {
    final enabled = await areNotificationsEnabled();
    if (enabled) return false;

    final status = await Permission.notification.status;
    return status.isPermanentlyDenied || status.isRestricted;
  }

  // ═══════════════════════════════════════════
  // 3. طلب الصلاحية الحقيقية + جدولة الإشعارات التلقائية فوراً
  // ═══════════════════════════════════════════
  static Future<bool> requestPermission() async {
    await init();

    if (Platform.isIOS) {
      final ios = _plugin.resolvePlatformSpecificImplementation<
          IOSFlutterLocalNotificationsPlugin>();
      final granted = await ios?.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
      if (granted == true) {
        await syncAllScheduledNotifications();
      }
      return granted ?? false;
    }

    if (Platform.isAndroid) {
      final android = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

      final alreadyEnabled = await android?.areNotificationsEnabled();
      if (alreadyEnabled == true) {
        await _requestExactAlarmIfSupported(android);
        await syncAllScheduledNotifications();
        return true;
      }

      final granted = await android?.requestNotificationsPermission();
      if (granted == true) {
        await _requestExactAlarmIfSupported(android);
        await syncAllScheduledNotifications();
        return true;
      }

      final permStatus = await Permission.notification.request();
      if (permStatus.isGranted || permStatus.isProvisional) {
        final isNowEnabled = await areNotificationsEnabled();
        if (isNowEnabled) {
          await _requestExactAlarmIfSupported(android);
          await syncAllScheduledNotifications();
        }
        return isNowEnabled;
      }
      return false;
    }

    return false;
  }

  static Future<void> _requestExactAlarmIfSupported(
    AndroidFlutterLocalNotificationsPlugin? android,
  ) async {
    try {
      final canScheduleExact = await android?.canScheduleExactNotifications();
      if (canScheduleExact == false) {
        await android?.requestExactAlarmsPermission();
      }
    } catch (_) {
      // بعض الإصدارات لا تتطلب صلاحية منفصلة للـ Exact Alarm
    }
  }

  // ═══════════════════════════════════════════
  // 4. فتح إعدادات إشعارات التطبيق في النظام الحقيقي
  // ═══════════════════════════════════════════
  static Future<void> openNotificationSettings() async {
    await AppSettings.openAppSettings(
      type: AppSettingsType.notification,
    );
  }

  // ═══════════════════════════════════════════
  // 5. إنشاء Notification Channels الحقيقية
  // ═══════════════════════════════════════════
  static Future<void> _createAllChannels() async {
    if (!Platform.isAndroid) return;

    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();

    await android?.createNotificationChannel(
      const AndroidNotificationChannel(
        generalChannelId,
        'إشعارات عامة',
        description: 'إشعارات عامة من تطبيق رِفْق',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );

    await android?.createNotificationChannel(
      const AndroidNotificationChannel(
        adhanChannelId,
        'تنبيهات الأذان وأوقات الصلاة',
        description: 'إشعارات أوقات الصلاة الخمس والتنبيه قبل الأذان',
        importance: Importance.max,
        playSound: true,
        enableVibration: true,
      ),
    );

    await android?.createNotificationChannel(
      const AndroidNotificationChannel(
        quranChannelId,
        'تذكير القرآن وآية وفائدة اليوم',
        description: 'تذكيرات الورد القرآني وآية اليوم وفائدة اليوم',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );

    await android?.createNotificationChannel(
      const AndroidNotificationChannel(
        azkarChannelId,
        'الأذكار اليومية',
        description: 'تذكيرات أذكار الصباح والمساء والنوم',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );

    await android?.createNotificationChannel(
      const AndroidNotificationChannel(
        remindersChannelId,
        'التذكيرات والأدعية',
        description: 'تذكيرات الأدعية المأثورة والتسبيح اليومي',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );
  }

  // ═══════════════════════════════════════════
  // 6. إرسال إشعار فوري حقيقي
  // ═══════════════════════════════════════════
  static Future<bool> showNotification({
    required int id,
    required String title,
    required String body,
    String channelId = generalChannelId,
    String channelName = 'إشعارات عامة',
    Importance importance = Importance.high,
    Priority priority = Priority.high,
    String? sound,
    String? payload,
  }) async {
    await init();

    final enabled = await areNotificationsEnabled();
    if (!enabled) {
      debugPrint('⚠️ الإشعارات غير مفعلة - لا يمكن الإرسال');
      return false;
    }

    final channelActive = await isChannelEnabled(channelId);
    if (!channelActive && channelId != generalChannelId) {
      debugPrint('⚠️ القناة $channelId متوقفة من إعدادات المستخدم');
      return false;
    }

    try {
      await _plugin.show(
        id,
        title,
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            channelId,
            channelName,
            importance: importance,
            priority: priority,
            sound: sound != null
                ? RawResourceAndroidNotificationSound(sound)
                : null,
            playSound: true,
            enableVibration: true,
            icon: '@mipmap/ic_launcher',
          ),
          iOS: const DarwinNotificationDetails(
            presentAlert: true,
            presentBadge: true,
            presentSound: true,
          ),
        ),
        payload: payload,
      );

      return true;
    } catch (e) {
      debugPrint('❌ فشل إرسال الإشعار: $e');
      return false;
    }
  }

  // ═══════════════════════════════════════════
  // 7. جدولة إشعار حقيقي مع Fallback تلقائي على Android 12+
  // ═══════════════════════════════════════════
  static Future<bool> scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledTime,
    String channelId = generalChannelId,
    String channelName = 'إشعارات عامة',
    String? payload,
    bool repeatDaily = false,
  }) async {
    await init();

    final enabled = await areNotificationsEnabled();
    if (!enabled) return false;

    final channelActive = await isChannelEnabled(channelId);
    if (!channelActive && channelId != generalChannelId) return false;

    var targetTime = scheduledTime;
    final now = DateTime.now();
    if (targetTime.isBefore(now)) {
      if (repeatDaily) {
        targetTime = DateTime(
          now.year,
          now.month,
          now.day,
          scheduledTime.hour,
          scheduledTime.minute,
        ).add(const Duration(days: 1));
      } else {
        return false;
      }
    }

    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        channelName,
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        enableVibration: true,
        icon: '@mipmap/ic_launcher',
      ),
      iOS: const DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    final tzTarget = tz.TZDateTime.from(targetTime, tz.local);

    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tzTarget,
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents:
            repeatDaily ? DateTimeComponents.time : null,
        payload: payload,
      );
      return true;
    } catch (e) {
      // في حال عدم توفر صلاحية SCHEDULE_EXACT_ALARM على بعض أجهزة أندرويد 12+
      // نستخدم inexactAllowWhileIdle لضمان وصول الإشعار وعدم سقوطه بصمت
      try {
        await _plugin.zonedSchedule(
          id,
          title,
          body,
          tzTarget,
          details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents:
              repeatDaily ? DateTimeComponents.time : null,
          payload: payload,
        );
        return true;
      } catch (innerErr) {
        debugPrint('❌ فشل جدولة الإشعار ($id): $innerErr');
        return false;
      }
    }
  }

  static Future<void> cancelNotification(int id) async {
    await init();
    await _plugin.cancel(id);
  }

  // ═══════════════════════════════════════════
  // 8. المزامنة الكاملة لجميع الإشعارات التلقائية المجدولة
  // ═══════════════════════════════════════════
  static Future<void> syncAllScheduledNotifications() async {
    final enabled = await areNotificationsEnabled();
    if (!enabled) return;

    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();

    // 1. قناة الأذكار (الصباح، المساء، النوم، الضحى)
    final azkarEnabled = await isChannelEnabled(azkarChannelId);
    if (azkarEnabled) {
      final morningH = prefs.getInt('rifq_morning_azkar_hour') ?? 6;
      final morningM = prefs.getInt('rifq_morning_azkar_min') ?? 30;
      await scheduleNotification(
        id: idMorningAzkar,
        title: 'حان وقت أذكار الصباح ☀️',
        body: 'حصّن يومك ونفسك بأذكار الصباح المباركة وافتتح نهارك بذكر الله.',
        scheduledTime: DateTime(now.year, now.month, now.day, morningH, morningM),
        channelId: azkarChannelId,
        channelName: 'الأذكار اليومية',
        payload: 'ward:morning',
        repeatDaily: true,
      );

      final eveningH = prefs.getInt('rifq_evening_azkar_hour') ?? 17;
      final eveningM = prefs.getInt('rifq_evening_azkar_min') ?? 30;
      await scheduleNotification(
        id: idEveningAzkar,
        title: 'حان وقت أذكار المساء 🌙',
        body: 'أمسينا وأمسى الملك لله، بادر بقراءة ورد المساء لتحصين النفس والسكينة.',
        scheduledTime: DateTime(now.year, now.month, now.day, eveningH, eveningM),
        channelId: azkarChannelId,
        channelName: 'الأذكار اليومية',
        payload: 'ward:evening',
        repeatDaily: true,
      );

      final sleepH = prefs.getInt('rifq_sleep_azkar_hour') ?? 22;
      final sleepM = prefs.getInt('rifq_sleep_azkar_min') ?? 0;
      await scheduleNotification(
        id: idSleepAzkar,
        title: 'حان وقت أذكار النوم 🌌',
        body: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا — اختم يومك بأذكار النوم وآية الكرسي.',
        scheduledTime: DateTime(now.year, now.month, now.day, sleepH, sleepM),
        channelId: azkarChannelId,
        channelName: 'الأذكار اليومية',
        payload: 'ward:sleep',
        repeatDaily: true,
      );

      await scheduleNotification(
        id: idDuhaDhikr,
        title: '☀️ رِفْق | ذكر الضحى',
        body: '«سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ»',
        scheduledTime: DateTime(now.year, now.month, now.day, 9, 30),
        channelId: azkarChannelId,
        channelName: 'الأذكار اليومية',
        payload: 'moment_dhikr',
        repeatDaily: true,
      );
    } else {
      await _plugin.cancel(idMorningAzkar);
      await _plugin.cancel(idEveningAzkar);
      await _plugin.cancel(idSleepAzkar);
      await _plugin.cancel(idDuhaDhikr);
    }

    // 2. قناة القرآن (آية اليوم، فائدة اليوم، الورد القرآني)
    final quranEnabled = await isChannelEnabled(quranChannelId);
    if (quranEnabled) {
      await scheduleNotification(
        id: idAyahOfTheDay,
        title: '📖 آية اليوم — رِفْق',
        body: '﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾ (سورة الرعد: 28)',
        scheduledTime: DateTime(now.year, now.month, now.day, 8, 0),
        channelId: quranChannelId,
        channelName: 'تذكير القرآن وآية وفائدة اليوم',
        payload: 'tadabbur',
        repeatDaily: true,
      );

      await scheduleNotification(
        id: idFaidaOfTheDay,
        title: '💡 فائدة اليوم القرآنية',
        body: 'في كل أسئلة القرآن يأتي الجواب بـ(قُل) إلا في آية الدعاء قال سبحانه مباشرة: ﴿فَإِنِّي قَرِيبٌ﴾.',
        scheduledTime: DateTime(now.year, now.month, now.day, 16, 0),
        channelId: quranChannelId,
        channelName: 'تذكير القرآن وآية وفائدة اليوم',
        payload: 'tadabbur',
        repeatDaily: true,
      );

      await scheduleNotification(
        id: idQuranWird,
        title: '🕌 تذكير الورد القرآني اليومي',
        body: 'اجعل لقلبك نصيباً من كتاب الله اليوم؛ ولو صفحة واحدة تنير بها يومك وصحيفة عملك.',
        scheduledTime: DateTime(now.year, now.month, now.day, 19, 0),
        channelId: quranChannelId,
        channelName: 'تذكير القرآن وآية وفائدة اليوم',
        payload: 'quran',
        repeatDaily: true,
      );
    } else {
      await _plugin.cancel(idAyahOfTheDay);
      await _plugin.cancel(idFaidaOfTheDay);
      await _plugin.cancel(idQuranWird);
    }

    // 3. قناة التذكيرات والأدعية
    final remindersEnabled = await isChannelEnabled(remindersChannelId);
    if (remindersEnabled) {
      await scheduleNotification(
        id: idDuaOfTheDay,
        title: 'دعاء اليوم المأثور 🤲',
        body: '«اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى» — رواه مسلم',
        scheduledTime: DateTime(now.year, now.month, now.day, 14, 0),
        channelId: remindersChannelId,
        channelName: 'التذكيرات والأدعية',
        payload: 'hisn_almuslim',
        repeatDaily: true,
      );

      await scheduleNotification(
        id: idSalawatReminder,
        title: 'الصلاة على النبي ﷺ 🌿',
        body: '«اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ»',
        scheduledTime: DateTime(now.year, now.month, now.day, 20, 30),
        channelId: remindersChannelId,
        channelName: 'التذكيرات والأدعية',
        payload: 'daily_reminders',
        repeatDaily: true,
      );
    } else {
      await _plugin.cancel(idDuaOfTheDay);
      await _plugin.cancel(idIstighfarReminder);
      await _plugin.cancel(idSalawatReminder);
    }

    // 4. قناة الأذان وأوقات الصلاة الخمس + التنبيه قبل الصلاة
    final adhanEnabled = await isChannelEnabled(adhanChannelId);
    if (adhanEnabled) {
      await _schedulePrayerNotifications(prefs, now);
    } else {
      for (final id in [
        idFajrAdhan,
        idDhuhrAdhan,
        idAsrAdhan,
        idMaghribAdhan,
        idIshaAdhan,
        idFajrPre,
        idDhuhrPre,
        idAsrPre,
        idMaghribPre,
        idIshaPre,
      ]) {
        await _plugin.cancel(id);
      }
    }
  }

  static Future<void> _schedulePrayerNotifications(
    SharedPreferences prefs,
    DateTime now,
  ) async {
    try {
      final lat = prefs.getDouble('rifq_lat') ?? 30.0444;
      final lng = prefs.getDouble('rifq_lng') ?? 31.2357;
      final preMinutes = prefs.getInt('rifq_pre_adhan_minutes') ?? 15;

      final coordinates = Coordinates(lat, lng);
      final params = CalculationMethod.egyptian.getParameters();
      params.madhab = Madhab.shafi;

      final todayPrayers = PrayerTimes(
        coordinates,
        DateComponents.from(now),
        params,
      );
      final tomorrowPrayers = PrayerTimes(
        coordinates,
        DateComponents.from(now.add(const Duration(days: 1))),
        params,
      );

      final items = <Map<String, dynamic>>[
        {
          'adhanId': idFajrAdhan,
          'preId': idFajrPre,
          'name': 'الفجر',
          'time': todayPrayers.fajr.isAfter(now)
              ? todayPrayers.fajr
              : tomorrowPrayers.fajr,
        },
        {
          'adhanId': idDhuhrAdhan,
          'preId': idDhuhrPre,
          'name': 'الظهر',
          'time': todayPrayers.dhuhr.isAfter(now)
              ? todayPrayers.dhuhr
              : tomorrowPrayers.dhuhr,
        },
        {
          'adhanId': idAsrAdhan,
          'preId': idAsrPre,
          'name': 'العصر',
          'time': todayPrayers.asr.isAfter(now)
              ? todayPrayers.asr
              : tomorrowPrayers.asr,
        },
        {
          'adhanId': idMaghribAdhan,
          'preId': idMaghribPre,
          'name': 'المغرب',
          'time': todayPrayers.maghrib.isAfter(now)
              ? todayPrayers.maghrib
              : tomorrowPrayers.maghrib,
        },
        {
          'adhanId': idIshaAdhan,
          'preId': idIshaPre,
          'name': 'العشاء',
          'time': todayPrayers.isha.isAfter(now)
              ? todayPrayers.isha
              : tomorrowPrayers.isha,
        },
      ];

      for (final p in items) {
        final DateTime pTime = p['time'] as DateTime;
        final String name = p['name'] as String;
        final int adhanId = p['adhanId'] as int;
        final int preId = p['preId'] as int;

        // جدولة إشعار الأذان الرئيسي
        await scheduleNotification(
          id: adhanId,
          title: 'حان الآن وقت صلاة $name 🕌',
          body: 'حي على الصلاة، حي على الفلاح • دخل الآن وقت صلاة $name',
          scheduledTime: pTime,
          channelId: adhanChannelId,
          channelName: 'تنبيهات الأذان وأوقات الصلاة',
          payload: 'prayers',
        );

        // جدولة إشعار الصلاة القادمة قبل الأذان
        final preTime = pTime.subtract(Duration(minutes: preMinutes));
        if (preTime.isAfter(now)) {
          await scheduleNotification(
            id: preId,
            title: 'اقترب موعد صلاة $name ⏳',
            body: 'تبقى $preMinutes دقيقة على أذان $name. استعد بالوضوء والصلاة.',
            scheduledTime: preTime,
            channelId: adhanChannelId,
            channelName: 'تنبيهات الأذان وأوقات الصلاة',
            payload: 'prayers',
          );
        }
      }
    } catch (e) {
      debugPrint('Error scheduling prayer notifications: $e');
    }
  }

  // ═══════════════════════════════════════════
  // 9. إدارة تفضيلات القنوات الداخلية مع إعادة الجدولة الفورية
  // ═══════════════════════════════════════════
  static Future<bool> isChannelEnabled(String channelId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('notif_channel_$channelId') ?? true;
  }

  static Future<void> setChannelEnabled(String channelId, bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notif_channel_$channelId', enabled);
    // تحديث وإلغاء/إعادة جدولة الإشعارات فوراً عند تغيير الإعداد
    await syncAllScheduledNotifications();
  }

  // ═══════════════════════════════════════════
  // 10. معالج الضغط على الإشعار
  // ═══════════════════════════════════════════
  static void _onNotificationTap(NotificationResponse response) {
    final payload = response.payload;
    if (payload != null && onNotificationTapCallback != null) {
      onNotificationTapCallback!(payload);
    }
  }
}
