import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:intl/intl.dart';

class MisbahaSessionRow {
  final String id;
  final String dhikr;
  final int count;
  final int target;
  final int duration;
  final String createdAt;

  const MisbahaSessionRow({
    required this.id,
    required this.dhikr,
    required this.count,
    required this.target,
    required this.duration,
    required this.createdAt,
  });

  factory MisbahaSessionRow.fromMap(Map<String, dynamic> map) {
    return MisbahaSessionRow(
      id: map['id']?.toString() ?? '',
      dhikr: map['dhikr']?.toString() ?? 'سُبْحَانَ اللَّهِ',
      count: (map['count'] as num?)?.toInt() ?? 0,
      target: (map['target'] as num?)?.toInt() ?? 100,
      duration: (map['duration'] as num?)?.toInt() ?? 0,
      createdAt: map['created_at']?.toString() ?? '',
    );
  }
}

class CustomDhikrRow {
  final String id;
  final String text;
  final int target;
  final String listName;
  final int usageCount;
  final String createdAt;

  const CustomDhikrRow({
    required this.id,
    required this.text,
    required this.target,
    required this.listName,
    required this.usageCount,
    required this.createdAt,
  });

  factory CustomDhikrRow.fromMap(Map<String, dynamic> map) {
    return CustomDhikrRow(
      id: map['id']?.toString() ?? '',
      text: map['text']?.toString() ?? '',
      target: (map['target'] as num?)?.toInt() ?? 100,
      listName: map['list_name']?.toString() ?? 'أذكار عامة',
      usageCount: (map['usage_count'] as num?)?.toInt() ?? 0,
      createdAt: map['created_at']?.toString() ?? '',
    );
  }
}

class DailyStatsRow {
  final String id;
  final String date;
  final int totalCount;
  final int sessionsCount;
  final Map<String, int> dhikrCounts;

  const DailyStatsRow({
    required this.id,
    required this.date,
    required this.totalCount,
    required this.sessionsCount,
    required this.dhikrCounts,
  });

  factory DailyStatsRow.fromMap(Map<String, dynamic> map) {
    Map<String, int> parsedDhikr = {};
    try {
      final rawJson = map['dhikr_counts_json']?.toString() ?? '{}';
      final decoded = jsonDecode(rawJson) as Map<String, dynamic>;
      decoded.forEach((key, value) {
        parsedDhikr[key] = (value as num).toInt();
      });
    } catch (_) {}

    return DailyStatsRow(
      id: map['id']?.toString() ?? '',
      date: map['date']?.toString() ?? '',
      totalCount: (map['total_count'] as num?)?.toInt() ?? 0,
      sessionsCount: (map['sessions_count'] as num?)?.toInt() ?? 0,
      dhikrCounts: parsedDhikr,
    );
  }
}

class MisbahaSettingsRow {
  final int id;
  final int dailyTarget; // 100, 500, 1000, 0 (open)
  final int weeklyTarget;
  final int monthlyTarget;
  final String sound; // wood, water, golden_bell, silent
  final double soundVolume; // 0.0 to 1.0
  final String vibration; // light, medium, strong, none
  final String theme; // gold, emerald, sapphire, brown, rose
  final bool darkMode;
  final String currentDhikr;
  final int currentCount;
  final int currentTarget;
  final int totalCycles;

  const MisbahaSettingsRow({
    required this.id,
    required this.dailyTarget,
    required this.weeklyTarget,
    required this.monthlyTarget,
    required this.sound,
    required this.soundVolume,
    required this.vibration,
    required this.theme,
    required this.darkMode,
    required this.currentDhikr,
    required this.currentCount,
    required this.currentTarget,
    required this.totalCycles,
  });

  factory MisbahaSettingsRow.fromMap(Map<String, dynamic> map) {
    return MisbahaSettingsRow(
      id: (map['id'] as num?)?.toInt() ?? 1,
      dailyTarget: (map['daily_target'] as num?)?.toInt() ?? 100,
      weeklyTarget: (map['weekly_target'] as num?)?.toInt() ?? 3000,
      monthlyTarget: (map['monthly_target'] as num?)?.toInt() ?? 15000,
      sound: map['sound']?.toString() ?? 'wood',
      soundVolume: ((map['sound_volume'] as num?)?.toDouble() ?? 75.0) / 100.0,
      vibration: map['vibration']?.toString() ?? 'medium',
      theme: map['theme']?.toString() ?? 'gold',
      darkMode: ((map['dark_mode'] as num?)?.toInt() ?? 0) == 1,
      currentDhikr: map['current_dhikr']?.toString() ?? 'سُبْحَانَ اللَّهِ',
      currentCount: (map['current_count'] as num?)?.toInt() ?? 0,
      currentTarget: (map['current_target'] as num?)?.toInt() ?? 100,
      totalCycles: (map['total_cycles'] as num?)?.toInt() ?? 0,
    );
  }
}

class MisbahaStreakRow {
  final int id;
  final int currentStreak;
  final int longestStreak;
  final String lastDate;

  const MisbahaStreakRow({
    required this.id,
    required this.currentStreak,
    required this.longestStreak,
    required this.lastDate,
  });

  factory MisbahaStreakRow.fromMap(Map<String, dynamic> map) {
    return MisbahaStreakRow(
      id: (map['id'] as num?)?.toInt() ?? 1,
      currentStreak: (map['current_streak'] as num?)?.toInt() ?? 0,
      longestStreak: (map['longest_streak'] as num?)?.toInt() ?? 0,
      lastDate: map['last_date']?.toString() ?? '',
    );
  }
}

class MisbahaSqliteService {
  static final MisbahaSqliteService instance = MisbahaSqliteService._internal();
  MisbahaSqliteService._internal();

  Database? _db;
  DateTime? _activeSessionStart;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'rifq_central_misbaha_v1.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        // 1. جدول misbaha_sessions
        await db.execute('''
          CREATE TABLE misbaha_sessions (
            id TEXT PRIMARY KEY,
            dhikr TEXT NOT NULL,
            count INTEGER NOT NULL,
            target INTEGER NOT NULL,
            duration INTEGER NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');

        // 2. جدول custom_adhkar
        await db.execute('''
          CREATE TABLE custom_adhkar (
            id TEXT PRIMARY KEY,
            text TEXT NOT NULL,
            target INTEGER NOT NULL DEFAULT 100,
            list_name TEXT NOT NULL DEFAULT 'أذكار عامة',
            usage_count INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
          )
        ''');

        // 3. جدول daily_stats
        await db.execute('''
          CREATE TABLE daily_stats (
            id TEXT PRIMARY KEY,
            date TEXT NOT NULL UNIQUE,
            total_count INTEGER NOT NULL DEFAULT 0,
            sessions_count INTEGER NOT NULL DEFAULT 0,
            dhikr_counts_json TEXT NOT NULL DEFAULT '{}'
          )
        ''');

        // 4. جدول settings
        await db.execute('''
          CREATE TABLE settings (
            id INTEGER PRIMARY KEY,
            daily_target INTEGER NOT NULL DEFAULT 100,
            weekly_target INTEGER NOT NULL DEFAULT 3000,
            monthly_target INTEGER NOT NULL DEFAULT 15000,
            sound TEXT NOT NULL DEFAULT 'wood',
            sound_volume INTEGER NOT NULL DEFAULT 75,
            vibration TEXT NOT NULL DEFAULT 'medium',
            theme TEXT NOT NULL DEFAULT 'gold',
            dark_mode INTEGER NOT NULL DEFAULT 0,
            current_dhikr TEXT NOT NULL DEFAULT 'سُبْحَانَ اللَّهِ',
            current_count INTEGER NOT NULL DEFAULT 0,
            current_target INTEGER NOT NULL DEFAULT 100,
            total_cycles INTEGER NOT NULL DEFAULT 0
          )
        ''');

        // 5. جدول streak
        await db.execute('''
          CREATE TABLE streak (
            id INTEGER PRIMARY KEY,
            current_streak INTEGER NOT NULL DEFAULT 0,
            longest_streak INTEGER NOT NULL DEFAULT 0,
            last_date TEXT NOT NULL DEFAULT ''
          )
        ''');

        await db.insert('settings', {
          'id': 1,
          'daily_target': 100,
          'weekly_target': 3000,
          'monthly_target': 15000,
          'sound': 'wood',
          'sound_volume': 75,
          'vibration': 'medium',
          'theme': 'gold',
          'dark_mode': 0,
          'current_dhikr': 'سُبْحَانَ اللَّهِ',
          'current_count': 0,
          'current_target': 100,
          'total_cycles': 0,
        });

        await db.insert('streak', {
          'id': 1,
          'current_streak': 0,
          'longest_streak': 0,
          'last_date': '',
        });
      },
    );
    return _db!;
  }

  String _todayString() {
    return DateFormat('yyyy-MM-dd').format(DateTime.now());
  }

  Future<MisbahaSettingsRow> getSettings() async {
    final db = await database;
    final rows = await db.query('settings', where: 'id = 1');
    if (rows.isEmpty) {
      return const MisbahaSettingsRow(
        id: 1,
        dailyTarget: 100,
        weeklyTarget: 3000,
        monthlyTarget: 15000,
        sound: 'wood',
        soundVolume: 0.75,
        vibration: 'medium',
        theme: 'gold',
        darkMode: false,
        currentDhikr: 'سُبْحَانَ اللَّهِ',
        currentCount: 0,
        currentTarget: 100,
        totalCycles: 0,
      );
    }
    return MisbahaSettingsRow.fromMap(rows.first);
  }

  Future<void> updateSettings(Map<String, dynamic> values) async {
    final db = await database;
    await db.update('settings', values, where: 'id = 1');
  }

  Future<MisbahaStreakRow> getStreak() async {
    final db = await database;
    final rows = await db.query('streak', where: 'id = 1');
    if (rows.isEmpty) {
      return const MisbahaStreakRow(id: 1, currentStreak: 0, longestStreak: 0, lastDate: '');
    }
    return MisbahaStreakRow.fromMap(rows.first);
  }

  Future<DailyStatsRow> getTodayStats() async {
    final db = await database;
    final today = _todayString();
    final rows = await db.query('daily_stats', where: 'date = ?', whereArgs: [today]);
    if (rows.isEmpty) {
      final row = {
        'id': 'stat_$today',
        'date': today,
        'total_count': 0,
        'sessions_count': 0,
        'dhikr_counts_json': '{}',
      };
      await db.insert('daily_stats', row);
      return DailyStatsRow.fromMap(row);
    }
    return DailyStatsRow.fromMap(rows.first);
  }

  Future<List<DailyStatsRow>> getAllDailyStats() async {
    final db = await database;
    final rows = await db.query('daily_stats', orderBy: 'date DESC');
    return rows.map((r) => DailyStatsRow.fromMap(r)).toList();
  }

  Future<List<MisbahaSessionRow>> getSessions() async {
    final db = await database;
    final rows = await db.query('misbaha_sessions', orderBy: 'created_at DESC');
    return rows.map((r) => MisbahaSessionRow.fromMap(r)).toList();
  }

  Future<List<CustomDhikrRow>> getCustomAdhkar() async {
    final db = await database;
    final rows = await db.query('custom_adhkar', orderBy: 'created_at DESC');
    return rows.map((r) => CustomDhikrRow.fromMap(r)).toList();
  }

  Future<void> addCustomDhikr({
    required String text,
    required int target,
    required String listName,
  }) async {
    final db = await database;
    final now = DateTime.now();
    await db.insert('custom_adhkar', {
      'id': 'custom_${now.millisecondsSinceEpoch}',
      'text': text.trim(),
      'target': target,
      'list_name': listName,
      'usage_count': 0,
      'created_at': now.toIso8601String(),
    });
  }

  Future<void> updateCustomDhikr({
    required String id,
    required String text,
    required int target,
    required String listName,
  }) async {
    final db = await database;
    await db.update(
      'custom_adhkar',
      {
        'text': text.trim(),
        'target': target,
        'list_name': listName,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> deleteCustomDhikr(String id) async {
    final db = await database;
    await db.delete('custom_adhkar', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteSession(String id) async {
    final db = await database;
    await db.delete('misbaha_sessions', where: 'id = ?', whereArgs: [id]);
  }

  /// Increments counter by 1 and returns true if cycle completed
  Future<bool> incrementTasbeeh() async {
    final db = await database;
    final settings = await getSettings();
    final todayStats = await getTodayStats();
    final now = DateTime.now();

    if (_activeSessionStart == null || settings.currentCount == 0) {
      _activeSessionStart = now;
    }

    final nextCount = settings.currentCount + 1;
    final target = settings.currentTarget;
    final dhikr = settings.currentDhikr;
    bool completedCycle = false;

    final updatedDhikrMap = Map<String, int>.from(todayStats.dhikrCounts);
    updatedDhikrMap[dhikr] = (updatedDhikrMap[dhikr] ?? 0) + 1;

    // Increment usage_count in custom_adhkar if matching
    await db.rawUpdate(
      'UPDATE custom_adhkar SET usage_count = usage_count + 1 WHERE text = ?',
      [dhikr],
    );

    if (target > 0 && nextCount >= target) {
      completedCycle = true;
      final durationSec = _activeSessionStart != null
          ? now.difference(_activeSessionStart!).inSeconds.clamp(1, 86400)
          : (target * 0.8).round();

      await db.insert('misbaha_sessions', {
        'id': 'sess_${now.millisecondsSinceEpoch}',
        'dhikr': dhikr,
        'count': target,
        'target': target,
        'duration': durationSec,
        'created_at': now.toIso8601String(),
      });

      await db.update(
        'settings',
        {
          'current_count': 0,
          'total_cycles': settings.totalCycles + 1,
        },
        where: 'id = 1',
      );

      await db.update(
        'daily_stats',
        {
          'total_count': todayStats.totalCount + 1,
          'sessions_count': todayStats.sessionsCount + 1,
          'dhikr_counts_json': jsonEncode(updatedDhikrMap),
        },
        where: 'date = ?',
        whereArgs: [todayStats.date],
      );

      _activeSessionStart = null;
    } else {
      await db.update(
        'settings',
        {'current_count': nextCount},
        where: 'id = 1',
      );

      await db.update(
        'daily_stats',
        {
          'total_count': todayStats.totalCount + 1,
          'sessions_count': todayStats.sessionsCount == 0 ? 1 : todayStats.sessionsCount,
          'dhikr_counts_json': jsonEncode(updatedDhikrMap),
        },
        where: 'date = ?',
        whereArgs: [todayStats.date],
      );
    }

    await _recomputeStreak();
    return completedCycle;
  }

  Future<void> decrementTasbeeh() async {
    final db = await database;
    final settings = await getSettings();
    final todayStats = await getTodayStats();

    if (settings.currentCount > 0) {
      await db.update(
        'settings',
        {'current_count': settings.currentCount - 1},
        where: 'id = 1',
      );
    }

    if (todayStats.totalCount > 0) {
      await db.update(
        'daily_stats',
        {'total_count': todayStats.totalCount - 1},
        where: 'date = ?',
        whereArgs: [todayStats.date],
      );
    }
  }

  Future<void> resetCurrentCounter({bool logPartialSession = true}) async {
    final db = await database;
    final settings = await getSettings();
    final now = DateTime.now();

    if (logPartialSession && settings.currentCount > 0) {
      final durationSec = _activeSessionStart != null
          ? now.difference(_activeSessionStart!).inSeconds.clamp(1, 86400)
          : settings.currentCount;

      await db.insert('misbaha_sessions', {
        'id': 'sess_${now.millisecondsSinceEpoch}',
        'dhikr': settings.currentDhikr,
        'count': settings.currentCount,
        'target': settings.currentTarget,
        'duration': durationSec,
        'created_at': now.toIso8601String(),
      });
    }

    await db.update('settings', {'current_count': 0}, where: 'id = 1');
    _activeSessionStart = null;
  }

  Future<void> resetAllStatistics() async {
    final db = await database;
    await db.delete('misbaha_sessions');
    await db.delete('daily_stats');
    await db.update(
      'settings',
      {'current_count': 0, 'total_cycles': 0},
      where: 'id = 1',
    );
    await db.update(
      'streak',
      {'current_streak': 0, 'longest_streak': 0, 'last_date': ''},
      where: 'id = 1',
    );
    await db.rawUpdate('UPDATE custom_adhkar SET usage_count = 0');
    _activeSessionStart = null;
  }

  Future<void> _recomputeStreak() async {
    final db = await database;
    final allStats = await getAllDailyStats();
    final activeDates = allStats
        .where((s) => s.totalCount > 0)
        .map((s) => s.date)
        .toList()
      ..sort();

    if (activeDates.isEmpty) {
      await db.update(
        'streak',
        {'current_streak': 0, 'longest_streak': 0, 'last_date': ''},
        where: 'id = 1',
      );
      return;
    }

    int longest = 0;
    int temp = 0;
    for (int i = 0; i < activeDates.length; i++) {
      if (i == 0) {
        temp = 1;
      } else {
        final prev = DateTime.parse(activeDates[i - 1]);
        final curr = DateTime.parse(activeDates[i]);
        final diff = curr.difference(prev).inDays;
        if (diff == 1) {
          temp++;
        } else if (diff > 1) {
          temp = 1;
        }
      }
      if (temp > longest) longest = temp;
    }

    final todayStr = _todayString();
    final yesterdayStr = DateFormat('yyyy-MM-dd')
        .format(DateTime.now().subtract(const Duration(days: 1)));
    final activeSet = activeDates.toSet();

    int current = 0;
    DateTime cursor = DateTime.now();
    if (activeSet.contains(todayStr) || activeSet.contains(yesterdayStr)) {
      if (!activeSet.contains(todayStr)) {
        cursor = DateTime.now().subtract(const Duration(days: 1));
      }
      while (true) {
        final dStr = DateFormat('yyyy-MM-dd').format(cursor);
        if (activeSet.contains(dStr)) {
          current++;
          cursor = cursor.subtract(const Duration(days: 1));
        } else {
          break;
        }
      }
    }

    await db.update(
      'streak',
      {
        'current_streak': current,
        'longest_streak': longest > current ? longest : current,
        'last_date': activeDates.last,
      },
      where: 'id = 1',
    );
  }
}
