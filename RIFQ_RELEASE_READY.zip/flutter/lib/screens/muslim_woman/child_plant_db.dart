import 'dart:math' as math;
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

/// ══════════════════════════════════════════════════════════════════════════
/// نماذج البيانات الحقيقية لميزة «نبتة طفلي» (SQLite 100% - بدون أي بيانات وهمية)
/// ══════════════════════════════════════════════════════════════════════════

class ChildRecordModel {
  final int? id;
  final String name;
  final String birthDate; // YYYY-MM-DD
  final String gender; // 'male' | 'female'
  final String? photoPath;
  final String createdAt;

  const ChildRecordModel({
    this.id,
    required this.name,
    required this.birthDate,
    required this.gender,
    this.photoPath,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'birth_date': birthDate,
        'gender': gender,
        'photo_path': photoPath,
        'created_at': createdAt,
      };

  factory ChildRecordModel.fromMap(Map<String, dynamic> map) => ChildRecordModel(
        id: map['id'] as int?,
        name: (map['name'] as String?)?.trim().isNotEmpty == true
            ? map['name'] as String
            : 'طفلي',
        birthDate: map['birth_date'] as String,
        gender: (map['gender'] as String?) ?? 'male',
        photoPath: map['photo_path'] as String?,
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class MeasurementRecordModel {
  final int? id;
  final int childId;
  final String date; // YYYY-MM-DD
  final double? height;
  final double? weight;
  final double? headCircumference;
  final String notes;
  final String createdAt;

  const MeasurementRecordModel({
    this.id,
    required this.childId,
    required this.date,
    this.height,
    this.weight,
    this.headCircumference,
    required this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'child_id': childId,
        'date': date,
        'height': height,
        'weight': weight,
        'head_circumference': headCircumference,
        'notes': notes,
        'created_at': createdAt,
      };

  factory MeasurementRecordModel.fromMap(Map<String, dynamic> map) =>
      MeasurementRecordModel(
        id: map['id'] as int?,
        childId: map['child_id'] as int,
        date: map['date'] as String,
        height: (map['height'] as num?)?.toDouble(),
        weight: (map['weight'] as num?)?.toDouble(),
        headCircumference: (map['head_circumference'] as num?)?.toDouble(),
        notes: (map['notes'] as String?) ?? '',
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class AppointmentRecordModel {
  final int? id;
  final int childId;
  final String title;
  final String date; // YYYY-MM-DD
  final String time; // HH:mm
  final String doctorName;
  final String notes;
  final int reminderEnabled; // 1 or 0
  final String createdAt;

  const AppointmentRecordModel({
    this.id,
    required this.childId,
    required this.title,
    required this.date,
    required this.time,
    required this.doctorName,
    required this.notes,
    required this.reminderEnabled,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'child_id': childId,
        'title': title,
        'date': date,
        'time': time,
        'doctor_name': doctorName,
        'notes': notes,
        'reminder_enabled': reminderEnabled,
        'created_at': createdAt,
      };

  factory AppointmentRecordModel.fromMap(Map<String, dynamic> map) =>
      AppointmentRecordModel(
        id: map['id'] as int?,
        childId: map['child_id'] as int,
        title: map['title'] as String,
        date: map['date'] as String,
        time: map['time'] as String,
        doctorName: (map['doctor_name'] as String?) ?? '',
        notes: (map['notes'] as String?) ?? '',
        reminderEnabled: (map['reminder_enabled'] as int?) ?? 1,
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class NoteRecordModel {
  final int? id;
  final int childId;
  final String title;
  final String content;
  final String createdAt;

  const NoteRecordModel({
    this.id,
    required this.childId,
    required this.title,
    required this.content,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'child_id': childId,
        'title': title,
        'content': content,
        'created_at': createdAt,
      };

  factory NoteRecordModel.fromMap(Map<String, dynamic> map) => NoteRecordModel(
        id: map['id'] as int?,
        childId: map['child_id'] as int,
        title: map['title'] as String,
        content: (map['content'] as String?) ?? '',
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

class ActivityRecordModel {
  final int? id;
  final int childId;
  final String type; // 'measurement' | 'appointment' | 'note' | 'birthday'
  final String title;
  final String subtitle;
  final String date;
  final String createdAt;

  const ActivityRecordModel({
    this.id,
    required this.childId,
    required this.type,
    required this.title,
    required this.subtitle,
    required this.date,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'child_id': childId,
        'type': type,
        'title': title,
        'subtitle': subtitle,
        'date': date,
        'created_at': createdAt,
      };

  factory ActivityRecordModel.fromMap(Map<String, dynamic> map) =>
      ActivityRecordModel(
        id: map['id'] as int?,
        childId: map['child_id'] as int,
        type: (map['type'] as String?) ?? 'note',
        title: (map['title'] as String?) ?? '',
        subtitle: (map['subtitle'] as String?) ?? '',
        date: (map['date'] as String?) ?? '',
        createdAt: (map['created_at'] as String?) ?? '',
      );
}

/// ══════════════════════════════════════════════════════════════════════════
/// حساب العمر الدقيق تلقائياً من تاريخ الميلاد + المرحلة والتدرج البصري المستمر
/// ══════════════════════════════════════════════════════════════════════════

class CalculatedChildAgeInfo {
  final int years;
  final int months;
  final int days;
  final double totalMonths;
  final int totalDays;
  final String formattedArabic;
  final int stageIndex; // 0..4
  final String stageTitle;
  final String stageDescription;
  final double visualScale;

  const CalculatedChildAgeInfo({
    required this.years,
    required this.months,
    required this.days,
    required this.totalMonths,
    required this.totalDays,
    required this.formattedArabic,
    required this.stageIndex,
    required this.stageTitle,
    required this.stageDescription,
    required this.visualScale,
  });

  static CalculatedChildAgeInfo fromBirthDate(String birthDateStr) {
    final now = DateTime.now();
    final birth = DateTime.tryParse(birthDateStr) ?? now;
    if (birth.isAfter(now)) {
      return const CalculatedChildAgeInfo(
        years: 0,
        months: 0,
        days: 0,
        totalMonths: 0,
        totalDays: 0,
        formattedArabic: 'حديث الولادة',
        stageIndex: 0,
        stageTitle: 'بذرة / برعم (من الولادة - 6 أشهر)',
        stageDescription:
            'مرحلة الاحتضان والتواصل البصري والسمعي الأولي مع الأم (مرجع تعليمي عام: WHO / CDC).',
        visualScale: 0.82,
      );
    }

    int years = now.year - birth.year;
    int months = now.month - birth.month;
    int days = now.day - birth.day;

    if (days < 0) {
      months -= 1;
      final prevMonthLastDay = DateTime(now.year, now.month, 0).day;
      days += prevMonthLastDay;
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }

    final totalDays = math.max(0, now.difference(birth).inDays);
    final totalMonths = years * 12 + months + (days / 30.0);

    final parts = <String>[];
    if (years > 0) {
      parts.add(years == 1 ? '1 سنة' : years == 2 ? 'سنتان' : '$years سنوات');
    }
    if (months > 0) {
      parts.add(months == 1 ? '1 شهر' : months == 2 ? 'شهران' : '$months أشهر');
    }
    if (years == 0 && months == 0) {
      parts.add(days <= 1 ? 'يوم واحد' : '$days أيام');
    } else if (years == 0 && days > 0) {
      parts.add('$days يوم');
    }

    int stageIndex = 0;
    String stageTitle = 'بذرة / برعم (من الولادة - 6 أشهر)';
    String stageDesc =
        'يتفاعل الصغير مع صوت الأم وابتسامتها، وتبدأ حواسه بالانتباه للضوء والأصوات المحيطة (WHO / CDC).';

    if (totalMonths >= 6 && totalMonths < 12) {
      stageIndex = 1;
      stageTitle = 'نبتة صغيرة (6 - 12 شهراً)';
      stageDesc =
          'مرحلة الجلوس المتوازن، استكشاف الأشياء باليدين، بدء الحبو والمناغاة بمقاطع صوتية (WHO / CDC).';
    } else if (totalMonths >= 12 && totalMonths < 24) {
      stageIndex = 2;
      stageTitle = 'نبتة أكثر نمواً (1 - 2 سنة)';
      stageDesc =
          'مرحلة الخطوات الأولى والمشي المستقل، نطق الكلمات الأولى، وفهم الإشارات البسيطة (WHO / CDC).';
    } else if (totalMonths >= 24 && totalMonths < 48) {
      stageIndex = 3;
      stageTitle = 'نبتة كبيرة مورقة (2 - 4 سنوات)';
      stageDesc =
          'مرحلة تكوين الجمل، اللعب التخيلي، الجري بتوازن، وتنمية المهارات الاجتماعية (WHO / CDC).';
    } else if (totalMonths >= 48) {
      stageIndex = 4;
      stageTitle = 'شجرة صغيرة راسخة (أكثر من 4 سنوات)';
      stageDesc =
          'مرحلة الاستقلالية التدريجية في المهارات اليومية، سرد القصص، والتعلم التعاوني (WHO / CDC).';
    }

    final continuousScale =
        (0.82 + (math.log(1 + totalDays / 45.0) / math.ln10) * 0.36)
            .clamp(0.80, 1.45);

    return CalculatedChildAgeInfo(
      years: years,
      months: months,
      days: days,
      totalMonths: totalMonths,
      totalDays: totalDays,
      formattedArabic: parts.join(' و '),
      stageIndex: stageIndex,
      stageTitle: stageTitle,
      stageDescription: stageDesc,
      visualScale: continuousScale,
    );
  }
}

/// ══════════════════════════════════════════════════════════════════════════
/// خدمة قاعدة البيانات SQLite (5 جداول حقيقية) + خدمة الإشعارات المحلية الحقيقية
/// ══════════════════════════════════════════════════════════════════════════

class ChildPlantSqliteService {
  ChildPlantSqliteService._();
  static final ChildPlantSqliteService instance = ChildPlantSqliteService._();

  Database? _db;
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();
  bool _notificationsInitialized = false;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'rifq_child_plant.db');

    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        // 1. جدول الأطفال
        await db.execute('''
          CREATE TABLE children (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            birth_date TEXT NOT NULL,
            gender TEXT,
            photo_path TEXT,
            created_at TEXT
          )
        ''');

        // 2. جدول القياسات
        await db.execute('''
          CREATE TABLE measurements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER,
            date TEXT NOT NULL,
            height REAL,
            weight REAL,
            head_circumference REAL,
            notes TEXT,
            created_at TEXT
          )
        ''');

        // 3. جدول المواعيد
        await db.execute('''
          CREATE TABLE appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER,
            title TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            doctor_name TEXT,
            notes TEXT,
            reminder_enabled INTEGER DEFAULT 1,
            created_at TEXT
          )
        ''');

        // 4. جدول الملاحظات
        await db.execute('''
          CREATE TABLE notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER,
            title TEXT NOT NULL,
            content TEXT,
            created_at TEXT
          )
        ''');

        // 5. جدول سجل الأحداث الموحد
        await db.execute('''
          CREATE TABLE activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER,
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            subtitle TEXT,
            date TEXT NOT NULL,
            created_at TEXT
          )
        ''');
      },
    );
    return _db!;
  }

  /// تهيئة نظام الإشعارات الحقيقي (يعمل بدون إنترنت وبعد إغلاق التطبيق وبعد إعادة تشغيل الجهاز)
  Future<void> initRealNotifications() async {
    if (_notificationsInitialized) return;
    tz_data.initializeTimeZones();

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const settings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );

    await _notifications.initialize(settings);

    final androidImplementation =
        _notifications.resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();
    await androidImplementation?.requestNotificationsPermission();
    await androidImplementation?.requestExactAlarmsPermission();

    _notificationsInitialized = true;
    await rescheduleAllActiveAppointments();
  }

  /// جدولة إشعار موعد حقيقي مع الحفاظ التام على الخصوصية (بدون تفاصيل حساسة)
  Future<void> scheduleAppointmentNotification(
      AppointmentRecordModel appt) async {
    await initRealNotifications();
    if (appt.id == null) return;

    if (appt.reminderEnabled == 0) {
      await _notifications.cancel(appt.id!);
      return;
    }

    final dateParts = appt.date.split('-');
    final timeParts = appt.time.split(':');
    if (dateParts.length < 3 || timeParts.length < 2) return;

    final scheduledDateTime = DateTime(
      int.tryParse(dateParts[0]) ?? DateTime.now().year,
      int.tryParse(dateParts[1]) ?? DateTime.now().month,
      int.tryParse(dateParts[2]) ?? DateTime.now().day,
      int.tryParse(timeParts[0]) ?? 9,
      int.tryParse(timeParts[1]) ?? 0,
    );

    if (scheduledDateTime.isBefore(DateTime.now())) return;

    final tzScheduled = tz.TZDateTime.from(scheduledDateTime, tz.local);

    await _notifications.zonedSchedule(
      appt.id!,
      'موعد طفلك',
      'لديك موعد اليوم',
      tzScheduled,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'child_appointments_channel',
          'مواعيد الطفل',
          channelDescription: 'تنبيهات مواعيد نبتة طفلي في قسم رفق للمرأة',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> cancelAppointmentNotification(int appointmentId) async {
    await initRealNotifications();
    await _notifications.cancel(appointmentId);
  }

  Future<void> rescheduleAllActiveAppointments() async {
    final db = await database;
    final rows = await db.query(
      'appointments',
      where: 'reminder_enabled = ?',
      whereArgs: [1],
    );
    for (final row in rows) {
      final appt = AppointmentRecordModel.fromMap(row);
      await scheduleAppointmentNotification(appt);
    }
  }

  // ── عمليات CRUD للأطفال ──
  Future<List<ChildRecordModel>> getChildren() async {
    final db = await database;
    final rows = await db.query('children', orderBy: 'id ASC');
    return rows.map(ChildRecordModel.fromMap).toList();
  }

  Future<int> insertChild(ChildRecordModel child) async {
    final db = await database;
    return db.insert('children', child.toMap());
  }

  Future<void> deleteAllChildData(int childId) async {
    final db = await database;
    final appts = await getAppointments(childId);
    for (final a in appts) {
      if (a.id != null) {
        await cancelAppointmentNotification(a.id!);
      }
    }
    await db.delete('measurements', where: 'child_id = ?', whereArgs: [childId]);
    await db.delete('appointments', where: 'child_id = ?', whereArgs: [childId]);
    await db.delete('notes', where: 'child_id = ?', whereArgs: [childId]);
    await db.delete('activities', where: 'child_id = ?', whereArgs: [childId]);
    await db.delete('children', where: 'id = ?', whereArgs: [childId]);
  }

  // ── عمليات CRUD للقياسات ──
  Future<List<MeasurementRecordModel>> getMeasurements(int childId) async {
    final db = await database;
    final rows = await db.query(
      'measurements',
      where: 'child_id = ?',
      whereArgs: [childId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(MeasurementRecordModel.fromMap).toList();
  }

  Future<int> saveMeasurement(MeasurementRecordModel m) async {
    final db = await database;
    if (m.id != null) {
      return db.update(
        'measurements',
        m.toMap(),
        where: 'id = ?',
        whereArgs: [m.id],
      );
    }
    final id = await db.insert('measurements', m.toMap());
    final summary = <String>[];
    if (m.height != null) summary.add('الطول: ${m.height} سم');
    if (m.weight != null) summary.add('الوزن: ${m.weight} كغ');
    if (m.headCircumference != null) {
      summary.add('محيط الرأس: ${m.headCircumference} سم');
    }
    await insertActivity(
      ActivityRecordModel(
        childId: m.childId,
        type: 'measurement',
        title: 'قياس نمو',
        subtitle: summary.join(' • '),
        date: m.date,
        createdAt: m.createdAt,
      ),
    );
    return id;
  }

  Future<void> deleteMeasurement(int id) async {
    final db = await database;
    await db.delete('measurements', where: 'id = ?', whereArgs: [id]);
  }

  // ── عمليات CRUD للمواعيد ──
  Future<List<AppointmentRecordModel>> getAppointments(int childId) async {
    final db = await database;
    final rows = await db.query(
      'appointments',
      where: 'child_id = ?',
      whereArgs: [childId],
      orderBy: 'date ASC, time ASC',
    );
    return rows.map(AppointmentRecordModel.fromMap).toList();
  }

  Future<int> saveAppointment(AppointmentRecordModel a) async {
    final db = await database;
    int savedId;
    if (a.id != null) {
      await db.update(
        'appointments',
        a.toMap(),
        where: 'id = ?',
        whereArgs: [a.id],
      );
      savedId = a.id!;
    } else {
      savedId = await db.insert('appointments', a.toMap());
      await insertActivity(
        ActivityRecordModel(
          childId: a.childId,
          type: 'appointment',
          title: 'موعد: ${a.title}',
          subtitle: '${a.date} الساعة ${a.time}',
          date: a.date,
          createdAt: a.createdAt,
        ),
      );
    }

    final withId = AppointmentRecordModel(
      id: savedId,
      childId: a.childId,
      title: a.title,
      date: a.date,
      time: a.time,
      doctorName: a.doctorName,
      notes: a.notes,
      reminderEnabled: a.reminderEnabled,
      createdAt: a.createdAt,
    );
    await scheduleAppointmentNotification(withId);
    return savedId;
  }

  Future<void> deleteAppointment(int id) async {
    final db = await database;
    await cancelAppointmentNotification(id);
    await db.delete('appointments', where: 'id = ?', whereArgs: [id]);
  }

  // ── عمليات CRUD للملاحظات ──
  Future<List<NoteRecordModel>> getNotes(int childId) async {
    final db = await database;
    final rows = await db.query(
      'notes',
      where: 'child_id = ?',
      whereArgs: [childId],
      orderBy: 'id DESC',
    );
    return rows.map(NoteRecordModel.fromMap).toList();
  }

  Future<int> saveNote(NoteRecordModel n) async {
    final db = await database;
    if (n.id != null) {
      return db.update('notes', n.toMap(), where: 'id = ?', whereArgs: [n.id]);
    }
    final id = await db.insert('notes', n.toMap());
    await insertActivity(
      ActivityRecordModel(
        childId: n.childId,
        type: 'note',
        title: 'ملاحظة: ${n.title}',
        subtitle: n.content,
        date: n.createdAt.length >= 10 ? n.createdAt.substring(0, 10) : n.createdAt,
        createdAt: n.createdAt,
      ),
    );
    return id;
  }

  Future<void> deleteNote(int id) async {
    final db = await database;
    await db.delete('notes', where: 'id = ?', whereArgs: [id]);
  }

  // ── عمليات سجل الطفل الموحد ──
  Future<List<ActivityRecordModel>> getActivities(int childId) async {
    final db = await database;
    final rows = await db.query(
      'activities',
      where: 'child_id = ?',
      whereArgs: [childId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(ActivityRecordModel.fromMap).toList();
  }

  Future<int> insertActivity(ActivityRecordModel act) async {
    final db = await database;
    return db.insert('activities', act.toMap());
  }
}
