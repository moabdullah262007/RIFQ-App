import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// أيقونات SVG الحقيقية والنبتة التفاعلية لميزة «نبتة طفلي» (بدون أي إيموجي)
/// ══════════════════════════════════════════════════════════════════════════

class ChildPlantSvgIcons {
  static Widget sprout({double size = 24}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 22V11" stroke="#4CAF82" stroke-width="2.2" stroke-linecap="round"/>
          <path d="M12 13C8.5 13 5 10.5 5 6.5C9 6.5 12 9 12 13Z" fill="#4CAF82" fill-opacity="0.22" stroke="#4CAF82" stroke-width="2"/>
          <path d="M12 11C15.5 11 19 8.5 19 4.5C15 4.5 12 7 12 11Z" fill="#5B5FEF" fill-opacity="0.28" stroke="#4CAF82" stroke-width="2"/>
          <path d="M8 22H16" stroke="#5B5FEF" stroke-width="2" stroke-linecap="round"/>
        </svg>
        ''',
        width: size,
        height: size,
      );

  static Widget ruler({double size = 22}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="6" width="18" height="12" rx="2.5" stroke="#5B5FEF" stroke-width="2" fill="#EEEEFF"/>
          <path d="M7 6V10M11 6V12M15 6V10M19 6V12" stroke="#25263A" stroke-width="1.8" stroke-linecap="round"/>
        </svg>
        ''',
        width: size,
        height: size,
      );

  static Widget weightScale({double size = 22}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="3" width="18" height="18" rx="4" stroke="#4CAF82" stroke-width="2" fill="#F7F7FC"/>
          <path d="M8 10C9.5 7.5 14.5 7.5 16 10" stroke="#5B5FEF" stroke-width="2" stroke-linecap="round"/>
          <path d="M12 11L14 8" stroke="#25263A" stroke-width="2" stroke-linecap="round"/>
          <circle cx="12" cy="11" r="1.5" fill="#5B5FEF"/>
        </svg>
        ''',
        width: size,
        height: size,
      );

  static Widget headCircumference({double size = 22}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="7.5" stroke="#E99AC7" stroke-width="2" fill="#EEEEFF"/>
          <ellipse cx="12" cy="10.5" rx="8.5" ry="3" stroke="#5B5FEF" stroke-width="1.8" stroke-dasharray="3 2"/>
        </svg>
        ''',
        width: size,
        height: size,
      );

  static Widget calendar({double size = 22}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="5" width="18" height="16" rx="3" stroke="#5B5FEF" stroke-width="2" fill="#FFFFFF"/>
          <path d="M3 10H21" stroke="#E99AC7" stroke-width="2"/>
          <path d="M8 3V7M16 3V7" stroke="#4CAF82" stroke-width="2" stroke-linecap="round"/>
          <circle cx="12" cy="15" r="2" fill="#4CAF82"/>
        </svg>
        ''',
        width: size,
        height: size,
      );

  static Widget notebook({double size = 22}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="5" y="3" width="14" height="18" rx="2.5" stroke="#5B5FEF" stroke-width="2" fill="#EEEEFF"/>
          <path d="M9 8H15M9 12H15M9 16H13" stroke="#25263A" stroke-width="1.8" stroke-linecap="round"/>
        </svg>
        ''',
        width: size,
        height: size,
      );

  static Widget activityLog({double size = 22}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M4 19V5M4 19H20" stroke="#5B5FEF" stroke-width="2" stroke-linecap="round"/>
          <path d="M7 14L11 10L15 13L19 7" stroke="#4CAF82" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="19" cy="7" r="2" fill="#5B5FEF"/>
        </svg>
        ''',
        width: size,
        height: size,
      );
}

/// النبتة التفاعلية SVG التي تتغير تدريجياً حسب عمر الطفل وتنمو مع Animation عند فتح الشاشة
class InteractiveChildPlantSvgWidget extends StatelessWidget {
  final int stageIndex; // 0..4
  final double visualScale;

  const InteractiveChildPlantSvgWidget({
    super.key,
    required this.stageIndex,
    required this.visualScale,
  });

  String _buildPlantSvgMarkup() {
    String foliage = '';
    if (stageIndex == 0) {
      foliage = '''
        <ellipse cx="100" cy="138" rx="10" ry="7" fill="#5B5FEF" stroke="#4CAF82" stroke-width="2"/>
        <path d="M100 138V110" stroke="#4CAF82" stroke-width="4" stroke-linecap="round"/>
        <path d="M100 118C86 118 76 108 76 96C88 96 100 106 100 118Z" fill="#4CAF82"/>
        <path d="M100 112C114 112 124 102 124 90C112 90 100 100 100 112Z" fill="#4CAF82"/>
      ''';
    } else if (stageIndex == 1) {
      foliage = '''
        <path d="M100 142V86" stroke="#4CAF82" stroke-width="4.5" stroke-linecap="round"/>
        <path d="M100 124C80 124 68 110 68 94C84 94 100 108 100 124Z" fill="#4CAF82"/>
        <path d="M100 116C120 116 132 102 132 86C116 86 100 100 100 116Z" fill="#4CAF82"/>
        <path d="M100 94C86 94 76 82 76 68C90 68 100 80 100 94Z" fill="#4CAF82"/>
        <circle cx="100" cy="74" r="5.5" fill="#5B5FEF"/>
      ''';
    } else if (stageIndex == 2) {
      foliage = '''
        <path d="M100 142V68" stroke="#4CAF82" stroke-width="5" stroke-linecap="round"/>
        <path d="M100 126C76 126 62 110 62 92C80 92 100 108 100 126Z" fill="#4CAF82"/>
        <path d="M100 118C124 118 138 102 138 84C120 84 100 100 100 118Z" fill="#4CAF82"/>
        <path d="M100 98C78 98 66 82 66 64C84 64 100 80 100 98Z" fill="#4CAF82"/>
        <path d="M100 90C122 90 134 74 134 56C116 56 100 72 100 90Z" fill="#4CAF82"/>
        <circle cx="100" cy="58" r="7" fill="#5B5FEF"/>
      ''';
    } else if (stageIndex == 3) {
      foliage = '''
        <path d="M100 142V52" stroke="#4CAF82" stroke-width="6" stroke-linecap="round"/>
        <path d="M100 128C72 128 56 110 56 90C76 90 100 108 100 128Z" fill="#4CAF82"/>
        <path d="M100 120C128 120 144 102 144 82C124 82 100 100 100 120Z" fill="#4CAF82"/>
        <path d="M100 96C74 96 58 78 58 58C78 58 100 76 100 96Z" fill="#4CAF82"/>
        <path d="M100 88C126 88 142 70 142 50C122 50 100 68 100 88Z" fill="#4CAF82"/>
        <circle cx="100" cy="46" r="9" fill="#E99AC7" stroke="#5B5FEF" stroke-width="2"/>
        <circle cx="100" cy="46" r="4" fill="#5B5FEF"/>
      ''';
    } else {
      foliage = '''
        <path d="M95 142L97 86H103L105 142H95Z" fill="#25263A"/>
        <circle cx="100" cy="64" r="34" fill="#4CAF82"/>
        <circle cx="76" cy="78" r="24" fill="#4CAF82"/>
        <circle cx="124" cy="78" r="24" fill="#4CAF82"/>
        <circle cx="88" cy="54" r="4.5" fill="#5B5FEF"/>
        <circle cx="114" cy="58" r="4.5" fill="#5B5FEF"/>
        <circle cx="70" cy="76" r="4" fill="#E99AC7"/>
        <circle cx="128" cy="74" r="4" fill="#E99AC7"/>
      ''';
    }

    return '''
      <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="100" cy="105" r="80" fill="#EEEEFF" fill-opacity="0.45"/>
        <path d="M66 150H134L126 182C125 185 122 187 119 187H81C78 187 75 185 74 182L66 150Z" fill="#E99AC7" stroke="#5B5FEF" stroke-width="2"/>
        <rect x="60" y="142" width="80" height="10" rx="5" fill="#FFFFFF" stroke="#5B5FEF" stroke-width="2"/>
        $foliage
      </svg>
    ''';
  }

  @override
  Widget build(BuildContext context) {
    final clampedScale = visualScale.clamp(0.80, 1.40);
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.72, end: clampedScale),
      duration: const Duration(milliseconds: 650),
      curve: Curves.easeOutBack,
      builder: (context, scale, child) => Transform.scale(
        scale: scale,
        child: child,
      ),
      child: SvgPicture.string(
        _buildPlantSvgMarkup(),
        width: 185,
        height: 185,
      ),
    );
  }
}
