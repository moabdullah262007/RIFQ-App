import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../settings/notification_settings_page.dart';
import 'pregnancy_db.dart';
import 'pregnancy_medical_data.dart';
import 'pregnancy_svg_widgets.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// قسم الحمل المتكامل «رحلتك» داخل «رِفْق للمرأة» (Flutter - Android/iOS)
/// - يعمل Offline 100% بقاعدة بيانات SQLite حقيقية (9 جداول)
/// - إشعارات محلية حقيقية 100% (تعمل بعد إغلاق التطبيق وبعد إعادة التشغيل)
/// - محتوى طبي وشرعي موثّق بالكامل مع تنبيه "استشيري الطبيب" في كل شاشة طبية
/// - بدون أي بيانات وهمية أو شارات أو إيموجي كأيقونات رئيسية
/// ══════════════════════════════════════════════════════════════════════════

class PregnancyJourneyScreen extends StatefulWidget {
  const PregnancyJourneyScreen({super.key});

  @override
  State<PregnancyJourneyScreen> createState() => _PregnancyJourneyScreenState();
}

class _PregnancyJourneyScreenState extends State<PregnancyJourneyScreen> {
  // الهوية اللونية الرسمية لقسم رِفْق للمرأة
  static const Color kGold = Color(0xFF5B5FEF);
  static const Color kBeige = Color(0xFFF7F7FC);
  static const Color kSoftPink = Color(0xFFE99AC7);
  static const Color kLightPink = Color(0xFFEEEEFF);
  static const Color kWhite = Color(0xFFFFFFFF);
  static const Color kBrown = Color(0xFF25263A);
  static const Color kGrey = Color(0xFF77798C);
  static const Color kGreen = Color(0xFF4CAF82);
  static const Color kBlue = Color(0xFF72B7E8);

  final PregnancySqliteService _db = PregnancySqliteService.instance;

  bool _isLoading = true;
  String _activeView =
      'main'; // main, setup, weeks, health, kicks, contractions, appointments, nutrition, duas_fiqh, bag, journal, settings

  PregnancyProfileModel? _profile;
  PregnancyCalculationResult? _calc;
  int _previewWeek = 1;

  List<PregnancyWeightRecord> _weights = [];
  List<PregnancySymptomRecord> _symptoms = [];
  List<FetalKickSessionRecord> _kickSessions = [];
  List<ContractionRecord> _contractions = [];
  List<PregnancyAppointmentRecord> _appointments = [];
  List<HospitalBagItemRecord> _bagItems = [];
  List<PregnancyNoteRecord> _notes = [];
  List<PregnancyReminderSetting> _reminders = [];

  // قفل الخصوصية (PIN)
  bool _pinEnabled = false;
  String? _savedPin;
  bool _isUnlocked = true;
  final TextEditingController _pinVerifyCtrl = TextEditingController();

  // حقول شاشة إعداد الحمل
  String _calcMethod = 'lmp'; // 'lmp' | 'due_date'
  DateTime? _selectedSetupDate;
  final TextEditingController _preWeightCtrl = TextEditingController();
  final TextEditingController _heightCtrl = TextEditingController();
  String _selectedBloodType = '';
  final TextEditingController _doctorNameCtrl = TextEditingController();
  final TextEditingController _hospitalNameCtrl = TextEditingController();

  // حقول شاشة الصحة والوزن والأعراض
  final TextEditingController _weightInputCtrl = TextEditingController();
  final TextEditingController _bpInputCtrl = TextEditingController();
  final TextEditingController _weightNotesCtrl = TextEditingController();
  final Set<String> _selectedSymptoms = {};
  String _symptomSeverity = 'mild';
  int _waterCupsToday = 0;
  bool _folicToday = false;
  bool _ironToday = false;
  bool _calciumToday = false;
  final TextEditingController _symptomNotesCtrl = TextEditingController();

  // عداد حركات الجنين (Kick Counter)
  bool _kickSessionActive = false;
  DateTime? _kickStartTime;
  int _currentKicksCount = 0;
  int _kickElapsedSeconds = 0;
  Timer? _kickTimer;
  final TextEditingController _kickNotesCtrl = TextEditingController();

  // مؤقت الانقباضات (Contraction Timer)
  bool _contractionActive = false;
  DateTime? _contractionStartTime;
  DateTime? _lastContractionStartTime;
  int _contractionElapsedSeconds = 0;
  String _contractionIntensity = 'moderate';
  Timer? _contractionTimer;

  // حقول مواعيد الطبيبة
  final TextEditingController _apptTitleCtrl = TextEditingController();
  final TextEditingController _apptDoctorCtrl = TextEditingController();
  String _apptType = 'checkup';
  DateTime? _apptDate;
  TimeOfDay _apptTime = const TimeOfDay(hour: 10, minute: 0);
  bool _apptReminder = true;
  final TextEditingController _apptNotesCtrl = TextEditingController();

  // حقول حقيبة الولادة
  String _bagTab = 'mother';
  final TextEditingController _customBagItemCtrl = TextEditingController();

  // حقول مذكرات رحلتي
  final TextEditingController _noteTitleCtrl = TextEditingController();
  final TextEditingController _noteContentCtrl = TextEditingController();

  // فلتر شاشة الأسابيع وشاشة الأدعية والفقه
  int _weeksFilterTrimester = 0; // 0 = الكل, 1, 2, 3
  String _duasFiqhFilter = 'all'; // 'all', 'dua', 'fiqh'

  static const List<String> _availableSymptoms = [
    'غثيان صباحي',
    'إرهاق ورغبة في النوم',
    'حرقة المعدة',
    'ألم أسفل الظهر',
    'تقلصات خفيفة',
    'تورم خفيف في القدمين',
    'تقلب المزاج',
    'صداع خفيف',
    'ضيق تنفس خفيف عند المجهود',
    'كثرة التبول',
  ];

  static const List<String> _bloodTypes = [
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
  ];

  @override
  void initState() {
    super.initState();
    _initScreen();
  }

  @override
  void dispose() {
    _kickTimer?.cancel();
    _contractionTimer?.cancel();
    _pinVerifyCtrl.dispose();
    _preWeightCtrl.dispose();
    _heightCtrl.dispose();
    _doctorNameCtrl.dispose();
    _hospitalNameCtrl.dispose();
    _weightInputCtrl.dispose();
    _bpInputCtrl.dispose();
    _weightNotesCtrl.dispose();
    _symptomNotesCtrl.dispose();
    _kickNotesCtrl.dispose();
    _apptTitleCtrl.dispose();
    _apptDoctorCtrl.dispose();
    _apptNotesCtrl.dispose();
    _customBagItemCtrl.dispose();
    _noteTitleCtrl.dispose();
    _noteContentCtrl.dispose();
    super.dispose();
  }

  Future<void> _initScreen() async {
    await _db.initRealNotifications();
    final prefs = await SharedPreferences.getInstance();
    _pinEnabled = prefs.getBool('pregnancy_pin_enabled') ?? false;
    _savedPin = prefs.getString('pregnancy_pin_code');
    _isUnlocked = !_pinEnabled;
    await _reloadData(resetPreviewWeek: true);
  }

  Future<void> _reloadData({bool resetPreviewWeek = false}) async {
    final profile = await _db.getActiveProfile();
    final reminders = await _db.getReminders();

    if (profile == null) {
      if (mounted) {
        setState(() {
          _profile = null;
          _calc = null;
          _reminders = reminders;
          _activeView = 'setup';
          _isLoading = false;
        });
      }
      return;
    }

    final calc = PregnancySqliteService.calculatePregnancy(profile);
    final pid = profile.id!;
    final weights = await _db.getWeights(pid);
    final symptoms = await _db.getSymptomRecords(pid);
    final kicks = await _db.getKickSessions(pid);
    final contractions = await _db.getContractions(pid);
    final appointments = await _db.getAppointments(pid);
    final bagItems = await _db.getHospitalBagItems(pid);
    final notes = await _db.getNotes(pid);

    if (mounted) {
      setState(() {
        _profile = profile;
        _calc = calc;
        if (resetPreviewWeek) {
          _previewWeek = calc.currentWeek;
        }
        _weights = weights;
        _symptoms = symptoms;
        _kickSessions = kicks;
        _contractions = contractions;
        _appointments = appointments;
        _bagItems = bagItems;
        _notes = notes;
        _reminders = reminders;
        if (_activeView == 'setup') {
          _activeView = 'main';
        }
        _isLoading = false;
      });
    }
  }

  String _todayIso() {
    final now = DateTime.now();
    return '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  }

  String _formatArabicDate(DateTime d) {
    const months = [
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر',
    ];
    return '${d.day} ${months[d.month - 1]} ${d.year}';
  }

  String _formatIsoToArabic(String iso) {
    try {
      return _formatArabicDate(DateTime.parse(iso));
    } catch (_) {
      return iso;
    }
  }

  String _formatDurationMmSs(int totalSeconds) {
    final m = (totalSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (totalSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _showMessage(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: isError ? Colors.red.shade700 : kGreen,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  /// شريط التنبيه الطبي الإلزامي في كل شاشة طبية
  Widget _buildMedicalDisclaimerBanner() {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFEEEEFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBlue.withOpacity(0.35)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PregnancySvgIcons.doctorConsult(size: 22),
          const SizedBox(width: 10),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'استشيري الطبيب المختص دائماً',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 12.5,
                    color: kBlue,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  PregnancyMedicalData.mandatoryMedicalDisclaimer,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 11.5,
                    color: kBrown,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: kBeige,
          body: Center(
            child: CircularProgressIndicator(color: kGold),
          ),
        ),
      );
    }

    if (!_isUnlocked) {
      return _buildPinLockScreen();
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: kBeige,
        appBar: AppBar(
          backgroundColor: kWhite,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: kBrown),
            onPressed: () {
              if (_activeView != 'main' && _profile != null) {
                setState(() => _activeView = 'main');
              } else {
                Navigator.pop(context);
              }
            },
          ),
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              PregnancySvgIcons.journeyHeader(size: 26),
              const SizedBox(width: 8),
              Text(
                _getAppBarTitle(),
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 19,
                  color: kBrown,
                ),
              ),
            ],
          ),
          centerTitle: true,
          actions: [
            if (_profile != null)
              IconButton(
                tooltip: 'إعدادات رحلتكِ والتذكيرات',
                icon: const Icon(Icons.settings_outlined, color: kGold),
                onPressed: () => setState(() => _activeView = 'settings'),
              ),
          ],
        ),
        body: _buildActiveBody(),
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_activeView) {
      case 'setup':
        return 'بدء رحلتكِ';
      case 'weeks':
        return 'تطور الجنين (40 أسبوعاً)';
      case 'health':
        return 'صحتكِ والوزن والأعراض';
      case 'kicks':
        return 'عدّاد حركات الجنين';
      case 'contractions':
        return 'مؤقّت الانقباضات';
      case 'appointments':
        return 'مواعيد الطبيبة والفحوصات';
      case 'nutrition':
        return 'التغذية والفيتامينات';
      case 'duas_fiqh':
        return 'أدعية وفقه الحامل';
      case 'bag':
        return 'حقيبة الولادة';
      case 'journal':
        return 'مذكرات رحلتي';
      case 'settings':
        return 'إعدادات رحلتكِ';
      default:
        return 'رحلتك';
    }
  }

  Widget _buildActiveBody() {
    if (_profile == null || _activeView == 'setup') {
      return _buildSetupScreen();
    }
    switch (_activeView) {
      case 'weeks':
        return _buildWeeksExplorerScreen();
      case 'health':
        return _buildHealthAndWeightScreen();
      case 'kicks':
        return _buildKickCounterScreen();
      case 'contractions':
        return _buildContractionTimerScreen();
      case 'appointments':
        return _buildAppointmentsScreen();
      case 'nutrition':
        return _buildNutritionScreen();
      case 'duas_fiqh':
        return _buildDuasAndFiqhScreen();
      case 'bag':
        return _buildHospitalBagScreen();
      case 'journal':
        return _buildJournalScreen();
      case 'settings':
        return _buildSettingsScreen();
      default:
        return _buildMainJourneyScreen();
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // شاشة القفل برمز PIN (الخصوصية الكاملة)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildPinLockScreen() {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: kBeige,
        appBar: AppBar(
          backgroundColor: kWhite,
          elevation: 0.5,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: kBrown),
            onPressed: () => Navigator.pop(context),
          ),
          title: const Text(
            'رحلتك — حماية الخصوصية',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: kBrown,
            ),
          ),
          centerTitle: true,
        ),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: kWhite,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: kGold.withOpacity(0.45)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  PregnancySvgIcons.journeyHeader(size: 54),
                  const SizedBox(height: 12),
                  const Text(
                    'أدخلي رمز الحماية الخاص برحلتكِ',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: kBrown,
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _pinVerifyCtrl,
                    obscureText: true,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    textAlign: TextAlign.center,
                    decoration: InputDecoration(
                      hintText: '••••',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kGold,
                        foregroundColor: kWhite,
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: () {
                        if (_pinVerifyCtrl.text.trim() == _savedPin) {
                          setState(() {
                            _isUnlocked = true;
                            _pinVerifyCtrl.clear();
                          });
                        } else {
                          _showMessage('رمز الحماية غير صحيح', isError: true);
                        }
                      },
                      child: const Text(
                        'فتح رحلتكِ',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // شاشة البداية (Empty State) — إعداد حساب الحمل الفعلي
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildSetupScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: kGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Column(
                  children: [
                    PregnancySvgIcons.fetusGrowth(size: 64),
                    const SizedBox(height: 10),
                    const Text(
                      'ابدئي متابعة رحلة حملكِ المباركة',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 17,
                        color: kBrown,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'لا توجد أي بيانات مسجلة حالياً. أدخلي تاريخ آخر دورة أو موعد الولادة المتوقع ليحسب التطبيق أسبوعكِ الحالي تلقائياً وبخصوصية تامة على جهازكِ.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: kGrey,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'طريقة حساب عمر الحمل:',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 13.5,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _buildChoiceButton(
                      selected: _calcMethod == 'lmp',
                      label: 'أول يوم لآخر دورة (LMP)',
                      onTap: () => setState(() {
                        _calcMethod = 'lmp';
                        _selectedSetupDate = null;
                      }),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _buildChoiceButton(
                      selected: _calcMethod == 'due_date',
                      label: 'تاريخ الولادة المتوقع',
                      onTap: () => setState(() {
                        _calcMethod = 'due_date';
                        _selectedSetupDate = null;
                      }),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                _calcMethod == 'lmp'
                    ? 'تاريخ أول يوم من آخر دورة شهرية (إلزامي):'
                    : 'تاريخ الولادة المتوقع الذي حددته الطبيبة (إلزامي):',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 8),
              InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () async {
                  final now = DateTime.now();
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _selectedSetupDate ??
                        (_calcMethod == 'lmp'
                            ? now.subtract(const Duration(days: 70))
                            : now.add(const Duration(days: 180))),
                    firstDate: _calcMethod == 'lmp'
                        ? now.subtract(const Duration(days: 290))
                        : now,
                    lastDate: _calcMethod == 'lmp'
                        ? now
                        : now.add(const Duration(days: 285)),
                  );
                  if (picked != null) {
                    setState(() => _selectedSetupDate = picked);
                  }
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  decoration: BoxDecoration(
                    color: kBeige.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: kGold.withOpacity(0.5)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _selectedSetupDate == null
                            ? 'اضغطي لاختيار التاريخ'
                            : _formatArabicDate(_selectedSetupDate!),
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: _selectedSetupDate == null ? kGrey : kBrown,
                        ),
                      ),
                      const Icon(Icons.calendar_month, color: kGold),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _preWeightCtrl,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: 'الوزن قبل الحمل (كجم - اختياري)',
                        labelStyle:
                            const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _heightCtrl,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: 'الطول (سم - اختياري)',
                        labelStyle:
                            const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _selectedBloodType.isEmpty ? null : _selectedBloodType,
                decoration: InputDecoration(
                  labelText: 'فصيلة الدم وعامل Rh (اختياري)',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                items: _bloodTypes
                    .map((b) => DropdownMenuItem(value: b, child: Text(b)))
                    .toList(),
                onChanged: (val) =>
                    setState(() => _selectedBloodType = val ?? ''),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _doctorNameCtrl,
                decoration: InputDecoration(
                  labelText: 'اسم الطبيبة المتابعة (اختياري)',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _hospitalNameCtrl,
                decoration: InputDecoration(
                  labelText: 'اسم المستشفى أو العيادة (اختياري)',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kGold,
                    foregroundColor: kWhite,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: _savePregnancySetup,
                  child: const Text(
                    'حساب الحمل وبدء رحلتكِ',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _savePregnancySetup() async {
    if (_selectedSetupDate == null) {
      _showMessage('يرجى اختيار التاريخ أولاً لحساب الحمل بدقة', isError: true);
      return;
    }

    final preW = _preWeightCtrl.text.trim().isNotEmpty
        ? double.tryParse(_preWeightCtrl.text.trim())
        : null;
    final hCm = _heightCtrl.text.trim().isNotEmpty
        ? double.tryParse(_heightCtrl.text.trim())
        : null;

    if ((preW != null && (preW <= 25 || preW > 250)) ||
        (hCm != null && (hCm <= 100 || hCm > 220))) {
      _showMessage('يرجى إدخال قيم صحيحة للوزن والطول', isError: true);
      return;
    }

    late DateTime lmp;
    late DateTime due;
    if (_calcMethod == 'lmp') {
      lmp = _selectedSetupDate!;
      due = lmp.add(const Duration(days: 280));
    } else {
      due = _selectedSetupDate!;
      lmp = due.subtract(const Duration(days: 280));
    }

    String fmt(DateTime d) =>
        '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

    final profile = PregnancyProfileModel(
      calculationMethod: _calcMethod,
      lmpDate: fmt(lmp),
      dueDate: fmt(due),
      prePregnancyWeight: preW,
      heightCm: hCm,
      bloodType: _selectedBloodType,
      doctorName: _doctorNameCtrl.text.trim(),
      hospitalName: _hospitalNameCtrl.text.trim(),
      createdAt: DateTime.now().toIso8601String(),
    );

    final pid = await _db.saveOrReplaceProfile(profile);
    if (preW != null) {
      await _db.insertWeight(
        PregnancyWeightRecord(
          pregnancyId: pid,
          date: fmt(lmp),
          week: 1,
          weightKg: preW,
          bloodPressure: '',
          notes: 'الوزن الابتدائي قبل الحمل',
          createdAt: DateTime.now().toIso8601String(),
        ),
      );
    }

    await _reloadData(resetPreviewWeek: true);
    _showMessage('تم حفظ بيانات حملكِ وحساب أسبوعكِ الحالي بنجاح');
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة الرئيسية — «رحلتك» (بطاقة الأسبوع + بطاقة الجنين + أدوات المتابعة)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildMainJourneyScreen() {
    final calc = _calc!;
    final weekInfo = PregnancyMedicalData.getWeekInfo(_previewWeek);
    final packedCount = _bagItems.where((i) => i.isPacked).length;
    final upcomingAppts =
        _appointments.where((a) => !a.isCompleted).toList().length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),

        // 【بطاقة الأسبوع】
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [kWhite, kLightPink],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: kGold, width: 1.4),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'الأسبوع ${calc.currentWeek}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          fontSize: 24,
                          color: kBrown,
                        ),
                      ),
                      Text(
                        '${calc.trimesterTitle} • ${calc.extraDays > 0 ? "و ${calc.extraDays} أيام" : "بداية الأسبوع"}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.w600,
                          fontSize: 13.5,
                          color: kGold,
                        ),
                      ),
                    ],
                  ),
                  PregnancySvgIcons.fetusGrowth(
                    size: 56,
                    trimester: calc.trimester,
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // شريط التقدم المئوي
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'نسبة إتمام رحلة الحمل',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: kBrown,
                    ),
                  ),
                  Text(
                    '${calc.progressPercent.round()}%',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: kGold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: (calc.progressPercent / 100.0).clamp(0.02, 1.0),
                  minHeight: 11,
                  backgroundColor: kBeige,
                  valueColor: const AlwaysStoppedAnimation<Color>(kGold),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'باقي ${calc.remainingDays} يوم',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      color: kGreen,
                    ),
                  ),
                  Text(
                    'تاريخ الولادة المتوقع: ${_formatArabicDate(calc.dueDate)}',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 12.5,
                      color: kBrown,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // 【بطاقة الجنين — مع إمكانية استعراض الأسابيع】
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: kSoftPink, width: 1.3),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      PregnancySvgIcons.fetusGrowth(
                        size: 38,
                        trimester: weekInfo.trimester,
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'حجم الجنين — الأسبوع ${weekInfo.week}',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.bold,
                              fontSize: 15.5,
                              color: kBrown,
                            ),
                          ),
                          Text(
                            'يقارب حجم: ${weekInfo.sizeComparison}',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                              color: kGold,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      IconButton(
                        tooltip: 'الأسبوع السابق',
                        onPressed: _previewWeek > 1
                            ? () => setState(() => _previewWeek--)
                            : null,
                        icon: const Icon(Icons.chevron_right, color: kBrown),
                      ),
                      IconButton(
                        tooltip: 'الأسبوع التالي',
                        onPressed: _previewWeek < 40
                            ? () => setState(() => _previewWeek++)
                            : null,
                        icon: const Icon(Icons.chevron_left, color: kBrown),
                      ),
                    ],
                  ),
                ],
              ),
              if (_previewWeek != calc.currentWeek)
                Padding(
                  padding: const EdgeInsets.only(top: 4, bottom: 6),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: TextButton.icon(
                      onPressed: () =>
                          setState(() => _previewWeek = calc.currentWeek),
                      icon: const Icon(Icons.restore, size: 16, color: kGold),
                      label: Text(
                        'العودة لأسبوعي الفعلي (الأسبوع ${calc.currentWeek})',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: kGold,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: kBeige.withOpacity(0.65),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          const Text(
                            'الطول التقريبي',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 11.5,
                              color: kGrey,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            weekInfo.lengthEstimate,
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                              color: kBrown,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: kBeige.withOpacity(0.65),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          const Text(
                            'الوزن التقريبي',
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 11.5,
                              color: kGrey,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            weekInfo.weightEstimate,
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                              color: kBrown,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _buildInfoSectionRow(
                title: 'تطور الجنين هذا الأسبوع:',
                body: weekInfo.fetalDevelopment,
              ),
              const SizedBox(height: 8),
              _buildInfoSectionRow(
                title: 'تغيرات جسم الأم:',
                body: weekInfo.motherChanges,
              ),
              const SizedBox(height: 8),
              _buildInfoSectionRow(
                title: 'إرشاد الأسبوع الطبي:',
                body: weekInfo.medicalTip,
              ),
              const Divider(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      'المصدر: ${weekInfo.medicalSource}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 11,
                        color: kGrey,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () => setState(() => _activeView = 'weeks'),
                    child: const Text(
                      'عرض كل الـ 40 أسبوعاً',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: kGold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),

        const Text(
          'أقسام وأدوات رحلتكِ',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: kBrown,
          ),
        ),
        const SizedBox(height: 10),

        // شبكة الأدوات الكاملة (أزرار حقيقية بأيقونات SVG وبدون شارات)
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.25,
          children: [
            _buildNavCard(
              icon: PregnancySvgIcons.fetusGrowth(size: 28),
              title: 'مراحل الـ 40 أسبوعاً',
              subtitle: 'تطور الجنين والأم أسبوعاً بأسبوع',
              onTap: () => setState(() => _activeView = 'weeks'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.weightHealth(size: 28),
              title: 'صحتكِ والوزن والأعراض',
              subtitle: _weights.isEmpty
                  ? 'سجلي وزنكِ وأعراضكِ اليومية'
                  : 'آخر وزن: ${_weights.last.weightKg} كجم',
              onTap: () => setState(() => _activeView = 'health'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.kicksCounter(size: 28),
              title: 'عدّاد حركات الجنين',
              subtitle: _kickSessions.isEmpty
                  ? 'حساب وقت 10 حركات للجنين'
                  : 'تم تسجيل ${_kickSessions.length} جلسات',
              onTap: () => setState(() => _activeView = 'kicks'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.contractionTimer(size: 28),
              title: 'مؤقّت الانقباضات',
              subtitle: _contractions.isEmpty
                  ? 'حساب مدة وتكرار الطلق'
                  : 'تم تسجيل ${_contractions.length} انقباضات',
              onTap: () => setState(() => _activeView = 'contractions'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.appointments(size: 28),
              title: 'مواعيد الطبيبة والفحوصات',
              subtitle: upcomingAppts == 0
                  ? 'جدولة المواعيد بتذكير حقيقي'
                  : 'لديكِ $upcomingAppts مواعيد قادمة',
              onTap: () => setState(() => _activeView = 'appointments'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.nutrition(size: 28),
              title: 'التغذية والفيتامينات',
              subtitle: 'العناصر الأساسية والأطعمة الممنوعة',
              onTap: () => setState(() => _activeView = 'nutrition'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.duasAndFiqh(size: 28),
              title: 'أدعية وفقه الحامل',
              subtitle: 'أدعية مأثورة وأحكام الحمل والولادة',
              onTap: () => setState(() => _activeView = 'duas_fiqh'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.hospitalBag(size: 28),
              title: 'حقيبة الولادة',
              subtitle: _bagItems.isEmpty
                  ? 'قائمة تجهيزات الأم والمولود'
                  : 'تم تجهيز $packedCount من ${_bagItems.length}',
              onTap: () => setState(() => _activeView = 'bag'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.journal(size: 28),
              title: 'مذكرات رحلتي',
              subtitle: _notes.isEmpty
                  ? 'دوني مشاعركِ ورسائلكِ لجنينكِ'
                  : '${_notes.length} مذكرات محفوظة',
              onTap: () => setState(() => _activeView = 'journal'),
            ),
            _buildNavCard(
              icon: PregnancySvgIcons.doctorConsult(size: 28),
              title: 'التذكيرات والإعدادات',
              subtitle: 'إشعارات الفيتامينات والماء والخصوصية',
              onTap: () => setState(() => _activeView = 'settings'),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoSectionRow({required String title, required String body}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 12.5,
            color: kBrown,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          body,
          style: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 12,
            color: kBrown,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildNavCard({
    required Widget icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: kWhite,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: kGold.withOpacity(0.35)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            icon,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5,
                    color: kBrown,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 11,
                    color: kGrey,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 2: تطور الجنين أسبوعاً بأسبوع (40 أسبوعاً كاملة بمصادر موثقة)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildWeeksExplorerScreen() {
    final filtered = _weeksFilterTrimester == 0
        ? PregnancyMedicalData.weeks
        : PregnancyMedicalData.weeks
            .where((w) => w.trimester == _weeksFilterTrimester)
            .toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _buildFilterTabButton(0, 'الكل (40 أسبوعاً)'),
              const SizedBox(width: 8),
              _buildFilterTabButton(1, 'الثلث الأول (1-13)'),
              const SizedBox(width: 8),
              _buildFilterTabButton(2, 'الثلث الثاني (14-27)'),
              const SizedBox(width: 8),
              _buildFilterTabButton(3, 'الثلث الثالث (28-40)'),
            ],
          ),
        ),
        const SizedBox(height: 14),
        ...filtered.map((w) {
          final isCurrent = _calc?.currentWeek == w.week;
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: kWhite,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: isCurrent ? kGold : kSoftPink.withOpacity(0.6),
                width: isCurrent ? 2 : 1,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'الأسبوع ${w.week} — ${w.sizeComparison}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: kBrown,
                      ),
                    ),
                    if (isCurrent)
                      const Text(
                        'أسبوعكِ الحالي',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          color: kGreen,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'الطول التقريبي: ${w.lengthEstimate} • الوزن التقريبي: ${w.weightEstimate}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12,
                    color: kGold,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                _buildInfoSectionRow(
                  title: 'الجنين:',
                  body: w.fetalDevelopment,
                ),
                const SizedBox(height: 6),
                _buildInfoSectionRow(
                  title: 'الأم:',
                  body: w.motherChanges,
                ),
                const SizedBox(height: 6),
                _buildInfoSectionRow(
                  title: 'نصيحة طبية:',
                  body: w.medicalTip,
                ),
                const SizedBox(height: 6),
                Text(
                  'المصدر: ${w.medicalSource}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 11,
                    color: kGrey,
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildFilterTabButton(int value, String label) {
    final selected = _weeksFilterTrimester == value;
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: selected ? kGold : kWhite,
        foregroundColor: selected ? kWhite : kBrown,
        elevation: 0,
        side: BorderSide(color: kGold.withOpacity(0.5)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      onPressed: () => setState(() => _weeksFilterTrimester = value),
      child: Text(
        label,
        style: const TextStyle(
          fontFamily: 'Cairo',
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 3: صحتكِ، منحنى الوزن (fl_chart)، والأعراض اليومية + علامات التحذير
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildHealthAndWeightScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),

        // بطاقة تسجيل وزن جديد
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kGold.withOpacity(0.4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  PregnancySvgIcons.weightHealth(size: 24),
                  const SizedBox(width: 8),
                  const Text(
                    'تسجيل الوزن وضغط الدم',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: kBrown,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _weightInputCtrl,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: 'الوزن الحالي (كجم)*',
                        labelStyle:
                            const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: _bpInputCtrl,
                      decoration: InputDecoration(
                        labelText: 'ضغط الدم (مثال 120/80)',
                        labelStyle:
                            const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _weightNotesCtrl,
                decoration: InputDecoration(
                  labelText: 'ملاحظات (اختياري)',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kGold,
                    foregroundColor: kWhite,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _saveWeightEntry,
                  child: const Text(
                    'حفظ القياس في السجل',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // منحنى الوزن الحقيقي بـ fl_chart
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'منحنى تغير الوزن خلال الحمل',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14.5,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 12),
              if (_weights.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Center(
                    child: Text(
                      'لا توجد قراءات وزن مسجلة بعد. أضيفي وزنكِ أعلاه ليظهر المنحنى البياني.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: kGrey,
                      ),
                    ),
                  ),
                )
              else ...[
                SizedBox(
                  height: 180,
                  child: LineChart(
                    LineChartData(
                      gridData: const FlGridData(show: true),
                      borderData: FlBorderData(show: true),
                      titlesData: const FlTitlesData(
                        rightTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                        topTitles: AxisTitles(
                          sideTitles: SideTitles(showTitles: false),
                        ),
                      ),
                      lineBarsData: [
                        LineChartBarData(
                          spots: _weights
                              .asMap()
                              .entries
                              .map((e) => FlSpot(
                                    e.value.week.toDouble(),
                                    e.value.weightKg,
                                  ))
                              .toList(),
                          isCurved: true,
                          color: kGold,
                          barWidth: 3,
                          dotData: const FlDotData(show: true),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                ..._weights.reversed.map(
                  (w) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text(
                      '${w.weightKg} كجم — الأسبوع ${w.week}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        color: kBrown,
                      ),
                    ),
                    subtitle: Text(
                      '${_formatIsoToArabic(w.date)}${w.bloodPressure.isNotEmpty ? " • الضغط: ${w.bloodPressure}" : ""}${w.notes.isNotEmpty ? " • ${w.notes}" : ""}',
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 11),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.redAccent, size: 20),
                      onPressed: () async {
                        if (w.id != null) {
                          await _db.deleteWeight(w.id!);
                          await _reloadData();
                        }
                      },
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),

        // بطاقة تسجيل الأعراض اليومية والماء والفيتامينات
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kGold.withOpacity(0.4)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'تسجيل الأعراض اليومية والفيتامينات والماء',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _availableSymptoms.map((sym) {
                  final sel = _selectedSymptoms.contains(sym);
                  return FilterChip(
                    selected: sel,
                    selectedColor: kLightPink,
                    checkmarkColor: kBrown,
                    label: Text(
                      sym,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 11.5,
                        color: kBrown,
                      ),
                    ),
                    onSelected: (v) {
                      setState(() {
                        if (v) {
                          _selectedSymptoms.add(sym);
                        } else {
                          _selectedSymptoms.remove(sym);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text(
                    'شدة الأعراض:',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 12.5,
                    ),
                  ),
                  const SizedBox(width: 10),
                  _buildSeverityButton('mild', 'خفيفة'),
                  const SizedBox(width: 6),
                  _buildSeverityButton('moderate', 'متوسطة'),
                  const SizedBox(width: 6),
                  _buildSeverityButton('severe', 'شديدة'),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      PregnancySvgIcons.waterDrop(size: 20),
                      const SizedBox(width: 6),
                      Text(
                        'أكواب الماء اليوم: $_waterCupsToday كوب',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      IconButton(
                        onPressed: _waterCupsToday > 0
                            ? () => setState(() => _waterCupsToday--)
                            : null,
                        icon: const Icon(Icons.remove_circle_outline,
                            color: kBrown),
                      ),
                      IconButton(
                        onPressed: () => setState(() => _waterCupsToday++),
                        icon:
                            const Icon(Icons.add_circle_outline, color: kBlue),
                      ),
                    ],
                  ),
                ],
              ),
              CheckboxListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                value: _folicToday,
                activeColor: kGreen,
                title: const Text(
                  'تناولتُ حمض الفوليك اليوم',
                  style: TextStyle(fontFamily: 'Cairo', fontSize: 12.5),
                ),
                onChanged: (v) => setState(() => _folicToday = v ?? false),
              ),
              CheckboxListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                value: _ironToday,
                activeColor: kGreen,
                title: const Text(
                  'تناولتُ مكمل الحديد اليوم',
                  style: TextStyle(fontFamily: 'Cairo', fontSize: 12.5),
                ),
                onChanged: (v) => setState(() => _ironToday = v ?? false),
              ),
              CheckboxListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                value: _calciumToday,
                activeColor: kGreen,
                title: const Text(
                  'تناولتُ الكالسيوم وفيتامين (د) اليوم',
                  style: TextStyle(fontFamily: 'Cairo', fontSize: 12.5),
                ),
                onChanged: (v) => setState(() => _calciumToday = v ?? false),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kGold,
                    foregroundColor: kWhite,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _saveDailySymptoms,
                  child: const Text(
                    'حفظ سجل اليوم الصحي',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              if (_symptoms.isNotEmpty) ...[
                const Divider(height: 24),
                const Text(
                  'سجل الأيام السابقة:',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                ..._symptoms.map(
                  (s) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text(
                      '${_formatIsoToArabic(s.date)} (الأسبوع ${s.week})',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 12.5,
                      ),
                    ),
                    subtitle: Text(
                      'الأعراض: ${s.symptoms.isEmpty ? "لا توجد" : s.symptoms.join("، ")} • الماء: ${s.waterCups} أكواب',
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 11),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.redAccent, size: 18),
                      onPressed: () async {
                        if (s.id != null) {
                          await _db.deleteSymptomRecord(s.id!);
                          await _reloadData();
                        }
                      },
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),

        // علامات التحذير الطبية الطارئة (WHO / ACOG)
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFFFEBEE),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.red.shade300),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'علامات تحذيرية تستدعي مراجعة الطبيب فوراً (WHO / ACOG)',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: Colors.red.shade900,
                ),
              ),
              const SizedBox(height: 8),
              ...PregnancyMedicalData.urgentWarningSigns.map(
                (w) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text(
                    '• ${w['sign']}: ${w['detail']}',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 12,
                      color: kBrown,
                      height: 1.4,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSeverityButton(String key, String label) {
    final selected = _symptomSeverity == key;
    return InkWell(
      onTap: () => setState(() => _symptomSeverity = key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: selected ? kGold : kBeige,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 11.5,
            fontWeight: FontWeight.bold,
            color: selected ? kWhite : kBrown,
          ),
        ),
      ),
    );
  }

  Future<void> _saveWeightEntry() async {
    final w = double.tryParse(_weightInputCtrl.text.trim());
    if (w == null || w <= 25 || w > 250) {
      _showMessage('يرجى إدخال وزن صحيح بالكيلوجرام', isError: true);
      return;
    }
    await _db.insertWeight(
      PregnancyWeightRecord(
        pregnancyId: _profile!.id!,
        date: _todayIso(),
        week: _calc!.currentWeek,
        weightKg: w,
        bloodPressure: _bpInputCtrl.text.trim(),
        notes: _weightNotesCtrl.text.trim(),
        createdAt: DateTime.now().toIso8601String(),
      ),
    );
    _weightInputCtrl.clear();
    _bpInputCtrl.clear();
    _weightNotesCtrl.clear();
    await _reloadData();
    _showMessage('تم حفظ القياس في سجل الوزن');
  }

  Future<void> _saveDailySymptoms() async {
    await _db.insertSymptomRecord(
      PregnancySymptomRecord(
        pregnancyId: _profile!.id!,
        date: _todayIso(),
        week: _calc!.currentWeek,
        symptoms: _selectedSymptoms.toList(),
        severity: _symptomSeverity,
        waterCups: _waterCupsToday,
        folicAcidTaken: _folicToday,
        ironTaken: _ironToday,
        calciumTaken: _calciumToday,
        notes: _symptomNotesCtrl.text.trim(),
        createdAt: DateTime.now().toIso8601String(),
      ),
    );
    _selectedSymptoms.clear();
    _symptomNotesCtrl.clear();
    await _reloadData();
    _showMessage('تم حفظ سجل الأعراض والفيتامينات لليوم');
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 4: عدّاد حركات الجنين (Kick Counter — قاعدة Count to 10 من ACOG)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildKickCounterScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: kGold.withOpacity(0.45)),
          ),
          child: Column(
            children: [
              PregnancySvgIcons.kicksCounter(size: 48),
              const SizedBox(height: 10),
              const Text(
                'عدّاد حركات الجنين (Count to 10)',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'توصي الكلية الأمريكية لأطباء النساء والتوليد (ACOG) بداية من الأسبوع 28 بحساب الوقت اللازم للشعور بـ 10 حركات (ركلات أو التفافات)، وغالباً ما تكتمل خلال أقل من ساعتين في وقت نشاط الجنين.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  color: kGrey,
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                '$_currentKicksCount / 10 حركات',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 28,
                  color: kBrown,
                ),
              ),
              Text(
                'المدة المنقضية: ${_formatDurationMmSs(_kickElapsedSeconds)}',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: kGold,
                ),
              ),
              const SizedBox(height: 16),
              if (!_kickSessionActive)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kGold,
                      foregroundColor: kWhite,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    onPressed: _startKickSession,
                    child: const Text(
                      'بدء جلسة عدّ الحركات الآن',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                  ),
                )
              else
                Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kGreen,
                          foregroundColor: kWhite,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                        ),
                        onPressed: _registerKickTap,
                        child: const Text(
                          'تسجيل حركة جديدة (+1)',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: _finishAndSaveKickSession,
                            child: const Text(
                              'حفظ وإنهاء الجلسة',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontWeight: FontWeight.bold,
                                color: kBrown,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              _kickTimer?.cancel();
                              setState(() {
                                _kickSessionActive = false;
                                _currentKicksCount = 0;
                                _kickElapsedSeconds = 0;
                              });
                            },
                            child: const Text(
                              'إلغاء',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                color: Colors.redAccent,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'سجل جلسات حركات الجنين المحفوظة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14.5,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 10),
              if (_kickSessions.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Center(
                    child: Text(
                      'لم يتم تسجيل أي جلسة لحركات الجنين بعد.',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: kGrey,
                      ),
                    ),
                  ),
                )
              else
                ..._kickSessions.map(
                  (k) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      '${k.kicksCount} حركات في ${_formatDurationMmSs(k.durationSeconds)} دقيقة',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: kBrown,
                      ),
                    ),
                    subtitle: Text(
                      '${_formatIsoToArabic(k.date)} • من ${k.startTime} إلى ${k.endTime}',
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 11),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.redAccent, size: 20),
                      onPressed: () async {
                        if (k.id != null) {
                          await _db.deleteKickSession(k.id!);
                          await _reloadData();
                        }
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  void _startKickSession() {
    _kickTimer?.cancel();
    setState(() {
      _kickSessionActive = true;
      _kickStartTime = DateTime.now();
      _currentKicksCount = 1;
      _kickElapsedSeconds = 0;
    });
    _kickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _kickSessionActive) {
        setState(() => _kickElapsedSeconds++);
      }
    });
  }

  void _registerKickTap() {
    HapticFeedback.mediumImpact();
    setState(() => _currentKicksCount++);
    if (_currentKicksCount >= 10) {
      _finishAndSaveKickSession();
    }
  }

  Future<void> _finishAndSaveKickSession() async {
    _kickTimer?.cancel();
    if (_currentKicksCount == 0 || _kickStartTime == null) return;
    final now = DateTime.now();
    String fmtHm(DateTime d) =>
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

    await _db.insertKickSession(
      FetalKickSessionRecord(
        pregnancyId: _profile!.id!,
        date: _todayIso(),
        startTime: fmtHm(_kickStartTime!),
        endTime: fmtHm(now),
        durationSeconds: _kickElapsedSeconds,
        kicksCount: _currentKicksCount,
        notes: '',
        createdAt: now.toIso8601String(),
      ),
    );
    setState(() {
      _kickSessionActive = false;
      _currentKicksCount = 0;
      _kickElapsedSeconds = 0;
    });
    await _reloadData();
    _showMessage('تم حفظ جلسة عدّ حركات الجنين بنجاح');
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 5: مؤقّت الانقباضات / الطلق (Contraction Timer — قاعدة 5-1-1)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildContractionTimerScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: kGold.withOpacity(0.45)),
          ),
          child: Column(
            children: [
              PregnancySvgIcons.contractionTimer(size: 48),
              const SizedBox(height: 10),
              const Text(
                'مؤقّت الانقباضات (قاعدة 5-1-1 الطبية)',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'اضغطي عند بداية الانقباضة ثم عند انتهائها. إذا أصبحت الانقباضات تأتي كل 5 دقائق، وتستمر كل منها لمدة دقيقة كاملة (60 ثانية)، واستمر هذا النمط لمدة ساعة كاملة، توجهي إلى المستشفى فوراً (ACOG).',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  color: kGrey,
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 14),
              Text(
                '${_contractionElapsedSeconds} ثانية',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 28,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'شدة الانقباضة:',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 12.5,
                    ),
                  ),
                  const SizedBox(width: 8),
                  _buildContractionIntensityBtn('mild', 'خفيفة'),
                  const SizedBox(width: 6),
                  _buildContractionIntensityBtn('moderate', 'متوسطة'),
                  const SizedBox(width: 6),
                  _buildContractionIntensityBtn('strong', 'قوية'),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        _contractionActive ? Colors.red.shade700 : kGold,
                    foregroundColor: kWhite,
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: _toggleContractionTimer,
                  child: Text(
                    _contractionActive
                        ? 'انتهت الانقباضة — حفظ المدة'
                        : 'بدأت الانقباضة الآن',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'سجل الانقباضات المحفوظة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14.5,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 10),
              if (_contractions.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Center(
                    child: Text(
                      'لا توجد انقباضات مسجلة حالياً.',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: kGrey,
                      ),
                    ),
                  ),
                )
              else
                ..._contractions.map(
                  (c) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      'المدة: ${c.durationSeconds} ثانية • الشدة: ${c.intensity == "strong" ? "قوية" : c.intensity == "moderate" ? "متوسطة" : "خفيفة"}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: kBrown,
                      ),
                    ),
                    subtitle: Text(
                      'الوقت: ${c.startTime}${c.intervalSeconds != null ? " • الفاصل عن السابقة: ${_formatDurationMmSs(c.intervalSeconds!)} د" : ""}',
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 11),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.redAccent, size: 20),
                      onPressed: () async {
                        if (c.id != null) {
                          await _db.deleteContraction(c.id!);
                          await _reloadData();
                        }
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildContractionIntensityBtn(String key, String label) {
    final sel = _contractionIntensity == key;
    return InkWell(
      onTap: () => setState(() => _contractionIntensity = key),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: sel ? kGold : kBeige,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 11.5,
            fontWeight: FontWeight.bold,
            color: sel ? kWhite : kBrown,
          ),
        ),
      ),
    );
  }

  Future<void> _toggleContractionTimer() async {
    if (!_contractionActive) {
      _contractionTimer?.cancel();
      setState(() {
        _contractionActive = true;
        _contractionStartTime = DateTime.now();
        _contractionElapsedSeconds = 0;
      });
      _contractionTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted && _contractionActive) {
          setState(() => _contractionElapsedSeconds++);
        }
      });
    } else {
      _contractionTimer?.cancel();
      final now = DateTime.now();
      final start = _contractionStartTime ?? now;
      final intervalSec = _lastContractionStartTime != null
          ? start.difference(_lastContractionStartTime!).inSeconds
          : null;
      _lastContractionStartTime = start;

      String fmtHm(DateTime d) =>
          '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}:${d.second.toString().padLeft(2, '0')}';

      await _db.insertContraction(
        ContractionRecord(
          pregnancyId: _profile!.id!,
          date: _todayIso(),
          startTime: fmtHm(start),
          endTime: fmtHm(now),
          durationSeconds: _contractionElapsedSeconds.clamp(1, 3600),
          intervalSeconds: intervalSec,
          intensity: _contractionIntensity,
          createdAt: now.toIso8601String(),
        ),
      );
      setState(() {
        _contractionActive = false;
        _contractionElapsedSeconds = 0;
      });
      await _reloadData();
      _showMessage('تم حفظ الانقباضة والفاصل الزمني في السجل');
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 6: مواعيد الطبيبة والفحوصات (مع إشعارات حقيقية + فحوصات الأثلاث)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildAppointmentsScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  PregnancySvgIcons.appointments(size: 24),
                  const SizedBox(width: 8),
                  const Text(
                    'إضافة موعد طبي أو فحص جديد',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: kBrown,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _apptTitleCtrl,
                decoration: InputDecoration(
                  labelText: 'عنوان الموعد (مثال: متابعة الشهر الخامس / سونار)*',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _apptDoctorCtrl,
                decoration: InputDecoration(
                  labelText: 'اسم الطبيبة أو المركز الطبي (اختياري)',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final now = DateTime.now();
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: _apptDate ?? now,
                          firstDate: now,
                          lastDate: now.add(const Duration(days: 300)),
                        );
                        if (picked != null) {
                          setState(() => _apptDate = picked);
                        }
                      },
                      icon: const Icon(Icons.calendar_today,
                          size: 16, color: kGold),
                      label: Text(
                        _apptDate == null
                            ? 'تاريخ الموعد*'
                            : _formatArabicDate(_apptDate!),
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: kBrown,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: _apptTime,
                        );
                        if (picked != null) {
                          setState(() => _apptTime = picked);
                        }
                      },
                      icon:
                          const Icon(Icons.access_time, size: 16, color: kGold),
                      label: Text(
                        '${_apptTime.hour.toString().padLeft(2, '0')}:${_apptTime.minute.toString().padLeft(2, '0')}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: kBrown,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                activeColor: kGreen,
                value: _apptReminder,
                title: const Text(
                  'تفعيل إشعار تنبيه حقيقي في وقت الموعد',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12.5,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                onChanged: (v) => setState(() => _apptReminder = v),
              ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kGold,
                    foregroundColor: kWhite,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: _saveAppointment,
                  child: const Text(
                    'حفظ الموعد وجدولة الإشعار',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // قائمة المواعيد المسجلة
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'مواعيدكِ المسجلة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14.5,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 8),
              if (_appointments.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Center(
                    child: Text(
                      'لا توجد مواعيد مسجلة بعد. أضيفي موعدكِ القادم مع الطبيبة أعلاه.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: kGrey,
                      ),
                    ),
                  ),
                )
              else
                ..._appointments.map(
                  (a) => CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    activeColor: kGreen,
                    value: a.isCompleted,
                    onChanged: (v) async {
                      if (a.id != null) {
                        await _db.toggleAppointmentCompleted(a.id!, v ?? false);
                        await _reloadData();
                      }
                    },
                    title: Text(
                      a.title,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        decoration:
                            a.isCompleted ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    subtitle: Text(
                      '${_formatIsoToArabic(a.date)} • الساعة ${a.time}${a.doctorOrLab.isNotEmpty ? " • ${a.doctorOrLab}" : ""}',
                      style: const TextStyle(fontFamily: 'Cairo', fontSize: 11),
                    ),
                    secondary: IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.redAccent, size: 20),
                      onPressed: () async {
                        if (a.id != null) {
                          await _db.deleteAppointment(a.id!);
                          await _reloadData();
                        }
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // دليل الفحوصات الموصى بها في كل ثلث (WHO / ACOG)
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kGold.withOpacity(0.35)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'جدول الفحوصات الطبية الموصى بها لكل ثلث',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14.5,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 10),
              ...PregnancyMedicalData.recommendedCheckups.map(
                (c) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'الثلث ${c.trimester == 1 ? "الأول" : c.trimester == 2 ? "الثاني" : "الثالث"} (${c.timingWeeks}): ${c.title}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          color: kBrown,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        c.description,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: kBrown,
                          height: 1.4,
                        ),
                      ),
                      Text(
                        'المصدر: ${c.source}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 11,
                          color: kGrey,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _saveAppointment() async {
    final title = _apptTitleCtrl.text.trim();
    if (title.isEmpty || _apptDate == null) {
      _showMessage('يرجى إدخال عنوان الموعد وتاريخه', isError: true);
      return;
    }

    final dIso =
        '${_apptDate!.year}-${_apptDate!.month.toString().padLeft(2, '0')}-${_apptDate!.day.toString().padLeft(2, '0')}';
    final tHm =
        '${_apptTime.hour.toString().padLeft(2, '0')}:${_apptTime.minute.toString().padLeft(2, '0')}';

    await _db.insertAppointment(
      PregnancyAppointmentRecord(
        pregnancyId: _profile!.id!,
        title: title,
        doctorOrLab: _apptDoctorCtrl.text.trim(),
        appointmentType: _apptType,
        date: dIso,
        time: tHm,
        notes: _apptNotesCtrl.text.trim(),
        reminderEnabled: _apptReminder,
        isCompleted: false,
        createdAt: DateTime.now().toIso8601String(),
      ),
    );

    _apptTitleCtrl.clear();
    _apptDoctorCtrl.clear();
    _apptNotesCtrl.clear();
    _apptDate = null;
    await _reloadData();
    _showMessage('تم حفظ الموعد وجدولة الإشعار المحلي الحقيقي');
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 7: التغذية والفيتامينات والأطعمة الممنوعة (موثقة من WHO / FDA / ACOG)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildNutritionScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildMedicalDisclaimerBanner(),
        const Text(
          'العناصر الغذائية الأساسية للحامل',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 15.5,
            color: kBrown,
          ),
        ),
        const SizedBox(height: 10),
        ...PregnancyMedicalData.essentialNutrients.map(
          (n) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: kWhite,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kGold.withOpacity(0.4)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${n.name} (${n.dailyNeed})',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: kBrown,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'الأهمية الطبية: ${n.importance}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12,
                    color: kBrown,
                    height: 1.45,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'المصادر الطبيعية: ${n.naturalSources}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12,
                    color: kGreen,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'المصدر: ${n.source}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 11,
                    color: kGrey,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'أطعمة وممارسات يجب تجنبها أثناء الحمل',
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 15.5,
            color: kBrown,
          ),
        ),
        const SizedBox(height: 10),
        ...PregnancyMedicalData.foodsToAvoid.map(
          (f) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: kWhite,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.red.shade200),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  f['title']!,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5,
                    color: Colors.red.shade800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  f['reason']!,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12,
                    color: kBrown,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'المصدر: ${f['source']}',
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 11,
                    color: kGrey,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 8: أدعية الحامل وفقه الحمل والولادة (خط Amiri ومصادر شرعية موثقة)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildDuasAndFiqhScreen() {
    final items = _duasFiqhFilter == 'all'
        ? PregnancyMedicalData.duasAndFiqhList
        : PregnancyMedicalData.duasAndFiqhList
            .where((i) => i.category == _duasFiqhFilter)
            .toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(
              child: _buildChoiceButton(
                selected: _duasFiqhFilter == 'all',
                label: 'الكل',
                onTap: () => setState(() => _duasFiqhFilter = 'all'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildChoiceButton(
                selected: _duasFiqhFilter == 'dua',
                label: 'أدعية القرآن والسنة',
                onTap: () => setState(() => _duasFiqhFilter = 'dua'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildChoiceButton(
                selected: _duasFiqhFilter == 'fiqh',
                label: 'فقه الحمل والولادة',
                onTap: () => setState(() => _duasFiqhFilter = 'fiqh'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        ...items.map(
          (item) => Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: kWhite,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kGold.withOpacity(0.45)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: kBrown,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: kBeige.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    item.arabicText,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: kBrown,
                      height: 1.75,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  item.explanation,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontSize: 12.5,
                    color: kBrown,
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        'المصدر: ${item.source}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 11.5,
                          fontWeight: FontWeight.bold,
                          color: kGold,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'نسخ النص مع المصدر',
                      icon: const Icon(Icons.copy_rounded,
                          size: 18, color: kBrown),
                      onPressed: () {
                        Clipboard.setData(
                          ClipboardData(
                            text:
                                '${item.title}\n${item.arabicText}\n(${item.source})',
                          ),
                        );
                        _showMessage('تم نسخ النص مع مصدره');
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 9: حقيبة الولادة التفاعلية (للأم + للمولود + المستندات)
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildHospitalBagScreen() {
    final items = _bagItems.where((i) => i.category == _bagTab).toList();
    final total = _bagItems.length;
    final packed = _bagItems.where((i) => i.isPacked).length;
    final pct = total == 0 ? 0.0 : (packed / total);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'نسبة تجهيز حقيبة الولادة',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 14.5,
                      color: kBrown,
                    ),
                  ),
                  Text(
                    '$packed من $total (${(pct * 100).round()}%)',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      color: kGreen,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: pct,
                  minHeight: 10,
                  backgroundColor: kBeige,
                  valueColor: const AlwaysStoppedAnimation<Color>(kGreen),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildChoiceButton(
                selected: _bagTab == 'mother',
                label: 'حقيبة الأم',
                onTap: () => setState(() => _bagTab = 'mother'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildChoiceButton(
                selected: _bagTab == 'baby',
                label: 'حقيبة المولود',
                onTap: () => setState(() => _bagTab = 'baby'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _buildChoiceButton(
                selected: _bagTab == 'documents',
                label: 'المستندات',
                onTap: () => setState(() => _bagTab = 'documents'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _customBagItemCtrl,
                decoration: InputDecoration(
                  hintText: 'أضيفي غرضاً جديداً لهذه القائمة...',
                  hintStyle: const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  filled: true,
                  fillColor: kWhite,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: kGold,
                foregroundColor: kWhite,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () async {
                final txt = _customBagItemCtrl.text.trim();
                if (txt.isEmpty) return;
                await _db.insertHospitalBagItem(
                  HospitalBagItemRecord(
                    pregnancyId: _profile!.id!,
                    category: _bagTab,
                    itemName: txt,
                    isPacked: false,
                    createdAt: DateTime.now().toIso8601String(),
                  ),
                );
                _customBagItemCtrl.clear();
                await _reloadData();
              },
              child: const Text(
                'إضافة',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kSoftPink),
          ),
          child: items.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                    child: Text(
                      'لا توجد عناصر في هذا القسم حالياً.',
                      style: TextStyle(fontFamily: 'Cairo', color: kGrey),
                    ),
                  ),
                )
              : Column(
                  children: items
                      .map(
                        (item) => CheckboxListTile(
                          activeColor: kGreen,
                          value: item.isPacked,
                          onChanged: (v) async {
                            if (item.id != null) {
                              await _db.toggleHospitalBagItem(
                                  item.id!, v ?? false);
                              await _reloadData();
                            }
                          },
                          title: Text(
                            item.itemName,
                            style: TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: kBrown,
                              decoration: item.isPacked
                                  ? TextDecoration.lineThrough
                                  : null,
                            ),
                          ),
                          secondary: IconButton(
                            icon: const Icon(Icons.delete_outline,
                                color: Colors.redAccent, size: 19),
                            onPressed: () async {
                              if (item.id != null) {
                                await _db.deleteHospitalBagItem(item.id!);
                                await _reloadData();
                              }
                            },
                          ),
                        ),
                      )
                      .toList(),
                ),
        ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 10: مذكرات رحلتي ورسائل لجنيني
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildJournalScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  PregnancySvgIcons.journal(size: 24),
                  const SizedBox(width: 8),
                  Text(
                    'خاطرة أو رسالة لجنينكِ (الأسبوع ${_calc!.currentWeek})',
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: kBrown,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _noteTitleCtrl,
                decoration: InputDecoration(
                  labelText: 'عنوان الخاطرة (اختياري)',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _noteContentCtrl,
                maxLines: 3,
                decoration: InputDecoration(
                  labelText: 'اكتبي مشاعركِ أو دعاءكِ لجنينكِ في هذا الأسبوع...',
                  labelStyle:
                      const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kGold,
                    foregroundColor: kWhite,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () async {
                    final content = _noteContentCtrl.text.trim();
                    if (content.isEmpty) {
                      _showMessage('يرجى كتابة نص الخاطرة أولاً',
                          isError: true);
                      return;
                    }
                    await _db.insertNote(
                      PregnancyNoteRecord(
                        pregnancyId: _profile!.id!,
                        week: _calc!.currentWeek,
                        date: _todayIso(),
                        title: _noteTitleCtrl.text.trim().isEmpty
                            ? 'ذكرى الأسبوع ${_calc!.currentWeek}'
                            : _noteTitleCtrl.text.trim(),
                        content: content,
                        createdAt: DateTime.now().toIso8601String(),
                      ),
                    );
                    _noteTitleCtrl.clear();
                    _noteContentCtrl.clear();
                    await _reloadData();
                    _showMessage('تم حفظ الخاطرة في مذكرات رحلتكِ');
                  },
                  child: const Text(
                    'حفظ في مذكرات رحلتي',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (_notes.isEmpty)
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: kWhite,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kSoftPink),
            ),
            child: const Center(
              child: Text(
                'لم تكتبي أي مذكرات بعد. كل ما تكتبينه هنا يُحفظ بخصوصية تامة على جهازكِ.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12.5,
                  color: kGrey,
                ),
              ),
            ),
          )
        else
          ..._notes.map(
            (n) => Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kWhite,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: kSoftPink),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${n.title} • الأسبوع ${n.week}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: kBrown,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline,
                            color: Colors.redAccent, size: 19),
                        onPressed: () async {
                          if (n.id != null) {
                            await _db.deleteNote(n.id!);
                            await _reloadData();
                          }
                        },
                      ),
                    ],
                  ),
                  Text(
                    _formatIsoToArabic(n.date),
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 11,
                      color: kGold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    n.content,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 13,
                      color: kBrown,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // الشاشة 11: التذكيرات الحقيقية والإعدادات والخصوصية
  // ══════════════════════════════════════════════════════════════════════════
  Widget _buildSettingsScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'التذكيرات اليومية الحقيقية (Offline Notifications)',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'تعمل التذكيرات عبر نظام إشعارات الهاتف الفعلي حتى بعد إغلاق التطبيق أو إعادة تشغيل الجهاز.',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 11.5,
                  color: kGrey,
                ),
              ),
              const SizedBox(height: 10),
              ..._reminders.map(
                (r) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kBeige.withOpacity(0.45),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              r.title,
                              style: const TextStyle(
                                fontFamily: 'Cairo',
                                fontWeight: FontWeight.bold,
                                fontSize: 13,
                                color: kBrown,
                              ),
                            ),
                            Text(
                              'الوقت المحدد: ${r.time}',
                              style: const TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 11.5,
                                color: kGold,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: () async {
                          final parts = r.time.split(':');
                          final picked = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay(
                              hour: int.tryParse(parts[0]) ?? 9,
                              minute: int.tryParse(parts[1]) ?? 0,
                            ),
                          );
                          if (picked != null) {
                            final hm =
                                '${picked.hour.toString().padLeft(2, '0')}:${picked.minute.toString().padLeft(2, '0')}';
                            final ok = await _db.updateReminder(
                              reminderKey: r.reminderKey,
                              enabled: true,
                              timeHm: hm,
                            );
                            await _reloadData();
                            if (ok) {
                              _showMessage('تم تحديث وقت التذكير وجدولته فعلياً');
                            } else {
                              _showMessage(
                                'يرجى تفعيل صلاحية الإشعارات أولاً',
                                isError: true,
                              );
                            }
                          }
                        },
                        child: const Text(
                          'تغيير الوقت',
                          style: TextStyle(fontFamily: 'Cairo', fontSize: 12),
                        ),
                      ),
                      Switch(
                        activeColor: kGreen,
                        value: r.enabled,
                        onChanged: (val) async {
                          final ok = await _db.updateReminder(
                            reminderKey: r.reminderKey,
                            enabled: val,
                            timeHm: r.time,
                          );
                          await _reloadData();
                          if (!ok && val) {
                            _showMessage(
                              'الإشعارات غير مفعلة في النظام، افتحي إعدادات الإشعارات',
                              isError: true,
                            );
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
              TextButton.icon(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const NotificationSettingsPage(),
                    ),
                  );
                },
                icon: const Icon(Icons.notifications_active_outlined,
                    size: 18, color: kGold),
                label: const Text(
                  'فحص وإدارة صلاحيات إشعارات النظام',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 12.5,
                    color: kGold,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // تعديل تاريخ الحمل أو إعادة الحساب
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: kWhite,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: kSoftPink),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'إدارة بيانات الحمل والخصوصية',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  color: kBrown,
                ),
              ),
              const SizedBox(height: 10),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.edit_calendar, color: kGold),
                title: const Text(
                  'تعديل تاريخ آخر دورة / موعد الولادة المتوقع',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                onTap: () => setState(() => _activeView = 'setup'),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading:
                    const Icon(Icons.delete_forever, color: Colors.redAccent),
                title: const Text(
                  'حذف جميع بيانات رحلة الحمل نهائياً',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: Colors.redAccent,
                  ),
                ),
                onTap: _confirmWipeAllData,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _confirmWipeAllData() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text(
            'حذف بيانات الحمل نهائياً؟',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
          ),
          content: const Text(
            'سيتم مسح جميع سجلات الوزن والأعراض وحركات الجنين والمواعيد والمذكرات من جهازكِ ولا يمكن التراجع عن ذلك.',
            style: TextStyle(fontFamily: 'Cairo', fontSize: 13),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child:
                  const Text('إلغاء', style: TextStyle(fontFamily: 'Cairo')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade700,
                foregroundColor: kWhite,
              ),
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text(
                'نعم، احذف الكل',
                style: TextStyle(
                    fontFamily: 'Cairo', fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );

    if (confirmed == true) {
      await _db.wipeAllPregnancyData();
      await _reloadData();
      _showMessage('تم حذف جميع بيانات الحمل بنجاح');
    }
  }

  Widget _buildChoiceButton({
    required bool selected,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? kGold : kWhite,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: kGold),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 12,
            color: selected ? kWhite : kBrown,
          ),
        ),
      ),
    );
  }
}
