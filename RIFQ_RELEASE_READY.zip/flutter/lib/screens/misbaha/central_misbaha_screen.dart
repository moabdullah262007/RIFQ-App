import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:confetti/confetti.dart';
import 'package:vibration/vibration.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:share_plus/share_plus.dart';
import '../../services/misbaha_sqlite_service.dart';

class CentralMisbahaScreen extends StatefulWidget {
  const CentralMisbahaScreen({Key? key}) : super(key: key);

  @override
  State<CentralMisbahaScreen> createState() => _CentralMisbahaScreenState();
}

class _CentralMisbahaScreenState extends State<CentralMisbahaScreen>
    with SingleTickerProviderStateMixin {
  // الهوية اللونية الرسمية لتطبيق رِفْق
  static const Color colorGold = Color(0xFF5B5FEF);
  static const Color colorLightGold = Color(0xFFE8B84A);
  static const Color colorWhite = Color(0xFFFFFFFF);
  static const Color colorBeige = Color(0xFFF7F7FC);
  static const Color colorLightBeige = Color(0xFFF7F7FC);
  static const Color colorBrown = Color(0xFF25263A);
  static const Color colorGray = Color(0xFF77798C);
  static const Color colorGreenStart = Color(0xFF5B5FEF);
  static const Color colorGreenEnd = Color(0xFF4145C7);
  static const Color colorRedWarning = Color(0xFFD95C6A);

  final MisbahaSqliteService _sqlite = MisbahaSqliteService.instance;
  final AudioPlayer _audioPlayer = AudioPlayer();
  late final ConfettiController _confettiController;
  late final AnimationController _pulseController;

  bool _isLoading = true;
  bool _isButtonPressed = false;
  String _activeSubScreen = 'main'; // main, goals, custom_adhkar, settings, stats, history, hisn

  MisbahaSettingsRow? _settings;
  DailyStatsRow? _todayStats;
  MisbahaStreakRow? _streak;
  List<DailyStatsRow> _allDailyStats = [];
  List<MisbahaSessionRow> _sessions = [];
  List<CustomDhikrRow> _customAdhkar = [];

  final List<Map<String, dynamic>> _builtinAdhkar = const [
    {'text': 'سُبْحَانَ اللَّهِ', 'target': 100},
    {'text': 'الْحَمْدُ لِلَّهِ', 'target': 100},
    {'text': 'اللَّهُ أَكْبَرُ', 'target': 100},
    {'text': 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ', 'target': 100},
    {'text': 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ', 'target': 100},
    {'text': 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ', 'target': 100},
    {'text': 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ', 'target': 100},
    {'text': 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', 'target': 100},
  ];

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: const Duration(seconds: 2));
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 160),
    );
    _loadDataFromSqlite();
  }

  @override
  void dispose() {
    _confettiController.dispose();
    _pulseController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _loadDataFromSqlite() async {
    final settings = await _sqlite.getSettings();
    final today = await _sqlite.getTodayStats();
    final streak = await _sqlite.getStreak();
    final allDaily = await _sqlite.getAllDailyStats();
    final sessions = await _sqlite.getSessions();
    final custom = await _sqlite.getCustomAdhkar();

    if (!mounted) return;
    setState(() {
      _settings = settings;
      _todayStats = today;
      _streak = streak;
      _allDailyStats = allDaily;
      _sessions = sessions;
      _customAdhkar = custom;
      _isLoading = false;
    });
  }

  Future<void> _triggerFeedback() async {
    final s = _settings;
    if (s == null) return;

    // 1. الصوت
    if (s.sound != 'silent' && s.soundVolume > 0) {
      await SystemSound.play(SystemSoundType.click);
    }

    // 2. الاهتزاز
    if (s.vibration != 'none') {
      try {
        final hasVib = await Vibration.hasVibrator() ?? false;
        if (hasVib) {
          final dur = s.vibration == 'light'
              ? 15
              : s.vibration == 'medium'
                  ? 35
                  : 70;
          Vibration.vibrate(duration: dur);
        } else {
          HapticFeedback.lightImpact();
        }
      } catch (_) {
        HapticFeedback.lightImpact();
      }
    }
  }

  Future<void> _handleTasbeehTap() async {
    await _triggerFeedback();
    _pulseController.forward(from: 0.0);

    final completedCycle = await _sqlite.incrementTasbeeh();
    await _loadDataFromSqlite();

    if (completedCycle) {
      _confettiController.play();
      HapticFeedback.heavyImpact();
    }
  }

  Color _getThemePrimaryColor() {
    final theme = _settings?.theme ?? 'gold';
    switch (theme) {
      case 'emerald':
        return const Color(0xFF4145C7);
      case 'sapphire':
        return const Color(0xFF0D47A1);
      case 'brown':
        return const Color(0xFF25263A);
      case 'rose':
        return const Color(0xFF880E4F);
      case 'gold':
      default:
        return colorGold;
    }
  }

  String _getMotivationalText() {
    final currentStreak = _streak?.currentStreak ?? 0;
    final todayCount = _todayStats?.totalCount ?? 0;
    if (currentStreak >= 7 || todayCount >= 100) {
      return 'ما شاء الله! واصل';
    }
    return 'أنت في الطريق الصحيح';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = _settings?.darkMode ?? false;
    final bgStart = isDark ? const Color(0xFF1E1410) : colorBeige;
    final bgEnd = isDark ? const Color(0xFF281A15) : colorLightBeige;
    final cardBg = isDark ? const Color(0xFF2A1B16) : colorWhite;
    final textColor = isDark ? colorBeige : colorBrown;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgStart,
        // 【الشريط العلوي】
        // يمين: ☰ القائمة + "المسبحة المركزية" Cairo Bold ذهبي
        // يسار: أيقونة الإحصائيات + الإعدادات
        // خلفية بيج مع حد ذهبي رفيع أسفل
        appBar: AppBar(
          backgroundColor: bgStart,
          elevation: 0,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1.2),
            child: Container(height: 1.2, color: colorGold),
          ),
          leading: IconButton(
            icon: Icon(
              _activeSubScreen == 'main' ? Icons.menu_rounded : Icons.arrow_back_rounded,
              color: colorGold,
            ),
            onPressed: () {
              if (_activeSubScreen != 'main') {
                setState(() => _activeSubScreen = 'main');
              } else {
                Navigator.of(context).maybePop();
              }
            },
          ),
          title: const Text(
            'المسبحة المركزية',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 20,
              color: colorGold,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.bar_chart_rounded, color: colorGold),
              tooltip: 'الإحصائيات',
              onPressed: () => setState(() {
                _activeSubScreen = _activeSubScreen == 'stats' ? 'main' : 'stats';
              }),
            ),
            IconButton(
              icon: const Icon(Icons.settings_outlined, color: colorGold),
              tooltip: 'الإعدادات',
              onPressed: () => setState(() {
                _activeSubScreen = _activeSubScreen == 'settings' ? 'main' : 'settings';
              }),
            ),
          ],
        ),
        body: Stack(
          alignment: Alignment.topCenter,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [bgStart, bgEnd],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _buildSubScreenTabs(cardBg, textColor),
                  const SizedBox(height: 16),
                  if (_activeSubScreen == 'main')
                    _buildMainMisbahaView(cardBg, textColor)
                  else if (_activeSubScreen == 'goals')
                    _buildGoalsSubScreen(cardBg, textColor)
                  else if (_activeSubScreen == 'custom_adhkar')
                    _buildCustomAdhkarSubScreen(cardBg, textColor)
                  else if (_activeSubScreen == 'settings')
                    _buildSettingsSubScreen(cardBg, textColor)
                  else if (_activeSubScreen == 'stats')
                    _buildStatsSubScreen(cardBg, textColor)
                  else if (_activeSubScreen == 'history')
                    _buildHistorySubScreen(cardBg, textColor)
                  else if (_activeSubScreen == 'hisn')
                    _buildHisnSubScreen(cardBg, textColor),
                ],
              ),
            ),
            ConfettiWidget(
              confettiController: _confettiController,
              blastDirectionality: BlastDirectionality.explosive,
              shouldLoop: false,
              colors: const [colorGold, colorLightGold, colorGreenStart, colorWhite],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubScreenTabs(Color cardBg, Color textColor) {
    final tabs = [
      {'id': 'main', 'label': 'المسبحة'},
      {'id': 'goals', 'label': 'الأهداف'},
      {'id': 'custom_adhkar', 'label': 'أذكار مخصصة'},
      {'id': 'stats', 'label': 'الإحصائيات'},
      {'id': 'history', 'label': 'السجل'},
      {'id': 'settings', 'label': 'الإعدادات'},
      {'id': 'hisn', 'label': 'حصن المسلم'},
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: tabs.map((t) {
          final active = _activeSubScreen == t['id'];
          return Padding(
            padding: const EdgeInsets.only(left: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => setState(() => _activeSubScreen = t['id']!),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: active ? colorGold : cardBg,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: colorGold, width: 1),
                ),
                child: Text(
                  t['label']!,
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    color: active ? colorWhite : textColor,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildMainMisbahaView(Color cardBg, Color textColor) {
    final currentDhikr = _settings?.currentDhikr ?? 'سُبْحَانَ اللَّهِ';
    final currentCount = _settings?.currentCount ?? 0;
    final currentTarget = _settings?.currentTarget ?? 100;
    final progress = currentTarget > 0 ? (currentCount / currentTarget).clamp(0.0, 1.0) : 1.0;
    final themeColor = _getThemePrimaryColor();

    return Column(
      children: [
        // 【بطاقة الذكر الحالي】
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: colorGold, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              const Row(
                children: [
                  Icon(Icons.mosque_outlined, color: colorGold, size: 20),
                  SizedBox(width: 8),
                  Text(
                    'الذكر الحالي',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      color: colorGray,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                currentDhikr,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontWeight: FontWeight.bold,
                  fontSize: 32,
                  color: textColor,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: colorGold),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onPressed: _showDhikrSelectorSheet,
                icon: const Icon(Icons.sync_rounded, color: colorGold, size: 18),
                label: Text(
                  'تغيير الذكر',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    color: textColor,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // 【الدائرة الكبيرة (العداد) — 280px】
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: colorGold, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              SizedBox(
                width: 280,
                height: 280,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 280,
                      height: 280,
                      child: CircularProgressIndicator(
                        value: progress,
                        strokeWidth: 8,
                        backgroundColor: colorGold.withOpacity(0.2),
                        valueColor: AlwaysStoppedAnimation<Color>(themeColor),
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '$currentCount',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 72,
                            color: themeColor,
                            height: 1.1,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          currentTarget > 0 ? 'من $currentTarget' : 'هدف مفتوح',
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.normal,
                            fontSize: 18,
                            color: colorGray,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 8,
                  backgroundColor: colorBeige,
                  valueColor: AlwaysStoppedAnimation<Color>(themeColor),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                '${(progress * 100).round()}%',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: colorGold,
                ),
              ),
              const SizedBox(height: 18),

              // 【زر التسبيح الرئيسي 120px + الأزرار الجانبية】
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  // يمين: نقصان -1
                  IconButton(
                    onPressed: () async {
                      await _sqlite.decrementTasbeeh();
                      await _loadDataFromSqlite();
                    },
                    icon: const Icon(Icons.remove_circle_outline_rounded, size: 32),
                    color: textColor,
                    tooltip: 'نقصان -1',
                  ),

                  // المنتصف: دائرة خضراء 120px
                  GestureDetector(
                    onTapDown: (_) => setState(() => _isButtonPressed = true),
                    onTapUp: (_) {
                      setState(() => _isButtonPressed = false);
                      _handleTasbeehTap();
                    },
                    onTapCancel: () => setState(() => _isButtonPressed = false),
                    child: AnimatedScale(
                      scale: _isButtonPressed ? 0.95 : 1.0,
                      duration: const Duration(milliseconds: 120),
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [colorGreenStart, colorGreenEnd],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: colorGreenStart.withOpacity(0.45),
                              blurRadius: 20,
                              offset: const Offset(0, 8),
                            ),
                          ],
                        ),
                        child: const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.grain_rounded, color: colorWhite, size: 38),
                            SizedBox(height: 4),
                            Text(
                              'سبّح',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                                color: colorWhite,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // يسار: إعادة تعيين
                  IconButton(
                    onPressed: () => _confirmResetDialog(resetAllStats: false),
                    icon: const Icon(Icons.restart_alt_rounded, size: 32),
                    color: colorRedWarning,
                    tooltip: 'إعادة تعيين',
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // 【الإحصائيات السريعة: 3 بطاقات】
        Row(
          children: [
            Expanded(
              child: _buildQuickStatCard(
                title: 'تسبيحات اليوم',
                value: '${_todayStats?.totalCount ?? 0}',
                cardBg: cardBg,
                textColor: textColor,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildQuickStatCard(
                title: 'الدورات',
                value: '${_settings?.totalCycles ?? 0}',
                cardBg: cardBg,
                textColor: textColor,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildQuickStatCard(
                title: 'السلسلة',
                value: '${_streak?.currentStreak ?? 0}',
                cardBg: cardBg,
                textColor: textColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),

        // 【بطاقة حصن المسلم السريع في الأسفل】
        InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => setState(() => _activeSubScreen = 'hisn'),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: colorGold, width: 1),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.menu_book_rounded, color: colorGold, size: 26),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'حصن المسلم السريع',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: textColor,
                          ),
                        ),
                        const Text(
                          'أذكار الصباح والمساء وأدعية التحصين النبوية',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            color: colorGray,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const Icon(Icons.arrow_forward_ios_rounded, color: colorGold, size: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuickStatCard({
    required String title,
    required String value,
    required Color cardBg,
    required Color textColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorGold, width: 1),
      ),
      child: Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 22,
              color: colorGold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 12,
              color: textColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGoalsSubScreen(Color cardBg, Color textColor) {
    final dailyTarget = _settings?.dailyTarget ?? 100;
    final todayCount = _todayStats?.totalCount ?? 0;
    final dailyProgress = dailyTarget > 0 ? (todayCount / dailyTarget).clamp(0.0, 1.0) : 1.0;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorGold, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'الأهداف اليومية والأسبوعية والشهرية',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: textColor,
            ),
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            children: [100, 500, 1000, 0].map((target) {
              final selected = dailyTarget == target;
              return ChoiceChip(
                label: Text(target == 0 ? 'مفتوح' : '$target'),
                selected: selected,
                selectedColor: colorGold,
                onSelected: (_) async {
                  await _sqlite.updateSettings({
                    'daily_target': target,
                    'current_target': target,
                  });
                  await _loadDataFromSqlite();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: dailyProgress,
            minHeight: 10,
            backgroundColor: colorBeige,
            valueColor: const AlwaysStoppedAnimation<Color>(colorGreenStart),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomAdhkarSubScreen(Color cardBg, Color textColor) {
    final controller = TextEditingController();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorGold, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'الأذكار المخصصة',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: textColor,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            decoration: const InputDecoration(
              hintText: 'أدخل نص الذكر المخصص...',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: colorGreenStart),
            onPressed: () async {
              if (controller.text.trim().isNotEmpty) {
                await _sqlite.addCustomDhikr(
                  text: controller.text.trim(),
                  target: 100,
                  listName: 'أذكار عامة',
                );
                await _loadDataFromSqlite();
              }
            },
            child: const Text('إضافة ذكر مخصص', style: TextStyle(color: colorWhite)),
          ),
          const SizedBox(height: 16),
          ..._customAdhkar.map(
            (item) => ListTile(
              title: Text(item.text, style: const TextStyle(fontFamily: 'Amiri', fontSize: 18)),
              subtitle: Text('${item.listName} · الهدف: ${item.target} · الاستخدام: ${item.usageCount}'),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: colorRedWarning),
                onPressed: () async {
                  await _sqlite.deleteCustomDhikr(item.id);
                  await _loadDataFromSqlite();
                },
              ),
              onTap: () async {
                await _sqlite.updateSettings({
                  'current_dhikr': item.text,
                  'current_target': item.target,
                });
                await _loadDataFromSqlite();
                setState(() => _activeSubScreen = 'main');
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsSubScreen(Color cardBg, Color textColor) {
    final currentSound = _settings?.sound ?? 'wood';
    final currentVib = _settings?.vibration ?? 'medium';
    final currentTheme = _settings?.theme ?? 'gold';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorGold, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'أصوات النقر',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, color: textColor),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              {'id': 'wood', 'label': 'خشبي'},
              {'id': 'water', 'label': 'ماء'},
              {'id': 'golden_bell', 'label': 'جرس ذهبي'},
              {'id': 'silent', 'label': 'صامت'},
            ].map((s) {
              return ChoiceChip(
                label: Text(s['label']!),
                selected: currentSound == s['id'],
                selectedColor: colorGold,
                onSelected: (_) async {
                  await _sqlite.updateSettings({'sound': s['id']});
                  await _loadDataFromSqlite();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Text(
            'الاهتزاز',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, color: textColor),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              {'id': 'light', 'label': 'خفيف'},
              {'id': 'medium', 'label': 'متوسط'},
              {'id': 'strong', 'label': 'قوي'},
              {'id': 'none', 'label': 'بدون'},
            ].map((v) {
              return ChoiceChip(
                label: Text(v['label']!),
                selected: currentVib == v['id'],
                selectedColor: colorGold,
                onSelected: (_) async {
                  await _sqlite.updateSettings({'vibration': v['id']});
                  await _loadDataFromSqlite();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Text(
            'ثيمات المسبحة',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, color: textColor),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              {'id': 'gold', 'label': 'ذهبي كلاسيكي'},
              {'id': 'emerald', 'label': 'أخضر زمردي'},
              {'id': 'sapphire', 'label': 'أزرق ملكي'},
              {'id': 'brown', 'label': 'بني دافئ'},
              {'id': 'rose', 'label': 'وردي هادئ'},
            ].map((th) {
              return ChoiceChip(
                label: Text(th['label']!),
                selected: currentTheme == th['id'],
                selectedColor: colorGold,
                onSelected: (_) async {
                  await _sqlite.updateSettings({'theme': th['id']});
                  await _loadDataFromSqlite();
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: colorRedWarning,
              side: const BorderSide(color: colorRedWarning),
            ),
            onPressed: () => _confirmResetDialog(resetAllStats: true),
            child: const Text('تصفير جميع الإحصائيات والسجل'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsSubScreen(Color cardBg, Color textColor) {
    final totalLifetime = _allDailyStats.fold<int>(0, (sum, r) => sum + r.totalCount);
    final totalCycles = _settings?.totalCycles ?? 0;
    final longestStreak = _streak?.longestStreak ?? 0;

    final achievements = [
      {'title': 'أكملت 1000 تسبيحة', 'done': totalLifetime >= 1000, 'progress': '$totalLifetime / 1000'},
      {'title': 'استمريت 30 يوم', 'done': longestStreak >= 30, 'progress': '$longestStreak / 30'},
      {'title': 'أكملت 100 دورة', 'done': totalCycles >= 100, 'progress': '$totalCycles / 100'},
    ];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorGold, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'الإحصائيات والإنجازات',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: textColor,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _getMotivationalText(),
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: colorGreenStart,
            ),
          ),
          const Divider(height: 24),
          ...achievements.map(
            (a) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    a['title'] as String,
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      color: (a['done'] as bool) ? colorGreenStart : textColor,
                    ),
                  ),
                  Text(
                    a['progress'] as String,
                    style: const TextStyle(fontFamily: 'Cairo', color: colorGray),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: colorGold),
            onPressed: () {
              Share.share(
                'إحصائياتي في المسبحة المركزية (رِفْق): اليوم ${_todayStats?.totalCount ?? 0} تسبيحة، الدورات $totalCycles، السلسلة ${_streak?.currentStreak ?? 0} يوم.',
              );
            },
            icon: const Icon(Icons.share_rounded, color: colorWhite),
            label: const Text('مشاركة الإنجاز', style: TextStyle(color: colorWhite)),
          ),
        ],
      ),
    );
  }

  Widget _buildHistorySubScreen(Color cardBg, Color textColor) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorGold, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'سجل الجلسات (${_sessions.length})',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: textColor,
            ),
          ),
          const SizedBox(height: 12),
          if (_sessions.isEmpty)
            const Text('لا توجد جلسات محفوظة بعد', style: TextStyle(color: colorGray))
          else
            ..._sessions.map(
              (sess) => ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(sess.dhikr, style: const TextStyle(fontFamily: 'Amiri', fontSize: 18)),
                subtitle: Text('العدد: ${sess.count} · المدة: ${sess.duration} ثانية'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline, color: colorRedWarning),
                  onPressed: () async {
                    await _sqlite.deleteSession(sess.id);
                    await _loadDataFromSqlite();
                  },
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildHisnSubScreen(Color cardBg, Color textColor) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorGold, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'حصن المسلم السريع',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: textColor,
            ),
          ),
          const SizedBox(height: 12),
          ..._builtinAdhkar.map(
            (d) => ListTile(
              title: Text(d['text'] as String, style: const TextStyle(fontFamily: 'Amiri', fontSize: 19)),
              trailing: const Text('تسبيح', style: TextStyle(color: colorGold, fontWeight: FontWeight.bold)),
              onTap: () async {
                await _sqlite.updateSettings({
                  'current_dhikr': d['text'],
                  'current_target': d['target'],
                });
                await _loadDataFromSqlite();
                setState(() => _activeSubScreen = 'main');
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showDhikrSelectorSheet() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'اختر الذكر الحالي',
              style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 12),
            ..._builtinAdhkar.map(
              (item) => ListTile(
                title: Text(item['text'] as String, style: const TextStyle(fontFamily: 'Amiri', fontSize: 20)),
                subtitle: Text('الهدف: ${item['target']}'),
                onTap: () async {
                  Navigator.pop(ctx);
                  await _sqlite.updateSettings({
                    'current_dhikr': item['text'],
                    'current_target': item['target'],
                  });
                  await _loadDataFromSqlite();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmResetDialog({required bool resetAllStats}) {
    showDialog(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: Text(
            resetAllStats ? 'تصفير جميع الإحصائيات' : 'إعادة تعيين العداد',
            style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
          ),
          content: Text(
            resetAllStats
                ? 'سيتم مسح جميع الإحصائيات والسجل والدورات نهائياً. هل أنت متأكد؟'
                : 'سيتم تصفير العداد الحالي مع حفظ الجلسة الحالية في السجل.',
            style: const TextStyle(fontFamily: 'Cairo'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: colorRedWarning),
              onPressed: () async {
                Navigator.pop(ctx);
                if (resetAllStats) {
                  await _sqlite.resetAllStatistics();
                } else {
                  await _sqlite.resetCurrentCounter(logPartialSession: true);
                }
                await _loadDataFromSqlite();
              },
              child: const Text('تأكيد', style: TextStyle(color: colorWhite)),
            ),
          ],
        ),
      ),
    );
  }
}
