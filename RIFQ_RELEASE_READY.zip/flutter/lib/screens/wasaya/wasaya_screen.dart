import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:share_plus/share_plus.dart';
import '../../services/wasaya_sqlite_service.dart';

class WasayaScreen extends StatefulWidget {
  const WasayaScreen({Key? key}) : super(key: key);

  @override
  State<WasayaScreen> createState() => _WasayaScreenState();
}

enum _WasayaSubScreen { home, category, detail, search, favorites }

class _WasayaScreenState extends State<WasayaScreen> {
  static const Color colorGold = Color(0xFF5B5FEF);
  static const Color colorLightGold = Color(0xFFE8B84A);
  static const Color colorWhite = Color(0xFFFFFFFF);
  static const Color colorBeige = Color(0xFFF7F7FC);
  static const Color colorBrown = Color(0xFF25263A);
  static const Color colorGray = Color(0xFF77798C);
  static const Color colorGreen = Color(0xFF4CAF82);

  _WasayaSubScreen _subScreen = _WasayaSubScreen.home;
  _WasayaSubScreen _previousScreen = _WasayaSubScreen.home;

  List<WasayaCategoryModel> _categories = [];
  List<WasiyaModel> _allWasaya = [];
  Set<String> _favoriteIds = {};

  String _selectedCategoryId = 'worship';
  WasiyaModel? _selectedWasiya;
  String _searchQuery = '';
  String _selectedFilterCategory = 'all';
  double _fontScale = 1.0;
  bool _isDarkMode = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final cats = await WasayaSqliteService.instance.getCategories();
    final wasaya = await WasayaSqliteService.instance.getAllWasaya();
    final favs = await WasayaSqliteService.instance.getFavoriteIds();
    if (!mounted) return;
    setState(() {
      _categories = cats;
      _allWasaya = wasaya;
      _favoriteIds = favs;
      _selectedWasiya = wasaya.isNotEmpty ? wasaya.first : null;
      _isLoading = false;
    });
  }

  WasiyaModel? get _dailyWasiya {
    if (_allWasaya.isEmpty) return null;
    final dayOfYear = DateTime.now().difference(DateTime(DateTime.now().year, 1, 1)).inDays;
    return _allWasaya[dayOfYear % _allWasaya.length];
  }

  Future<void> _toggleFav(String wasiyaId) async {
    HapticFeedback.lightImpact();
    final isFav = await WasayaSqliteService.instance.toggleFavorite(wasiyaId);
    final favs = await WasayaSqliteService.instance.getFavoriteIds();
    final wasaya = await WasayaSqliteService.instance.getAllWasaya();
    if (!mounted) return;
    setState(() {
      _favoriteIds = favs;
      _allWasaya = wasaya;
      if (_selectedWasiya?.id == wasiyaId) {
        _selectedWasiya = wasaya.firstWhere((w) => w.id == wasiyaId);
      }
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          isFav ? 'تم حفظ الوصية في المفضلة' : 'تمت إزالة الوصية من المفضلة',
          style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        backgroundColor: colorBrown,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _copyWasiya(WasiyaModel w) {
    HapticFeedback.lightImpact();
    final text = 'وصايا الرسول ﷺ — ${w.title}\n«${w.text}»\nالمصدر: ${w.source} (${w.narrator})\n— تطبيق رِفْق | RIFQ';
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'تم نسخ الوصية النبوية مع المصدر',
          style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        backgroundColor: colorBrown,
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _shareWasiya(WasiyaModel w) {
    HapticFeedback.lightImpact();
    final text = 'وصايا الرسول ﷺ — ${w.title}\n«${w.text}»\nالمصدر: ${w.source} (${w.narrator})\n— تطبيق رِفْق | RIFQ';
    Share.share(text);
  }

  /// أيقونة SVG مصحف + قلب ذهبي (48×48)
  Widget _buildMushafHeartSvg({double size = 40}) {
    const svgStr = '''
    <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="24" cy="24" r="22" fill="#F7F7FC" stroke="#5B5FEF" stroke-width="2"/>
      <path d="M10 18C10 16.3 11.3 15 13 15H21C22.7 15 24 16.3 24 18V34C24 32.9 23.1 32 22 32H12C10.9 32 10 31.1 10 30V18Z" fill="#FFFFFF" stroke="#5B5FEF" stroke-width="2"/>
      <path d="M38 18C38 16.3 36.7 15 35 15H27C25.3 15 24 16.3 24 18V34C24 32.9 24.9 32 26 32H36C37.1 32 38 31.1 38 30V18Z" fill="#FFFFFF" stroke="#5B5FEF" stroke-width="2"/>
      <path d="M24 17.5C24 17.5 18.5 13.8 18.5 10.3C18.5 8.5 19.9 7.2 21.6 7.2C22.7 7.2 23.5 7.8 24 8.6C24.5 7.8 25.3 7.2 26.4 7.2C28.1 7.2 29.5 8.5 29.5 10.3C29.5 13.8 24 17.5 24 17.5Z" fill="#5B5FEF"/>
      <path d="M16 36L24 33L32 36" stroke="#4CAF82" stroke-width="2" stroke-linecap="round"/>
    </svg>
    ''';
    return SvgPicture.string(svgStr, width: size, height: size);
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = _isDarkMode ? const Color(0xFF121212) : colorBeige;
    final cardColor = _isDarkMode ? const Color(0xFF1E1E1E) : colorWhite;
    final textColor = _isDarkMode ? colorWhite : colorBrown;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: cardColor,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_rounded, color: textColor),
            onPressed: () {
              if (_subScreen == _WasayaSubScreen.home) {
                Navigator.pop(context);
              } else {
                setState(() => _subScreen = _previousScreen);
              }
            },
          ),
          title: Text(
            _subScreen == _WasayaSubScreen.category
                ? (_categories.firstWhere((c) => c.id == _selectedCategoryId, orElse: () => _categories.first).name)
                : _subScreen == _WasayaSubScreen.favorites
                    ? 'الوصايا المحفوظة'
                    : _subScreen == _WasayaSubScreen.search
                        ? 'البحث في الوصايا'
                        : 'وصايا الرسول ﷺ',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: textColor,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.search_rounded, color: colorGold),
              onPressed: () {
                setState(() {
                  _previousScreen = _subScreen;
                  _subScreen = _WasayaSubScreen.search;
                });
              },
            ),
            IconButton(
              icon: Icon(
                _favoriteIds.isNotEmpty ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: colorGold,
              ),
              onPressed: () {
                setState(() {
                  _previousScreen = _subScreen;
                  _subScreen = _WasayaSubScreen.favorites;
                });
              },
            ),
            IconButton(
              icon: Icon(
                _isDarkMode ? Icons.wb_sunny_outlined : Icons.nightlight_round,
                color: colorGold,
              ),
              onPressed: () => setState(() => _isDarkMode = !_isDarkMode),
            ),
          ],
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(color: colorGold))
            : _buildCurrentSubScreen(cardColor, textColor),
      ),
    );
  }

  Widget _buildCurrentSubScreen(Color cardColor, Color textColor) {
    switch (_subScreen) {
      case _WasayaSubScreen.home:
        return _buildHomeSubScreen(cardColor, textColor);
      case _WasayaSubScreen.category:
        return _buildCategorySubScreen(cardColor, textColor);
      case _WasayaSubScreen.detail:
        return _buildDetailSubScreen(cardColor, textColor);
      case _WasayaSubScreen.search:
        return _buildSearchSubScreen(cardColor, textColor);
      case _WasayaSubScreen.favorites:
        return _buildFavoritesSubScreen(cardColor, textColor);
    }
  }

  Widget _buildHomeSubScreen(Color cardColor, Color textColor) {
    final daily = _dailyWasiya;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // البطاقة الترحيبية
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold.withOpacity(0.5)),
          ),
          child: Column(
            children: [
              const Text(
                '﴿لَقَدْ كَانَ لَكُمْ فِي رَسُولِ اللَّهِ أُسْوَةٌ حَسَنَةٌ﴾ (الأحزاب: 21)',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: colorGreen,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '«تركت فيكم ما إن تمسكتم به لن تضلوا بعدي أبدًا» (مسلم)',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 16,
                  color: textColor,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),

        // قسم وصية اليوم
        if (daily != null) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: colorGold.withOpacity(0.5)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    _buildMushafHeartSvg(size: 32),
                    const SizedBox(width: 8),
                    const Text(
                      'وصية اليوم',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: colorGold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: _isDarkMode ? const Color(0xFF161616) : colorBeige,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '«${daily.text}»',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: 18,
                      color: textColor,
                      height: 1.8,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        '${daily.source} — ${daily.narrator}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: colorGray,
                        ),
                      ),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: colorGold,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        setState(() {
                          _selectedWasiya = daily;
                          _previousScreen = _WasayaSubScreen.home;
                          _subScreen = _WasayaSubScreen.detail;
                        });
                      },
                      child: const Text(
                        'اقرأ المزيد',
                        style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],

        // شبكة التصنيفات (2×N)
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
          ),
          itemCount: _categories.length,
          itemBuilder: (context, index) {
            final cat = _categories[index];
            return InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () {
                setState(() {
                  _selectedCategoryId = cat.id;
                  _previousScreen = _WasayaSubScreen.home;
                  _subScreen = _WasayaSubScreen.category;
                });
              },
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: colorGold.withOpacity(0.45)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildMushafHeartSvg(size: 48),
                        const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: colorGold),
                      ],
                    ),
                    Text(
                      cat.name,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: textColor,
                      ),
                    ),
                    Text(
                      'عدد الوصايا: ${cat.count}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontSize: 12,
                        color: colorGray,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildCategorySubScreen(Color cardColor, Color textColor) {
    final items = _allWasaya.where((w) => w.categoryId == _selectedCategoryId).toList();
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final w = items[index];
        return _buildWasiyaListCard(w, cardColor, textColor, _WasayaSubScreen.category);
      },
    );
  }

  Widget _buildWasiyaListCard(
    WasiyaModel w,
    Color cardColor,
    Color textColor,
    _WasayaSubScreen fromScreen,
  ) {
    final isFav = _favoriteIds.contains(w.id);
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () {
        setState(() {
          _selectedWasiya = w;
          _previousScreen = fromScreen;
          _subScreen = _WasayaSubScreen.detail;
        });
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: colorGold.withOpacity(0.45)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _isDarkMode ? const Color(0xFF161616) : colorBeige,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '«${w.text}»',
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 18,
                  color: textColor,
                  height: 1.85,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              '${w.source} — ${w.narrator}',
              style: const TextStyle(
                fontFamily: 'Cairo',
                fontSize: 12,
                color: colorGray,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () => _copyWasiya(w),
                  icon: const Icon(Icons.copy_rounded, size: 16, color: colorGold),
                  label: Text('نسخ', style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: textColor)),
                ),
                TextButton.icon(
                  onPressed: () => _shareWasiya(w),
                  icon: const Icon(Icons.share_rounded, size: 16, color: colorGold),
                  label: Text('مشاركة', style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: textColor)),
                ),
                TextButton.icon(
                  onPressed: () => _toggleFav(w.id),
                  icon: Icon(
                    isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                    size: 16,
                    color: colorGold,
                  ),
                  label: Text('مفضلة', style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: textColor)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailSubScreen(Color cardColor, Color textColor) {
    final w = _selectedWasiya;
    if (w == null) return const SizedBox.shrink();
    final isFav = _favoriteIds.contains(w.id);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold.withOpacity(0.5)),
          ),
          child: Column(
            children: [
              const Text(
                '─── الوصية ───',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                  color: colorGold,
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _isDarkMode ? const Color(0xFF161616) : colorBeige,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '«${w.text}»',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: 18 * _fontScale,
                    color: textColor,
                    height: 1.95,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                '${w.source} — ${w.narrator}',
                style: const TextStyle(fontFamily: 'Cairo', fontSize: 12, color: colorGray),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'الشرح',
                style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, fontSize: 16, color: colorGold),
              ),
              const SizedBox(height: 8),
              Text(
                w.explanation,
                style: TextStyle(fontFamily: 'Cairo', fontSize: 14 * _fontScale, color: textColor, height: 1.8),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'الفوائد',
                style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, fontSize: 16, color: colorGold),
              ),
              const SizedBox(height: 8),
              ...w.lessons.asMap().entries.map(
                    (entry) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        '${entry.key + 1}. ${entry.value}',
                        style: TextStyle(fontFamily: 'Cairo', fontSize: 14 * _fontScale, color: textColor),
                      ),
                    ),
                  ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: colorGold.withOpacity(0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'المصدر',
                style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, fontSize: 16, color: colorGold),
              ),
              const SizedBox(height: 8),
              Text('الكتاب: ${w.book}', style: TextStyle(fontFamily: 'Cairo', fontSize: 13, color: textColor)),
              Text('رقم الحديث: ${w.hadithNumber}', style: TextStyle(fontFamily: 'Cairo', fontSize: 13, color: textColor)),
              Text('الراوي: ${w.narrator}', style: TextStyle(fontFamily: 'Cairo', fontSize: 13, color: textColor)),
              Text('درجة الحديث: ${w.grade}', style: const TextStyle(fontFamily: 'Cairo', fontSize: 13, color: colorGreen, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () => _copyWasiya(w),
                child: const Text('نسخ', style: TextStyle(fontFamily: 'Cairo')),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: colorGold, foregroundColor: Colors.white),
                onPressed: () => _shareWasiya(w),
                child: const Text('مشاركة', style: TextStyle(fontFamily: 'Cairo')),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton(
                onPressed: () => _toggleFav(w.id),
                child: Text(isFav ? 'محفوظة' : 'مفضلة', style: const TextStyle(fontFamily: 'Cairo')),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  setState(() {
                    _fontScale = _fontScale >= 1.3 ? 1.0 : _fontScale + 0.15;
                  });
                },
                child: const Text('تكبير الخط', style: TextStyle(fontFamily: 'Cairo')),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSearchSubScreen(Color cardColor, Color textColor) {
    final results = _allWasaya.where((w) {
      if (_selectedFilterCategory != 'all' && w.categoryId != _selectedFilterCategory) return false;
      if (_searchQuery.trim().isEmpty) return true;
      return w.text.contains(_searchQuery) ||
          w.title.contains(_searchQuery) ||
          w.source.contains(_searchQuery) ||
          w.narrator.contains(_searchQuery);
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            onChanged: (v) => setState(() => _searchQuery = v),
            decoration: InputDecoration(
              hintText: 'ابحث في الوصايا...',
              filled: true,
              fillColor: cardColor,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: results.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, index) =>
                _buildWasiyaListCard(results[index], cardColor, textColor, _WasayaSubScreen.search),
          ),
        ),
      ],
    );
  }

  Widget _buildFavoritesSubScreen(Color cardColor, Color textColor) {
    final favItems = _allWasaya.where((w) => _favoriteIds.contains(w.id)).toList();
    if (favItems.isEmpty) {
      return Center(
        child: Text(
          'لا توجد وصايا محفوظة في المفضلة بعد',
          style: TextStyle(fontFamily: 'Cairo', fontSize: 15, color: textColor),
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: favItems.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) =>
          _buildWasiyaListCard(favItems[index], cardColor, textColor, _WasayaSubScreen.favorites),
    );
  }
}
