import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'misbaha/central_misbaha_screen.dart';
import 'quran/quran_mushaf_screen.dart';
import 'quran/quran_audio_screen.dart';
import 'quran/interactive_browsing_quiz_screen.dart';
import 'arbain_nawawiya/arbain_nawawiya_screen.dart';
import 'wasaya/wasaya_screen.dart';
import 'ghiras/ghiras_screen.dart';
import 'muslim_woman/muslim_woman_screen.dart';
import 'settings/notification_settings_page.dart';
export 'kids_stories/kids_stories_screen.dart';

// ═══════════════════════════════════════════════════════════════════════════
// 1. الصفحات المربوطة مباشرة بالشاشات الكاملة الموجودة في التطبيق
// ═══════════════════════════════════════════════════════════════════════════

class MisbahaPage extends StatelessWidget {
  const MisbahaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const CentralMisbahaScreen();
}

class SmartTasbeehPage extends StatelessWidget {
  const SmartTasbeehPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const CentralMisbahaScreen();
}

class QuranPage extends StatelessWidget {
  const QuranPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const QuranMushafScreen(
        surahNumber: 1,
        surahName: 'الفاتحة',
        juzNumber: 1,
        totalVerses: 7,
        revelationType: 'Meccan',
      );
}

class QuranAudioPage extends StatelessWidget {
  const QuranAudioPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const QuranAudioScreen();
}

class MemorizationPage extends StatelessWidget {
  const MemorizationPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const InteractiveBrowsingQuizScreen();
}

class NawawiPage extends StatelessWidget {
  const NawawiPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const ArbainNawawiyaScreen();
}

class WasiyaPage extends StatelessWidget {
  const WasiyaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const WasayaScreen();
}

class ParadiseGardenPage extends StatelessWidget {
  const ParadiseGardenPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const GhirasAlJannahScreen();
}

class WomenRifqPage extends StatelessWidget {
  const WomenRifqPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const MuslimWomanScreen();
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const NotificationSettingsPage();
}

// ═══════════════════════════════════════════════════════════════════════════
// 2. شاشات الأقسام التفاعلية الكاملة (RTL)
// ═══════════════════════════════════════════════════════════════════════════

class PrayerTimesPage extends StatelessWidget {
  const PrayerTimesPage({Key? key}) : super(key: key);

  static const List<Map<String, String>> _prayers = [
    {'name': 'الفجر', 'time': '04:42 ص', 'sunnah': 'ركعتان قبلها'},
    {'name': 'الشروق', 'time': '06:09 ص', 'sunnah': 'صلاة الضحى بعده بـ 15 دقيقة'},
    {'name': 'الظهر', 'time': '12:14 م', 'sunnah': '4 ركعات قبلها وركعتان بعدها'},
    {'name': 'العصر', 'time': '03:38 م', 'sunnah': 'صلاة الوسطى — حافظوا عليها'},
    {'name': 'المغرب', 'time': '06:18 م', 'sunnah': 'ركعتان بعدها'},
    {'name': 'العشاء', 'time': '07:36 م', 'sunnah': 'ركعتان بعدها + الوتر'},
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F7FC),
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: const IconThemeData(color: Color(0xFF5B5FEF)),
          title: const Text(
            'مواقيت الصلاة',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Color(0xFF5B5FEF),
            ),
          ),
        ),
        body: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: _prayers.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final p = _prayers[index];
            return Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE6E6F0)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        p['name']!,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                          color: Color(0xFF25263A),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        p['sunnah']!,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: Color(0xFF77798C),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEEEEFF),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      p['time']!,
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Color(0xFF4145C7),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class WirdPage extends StatelessWidget {
  const WirdPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'وِرد | WIRD — الختمة اليومية',
      subtitle: 'نظّم وردك اليومي من القرآن الكريم والأذكار المأثورة',
      items: [
        {
          'title': 'الورد القرآني اليومي (جزء واحد يومياً)',
          'body': 'قراءة ٢٠ صفحة يومياً (٤ صفحات بعد كل صلاة مفروضة) تختم القرآن الكريم كاملاً كل شهر.',
          'badge': 'ختمة شهرية',
        },
        {
          'title': 'ورد الحزب اليومي (نصف جزء)',
          'body': 'قراءة ١٠ صفحات يومياً تختم القرآن الكريم في شهرين بيسر وطمأنينة.',
          'badge': 'ختمة شهرين',
        },
        {
          'title': 'ورد التدبر اليومي (صفحتان)',
          'body': 'قراءة صفحتين يومياً مع التفسير الميسر وتدبر المعاني والعمل بالآيات.',
          'badge': 'تدبر وعمل',
        },
      ],
    );
  }
}

class SahabaPage extends StatelessWidget {
  const SahabaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'قصص الصحابة الكرام',
      subtitle: 'سير ومواقف أصحاب رسول الله ﷺ رضوان الله عليهم',
      items: [
        {
          'title': 'أبو بكر الصديق رضي الله عنه',
          'body': 'الصديق الأكبر، أول من آمن من الرجال، وصاحب النبي ﷺ في الهجرة والغار، وخليفته الأول.',
          'badge': 'العشرة المبشرون',
        },
        {
          'title': 'عمر بن الخطاب رضي الله عنه',
          'body': 'الفاروق الذي فرّق الله به بين الحق والباطل، عُرف بالعدل والقوة في الحق والرحمة بالرعية.',
          'badge': 'العشرة المبشرون',
        },
        {
          'title': 'عثمان بن عفان رضي الله عنه',
          'body': 'ذو النورين، جامع القرآن الكريم على مصحف إمام واحد، ومجهّز جيش العسرة.',
          'badge': 'العشرة المبشرون',
        },
        {
          'title': 'علي بن أبي طالب رضي الله عنه',
          'body': 'أول من أسلم من الصبيان، وباب العلم والشجاعة، وأحد العشرة المبشرين بالجنة.',
          'badge': 'العشرة المبشرون',
        },
      ],
    );
  }
}

class AzkarPage extends StatelessWidget {
  const AzkarPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'موسوعة الأذكار المأثورة',
      subtitle: 'أذكار الصباح والمساء والنوم وبعد الصلاة من الكتاب والسنة',
      items: [
        {
          'title': 'سيد الاستغفار',
          'body': '«اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ».',
          'badge': 'رواه البخاري',
        },
        {
          'title': 'ذكر الصباح والمساء الجامع',
          'body': '«بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ» (ثلاث مرات).',
          'badge': 'صحيح الترمذي',
        },
        {
          'title': 'التسبيح المضاعف',
          'body': '«سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ» (ثلاث مرات).',
          'badge': 'رواه مسلم',
        },
      ],
    );
  }
}

class WuduPage extends StatelessWidget {
  const WuduPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'تعليم الوضوء والصلاة',
      subtitle: 'صفة وضوء وصلاة النبي ﷺ خطوة بخطوة بالأدلة الصحيحة',
      items: [
        {
          'title': '١. النية والبسملة وغسل الكفين',
          'body': 'ينوي الوضوء بقلبه، ثم يقول «بسم الله» ويغسل كفيه ثلاث مرات.',
          'badge': 'الخطوة ١',
        },
        {
          'title': '٢. المضمضة والاستنشاق وغسل الوجه',
          'body': 'يتمضمض ويستنشق ويستنثر ثلاثاً، ثم يغسل وجهه كاملاً من منابت الشعر إلى الذقن ثلاثاً.',
          'badge': 'الخطوة ٢',
        },
        {
          'title': '٣. غسل اليدين إلى المرفقين ومسح الرأس وغسل الرجلين',
          'body': 'يغسل يديه مع المرفقين ثلاثاً، ويمسح رأسه وأذنيه مرة واحدة، ثم يغسل رجليه مع الكعبين ثلاثاً.',
          'badge': 'الخطوة ٣',
        },
        {
          'title': '٤. الذكر بعد الفراغ من الوضوء',
          'body': '«أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ» — فتُفتح له أبواب الجنة الثمانية.',
          'badge': 'رواه مسلم',
        },
      ],
    );
  }
}

class AchievementsPage extends StatelessWidget {
  const AchievementsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'حصاد الأعمال الصالحة',
      subtitle: 'سجل متابعة الأوراد والعبادات اليومية',
      items: [
        {
          'title': 'المواظبة على الصلوات الخمس في وقتها',
          'body': 'أحب الأعمال إلى الله الصلاة على وقتها.',
          'badge': 'فريضة يومية',
        },
        {
          'title': 'أذكار الصباح والمساء وأدبار الصلوات',
          'body': 'حصن المسلم اليومي وذكر الله كثيراً.',
          'badge': 'سنة مؤكدة',
        },
        {
          'title': 'الورد القرآني والتسبيح اليومي',
          'body': 'قراءة الورد اليومي من المصحف وذكر الله بالمسبحة المركزية.',
          'badge': 'ورد مستمر',
        },
      ],
    );
  }
}

class StatisticsPage extends StatelessWidget {
  const StatisticsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'الإحصائيات ومؤشرات المداومة',
      subtitle: 'متابعة التقدم في التسبيح والقرآن والأوراد اليومية',
      items: [
        {
          'title': 'إحصائيات المسبحة المركزية',
          'body': 'يتم حفظ جميع تسبيحاتك وأورادك تلقائياً في قاعدة بيانات SQLite المحلية داخل جهازك.',
          'badge': 'SQLite محلي',
        },
        {
          'title': 'سجل القراءة والاستماع للقرآن الكريم',
          'body': 'متابعة آخر سورة وآية وصلت إليها في المصحف والاستماع الصوتي.',
          'badge': 'متابعة مستمرة',
        },
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'الملف الشخصي',
      subtitle: 'إعدادات حسابك وبياناتك المحفوظة بخصوصية تامة على جهازك',
      items: [
        {
          'title': 'الخصوصية والحفظ المحلي الكامل (Offline 100%)',
          'body': 'جميع بياناتك وأورادك محفوظة محلياً على جهازك دون مشاركة مع أي طرف خارجي.',
          'badge': 'خصوصية كاملة',
        },
      ],
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'تواصل مع المطور',
      subtitle: 'نسعد بملاحظاتكم واقتراحاتكم لتطوير تطبيق «رِفْق | RIFQ»',
      items: [
        {
          'title': 'عن تطبيق «رِفْق | RIFQ»',
          'body': 'تطبيق إسلامي شامل للقرآن الكريم والأذكار والسنة النبوية والفقه الميسر، صُمم ليعمل بكفاءة عالية وبدون إنترنت.',
          'badge': 'صدقة جارية',
        },
      ],
    );
  }
}

class AllahNamesPage extends StatelessWidget {
  const AllahNamesPage({Key? key}) : super(key: key);

  static const List<Map<String, String>> _names = [
    {'name': 'الله', 'meaning': 'الاسم الأعظم الجامع لمعاني الإلهية الحق المتفرد بالعبودية.'},
    {'name': 'الرَّحْمَنُ', 'meaning': 'ذو الرحمة الواسعة التي وسعت كل شيء في الدنيا والآخرة.'},
    {'name': 'الرَّحِيمُ', 'meaning': 'الموصل رحمته الخاصة لعباده المؤمنين.'},
    {'name': 'المَلِكُ', 'meaning': 'المتصرف في ملكه كيف يشاء، له الملك الكامل والتام.'},
    {'name': 'القُدُّوسُ', 'meaning': 'المنزّه عن كل نقص وعيب، الموصوف بصفات الكمال.'},
    {'name': 'السَّلَامُ', 'meaning': 'السالم من كل عيب، ومانح السلام والأمن لعباده.'},
    {'name': 'المُؤْمِنُ', 'meaning': 'المصدّق لرسله بالآيات، والواهب للأمن والطمأنينة.'},
    {'name': 'المُهَيْمِنُ', 'meaning': 'الرقيب الشهيد الحافظ لكل شيء.'},
    {'name': 'العَزِيزُ', 'meaning': 'الغالب القوي الذي لا يُغلب ولا يُمانع.'},
    {'name': 'الجَبَّارُ', 'meaning': 'الذي يجبر الكسير ويغني الفقير، العلي العظيم.'},
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F7FC),
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: const IconThemeData(color: Color(0xFF5B5FEF)),
          title: const Text(
            'أسماء الله الحسنى',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Color(0xFF5B5FEF),
            ),
          ),
        ),
        body: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: _names.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final item = _names[index];
            return Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE6E6F0)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFFEEEEFF),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${index + 1}',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF5B5FEF),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item['name']!,
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: Color(0xFF25263A),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          item['meaning']!,
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 13,
                            color: Color(0xFF77798C),
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 3. شاشات إضافية للأقسام الشرعية والقرآنية (RTL)
// ═══════════════════════════════════════════════════════════════════════════

class HadithPage extends StatelessWidget {
  const HadithPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => const ArbainNawawiyaScreen();
}

class TajweedPage extends StatelessWidget {
  const TajweedPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'أحكام التجويد الميسرة',
      subtitle: 'قواعد تلاوة القرآن الكريم وتصحيح النطق ومخارج الحروف',
      items: [
        {
          'title': 'أحكام النون الساكنة والتنوين',
          'body': 'الإظهار الحلقي، الإدغام بغنة وبغير غنة، الإقلاب، والإخفاء الحقيقي.',
          'badge': '٤ أحكام',
        },
        {
          'title': 'أحكام الميم الساكنة',
          'body': 'الإخفاء الشفوي عند الباء، الإدغام الشفوي عند الميم، والإظهار الشفوي عند باقي الحروف.',
          'badge': '٣ أحكام',
        },
        {
          'title': 'أحكام المدود',
          'body': 'المد الطبيعي (حركتان)، والمد الفرعي بسبب الهمز أو السكون (المتصل والمنفصل واللازم والعارض للسكون).',
          'badge': 'المدود',
        },
      ],
    );
  }
}

class TadabburPage extends StatelessWidget {
  const TadabburPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'آية وفائدة — تدبر القرآن',
      subtitle: 'وقفات تدبرية وفوائد إيمانية من آيات الكتاب العزيز',
      items: [
        {
          'title': '﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾ [الرعد: 28]',
          'body': 'لا شيء أشدّ طمأنينة وسكينة للقلب من دوام ذكر الله تعالى باللسان والقلب والجوارح.',
          'badge': 'سورة الرعد',
        },
        {
          'title': '﴿فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا﴾ [الشرح: 5-6]',
          'body': 'بشارة ربانية عظيمة: لن يغلب عسرٌ يُسرين، ومع كل شدة يخلق الله فرجاً ومخرجاً.',
          'badge': 'سورة الشرح',
        },
      ],
    );
  }
}

class ZakatPage extends StatelessWidget {
  const ZakatPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'الزكاة والمواريث',
      subtitle: 'أحكام وأنصبة الزكاة الشرعية والفرائض من الكتاب والسنة',
      items: [
        {
          'title': 'زكاة المال والذهب والفضة وعروض التجارة',
          'body': 'تجب الزكاة إذا بلغ المال النصاب (ما يعادل ٨٥ غراماً من الذهب الخالص) وحال عليه الحول الهجري، ومقدارها ربع العشر (٢.٥٪).',
          'badge': '٢.٥٪ ربع العشر',
        },
        {
          'title': 'زكاة الفطر',
          'body': 'صاع من طعام عن كل مسلم صغير أو كبير، وتخرج قبل صلاة عيد الفطر تطهيراً للصائم وطعمة للمساكين.',
          'badge': 'فريضة',
        },
      ],
    );
  }
}

class HijriFastingPage extends StatelessWidget {
  const HijriFastingPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'التقويم الهجري وأيام الصيام',
      subtitle: 'مواسم الطاعات وصيام التطوع المأثور عن النبي ﷺ',
      items: [
        {
          'title': 'صيام الأيام البيض من كل شهر هجري',
          'body': 'اليوم الثالث عشر والرابع عشر والخامس عشر من كل شهر هجري — وصيامها كصيام الدهر.',
          'badge': '١٣ و ١٤ و ١٥',
        },
        {
          'title': 'صيام يومي الإثنين والخميس',
          'body': 'تُعرض الأعمال يوم الإثنين والخميس، فكان النبي ﷺ يتحرى صومهما.',
          'badge': 'سنة أسبوعية',
        },
        {
          'title': 'صيام يوم عرفة ويوم عاشوراء',
          'body': 'صيام يوم عرفة يكفّر سنتين (الماضية والباقية)، وصيام يوم عاشوراء يكفّر السنة الماضية.',
          'badge': 'مواسم فاضلة',
        },
      ],
    );
  }
}

class HajjUmrahPage extends StatelessWidget {
  const HajjUmrahPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'دليل الحج والعمرة (المطوّف)',
      subtitle: 'مناسك الحج والعمرة خطوة بخطوة وأدعية الطواف والسعي',
      items: [
        {
          'title': '١. الإحرام من الميقات والتلبية',
          'body': '«لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لَا شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لَا شَرِيكَ لَكَ».',
          'badge': 'ركن الإحرام',
        },
        {
          'title': '٢. الطواف بالبيت العتيق (٧ أشواط)',
          'body': 'يبدأ من الحجر الأسود ويجعل الكعبة عن يساره سبعة أشواط، ثم يصلي ركعتين خلف مقام إبراهيم.',
          'badge': 'ركن الطواف',
        },
        {
          'title': '٣. السعي بين الصفا والمروة (٧ أشواط) والحلق أو التقصير',
          'body': 'يبدأ بالصفا ويختم بالمروة سبعة أشواط، ثم يحلق أو يقصّر شعره وبه تتم العمرة.',
          'badge': 'السعي والتحلل',
        },
      ],
    );
  }
}

class RuqyahPage extends StatelessWidget {
  const RuqyahPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const _RifqContentListPage(
      title: 'الرقية الشرعية والطب النبوي',
      subtitle: 'الرقية الثابتة من القرآن الكريم والسنة النبوية المطهرة',
      items: [
        {
          'title': 'سورة الفاتحة وآية الكرسي والمعوذات',
          'body': 'قراءة سورة الفاتحة، وآية الكرسي [البقرة: 255]، وخواتيم سورة البقرة، وسور الإخلاص والفلق والناس (ثلاث مرات).',
          'badge': 'القرآن الكريم',
        },
        {
          'title': 'رقية النبي ﷺ للمريض',
          'body': '«أَذْهِبِ الْبَاسَ رَبَّ النَّاسِ، اشْفِ وَأَنْتَ الشَّافِي، لَا شِفَاءَ إِلَّا شِفَاؤُكَ، شِفَاءً لَا يُغَادِرُ سَقَمًا».',
          'badge': 'متفق عليه',
        },
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// 4. قوالب المحتوى الموحدة وصفحة ComingSoonPage
// ═══════════════════════════════════════════════════════════════════════════

class _RifqContentListPage extends StatelessWidget {
  final String title;
  final String subtitle;
  final List<Map<String, String>> items;

  const _RifqContentListPage({
    Key? key,
    required this.title,
    required this.subtitle,
    required this.items,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F7FC),
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: const IconThemeData(color: Color(0xFF5B5FEF)),
          title: Text(
            title,
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Color(0xFF5B5FEF),
              fontSize: 18,
            ),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE6E6F0)),
              ),
              child: Text(
                subtitle,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF77798C),
                ),
              ),
            ),
            const SizedBox(height: 14),
            ...items.map(
              (item) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFE6E6F0)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              item['title']!,
                              style: const TextStyle(
                                fontFamily: 'Cairo',
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Color(0xFF25263A),
                              ),
                            ),
                          ),
                          if (item['badge'] != null)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEEEEFF),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                item['badge']!,
                                style: const TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF4145C7),
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        item['body']!,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 14,
                          color: Color(0xFF77798C),
                          height: 1.65,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ComingSoonPage extends StatelessWidget {
  final String title;
  const ComingSoonPage({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F7FC),
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: const IconThemeData(color: Color(0xFF5B5FEF)),
          title: Text(
            title,
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: Color(0xFF5B5FEF),
            ),
          ),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.construction_rounded, size: 80, color: Color(0xFF5B5FEF)),
              const SizedBox(height: 20),
              Text(
                title,
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                  color: Color(0xFF25263A),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'قريباً إن شاء الله',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 16,
                  color: Color(0xFF77798C),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
