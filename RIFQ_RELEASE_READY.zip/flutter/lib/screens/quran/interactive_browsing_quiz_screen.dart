import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// ═══════════════════════════════════════════════════════════════════════════
/// الهوية اللونية الرسمية لتطبيق «رِفْق | RIFQ»
/// ═══════════════════════════════════════════════════════════════════════════
const Color kRifqGold = Color(0xFF5B5FEF);
const Color kRifqGoldLight = Color(0xFFE8B84A);
const Color kRifqBeige = Color(0xFFF7F7FC);
const Color kRifqIvory = Color(0xFFF7F7FC);
const Color kRifqWhite = Color(0xFFFFFFFF);
const Color kRifqBrown = Color(0xFF25263A);
const Color kRifqGrey = Color(0xFF77798C);
const Color kRifqCorrectGreen = Color(0xFF4CAF82);
const Color kRifqWrongRed = Color(0xFFD95C6A);
const Color kRifqDarkIslamicGreen = Color(0xFF4145C7);

/// ═══════════════════════════════════════════════════════════════════════════
/// بنية الجداول الإلزامية (SQLite Schema: quran_ayahs, quran_words & quiz_questions)
/// ═══════════════════════════════════════════════════════════════════════════
class QuranTablesSqlSchema {
  static const String createQuranAyahsTable = '''
    CREATE TABLE IF NOT EXISTS quran_ayahs (
      id TEXT PRIMARY KEY,
      surah_id INTEGER NOT NULL,
      ayah_number INTEGER NOT NULL,
      ayah_text TEXT NOT NULL,
      page_number INTEGER NOT NULL,
      juz_number INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_quran_ayahs_surah ON quran_ayahs(surah_id, ayah_number);
  ''';

  static const String createQuranWordsTable = '''
    CREATE TABLE IF NOT EXISTS quran_words (
      id TEXT PRIMARY KEY,
      surah_id INTEGER NOT NULL,
      ayah_number INTEGER NOT NULL,
      word_index INTEGER NOT NULL,
      word_text TEXT NOT NULL,
      word_text_without_tashkeel TEXT NOT NULL,
      position INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_quran_words_surah_ayah ON quran_words(surah_id, ayah_number, word_index);
  ''';

  static const String createQuizQuestionsTable = '''
    CREATE TABLE IF NOT EXISTS quiz_questions (
      id TEXT PRIMARY KEY,
      surah_id INTEGER NOT NULL,
      surah_name TEXT NOT NULL,
      ayah_number INTEGER NOT NULL,
      page_number INTEGER NOT NULL,
      juz_number INTEGER NOT NULL,
      ayah_text TEXT NOT NULL,
      word_id TEXT NOT NULL,
      word_index INTEGER NOT NULL,
      word_text TEXT NOT NULL,
      word_text_without_tashkeel TEXT NOT NULL,
      difficulty TEXT NOT NULL,
      masked_word_preview TEXT NOT NULL,
      missing_slots_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (word_id) REFERENCES quran_words(id)
    );
    CREATE INDEX IF NOT EXISTS idx_quiz_questions_lookup ON quiz_questions(surah_id, ayah_number, difficulty);
  ''';

  static const String createQuizResultsTable = '''
    CREATE TABLE IF NOT EXISTS quiz_results (
      id TEXT PRIMARY KEY,
      surah_id INTEGER NOT NULL,
      surah_name TEXT NOT NULL,
      from_ayah INTEGER NOT NULL,
      to_ayah INTEGER NOT NULL,
      questions_count INTEGER NOT NULL,
      difficulty TEXT NOT NULL,
      score INTEGER NOT NULL,
      correct_answers INTEGER NOT NULL,
      wrong_answers INTEGER NOT NULL,
      accuracy_percent INTEGER NOT NULL,
      elapsed_seconds INTEGER NOT NULL,
      created_at TEXT NOT NULL
    );
  ''';
}

class QuranAyahEntity {
  final String id;
  final int surahId;
  final int ayahNumber;
  final String ayahText;
  final int pageNumber;
  final int juzNumber;

  const QuranAyahEntity({
    required this.id,
    required this.surahId,
    required this.ayahNumber,
    required this.ayahText,
    required this.pageNumber,
    required this.juzNumber,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'surah_id': surahId,
        'ayah_number': ayahNumber,
        'ayah_text': ayahText,
        'page_number': pageNumber,
        'juz_number': juzNumber,
      };

  factory QuranAyahEntity.fromJson(Map<String, dynamic> json) => QuranAyahEntity(
        id: json['id'] as String,
        surahId: json['surah_id'] as int,
        ayahNumber: json['ayah_number'] as int,
        ayahText: json['ayah_text'] as String,
        pageNumber: json['page_number'] as int? ?? 1,
        juzNumber: json['juz_number'] as int? ?? 1,
      );
}

class QuranWordEntity {
  final String id;
  final int surahId;
  final int ayahNumber;
  final int wordIndex;
  final String wordText;
  final String wordTextWithoutTashkeel;
  final int position;

  const QuranWordEntity({
    required this.id,
    required this.surahId,
    required this.ayahNumber,
    required this.wordIndex,
    required this.wordText,
    required this.wordTextWithoutTashkeel,
    required this.position,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'surah_id': surahId,
        'ayah_number': ayahNumber,
        'word_index': wordIndex,
        'word_text': wordText,
        'word_text_without_tashkeel': wordTextWithoutTashkeel,
        'position': position,
      };

  factory QuranWordEntity.fromJson(Map<String, dynamic> json) => QuranWordEntity(
        id: json['id'] as String,
        surahId: json['surah_id'] as int,
        ayahNumber: json['ayah_number'] as int,
        wordIndex: json['word_index'] as int,
        wordText: json['word_text'] as String,
        wordTextWithoutTashkeel: json['word_text_without_tashkeel'] as String,
        position: json['position'] as int? ?? 1,
      );
}

class LetterClusterEntity {
  final int clusterIndex;
  final String clusterWithTashkeel;
  final String baseLetter;
  final String normalizedLetter;

  const LetterClusterEntity({
    required this.clusterIndex,
    required this.clusterWithTashkeel,
    required this.baseLetter,
    required this.normalizedLetter,
  });
}

class MissingLetterSlotEntity {
  final String slotId;
  final int wordIndex;
  final int clusterIndex;
  final String originalClusterWithTashkeel;
  final String correctBaseLetter;
  final String normalizedCorrectLetter;
  final List<String> options;

  const MissingLetterSlotEntity({
    required this.slotId,
    required this.wordIndex,
    required this.clusterIndex,
    required this.originalClusterWithTashkeel,
    required this.correctBaseLetter,
    required this.normalizedCorrectLetter,
    required this.options,
  });
}

class InteractiveQuestionEntity {
  final int questionIndex;
  final int surahId;
  final String surahName;
  final int ayahNumber;
  final int pageNumber;
  final int juzNumber;
  final String ayahText;
  final List<QuranWordEntity> words;
  final Map<int, List<LetterClusterEntity>> wordClustersMap;
  final List<MissingLetterSlotEntity> missingSlots;

  const InteractiveQuestionEntity({
    required this.questionIndex,
    required this.surahId,
    required this.surahName,
    required this.ayahNumber,
    required this.pageNumber,
    required this.juzNumber,
    required this.ayahText,
    required this.words,
    required this.wordClustersMap,
    required this.missingSlots,
  });
}

/// ═══════════════════════════════════════════════════════════════════════════
/// معالج النصوص العثمانية وتقطيع الكلمات والحروف بدقة 100%
/// ═══════════════════════════════════════════════════════════════════════════
class QuranUthmaniTokenizer {
  static final RegExp _pauseSymbols = RegExp(r'^[\u06D6-\u06ED\u06DD\u06DE\u06E9]+$');

  static String stripTashkeel(String input) {
    return input
        .replaceAll('\u0671', 'ا')
        .replaceAll('\u0670', '')
        .replaceAll(RegExp(r'[\u0610-\u061A\u064B-\u065F\u06D6-\u06ED\u0640\u06DD\u06DE\u06E9]'), '')
        .replaceAll(RegExp(r'[^\u0621-\u063A\u0641-\u064A]'), '')
        .trim();
  }

  static List<QuranWordEntity> tokenizeAyah(int surahId, int ayahNumber, String ayahText) {
    final rawTokens = ayahText.trim().split(RegExp(r'\s+'));
    final List<QuranWordEntity> words = [];
    int wordIdx = 0;

    for (final token in rawTokens) {
      if (token.isEmpty || _pauseSymbols.hasMatch(token)) continue;
      final cleaned = token
          .replaceAll(RegExp(r'^[\u06D6-\u06ED\u06DD\u06DE\u06E9﴿﴾]+'), '')
          .replaceAll(RegExp(r'[\u06D6-\u06ED\u06DD\u06DE\u06E9﴿﴾]+$'), '')
          .trim();
      if (cleaned.isEmpty) continue;
      final withoutTashkeel = stripTashkeel(cleaned);
      if (withoutTashkeel.isEmpty) continue;

      words.add(
        QuranWordEntity(
          id: '${surahId}_${ayahNumber}_$wordIdx',
          surahId: surahId,
          ayahNumber: ayahNumber,
          wordIndex: wordIdx,
          wordText: cleaned,
          wordTextWithoutTashkeel: withoutTashkeel,
          position: wordIdx + 1,
        ),
      );
      wordIdx++;
    }
    return words;
  }

  static bool _isBaseArabicLetter(int codeUnit) {
    return (codeUnit >= 0x0621 && codeUnit <= 0x063A) ||
        (codeUnit >= 0x0641 && codeUnit <= 0x064A) ||
        codeUnit == 0x0671;
  }

  static List<LetterClusterEntity> splitWordIntoClusters(String wordText) {
    final List<LetterClusterEntity> clusters = [];
    String currentCluster = '';
    String currentBase = '';

    for (int i = 0; i < wordText.length; i++) {
      final ch = wordText[i];
      final code = wordText.codeUnitAt(i);
      if (code >= 0x06D6 && code <= 0x06ED && code != 0x06E5 && code != 0x06E6) {
        continue;
      }
      if (_isBaseArabicLetter(code)) {
        if (currentBase.isNotEmpty) {
          final displayBase = currentBase == '\u0671' ? 'ا' : currentBase;
          clusters.add(
            LetterClusterEntity(
              clusterIndex: clusters.length,
              clusterWithTashkeel: currentCluster,
              baseLetter: displayBase,
              normalizedLetter: stripTashkeel(displayBase),
            ),
          );
        }
        currentBase = ch;
        currentCluster = ch;
      } else if (currentBase.isNotEmpty) {
        currentCluster += ch;
      }
    }

    if (currentBase.isNotEmpty) {
      final displayBase = currentBase == '\u0671' ? 'ا' : currentBase;
      clusters.add(
        LetterClusterEntity(
          clusterIndex: clusters.length,
          clusterWithTashkeel: currentCluster,
          baseLetter: displayBase,
          normalizedLetter: stripTashkeel(displayBase),
        ),
      );
    }
    return clusters;
  }
}

/// ═══════════════════════════════════════════════════════════════════════════
/// أيقونة SVG مرسومة بدقة (بدون إيموجي)
/// ═══════════════════════════════════════════════════════════════════════════
class InteractiveMushafSvgIcon extends StatelessWidget {
  final double size;
  final Color color;

  const InteractiveMushafSvgIcon({
    Key? key,
    this.size = 24,
    this.color = kRifqGold,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size),
      painter: _InteractiveMushafPainter(color),
    );
  }
}

class _InteractiveMushafPainter extends CustomPainter {
  final Color color;
  _InteractiveMushafPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.08
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fill = Paint()
      ..color = color.withOpacity(0.12)
      ..style = PaintingStyle.fill;

    final rect = RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width * 0.12, size.height * 0.18, size.width * 0.76, size.height * 0.64),
      Radius.circular(size.width * 0.12),
    );
    canvas.drawRRect(rect, fill);
    canvas.drawRRect(rect, stroke);

    canvas.drawLine(
      Offset(size.width * 0.5, size.height * 0.18),
      Offset(size.width * 0.5, size.height * 0.82),
      stroke,
    );
  }

  @override
  bool shouldRepaint(covariant _InteractiveMushafPainter oldDelegate) =>
      oldDelegate.color != color;
}

/// ═══════════════════════════════════════════════════════════════════════════
/// شاشة «التصفح التفاعلي» الكاملة (الإعداد + الاختبار + النتيجة)
/// ═══════════════════════════════════════════════════════════════════════════
class InteractiveBrowsingQuizScreen extends StatefulWidget {
  final int initialSurahId;

  const InteractiveBrowsingQuizScreen({
    Key? key,
    this.initialSurahId = 67,
  }) : super(key: key);

  @override
  State<InteractiveBrowsingQuizScreen> createState() => _InteractiveBrowsingQuizScreenState();
}

class _InteractiveBrowsingQuizScreenState extends State<InteractiveBrowsingQuizScreen> {
  // 0: Setup, 1: Testing, 2: Result
  int _screenStep = 0;

  int _selectedSurahId = 67;
  int _fromAyah = 1;
  int _toAyah = 20;
  int _questionsCount = 10;
  String _difficulty = 'easy'; // easy | medium | hard
  double _fontSize = 26.0;
  bool _showTashkeel = true;
  bool _isLoading = false;

  List<InteractiveQuestionEntity> _questions = [];
  int _currentQIdx = 0;
  int _activeSlotIdx = 0;
  final Map<String, String> _filledSlots = {};
  String? _wrongTappedLetter;
  int _correctCount = 0;
  int _wrongCount = 0;
  int _elapsedSeconds = 0;
  Timer? _timer;

  static const List<Map<String, dynamic>> _surahMetaList = [
    {'id': 1, 'name': 'الفاتحة', 'ayahs': 7},
    {'id': 2, 'name': 'البقرة', 'ayahs': 286},
    {'id': 18, 'name': 'الكهف', 'ayahs': 110},
    {'id': 36, 'name': 'يس', 'ayahs': 83},
    {'id': 55, 'name': 'الرحمن', 'ayahs': 78},
    {'id': 56, 'name': 'الواقعة', 'ayahs': 96},
    {'id': 67, 'name': 'الملك', 'ayahs': 30},
    {'id': 78, 'name': 'النبأ', 'ayahs': 40},
    {'id': 112, 'name': 'الإخلاص', 'ayahs': 4},
    {'id': 113, 'name': 'الفلق', 'ayahs': 5},
    {'id': 114, 'name': 'الناس', 'ayahs': 6},
  ];

  @override
  void initState() {
    super.initState();
    _selectedSurahId = widget.initialSurahId;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<List<QuranAyahEntity>> _fetchAndCacheSurahUthmani(int surahId) async {
    final prefs = await SharedPreferences.getInstance();
    final cacheKey = 'sqlite_quran_ayahs_surah_$surahId';
    final cached = prefs.getString(cacheKey);
    if (cached != null && cached.isNotEmpty) {
      final List<dynamic> decoded = jsonDecode(cached);
      return decoded.map((e) => QuranAyahEntity.fromJson(e as Map<String, dynamic>)).toList();
    }

    final uri = Uri.parse('https://api.alquran.cloud/v1/surah/$surahId/quran-uthmani');
    final response = await http.get(uri);
    if (response.statusCode == 200) {
      final body = jsonDecode(response.body);
      final List<dynamic> rawAyahs = body['data']['ayahs'] as List<dynamic>;
      final List<QuranAyahEntity> result = [];
      for (int i = 0; i < rawAyahs.length; i++) {
        final item = rawAyahs[i] as Map<String, dynamic>;
        String text = (item['text'] as String? ?? '').trim();
        if (surahId != 1 &&
            surahId != 9 &&
            i == 0 &&
            text.startsWith('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ')) {
          text = text.replaceFirst('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', '').trim();
        }
        result.add(
          QuranAyahEntity(
            id: '${surahId}_${item['numberInSurah']}',
            surahId: surahId,
            ayahNumber: item['numberInSurah'] as int? ?? (i + 1),
            ayahText: text,
            pageNumber: item['page'] as int? ?? 1,
            juzNumber: item['juz'] as int? ?? 1,
          ),
        );
      }
      await prefs.setString(cacheKey, jsonEncode(result.map((e) => e.toJson()).toList()));
      return result;
    }
    throw Exception('Failed to load quran-uthmani');
  }

  List<String> _buildLetterOptions(String correctLetter, int count) {
    const allLetters = [
      'ا', 'أ', 'إ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
      'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م',
      'ن', 'ه', 'و', 'ي', 'ة', 'ى'
    ];
    final Set<String> opts = {correctLetter};
    final rnd = Random();
    while (opts.length < count) {
      opts.add(allLetters[rnd.nextInt(allLetters.length)]);
    }
    final list = opts.toList()..shuffle(rnd);
    return list;
  }

  Future<void> _startInteractiveQuiz() async {
    setState(() => _isLoading = true);
    try {
      final ayahs = await _fetchAndCacheSurahUthmani(_selectedSurahId);
      final filtered = ayahs
          .where((a) => a.ayahNumber >= _fromAyah && a.ayahNumber <= _toAyah)
          .toList();
      final sourceAyahs = filtered.isNotEmpty ? filtered : ayahs;

      final List<InteractiveQuestionEntity> generated = [];
      final int optionsCount = _difficulty == 'easy' ? 4 : _difficulty == 'medium' ? 6 : 8;

      for (int q = 0; q < _questionsCount; q++) {
        final ayah = sourceAyahs[q % sourceAyahs.length];
        final words = QuranUthmaniTokenizer.tokenizeAyah(_selectedSurahId, ayah.ayahNumber, ayah.ayahText);
        final Map<int, List<LetterClusterEntity>> clusterMap = {};
        for (final w in words) {
          clusterMap[w.wordIndex] = QuranUthmaniTokenizer.splitWordIntoClusters(w.wordText);
        }

        final targetWord = words[(q + ayah.ayahNumber) % words.length];
        final targetClusters = clusterMap[targetWord.wordIndex] ?? [];
        final List<MissingLetterSlotEntity> slots = [];

        if (targetClusters.isNotEmpty) {
          final targetCluster = targetClusters.last;
          slots.add(
            MissingLetterSlotEntity(
              slotId: '${targetWord.wordIndex}_${targetCluster.clusterIndex}',
              wordIndex: targetWord.wordIndex,
              clusterIndex: targetCluster.clusterIndex,
              originalClusterWithTashkeel: targetCluster.clusterWithTashkeel,
              correctBaseLetter: targetCluster.baseLetter,
              normalizedCorrectLetter: targetCluster.normalizedLetter,
              options: _buildLetterOptions(targetCluster.baseLetter, optionsCount),
            ),
          );
        }

        generated.add(
          InteractiveQuestionEntity(
            questionIndex: q,
            surahId: _selectedSurahId,
            surahName: 'السورة $_selectedSurahId',
            ayahNumber: ayah.ayahNumber,
            pageNumber: ayah.pageNumber,
            juzNumber: ayah.juzNumber,
            ayahText: ayah.ayahText,
            words: words,
            wordClustersMap: clusterMap,
            missingSlots: slots,
          ),
        );
      }

      _timer?.cancel();
      _elapsedSeconds = 0;
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted && _screenStep == 1) {
          setState(() => _elapsedSeconds++);
        }
      });

      setState(() {
        _questions = generated;
        _currentQIdx = 0;
        _activeSlotIdx = 0;
        _filledSlots.clear();
        _wrongTappedLetter = null;
        _correctCount = 0;
        _wrongCount = 0;
        _isLoading = false;
        _screenStep = 1;
      });
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  void _onTapLetter(String letter) {
    final q = _questions[_currentQIdx];
    final slot = q.missingSlots[_activeSlotIdx];
    final isMatch = QuranUthmaniTokenizer.stripTashkeel(letter) == slot.normalizedCorrectLetter ||
        letter == slot.correctBaseLetter;

    if (isMatch) {
      HapticFeedback.lightImpact();
      setState(() {
        _filledSlots[slot.slotId] = slot.originalClusterWithTashkeel;
        _wrongTappedLetter = null;
        _correctCount++;
      });

      if (_activeSlotIdx < q.missingSlots.length - 1) {
        setState(() => _activeSlotIdx++);
      } else {
        Future.delayed(const Duration(milliseconds: 750), () {
          if (!mounted) return;
          if (_currentQIdx < _questions.length - 1) {
            setState(() {
              _currentQIdx++;
              _activeSlotIdx = 0;
              _filledSlots.clear();
              _wrongTappedLetter = null;
            });
          } else {
            _timer?.cancel();
            setState(() => _screenStep = 2);
          }
        });
      }
    } else {
      HapticFeedback.heavyImpact();
      setState(() {
        _wrongTappedLetter = letter;
        _wrongCount++;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: kRifqBeige,
        appBar: AppBar(
          backgroundColor: kRifqWhite,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: kRifqBrown, size: 20),
            onPressed: () {
              if (_screenStep != 0) {
                setState(() => _screenStep = 0);
              } else {
                Navigator.pop(context);
              }
            },
          ),
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              InteractiveMushafSvgIcon(size: 22, color: kRifqGold),
              SizedBox(width: 8),
              Text(
                'التصفح التفاعلي',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  color: kRifqBrown,
                ),
              ),
            ],
          ),
          centerTitle: true,
        ),
        body: _screenStep == 0
            ? _buildSetupScreen()
            : _screenStep == 1
                ? _buildTestingScreen()
                : _buildResultScreen(),
      ),
    );
  }

  Widget _buildSetupScreen() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: kRifqWhite,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: kRifqGold.withOpacity(0.45), width: 1.5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '1. اختيار السورة:',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: kRifqBrown),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<int>(
                value: _selectedSurahId,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: kRifqIvory,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: kRifqGold),
                  ),
                ),
                items: _surahMetaList
                    .map(
                      (s) => DropdownMenuItem<int>(
                        value: s['id'] as int,
                        child: Text('سورة ${s['name']} (${s['ayahs']} آية)'),
                      ),
                    )
                    .toList(),
                onChanged: (val) {
                  if (val != null) {
                    setState(() => _selectedSurahId = val);
                  }
                },
              ),
              const SizedBox(height: 16),
              const Text(
                '2. عدد الأسئلة:',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: kRifqBrown),
              ),
              const SizedBox(height: 8),
              Row(
                children: [5, 10, 15, 20].map((cnt) {
                  final active = _questionsCount == cnt;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ElevatedButton(
                        onPressed: () => setState(() => _questionsCount = cnt),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: active ? kRifqGold : kRifqIvory,
                          foregroundColor: active ? kRifqWhite : kRifqBrown,
                          elevation: 0,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        child: Text('$cnt', style: const TextStyle(fontWeight: FontWeight.w900)),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _startInteractiveQuiz,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kRifqGold,
                    foregroundColor: kRifqWhite,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: Text(
                    _isLoading ? 'جاري التحميل من المصحف...' : 'بدء اختبار التصفح التفاعلي',
                    style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTestingScreen() {
    final q = _questions[_currentQIdx];
    final slot = q.missingSlots[_activeSlotIdx];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: kRifqIvory,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kRifqGold, width: 1.8),
          ),
          child: Wrap(
            alignment: WrapAlignment.center,
            spacing: 6,
            runSpacing: 12,
            children: q.words.map((w) {
              final clusters = q.wordClustersMap[w.wordIndex] ?? [];
              final wordSlots = q.missingSlots.where((s) => s.wordIndex == w.wordIndex).toList();
              if (wordSlots.isEmpty) {
                return Text(
                  _showTashkeel ? w.wordText : w.wordTextWithoutTashkeel,
                  style: TextStyle(
                    fontFamily: 'Amiri',
                    fontSize: _fontSize,
                    color: kRifqBrown,
                  ),
                );
              }

              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: kRifqWhite,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kRifqGold),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: clusters.map((c) {
                    final matchedSlot =
                        wordSlots.where((s) => s.clusterIndex == c.clusterIndex).toList();
                    if (matchedSlot.isEmpty) {
                      return Text(
                        c.clusterWithTashkeel,
                        style: TextStyle(fontFamily: 'Amiri', fontSize: _fontSize, color: kRifqBrown),
                      );
                    }
                    final s = matchedSlot.first;
                    final filled = _filledSlots[s.slotId];
                    if (filled != null) {
                      return Text(
                        filled,
                        style: TextStyle(
                          fontFamily: 'Amiri',
                          fontSize: _fontSize,
                          color: kRifqCorrectGreen,
                          fontWeight: FontWeight.bold,
                        ),
                      );
                    }
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: kRifqGold.withOpacity(0.18),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: kRifqGold),
                      ),
                      child: const Text('؟', style: TextStyle(fontWeight: FontWeight.w900)),
                    );
                  }).toList(),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 18),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: slot.options.map((letter) {
            final isWrong = _wrongTappedLetter == letter;
            return SizedBox(
              width: (MediaQuery.of(context).size.width - 52) / 2,
              child: ElevatedButton(
                onPressed: () => _onTapLetter(letter),
                style: ElevatedButton.styleFrom(
                  backgroundColor: isWrong ? kRifqWrongRed : kRifqWhite,
                  foregroundColor: isWrong ? kRifqWhite : kRifqBrown,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: const BorderSide(color: kRifqGold),
                  ),
                ),
                child: Text(
                  letter,
                  style: const TextStyle(fontFamily: 'Amiri', fontSize: 24, fontWeight: FontWeight.bold),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildResultScreen() {
    final total = max(1, _correctCount + _wrongCount);
    final accuracy = ((_correctCount / total) * 100).round();

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: kRifqWhite,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kRifqGold, width: 1.5),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'نتيجة التصفح التفاعلي',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: kRifqBrown),
              ),
              const SizedBox(height: 12),
              Text(
                'الدقة: $accuracy% • إجابات صحيحة: $_correctCount • أخطاء: $_wrongCount',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: kRifqGrey),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () => setState(() => _screenStep = 0),
                style: ElevatedButton.styleFrom(
                  backgroundColor: kRifqGold,
                  foregroundColor: kRifqWhite,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text('اختبار جديد', style: TextStyle(fontWeight: FontWeight.w900)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
