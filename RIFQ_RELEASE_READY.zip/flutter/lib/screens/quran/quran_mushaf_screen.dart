import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/quran_api_service.dart';
import '../../services/quran_database_helper.dart';
import 'interactive_browsing_quiz_screen.dart';

class QuranMushafScreen extends StatefulWidget {
  final int surahNumber;
  final String surahName;
  final int juzNumber;
  final int totalVerses;
  final String revelationType;

  const QuranMushafScreen({
    Key? key,
    required this.surahNumber,
    required this.surahName,
    required this.juzNumber,
    required this.totalVerses,
    required this.revelationType,
  }) : super(key: key);

  @override
  State<QuranMushafScreen> createState() => _QuranMushafScreenState();
}

class _QuranMushafScreenState extends State<QuranMushafScreen> {
  List<Map<String, dynamic>> _verses = [];
  bool _isLoading = true;
  double _fontSize = 26.0;
  bool _isDarkMode = false;
  bool _isHideMode = false;
  final Map<int, bool> _revealedAyahs = {};
  int _activeTab = 0; // 0: المصحف, 1: التفسير, 2: الترجمة
  String _selectedTafseer = 'muyassar';

  @override
  void initState() {
    super.initState();
    _loadSurah();
  }

  Future<void> _loadSurah() async {
    setState(() => _isLoading = true);
    final verses = await QuranApiService.getSurahVerses(widget.surahNumber);
    if (mounted) {
      setState(() {
        _verses = verses;
        _isLoading = false;
      });
      // Save last read position
      QuranDatabaseHelper.instance.saveLastReadPosition(widget.surahNumber, 1);
    }
  }

  void _showAyahBottomSheet(Map<String, dynamic> ayah) {
    showModalBottomSheet(
      context: context,
      backgroundColor: _isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'سورة ${widget.surahName} — الآية ${ayah['numberInSurah']}',
                      style: const TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF5B5FEF),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7F7FC),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    '﴿ ${ayah['text']} ﴾',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontFamily: 'Amiri',
                      fontSize: 18,
                      color: Color(0xFF25263A),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildActionButton(Icons.copy, 'نسخ', () {
                      Clipboard.setData(ClipboardData(
                        text: '﴿ ${ayah['text']} ﴾ [سورة ${widget.surahName}: ${ayah['numberInSurah']}]',
                      ));
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم نسخ الآية الكريمة 📋')),
                      );
                    }),
                    _buildActionButton(Icons.bookmark, 'إشارة', () {
                      QuranDatabaseHelper.instance.toggleBookmark(
                        widget.surahNumber,
                        ayah['numberInSurah'],
                      );
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم حفظ الإشارة المرجعية 🔖')),
                      );
                    }),
                    _buildActionButton(Icons.menu_book, 'التفسير', () {
                      Navigator.pop(ctx);
                      _showTafseerDialog(ayah);
                    }),
                  ],
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildActionButton(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 75,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF5B5FEF).withOpacity(0.12),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF5B5FEF).withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFF5B5FEF), size: 22),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  void _showTafseerDialog(Map<String, dynamic> ayah) async {
    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          return FutureBuilder<String>(
            future: QuranApiService.getTafseerText(
              widget.surahNumber,
              ayah['numberInSurah'],
              _selectedTafseer,
            ),
            builder: (context, snapshot) {
              return Directionality(
                textDirection: TextDirection.rtl,
                child: AlertDialog(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  title: Row(
                    children: [
                      const Icon(Icons.book, color: Color(0xFF5B5FEF)),
                      const SizedBox(width: 8),
                      Text('تفسير الآية ${ayah['numberInSurah']}'),
                    ],
                  ),
                  content: snapshot.connectionState == ConnectionState.waiting
                      ? const SizedBox(
                          height: 100,
                          child: Center(
                            child: CircularProgressIndicator(color: Color(0xFF5B5FEF)),
                          ),
                        )
                      : SingleChildScrollView(
                          child: Text(
                            snapshot.data ?? 'غير متوفر',
                            style: const TextStyle(fontSize: 15, height: 1.6),
                          ),
                        ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('إغلاق', style: TextStyle(color: Color(0xFF5B5FEF))),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _showSettingsDialog() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          return Directionality(
            textDirection: TextDirection.rtl,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'إعدادات المصحف',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF5B5FEF)),
                  ),
                  const SizedBox(height: 16),
                  Text('حجم الخط: ${_fontSize.toInt()}px'),
                  Slider(
                    min: 20,
                    max: 36,
                    value: _fontSize,
                    activeColor: const Color(0xFF5B5FEF),
                    onChanged: (val) {
                      setSheetState(() => _fontSize = val);
                      setState(() => _fontSize = val);
                    },
                  ),
                  const SizedBox(height: 10),
                  SwitchListTile(
                    title: const Text('الوضع الليلي'),
                    value: _isDarkMode,
                    activeColor: const Color(0xFF5B5FEF),
                    onChanged: (val) {
                      setSheetState(() => _isDarkMode = val);
                      setState(() => _isDarkMode = val);
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = _isDarkMode ? const Color(0xFF121212) : const Color(0xFFF7F7FC);
    final textColor = _isDarkMode ? const Color(0xFFE6E6F0) : const Color(0xFF25263A);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: _isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
          elevation: 0,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(color: const Color(0xFF5B5FEF).withOpacity(0.3), height: 1),
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Color(0xFF5B5FEF)),
            onPressed: () => Navigator.pop(context),
          ),
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildTabButton('المصحف', 0),
              const SizedBox(width: 6),
              _buildTabButton('التفسير', 1),
              const SizedBox(width: 6),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const InteractiveBrowsingQuizScreen(),
                    ),
                  );
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF5B5FEF).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFF5B5FEF)),
                  ),
                  child: const Text(
                    'اختبر حفظك',
                    style: TextStyle(
                      color: Color(0xFF5B5FEF),
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ],
          ),
          centerTitle: true,
          actions: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF5B5FEF).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF5B5FEF).withOpacity(0.4)),
                ),
                child: Center(
                  child: Text(
                    'الجزء ${widget.juzNumber}',
                    style: const TextStyle(
                      color: Color(0xFF5B5FEF),
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(color: Color(0xFF5B5FEF)))
            : SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: _isDarkMode ? const Color(0xFF1A1A1A) : Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF5B5FEF), width: 2),
                  ),
                  child: Column(
                    children: [
                      // Ornate Surah Header
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                        decoration: BoxDecoration(
                          color: _isDarkMode ? const Color(0xFF222222) : Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFF5B5FEF), width: 3),
                        ),
                        child: Text(
                          '❁ ❁ سُورَةُ ${widget.surahName} ❁ ❁',
                          style: const TextStyle(
                            fontFamily: 'Amiri',
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF5B5FEF),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${widget.revelationType == 'Meccan' ? 'مكية' : 'مدنية'} • ${widget.totalVerses} آيات',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      const SizedBox(height: 16),

                      // Bismillah
                      if (widget.surahNumber != 1 && widget.surahNumber != 9) ...[
                        Text(
                          'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                          style: TextStyle(
                            fontFamily: 'Amiri',
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: textColor,
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],

                      // Continuous Mushaf Paragraph
                      RichText(
                        textAlign: TextAlign.justify,
                        text: TextSpan(
                          children: _verses.map((ayah) {
                            final ayahNum = ayah['numberInSurah'] as int;
                            final isMasked = _isHideMode && !(_revealedAyahs[ayahNum] ?? false);

                            return TextSpan(
                              text: isMasked ? '•••••••• ' : '${ayah['text']} ',
                              style: TextStyle(
                                fontFamily: 'Amiri',
                                fontSize: _fontSize,
                                height: 2.2,
                                color: textColor,
                              ),
                              children: [
                                WidgetSpan(
                                  alignment: PlaceholderAlignment.middle,
                                  child: GestureDetector(
                                    onTap: () {
                                      if (_isHideMode) {
                                        setState(() {
                                          _revealedAyahs[ayahNum] = !(_revealedAyahs[ayahNum] ?? false);
                                        });
                                      } else {
                                        _showAyahBottomSheet(ayah);
                                      }
                                    },
                                    child: Container(
                                      margin: const EdgeInsets.symmetric(horizontal: 4),
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: const Color(0xFF5B5FEF), width: 1.5),
                                      ),
                                      child: Text(
                                        '﴿$ayahNum﴾',
                                        style: const TextStyle(
                                          color: Color(0xFF5B5FEF),
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
        bottomNavigationBar: Container(
          height: 65,
          decoration: BoxDecoration(
            color: _isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
            border: Border(
              top: BorderSide(color: const Color(0xFF5B5FEF).withOpacity(0.3)),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(
                icon: const Icon(Icons.settings, color: Color(0xFF5B5FEF)),
                onPressed: _showSettingsDialog,
                tooltip: 'الإعدادات',
              ),
              IconButton(
                icon: const Icon(Icons.bookmark_border, color: Color(0xFF5B5FEF)),
                onPressed: () {
                  QuranDatabaseHelper.instance.toggleBookmark(widget.surahNumber, 1);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تم حفظ الصفحة الحالية 🔖')),
                  );
                },
                tooltip: 'حفظ الموضع',
              ),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isHideMode ? const Color(0xFF5B5FEF) : const Color(0xFFF7F7FC),
                  foregroundColor: _isHideMode ? Colors.white : const Color(0xFF25263A),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  elevation: 0,
                ),
                onPressed: () => setState(() => _isHideMode = !_isHideMode),
                icon: Icon(_isHideMode ? Icons.visibility : Icons.visibility_off, size: 16),
                label: const Text('وضع الإخفاء', style: TextStyle(fontSize: 12)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF5B5FEF).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'حزب ${(widget.juzNumber - 1) * 2 + 1}',
                  style: const TextStyle(color: Color(0xFF5B5FEF), fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabButton(String label, int index) {
    final isActive = _activeTab == index;
    return GestureDetector(
      onTap: () => setState(() => _activeTab = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFF5B5FEF) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isActive ? Colors.white : Colors.grey,
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}
