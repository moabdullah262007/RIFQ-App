import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// أيقونات وعناصر SVG حقيقية 100% لقسم «غراس الجنة» في Flutter (بدون أي إيموجي)
/// ══════════════════════════════════════════════════════════════════════════

class GhirasSvgWidgets {
  /// أيقونة القسم الرسمية: نخلة + شجرة (SVG ذهبي / أخضر)
  static Widget palmAndTreeIcon({double size = 26}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="22" cy="14" r="6.5" fill="#4CAF82" fill-opacity="0.45" stroke="#4CAF82" stroke-width="1.6"/>
          <path d="M22 20V27" stroke="#77798C" stroke-width="2.2" stroke-linecap="round"/>
          <path d="M12 27C12 21 13 15 13.5 10" stroke="#5B5FEF" stroke-width="2.6" stroke-linecap="round"/>
          <path d="M13.5 10C9 9 5.5 11.5 4.5 14.5C7.5 13 10.5 12 13.5 10Z" fill="#4CAF82"/>
          <path d="M13.5 10C18 9 21.5 11.5 22.5 14.5C19.5 13 16.5 12 13.5 10Z" fill="#4CAF82"/>
          <path d="M13.5 10C10.5 6 6.5 6 4.5 8C8 8.5 11 9 13.5 10Z" fill="#4CAF82"/>
          <path d="M13.5 10C16.5 6 20.5 6 22.5 8C19 8.5 16 9 13.5 10Z" fill="#4CAF82"/>
          <circle cx="12" cy="12" r="1.4" fill="#E8B84A"/>
          <circle cx="15" cy="12" r="1.4" fill="#E8B84A"/>
          <path d="M4 27H28" stroke="#5B5FEF" stroke-width="2" stroke-linecap="round"/>
        </svg>
        ''',
        width: size,
        height: size,
      );

  /// 6 مستويات لنمو النباتات (0: بذرة، 1: برعم، 2: شتلة، 3: شجرة صغيرة، 4: شجرة كبيرة، 5: شجرة مزهرة)
  static Widget plantByLevel(int level, {double size = 50}) {
    String content = '';
    if (level <= 0) {
      content = '''
        <ellipse cx="32" cy="52" rx="7" ry="5" fill="#E8B84A" stroke="#25263A" stroke-width="1.5"/>
        <path d="M32 47C32 43 34 41 36 40" stroke="#4CAF82" stroke-width="2.2" stroke-linecap="round"/>
      ''';
    } else if (level == 1) {
      content = '''
        <path d="M32 56V38" stroke="#4CAF82" stroke-width="3" stroke-linecap="round"/>
        <path d="M32 44C25 44 21 39 21 33C27 33 32 38 32 44Z" fill="#4CAF82" stroke="#4CAF82" stroke-width="1.5"/>
        <path d="M32 41C39 41 43 36 43 30C37 30 32 35 32 41Z" fill="#4CAF82"/>
      ''';
    } else if (level == 2) {
      content = '''
        <path d="M32 56V28" stroke="#4CAF82" stroke-width="3.5" stroke-linecap="round"/>
        <path d="M32 47C23 47 18 41 18 34C25 34 32 40 32 47Z" fill="#4CAF82"/>
        <path d="M32 43C41 43 46 37 46 30C39 30 32 36 32 43Z" fill="#4CAF82"/>
        <circle cx="32" cy="24" r="3" fill="#E8B84A"/>
      ''';
    } else if (level == 3) {
      content = '''
        <path d="M30 56L31 34H33L34 56H30Z" fill="#77798C"/>
        <circle cx="32" cy="28" r="13" fill="#4CAF82"/>
        <circle cx="24" cy="32" r="9" fill="#4CAF82"/>
        <circle cx="40" cy="32" r="9" fill="#4CAF82"/>
      ''';
    } else if (level == 4) {
      content = '''
        <path d="M28 56L30 30H34L36 56H28Z" fill="#77798C"/>
        <circle cx="32" cy="24" r="16" fill="#4CAF82"/>
        <circle cx="20" cy="30" r="11" fill="#4CAF82"/>
        <circle cx="44" cy="30" r="11" fill="#4CAF82"/>
        <circle cx="26" cy="20" r="10" fill="#4CAF82"/>
        <circle cx="38" cy="22" r="9" fill="#4CAF82"/>
      ''';
    } else {
      content = '''
        <path d="M27 56L29.5 28H34.5L37 56H27Z" fill="#77798C"/>
        <circle cx="32" cy="23" r="17" fill="#4CAF82"/>
        <circle cx="19" cy="29" r="11.5" fill="#4CAF82"/>
        <circle cx="45" cy="29" r="11.5" fill="#4CAF82"/>
        <circle cx="24" cy="22" r="3.2" fill="#FFFFFF" stroke="#E8B84A" stroke-width="1.5"/>
        <circle cx="40" cy="22" r="3.2" fill="#FFFFFF" stroke="#E8B84A" stroke-width="1.5"/>
        <circle cx="32" cy="14" r="3.2" fill="#E8B84A"/>
      ''';
    }

    return SvgPicture.string(
      '''
      <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="32" cy="57" rx="16" ry="4" fill="#77798C" fill-opacity="0.65"/>
        $content
      </svg>
      ''',
      width: size,
      height: size,
    );
  }

  /// نافورة ومجرى الماء في الحديقة (SVG)
  static Widget fountain({double size = 64}) => SvgPicture.string(
        '''
        <svg viewBox="0 0 100 78" fill="none" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="50" cy="64" rx="40" ry="10" fill="#5B5FEF" fill-opacity="0.35" stroke="#5B5FEF" stroke-width="2"/>
          <ellipse cx="50" cy="62" rx="34" ry="7" fill="#72B7E8" fill-opacity="0.85"/>
          <path d="M44 62V38H56V62" fill="#E8B84A" stroke="#25263A" stroke-width="1.4"/>
          <ellipse cx="50" cy="38" rx="18" ry="5" fill="#FFFFFF" stroke="#5B5FEF" stroke-width="1.8"/>
          <path d="M50 35C42 20 30 26 26 58" stroke="#72B7E8" stroke-width="2.5" stroke-linecap="round"/>
          <path d="M50 35C58 20 70 26 74 58" stroke="#72B7E8" stroke-width="2.5" stroke-linecap="round"/>
          <path d="M50 35V16" stroke="#72B7E8" stroke-width="2.8" stroke-linecap="round"/>
          <circle cx="50" cy="13" r="3" fill="#72B7E8"/>
        </svg>
        ''',
        width: size,
        height: size * 0.78,
      );
}
