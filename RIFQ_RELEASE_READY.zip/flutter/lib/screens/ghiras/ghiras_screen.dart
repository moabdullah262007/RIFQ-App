import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'ghiras_db.dart';
import 'ghiras_svg_widgets.dart';

/// ══════════════════════════════════════════════════════════════════════════
/// قسم «غراس الجنة» المتكامل في تطبيق «رِفْق | RIFQ» (Flutter - Android/iOS)
/// - 8 شاشات متكاملة بدون أي بيانات وهمية أو ادعاء حساب حسنات أو شارات
/// - قاعدة بيانات SQLite من 6 جداول + إشعارات اختيارية حقيقية + رسوم fl_chart
/// ══════════════════════════════════════════════════════════════════════════

class GhirasAlJannahScreen extends StatefulWidget {
  const GhirasAlJannahScreen({super.key});

  @override
  State<GhirasAlJannahScreen> createState() => _GhirasAlJannahScreenState();
}

class _GhirasAlJannahScreenState extends State<GhirasAlJannahScreen> {
  // الهوية اللونية الرسمية
  static const Color kGold = Color(0xFF5B5FEF);
  static const Color kLightGold = Color(0xFFE8B84A);
  static const Color kBeige = Color(0xFFF7F7FC);
  static const Color kBrown = Color(0xFF25263A);
  static const Color kGrey = Color(0xFF77798C);
  static const Color kEmerald = Color(0xFF4CAF82);
  static const Color kLightGreen = Color(0xFF4CAF82);
  static const Color kSkyBlue = Color(0xFF72B7E8);
  static const Color kSoilBrown = Color(0xFF77798C);

  final GhirasSqliteService _dbService = GhirasSqliteService.instance;

  String _activeScreen = 'home'; // home, plant, history, stages, stats, achievements, daily_deed, settings
  String _historyFilter = 'all'; // today, week, month, all
  bool _isLoading = true;

  // إعدادات المستخدم
  bool _dynamicSky = true;
  bool _fountainEnabled = true;
  bool _soundsEnabled = false;
  bool _darkMode = false;

  // التذكيرات الاختيارية الـ 4
  final Map<String, bool> _reminderEnabled = {
    'athkar': false,
    'quran': false,
    'good_deed': false,
    'watering': false,
  };
  final Map<String, TimeOfDay> _reminderTimes = {
    'athkar': const TimeOfDay(hour: 7, minute: 0),
    'quran': const TimeOfDay(hour: 18, minute: 0),
    'good_deed': const TimeOfDay(hour: 13, minute: 0),
    'watering': const TimeOfDay(hour: 20, minute: 30),
  };

  List<GhirasSeedModel> _seeds = [];
  List<GhirasActionTypeModel> _actionTypes = [];
  Map<String, dynamic> _summary = {};
  final TextEditingController _noteCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    final prefs = await SharedPreferences.getInstance();
    _dynamicSky = prefs.getBool('ghiras_dynamic_sky') ?? true;
    _fountainEnabled = prefs.getBool('ghiras_fountain') ?? true;
    _soundsEnabled = prefs.getBool('ghiras_sounds') ?? false;
    _darkMode = prefs.getBool('ghiras_dark_mode') ?? false;

    for (final k in _reminderEnabled.keys) {
      _reminderEnabled[k] = prefs.getBool('ghiras_rem_$k') ?? false;
    }

    await _reloadDb();
  }

  Future<void> _reloadDb() async {
    final seeds = await _dbService.getSeeds();
    final types = await _dbService.getActionTypes();
    final summary = await _dbService.getSummary();
    if (mounted) {
      setState(() {
        _seeds = seeds;
        _actionTypes = types;
        _summary = summary;
        _isLoading = false;
      });
    }
  }

  void _showToast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        backgroundColor: kEmerald,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  List<Color> _currentSkyGradient() {
    if (_darkMode) {
      return [const Color(0xFF0B132B), const Color(0xFF1C2541)];
    }
    if (!_dynamicSky) {
      return [kSkyBlue, const Color(0xFFD6F0FF)];
    }
    final h = DateTime.now().hour;
    if (h >= 5 && h < 11) {
      return [kSkyBlue, const Color(0xFFE8F6FF)];
    } else if (h >= 11 && h < 15) {
      return [const Color(0xFF56B4E9), kSkyBlue];
    } else if (h >= 15 && h < 17) {
      return [const Color(0xFFF4A261), const Color(0xFFF6BD60)];
    } else if (h >= 17 && h < 19) {
      return [const Color(0xFFE76F51), const Color(0xFFF4A261)];
    }
    return [const Color(0xFF0B132B), const Color(0xFF28385E)];
  }

  int _plantVisualLevel(int idx, int total) {
    final rank = total - idx;
    if (rank >= 40) return 5;
    if (rank >= 20) return 4;
    if (rank >= 10) return 3;
    if (rank >= 4) return 2;
    if (rank >= 2) return 1;
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final bgColor = _darkMode ? const Color(0xFF121212) : kBeige;
    final cardColor = _darkMode ? const Color(0xFF1E1E1E) : Colors.white;
    final textColor = _darkMode ? Colors.white : kBrown;

    if (_isLoading) {
      return Scaffold(
        backgroundColor: bgColor,
        body: const Center(child: CircularProgressIndicator(color: kGold)),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: bgColor,
        appBar: AppBar(
          backgroundColor: cardColor,
          elevation: 0.5,
          leading: IconButton(
            icon: Icon(Icons.arrow_back_ios_new, color: textColor),
            onPressed: () {
              if (_activeScreen != 'home') {
                setState(() => _activeScreen = 'home');
              } else {
                Navigator.pop(context);
              }
            },
          ),
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              GhirasSvgWidgets.palmAndTreeIcon(size: 24),
              const SizedBox(width: 8),
              Text(
                _screenTitle(),
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: textColor,
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings_outlined, color: kGold),
              onPressed: () => setState(() => _activeScreen = 'settings'),
            ),
          ],
        ),
        body: Column(
          children: [
            // شريط التنقل الفرعي للشاشات الـ 8
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  _navTab('home', 'حديقتك', cardColor, textColor),
                  _navTab('plant', 'ازرع غرسة', cardColor, textColor),
                  _navTab('history', 'سجل غراسي', cardColor, textColor),
                  _navTab('stages', 'مراحل التطور', cardColor, textColor),
                  _navTab('stats', 'إحصائياتي', cardColor, textColor),
                  _navTab('achievements', 'إنجازات', cardColor, textColor),
                  _navTab('daily_deed', 'عمل صالح اليوم', cardColor, textColor),
                  _navTab('settings', 'الإعدادات', cardColor, textColor),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: _buildActiveScreen(cardColor, textColor),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _navTab(String id, String label, Color cardColor, Color textColor) {
    final active = _activeScreen == id;
    return Padding(
      padding: const EdgeInsets.only(left: 6),
      child: ChoiceChip(
        label: Text(
          label,
          style: TextStyle(
            fontFamily: 'Cairo',
            fontWeight: FontWeight.bold,
            fontSize: 12,
            color: active ? Colors.white : textColor,
          ),
        ),
        selected: active,
        selectedColor: kEmerald,
        backgroundColor: cardColor,
        onSelected: (_) => setState(() => _activeScreen = id),
      ),
    );
  }

  String _screenTitle() {
    switch (_activeScreen) {
      case 'plant':
        return 'ازرع غرسة';
      case 'history':
        return 'سجل غراسي';
      case 'stages':
        return 'مراحل تطور الحديقة';
      case 'stats':
        return 'إحصائياتي';
      case 'achievements':
        return 'إنجازات';
      case 'daily_deed':
        return 'عمل صالح اليوم';
      case 'settings':
        return 'الإعدادات';
      default:
        return 'غراس الجنة';
    }
  }

  Widget _buildActiveScreen(Color cardColor, Color textColor) {
    switch (_activeScreen) {
      case 'plant':
        return _buildPlantScreen(cardColor, textColor);
      case 'history':
        return _buildHistoryScreen(cardColor, textColor);
      case 'stages':
        return _buildStagesScreen(cardColor, textColor);
      case 'stats':
        return _buildStatsScreen(cardColor, textColor);
      case 'achievements':
        return _buildAchievementsScreen(cardColor, textColor);
      case 'daily_deed':
        return _buildDailyDeedScreen(cardColor, textColor);
      case 'settings':
        return _buildSettingsScreen(cardColor, textColor);
      default:
        return _buildGardenHomeScreen(cardColor, textColor);
    }
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 1: الحديقة الشخصية
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildGardenHomeScreen(Color cardColor, Color textColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // بطاقة الترحيب
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kGold),
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GhirasSvgWidgets.palmAndTreeIcon(size: 22),
                  const SizedBox(width: 6),
                  Text(
                    'حديقتك',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      color: textColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text(
                '﴿مَثَلُ الَّذِينَ يُنفِقُونَ أَمْوَالَهُمْ فِي سَبِيلِ اللَّهِ كَمَثَلِ حَبَّةٍ أَنبَتَتْ سَبْعَ سَنَابِلَ﴾',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Amiri',
                  fontSize: 18,
                  color: kEmerald,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'سورة البقرة - آية 261',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: kGold,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),

        // الحديقة التفاعلية (سماء متغيرة + نباتات SVG + تربة #77798C + نافورة SVG)
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: kGold),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  constraints: const BoxConstraints(minHeight: 210),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: _currentSkyGradient(),
                    ),
                  ),
                  child: _seeds.isEmpty
                      ? Center(
                          child: Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.92),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: kGold),
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                GhirasSvgWidgets.plantByLevel(0, size: 44),
                                const SizedBox(height: 8),
                                const Text(
                                  'حديقتك ما زالت تنتظر أول غرسة',
                                  style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.bold,
                                    color: kBrown,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: kEmerald,
                                  ),
                                  onPressed: () =>
                                      setState(() => _activeScreen = 'plant'),
                                  child: const Text(
                                    'ازرع أول غرسة',
                                    style: TextStyle(
                                      fontFamily: 'Cairo',
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          alignment: WrapAlignment.center,
                          children: List.generate(
                            _seeds.length > 24 ? 24 : _seeds.length,
                            (idx) => GhirasSvgWidgets.plantByLevel(
                              _plantVisualLevel(idx, _seeds.length),
                              size: 48,
                            ),
                          ),
                        ),
                ),
                // التربة #77798C والنافورة SVG
                Container(
                  width: double.infinity,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  color: kSoilBrown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (_fountainEnabled) GhirasSvgWidgets.fountain(size: 54),
                      Text(
                        'عدد الغرسات الحقيقية: ${_seeds.length}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),

        // الأزرار السريعة
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _quickActionBtn('ازرع غرسة جديدة', () {
              setState(() => _activeScreen = 'plant');
            }),
            _quickActionBtn('اسقِ حديقتك', () async {
              await _dbService.waterGardenNow();
              await _reloadDb();
              _showToast('تم ري حديقتك بنجاح');
            }),
            _quickActionBtn('سجل غراسي', () {
              setState(() => _activeScreen = 'history');
            }),
            _quickActionBtn('إحصائياتي', () {
              setState(() => _activeScreen = 'stats');
            }),
            _quickActionBtn('الإعدادات', () {
              setState(() => _activeScreen = 'settings');
            }),
          ],
        ),
      ],
    );
  }

  Widget _quickActionBtn(String label, VoidCallback onTap) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: kEmerald,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      onPressed: onTap,
      child: Text(
        label,
        style: const TextStyle(
          fontFamily: 'Cairo',
          fontWeight: FontWeight.bold,
          color: Colors.white,
          fontSize: 12,
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 2: ازرع غرسة جديدة
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildPlantScreen(Color cardColor, Color textColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kGold),
          ),
          child: const Text(
            'التطبيق يسجل الأفعال فقط، والأجر عند الله وحده',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: kEmerald,
              fontSize: 13,
            ),
          ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _noteCtrl,
          decoration: const InputDecoration(
            hintText: 'ملاحظة اختيارية مع الغرسة...',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 10),
        OutlinedButton(
          onPressed: _openAddCustomActionDialog,
          child: const Text(
            '+ إضافة عمل مخصص',
            style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 10),
        ..._actionTypes.map(
          (act) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kGold.withOpacity(0.6)),
            ),
            child: Row(
              children: [
                GhirasSvgWidgets.palmAndTreeIcon(size: 26),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        act.name,
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: textColor,
                        ),
                      ),
                      Text(
                        act.description,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 12,
                          color: kGrey,
                        ),
                      ),
                    ],
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: kEmerald),
                  onPressed: () async {
                    await _dbService.plantSeed(
                      GhirasSeedModel(
                        type: act.icon,
                        customName: act.name,
                        plantedAt: DateTime.now().toIso8601String(),
                        note: _noteCtrl.text.trim(),
                      ),
                    );
                    _noteCtrl.clear();
                    await _reloadDb();
                    setState(() => _activeScreen = 'home');
                    _showToast('تم زرع غرسة جديدة');
                  },
                  child: const Text(
                    'ازرع',
                    style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _openAddCustomActionDialog() async {
    final nameCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text(
          'إضافة عمل مخصص',
          style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: 'اسم العمل'),
            ),
            TextField(
              controller: descCtrl,
              decoration: const InputDecoration(labelText: 'وصف (اختياري)'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kEmerald),
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              await _dbService.addCustomActionType(
                GhirasActionTypeModel(
                  name: nameCtrl.text.trim(),
                  icon: 'custom',
                  description: descCtrl.text.trim(),
                  isCustom: 1,
                ),
              );
              if (mounted) Navigator.pop(ctx);
              await _reloadDb();
            },
            child: const Text('حفظ', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 3: سجل غراسي
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildHistoryScreen(Color cardColor, Color textColor) {
    final now = DateTime.now();
    final filtered = _seeds.where((s) {
      if (_historyFilter == 'all') return true;
      final dt = DateTime.tryParse(s.plantedAt) ?? now;
      final diff = now.difference(dt).inDays;
      if (_historyFilter == 'today') return diff == 0;
      if (_historyFilter == 'week') return diff <= 7;
      if (_historyFilter == 'month') return diff <= 30;
      return true;
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            for (final f in [
              {'id': 'today', 'label': 'اليوم'},
              {'id': 'week', 'label': 'الأسبوع'},
              {'id': 'month', 'label': 'الشهر'},
              {'id': 'all', 'label': 'الكل'},
            ])
              ChoiceChip(
                label: Text(f['label']!),
                selected: _historyFilter == f['id'],
                selectedColor: kEmerald,
                onSelected: (_) => setState(() => _historyFilter = f['id']!),
              ),
          ],
        ),
        const SizedBox(height: 12),
        if (filtered.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: kGold),
            ),
            child: Column(
              children: [
                Text(
                  'لم تسجل أي عمل صالح بعد',
                  style: TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: kEmerald),
                  onPressed: () => setState(() => _activeScreen = 'plant'),
                  child: const Text(
                    'ازرع أول غرسة',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          )
        else
          ...filtered.map(
            (s) => Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kGold.withOpacity(0.6)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          s.customName,
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            color: textColor,
                          ),
                        ),
                        Text(
                          s.plantedAt.length >= 16
                              ? s.plantedAt.substring(0, 16).replaceAll('T', ' - ')
                              : s.plantedAt,
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            color: kGold,
                          ),
                        ),
                        if (s.note.isNotEmpty)
                          Text(
                            s.note,
                            style: const TextStyle(fontSize: 12, color: kGrey),
                          ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: () async {
                      if (s.id != null) {
                        await _dbService.deleteSeed(s.id!);
                        await _reloadDb();
                      }
                    },
                    child: const Text('حذف', style: TextStyle(color: Colors.red)),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 4: مراحل تطور الحديقة
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildStagesScreen(Color cardColor, Color textColor) {
    final stages = [
      {'name': 'بذرة', 'range': '0 - 4 غرسات', 'lvl': 0},
      {'name': 'برعم', 'range': '5 - 14 غرسة', 'lvl': 1},
      {'name': 'شتلة', 'range': '15 - 29 غرسة', 'lvl': 2},
      {'name': 'شجرة', 'range': '30 - 99 غرسة', 'lvl': 3},
      {'name': 'حديقة', 'range': '100 - 249 غرسة', 'lvl': 4},
      {'name': 'بستان', 'range': '250 - 499 غرسة', 'lvl': 4},
      {'name': 'حديقة مزهرة', 'range': '500+ غرسة', 'lvl': 5},
    ];
    final currentStage = GhirasSqliteService.stageNameForCount(_seeds.length);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kGold),
          ),
          child: Text(
            'المرحلة الحالية: $currentStage (${_seeds.length} غرسة)',
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              color: kEmerald,
              fontSize: 16,
            ),
          ),
        ),
        const SizedBox(height: 12),
        ...stages.map(
          (st) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: st['name'] == currentStage ? kEmerald : kGold,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    GhirasSvgWidgets.plantByLevel(st['lvl'] as int, size: 42),
                    const SizedBox(width: 10),
                    Text(
                      st['name'] as String,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        color: textColor,
                      ),
                    ),
                  ],
                ),
                Text(
                  st['range'] as String,
                  style: const TextStyle(
                    fontFamily: 'Cairo',
                    fontWeight: FontWeight.bold,
                    color: kGold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 5: إحصائياتي
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildStatsScreen(Color cardColor, Color textColor) {
    if (_seeds.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kGold),
        ),
        child: const Text(
          'لا توجد بيانات بعد — ابدأ بتسجيل أول عمل صالح',
          textAlign: TextAlign.center,
          style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
        ),
      );
    }

    final streakMap = (_summary['streak'] as Map<String, dynamic>?) ?? {};
    final dailyStats = (_summary['daily_stats'] as List<dynamic>?) ?? [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kGold),
          ),
          child: Column(
            children: [
              Text(
                'إجمالي الغرسات: ${_seeds.length} • أيام التسجيل: ${dailyStats.length}',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
              Text(
                'الاستمرارية الحالية: ${streakMap['current_streak'] ?? 0} يوم • أطول سلسلة: ${streakMap['longest_streak'] ?? 0} يوم',
                style: const TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  color: kEmerald,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          height: 200,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kGold),
          ),
          child: BarChart(
            BarChartData(
              barGroups: List.generate(
                dailyStats.length > 7 ? 7 : dailyStats.length,
                (idx) {
                  final row = dailyStats[idx] as Map<String, dynamic>;
                  final cnt = (row['actions_count'] as int?) ?? 0;
                  return BarChartGroupData(
                    x: idx,
                    barRods: [
                      BarChartRodData(toY: cnt.toDouble(), color: kEmerald),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 6: إنجازات (بدون ادعاء حساب حسنات)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildAchievementsScreen(Color cardColor, Color textColor) {
    final unlockedList = (_summary['achievements'] as List<dynamic>?) ?? [];
    final unlockedIds =
        unlockedList.map((e) => (e as Map)['achievement_id'] as String).toSet();

    final items = [
      {'id': 'first_seed', 'title': 'أول غرسة'},
      {'id': 'seven_days_logged', 'title': '7 أيام من التسجيل'},
      {'id': 'thirty_seeds', 'title': '30 غرسة'},
      {'id': 'first_tree', 'title': 'أول شجرة'},
      {'id': 'first_complete_garden', 'title': 'أول حديقة مكتملة'},
      {'id': 'thirty_days_streak', 'title': '30 يوم استمرارية'},
      {'id': 'hundred_seeds', 'title': '100 غرسة'},
    ];

    return Column(
      children: items.map((ach) {
        final isOpen = unlockedIds.contains(ach['id']);
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: isOpen ? kEmerald : kGold),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                ach['title']!,
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  color: textColor,
                ),
              ),
              Text(
                isOpen ? 'مفتوح' : 'مغلق',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.bold,
                  color: isOpen ? kEmerald : kGrey,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 7: عمل صالح اليوم
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildDailyDeedScreen(Color cardColor, Color textColor) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kGold),
      ),
      child: Column(
        children: [
          Text(
            'ماذا ستغرس اليوم؟',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 16,
              color: textColor,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            '﴿مَن ذَا الَّذِي يُقْرِضُ اللَّهَ قَرْضًا حَسَنًا﴾',
            style: TextStyle(fontFamily: 'Amiri', fontSize: 20, color: kEmerald),
          ),
          const Text(
            'سورة البقرة - آية 245',
            style: TextStyle(fontFamily: 'Cairo', fontSize: 12, color: kGold),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kEmerald),
            onPressed: () => setState(() => _activeScreen = 'plant'),
            child: const Text(
              'أفعل هذا اليوم',
              style: TextStyle(fontFamily: 'Cairo', color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // الشاشة 8: الإعدادات (الحديقة + التذكيرات الاختيارية + حذف البيانات)
  // ════════════════════════════════════════════════════════════════════════
  Widget _buildSettingsScreen(Color cardColor, Color textColor) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: kGold),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SwitchListTile(
            title: Text('تفعيل السماء المتغيرة', style: TextStyle(color: textColor)),
            value: _dynamicSky,
            onChanged: (val) async {
              final prefs = await SharedPreferences.getInstance();
              setState(() => _dynamicSky = val);
              await prefs.setBool('ghiras_dynamic_sky', val);
            },
          ),
          SwitchListTile(
            title: Text('تفعيل النافورة', style: TextStyle(color: textColor)),
            value: _fountainEnabled,
            onChanged: (val) async {
              final prefs = await SharedPreferences.getInstance();
              setState(() => _fountainEnabled = val);
              await prefs.setBool('ghiras_fountain', val);
            },
          ),
          SwitchListTile(
            title: Text('الوضع الليلي (#121212)', style: TextStyle(color: textColor)),
            value: _darkMode,
            onChanged: (val) async {
              final prefs = await SharedPreferences.getInstance();
              setState(() => _darkMode = val);
              await prefs.setBool('ghiras_dark_mode', val);
            },
          ),
          const Divider(),
          for (final entry in [
            {'key': 'athkar', 'title': 'تذكير الأذكار', 'id': 4101},
            {'key': 'quran', 'title': 'تذكير القرآن', 'id': 4102},
            {'key': 'good_deed', 'title': 'تذكير بعمل صالح', 'id': 4103},
            {'key': 'watering', 'title': 'تذكير بري الحديقة', 'id': 4104},
          ])
            SwitchListTile(
              title: Text(
                entry['title'] as String,
                style: TextStyle(color: textColor),
              ),
              value: _reminderEnabled[entry['key']] ?? false,
              onChanged: (val) async {
                final k = entry['key'] as String;
                final prefs = await SharedPreferences.getInstance();
                setState(() => _reminderEnabled[k] = val);
                await prefs.setBool('ghiras_rem_$k', val);
                final t = _reminderTimes[k]!;
                await _dbService.scheduleOptionalReminder(
                  notificationId: entry['id'] as int,
                  title: entry['title'] as String,
                  hour: t.hour,
                  minute: t.minute,
                  enabled: val,
                );
              },
            ),
          const Divider(),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              await _dbService.wipeAllGardenData();
              await _reloadDb();
              _showToast('تم حذف كل البيانات بنجاح');
            },
            child: const Text(
              'حذف كل البيانات',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
