import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class KidsStoryModel {
  final String id;
  final String title;
  final String description;
  final String categoryId;
  final String categoryLabel;
  final String ageRange;
  final int readingTimeMinutes;
  final String readingTimeGroup; // 'short' | 'medium' | 'long'
  final String moral;
  final List<String> paragraphs;
  final bool isFeatured;

  const KidsStoryModel({
    required this.id,
    required this.title,
    required this.description,
    required this.categoryId,
    required this.categoryLabel,
    required this.ageRange,
    required this.readingTimeMinutes,
    required this.readingTimeGroup,
    required this.moral,
    required this.paragraphs,
    this.isFeatured = false,
  });
}

class KidsStoriesData {
  static const List<Map<String, String>> categories = [
    {'id': 'all', 'label': 'الكل'},
    {'id': 'animals', 'label': 'قصص الحيوانات'},
    {'id': 'adventure', 'label': 'قصص مغامرات'},
    {'id': 'bedtime', 'label': 'قصص قبل النوم'},
    {'id': 'funny', 'label': 'قصص مضحكة'},
    {'id': 'friendship', 'label': 'قصص الصداقة والتعاون'},
    {'id': 'educational', 'label': 'قصص تعليمية'},
    {'id': 'morals', 'label': 'قصص الأخلاق والقيم'},
    {'id': 'fantasy', 'label': 'قصص خيالية'},
    {'id': 'islamic', 'label': 'قصص دينية للأطفال'},
    {'id': 'short', 'label': 'قصص قصيرة جدًا'},
  ];

  static const List<KidsStoryModel> stories = [
    KidsStoryModel(
      id: 'ks_01',
      title: 'السلحفاة المثابرة والأرنب السريع',
      description: 'في غابة الزمرد الخضراء، تعلّم الأرنب "برق" أن العبرة ليست بالسرعة وحدها بل بالصبر والاستمرار حتى خط النهاية.',
      categoryId: 'animals',
      categoryLabel: 'قصص الحيوانات',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 3,
      readingTimeGroup: 'short',
      moral: 'المثابرة والعمل الهادئ المستمر يوصلان إلى النجاح، والغرور يضيّع الفرص.',
      isFeatured: true,
      paragraphs: [
        'في غابةٍ خضراءَ جميلةٍ تملؤها الأزهار الملوّنة، كان يعيش أرنبٌ أبيضُ سريعٌ اسمه "برق". كان برق يفتخر دائماً بسرعته الفائقة، ويقفز بين الأشجار قائلاً لأصدقائه: "لا أحد في هذه الغابة يستطيع أن يسبقني أبداً!"',
        'وفي صباحٍ مشمس، مرّ برق بجانب السلحفاة الصغيرة "صابرة" وهي تمشي بهدوءٍ وابتسامةٍ لطيفة. ضحك الأرنب وقال: "يا صابرة، متى تصلين إلى النهر بهذه الخطوات البطيئة؟" أجابته السلحفاة بأدب: "أنا أمشي بخطواتٍ ثابتة يا صديقي، ومن يثابر يصل حتماً. ما رأيك أن نتسابق إلى شجرة التين الكبيرة عند التل؟"',
        'انطلق السباق وسط تشجيع العصافير والسناجب. ركض الأرنب بسرعةٍ كبيرة حتى ابتعد كثيراً، ثم نظر خلفه فلم يرَ السلحفاة إلا نقطةً بعيدة. قال في نفسه: "الوقت طويلٌ جداً، سأنام قليلاً في ظل هذه الشجرة الباردة ثم أكمل السباق في لمح البصر!"',
        'أما السلحفاة صابرة فلم تتوقف لحظةً واحدة؛ كانت تمشي خطوةً بعد خطوة وهي تردد: "خطوةٌ صغيرةٌ بعد خطوةٍ صغيرة تصنع طريقاً كبيراً". مرّت بجانب الأرنب النائم وتابعت طريقها بهدوءٍ وثبات.',
        'عندما استيقظ الأرنب قبيل الغروب، ركض بأقصى سرعته نحو التل، لكنه وجد السلحفاة صابرة قد وصلت قبله وتبتسم له بلطف! صفّقت حيوانات الغابة للسلحفاة المثابرة، واقترب الأرنب معتذراً وقال: "تعلّمت اليوم درساً لن أنساه؛ المثابرة والصبر أجمل من السرعة مع الكسل."',
      ],
    ),
    KidsStoryModel(
      id: 'ks_02',
      title: 'النجمة التي أضاءت الطريق',
      description: 'نجمة صغيرة في السماء ظنّت أن نورها ضعيف لا يفيد أحداً، حتى ساعدت عصفوراً صغيراً في العودة إلى عشه قبل النوم.',
      categoryId: 'bedtime',
      categoryLabel: 'قصص قبل النوم',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 3,
      readingTimeGroup: 'short',
      moral: 'كل خيرٍ صغير تقدّمه للآخرين له أثرٌ كبير وجميل.',
      isFeatured: true,
      paragraphs: [
        'حين أرخى الليل ستائره الهادئة، تلألأت النجوم في السماء كأنها مصابيحُ من ذهب. وفي طرف السماء، كانت هناك نجمةٌ صغيرةٌ اسمها "لمعة"، تنظر إلى القمر البدر وتقول بحزن: "نور القمر كبيرٌ وساطع، أما نوري فصغيرٌ جداً، فهل ينتفع به أحد؟"',
        'سمعتها سحابةٌ بيضاءُ ناعمة وقالت لها بحنان: "يا لمعة، الله سبحانه جعل لكل مخلوقٍ دوراً جميلاً؛ انظري إلى الأرض وستعرفين قيمة نورك."',
        'نظرت لمعة إلى الأسفل، فرأت فرخَ عصفورٍ صغيرٍ قد تأخّر عن عشّه فوق شجرة الزيتون، وغطّت غيمةٌ عابرةٌ ضوء القمر فاحتار العصفور الصغير في طريقه.',
        'جمعت النجمة لمعة كل طاقتها وأرسلت شعاعاً ذهبياً دافئاً نحو غصن شجرة الزيتون، فاهتدى العصفور الصغير إلى عشه الدافئ وجلس بجانب أمه بأمان.',
        'ابتسمت النجمة الصغيرة لمعة بسعادةٍ غامرة، وأدركت أن الخير مهما بدا صغيراً فإنه يضيء القلوب والدروب، ثم أغمضت عينيها لتستمتع بليلٍ هادئٍ وجميل.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_03',
      title: 'رحلة السفينة الطائرة فوق الغيوم',
      description: 'مغامرة شيّقة لثلاثة أصدقاء بنوا منطاداً خشبياً صغيراً لاكتشاف ما فوق الغيوم البيضاء وإنقاذ حديقة القرية.',
      categoryId: 'adventure',
      categoryLabel: 'قصص مغامرات',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 5,
      readingTimeGroup: 'medium',
      moral: 'التفكير العلمي والشجاعة والتعاون تفتح أبواب الاكتشاف وحل المشكلات.',
      isFeatured: true,
      paragraphs: [
        'في قرية "التلال الذهبية"، كان الأصدقاء الثلاثة: مازن الذي يحب النجارة، وليلى التي تحب قراءة كتب العلوم، وعمرو الذي يجيد رسم الخرائط، يجلسون فوق التل ويتأملون السحب البيضاء.',
        'قالت ليلى: "لقد تأخر المطر هذا الموسم عن بستان القرية، وجدول الماء الذي ينزل من قمة الجبل قد توقّف؛ لا بد أن شيئاً يسدّ مجرى النبع في الأعلى!"',
        'تعاون الأصدقاء الثلاثة مع حكيم القرية في تجهيز مركبٍ هوائيٍّ صغيرٍ يرتفع بمنطادٍ متين، وحملوا معهم حبالاً وأدواتٍ بسيطة وبوصلةً لتحديد الاتجاه.',
        'ارتفع المركب الهوائي بهدوءٍ بين النسائم العليلة حتى وصلوا إلى هضبة النبع العالية فوق الغيوم، وهناك وجدوا جذع شجرةٍ يابساً وأحجاراً قد تجمّعت فحولت مجرى الماء بعيداً عن وادي القرية.',
        'وبالتعاون والتفكير السليم، استخدم مازن وعمرو وليلى الحبال والروافع الخشبية لإزاحة الجذع والأحجار، فانطلق الماء الصافي من جديد ينساب نحو البستان، وعاد الأصدقاء إلى قريتهم وسط فرحة الأهالي.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_04',
      title: 'الغيمة الضاحكة والمطر الملوّن',
      description: 'قصة طريفة عن غيمة صغيرة اسمها "قطنة" كانت كلما دغدغتها الريح عطست أمطاراً ترسم قوس المطر وتضحك الأطفال.',
      categoryId: 'funny',
      categoryLabel: 'قصص مضحكة',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 3,
      readingTimeGroup: 'short',
      moral: 'الابتسامة والمرح اللطيف ينشران البهجة في نفوس من حولنا.',
      paragraphs: [
        'كانت الغيمة الصغيرة "قطنة" أكثر الغيوم مرحاً في السماء؛ فبينما كانت الغيوم الكبيرة تمشي بوقارٍ وهدوء، كانت قطنة تتشقلب في الهواء وتصنع أشكالاً مضحكة: مرةً على شكل أرنبٍ بأذنين طويلتين، ومرةً على شكل إبريق شايٍ كبير!',
        'وفي يومٍ من الأيام، مرّت نسمةُ هواءٍ لطيفة فدغدغت الغيمة قطنة، فبدأت قطنة تضحك وتقول: "هاها.. هاتشووو!" ومع كل عطسةٍ صغيرة كانت تسقط قطراتُ ماءٍ باردةٌ ومنعشة فوق حديقة الأطفال.',
        'نظر الأطفال إلى الأعلى بدهشةٍ وضحكوا حين رأوا الغيمة تشكّل وجهاً مبتسماً كبيراً، وأشرقت الشمس في اللحظة نفسها فارتسم قوسُ المطر بألوانه السبعة الزاهية.',
        'ركض البطّ الصغير في البركة وهو يقلّد صوت الغيمة الضاحكة، وتعلّم أطفال الحي أن البشاشة والروح المرحة تجعل اليوم العادي يوماً مليئاً بالسعادة.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_05',
      title: 'النملات الثلاث وحبة القمح الذهبية',
      description: 'ثلاث نملات صغيرات وجدن حبة قمح كبيرة، فاكتشفن أن القوة الحقيقية تكمن في اتحاد الأيدي وتقاسم المهام.',
      categoryId: 'friendship',
      categoryLabel: 'قصص الصداقة والتعاون',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 3,
      readingTimeGroup: 'short',
      moral: 'في الاتحاد قوة، وما يعجز عنه الفرد وحده ينجزه الأصدقاء بالتعاون.',
      paragraphs: [
        'خرجت النملة "همّة" في الصباح الباكر تبحث عن طعامٍ لبيتها قبل حلول الشتاء، فعثرت تحت سنبلةٍ صفراء على حبة قمحٍ ذهبيةٍ كبيرةٍ وجميلة.',
        'حاولت همّة أن ترفع حبة القمح وحدها، فدفعتها يميناً ودفعتها يساراً، لكن الحبة لم تتحرك إلا قليلاً لأنها كانت أثقل منها بكثير.',
        'نادَت همّة صديقتيها "نشاط" و"تعاون"، فجاءتا مسرعتين، وقالت نشاط: "سأمسك أنا من المقدمة، وأنتِ يا همّة من الوسط، وتعاون تدفع معنا من الخلف، ولنعدّ معاً: واحد، اثنان، ثلاثة!"',
        'وبمجرد أن وحّدت النملات الثلاث جهودهن، ارتفعت حبة القمح بسهولةٍ وسارت بها النملات وهنّ ينشدن نشيد الصداقة حتى وصلن إلى بيت النمل، وتقاسم الجميع الخير بفرحٍ ومحبّة.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_06',
      title: 'القمر النعسان ولحاف الغيوم',
      description: 'قصة هادئة ومريحة قبل النوم عن القمر الذي يطمئن على نوم العصافير والأزهار والأطفال قبل أن يستريح.',
      categoryId: 'bedtime',
      categoryLabel: 'قصص قبل النوم',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 3,
      readingTimeGroup: 'short',
      moral: 'النوم المبكر بعد ذكر الله يمنح الجسم الراحة والنشاط ليومٍ جديد.',
      paragraphs: [
        'في المساء الهادئ، ارتدى القمر عباءته الفضية الناعمة، وأطلّ من خلف التلال ليطمئنّ على الأرض وأهلها بعد يومٍ طويلٍ من العمل واللعب.',
        'مرّ القمر فوق الغابة، فرأى العصافير الصغيرة قد دخلت أعشاشها وأغمضت عيونها، ومرّ فوق الحقول فرأى الأزهار قد ضمّت أوراقها لتستريح حتى الصباح.',
        'ثم أطلّ القمر من نافذة غرفة الطفل الصغير "زياد"، فرآه قد نظّف أسنانه، وتوضأ، وقرأ أذكار النوم مع أمه، وقال: "باسمك اللهم أموت وأحيا".',
        'ابتسم القمر النعسان وقال للغيمة البيضاء: "الآن نام الجميع بسلام، هاتي لحافكِ القطنيّ اللطيف"، وعمّ الهدوء والسكينة في كل مكان.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_07',
      title: 'الحطّاب الأمين وكنز النهر',
      description: 'حكاية أخلاقية جميلة عن حطّاب فقير سقطت فأسه في النهر، فرفض أن يأخذ فأساً من ذهب لأنها ليست ملكه.',
      categoryId: 'morals',
      categoryLabel: 'قصص الأخلاق والقيم',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 5,
      readingTimeGroup: 'medium',
      moral: 'الأمانة والصدق يجلبان البركة والاحترام وطمأنينة القلب.',
      paragraphs: [
        'كان في قديم الزمان حطّابٌ طيبُ القلب اسمه "عمّ صالح"، يعمل كل يومٍ بجدٍّ ونشاطٍ ليجمع الحطب اليابس ويبيعه في السوق ليطعم أسرته من كسب يده الحلال.',
        'وفي أحد الأيام، بينما كان يعمل قرب النهر، انزلقت فأسه الحديدية القديمة من يده وسقطت في الماء العميق. جلس عمّ صالح على الضفة يفكّر كيف سيعمل غداً دون فأسه الوحيدة.',
        'مرّ به تاجرٌ كريمٌ يملك قارباً وشبكة غوص، فلما سمع قصته أراد أن يختبر أمانته، فأخرج له من صندوقه فأساً مطليّةً بالذهب اللامع وقال: "أهذه فأسك يا عمّ صالح؟" قال الحطّاب فوراً: "لا يا سيدي، هذه فأسٌ ثمينةٌ من ذهب، وليست فأسي."',
        'أخرج التاجر فأساً أخرى من فضة، فقال الحطّاب بصدق: "ولا هذه لي؛ فأسي حديديةٌ بسيطةٌ عليها علامةٌ خشبية." فغاص رجال التاجر وأخرجوا الفأس الحديدية القديمة، ففرح الحطّاب وقال: "نعم! هذه هي فأسي الحقيقية، بارك الله فيكم."',
        'أُعجب التاجر بأمانة عمّ صالح وعفّته، فأهداه الفأس الذهبية والفضية مكافأةً لصدقه وأمانته، وعاد الحطّاب إلى بيته مسروراً لأن الصدق والأمانة هما أعظم كنز.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_08',
      title: 'العصفور الصغير والتمرة المباركة',
      description: 'قصة دينية تربوية للأطفال عن طفل اسمه "أنس" تعلّم قيمة الرفق بالحيوان والصدقة من خلال إطعام عصفورٍ جائع.',
      categoryId: 'islamic',
      categoryLabel: 'قصص دينية للأطفال',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 4,
      readingTimeGroup: 'medium',
      moral: 'في كل كبدٍ رطبةٍ أجر؛ الرفق بالحيوانات وإطعامها سببٌ لرضا الله سبحانه.',
      paragraphs: [
        'اعتاد الطفل "أنس" أن يجلس مع جده في شرفة البيت بعد صلاة العصر ليأكلا التمر ويشربا الحليب الدافئ، ويستمع إلى القصص النبوية الجميلة.',
        'وفي يومٍ بارد، حطّ عصفورٌ صغيرٌ على حافة الشرفة، وكان ينفض ريشه من البرد ويبحث عن فتات طعام. نظر أنس إلى العصفور بشفقةٍ وقال: "يا جدي، يبدو هذا العصفور جائعاً وعطشان!"',
        'ابتسم الجد وقال: "أحسنت الملاحظة يا بني؛ لقد علّمنا نبينا محمدٌ ﷺ الرحمة بكل المخلوقات، وأخبرنا أن في سقيا كل ذي كبدٍ رطبةٍ أجراً عظيماً عند الله."',
        'أحضر أنس إناءً صغيراً نظيفاً وملأه بالماء العذب، وفتّت حبة تمرٍ وحفنةً من الحبوب ووضعها في زاوية الشرفة، ثم تراجع بهدوء حتى لا يخاف العصفور.',
        'أقبل العصفور الصغير فأكل وشرب حتى شبع، ثم وقف على الغصن يغرّد بصوتٍ عذبٍ جميل كأنه يشكر أنساً، ومنذ ذلك اليوم صارت شرفة أنس مطعماً يومياً لطيور الحي.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_09',
      title: 'سرّ الساعة الذهبية القديمة',
      description: 'قصة تعليمية ممتعة عن الأختين "مريم" و"سلمى" اللتين اكتشفتا كيف يعمل الوقت وكيف ينظّم الإنسان يومه بنجاح.',
      categoryId: 'educational',
      categoryLabel: 'قصص تعليمية',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 5,
      readingTimeGroup: 'medium',
      moral: 'تنظيم الوقت بين الدراسة والعبادة واللعب والراحة سرّ التفوق والسعادة.',
      paragraphs: [
        'كانت "مريم" تحب الرسم والقراءة، لكنها كثيراً ما تنسى واجباتها المدرسية حتى وقتٍ متأخرٍ من المساء لأنها تقضي ساعاتٍ طويلةً دون جدولٍ واضح.',
        'وفي زيارةٍ لبيت الجد، لفتت نظرها ساعةٌ خشبيةٌ ذهبيةٌ كبيرةٌ في غرفة المكتبة تدقّ بانتظام: "تِك.. تَك.. تِك.. تَك". سألت مريم جدها: "لماذا لا تتعب عقارب الساعة يا جدي؟"',
        'أجاب الجد بابتسامة: "لأن كل عقربٍ يعرف مهمته ويمشي بنظامٍ دقيق؛ العقرب الصغير للساعات، والكبير للدقائق، ولو توقّف أحدهما لاختلّ الوقت كله. وكذلك يوم الإنسان يا مريم يحتاج إلى تقسيمٍ متوازن."',
        'أحضر الجد ورقةً ملوّنة وساعد مريم وأختها سلمى في رسم "عجلة اليوم السعيد": وقتٌ للصلاة والقرآن، ووقتٌ للمدرسة والمذاكرة، ووقتٌ للعب والرياضة، ووقتٌ للنوم المبكر.',
        'طبّقت مريم الجدول الجديد لأسبوعٍ واحد، فتفاجأت بأنها أنجزت كل دروسها مبكراً، ورسمت ثلاث لوحاتٍ جميلة، وبقي لديها وقتٌ كافٍ للجلوس مع عائلتها بكل راحةٍ وسرور.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_10',
      title: 'المظلّة الملوّنة في يومٍ ماطر',
      description: 'قصة عن الأنانية والإيثار؛ كيف تحوّلت مظلة "يوسف" الصغيرة إلى مظلةٍ تسع الأصدقاء جميعاً بفضل المحبة.',
      categoryId: 'friendship',
      categoryLabel: 'قصص الصداقة والتعاون',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 4,
      readingTimeGroup: 'medium',
      moral: 'المشاركة مع الأصدقاء تضاعف الفرح وتجعل الأشياء الصغيرة واسعةً بالمحبة.',
      paragraphs: [
        'حمل "يوسف" مظلّته الجديدة الملونة بألوان الطيف وهو ذاهبٌ إلى المدرسة، وكان ينتظر نزول المطر بفارغ الصبر ليجرّبها.',
        'وعند انتهاء اليوم الدراسي، هطل مطرٌ غزير، ففتح يوسف مظلته بفخر، لكنه رأى زميله "كريم" يقف عند باب المدرسة دون مظلةٍ ويخشى أن تبتلّ كتبه ودفاتره.',
        'تردّد يوسف لحظةً، ثم تذكّر أن الصديق الحقّ يقف مع صديقه، فنادى كريماً وقال: "تعال يا كريم، المظلة تكفينا نحن الاثنين!"',
        'وفي الطريق وجدا جارهم الصغير "سامي" يحمل مظلةً كبيرةً لكن الرياح كانت تميلها، فاجتمع الثلاثة معاً وأمسكوا بالمظلتين بجانب بعضهما، وعادوا إلى بيوتهم جافّين مسرورين وهم يضحكون تحت زخّات المطر.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_11',
      title: 'الفانوس الشجاع في كهف الصدى',
      description: 'مغامرة خيالية مشوّقة عن الفانوس الصغير "نور" الذي ساعد المستكشف الصغير على تجاوز الخوف من الظلام.',
      categoryId: 'fantasy',
      categoryLabel: 'قصص خيالية',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 5,
      readingTimeGroup: 'medium',
      moral: 'الشجاعة ليست عدم الشعور بالخوف، بل التفكير الهادئ والتقدم بنور المعرفة.',
      paragraphs: [
        'في مدينة الفوانيس العجيبة، كان الفانوس الصغير "نور" يحلم بأن يرافق المستكشفين في رحلةٍ إلى "وادي البلّور"، حيث توجد الأحجار المضيئة التي تُزيّن مكتبة المدينة.',
        'رافق الفانوس نور الفتى المستكشف "طارق"، وعندما دخلا ممرّ الصدى الجبليّ، كانت الظلال تبدو طويلةً على الجدران، فشعر طارق ببعض الرهبة.',
        'توهّج الفانوس نور بضوءٍ ذهبيٍّ دافئ وقال له: "اقترب يا طارق وانظر جيداً؛ هذه الظلال الضخمة ليست إلا صخوراً صغيرةً وأغصاناً عاديةً كَبُر ظلّها لأن الضوء خلفها!"',
        'ابتسم طارق حين رأى الحقيقة بعينيه، وتابع المسير بثقةٍ وهدوء حتى وصلا إلى قاعة البلّور التي انعكس فيها نور الفانوس الصغير فتحوّلت القاعة كلها إلى لوحةٍ من النجوم الساطعة.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_12',
      title: 'البستانيّ الصغير وبذرة الصبر',
      description: 'قصة قصيرة جداً عن الطفل "ريان" الذي زرع بذرة تفاح وتعلّم أن الأشياء الجميلة تحتاج إلى رعايةٍ وصبر.',
      categoryId: 'short',
      categoryLabel: 'قصص قصيرة جدًا',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 2,
      readingTimeGroup: 'short',
      moral: 'الصبر والعناية اليومية يصنعان أجمل الثمار.',
      paragraphs: [
        'زرع "ريان" بذرةً صغيرةً في أصيصٍ فخاري، وسقاها بالماء، ثم جلس أمامها ينتظر أن تخرج الشجرة في اللحظة نفسها!',
        'ابتسمت أمه وقالت: "يا ريان، البذرة الآن تنمو تحت التراب بهدوء؛ تحتاج منك كل يومٍ قليلاً من الماء، وضوء الشمس، وكثيراً من الصبر."',
        'واظب ريان على سقايتها كل صباح، وبعد أيامٍ خرجت نبتةٌ خضراءُ صغيرةٌ تشبه ورقةين مبتسمتين، ففرح ريان وعرف أن الصبر مفتاح كل نجاح.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_13',
      title: 'حكمة البومة العالمة في مدرسة الغابة',
      description: 'في مدرسة الغابة، اختلفت الحيوانات الصغيرة حول أهمّ مهارة في الحياة، فجمعتهم المعلمة الحكيمة في تجربةٍ عملية.',
      categoryId: 'educational',
      categoryLabel: 'قصص تعليمية',
      ageRange: '9–12 سنة',
      readingTimeMinutes: 6,
      readingTimeGroup: 'medium',
      moral: 'العلم الحقيقي يجمع بين القراءة والتجربة والعمل النافع وتكامل المواهب.',
      paragraphs: [
        'في مدرسة الغابة الكبرى، دار نقاشٌ حماسيٌّ بين الطلاب؛ قال القندس: "الهندسة والبناء أهم شيء!" وقال البلبل: "بل اللغة والبيان!" وقال السنجاب: "بل الحساب وجمع المؤونة!"',
        'استمعت المعلمة الحكيمة إلى الجميع باهتمام، ثم طلبت منهم مهمةً واحدة: بناء مكتبةٍ عائمةٍ صغيرةٍ فوق جدول الغابة يستفيد منها الجميع قبل نهاية الأسبوع.',
        'بدأ القندس بقصّ الأخشاب لكنه احتاج إلى حسابات السنجاب الدقيقة لكيلا تميل المكتبة، ثم احتاجا إلى البلبل ليكتب لوحات الإرشاد ويرتّب عناوين الكتب بخطٍّ واضحٍ وجميل.',
        'عندما اكتملت المكتبة الخشبية الجميلة، أدرك الطلاب أن كل علمٍ يكمل العلوم الأخرى، وأن المجتمع الناجح يحتاج إلى المهندس والأديب والمحاسب والطبيب معاً.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_14',
      title: 'التفاحة الذهبية وحقّ الطريق',
      description: 'قصة دينية وأخلاقية مستوحاة من قيم الأمانة والورع، عن فتى وجد تفاحةً في مجرى الماء فبحث عن صاحب البستان.',
      categoryId: 'islamic',
      categoryLabel: 'قصص دينية للأطفال',
      ageRange: '9–12 سنة',
      readingTimeMinutes: 7,
      readingTimeGroup: 'long',
      moral: 'حفظ الأمانة وطلب الحلال واستئذان أصحاب الحقوق من أسمى أخلاق المسلم.',
      paragraphs: [
        'كان الفتى "ثابت" يسير بجانب جدول ماءٍ يمرّ بين بساتين القرية بعد يومٍ طويلٍ من السفر وطلب العلم، وقد شعر بجوعٍ شديد.',
        'فرأى تفاحةً حمراءَ يانعةً يحملها تيار الماء، فالتقطها وغسلها وأكل منها لقمةً، ثم تذكّر فجأةً وقال في نفسه: "هذه التفاحة سقطت من بستانٍ لأحد الناس، ولم أستأذن صاحبها!"',
        'سار ثابت بمحاذاة الجدول عكس اتجاه الماء حتى وصل إلى بستانٍ تتدلّى أغصان تفاحه فوق الساقية، فطرق الباب على صاحب البستان الشيخ الجليل، وحكى له ما جرى بصدقٍ وأدب، وطلب منه أن يسامحه أو يعمل عنده مقابل ثمن التفاحة.',
        'نظر صاحب البستان إلى الفتى بإعجابٍ شديدٍ لأمانته وورعه وحرصه على الحلال في شيءٍ قد يراه الناس يسيراً، وقال له: "يا بنيّ، من يحفظ الأمانة في تفاحةٍ صغيرة فهو على ما سواها أمين؛ قد سامحتك وجعلت لك نصيباً من ثمار البستان هديةً لأمانتك!"',
      ],
    ),
    KidsStoryModel(
      id: 'ks_15',
      title: 'مغامرة القارب الورقيّ الذي لم يستسلم',
      description: 'رحلة قاربٍ ورقيٍّ صنعه طفلٌ من ورقٍ مقوّى مطليٍّ بالشمع، وكيف عبر الجداول الصغيرة ليصل إلى البحيرة الواسعة.',
      categoryId: 'adventure',
      categoryLabel: 'قصص مغامرات',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 4,
      readingTimeGroup: 'medium',
      moral: 'الإعداد الجيد والمرونة أمام العقبات يساعداننا على الوصول إلى أهدافنا.',
      paragraphs: [
        'صنع الطفل "فارس" قارباً جميلاً من الورق المقوّى، ودهن قاعدته بطبقةٍ رقيقةٍ من شمع العسل الطبيعي كما علّمه معلم العلوم حتى لا يبتلّ بالماء، وسمّاه "المستكشف الصغير".',
        'وضع فارس القارب في الساقية الصافية التي تجري نحو بحيرة الحديقة، وركض بجانبه يراقب رحلته عبر المنعطفات والجسور الحجرية الصغيرة.',
        'اعترضت القاربَ بعضُ الأغصان والأوراق المتساقطة، فكان القارب يدور بلطفٍ مع تيار الماء ويجد ممرّاً جديداً دون أن ينكسر بفضل متانته وتوازنه.',
        'وفي النهاية وصل "المستكشف الصغير" إلى البحيرة الواسعة حيث تسبح الإوزات البيضاء، واستقبله فارس عند الضفة الأخرى بفرحٍ وفخرٍ بتجربته العلمية الناجحة.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_16',
      title: 'الخبّاز الكريم ورائحة الخبز الدافئ',
      description: 'قصة دافئة عن خبّاز القرية "عمّ رضوان" الذي كان يجعل في كل عجينةٍ نصيباً للطيور والفقراء فتباركت تجارته.',
      categoryId: 'morals',
      categoryLabel: 'قصص الأخلاق والقيم',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 5,
      readingTimeGroup: 'medium',
      moral: 'الكرم وإحسان العمل ومساعدة المحتاجين تزيد الرزق بركةً والقلب سعادة.',
      paragraphs: [
        'قبل أن تشرق الشمس على القرية، كانت رائحة الخبز الطازج تفوح من مخبز "العمّ رضوان"، فتوقظ الناس على أطيب نسيمٍ وأجمل ابتسامة.',
        'كان سرّ العمّ رضوان أنه يختار أنقى القمح، ويخبز بإتقانٍ وأمانة، ويضع كل صباحٍ سلّةً خاصةً عند نافذة المخبز مكتوباً عليها: "لمن نسي نقوده أو كان عابر سبيل، خذ برغيفك على بركة الله".',
        'وفي سنةٍ قلّ فيها القمح في الأسواق، اجتمع أهل القرية والمزارعون وأحضروا للعمّ رضوان أجود أكياس القمح من مزارعهم عرفاناً بكرمه وأخلاقه النبيلة.',
        'قال العمّ رضوان لحفيده الصغير وهو يعلّمه صناعة الخبز: "يا بنيّ، اليد التي تعطي بالخير لا تفتقر أبداً، والصدقة تحفظ النعمة وتزيدها بركة."',
      ],
    ),
    KidsStoryModel(
      id: 'ks_17',
      title: 'السنجاب الفضوليّ الذي أضاع مخزنه',
      description: 'قصة مضحكة وتعليمية عن السنجاب "بندق" الذي خبّأ جوزه في عشرة أماكن سرية ثم نسيها جميعاً فتحوّلت إلى أشجار!',
      categoryId: 'funny',
      categoryLabel: 'قصص مضحكة',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 4,
      readingTimeGroup: 'medium',
      moral: 'تدوين الملاحظات والتنظيم يحمينا من النسيان، وربّ نافعةٍ خرجت من خطأ غير مقصود.',
      paragraphs: [
        'جمع السنجاب "بندق" كيساً كبيراً من حبّات البلوط والجوز، وقال في نفسه بذكاءٍ مفرط: "سأخبّئ كل حبّةٍ في مكانٍ سريٍّ للغاية حتى لا يعثر عليها أحد!"',
        'خبّأ حبةً خلف الصخرة الزرقاء، وحبةً تحت الشجيرة القصيرة، وحبةً عند جذور البلوطة القديمة، وظلّ يركض طوال اليوم دون أن يرسم خريطةً أو يضع علامةً واحدة.',
        'وفي اليوم التالي، وقف بندق يحكّ رأسه ويقول: "أين وضعت الجوز؟ أكان خلف الصخرة اليمنى أم اليسرى؟!" وجعل يحفر هنا وهناك فيعثر على حصىً ومخاريط صنوبر قديمة وسط ضحك أصدقائه اللطيف.',
        'شارك الأصدقاءُ بندقاً من طعامهم، وعندما جاء فصل الربيع كانت المفاجأة المدهشة: لقد نبتت حبات الجوز التي نسيها بندق تحت التراب، وأصبحت شجيراتٍ صغيرةً جميلةً ملأت الغابة بالخير، ومن يومها صار بندق يحمل دفتراً صغيراً يسجّل فيه كل شيء!',
      ],
    ),
    KidsStoryModel(
      id: 'ks_18',
      title: 'همسة النسيم وورقة الخريف',
      description: 'قصة خيالية شاعرية عن ورقة شجر ذهبية ظنّت أن سقوطها في الخريف نهاية رحلتها، فاكتشفت أنها بداية حياةٍ جديدة.',
      categoryId: 'fantasy',
      categoryLabel: 'قصص خيالية',
      ageRange: '9–12 سنة',
      readingTimeMinutes: 6,
      readingTimeGroup: 'medium',
      moral: 'التغيّرات في الحياة تحمل حكمةً وخيراً، ولكل فصلٍ من فصول العمر جماله وعطاؤه.',
      paragraphs: [
        'على غصنٍ عالٍ من شجرة القيقب، كانت الورقة الذهبية "كهرمانة" تنظر إلى أخواتها اللواتي يتطايرن مع نسيم الخريف وتهمس للشجرة الأم: "أخاف أن أترك الغصن فينتهي دوري في البستان."',
        'أجابتها الشجرة الأم بصوتٍ حنون: "لا تحزني يا صغيرتي؛ لقد أظللتِ العصافير طوال الصيف، وصنعتِ الغذاء بضوء الشمس، والآن تبدأ مهمتكِ الجديدة على الأرض."',
        'حمل النسيمُ اللطيفُ الورقةَ الذهبيةَ في رقصةٍ هادئةٍ حتى استقرّت فوق التربة الدافئة قرب جذور الشجرة، وشكّلت مع الأوراق الأخرى غطاءً طبيعياً يحمي الجذور والبذور الصغيرة من برد الشتاء.',
        'ومع أمطار الشتاء ودفء الربيع، تحوّلت الأوراق إلى غذاءٍ غنيٍّ للتربة، فازدهرت الشجرة الأم بأوراقٍ خضراءَ جديدةٍ وأزهارٍ عطرة، واستمرّت دورة الحياة البديعة.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_19',
      title: 'القطّة البيضاء وكلمة "شكراً"',
      description: 'قصة قصيرة جداً للأطفال الصغار عن القطة اللطيفة "بياض" والطفلة "جنى" التي تعلّمت شكر الله ثم شكر الناس.',
      categoryId: 'short',
      categoryLabel: 'قصص قصيرة جدًا',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 2,
      readingTimeGroup: 'short',
      moral: 'قول "الحمد لله" و"شكراً لك" و"جزاك الله خيراً" ينشر المحبة والأدب.',
      paragraphs: [
        'قدّمت الطفلة "جنى" طبقاً من الحليب الدافئ للقطة الصغيرة "بياض"، فاقتربت القطة ومسحت رأسها الناعم بيد جنى وهي تموء بصوتٍ رقيقٍ كأنها تقول لها: شكراً!',
        'فرحت جنى وقالت لأمها: "انظري يا أمي، حتى القطة الصغيرة تشكر من يحسن إليها!"',
        'قالت الأم: "نعم يا حبيبتي، المسلم المهذّب يحمد الله على النعم، ويقول لمن قدّم له معروفاً: شكراً لك وجزاك الله خيراً."',
      ],
    ),
    KidsStoryModel(
      id: 'ks_20',
      title: 'فرشاة الألوان التي رسمت الابتسامة',
      description: 'قصة خيالية ملهمة عن الطفل "آدم" الذي استخدم موهبته في الرسم لتجميل جدران الحي وإدخال السرور على جيرانه.',
      categoryId: 'fantasy',
      categoryLabel: 'قصص خيالية',
      ageRange: '6–8 سنوات',
      readingTimeMinutes: 5,
      readingTimeGroup: 'medium',
      moral: 'الموهبة نعمةٌ من الله، وتصبح أجمل حين نستخدمها في نفع الناس وتجميل بيئتنا.',
      paragraphs: [
        'أهدى المعلمُ التلميذَ الموهوب "آدم" علبة ألوانٍ مائيةٍ وفرشاةً خشبيةً متقنة، وقال له: "الفنّ الجميل يا آدم هو الذي يترك أثراً طيباً في قلوب الناس."',
        'لاحظ آدم أن الجدار المحيط بحديقة الحي قد بهت لونه وتقشّر طلاؤه، فاستأذن مجلس الحي ومعلمه في تنظيم يومٍ تطوّعيٍّ لتنظيف الجدار وتلوينه مع أصدقائه.',
        'رسم آدم وأصدقاؤه على الجدار أشجاراً مورقةً، وطيوراً محلّقةً، وعباراتٍ جميلةً عن النظافة والتعاون والرفق، فصارت الحديقة كأنها لوحةٌ فنيةٌ نابضةٌ بالحياة.',
        'كلما مرّ أهل الحيّ وأطفاله بجانب الجدار الملوّن ابتسموا، وعرف آدم أن فرشاته الصغيرة صنعت بهجةً حقيقيةً بالتعاون والعمل الصالح.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_21',
      title: 'الشمس المبتسمة وصباح النشاط',
      description: 'قصة قصيرة جداً ومشرقة تشجّع الأطفال الصغار على الاستيقاظ المبكر بابتسامةٍ ونشاط.',
      categoryId: 'short',
      categoryLabel: 'قصص قصيرة جدًا',
      ageRange: '3–5 سنوات',
      readingTimeMinutes: 2,
      readingTimeGroup: 'short',
      moral: 'الاستيقاظ المبكر مع الذكر والابتسامة يجعل يومنا مباركاً ومليئاً بالحيوية.',
      paragraphs: [
        'أشرقت الشمس الذهبية في الصباح الباكر، وأرسلت أشعتها الدافئة لتوقظ الأزهار والطيور والأطفال النشيطين.',
        'استيقظ الطفل "عمر" مبكراً، وقال دعاء الاستيقاظ: "الحمد لله الذي أحيانا بعدما أماتنا وإليه النشور"، ثم توضأ وصلّى وتناول فطوره الصحيّ.',
        'خرج عمر إلى مدرسته بابتسامةٍ مشرقةٍ تشبه نور الشمس، فقضى يوماً ممتعاً مليئاً بالعلم واللعب والنشاط.',
      ],
    ),
    KidsStoryModel(
      id: 'ks_22',
      title: 'مفتاح مكتبة الحكمة',
      description: 'قصة شائقة للفئة العمرية 9–12 سنة عن ثلاثة طلاب حلّوا ألغازاً معرفية وأخلاقية للوصول إلى جناح المخطوطات النادرة.',
      categoryId: 'educational',
      categoryLabel: 'قصص تعليمية',
      ageRange: '9–12 سنة',
      readingTimeMinutes: 8,
      readingTimeGroup: 'long',
      moral: 'القراءة مفتاح العقول، والتواضع لطلب العلم يرفع شأن صاحبه.',
      isFeatured: true,
      paragraphs: [
        'في المدرسة العتيقة، أعلن أمين المكتبة الأستاذ "نديم" عن مسابقةٍ ثقافيةٍ كبرى، جائزتها الحصول على "مفتاح جناح الروّاد" الذي يضمّ أروع الموسوعات العلمية والتجارب التفاعلية.',
        'تطلّبت المسابقة الإجابة عن ثلاثة تحديات: التحدي الأول في دقة الملاحظة والبحث في الفهارس، والتحدي الثاني في التحقّق من صحة المعلومة ومصدرها، والتحدي الثالث في تلخيص فائدةٍ عمليةٍ تنفع طلاب المدرسة.',
        'اجتمع الفريق المكوّن من "حمزة" و"نور" و"جاد"، فقسّموا المهام بينهم بتواضعٍ ونظام؛ لم يتعجلوا في الإجابة، بل راجعوا أمهات الكتب والموسوعات العلمية وتثبّتوا من كل معلومة.',
        'وفي المرحلة الأخيرة، قدّم الفريق مشروعاً عملياً بعنوان "نادي القارئ الصغير" لمساعدة طلاب الصفوف الأولى على حبّ القراءة العربية الفصيحة.',
        'سلّمهم الأستاذ نديم المفتاح الذهبيّ قائلاً: "لقد أدركتم السرّ الحقيقيّ للمعرفة؛ فالعلم يبدأ بالقراءة والتثبّت، ويثمر حين نشاركه مع الآخرين بتواضعٍ وإخلاص."',
      ],
    ),
  ];

  static KidsStoryModel getStoryOfTheDay() {
    final now = DateTime.now();
    final daySeed = now.year * 1000 + now.month * 31 + now.day;
    return stories[daySeed % stories.length];
  }
}

class KidsStoriesPage extends StatefulWidget {
  const KidsStoriesPage({Key? key}) : super(key: key);

  @override
  State<KidsStoriesPage> createState() => _KidsStoriesPageState();
}

class _KidsStoriesPageState extends State<KidsStoriesPage> {
  static const String _favPrefsKey = 'rifq_kids_stories_favorites_v1';
  static const String _donePrefsKey = 'rifq_kids_stories_completed_v1';

  String _searchQuery = '';
  String _selectedCategory = 'all';
  String _selectedAge = 'all';
  String _selectedTimeGroup = 'all';
  bool _showFavoritesOnly = false;

  Set<String> _favoriteIds = {};
  Set<String> _completedIds = {};

  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadSavedState();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadSavedState() async {
    final prefs = await SharedPreferences.getInstance();
    final favs = prefs.getStringList(_favPrefsKey) ?? [];
    final done = prefs.getStringList(_donePrefsKey) ?? [];
    if (mounted) {
      setState(() {
        _favoriteIds = favs.toSet();
        _completedIds = done.toSet();
      });
    }
  }

  Future<void> _toggleFavorite(String id) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if (_favoriteIds.contains(id)) {
        _favoriteIds.remove(id);
      } else {
        _favoriteIds.add(id);
      }
    });
    await prefs.setStringList(_favPrefsKey, _favoriteIds.toList());
  }

  Future<void> _markCompleted(String id) async {
    if (_completedIds.contains(id)) return;
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _completedIds.add(id);
    });
    await prefs.setStringList(_donePrefsKey, _completedIds.toList());
  }

  List<KidsStoryModel> get _filteredStories {
    final q = _searchQuery.trim().toLowerCase();
    return KidsStoriesData.stories.where((story) {
      if (_showFavoritesOnly && !_favoriteIds.contains(story.id)) return false;
      if (_selectedCategory != 'all' && story.categoryId != _selectedCategory) return false;
      if (_selectedAge != 'all' && story.ageRange != _selectedAge) return false;
      if (_selectedTimeGroup != 'all' && story.readingTimeGroup != _selectedTimeGroup) return false;
      if (q.isNotEmpty) {
        final matchTitle = story.title.toLowerCase().contains(q);
        final matchDesc = story.description.toLowerCase().contains(q);
        final matchCat = story.categoryLabel.toLowerCase().contains(q);
        final matchMoral = story.moral.toLowerCase().contains(q);
        return matchTitle || matchDesc || matchCat || matchMoral;
      }
      return true;
    }).toList();
  }

  void _openStory(KidsStoryModel story) {
    _markCompleted(story.id);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => KidsStoryReaderScreen(
          story: story,
          isFavorite: _favoriteIds.contains(story.id),
          onToggleFavorite: () => _toggleFavorite(story.id),
        ),
      ),
    ).then((_) => setState(() {}));
  }

  void _openRandomStory() {
    final list = KidsStoriesData.stories;
    if (list.isEmpty) return;
    final rnd = Random().nextInt(list.length);
    _openStory(list[rnd]);
  }

  void _resetFilters() {
    setState(() {
      _searchQuery = '';
      _searchController.clear();
      _selectedCategory = 'all';
      _selectedAge = 'all';
      _selectedTimeGroup = 'all';
      _showFavoritesOnly = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final storyOfTheDay = KidsStoriesData.getStoryOfTheDay();
    final filtered = _filteredStories;
    final isDefaultView = _searchQuery.trim().isEmpty &&
        _selectedCategory == 'all' &&
        _selectedAge == 'all' &&
        _selectedTimeGroup == 'all' &&
        !_showFavoritesOnly;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F5EE),
        appBar: AppBar(
          backgroundColor: const Color(0xFFF5F0E8),
          elevation: 0,
          foregroundColor: const Color(0xFF1E1B4B),
          title: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'قصص الأطفال',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontWeight: FontWeight.w800,
                  fontSize: 19,
                  color: Color(0xFF1E1B4B),
                ),
              ),
              Text(
                'حكايات ممتعة ومفيدة قبل النوم وفي كل وقت',
                style: TextStyle(
                  fontFamily: 'Cairo',
                  fontSize: 11,
                  color: Color(0xFF5A5575),
                ),
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'قصة عشوائية',
              onPressed: _openRandomStory,
              icon: const Icon(Icons.shuffle_rounded, color: Color(0xFF4F46E5)),
            ),
            IconButton(
              tooltip: 'المفضلة',
              onPressed: () {
                setState(() {
                  _showFavoritesOnly = !_showFavoritesOnly;
                });
              },
              icon: Icon(
                _showFavoritesOnly ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: _showFavoritesOnly ? Colors.pinkAccent : const Color(0xFF4F46E5),
              ),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Search Box
            TextField(
              controller: _searchController,
              onChanged: (val) => setState(() => _searchQuery = val),
              decoration: InputDecoration(
                hintText: 'ابحث عن قصة بالعنوان أو الموضوع أو القيمة...',
                prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF4F46E5)),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear_rounded),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFFE6DFD3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: const BorderSide(color: Color(0xFFE6DFD3)),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Category Filter Chips
            SizedBox(
              height: 42,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: KidsStoriesData.categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final cat = KidsStoriesData.categories[index];
                  final isSelected = _selectedCategory == cat['id'];
                  return ChoiceChip(
                    label: Text(
                      cat['label']!,
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        color: isSelected ? Colors.white : const Color(0xFF2E2A4A),
                      ),
                    ),
                    selected: isSelected,
                    selectedColor: const Color(0xFF4F46E5),
                    backgroundColor: Colors.white,
                    onSelected: (_) {
                      setState(() => _selectedCategory = cat['id']!);
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 10),

            // Age Filter Row
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  const Text(
                    'العمر: ',
                    style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold, fontSize: 12),
                  ),
                  for (final age in ['all', '3–5 سنوات', '6–8 سنوات', '9–12 سنة'])
                    Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: ActionChip(
                        backgroundColor: _selectedAge == age
                            ? const Color(0xFFC9A84C)
                            : Colors.white,
                        label: Text(
                          age == 'all' ? 'كل الأعمار' : age,
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: _selectedAge == age ? Colors.white : const Color(0xFF2E2A4A),
                          ),
                        ),
                        onPressed: () => setState(() => _selectedAge = age),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Story of the Day Card
            if (isDefaultView) ...[
              InkWell(
                onTap: () => _openStory(storyOfTheDay),
                borderRadius: BorderRadius.circular(24),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF312E81), Color(0xFF4F46E5)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF4F46E5).withOpacity(0.22),
                        blurRadius: 14,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF59E0B).withOpacity(0.25),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text(
                          'قصة اليوم المميزة',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFFFDE68A),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        storyOfTheDay.title,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        storyOfTheDay.description,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: 13,
                          color: Color(0xFFE0E7FF),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${storyOfTheDay.ageRange} • ${storyOfTheDay.readingTimeMinutes} دقائق',
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFFFDE68A),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF59E0B),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: const Text(
                              'اقرأ قصة اليوم',
                              style: TextStyle(
                                fontFamily: 'Cairo',
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
            ],

            // Stories List or Empty State
            if (filtered.isEmpty)
              Container(
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFFEAE2D3)),
                ),
                child: Column(
                  children: [
                    const Icon(Icons.menu_book_rounded, size: 48, color: Color(0xFF4F46E5)),
                    const SizedBox(height: 12),
                    Text(
                      _showFavoritesOnly
                          ? 'لا توجد قصص في المفضلة حتى الآن'
                          : 'لم نجد قصصاً مطابقة لبحثك',
                      style: const TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: _resetFilters,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4F46E5),
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('عرض جميع القصص'),
                    ),
                  ],
                ),
              )
            else
              ...filtered.map((story) {
                final isFav = _favoriteIds.contains(story.id);
                final isDone = _completedIds.contains(story.id);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: InkWell(
                    onTap: () => _openStory(story),
                    borderRadius: BorderRadius.circular(22),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: const Color(0xFFEAE2D3)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.03),
                            blurRadius: 8,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEEF2FF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  story.categoryLabel,
                                  style: const TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF4F46E5),
                                  ),
                                ),
                              ),
                              Row(
                                children: [
                                  if (isDone)
                                    const Padding(
                                      padding: EdgeInsets.only(left: 6),
                                      child: Icon(
                                        Icons.check_circle_rounded,
                                        size: 18,
                                        color: Colors.teal,
                                      ),
                                    ),
                                  IconButton(
                                    constraints: const BoxConstraints(),
                                    padding: EdgeInsets.zero,
                                    icon: Icon(
                                      isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                      color: isFav ? Colors.pinkAccent : Colors.grey,
                                      size: 22,
                                    ),
                                    onPressed: () => _toggleFavorite(story.id),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            story.title,
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF1E1B4B),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            story.description,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontSize: 13,
                              height: 1.5,
                              color: Color(0xFF5A5575),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${story.ageRange} • ${story.readingTimeMinutes} دقائق',
                                style: const TextStyle(
                                  fontFamily: 'Cairo',
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF8A7132),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEEF2FF),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Text(
                                  'اقرأ القصة',
                                  style: TextStyle(
                                    fontFamily: 'Cairo',
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF4F46E5),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class KidsStoryReaderScreen extends StatefulWidget {
  final KidsStoryModel story;
  final bool isFavorite;
  final VoidCallback onToggleFavorite;

  const KidsStoryReaderScreen({
    Key? key,
    required this.story,
    required this.isFavorite,
    required this.onToggleFavorite,
  }) : super(key: key);

  @override
  State<KidsStoryReaderScreen> createState() => _KidsStoryReaderScreenState();
}

class _KidsStoryReaderScreenState extends State<KidsStoryReaderScreen> {
  late KidsStoryModel _currentStory;
  late bool _isFav;
  double _fontSize = 20.0;

  @override
  void initState() {
    super.initState();
    _currentStory = widget.story;
    _isFav = widget.isFavorite;
  }

  void _shareStory() {
    final text =
        '📚 قصة: ${_currentStory.title}\n\n${_currentStory.description}\n\n💡 ماذا تعلمنا؟\n${_currentStory.moral}\n\n— من قسم قصص الأطفال في تطبيق رِفْق';
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم نسخ القصة والفائدة لمشاركتها')),
    );
  }

  void _pickAnotherStory() {
    final pool = KidsStoriesData.stories.where((s) => s.id != _currentStory.id).toList();
    if (pool.isEmpty) return;
    final next = pool[Random().nextInt(pool.length)];
    setState(() {
      _currentStory = next;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F5EE),
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0.5,
          foregroundColor: const Color(0xFF1E1B4B),
          title: Text(
            _currentStory.title,
            style: const TextStyle(
              fontFamily: 'Cairo',
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.remove_circle_outline_rounded),
              onPressed: () => setState(() => _fontSize = max(16.0, _fontSize - 2)),
            ),
            IconButton(
              icon: const Icon(Icons.add_circle_outline_rounded),
              onPressed: () => setState(() => _fontSize = min(28.0, _fontSize + 2)),
            ),
            IconButton(
              icon: Icon(
                _isFav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: _isFav ? Colors.pinkAccent : const Color(0xFF4F46E5),
              ),
              onPressed: () {
                widget.onToggleFavorite();
                setState(() => _isFav = !_isFav);
              },
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: const Color(0xFFEAE2D3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Chip(
                        backgroundColor: const Color(0xFFEEF2FF),
                        label: Text(
                          _currentStory.categoryLabel,
                          style: const TextStyle(
                            fontFamily: 'Cairo',
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF4F46E5),
                          ),
                        ),
                      ),
                      Chip(
                        backgroundColor: const Color(0xFFFAF7F0),
                        label: Text(
                          'العمر: ${_currentStory.ageRange}',
                          style: const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                        ),
                      ),
                      Chip(
                        backgroundColor: const Color(0xFFFAF7F0),
                        label: Text(
                          'الوقت: ${_currentStory.readingTimeMinutes} دقائق',
                          style: const TextStyle(fontFamily: 'Cairo', fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _currentStory.title,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1E1B4B),
                    ),
                  ),
                  const Divider(height: 28),
                  for (final p in _currentStory.paragraphs)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 18),
                      child: Text(
                        p,
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontSize: _fontSize,
                          height: 1.95,
                          color: const Color(0xFF221F3B),
                        ),
                      ),
                    ),
                  const SizedBox(height: 8),
                  const Center(
                    child: Chip(
                      backgroundColor: Color(0xFFFFFBEB),
                      label: Text(
                        '✨ النهاية ✨',
                        style: TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF92400E),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Moral Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                color: const Color(0xFFEEF2FF),
                border: Border.all(color: const Color(0xFFC9A84C), width: 1.5),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '💡 ماذا تعلمنا من القصة؟',
                    style: TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF312E81),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _currentStory.moral,
                    style: const TextStyle(
                      fontFamily: 'Cairo',
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      height: 1.6,
                      color: Color(0xFF1E1B4B),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Bottom Actions
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _shareStory,
                    icon: const Icon(Icons.share_rounded),
                    label: const Text('مشاركة القصة'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _pickAnotherStory,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF4F46E5),
                      foregroundColor: Colors.white,
                    ),
                    icon: const Icon(Icons.shuffle_rounded),
                    label: const Text('قصة أخرى'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
