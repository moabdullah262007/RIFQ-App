import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/alarm_database_helper.dart';
import '../../services/alarm_service.dart';
import 'alarm_setup_screen.dart';
import 'challenge_screen.dart';

class SmartAlarmListScreen extends StatefulWidget {
  const SmartAlarmListScreen({Key? key}) : super(key: key);

  @override
  State<SmartAlarmListScreen> createState() => _SmartAlarmListScreenState();
}

class _SmartAlarmListScreenState extends State<SmartAlarmListScreen> {
  final AlarmDatabaseHelper _dbHelper = AlarmDatabaseHelper();
  final AlarmService _alarmService = AlarmService();

  List<Map<String, dynamic>> _alarms = [];
  bool _isLoading = true;

  static const Color colorPrimaryWhite = Color(0xFFFFFFFF);
  static const Color colorBackgroundBeige = Color(0xFFF7F7FC);
  static const Color colorAccentGold = Color(0xFF5B5FEF);
  static const Color colorTextDarkBrown = Color(0xFF25263A);
  static const Color colorTextSecondaryGray = Color(0xFF77798C);

  @override
  void initState() {
    super.initState();
    _loadAlarms();
  }

  Future<void> _loadAlarms() async {
    setState(() => _isLoading = true);
    final data = await _dbHelper.getAlarms();
    setState(() {
      _alarms = data;
      _isLoading = false;
    });
  }

  Future<void> _toggleAlarm(int id, bool currentStatus) async {
    HapticFeedback.lightImpact();
    final newStatus = !currentStatus;
    await _dbHelper.toggleAlarm(id, newStatus);
    final alarm = _alarms.firstWhere((a) => a['id'] == id);

    if (newStatus) {
      await _alarmService.scheduleSmartAlarm(
        id: id,
        hour: alarm['hour'],
        minute: alarm['minute'],
        challengeType: alarm['challenge_type'],
        difficulty: alarm['difficulty'],
        sound: alarm['sound'],
      );
    } else {
      await _alarmService.cancelAlarm(id);
    }

    _loadAlarms();
  }

  Future<void> _deleteAlarm(int id) async {
    HapticFeedback.mediumImpact();
    await _alarmService.cancelAlarm(id);
    await _dbHelper.deleteAlarm(id);
    _loadAlarms();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم حذف المنبه بنجاح', style: TextStyle(fontFamily: 'Cairo')),
          backgroundColor: colorTextDarkBrown,
        ),
      );
    }
  }

  String _formatTime(int hour, int minute) {
    final period = hour >= 12 ? 'م' : 'ص';
    final h = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
    final m = minute.toString().padLeft(2, '0');
    return '$h:$m $period';
  }

  String _getChallengeTitle(String type) {
    switch (type) {
      case 'math':
        return '🧮 رياضيات';
      case 'memory':
        return '🎴 ذاكرة';
      case 'shake':
        return '📳 رجّ الجهاز';
      case 'religious':
        return '🕌 سؤال ديني';
      default:
        return '🎲 عشوائي';
    }
  }

  String _getSoundTitle(String sound) {
    switch (sound) {
      case 'adhan_fajr':
        return 'أذان الفجر';
      case 'custom':
        return 'صوت مخصص';
      default:
        return 'تنبيه هادئ';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBackgroundBeige,
        appBar: AppBar(
          backgroundColor: colorPrimaryWhite,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: colorAccentGold, size: 22),
            onPressed: () => Navigator.pop(context),
          ),
          centerTitle: true,
          title: const Text(
            'المنبّه الذكي 🧠',
            style: TextStyle(
              color: colorAccentGold,
              fontWeight: FontWeight.w900,
              fontSize: 20,
              fontFamily: 'Cairo',
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.add_circle_outline_rounded, color: colorAccentGold, size: 28),
              tooltip: 'إضافة منبه',
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AlarmSetupScreen()),
                );
                if (result == true) _loadAlarms();
              },
            ),
            const SizedBox(width: 8),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1.5),
            child: Container(color: colorAccentGold.withOpacity(0.3), height: 1.5),
          ),
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator(color: colorAccentGold))
            : _alarms.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                    itemCount: _alarms.length,
                    itemBuilder: (context, index) {
                      final alarm = _alarms[index];
                      return _buildAlarmCard(alarm);
                    },
                  ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: colorAccentGold,
          onPressed: () async {
            final result = await Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AlarmSetupScreen()),
            );
            if (result == true) _loadAlarms();
          },
          icon: const Icon(Icons.alarm_add_rounded, color: Colors.white),
          label: const Text(
            'إضافة منبّه',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontFamily: 'Cairo',
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: colorPrimaryWhite,
                shape: BoxShape.circle,
                border: Border.all(color: colorAccentGold.withOpacity(0.4), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: colorAccentGold.withOpacity(0.15),
                    blurRadius: 16,
                  ),
                ],
              ),
              alignment: Alignment.center,
              child: const Text('⏰', style: TextStyle(fontSize: 44)),
            ),
            const SizedBox(height: 24),
            const Text(
              'لا توجد منبّهات بعد',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: colorTextDarkBrown,
                fontFamily: 'Cairo',
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'اضبط منبهك الذكي واستيقظ بنشاط عبر إكمال تحديات الاستيقاظ المباركة',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: colorTextSecondaryGray,
                fontFamily: 'Cairo',
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: colorAccentGold,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AlarmSetupScreen()),
                );
                if (result == true) _loadAlarms();
              },
              icon: const Icon(Icons.add_rounded),
              label: const Text(
                '+ إضافة منبّه',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Cairo'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAlarmCard(Map<String, dynamic> alarm) {
    final bool isActive = (alarm['is_active'] ?? 1) == 1;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: colorPrimaryWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isActive ? colorAccentGold : Colors.grey.shade300,
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row 1: Time + Active Switch
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Text('⏰ ', style: TextStyle(fontSize: 22)),
                  Text(
                    _formatTime(alarm['hour'], alarm['minute']),
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Cairo',
                      color: isActive ? colorTextDarkBrown : Colors.grey,
                    ),
                  ),
                ],
              ),
              Switch(
                value: isActive,
                activeColor: colorAccentGold,
                onChanged: (_) => _toggleAlarm(alarm['id'], isActive),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Divider(height: 1, color: colorAccentGold.withOpacity(0.2)),
          const SizedBox(height: 10),

          // Row 2: Details Badges
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              _buildBadge('📅 كل يوم'),
              _buildBadge(_getChallengeTitle(alarm['challenge_type'])),
              _buildBadge('🎵 ${_getSoundTitle(alarm['sound'])}'),
            ],
          ),
          const SizedBox(height: 14),

          // Row 3: Action Buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // زر تجربة التحدي الآن
              TextButton.icon(
                style: TextButton.styleFrom(
                  backgroundColor: colorBackgroundBeige,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                icon: const Icon(Icons.play_circle_outline_rounded, size: 18, color: colorAccentGold),
                label: const Text(
                  'اختبر التحدي',
                  style: TextStyle(
                    color: colorTextDarkBrown,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                    fontFamily: 'Cairo',
                  ),
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChallengeScreen(
                        alarmId: alarm['id'],
                        challengeType: alarm['challenge_type'],
                        difficulty: alarm['difficulty'],
                        sound: alarm['sound'],
                      ),
                    ),
                  );
                },
              ),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit_outlined, size: 20, color: colorAccentGold),
                    tooltip: 'تعديل',
                    onPressed: () async {
                      final result = await Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => AlarmSetupScreen(existingAlarm: alarm),
                        ),
                      );
                      if (result == true) _loadAlarms();
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline_rounded, size: 20, color: Color(0xFFD95C6A)),
                    tooltip: 'حذف',
                    onPressed: () => _deleteAlarm(alarm['id']),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBadge(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: colorBackgroundBeige,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: colorAccentGold.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 11.5,
          fontWeight: FontWeight.bold,
          color: colorTextDarkBrown,
          fontFamily: 'Cairo',
        ),
      ),
    );
  }
}
