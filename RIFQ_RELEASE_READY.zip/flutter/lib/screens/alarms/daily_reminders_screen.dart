import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/notification_manager.dart';
import '../settings/notification_settings_page.dart';

/// شاشة التذكيرات اليومية للأدعية والتسبيح في تطبيق «مسبحة رفيق المسلم — رِفْق | RIFQ»
/// تتيح للمستخدم ضبط أوقات محددة لتذكيرات الأذكار والأدعية والتسبيح اليومي مع احترام تفضيلاته وساعات الهدوء.
class DailyRemindersScreen extends StatefulWidget {
  const DailyRemindersScreen({Key? key}) : super(key: key);

  @override
  State<DailyRemindersScreen> createState() => _DailyRemindersScreenState();
}

class _DailyRemindersScreenState extends State<DailyRemindersScreen>
    with WidgetsBindingObserver {
  static const Color colorGold = Color(0xFF5B5FEF);
  static const Color colorBeige = Color(0xFFF7F7FC);
  static const Color colorBrown = Color(0xFF25263A);
  static const Color colorGray = Color(0xFF77798C);
  static const Color colorGreen = Color(0xFF4CAF82);

  bool _masterEnabled = false;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;
  bool _quietHoursEnabled = false;
  TimeOfDay _quietStart = const TimeOfDay(hour: 23, minute: 0);
  TimeOfDay _quietEnd = const TimeOfDay(hour: 4, minute: 30);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _syncPermissionState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _syncPermissionState();
    }
  }

  Future<void> _syncPermissionState() async {
    final enabled = await NotificationManager.areNotificationsEnabled();
    if (mounted) {
      setState(() => _masterEnabled = enabled);
    }
  }

  Future<void> _scheduleOrCancelReminder(int index) async {
    final item = _reminders[index];
    final bool enabled = item['enabled'] as bool;
    final TimeOfDay time = item['time'] as TimeOfDay;
    final int notifId = 4100 + index;

    if (!enabled || !_masterEnabled) {
      await NotificationManager.cancelNotification(notifId);
      return;
    }

    final now = DateTime.now();
    final scheduled = DateTime(now.year, now.month, now.day, time.hour, time.minute);
    await NotificationManager.scheduleNotification(
      id: notifId,
      title: item['title'] as String,
      body: item['text'] as String,
      scheduledTime: scheduled,
      channelId: NotificationManager.azkarChannelId,
      channelName: 'أذكار',
      repeatDaily: true,
    );
  }

  final List<Map<String, dynamic>> _reminders = [
    {
      'id': 'morning_athkar',
      'title': 'أذكار الصباح المباركة',
      'text': 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
      'time': const TimeOfDay(hour: 6, minute: 30),
      'target': 1,
      'enabled': true,
    },
    {
      'id': 'duha_tasbeeh',
      'title': 'ورد التسبيح اليومي (الضحى)',
      'text': 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
      'time': const TimeOfDay(hour: 9, minute: 30),
      'target': 100,
      'enabled': true,
    },
    {
      'id': 'dhuhr_istighfar',
      'title': 'ورد الاستغفار والتوبة',
      'text': 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ',
      'time': const TimeOfDay(hour: 13, minute: 30),
      'target': 100,
      'enabled': true,
    },
    {
      'id': 'evening_athkar',
      'title': 'أذكار المساء والتحصين',
      'text': 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ',
      'time': const TimeOfDay(hour: 17, minute: 30),
      'target': 1,
      'enabled': true,
    },
    {
      'id': 'night_salawat',
      'title': 'الصلاة على النبي ﷺ والدعاء الجامع',
      'text': 'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
      'time': const TimeOfDay(hour: 20, minute: 30),
      'target': 33,
      'enabled': true,
    },
    {
      'id': 'sleep_athkar',
      'title': 'أذكار النوم وخواتيم اليوم',
      'text': 'سُبْحَانَ اللَّهِ (٣٣) وَالْحَمْدُ لِلَّهِ (٣٣) وَاللَّهُ أَكْبَرُ (٣٤)',
      'time': const TimeOfDay(hour: 22, minute: 0),
      'target': 33,
      'enabled': true,
    },
  ];

  String _formatTime(TimeOfDay t) {
    final period = t.hour >= 12 ? 'م' : 'ص';
    final h12 = t.hourOfPeriod == 0 ? 12 : t.hourOfPeriod;
    final m = t.minute.toString().padLeft(2, '0');
    return '$h12:$m $period';
  }

  Future<void> _pickReminderTime(int index) async {
    final current = _reminders[index]['time'] as TimeOfDay;
    final picked = await showTimePicker(
      context: context,
      initialTime: current,
    );
    if (picked != null) {
      setState(() {
        _reminders[index]['time'] = picked;
      });
      await _scheduleOrCancelReminder(index);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: colorBrown,
          content: Text(
            'تم تحديث وقت «${_reminders[index]['title']}» إلى ${_formatTime(picked)}',
            style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
          ),
        ),
      );
    }
  }

  void _showAddReminderDialog() {
    final titleCtrl = TextEditingController();
    final textCtrl = TextEditingController();
    TimeOfDay selectedTime = const TimeOfDay(hour: 8, minute: 0);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: Padding(
                padding: EdgeInsets.only(
                  right: 20,
                  left: 20,
                  top: 20,
                  bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'إضافة تذكير يومي جديد للدعاء أو التسبيح',
                      style: TextStyle(
                        fontFamily: 'Cairo',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: colorBrown,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: titleCtrl,
                      decoration: InputDecoration(
                        labelText: 'عنوان التذكير (مثال: ورد الحوقلة)',
                        filled: true,
                        fillColor: colorBeige,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: textCtrl,
                      maxLines: 2,
                      decoration: InputDecoration(
                        labelText: 'نص الدعاء أو التسبيح',
                        filled: true,
                        fillColor: colorBeige,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: ctx,
                          initialTime: selectedTime,
                        );
                        if (picked != null) {
                          setModalState(() => selectedTime = picked);
                        }
                      },
                      icon: const Icon(Icons.access_time, color: colorGold),
                      label: Text(
                        'وقت التذكير: ${_formatTime(selectedTime)}',
                        style: const TextStyle(
                          fontFamily: 'Cairo',
                          fontWeight: FontWeight.bold,
                          color: colorBrown,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: colorGreen,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        if (titleCtrl.text.trim().isEmpty || textCtrl.text.trim().isEmpty) {
                          return;
                        }
                        setState(() {
                          _reminders.insert(0, {
                            'id': 'custom_${DateTime.now().millisecondsSinceEpoch}',
                            'title': titleCtrl.text.trim(),
                            'text': textCtrl.text.trim(),
                            'time': selectedTime,
                            'target': 100,
                            'enabled': true,
                          });
                        });
                        Navigator.pop(ctx);
                      },
                      child: const Text(
                        'حفظ موعد التذكير',
                        style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBeige,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: const IconThemeData(color: colorGold),
          title: const Text(
            'التذكيرات اليومية للأدعية والتسبيح',
            style: TextStyle(
              fontFamily: 'Cairo',
              fontWeight: FontWeight.bold,
              fontSize: 17,
              color: colorBrown,
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const NotificationSettingsPage(),
                  ),
                );
              },
              icon: const Icon(Icons.settings_outlined, color: colorGold),
              tooltip: 'إعدادات الإشعارات',
            ),
            IconButton(
              onPressed: _showAddReminderDialog,
              icon: const Icon(Icons.add_alarm_rounded, color: colorGold),
              tooltip: 'إضافة تذكير جديد',
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // بطاقة تفضيلات الإشعارات وساعات الهدوء
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: colorGold),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Expanded(
                        child: Text(
                          'تفضيلات التنبيه واحترام أوقات الهدوء',
                          style: TextStyle(
                            fontFamily: 'Cairo',
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: colorBrown,
                          ),
                        ),
                      ),
                      Switch(
                        value: _masterEnabled,
                        activeColor: colorGreen,
                        onChanged: (val) async {
                          if (val) {
                            final granted = await NotificationManager.requestPermission();
                            if (!granted) {
                              await NotificationManager.openNotificationSettings();
                            }
                            await _syncPermissionState();
                          } else {
                            setState(() => _masterEnabled = false);
                          }
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilterChip(
                        label: const Text('التنبيه الصوتي'),
                        selected: _soundEnabled,
                        selectedColor: colorBeige,
                        checkmarkColor: colorGreen,
                        onSelected: (v) => setState(() => _soundEnabled = v),
                      ),
                      FilterChip(
                        label: const Text('الاهتزاز'),
                        selected: _vibrationEnabled,
                        selectedColor: colorBeige,
                        checkmarkColor: colorGreen,
                        onSelected: (v) => setState(() => _vibrationEnabled = v),
                      ),
                      FilterChip(
                        label: Text(
                          _quietHoursEnabled
                              ? 'ساعات الهدوء (${_formatTime(_quietStart)} - ${_formatTime(_quietEnd)})'
                              : 'ساعات الهدوء (عدم الإزعاج)',
                        ),
                        selected: _quietHoursEnabled,
                        selectedColor: colorBeige,
                        checkmarkColor: colorGreen,
                        onSelected: (v) => setState(() => _quietHoursEnabled = v),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // قائمة التذكيرات المجدولة
            ...List.generate(_reminders.length, (index) {
              final item = _reminders[index];
              final bool enabled = item['enabled'] as bool;
              final TimeOfDay time = item['time'] as TimeOfDay;

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: enabled ? colorGold : colorGold.withOpacity(0.35),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            item['title'] as String,
                            style: const TextStyle(
                              fontFamily: 'Cairo',
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: colorBrown,
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () => _pickReminderTime(index),
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: colorBeige,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: colorGold),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.access_time, size: 16, color: colorGold),
                                const SizedBox(width: 4),
                                Text(
                                  _formatTime(time),
                                  style: const TextStyle(
                                    fontFamily: 'Cairo',
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                    color: colorBrown,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Switch(
                          value: enabled,
                          activeColor: colorGreen,
                          onChanged: (val) async {
                            HapticFeedback.lightImpact();
                            setState(() => _reminders[index]['enabled'] = val);
                            await _scheduleOrCancelReminder(index);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      item['text'] as String,
                      style: const TextStyle(
                        fontFamily: 'Amiri',
                        fontSize: 17,
                        color: colorBrown,
                        height: 1.5,
                      ),
                    ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
