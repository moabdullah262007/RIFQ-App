import 'dart:math';

// ── 🧮 1. منطق تحدي الرياضيات ──
class MathChallenge {
  int a = 0;
  int b = 0;
  int answer = 0;
  String operatorSymbol = '+';
  List<int> options = [];

  void generate(String difficulty) {
    final random = Random();
    switch (difficulty) {
      case 'easy':
        a = random.nextInt(40) + 5;
        b = random.nextInt(40) + 5;
        operatorSymbol = '+';
        answer = a + b;
        break;
      case 'medium':
        a = random.nextInt(75) + 15;
        b = random.nextInt(75) + 15;
        operatorSymbol = '+';
        answer = a + b;
        break;
      case 'hard':
        a = random.nextInt(15) + 3;
        b = random.nextInt(9) + 2;
        operatorSymbol = '×';
        answer = a * b;
        break;
      default:
        a = random.nextInt(50) + 10;
        b = random.nextInt(50) + 10;
        operatorSymbol = '+';
        answer = a + b;
    }

    // توليد 4 خيارات حقيقية فريدة وغير مكررة
    final generatedOptions = <int>{answer};
    while (generatedOptions.length < 4) {
      final delta = (random.nextInt(16) - 8);
      final wrong = answer + (delta == 0 ? 3 : delta);
      if (wrong != answer && wrong > 0) {
        generatedOptions.add(wrong);
      }
    }
    options = generatedOptions.toList()..shuffle();
  }
}

// ── 🎴 2. منطق تحدي الذاكرة (8 بطاقات - 4 أزواج) ──
class MemoryCard {
  final int id;
  final String symbol;
  bool isFlipped;
  bool isMatched;

  MemoryCard({
    required this.id,
    required this.symbol,
    this.isFlipped = false,
    this.isMatched = false,
  });
}

class MemoryChallenge {
  List<MemoryCard> cards = [];

  void generate() {
    final symbols = ['🕌', '📿', '📖', '🌙'];
    final list = <MemoryCard>[];
    int idCounter = 0;

    for (final sym in symbols) {
      list.add(MemoryCard(id: idCounter++, symbol: sym));
      list.add(MemoryCard(id: idCounter++, symbol: sym));
    }

    list.shuffle();
    cards = list;
  }

  bool get isAllMatched => cards.every((c) => c.isMatched);
}

// ── 🕌 3. أسئلة دينية حقيقية من مصادر موثقة ──
class ReligiousQuestion {
  final String question;
  final String correctAnswer;
  final List<String> options;
  final String source;

  ReligiousQuestion({
    required this.question,
    required this.correctAnswer,
    required this.options,
    required this.source,
  });
}

class ReligiousChallenge {
  static final List<ReligiousQuestion> allQuestions = [
    ReligiousQuestion(
      question: 'كم عدد أركان الإسلام؟',
      correctAnswer: '5',
      options: ['5', '6', '4', '7'],
      source: 'صحيح البخاري ومسلم',
    ),
    ReligiousQuestion(
      question: 'كم عدد أركان الإيمان؟',
      correctAnswer: '6',
      options: ['6', '5', '7', '4'],
      source: 'حديث جبريل عليه السلام في صحيح مسلم',
    ),
    ReligiousQuestion(
      question: 'في أي شهر هجري فُرض صيام رمضان المبارك؟',
      correctAnswer: 'شعبان (السنة 2 هـ)',
      options: ['شعبان (السنة 2 هـ)', 'رمضان (السنة 1 هـ)', 'رجب (السنة 2 هـ)', 'شوال (السنة 3 هـ)'],
      source: 'السيرة النبوية الصحيحة',
    ),
    ReligiousQuestion(
      question: 'كم عدد الصلوات المكتوبة في اليوم والليلة؟',
      correctAnswer: '5 صلوات',
      options: ['5 صلوات', '3 صلوات', '7 صلوات', '4 صلوات'],
      source: 'متفق عليه',
    ),
    ReligiousQuestion(
      question: 'ما هي أول آيات نزلت من القرآن الكريم؟',
      correctAnswer: '﴿اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ﴾',
      options: [
        '﴿اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ﴾',
        '﴿يَا أَيُّهَا الْمُدَّثِّرُ﴾',
        '﴿الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ﴾',
        '﴿إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ﴾'
      ],
      source: 'صحيح البخاري',
    ),
    ReligiousQuestion(
      question: 'ما هي أعظم آية في كتاب الله تعالى؟',
      correctAnswer: 'آية الكرسي',
      options: ['آية الكرسي', 'آخر سورة البقرة', 'آية الدين', 'الفاتحة'],
      source: 'صحيح مسلم عن أُبيّ بن كعب',
    ),
    ReligiousQuestion(
      question: 'كم عدد سور القرآن الكريم؟',
      correctAnswer: '114 سورة',
      options: ['114 سورة', '110 سور', '120 سورة', '112 سورة'],
      source: 'إجماع علماء الأمة',
    ),
  ];

  ReligiousQuestion getRandomQuestion() {
    final rand = Random();
    final q = allQuestions[rand.nextInt(allQuestions.length)];
    final shuffled = List<String>.from(q.options)..shuffle();
    return ReligiousQuestion(
      question: q.question,
      correctAnswer: q.correctAnswer,
      options: shuffled,
      source: q.source,
    );
  }
}
