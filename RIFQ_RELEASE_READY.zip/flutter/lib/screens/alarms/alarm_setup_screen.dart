import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/alarm_database_helper.dart';
import '../../services/alarm_service.dart';

class AlarmSetupScreen extends StatefulWidget {
  final Map<String, dynamic>? existingAlarm;

  const AlarmSetupScreen({Key? key, this.existingAlarm}) : super(key: key);

  @override
  State<AlarmSetupScreen> createState() => _AlarmSetupScreenState();
}

class _AlarmSetupScreenState extends State<AlarmSetupScreen> {
  final AlarmDatabaseHelper _dbHelper = AlarmDatabaseHelper();
  final AlarmService _alarmService = AlarmService();

  TimeOfDay _selectedTime = const TimeOfDay(hour: 4, minute: 30);
  String _repeatOption = 'daily'; // 'daily', 'sat', 'specific', 'custom'
  String _selectedSound = 'gentle'; // 'gentle', 'adhan_fajr', 'custom'
  String _challengeType = 'random'; // 'math', 'memory', 'shake', 'religious', 'random'
  String _difficulty = 'medium'; // 'easy', 'medium', 'hard'

  static const Color colorPrimaryWhite = Color(0xFFFFFFFF);
  static const Color colorBackgroundBeige = Color(0xFFF7F7FC);
  static const Color colorAccentGold = Color(0xFF5B5FEF);
  static const Color colorTextDarkBrown = Color(0xFF25263A);
  static const Color colorTextSecondaryGray = Color(0xFF77798C);

  @override
  void initState() {
    super.initState();
    if (widget.existingAlarm != null) {
      final a = widget.existingAlarm!;
      _selectedTime = TimeOfDay(hour: a['hour'], minute: a['minute']);
      _repeatOption = a['days'] ?? 'daily';
      _selectedSound = a['sound'] ?? 'gentle';
      _challengeType = a['challenge_type'] ?? 'random';
      _difficulty = a['difficulty'] ?? 'medium';
    }
  }

  Future<void> _pickTime() async {
    HapticFeedback.lightImpact();
    final picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(
              primary: colorAccentGold,
              onPrimary: Colors.white,
              surface: Colors.white,
              onSurface: colorTextDarkBrown,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() => _selectedTime = picked);
    }
  }

  Future<void> _saveAlarm() async {
    HapticFeedback.mediumImpact();

    final alarmData = {
      'hour': _selectedTime.hour,
      'minute': _selectedTime.minute,
      'days': _repeatOption,
      'sound': _selectedSound,
      'challenge_type': _challengeType,
      'difficulty': _difficulty,
      'is_active': 1,
      'created_at': DateTime.now().toIso8601String(),
    };

    int alarmId;
    if (widget.existingAlarm != null) {
      alarmId = widget.existingAlarm!['id'];
      await _dbHelper.updateAlarm(alarmId, alarmData);
    } else {
      alarmId = await _dbHelper.insertAlarm(alarmData);
    }

    // جدولة الإشعار الفعلي
    await _alarmService.scheduleSmartAlarm(
      id: alarmId,
      hour: _selectedTime.hour,
      minute: _selectedTime.minute,
      challengeType: _challengeType,
      difficulty: _difficulty,
      sound: _selectedSound,
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم حفظ المنبّه الذكي بنجاح ✅', style: TextStyle(fontFamily: 'Cairo')),
          backgroundColor: Color(0xFF4CAF82),
        ),
      );
      Navigator.pop(context, true);
    }
  }

  String _formatTime() {
    final period = _selectedTime.hour >= 12 ? 'م' : 'ص';
    final h = _selectedTime.hour > 12
        ? _selectedTime.hour - 12
        : (_selectedTime.hour == 0 ? 12 : _selectedTime.hour);
    final m = _selectedTime.minute.toString().padLeft(2, '0');
    return '$h:$m $period';
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.existingAlarm != null;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: colorBackgroundBeige,
        appBar: AppBar(
          backgroundColor: colorPrimaryWhite,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: colorAccentGold, size: 22),
            onPressed: () => Navigator.pop(context),
          ),
          centerTitle: true,
          title: Text(
            isEditing ? 'تعديل المنبّه' : 'إعداد منبّه جديد',
            style: const TextStyle(
              color: colorAccentGold,
              fontWeight: FontWeight.w900,
              fontSize: 20,
              fontFamily: 'Cairo',
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1.5),
            child: Container(color: colorAccentGold.withOpacity(0.3), height: 1.5),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
          children: [
            // 【1】الوقت المختار مع خط Cairo Bold 48px ذهبي
            Container(
              decoration: BoxDecoration(
                color: colorPrimaryWhite,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: colorAccentGold.withOpacity(0.4), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: colorAccentGold.withOpacity(0.08),
                    blurRadius: 10,
                  ),
                ],
              ),
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              child: Column(
                children: [
                  const Text(
                    'وقت الاستيقاظ',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: colorTextSecondaryGray,
                      fontFamily: 'Cairo',
                    ),
                  ),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: _pickTime,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                      decoration: BoxDecoration(
                        color: colorBackgroundBeige,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: colorAccentGold.withOpacity(0.5)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _formatTime(),
                            style: const TextStyle(
                              fontSize: 48,
                              fontWeight: FontWeight.w900,
                              color: colorAccentGold,
                              fontFamily: 'Cairo',
                              letterSpacing: -1,
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Icon(Icons.edit_time_rounded, color: colorAccentGold, size: 28),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'اضغط لتغيير وقت المنبه',
                    style: TextStyle(fontSize: 11, color: colorTextSecondaryGray, fontFamily: 'Cairo'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 【2】التكرار
            _buildSectionCard(
              title: '📅 التكرار',
              children: [
                _buildRadioOption('كل يوم', 'daily', _repeatOption, (v) => setState(() => _repeatOption = v)),
                _buildRadioOption('السبت فقط', 'sat', _repeatOption, (v) => setState(() => _repeatOption = v)),
                _buildRadioOption('أيام العمل (الأحد - الخميس)', 'specific', _repeatOption, (v) => setState(() => _repeatOption = v)),
                _buildRadioOption('مخصص', 'custom', _repeatOption, (v) => setState(() => _repeatOption = v)),
              ],
            ),
            const SizedBox(height: 16),

            // 【3】الصوت
            _buildSectionCard(
              title: '🎵 الصوت',
              children: [
                _buildRadioOption('تنبيه هادئ (افتراضي)', 'gentle', _selectedSound, (v) => setState(() => _selectedSound = v)),
                _buildRadioOption('أذان الفجر المبارك', 'adhan_fajr', _selectedSound, (v) => setState(() => _selectedSound = v)),
                _buildRadioOption('صوت مخصص من الجهاز', 'custom', _selectedSound, (v) => setState(() => _selectedSound = v)),
              ],
            ),
            const SizedBox(height: 16),

            // 【4】نوع التحدي
            _buildSectionCard(
              title: '🧠 نوع التحدّي لإيقاف المنبّه',
              children: [
                _buildRadioOption('🧮 رياضيات', 'math', _challengeType, (v) => setState(() => _challengeType = v)),
                _buildRadioOption('🎴 ذاكرة (مطابقة البطاقات)', 'memory', _challengeType, (v) => setState(() => _challengeType = v)),
                _buildRadioOption('📳 رجّ الجهاز (30 حركة)', 'shake', _challengeType, (v) => setState(() => _challengeType = v)),
                _buildRadioOption('🕌 سؤال ديني موثق', 'religious', _challengeType, (v) => setState(() => _challengeType = v)),
                _buildRadioOption('🎲 عشوائي (افتراضي)', 'random', _challengeType, (v) => setState(() => _challengeType = v)),
              ],
            ),
            const SizedBox(height: 16),

            // 【5】مستوى الصعوبة
            _buildSectionCard(
              title: '⚡ مستوى الصعوبة',
              children: [
                _buildRadioOption('سهل', 'easy', _difficulty, (v) => setState(() => _difficulty = v)),
                _buildRadioOption('متوسط (افتراضي)', 'medium', _difficulty, (v) => setState(() => _difficulty = v)),
                _buildRadioOption('صعب', 'hard', _difficulty, (v) => setState(() => _difficulty = v)),
              ],
            ),
            const SizedBox(height: 24),

            // 【6】زر "حفظ المنبّه" (ذهبي متدرج)
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: const LinearGradient(
                  colors: [Color(0xFF5B5FEF), Color(0xFFE8B84A)],
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                ),
                boxShadow: [
                  BoxShadow(
                    color: colorAccentGold.withOpacity(0.35),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: _saveAlarm,
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: Center(
                      child: Text(
                        'حفظ المنبّه ✨',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          fontFamily: 'Cairo',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionCard({required String title, required List<Widget> children}) {
    return Container(
      decoration: BoxDecoration(
        color: colorPrimaryWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colorAccentGold.withOpacity(0.35), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 6,
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: colorTextDarkBrown,
              fontFamily: 'Cairo',
            ),
          ),
          const SizedBox(height: 8),
          Divider(height: 1, color: colorAccentGold.withOpacity(0.2)),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    );
  }

  Widget _buildRadioOption(
    String label,
    String value,
    String currentValue,
    Function(String) onChanged,
  ) {
    final isSelected = value == currentValue;
    return InkWell(
      onTap: () {
        HapticFeedback.selectionClick();
        onChanged(value);
      },
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: isSelected ? colorAccentGold : Colors.grey,
              size: 20,
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                color: isSelected ? colorTextDarkBrown : colorTextSecondaryGray,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
