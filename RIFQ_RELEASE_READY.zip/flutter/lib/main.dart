import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'services/notification_manager.dart';
import 'services/permissions_service.dart';
import 'services/alarm_service.dart';
import 'screens/permissions_flow_screen.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize real NotificationManager & channels (does NOT request permission on startup)
  await NotificationManager.init();

  // Check current permissions state passively on resume/launch
  final permissionsService = PermissionsService();
  await permissionsService.initNotificationsPlugin();
  await permissionsService.checkAllPermissionsOnResume();

  final alarmService = AlarmService();
  await alarmService.init();

  runApp(const RifqApp());
}

class RifqApp extends StatelessWidget {
  const RifqApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'رِفْق | RIFQ',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        fontFamily: 'Cairo',
        primaryColor: const Color(0xFF5B5FEF),
        scaffoldBackgroundColor: const Color(0xFFF7F7FC),
        cardColor: const Color(0xFFFFFFFF),
        dividerColor: const Color(0xFFE6E6F0),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF5B5FEF),
          primary: const Color(0xFF5B5FEF),
          secondary: const Color(0xFF4145C7),
          tertiary: const Color(0xFFE8B84A),
          surface: const Color(0xFFFFFFFF),
          error: const Color(0xFFD95C6A),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
