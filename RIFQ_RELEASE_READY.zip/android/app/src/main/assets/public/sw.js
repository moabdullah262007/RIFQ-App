// Service Worker for RIFQ Companion (رِفْق | RIFQ)
// Handles Background Prayer Time Notifications, Pre-Prayer Alerts, Athkar, Ayah/Faida of the Day, Quran Wird, Duas & Custom Reminders
// Persists schedule & fired registry in IndexedDB so worker restarts never lose state or duplicate alerts.

const DB_NAME = 'rifq_sw_notifications_db';
const DB_VERSION = 1;
const STORE_NAME = 'sw_state';

let scheduledPrayers = [];
let scheduledItems = [];
let currentCityName = 'القاهرة';
let channelStates = {
  rifq_general: true,
  rifq_prayer: true,
  rifq_adhan: true,
  rifq_quran: true,
  rifq_adhkar: true,
  rifq_azkar: true,
  rifq_reminders: true,
  rifq_updates: true,
};
const firedKeys = new Set();
let stateLoaded = false;

function openSwDb() {
  return new Promise((resolve, reject) => {
    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME);
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    } catch (err) {
      reject(err);
    }
  });
}

async function saveSwStateToIdb() {
  try {
    const db = await openSwDb();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put(
      {
        scheduledPrayers,
        scheduledItems,
        currentCityName,
        channelStates,
        firedKeys: Array.from(firedKeys).slice(-400),
        updatedAt: Date.now(),
      },
      'current_schedule'
    );
  } catch {
    // ignore IndexedDB errors in private browsing
  }
}

async function loadSwStateFromIdb() {
  if (stateLoaded) return;
  stateLoaded = true;
  try {
    const db = await openSwDb();
    const data = await new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get('current_schedule');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    });
    if (data) {
      if (Array.isArray(data.scheduledPrayers)) scheduledPrayers = data.scheduledPrayers;
      if (Array.isArray(data.scheduledItems)) scheduledItems = data.scheduledItems;
      if (data.currentCityName) currentCityName = data.currentCityName;
      if (data.channelStates && typeof data.channelStates === 'object') {
        channelStates = { ...channelStates, ...data.channelStates };
      }
      if (Array.isArray(data.firedKeys)) {
        data.firedKeys.forEach((k) => firedKeys.add(k));
      }
    }
  } catch {
    // ignore
  }
}

function getLocalTodayStr() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(loadSwStateFromIdb());
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      self.clients.claim(),
      loadSwStateFromIdb().then(() => runAllBackgroundChecks()),
    ])
  );
});

/**
 * Checks synced prayer times (both main Adhan & pre-Adhan alerts) in the background
 */
async function checkBackgroundPrayerSchedule() {
  if (channelStates.rifq_adhan === false || channelStates.rifq_prayer === false) return;
  if (!scheduledPrayers || scheduledPrayers.length === 0) return;

  const now = Date.now();
  const todayStr = getLocalTodayStr();
  let stateChanged = false;

  for (const item of scheduledPrayers) {
    if (!item || !item.enabled || !item.timestamp) continue;

    // 1. Check Pre-Adhan ("الصلاة القادمة") reminder if enabled for this prayer
    if (item.preReminder && item.preReminderMinutes > 0 && item.key !== 'sunrise') {
      const preTimestamp = item.timestamp - item.preReminderMinutes * 60 * 1000;
      const preDiffMs = now - preTimestamp;
      const preSig = `${todayStr}_pre_${item.key}`;

      // Within 10 minutes of the pre-reminder timestamp and before actual prayer time
      if (
        preDiffMs >= 0 &&
        preDiffMs <= 10 * 60 * 1000 &&
        now < item.timestamp &&
        !firedKeys.has(preSig)
      ) {
        firedKeys.add(preSig);
        stateChanged = true;

        const preTitle = `اقترب موعد صلاة ${item.nameAr} ⏳`;
        const preBody = `تبقى حوالي ${item.preReminderMinutes} دقيقة على أذان ${item.nameAr} (${item.timeFormatted}) بتوقيت ${currentCityName}. استعد بالوضوء والصلاة.`;

        await self.registration
          .showNotification(preTitle, {
            body: preBody,
            icon: '/assets/icons/ic_notification.png',
            badge: '/assets/icons/ic_notification.png',
            tag: `prayer-${item.nameAr}-${todayStr}-pre`,
            renotify: true,
            lang: 'ar',
            dir: 'rtl',
            vibrate: [150, 80, 150],
            data: {
              screen: 'prayers',
              channelId: 'rifq_adhan',
              prayerKey: item.key,
              prayerNameAr: item.nameAr,
              cityName: currentCityName,
              timeFormatted: item.timeFormatted,
              signatureKey: preSig,
              url: '/?screen=prayers',
            },
          })
          .catch(() => {});

        notifyClientsFired(preSig, {
          title: preTitle,
          body: preBody,
          screen: 'prayers',
        });
      }
    }

    // 2. Check Main Prayer Adhan notification
    const diffMs = now - item.timestamp;
    const fireId = `${todayStr}_${item.key}`;

    // Resilient window: from exact prayer time up to 15 minutes after (in case device was dozing)
    if (diffMs >= 0 && diffMs <= 15 * 60 * 1000 && !firedKeys.has(fireId)) {
      firedKeys.add(fireId);
      stateChanged = true;

      const title = `حان الآن وقت صلاة ${item.nameAr} 🕌`;
      const body = `دخل الآن وقت صلاة ${item.nameAr} (${item.timeFormatted}) بتوقيت ${currentCityName} • حي على الصلاة، حي على الفلاح`;

      await self.registration
        .showNotification(title, {
          body,
          icon: '/assets/icons/ic_notification.png',
          badge: '/assets/icons/ic_notification.png',
          tag: `prayer-${item.nameAr}-${todayStr}-main`,
          renotify: true,
          lang: 'ar',
          dir: 'rtl',
          vibrate: [200, 100, 300, 100, 200],
          actions: [
            { action: 'play_adhan', title: '🔊 بدء الأذان' },
            { action: 'stop_adhan', title: '🔇 إيقاف الأذان' },
          ],
          data: {
            screen: 'prayers',
            channelId: 'rifq_adhan',
            prayerKey: item.key,
            prayerNameAr: item.nameAr,
            cityName: currentCityName,
            timeFormatted: item.timeFormatted,
            signatureKey: fireId,
            url: '/?screen=prayers',
          },
        })
        .catch(() => {});

      notifyClientsFired(fireId, {
        title,
        body,
        screen: 'prayers',
      });

      // Notify any open client windows so in-app popup notification with Adhan controls appears
      self.clients
        .matchAll({ type: 'window', includeUncontrolled: true })
        .then((clientList) => {
          for (const client of clientList) {
            client.postMessage({
              type: 'PRAYER_TIME_ENTERED',
              prayerKey: item.key,
              prayerNameAr: item.nameAr,
              cityName: currentCityName,
              timeStr: item.timeFormatted,
              signatureKey: fireId,
            });
          }
        })
        .catch(() => {});
    }
  }

  if (stateChanged) {
    await saveSwStateToIdb();
  }
}

/**
 * Checks all non-prayer scheduled notifications (Athkar, Ayah of the Day, Faida of the Day, Quran Wird, Duas, Reminders)
 */
async function checkBackgroundScheduledItems() {
  if (!scheduledItems || scheduledItems.length === 0) return;

  const now = Date.now();
  let stateChanged = false;

  for (const item of scheduledItems) {
    if (!item || !item.timestamp || !item.signatureKey) continue;

    // Respect channel enablement
    if (item.channelId && channelStates[item.channelId] === false) {
      continue;
    }

    if (firedKeys.has(item.signatureKey)) {
      continue;
    }

    const diffMs = now - item.timestamp;
    // Resilient window: from scheduled timestamp up to 60 minutes after
    if (diffMs >= 0 && diffMs <= 60 * 60 * 1000) {
      firedKeys.add(item.signatureKey);
      stateChanged = true;

      const targetUrl = item.screen
        ? `/?screen=${item.screen}${item.ward ? `&ward=${item.ward}` : ''}${
            item.dhikrId ? `&dhikrId=${item.dhikrId}` : ''
          }`
        : '/';

      await self.registration
        .showNotification(item.title, {
          body: item.body,
          icon: '/assets/icons/ic_notification.png',
          badge: '/assets/icons/ic_notification.png',
          tag: item.tag || `rifq-sched-${item.id}`,
          renotify: true,
          lang: 'ar',
          dir: 'rtl',
          vibrate: [120, 60, 160],
          data: {
            screen: item.screen,
            ward: item.ward,
            dhikrId: item.dhikrId,
            channelId: item.channelId || 'rifq_general',
            signatureKey: item.signatureKey,
            url: targetUrl,
          },
        })
        .catch(() => {});

      notifyClientsFired(item.signatureKey, {
        title: item.title,
        body: item.body,
        screen: item.screen,
        ward: item.ward,
        dhikrId: item.dhikrId,
      });
    }
  }

  if (stateChanged) {
    await saveSwStateToIdb();
  }
}

function notifyClientsFired(signatureKey, meta) {
  self.clients
    .matchAll({ type: 'window', includeUncontrolled: true })
    .then((clientList) => {
      for (const client of clientList) {
        client.postMessage({
          type: 'SW_NOTIFICATION_FIRED',
          signatureKey,
          ...(meta || {}),
        });
      }
    })
    .catch(() => {});
}

async function runAllBackgroundChecks() {
  await loadSwStateFromIdb();
  await checkBackgroundPrayerSchedule();
  await checkBackgroundScheduledItems();
}

// Run background check inside the Service Worker every 15 seconds while alive
setInterval(() => {
  runAllBackgroundChecks();
}, 15000);

// Support Periodic Background Sync when browser wakes the Service Worker
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'rifq-periodic-notifications') {
    event.waitUntil(runAllBackgroundChecks());
  }
});

// Support standard Web Push / FCM push events if received from a push server
self.addEventListener('push', (event) => {
  event.waitUntil(
    (async () => {
      await loadSwStateFromIdb();
      let payload = {
        title: 'رِفْق | RIFQ',
        body: 'لديك تذكير جديد من تطبيق رِفْق',
        tag: `rifq-push-${Date.now()}`,
        channelId: 'rifq_general',
        screen: 'home',
      };

      if (event.data) {
        try {
          const parsed = event.data.json();
          payload = {
            ...payload,
            ...(parsed.notification || {}),
            ...(parsed.data || {}),
            ...parsed,
          };
        } catch {
          payload.body = event.data.text() || payload.body;
        }
      }

      if (payload.channelId && channelStates[payload.channelId] === false) {
        return;
      }

      await self.registration.showNotification(payload.title, {
        body: payload.body,
        icon: '/assets/icons/ic_notification.png',
        badge: '/assets/icons/ic_notification.png',
        tag: payload.tag,
        renotify: true,
        lang: 'ar',
        dir: 'rtl',
        vibrate: [120, 60, 160],
        data: {
          screen: payload.screen,
          ward: payload.ward,
          dhikrId: payload.dhikrId,
          channelId: payload.channelId,
          url: payload.url || '/',
        },
      });
    })()
  );
});

self.addEventListener('message', (event) => {
  const payload = event.data;
  if (!payload || !payload.type) return;

  event.waitUntil(
    (async () => {
      await loadSwStateFromIdb();

      if (payload.type === 'SYNC_PRAYER_SCHEDULE') {
        scheduledPrayers = Array.isArray(payload.prayers) ? payload.prayers : [];
        if (payload.cityName) {
          currentCityName = payload.cityName;
        }
        if (typeof payload.adhanChannelEnabled === 'boolean') {
          channelStates.rifq_adhan = payload.adhanChannelEnabled;
        }
        if (Array.isArray(payload.alreadyFiredKeys)) {
          payload.alreadyFiredKeys.forEach((k) => firedKeys.add(k));
        }
        await saveSwStateToIdb();
        await checkBackgroundPrayerSchedule();
      } else if (payload.type === 'SYNC_FULL_SCHEDULE') {
        if (Array.isArray(payload.scheduleItems)) {
          scheduledItems = payload.scheduleItems;
        }
        if (payload.channels && typeof payload.channels === 'object') {
          channelStates = { ...channelStates, ...payload.channels };
        }
        if (Array.isArray(payload.firedKeys)) {
          payload.firedKeys.forEach((k) => firedKeys.add(k));
        }
        await saveSwStateToIdb();
        await runAllBackgroundChecks();
      } else if (payload.type === 'MARK_NOTIFICATION_FIRED') {
        if (payload.signatureKey) {
          firedKeys.add(payload.signatureKey);
          await saveSwStateToIdb();
        }
      } else if (payload.type === 'SHOW_PRAYER_NOTIFICATION') {
        if (channelStates.rifq_adhan === false && !payload.bypassChannelCheck) return;
        const title = payload.title || 'تذكير بوقت الصلاة 🕌';
        const body = payload.body || 'حان الآن موعد الصلاة.';
        await self.registration
          .showNotification(title, {
            body,
            icon: '/assets/icons/ic_notification.png',
            badge: '/assets/icons/ic_notification.png',
            tag: payload.tag || `prayer-notify-${Date.now()}`,
            renotify: true,
            lang: 'ar',
            dir: 'rtl',
            actions: [
              { action: 'play_adhan', title: '🔊 بدء الأذان' },
              { action: 'stop_adhan', title: '🔇 إيقاف الأذان' },
            ],
            data: {
              screen: 'prayers',
              channelId: 'rifq_adhan',
              prayerNameAr: payload.prayerNameAr || '',
              url: '/?screen=prayers',
            },
          })
          .catch(() => {});
      }
    })()
  );
});

self.addEventListener('notificationclick', (event) => {
  const action = event.action;
  const data = event.notification.data || {};
  const ward = data.ward;
  const screen = data.screen;
  const dhikrId = data.dhikrId;
  const prayerNameAr = data.prayerNameAr || '';
  const targetUrl = data.url || '/';

  if (action === 'stop_adhan') {
    event.notification.close();
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
        for (const client of clientList) {
          client.postMessage({
            type: 'ADHAN_CONTROL',
            command: 'stop',
            prayerNameAr,
          });
        }
      })
    );
    return;
  }

  if (action === 'play_adhan') {
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
        for (const client of clientList) {
          if ('focus' in client) {
            client.focus();
          }
          client.postMessage({
            type: 'ADHAN_CONTROL',
            command: 'play',
            prayerNameAr,
            cityName: data.cityName,
            timeStr: data.timeFormatted,
          });
          return;
        }
        if (self.clients.openWindow) {
          return self.clients.openWindow(targetUrl);
        }
      })
    );
    return;
  }

  event.notification.close();

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ('focus' in client) {
          client.focus();
          if (screen === 'prayers') {
            client.postMessage({ type: 'NAVIGATE_PRAYERS' });
          } else if (screen === 'moment_dhikr') {
            client.postMessage({ type: 'NAVIGATE_MOMENT_DHIKR', dhikrId });
          } else if (ward) {
            client.postMessage({ action: 'NAVIGATE_WARD', wardType: ward });
          } else if (screen) {
            client.postMessage({ type: 'NAVIGATE_SCREEN', screen, dhikrId });
          }
          return;
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});
