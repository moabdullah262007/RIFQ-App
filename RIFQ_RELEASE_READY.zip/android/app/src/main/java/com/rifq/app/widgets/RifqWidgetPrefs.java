package com.rifq.app.widgets;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * Thread-safe, atomic Native Data Layer for RIFQ Home Screen Widgets.
 *
 * Guarantees:
 * 1. Atomic increment (`synchronized (LOCK)`) so rapid "+ + + + +" taps on the Home Screen
 *    never lose a single count or suffer from race conditions.
 * 2. Per-widget instance configuration (`appWidgetId`) so multiple widgets on the Home Screen
 *    (e.g., Widget 1 = Prayer, Widget 2 = Dhikr, Widget 3 = Tasbeeh) maintain independent settings.
 * 3. Two-way delta queue (`pendingDeltaCount` + `pendingDhikrDeltasJson`) so increments performed
 *    while RIFQ is closed are atomically merged into localStorage & Firestore when RIFQ opens.
 * 4. Offline-first authentic data storage (never shows fake data or errors when offline).
 */
public class RifqWidgetPrefs {

    public static final String PREFS_NAME = "rifq_native_widgets_prefs";
    private static final Object LOCK = new Object();

    // Global synced user & tasbeeh keys
    public static final String KEY_ACTIVE_UID = "active_uid";
    public static final String KEY_TODAY_DATE = "today_date_str";
    public static final String KEY_TODAY_COUNT = "today_total_count";
    public static final String KEY_DAILY_GOAL = "daily_goal";
    public static final String KEY_STREAK_DAYS = "streak_days";
    public static final String KEY_LIFETIME_TOTAL = "lifetime_total";
    public static final String KEY_COMPLETED_ATHKAR_TODAY = "completed_athkar_today";
    public static final String KEY_ACTIVE_TASBEEH_DHIKR = "active_tasbeeh_dhikr";
    public static final String KEY_VIBRATION_ENABLED = "vibration_enabled";

    // Atomic pending delta queue for React <-> Firestore synchronization
    public static final String KEY_PENDING_DELTA_COUNT = "pending_delta_count";
    public static final String KEY_PENDING_DHIKR_DELTAS_JSON = "pending_dhikr_deltas_json";
    public static final String KEY_PENDING_DATE_STR = "pending_date_str";
    public static final String KEY_PENDING_UID = "pending_uid";
    public static final String KEY_LAST_NATIVE_MUTATION_AT = "last_native_mutation_at";

    // Synced Prayer & City keys
    public static final String KEY_CITY_NAME_AR = "city_name_ar";
    public static final String KEY_CITY_LAT_BITS = "city_lat_bits";
    public static final String KEY_CITY_LNG_BITS = "city_lng_bits";
    public static final String KEY_CALC_METHOD = "calc_method";
    public static final String KEY_MADHAB = "madhab";
    public static final String KEY_TIME_FORMAT = "time_format";
    public static final String KEY_HIJRI_ADJUSTMENT = "hijri_adjustment";
    public static final String KEY_MANUAL_OFFSETS_JSON = "manual_offsets_json";

    // Synced Athkar keys
    public static final String KEY_CUSTOM_ATHKAR_JSON = "custom_athkar_json";
    public static final String KEY_GLOBAL_DHIKR_INDEX = "global_dhikr_index";
    public static final String KEY_COPY_FEEDBACK_UNTIL_MS = "copy_feedback_until_ms";

    // Pending Pin Request keys
    public static final String KEY_PENDING_PIN_TYPE = "pending_pin_type";
    public static final String KEY_PENDING_PIN_SIZE = "pending_pin_size";
    public static final String KEY_PENDING_PIN_THEME = "pending_pin_theme";
    public static final String KEY_PENDING_PIN_DHIKR = "pending_pin_dhikr";
    public static final String KEY_PENDING_PIN_PRAYER = "pending_pin_prayer";
    public static final String KEY_PENDING_PIN_STATS_MODE = "pending_pin_stats_mode";
    public static final String KEY_PENDING_PIN_TIMESTAMP = "pending_pin_timestamp";
    public static final String KEY_LAST_PINNED_WIDGET_ID = "last_pinned_widget_id";
    public static final String KEY_LAST_PINNED_AT = "last_pinned_at";

    // Global default widget configuration persisted from Widget Settings page or RifqWidgetConfigActivity
    public static final String KEY_DEFAULT_WIDGET_TYPE = "default_widget_type";
    public static final String KEY_DEFAULT_WIDGET_SIZE = "default_widget_size";
    public static final String KEY_DEFAULT_WIDGET_THEME = "default_widget_theme";
    public static final String KEY_DEFAULT_TARGET_PRAYER = "default_target_prayer";
    public static final String KEY_DEFAULT_STATS_MODE = "default_stats_mode";
    public static final String KEY_DEFAULT_CUSTOM_DHIKR = "default_custom_dhikr";

    public static final String[] TASBEEH_PRESET_PHRASES = new String[]{
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "سُبْحَانَ اللَّهِ",
        "الْحَمْدُ لِلَّهِ",
        "اللَّهُ أَكْبَرُ",
        "لَا إِلَهَ إِلَّا اللَّهُ",
        "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
        "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
        "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ"
    };

    public static class BuiltInDhikr {
        public final String id;
        public final String text;
        public final String source;
        public final String virtue;
        public final int target;

        public BuiltInDhikr(String id, String text, String source, String virtue, int target) {
            this.id = id;
            this.text = text;
            this.source = source;
            this.virtue = virtue;
            this.target = target;
        }
    }

    /**
     * Authentic Quranic & Prophetic Athkar matching `/src/data/athkarData.ts`.
     */
    private static final BuiltInDhikr[] BUILT_IN_ATHKAR = new BuiltInDhikr[]{
        new BuiltInDhikr(
            "q-1",
            "الَّذِينَ آمَنُوا وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ اللَّهِ ۗ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ",
            "سورة الرعد - الآية 28",
            "سكينة القلب وطمأنينة النفس ورضا الرحمن",
            7
        ),
        new BuiltInDhikr(
            "s-2",
            "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
            "متفق عليه",
            "كلمتان خفيفتان على اللسان ثقيلتان في الميزان حبيبتان إلى الرحمن",
            100
        ),
        new BuiltInDhikr(
            "q-2",
            "وَالذَّاكِرِينَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتِ أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا",
            "سورة الأحزاب - الآية 35",
            "وعد الله بالمغفرة الواسعة والأجر العظيم",
            7
        ),
        new BuiltInDhikr(
            "q-3",
            "فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ",
            "سورة البقرة - الآية 152",
            "ذكر الله للعبد في الملأ الأعلى عند ذكره في الأرض",
            10
        ),
        new BuiltInDhikr(
            "s-1",
            "مَثَلُ الَّذِي يَذْكُرُ رَبَّهُ وَالَّذِي لَا يَذْكُرُ رَبَّهُ مَثَلُ الْحَيِّ وَالْمَيِّتِ",
            "صحيح البخاري",
            "حياة القلوب ونجاة النفوس من الغفلة",
            10
        ),
        new BuiltInDhikr(
            "s-3",
            "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            "متفق عليه",
            "كعدل عشر رقاب وكتبت له مائة حسنة ومحيت عنه مائة سيئة",
            100
        ),
        new BuiltInDhikr(
            "s-4",
            "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ",
            "متفق عليه",
            "كنز من كنوز الجنة",
            100
        ),
        new BuiltInDhikr(
            "s-5",
            "اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
            "صحيح مسلم",
            "من صلى عليّ صلاة صلى الله عليه بها عشراً",
            100
        )
    };

    public static class WidgetInstanceConfig {
        public final int appWidgetId;
        public final String type;         // "tasbeeh" | "prayer" | "dhikr" | "multi"
        public final String size;         // "auto" | "small" | "medium" | "large"
        public final String theme;        // "navy" | "gold" | "midnight" | "cream"
        public final String customDhikr;
        public final String targetPrayer; // "next" | "fajr" | "sunrise" | "dhuhr" | "asr" | "maghrib" | "isha"
        public final String statsMode;    // "today_count" | "streak" | "lifetime" | "completed_athkar"
        public final int dhikrIndex;

        public WidgetInstanceConfig(
            int appWidgetId,
            String type,
            String size,
            String theme,
            String customDhikr,
            String targetPrayer,
            String statsMode,
            int dhikrIndex
        ) {
            this.appWidgetId = appWidgetId;
            this.type = type;
            this.size = size;
            this.theme = theme;
            this.customDhikr = customDhikr;
            this.targetPrayer = targetPrayer != null && !targetPrayer.isEmpty() ? targetPrayer : "next";
            this.statsMode = statsMode != null && !statsMode.isEmpty() ? statsMode : "today_count";
            this.dhikrIndex = dhikrIndex;
        }
    }

    public static class TasbeehSnapshot {
        public final String uid;
        public final String todayDateStr;
        public final int todayCount;
        public final int dailyGoal;
        public final int streakDays;
        public final int lifetimeTotal;
        public final int completedAthkarToday;
        public final String activeDhikr;
        public final boolean vibrationEnabled;

        public TasbeehSnapshot(
            String uid,
            String todayDateStr,
            int todayCount,
            int dailyGoal,
            int streakDays,
            int lifetimeTotal,
            int completedAthkarToday,
            String activeDhikr,
            boolean vibrationEnabled
        ) {
            this.uid = uid;
            this.todayDateStr = todayDateStr;
            this.todayCount = todayCount;
            this.dailyGoal = dailyGoal;
            this.streakDays = streakDays;
            this.lifetimeTotal = lifetimeTotal;
            this.completedAthkarToday = completedAthkarToday;
            this.activeDhikr = activeDhikr;
            this.vibrationEnabled = vibrationEnabled;
        }
    }

    public static SharedPreferences getPrefs(Context context) {
        Context appCtx = context.getApplicationContext();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            Context deviceCtx = appCtx.createDeviceProtectedStorageContext();
            if (deviceCtx != null) {
                return deviceCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            }
        }
        return appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static String getTodayDateString() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /**
     * Ensures midnight rollover is handled cleanly if the date changed while RIFQ was closed.
     */
    private static void ensureDateRolloverLocked(SharedPreferences prefs) {
        String today = getTodayDateString();
        String storedDate = prefs.getString(KEY_TODAY_DATE, "");
        if (!today.equals(storedDate)) {
            prefs.edit()
                .putString(KEY_TODAY_DATE, today)
                .putInt(KEY_TODAY_COUNT, 0)
                .putInt(KEY_COMPLETED_ATHKAR_TODAY, 0)
                .apply();
        }
    }

    public static TasbeehSnapshot getTasbeehSnapshot(Context context) {
        synchronized (LOCK) {
            SharedPreferences prefs = getPrefs(context);
            ensureDateRolloverLocked(prefs);
            String uid = prefs.getString(KEY_ACTIVE_UID, "guest");
            String today = prefs.getString(KEY_TODAY_DATE, getTodayDateString());
            int todayCount = Math.max(0, prefs.getInt(KEY_TODAY_COUNT, 0));
            int dailyGoal = Math.max(1, prefs.getInt(KEY_DAILY_GOAL, 100));
            int streak = Math.max(0, prefs.getInt(KEY_STREAK_DAYS, 0));
            int lifetime = Math.max(todayCount, prefs.getInt(KEY_LIFETIME_TOTAL, todayCount));
            int completed = Math.max(0, prefs.getInt(KEY_COMPLETED_ATHKAR_TODAY, 0));
            String dhikr = prefs.getString(KEY_ACTIVE_TASBEEH_DHIKR, "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ");
            if (dhikr == null || dhikr.trim().isEmpty()) {
                dhikr = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ";
            }
            boolean vib = prefs.getBoolean(KEY_VIBRATION_ENABLED, true);
            return new TasbeehSnapshot(uid, today, todayCount, dailyGoal, streak, lifetime, completed, dhikr, vib);
        }
    }

    /**
     * Requirement 11: Race-condition-free atomic increment for rapid "+ + + + +" taps on the Home Screen.
     */
    public static TasbeehSnapshot incrementTasbeehAtomically(Context context, int delta, String customDhikr) {
        if (delta <= 0) delta = 1;
        synchronized (LOCK) {
            SharedPreferences prefs = getPrefs(context);
            ensureDateRolloverLocked(prefs);

            String today = getTodayDateString();
            String uid = prefs.getString(KEY_ACTIVE_UID, "guest");
            int prevCount = Math.max(0, prefs.getInt(KEY_TODAY_COUNT, 0));
            int nextCount = prevCount + delta;
            int prevLifetime = Math.max(prevCount, prefs.getInt(KEY_LIFETIME_TOTAL, 0));
            int nextLifetime = prevLifetime + delta;
            int streak = Math.max(0, prefs.getInt(KEY_STREAK_DAYS, 0));
            if (prevCount == 0 && nextCount > 0 && streak == 0) {
                streak = 1;
            }

            String dhikr = (customDhikr != null && !customDhikr.trim().isEmpty())
                ? customDhikr.trim()
                : prefs.getString(KEY_ACTIVE_TASBEEH_DHIKR, "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ");
            if (dhikr == null || dhikr.isEmpty()) {
                dhikr = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ";
            }

            // Update atomic delta queue for React/Firestore sync
            String pendingDate = prefs.getString(KEY_PENDING_DATE_STR, today);
            int prevPendingDelta = today.equals(pendingDate)
                ? Math.max(0, prefs.getInt(KEY_PENDING_DELTA_COUNT, 0))
                : 0;
            int nextPendingDelta = prevPendingDelta + delta;

            JSONObject dhikrDeltas;
            try {
                dhikrDeltas = today.equals(pendingDate)
                    ? new JSONObject(prefs.getString(KEY_PENDING_DHIKR_DELTAS_JSON, "{}"))
                    : new JSONObject();
            } catch (Exception e) {
                dhikrDeltas = new JSONObject();
            }
            try {
                int currentDhikrDelta = dhikrDeltas.optInt(dhikr, 0);
                dhikrDeltas.put(dhikr, currentDhikrDelta + delta);
            } catch (Exception ignored) {
            }

            long now = System.currentTimeMillis();
            // Use commit() inside synchronized block to guarantee immediate disk durability on rapid taps
            prefs.edit()
                .putString(KEY_TODAY_DATE, today)
                .putInt(KEY_TODAY_COUNT, nextCount)
                .putInt(KEY_LIFETIME_TOTAL, nextLifetime)
                .putInt(KEY_STREAK_DAYS, streak)
                .putString(KEY_ACTIVE_TASBEEH_DHIKR, dhikr)
                .putInt(KEY_PENDING_DELTA_COUNT, nextPendingDelta)
                .putString(KEY_PENDING_DHIKR_DELTAS_JSON, dhikrDeltas.toString())
                .putString(KEY_PENDING_DATE_STR, today)
                .putString(KEY_PENDING_UID, uid)
                .putLong(KEY_LAST_NATIVE_MUTATION_AT, now)
                .commit();

            int dailyGoal = Math.max(1, prefs.getInt(KEY_DAILY_GOAL, 100));
            int completed = Math.max(0, prefs.getInt(KEY_COMPLETED_ATHKAR_TODAY, 0));
            boolean vib = prefs.getBoolean(KEY_VIBRATION_ENABLED, true);

            return new TasbeehSnapshot(uid, today, nextCount, dailyGoal, streak, nextLifetime, completed, dhikr, vib);
        }
    }

    /**
     * Cycles the active Tasbeeh Dhikr phrase directly from the Home Screen Widget.
     */
    public static String cycleTasbeehDhikr(Context context, int appWidgetId) {
        synchronized (LOCK) {
            SharedPreferences prefs = getPrefs(context);
            String current = prefs.getString(KEY_ACTIVE_TASBEEH_DHIKR, TASBEEH_PRESET_PHRASES[0]);
            int foundIdx = 0;
            for (int i = 0; i < TASBEEH_PRESET_PHRASES.length; i++) {
                if (TASBEEH_PRESET_PHRASES[i].equals(current)) {
                    foundIdx = i;
                    break;
                }
            }
            String next = TASBEEH_PRESET_PHRASES[(foundIdx + 1) % TASBEEH_PRESET_PHRASES.length];
            prefs.edit().putString(KEY_ACTIVE_TASBEEH_DHIKR, next).commit();
            if (appWidgetId != 0) {
                prefs.edit().putString(widgetKey(appWidgetId, "custom_dhikr"), next).apply();
            }
            return next;
        }
    }

    /**
     * Atomically consumes pending widget increments so React can merge them into localStorage & Firestore
     * without double-applying or losing rapid taps.
     */
    public static JSONObject consumePendingIncrementsAtomically(Context context) {
        synchronized (LOCK) {
            SharedPreferences prefs = getPrefs(context);
            int pendingDelta = Math.max(0, prefs.getInt(KEY_PENDING_DELTA_COUNT, 0));
            String deltasJson = prefs.getString(KEY_PENDING_DHIKR_DELTAS_JSON, "{}");
            String dateStr = prefs.getString(KEY_PENDING_DATE_STR, getTodayDateString());
            String uid = prefs.getString(KEY_PENDING_UID, prefs.getString(KEY_ACTIVE_UID, "guest"));
            long mutatedAt = prefs.getLong(KEY_LAST_NATIVE_MUTATION_AT, 0L);

            if (pendingDelta > 0) {
                prefs.edit()
                    .putInt(KEY_PENDING_DELTA_COUNT, 0)
                    .putString(KEY_PENDING_DHIKR_DELTAS_JSON, "{}")
                    .commit();
            }

            JSONObject result = new JSONObject();
            try {
                result.put("pendingDeltaCount", pendingDelta);
                result.put("dhikrDeltas", new JSONObject(deltasJson));
                result.put("dateStr", dateStr);
                result.put("uid", uid);
                result.put("lastNativeMutationAt", mutatedAt);
                result.put("todayTotalCount", prefs.getInt(KEY_TODAY_COUNT, 0));
            } catch (Exception ignored) {
            }
            return result;
        }
    }

    /**
     * Syncs state from React/Firestore into Native Widget storage while preserving any unconsumed
     * native widget increments (`pendingDeltaCount`) so offline/background taps are never overwritten.
     */
    public static void syncStateFromApp(
        Context context,
        String uid,
        int appTodayCount,
        int dailyGoal,
        int streakDays,
        int lifetimeTotal,
        int completedAthkarToday,
        String activeDhikr,
        boolean vibrationEnabled,
        String cityNameAr,
        Double cityLat,
        Double cityLng,
        String calcMethod,
        String madhab,
        String timeFormat,
        Integer hijriAdjustment,
        String manualOffsetsJson,
        String customAthkarJson
    ) {
        synchronized (LOCK) {
            SharedPreferences prefs = getPrefs(context);
            String today = getTodayDateString();
            String prevUid = prefs.getString(KEY_ACTIVE_UID, "guest");
            String nextUid = (uid != null && !uid.trim().isEmpty()) ? uid.trim() : "guest";

            // Preserve any unconsumed native increments for the same user & day
            int unconsumedDelta = 0;
            if (nextUid.equals(prevUid) && today.equals(prefs.getString(KEY_PENDING_DATE_STR, today))) {
                unconsumedDelta = Math.max(0, prefs.getInt(KEY_PENDING_DELTA_COUNT, 0));
            } else if (!nextUid.equals(prevUid)) {
                // Account switched: reset pending delta for the new account context
                prefs.edit()
                    .putInt(KEY_PENDING_DELTA_COUNT, 0)
                    .putString(KEY_PENDING_DHIKR_DELTAS_JSON, "{}")
                    .commit();
            }

            int effectiveTodayCount = Math.max(0, appTodayCount) + unconsumedDelta;
            int effectiveLifetime = Math.max(effectiveTodayCount, Math.max(0, lifetimeTotal) + unconsumedDelta);

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(KEY_ACTIVE_UID, nextUid);
            editor.putString(KEY_TODAY_DATE, today);
            editor.putInt(KEY_TODAY_COUNT, effectiveTodayCount);
            editor.putInt(KEY_DAILY_GOAL, Math.max(1, dailyGoal));
            editor.putInt(KEY_STREAK_DAYS, Math.max(0, streakDays));
            editor.putInt(KEY_LIFETIME_TOTAL, effectiveLifetime);
            editor.putInt(KEY_COMPLETED_ATHKAR_TODAY, Math.max(0, completedAthkarToday));
            editor.putBoolean(KEY_VIBRATION_ENABLED, vibrationEnabled);

            if (activeDhikr != null && !activeDhikr.trim().isEmpty()) {
                editor.putString(KEY_ACTIVE_TASBEEH_DHIKR, activeDhikr.trim());
            }
            if (cityNameAr != null && !cityNameAr.trim().isEmpty()) {
                editor.putString(KEY_CITY_NAME_AR, cityNameAr.trim());
            }
            if (cityLat != null && cityLng != null) {
                editor.putLong(KEY_CITY_LAT_BITS, Double.doubleToLongBits(cityLat));
                editor.putLong(KEY_CITY_LNG_BITS, Double.doubleToLongBits(cityLng));
            }
            if (calcMethod != null && !calcMethod.isEmpty()) {
                editor.putString(KEY_CALC_METHOD, calcMethod);
            }
            if (madhab != null && !madhab.isEmpty()) {
                editor.putString(KEY_MADHAB, madhab);
            }
            if (timeFormat != null && !timeFormat.isEmpty()) {
                editor.putString(KEY_TIME_FORMAT, timeFormat);
            }
            if (hijriAdjustment != null) {
                editor.putInt(KEY_HIJRI_ADJUSTMENT, hijriAdjustment);
            }
            if (manualOffsetsJson != null) {
                editor.putString(KEY_MANUAL_OFFSETS_JSON, manualOffsetsJson);
            }
            if (customAthkarJson != null) {
                editor.putString(KEY_CUSTOM_ATHKAR_JSON, customAthkarJson);
            }
            editor.commit();
        }
    }

    /**
     * Returns all available Athkar (built-in authentic Athkar + user's synced custom Athkar).
     */
    public static List<BuiltInDhikr> getAllAvailableAthkar(Context context) {
        List<BuiltInDhikr> list = new ArrayList<>();
        for (BuiltInDhikr item : BUILT_IN_ATHKAR) {
            list.add(item);
        }
        try {
            String customJson = getPrefs(context).getString(KEY_CUSTOM_ATHKAR_JSON, "[]");
            JSONArray arr = new JSONArray(customJson);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                String text = obj.optString("text", "").trim();
                if (text.isEmpty()) continue;
                String id = obj.optString("id", "custom_" + i);
                String source = obj.optString("source", "وردي المخصص في رِفْق");
                String virtue = obj.optString("virtue", "ذكر مخصص");
                int target = obj.optInt("countTarget", 33);
                list.add(new BuiltInDhikr(id, text, source, virtue, target));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static BuiltInDhikr getCurrentDhikrForWidget(Context context, int appWidgetId) {
        List<BuiltInDhikr> all = getAllAvailableAthkar(context);
        if (all.isEmpty()) {
            return BUILT_IN_ATHKAR[0];
        }
        SharedPreferences prefs = getPrefs(context);
        // Check if a custom Dhikr text is explicitly configured for this widget or globally
        String customText = appWidgetId != 0
            ? prefs.getString(widgetKey(appWidgetId, "custom_dhikr"), "")
            : "";
        if (customText == null || customText.trim().isEmpty()) {
            customText = prefs.getString(KEY_DEFAULT_CUSTOM_DHIKR, "");
        }
        if (customText != null && !customText.trim().isEmpty() && !prefs.contains(widgetKey(appWidgetId, "dhikr_idx"))) {
            String trimmed = customText.trim();
            for (BuiltInDhikr item : all) {
                if (item.text.equals(trimmed)) {
                    return item;
                }
            }
            return new BuiltInDhikr("custom_selected", trimmed, "ورد مخصص في رِفْق", "ذكر مبارك مختار للويدجت", 100);
        }

        int defaultDailyIdx = Math.abs(getTodayDateString().hashCode()) % all.size();
        int idx;
        if (appWidgetId != 0 && prefs.contains(widgetKey(appWidgetId, "dhikr_idx"))) {
            idx = prefs.getInt(widgetKey(appWidgetId, "dhikr_idx"), defaultDailyIdx);
        } else {
            idx = prefs.getInt(KEY_GLOBAL_DHIKR_INDEX, defaultDailyIdx);
        }
        return all.get(Math.abs(idx) % all.size());
    }

    public static BuiltInDhikr advanceToNextDhikr(Context context, int appWidgetId) {
        synchronized (LOCK) {
            List<BuiltInDhikr> all = getAllAvailableAthkar(context);
            if (all.isEmpty()) return BUILT_IN_ATHKAR[0];
            SharedPreferences prefs = getPrefs(context);
            int currentIdx;
            if (appWidgetId != 0 && prefs.contains(widgetKey(appWidgetId, "dhikr_idx"))) {
                currentIdx = prefs.getInt(widgetKey(appWidgetId, "dhikr_idx"), 0);
            } else {
                currentIdx = prefs.getInt(KEY_GLOBAL_DHIKR_INDEX, 0);
            }
            int nextIdx = (Math.abs(currentIdx) + 1) % all.size();
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt(KEY_GLOBAL_DHIKR_INDEX, nextIdx);
            if (appWidgetId != 0) {
                editor.putInt(widgetKey(appWidgetId, "dhikr_idx"), nextIdx);
            }
            editor.commit();
            return all.get(nextIdx);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Global Default & Per-Widget Instance Configuration (SharedPreferences)
    // ═══════════════════════════════════════════════════════════════════════════

    private static String widgetKey(int appWidgetId, String suffix) {
        return "widget_" + appWidgetId + "_" + suffix;
    }

    public static WidgetInstanceConfig getGlobalDefaultConfig(Context context) {
        SharedPreferences prefs = getPrefs(context);
        String type = prefs.getString(KEY_DEFAULT_WIDGET_TYPE, "tasbeeh");
        String size = prefs.getString(KEY_DEFAULT_WIDGET_SIZE, "medium");
        String theme = prefs.getString(KEY_DEFAULT_WIDGET_THEME, "navy");
        String customDhikr = prefs.getString(
            KEY_DEFAULT_CUSTOM_DHIKR,
            prefs.getString(KEY_ACTIVE_TASBEEH_DHIKR, TASBEEH_PRESET_PHRASES[0])
        );
        String targetPrayer = prefs.getString(KEY_DEFAULT_TARGET_PRAYER, "next");
        String statsMode = prefs.getString(KEY_DEFAULT_STATS_MODE, "today_count");
        int dhikrIdx = prefs.getInt(KEY_GLOBAL_DHIKR_INDEX, 0);
        return new WidgetInstanceConfig(0, type, size, theme, customDhikr, targetPrayer, statsMode, dhikrIdx);
    }

    public static void saveGlobalDefaultConfig(
        Context context,
        String type,
        String size,
        String theme,
        String customDhikr,
        String targetPrayer,
        String statsMode
    ) {
        synchronized (LOCK) {
            SharedPreferences.Editor editor = getPrefs(context).edit();
            if (type != null && !type.isEmpty()) {
                editor.putString(KEY_DEFAULT_WIDGET_TYPE, type);
            }
            if (size != null && !size.isEmpty()) {
                editor.putString(KEY_DEFAULT_WIDGET_SIZE, size);
            }
            if (theme != null && !theme.isEmpty()) {
                editor.putString(KEY_DEFAULT_WIDGET_THEME, theme);
            }
            if (customDhikr != null && !customDhikr.trim().isEmpty()) {
                editor.putString(KEY_DEFAULT_CUSTOM_DHIKR, customDhikr.trim());
                editor.putString(KEY_ACTIVE_TASBEEH_DHIKR, customDhikr.trim());
            }
            if (targetPrayer != null && !targetPrayer.isEmpty()) {
                editor.putString(KEY_DEFAULT_TARGET_PRAYER, targetPrayer);
            }
            if (statsMode != null && !statsMode.isEmpty()) {
                editor.putString(KEY_DEFAULT_STATS_MODE, statsMode);
            }
            editor.commit();
        }
    }

    public static WidgetInstanceConfig getWidgetConfig(Context context, int appWidgetId, String defaultType) {
        SharedPreferences prefs = getPrefs(context);
        String globalTheme = prefs.getString(KEY_DEFAULT_WIDGET_THEME, "navy");
        String globalSize = prefs.getString(KEY_DEFAULT_WIDGET_SIZE, "auto");
        String globalDhikr = prefs.getString(
            KEY_DEFAULT_CUSTOM_DHIKR,
            prefs.getString(KEY_ACTIVE_TASBEEH_DHIKR, "")
        );
        String globalPrayer = prefs.getString(KEY_DEFAULT_TARGET_PRAYER, "next");
        String globalStatsMode = prefs.getString(KEY_DEFAULT_STATS_MODE, "today_count");

        String fallbackType = (defaultType != null && !defaultType.isEmpty())
            ? defaultType
            : prefs.getString(KEY_DEFAULT_WIDGET_TYPE, "tasbeeh");

        String type = prefs.getString(widgetKey(appWidgetId, "type"), fallbackType);
        String size = prefs.getString(widgetKey(appWidgetId, "size"), globalSize);
        String theme = prefs.getString(widgetKey(appWidgetId, "theme"), globalTheme);
        String customDhikr = prefs.getString(widgetKey(appWidgetId, "custom_dhikr"), globalDhikr);
        String targetPrayer = prefs.getString(widgetKey(appWidgetId, "target_prayer"), globalPrayer);
        String statsMode = prefs.getString(widgetKey(appWidgetId, "stats_mode"), globalStatsMode);
        int dhikrIdx = prefs.getInt(widgetKey(appWidgetId, "dhikr_idx"), -1);
        return new WidgetInstanceConfig(
            appWidgetId,
            type,
            size,
            theme,
            customDhikr,
            targetPrayer,
            statsMode,
            dhikrIdx
        );
    }

    public static boolean hasWidgetConfig(Context context, int appWidgetId) {
        return getPrefs(context).contains(widgetKey(appWidgetId, "type"));
    }

    public static void saveWidgetConfig(
        Context context,
        int appWidgetId,
        String type,
        String size,
        String theme,
        String customDhikr
    ) {
        saveWidgetConfig(context, appWidgetId, type, size, theme, customDhikr, null, null);
    }

    public static void saveWidgetConfig(
        Context context,
        int appWidgetId,
        String type,
        String size,
        String theme,
        String customDhikr,
        String targetPrayer,
        String statsMode
    ) {
        synchronized (LOCK) {
            // Always update global defaults as well so newly added widgets inherit the latest preferences
            saveGlobalDefaultConfig(context, type, size, theme, customDhikr, targetPrayer, statsMode);
            if (appWidgetId == 0) return;

            SharedPreferences.Editor editor = getPrefs(context).edit();
            if (type != null && !type.isEmpty()) {
                editor.putString(widgetKey(appWidgetId, "type"), type);
            }
            if (size != null && !size.isEmpty()) {
                editor.putString(widgetKey(appWidgetId, "size"), size);
            }
            if (theme != null && !theme.isEmpty()) {
                editor.putString(widgetKey(appWidgetId, "theme"), theme);
            }
            if (customDhikr != null) {
                editor.putString(widgetKey(appWidgetId, "custom_dhikr"), customDhikr);
                editor.remove(widgetKey(appWidgetId, "dhikr_idx"));
                if (!customDhikr.trim().isEmpty()) {
                    editor.putString(KEY_ACTIVE_TASBEEH_DHIKR, customDhikr.trim());
                }
            }
            if (targetPrayer != null && !targetPrayer.isEmpty()) {
                editor.putString(widgetKey(appWidgetId, "target_prayer"), targetPrayer);
            }
            if (statsMode != null && !statsMode.isEmpty()) {
                editor.putString(widgetKey(appWidgetId, "stats_mode"), statsMode);
            }
            editor.commit();
        }
    }

    public static void deleteWidgetConfig(Context context, int appWidgetId) {
        if (appWidgetId == 0) return;
        getPrefs(context).edit()
            .remove(widgetKey(appWidgetId, "type"))
            .remove(widgetKey(appWidgetId, "size"))
            .remove(widgetKey(appWidgetId, "theme"))
            .remove(widgetKey(appWidgetId, "custom_dhikr"))
            .remove(widgetKey(appWidgetId, "target_prayer"))
            .remove(widgetKey(appWidgetId, "stats_mode"))
            .remove(widgetKey(appWidgetId, "dhikr_idx"))
            .apply();
    }

    public static void setPendingPinConfig(
        Context context,
        String type,
        String size,
        String theme,
        String dhikrText
    ) {
        setPendingPinConfig(context, type, size, theme, dhikrText, "next", "today_count");
    }

    public static void setPendingPinConfig(
        Context context,
        String type,
        String size,
        String theme,
        String dhikrText,
        String targetPrayer,
        String statsMode
    ) {
        saveGlobalDefaultConfig(context, type, size, theme, dhikrText, targetPrayer, statsMode);
        getPrefs(context).edit()
            .putString(KEY_PENDING_PIN_TYPE, type != null ? type : "tasbeeh")
            .putString(KEY_PENDING_PIN_SIZE, size != null ? size : "medium")
            .putString(KEY_PENDING_PIN_THEME, theme != null ? theme : "navy")
            .putString(KEY_PENDING_PIN_DHIKR, dhikrText != null ? dhikrText : "")
            .putString(KEY_PENDING_PIN_PRAYER, targetPrayer != null ? targetPrayer : "next")
            .putString(KEY_PENDING_PIN_STATS_MODE, statsMode != null ? statsMode : "today_count")
            .putLong(KEY_PENDING_PIN_TIMESTAMP, System.currentTimeMillis())
            .commit();
    }

    public static void applyPendingPinConfigIfRecent(Context context, int appWidgetId, String providerDefaultType) {
        SharedPreferences prefs = getPrefs(context);
        long ts = prefs.getLong(KEY_PENDING_PIN_TIMESTAMP, 0L);
        if (ts > 0 && (System.currentTimeMillis() - ts) < 120_000L) {
            String type = prefs.getString(KEY_PENDING_PIN_TYPE, providerDefaultType);
            String size = prefs.getString(KEY_PENDING_PIN_SIZE, "auto");
            String theme = prefs.getString(KEY_PENDING_PIN_THEME, "navy");
            String dhikr = prefs.getString(KEY_PENDING_PIN_DHIKR, "");
            String targetPrayer = prefs.getString(KEY_PENDING_PIN_PRAYER, "next");
            String statsMode = prefs.getString(KEY_PENDING_PIN_STATS_MODE, "today_count");
            saveWidgetConfig(context, appWidgetId, type, size, theme, dhikr, targetPrayer, statsMode);
            prefs.edit()
                .putLong(KEY_PENDING_PIN_TIMESTAMP, 0L)
                .putInt(KEY_LAST_PINNED_WIDGET_ID, appWidgetId)
                .putLong(KEY_LAST_PINNED_AT, System.currentTimeMillis())
                .commit();
        } else if (!hasWidgetConfig(context, appWidgetId)) {
            WidgetInstanceConfig def = getGlobalDefaultConfig(context);
            saveWidgetConfig(
                context,
                appWidgetId,
                providerDefaultType,
                def.size,
                def.theme,
                def.customDhikr,
                def.targetPrayer,
                def.statsMode
            );
        }
    }

    public static String formatArabicNumber(int number) {
        return String.format(new Locale("ar", "EG"), "%,d", number);
    }
}
