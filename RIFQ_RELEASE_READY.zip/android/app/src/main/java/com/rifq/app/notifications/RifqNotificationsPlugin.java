package com.rifq.app.notifications;

import android.Manifest;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.rifq.app.audioathkar.RifqAudioAthkarCatalog;
import com.rifq.app.audioathkar.RifqAudioAthkarPrefs;
import com.rifq.app.audioathkar.RifqAudioAthkarScheduler;
import com.rifq.app.audioathkar.RifqAudioAthkarService;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Capacitor Native Android Plugin for «رِفْق | RIFQ» Production Notification System.
 *
 * Bridges React/TypeScript with:
 * - Android 13+ POST_NOTIFICATIONS runtime permission
 * - Android NotificationManager & NotificationChannels (rifq_general, rifq_adhkar, rifq_prayer, rifq_reminders, rifq_quran, rifq_updates)
 * - Android AlarmManager exact/idle background scheduling & cancellation
 * - Deep-link tap handling from Android Status Bar / Notification Shade into specific RIFQ screens
 * - Dual synchronization between Android System Notifications and RIFQ's in-app Notification Center
 */
@CapacitorPlugin(
    name = "RifqNotifications",
    permissions = {
        @Permission(
            strings = { Manifest.permission.POST_NOTIFICATIONS },
            alias = "notifications"
        )
    }
)
public class RifqNotificationsPlugin extends Plugin {

    private static RifqNotificationsPlugin activeInstance = null;

    @Override
    public void load() {
        super.load();
        activeInstance = this;
        RifqNotificationChannels.createAllChannels(getContext());
    }

    /**
     * Called when an Android System Notification is tapped (from cold start or background)
     * so React can navigate immediately to the appropriate screen.
     */
    public static void notifyNotificationTapped(
        String screen,
        String ward,
        String dhikrId,
        String notificationId
    ) {
        if (activeInstance != null) {
            JSObject data = new JSObject();
            data.put("screen", screen != null ? screen : "");
            data.put("ward", ward != null ? ward : "");
            data.put("dhikrId", dhikrId != null ? dhikrId : "");
            data.put("notificationId", notificationId != null ? notificationId : "");
            activeInstance.notifyListeners("notificationTapped", data, true);
        }
    }

    /**
     * Called when a background alarm or FCM push fires while the app is alive,
     * so the in-app Notification Center updates immediately.
     */
    public static void notifyInAppNotificationReceived(
        String id,
        String title,
        String message,
        String screen,
        String ward,
        String dhikrId,
        String signatureKey,
        long timestampMs
    ) {
        if (activeInstance != null) {
            JSObject data = new JSObject();
            data.put("id", id != null ? id : "");
            data.put("title", title != null ? title : "رِفْق");
            data.put("message", message != null ? message : "");
            data.put("screen", screen != null ? screen : "");
            data.put("ward", ward != null ? ward : "");
            data.put("dhikrId", dhikrId != null ? dhikrId : "");
            data.put("signatureKey", signatureKey != null ? signatureKey : "");
            data.put("timestamp", timestampMs);
            activeInstance.notifyListeners("systemNotificationFired", data, true);
        }
    }

    /**
     * 1. getNotificationStatus()
     * Returns real Android notification permission state, channel statuses, and exact alarm capability.
     */
    @PluginMethod
    public void getNotificationStatus(PluginCall call) {
        Context context = getContext();
        RifqNotificationChannels.createAllChannels(context);
        JSObject ret = buildCurrentStatusObject(context);
        call.resolve(ret);
    }

    /**
     * 2. requestNotificationPermission()
     * Requests Android 13+ POST_NOTIFICATIONS runtime permission natively.
     */
    @PluginMethod
    public void requestNotificationPermission(PluginCall call) {
        Context context = getContext();
        RifqNotificationChannels.createAllChannels(context);

        if (Build.VERSION.SDK_INT >= 33) {
            int currentPerm = ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            );
            if (currentPerm == PackageManager.PERMISSION_GRANTED) {
                call.resolve(buildCurrentStatusObject(context));
                return;
            }
            RifqNotificationPrefs.getPrefs(context).edit()
                .putBoolean(RifqNotificationPrefs.KEY_HAS_ASKED_POST_NOTIF, true)
                .apply();
            requestPermissionForAlias("notifications", call, "notificationsPermissionCallback");
        } else {
            call.resolve(buildCurrentStatusObject(context));
        }
    }

    @PermissionCallback
    private void notificationsPermissionCallback(PluginCall call) {
        Context context = getContext();
        RifqNotificationChannels.createAllChannels(context);
        JSObject status = buildCurrentStatusObject(context);
        if (status.optBoolean("granted", false)) {
            RifqAlarmScheduler.rescheduleAllSavedAlarms(context);
        }
        call.resolve(status);
    }

    /**
     * 3. openNotificationSettings()
     * Opens official Android App Notification Settings (or specific Channel Settings).
     */
    @PluginMethod
    public void openNotificationSettings(PluginCall call) {
        Context context = getContext();
        String rawChannelId = call.getString("channelId", null);

        try {
            Intent intent;
            if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                rawChannelId != null &&
                !rawChannelId.trim().isEmpty()
            ) {
                RifqNotificationChannels.createAllChannels(context);
                String normalized = RifqNotificationChannels.normalizeChannelId(rawChannelId);
                intent = new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
                intent.putExtra(Settings.EXTRA_CHANNEL_ID, normalized);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
            } else {
                intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(Uri.fromParts("package", context.getPackageName(), null));
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);

            JSObject ret = new JSObject();
            ret.put("opened", true);
            call.resolve(ret);
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                fallback.setData(Uri.fromParts("package", context.getPackageName(), null));
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(fallback);
                JSObject ret = new JSObject();
                ret.put("opened", true);
                call.resolve(ret);
            } catch (Exception inner) {
                JSObject ret = new JSObject();
                ret.put("opened", false);
                ret.put("error", inner.getMessage());
                call.resolve(ret);
            }
        }
    }

    /**
     * 4. showSystemNotification()
     * Immediately posts a real Android System Notification to the status bar / notification shade.
     */
    @PluginMethod
    public void showSystemNotification(PluginCall call) {
        Context context = getContext();
        String idStr = call.getString("id", null);
        Integer rawIntId = call.getInt("notificationId", null);
        int notifId = rawIntId != null
            ? rawIntId
            : (idStr != null ? RifqAlarmScheduler.stableNotificationId(idStr) : (int) (System.currentTimeMillis() % 100000));

        String channelId = call.getString("channelId", RifqNotificationChannels.CHANNEL_GENERAL);
        String title = call.getString("title", "رِفْق | RIFQ");
        String body = call.getString("body", "");
        String screen = call.getString("screen", "");
        String ward = call.getString("ward", "");
        String dhikrId = call.getString("dhikrId", "");
        String signatureKey = call.getString("signatureKey", "");
        boolean bypassChannelCheck = Boolean.TRUE.equals(call.getBoolean("bypassChannelCheck", false));
        boolean recordInApp = Boolean.TRUE.equals(call.getBoolean("recordInApp", false));

        boolean displayed = RifqNotificationHelper.showSystemNotification(
            context,
            notifId,
            channelId,
            title,
            body,
            screen,
            ward,
            dhikrId,
            signatureKey,
            bypassChannelCheck,
            recordInApp
        );

        JSObject ret = new JSObject();
        ret.put("displayed", displayed);
        ret.put("notificationId", notifId);
        ret.put("channelId", RifqNotificationChannels.normalizeChannelId(channelId));
        if (!displayed) {
            boolean sysEnabled = RifqNotificationHelper.canPostSystemNotifications(context);
            ret.put(
                "reason",
                !sysEnabled ? "system_permission_denied" : "channel_disabled_or_deduplicated"
            );
        }
        call.resolve(ret);
    }

    /**
     * 5. sendTestSystemNotification()
     * Sends a real verification Android notification to the status bar and notification shade.
     * Never fakes success if system permission is denied.
     */
    @PluginMethod
    public void sendTestSystemNotification(PluginCall call) {
        Context context = getContext();
        RifqNotificationChannels.createAllChannels(context);

        if (!RifqNotificationHelper.canPostSystemNotifications(context)) {
            JSObject ret = new JSObject();
            ret.put("displayed", false);
            ret.put("reason", "system_permission_denied");
            ret.put("error", "إشعارات الجهاز متوقفة من إعدادات Android");
            call.resolve(ret);
            return;
        }

        String title = call.getString("title", "🔔 إشعار تجريبي — رِفْق | RIFQ");
        String body = call.getString(
            "body",
            "تم إرسال هذا الإشعار الحقيقي إلى شريط إشعارات Android ومركز التذكيرات في تطبيق رِفْق بنجاح."
        );
        String screen = call.getString("screen", "daily_reminders");

        int testNotifId = 99000 + (int) (System.currentTimeMillis() % 999);
        boolean displayed = RifqNotificationHelper.showSystemNotification(
            context,
            testNotifId,
            RifqNotificationChannels.CHANNEL_GENERAL,
            title,
            body,
            screen,
            "",
            "",
            "",
            true,
            false
        );

        JSObject ret = new JSObject();
        ret.put("displayed", displayed);
        ret.put("notificationId", testNotifId);
        if (!displayed) {
            ret.put("error", "تعذر إظهار الإشعار في نظام الجهاز — تأكد من تفعيل قناة الإشعارات");
        }
        call.resolve(ret);
    }

    /**
     * 6. syncScheduledNotifications()
     * Synchronizes all scheduled reminders, channel states, fired keys, and quiet hours with Android AlarmManager.
     */
    @PluginMethod
    public void syncScheduledNotifications(PluginCall call) {
        Context context = getContext();
        RifqNotificationChannels.createAllChannels(context);

        // 1. Sync channel states if provided
        JSObject channelsObj = call.getObject("channels", null);
        if (channelsObj != null) {
            if (channelsObj.has("rifq_adhan")) {
                RifqNotificationPrefs.setChannelEnabledInApp(
                    context,
                    RifqNotificationChannels.CHANNEL_PRAYER,
                    channelsObj.optBoolean("rifq_adhan", true)
                );
            }
            if (channelsObj.has("rifq_prayer")) {
                RifqNotificationPrefs.setChannelEnabledInApp(
                    context,
                    RifqNotificationChannels.CHANNEL_PRAYER,
                    channelsObj.optBoolean("rifq_prayer", true)
                );
            }
            if (channelsObj.has("rifq_azkar")) {
                RifqNotificationPrefs.setChannelEnabledInApp(
                    context,
                    RifqNotificationChannels.CHANNEL_ADHKAR,
                    channelsObj.optBoolean("rifq_azkar", true)
                );
            }
            if (channelsObj.has("rifq_adhkar")) {
                RifqNotificationPrefs.setChannelEnabledInApp(
                    context,
                    RifqNotificationChannels.CHANNEL_ADHKAR,
                    channelsObj.optBoolean("rifq_adhkar", true)
                );
            }
            if (channelsObj.has("rifq_quran")) {
                RifqNotificationPrefs.setChannelEnabledInApp(
                    context,
                    RifqNotificationChannels.CHANNEL_QURAN,
                    channelsObj.optBoolean("rifq_quran", true)
                );
            }
            if (channelsObj.has("rifq_reminders")) {
                RifqNotificationPrefs.setChannelEnabledInApp(
                    context,
                    RifqNotificationChannels.CHANNEL_REMINDERS,
                    channelsObj.optBoolean("rifq_reminders", true)
                );
            }
            if (channelsObj.has("rifq_updates")) {
                RifqNotificationPrefs.setChannelEnabledInApp(
                    context,
                    RifqNotificationChannels.CHANNEL_UPDATES,
                    channelsObj.optBoolean("rifq_updates", true)
                );
            }
        }

        // 2. Sync quiet hours if provided
        JSObject quietObj = call.getObject("quietHours", null);
        if (quietObj != null) {
            RifqNotificationPrefs.setQuietHours(
                context,
                quietObj.optBoolean("enabled", false),
                quietObj.optString("start", "23:00"),
                quietObj.optString("end", "04:30")
            );
        }

        // 3. Sync fired keys so native AlarmManager doesn't re-fire a notification already fired in foreground
        JSArray firedKeysArr = call.getArray("firedKeys", null);
        if (firedKeysArr != null) {
            for (int i = 0; i < firedKeysArr.length(); i++) {
                String sig = firedKeysArr.optString(i, "");
                if (sig != null && !sig.isEmpty()) {
                    RifqNotificationPrefs.markSignatureFired(context, sig);
                }
            }
        }

        // 4. Sync scheduled items with Android AlarmManager
        JSArray scheduleItemsArr = call.getArray("scheduleItems", null);
        JSONArray nativeSchedule = new JSONArray();
        if (scheduleItemsArr != null) {
            for (int i = 0; i < scheduleItemsArr.length(); i++) {
                try {
                    JSONObject itemObj = scheduleItemsArr.getJSONObject(i);
                    if (itemObj != null) {
                        nativeSchedule.put(itemObj);
                    }
                } catch (Exception ignored) {
                }
            }
        }

        RifqAlarmScheduler.syncScheduleList(context, nativeSchedule);

        JSObject ret = new JSObject();
        ret.put("synced", true);
        ret.put("scheduledCount", nativeSchedule.length());
        call.resolve(ret);
    }

    /**
     * 7. setChannelEnabled()
     * Enables or disables a notification channel and updates AlarmManager immediately.
     */
    @PluginMethod
    public void setChannelEnabled(PluginCall call) {
        Context context = getContext();
        String channelId = call.getString("channelId", RifqNotificationChannels.CHANNEL_GENERAL);
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", true));

        RifqNotificationPrefs.setChannelEnabledInApp(context, channelId, enabled);
        RifqAlarmScheduler.rescheduleAllSavedAlarms(context);

        JSObject ret = new JSObject();
        ret.put("channelId", RifqNotificationChannels.normalizeChannelId(channelId));
        ret.put("enabled", enabled);
        call.resolve(ret);
    }

    /**
     * 8. cancelScheduledNotification()
     * Cancels a specific scheduled alarm in Android AlarmManager.
     */
    @PluginMethod
    public void cancelScheduledNotification(PluginCall call) {
        Context context = getContext();
        String id = call.getString("id", null);
        if (id != null && !id.isEmpty()) {
            RifqAlarmScheduler.cancelAlarmById(context, id);
            RifqNotificationHelper.cancelNotificationById(
                context,
                RifqAlarmScheduler.stableNotificationId(id)
            );
        }
        JSObject ret = new JSObject();
        ret.put("cancelled", true);
        call.resolve(ret);
    }

    /**
     * 9. consumePendingEvents()
     * Returns any notifications that fired in background while the app was closed (for the in-app Notification Center)
     * AND any pending deep-link navigation target when the user tapped a notification in the Android Notification Shade.
     */
    @PluginMethod
    public void consumePendingEvents(PluginCall call) {
        Context context = getContext();
        JSONArray pendingNotifs = RifqNotificationPrefs.consumePendingInAppNotifications(context);
        JSONObject pendingNav = RifqNotificationPrefs.consumePendingNavigation(context);

        JSArray jsNotifs = new JSArray();
        for (int i = 0; i < pendingNotifs.length(); i++) {
            JSONObject obj = pendingNotifs.optJSONObject(i);
            if (obj != null) {
                JSObject jsItem = new JSObject();
                jsItem.put("id", obj.optString("id", ""));
                jsItem.put("title", obj.optString("title", "رِفْق"));
                jsItem.put("message", obj.optString("message", ""));
                jsItem.put("screen", obj.optString("screen", ""));
                jsItem.put("ward", obj.optString("ward", ""));
                jsItem.put("dhikrId", obj.optString("dhikrId", ""));
                jsItem.put("signatureKey", obj.optString("signatureKey", ""));
                jsItem.put("timestamp", obj.optLong("timestamp", System.currentTimeMillis()));
                jsNotifs.put(jsItem);
            }
        }

        JSObject ret = new JSObject();
        ret.put("pendingNotifications", jsNotifs);
        if (pendingNav != null) {
            JSObject navObj = new JSObject();
            navObj.put("screen", pendingNav.optString("screen", ""));
            navObj.put("ward", pendingNav.optString("ward", ""));
            navObj.put("dhikrId", pendingNav.optString("dhikrId", ""));
            navObj.put("notificationId", pendingNav.optString("notificationId", ""));
            ret.put("pendingNavigation", navObj);
        } else {
            ret.put("pendingNavigation", JSObject.NULL);
        }
        call.resolve(ret);
    }

    private JSObject buildCurrentStatusObject(Context context) {
        boolean systemEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled();
        String postPermState = "granted";
        boolean hasAskedBefore = RifqNotificationPrefs.getPrefs(context)
            .getBoolean(RifqNotificationPrefs.KEY_HAS_ASKED_POST_NOTIF, false);

        if (Build.VERSION.SDK_INT >= 33) {
            PermissionState capPerm = getPermissionState("notifications");
            int osPerm = ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            );
            if (osPerm == PackageManager.PERMISSION_GRANTED) {
                postPermState = "granted";
            } else if (capPerm == PermissionState.DENIED || hasAskedBefore) {
                postPermState = "denied";
            } else {
                postPermState = "prompt";
            }
        } else {
            postPermState = systemEnabled ? "granted" : "denied";
        }

        boolean effectivelyGranted = "granted".equals(postPermState) && systemEnabled;

        boolean canScheduleExact = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                canScheduleExact = am.canScheduleExactAlarms();
            }
        }

        JSObject ret = new JSObject();
        ret.put("granted", effectivelyGranted);
        ret.put("systemNotificationsEnabled", systemEnabled);
        ret.put("postNotificationsPermission", postPermState);
        ret.put("permanentlyBlocked", !effectivelyGranted && ("denied".equals(postPermState) || !systemEnabled));
        ret.put("sdkInt", Build.VERSION.SDK_INT);
        ret.put("canScheduleExactAlarms", canScheduleExact);
        ret.put("channels", RifqNotificationChannels.getChannelsStatusArray(context));
        return ret;
    }

    /**
     * Broadcasts live Spoken Audio Athkar state changes to the React WebView if active.
     */
    public static void notifyAudioAthkarStateChanged(Context context) {
        if (activeInstance != null && context != null) {
            try {
                JSONObject json = RifqAudioAthkarPrefs.toJsonObject(context);
                JSObject payload = JSObject.fromJSONObject(json);
                activeInstance.notifyListeners("rifqAudioAthkarStateChanged", payload, true);
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * 10. syncAudioAthkarSettings()
     * Persists user's Spoken Audio Athkar preferences in SharedPreferences and reschedules background alarms.
     */
    @PluginMethod
    public void syncAudioAthkarSettings(PluginCall call) {
        Context context = getContext();
        RifqAudioAthkarPrefs.AudioAthkarConfig cfg = RifqAudioAthkarPrefs.loadConfig(context);

        if (call.hasOption("enabled")) {
            cfg.enabled = Boolean.TRUE.equals(call.getBoolean("enabled", true));
        }
        if (call.hasOption("alertMode")) {
            cfg.alertMode = call.getString("alertMode", cfg.alertMode);
        }
        if (call.hasOption("scheduleMode")) {
            cfg.scheduleMode = call.getString("scheduleMode", cfg.scheduleMode);
        }
        if (call.hasOption("intervalMinutes")) {
            Integer iv = call.getInt("intervalMinutes", cfg.intervalMinutes);
            if (iv != null) cfg.intervalMinutes = Math.max(30, iv);
        }
        if (call.hasOption("quietHoursEnabled")) {
            cfg.quietHoursEnabled = Boolean.TRUE.equals(call.getBoolean("quietHoursEnabled", cfg.quietHoursEnabled));
        }
        if (call.hasOption("quietHoursStart")) {
            cfg.quietHoursStart = call.getString("quietHoursStart", cfg.quietHoursStart);
        }
        if (call.hasOption("quietHoursEnd")) {
            cfg.quietHoursEnd = call.getString("quietHoursEnd", cfg.quietHoursEnd);
        }
        if (call.hasOption("respectSilentAndDnd")) {
            cfg.respectSilentAndDnd = Boolean.TRUE.equals(call.getBoolean("respectSilentAndDnd", cfg.respectSilentAndDnd));
        }
        if (call.hasOption("respectActiveAudio")) {
            cfg.respectActiveAudio = Boolean.TRUE.equals(call.getBoolean("respectActiveAudio", cfg.respectActiveAudio));
        }
        if (call.hasOption("speechRate")) {
            Float sr = call.getFloat("speechRate", cfg.speechRate);
            if (sr != null) cfg.speechRate = sr;
        }
        if (call.hasOption("speechPitch")) {
            Float sp = call.getFloat("speechPitch", cfg.speechPitch);
            if (sp != null) cfg.speechPitch = sp;
        }
        if (call.hasOption("volume")) {
            Float vol = call.getFloat("volume", cfg.volume);
            if (vol != null) cfg.volume = vol;
        }
        if (call.hasOption("preferredVoiceName")) {
            cfg.preferredVoiceName = call.getString("preferredVoiceName", "");
        }

        JSArray catsArr = call.getArray("categories", null);
        if (catsArr != null) {
            cfg.categories.clear();
            for (int i = 0; i < catsArr.length(); i++) {
                String c = catsArr.optString(i, "").trim();
                if (!c.isEmpty()) cfg.categories.add(c);
            }
        }

        JSArray timesArr = call.getArray("customTimes", null);
        if (timesArr != null) {
            cfg.customTimes.clear();
            for (int i = 0; i < timesArr.length(); i++) {
                String t = timesArr.optString(i, "").trim();
                if (t.matches("^\\d{2}:\\d{2}$")) cfg.customTimes.add(t);
            }
        }

        RifqAudioAthkarPrefs.saveConfig(context, cfg);
        RifqAudioAthkarScheduler.rescheduleAll(context);

        try {
            call.resolve(JSObject.fromJSONObject(RifqAudioAthkarPrefs.toJsonObject(context)));
        } catch (Exception e) {
            JSObject ret = new JSObject();
            ret.put("synced", true);
            call.resolve(ret);
        }
    }

    /**
     * 11. getAudioAthkarSettings()
     * Returns the current Spoken Audio Athkar settings and live playback/voice status from SharedPreferences.
     */
    @PluginMethod
    public void getAudioAthkarSettings(PluginCall call) {
        Context context = getContext();
        try {
            call.resolve(JSObject.fromJSONObject(RifqAudioAthkarPrefs.toJsonObject(context)));
        } catch (Exception e) {
            call.resolve(new JSObject());
        }
    }

    /**
     * 12. speakDhikrNow()
     * Speaks a specific authentic Dhikr (or picks the next non-repeating Dhikr) immediately using Android Native TTS.
     */
    @PluginMethod
    public void speakDhikrNow(PluginCall call) {
        Context context = getContext();
        String text = call.getString("text", "");
        String title = call.getString("title", "ذكر مبارك من رِفْق");
        String source = call.getString("source", "رِفْق | RIFQ");
        String category = call.getString("category", null);
        boolean showNotif = Boolean.TRUE.equals(call.getBoolean("showNotification", false));

        if (text == null || text.trim().isEmpty()) {
            RifqAudioAthkarCatalog.AudioDhikrEntry picked =
                RifqAudioAthkarCatalog.pickNextNonRepeatingDhikr(context, category);
            text = picked.text;
            title = picked.title;
            source = picked.source;
        }

        RifqAudioAthkarService.speakDhikrNow(
            context,
            text,
            title,
            source,
            category,
            true,
            showNotif
        );

        JSObject ret = new JSObject();
        ret.put("started", true);
        ret.put("text", text);
        ret.put("title", title);
        ret.put("source", source);
        call.resolve(ret);
    }

    /**
     * 13. stopAudioAthkar()
     * Immediately stops any active Spoken Audio Dhikr on the device.
     */
    @PluginMethod
    public void stopAudioAthkar(PluginCall call) {
        Context context = getContext();
        RifqAudioAthkarService.stopSpeakingNow(context);
        JSObject ret = new JSObject();
        ret.put("stopped", true);
        call.resolve(ret);
    }

    /**
     * 14. syncAthkarCatalog()
     * Syncs the full authentic RIFQ Athkar library from TypeScript to Native SharedPreferences.
     */
    @PluginMethod
    public void syncAthkarCatalog(PluginCall call) {
        Context context = getContext();
        JSArray items = call.getArray("items", null);
        if (items != null && items.length() > 0) {
            RifqAudioAthkarPrefs.getPrefs(context).edit()
                .putString(RifqAudioAthkarPrefs.KEY_SYNCED_CATALOG_JSON, items.toString())
                .apply();
        }
        JSObject ret = new JSObject();
        ret.put("synced", true);
        ret.put("count", items != null ? items.length() : 0);
        call.resolve(ret);
    }

    /**
     * Broadcasts an incoming WIRD invite Deep Link / Android App Link (?wirdJoin=INVITE_CODE)
     * to the active React WebView immediately when opened from background or foreground.
     */
    public static void notifyWirdInviteDeepLink(String inviteCode, String rawUrl) {
        if (activeInstance != null && inviteCode != null && !inviteCode.trim().isEmpty()) {
            JSObject data = new JSObject();
            data.put("inviteCode", inviteCode.trim().toUpperCase());
            data.put("url", rawUrl != null ? rawUrl : "");
            data.put("timestamp", System.currentTimeMillis());
            activeInstance.notifyListeners("wirdInviteDeepLink", data, true);
        }
    }

    /**
     * 15. consumePendingWirdInvite()
     * Retrieves and clears any pending WIRD group invite code received when the app was cold-started
     * or resumed via an Android App Link / Deep Link.
     */
    @PluginMethod
    public void consumePendingWirdInvite(PluginCall call) {
        Context context = getContext();
        JSONObject pending = RifqNotificationPrefs.consumePendingWirdInvite(context);
        JSObject ret = new JSObject();
        if (pending != null) {
            ret.put("hasPending", true);
            ret.put("inviteCode", pending.optString("inviteCode", ""));
            ret.put("url", pending.optString("url", ""));
            ret.put("timestamp", pending.optLong("timestamp", 0L));
        } else {
            ret.put("hasPending", false);
        }
        call.resolve(ret);
    }

    /**
     * 16. shareNative()
     * Opens the official Android Native Share Sheet (Intent.ACTION_SEND + Intent.createChooser).
     * Never uses fake Toast or simulation.
     */
    @PluginMethod
    public void shareNative(PluginCall call) {
        Context context = getContext();
        String title = call.getString("title", "مشاركة دعوة وِرد | رِفْق");
        String text = call.getString("text", "");
        String url = call.getString("url", "");
        String dialogTitle = call.getString("dialogTitle", title);

        String fullShareBody = text != null ? text.trim() : "";
        if (url != null && !url.trim().isEmpty() && !fullShareBody.contains(url.trim())) {
            fullShareBody = fullShareBody.isEmpty() ? url.trim() : (fullShareBody + "\n" + url.trim());
        }

        try {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            if (title != null && !title.trim().isEmpty()) {
                sendIntent.putExtra(Intent.EXTRA_SUBJECT, title.trim());
                sendIntent.putExtra(Intent.EXTRA_TITLE, title.trim());
            }
            sendIntent.putExtra(Intent.EXTRA_TEXT, fullShareBody);

            Intent chooser = Intent.createChooser(sendIntent, dialogTitle);
            if (getActivity() != null) {
                getActivity().startActivity(chooser);
            } else {
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(chooser);
            }

            JSObject ret = new JSObject();
            ret.put("shared", true);
            call.resolve(ret);
        } catch (Exception e) {
            JSObject ret = new JSObject();
            ret.put("shared", false);
            ret.put("error", e.getMessage());
            call.resolve(ret);
        }
    }

    /**
     * 17. openExternalUrl()
     * Launches external share targets (WhatsApp, Telegram, Browser) natively via Intent.ACTION_VIEW.
     */
    @PluginMethod
    public void openExternalUrl(PluginCall call) {
        Context context = getContext();
        String url = call.getString("url", "");
        if (url == null || url.trim().isEmpty()) {
            JSObject ret = new JSObject();
            ret.put("opened", false);
            call.resolve(ret);
            return;
        }

        try {
            Intent viewIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url.trim()));
            viewIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if (getActivity() != null) {
                getActivity().startActivity(viewIntent);
            } else {
                context.startActivity(viewIntent);
            }
            JSObject ret = new JSObject();
            ret.put("opened", true);
            call.resolve(ret);
        } catch (Exception e) {
            JSObject ret = new JSObject();
            ret.put("opened", false);
            ret.put("error", e.getMessage());
            call.resolve(ret);
        }
    }
}
