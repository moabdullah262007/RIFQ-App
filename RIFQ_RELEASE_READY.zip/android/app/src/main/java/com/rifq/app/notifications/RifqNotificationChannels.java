package com.rifq.app.notifications;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;

/**
 * Manages real Android Notification Channels (API 26+) for «رِفْق | RIFQ».
 *
 * Channels created:
 * - rifq_general: إشعارات رِفْق العامة
 * - rifq_adhkar: الأذكار اليومية (الصباح والمساء والنوم وذكر اللحظة)
 * - rifq_prayer: مواقيت الصلاة والأذان
 * - rifq_reminders: التذكيرات اليومية والأدعية
 * - rifq_quran: الورد القرآني وآية وفائدة اليوم
 * - rifq_updates: التحديثات والرسائل العامة
 */
public class RifqNotificationChannels {

    public static final String CHANNEL_GENERAL = "rifq_general";
    public static final String CHANNEL_ADHKAR = "rifq_adhkar";
    public static final String CHANNEL_PRAYER = "rifq_prayer";
    public static final String CHANNEL_REMINDERS = "rifq_reminders";
    public static final String CHANNEL_QURAN = "rifq_quran";
    public static final String CHANNEL_UPDATES = "rifq_updates";

    // Legacy aliases mapped seamlessly to official channels
    public static final String ALIAS_AZKAR = "rifq_azkar";
    public static final String ALIAS_ADHAN = "rifq_adhan";

    public static class ChannelMeta {
        public final String id;
        public final String nameAr;
        public final String descriptionAr;
        public final int importance;

        public ChannelMeta(String id, String nameAr, String descriptionAr, int importance) {
            this.id = id;
            this.nameAr = nameAr;
            this.descriptionAr = descriptionAr;
            this.importance = importance;
        }
    }

    public static final ChannelMeta[] ALL_CHANNELS = new ChannelMeta[] {
        new ChannelMeta(
            CHANNEL_GENERAL,
            "إشعارات رِفْق العامة",
            "التنبيهات والإشعارات العامة والتجريبية في تطبيق رِفْق",
            NotificationManager.IMPORTANCE_HIGH
        ),
        new ChannelMeta(
            CHANNEL_ADHKAR,
            "الأذكار اليومية",
            "تنبيهات أذكار الصباح والمساء وأذكار النوم وذكر اللحظة",
            NotificationManager.IMPORTANCE_HIGH
        ),
        new ChannelMeta(
            CHANNEL_PRAYER,
            "مواقيت الصلاة والأذان",
            "تنبيهات دخول وقت الصلاة والتذكير قبل الأذان ووضع الصلاة",
            NotificationManager.IMPORTANCE_HIGH
        ),
        new ChannelMeta(
            CHANNEL_REMINDERS,
            "التذكيرات والأدعية اليومية",
            "التذكيرات اليومية المخصصة ودعاء اليوم المأثور والتسبيح",
            NotificationManager.IMPORTANCE_HIGH
        ),
        new ChannelMeta(
            CHANNEL_QURAN,
            "الورد القرآني وآية وفائدة اليوم",
            "تذكير الورد القرآني اليومي وآية اليوم وفائدة اليوم",
            NotificationManager.IMPORTANCE_HIGH
        ),
        new ChannelMeta(
            CHANNEL_UPDATES,
            "التحديثات والرسائل العامة",
            "إشعارات التحديثات والرسائل الإيمانية العامة عبر السحابة",
            NotificationManager.IMPORTANCE_HIGH
        )
    };

    /**
     * Normalizes any channel ID (including legacy rifq_azkar / rifq_adhan) to the canonical Android NotificationChannel ID.
     */
    public static String normalizeChannelId(String rawChannelId) {
        if (rawChannelId == null || rawChannelId.trim().isEmpty()) {
            return CHANNEL_GENERAL;
        }
        String cleaned = rawChannelId.trim();
        if (ALIAS_AZKAR.equals(cleaned) || CHANNEL_ADHKAR.equals(cleaned)) {
            return CHANNEL_ADHKAR;
        }
        if (ALIAS_ADHAN.equals(cleaned) || CHANNEL_PRAYER.equals(cleaned)) {
            return CHANNEL_PRAYER;
        }
        if (CHANNEL_QURAN.equals(cleaned)) {
            return CHANNEL_QURAN;
        }
        if (CHANNEL_REMINDERS.equals(cleaned)) {
            return CHANNEL_REMINDERS;
        }
        if (CHANNEL_UPDATES.equals(cleaned)) {
            return CHANNEL_UPDATES;
        }
        return CHANNEL_GENERAL;
    }

    /**
     * Creates all official Android Notification Channels on Android 8.0+ (API 26+).
     * Safe to call repeatedly; Android updates existing channel names/descriptions without resetting user preferences.
     */
    public static void createAllChannels(Context context) {
        if (context == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();

        for (ChannelMeta meta : ALL_CHANNELS) {
            NotificationChannel channel = new NotificationChannel(
                meta.id,
                meta.nameAr,
                meta.importance
            );
            channel.setDescription(meta.descriptionAr);
            channel.enableLights(true);
            channel.setLightColor(0xFF5B5FEF);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[] { 0, 160, 80, 200 });
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.setShowBadge(true);
            if (defaultSoundUri != null) {
                channel.setSound(defaultSoundUri, audioAttributes);
            }
            nm.createNotificationChannel(channel);
        }
    }

    /**
     * Checks whether system notifications are enabled for the app at OS level.
     */
    public static boolean areSystemNotificationsEnabled(Context context) {
        if (context == null) return false;
        return NotificationManagerCompat.from(context).areNotificationsEnabled();
    }

    /**
     * Checks whether a specific Android NotificationChannel has been muted/disabled by the user in Android system settings.
     */
    public static boolean isChannelEnabledInSystem(Context context, String rawChannelId) {
        if (context == null) return false;
        if (!areSystemNotificationsEnabled(context)) return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return true;
            String normalized = normalizeChannelId(rawChannelId);
            NotificationChannel ch = nm.getNotificationChannel(normalized);
            if (ch == null) {
                createAllChannels(context);
                ch = nm.getNotificationChannel(normalized);
            }
            if (ch != null) {
                return ch.getImportance() != NotificationManager.IMPORTANCE_NONE;
            }
        }
        return true;
    }

    /**
     * Returns a JSArray describing all channels and their live system & app states.
     */
    public static JSArray getChannelsStatusArray(Context context) {
        createAllChannels(context);
        JSArray arr = new JSArray();
        for (ChannelMeta meta : ALL_CHANNELS) {
            JSObject obj = new JSObject();
            boolean systemEnabled = isChannelEnabledInSystem(context, meta.id);
            boolean appEnabled = RifqNotificationPrefs.isChannelEnabledInApp(context, meta.id);
            obj.put("id", meta.id);
            obj.put("nameAr", meta.nameAr);
            obj.put("descriptionAr", meta.descriptionAr);
            obj.put("systemEnabled", systemEnabled);
            obj.put("appEnabled", appEnabled);
            obj.put("effectiveEnabled", systemEnabled && appEnabled);
            arr.put(obj);
        }
        return arr;
    }
}
