package com.rifq.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.rifq.app.prayerfocus.PrayerDeviceAdminReceiver;
import com.rifq.app.prayerfocus.PrayerDeviceLockService;
import com.rifq.app.prayerfocus.PrayerFocusPrefs;

/**
 * Official Android DeviceAdminReceiver in root package `com.rifq.app` for
 * RIFQ Prayer Device Lock («وضع قفل الجهاز وقت الصلاة»).
 *
 * Works alongside `com.rifq.app.prayerfocus.PrayerDeviceAdminReceiver` and `DevicePolicyManager`
 * to support Device Owner / Dedicated Device Kiosk Mode (`setLockTaskPackages`, `startLockTask`,
 * `stopLockTask`, and `lockNow`) with BIND_DEVICE_ADMIN permission.
 */
public class RifqDeviceAdminReceiver extends PrayerDeviceAdminReceiver {

    public static ComponentName getRootAdminComponentName(Context context) {
        return new ComponentName(context.getApplicationContext(), RifqDeviceAdminReceiver.class);
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        if (isDeviceOwner(context)) {
            configureKioskLockTaskPolicy(context);
        }
        if (PrayerFocusPrefs.isEnabled(context)) {
            PrayerDeviceLockService.startAndScheduleAlarms(context);
        }
    }

    @Override
    public void onProfileProvisioningComplete(Context context, Intent intent) {
        super.onProfileProvisioningComplete(context, intent);
        if (isDeviceOwner(context)) {
            configureKioskLockTaskPolicy(context);
        }
        PrayerDeviceLockService.startAndScheduleAlarms(context);
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
    }

    /**
     * Checks if either RifqDeviceAdminReceiver or PrayerDeviceAdminReceiver is an active Device Admin.
     */
    public static boolean isAnyRifqAdminActive(Context context) {
        if (context == null) return false;
        try {
            DevicePolicyManager dpm = getDpm(context);
            if (dpm == null) return false;
            return (
                dpm.isAdminActive(getRootAdminComponentName(context)) ||
                dpm.isAdminActive(PrayerDeviceAdminReceiver.getComponentName(context))
            );
        } catch (Exception e) {
            return false;
        }
    }
}
