package com.rifq.app.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/**
 * Handles incoming Firebase Cloud Messaging (FCM) / Google Cloud Messaging push intents
 * ("com.google.android.c2dm.intent.RECEIVE") so remote push notifications sent via FCM
 * are displayed as real Android System Notifications on the appropriate RIFQ channel
 * AND recorded inside RIFQ's in-app Notification Center ("مركز التذكيرات والإشعارات").
 */
public class RifqFcmPushReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        Bundle extras = intent.getExtras();
        if (extras == null || extras.isEmpty()) return;

        String title = firstNonEmpty(
            extras.getString("gcm.notification.title"),
            extras.getString("title"),
            extras.getString("notification_title")
        );
        String body = firstNonEmpty(
            extras.getString("gcm.notification.body"),
            extras.getString("body"),
            extras.getString("message"),
            extras.getString("notification_body")
        );

        // Ignore non-notification control messages
        if ((title == null || title.isEmpty()) && (body == null || body.isEmpty())) {
            return;
        }

        String channelId = firstNonEmpty(
            extras.getString("gcm.notification.android_channel_id"),
            extras.getString("channelId"),
            extras.getString("channel_id"),
            RifqNotificationChannels.CHANNEL_UPDATES
        );
        String screen = firstNonEmpty(
            extras.getString("screen"),
            extras.getString("route")
        );
        String ward = extras.getString("ward");
        String dhikrId = extras.getString("dhikrId");
        String messageId = firstNonEmpty(
            extras.getString("google.message_id"),
            extras.getString("message_id"),
            "fcm_" + System.currentTimeMillis()
        );

        int notifId = RifqAlarmScheduler.stableNotificationId(messageId);

        RifqNotificationHelper.showSystemNotification(
            context,
            notifId,
            channelId,
            title != null ? title : "رِفْق | RIFQ",
            body != null ? body : "",
            screen,
            ward,
            dhikrId,
            "fcm_" + messageId,
            false,
            true
        );
    }

    private static String firstNonEmpty(String... values) {
        if (values == null) return null;
        for (String v : values) {
            if (v != null && !v.trim().isEmpty()) {
                return v.trim();
            }
        }
        return null;
    }
}
