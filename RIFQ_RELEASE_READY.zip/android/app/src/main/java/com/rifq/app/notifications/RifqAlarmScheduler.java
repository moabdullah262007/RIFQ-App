package com.rifq.app.notifications;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

/**
 * Schedules, updates, and cancels real Android background notifications using AlarmManager.
 * Works when RIFQ is open, in background, completely closed, when the screen is off (Doze mode),
 * and restores all scheduled reminders after device reboot or time/timezone change.
 */
public class RifqAlarmScheduler {

    public static final String ACTION_TRIGGER_NOTIFICATION =
        "com.rifq.app.ACTION_TRIGGER_SCHEDULED_NOTIFICATION";

    /**
     * Generates a stable positive notification/requestCode integer from a string ID.
     */
    public static int stableNotificationId(String idStr) {
        if (idStr == null || idStr.isEmpty()) return 5000;
        int hash = idStr.hashCode() & 0x7fffffff;
        return 10000 + (hash % 800000);
    }

    /**
     * Synchronizes the full list of scheduled reminders with Android AlarmManager.
     * - Cancels any previously scheduled items that were removed or disabled.
     * - Schedules all enabled items for their exact upcoming timestamp.
     */
    public static synchronized void syncScheduleList(Context context, JSONArray newItems) {
        if (context == null) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        // 1. Cancel existing alarms first so changed times or disabled reminders never ghost-fire
        JSONArray oldItems = RifqNotificationPrefs.getScheduledItems(context);
        for (int i = 0; i < oldItems.length(); i++) {
            JSONObject oldObj = oldItems.optJSONObject(i);
            if (oldObj != null) {
                String oldId = oldObj.optString("id", "");
                int reqCode = oldObj.optInt("notificationId", stableNotificationId(oldId));
                cancelAlarmInternal(context, alarmManager, reqCode);
            }
        }

        // 2. Save new schedule list in SharedPreferences
        JSONArray safeItems = newItems != null ? newItems : new JSONArray();
        RifqNotificationPrefs.saveScheduledItems(context, safeItems);

        // 3. Schedule all enabled items
        long nowMs = System.currentTimeMillis();
        for (int i = 0; i < safeItems.length(); i++) {
            JSONObject item = safeItems.optJSONObject(i);
            if (item == null) continue;
            if (!item.optBoolean("enabled", true)) continue;

            scheduleSingleItem(context, alarmManager, item, nowMs);
        }
    }

    /**
     * Re-schedules all saved notifications (called by RifqNotificationBootReceiver on BOOT_COMPLETED,
     * MY_PACKAGE_REPLACED, TIME_SET, TIMEZONE_CHANGED).
     */
    public static synchronized void rescheduleAllSavedAlarms(Context context) {
        if (context == null) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        JSONArray savedItems = RifqNotificationPrefs.getScheduledItems(context);
        long nowMs = System.currentTimeMillis();

        for (int i = 0; i < savedItems.length(); i++) {
            JSONObject item = savedItems.optJSONObject(i);
            if (item == null || !item.optBoolean("enabled", true)) continue;

            // If item has a daily HH:mm time and its stored timestamp is in the past, roll forward to next occurrence
            long triggerMs = item.optLong("timestamp", 0L);
            String timeHHMM = item.optString("timeHHMM", "");
            boolean repeatDaily = item.optBoolean("repeatDaily", true);

            if (triggerMs <= nowMs && repeatDaily && !timeHHMM.isEmpty()) {
                triggerMs = computeNextOccurrenceMs(timeHHMM, nowMs);
                try {
                    item.put("timestamp", triggerMs);
                } catch (Exception ignored) {
                }
            }

            if (triggerMs > nowMs) {
                scheduleSingleItem(context, alarmManager, item, nowMs);
            }
        }

        RifqNotificationPrefs.saveScheduledItems(context, savedItems);
    }

    public static void scheduleSingleItem(
        Context context,
        AlarmManager alarmManager,
        JSONObject item,
        long nowMs
    ) {
        String id = item.optString("id", "notif_item");
        int notificationId = item.optInt("notificationId", stableNotificationId(id));
        String channelId = RifqNotificationChannels.normalizeChannelId(item.optString("channelId", "rifq_general"));

        if (!RifqNotificationPrefs.isChannelEnabledInApp(context, channelId)) {
            cancelAlarmInternal(context, alarmManager, notificationId);
            return;
        }

        long triggerAtMs = item.optLong("timestamp", 0L);
        String timeHHMM = item.optString("timeHHMM", "");
        boolean repeatDaily = item.optBoolean("repeatDaily", true);
        String signatureKey = item.optString("signatureKey", "");

        // If today's time has already passed (or already fired), schedule for tomorrow if repeatDaily is true
        if (
            (triggerAtMs <= nowMs - 60_000L ||
                (!signatureKey.isEmpty() && RifqNotificationPrefs.hasSignatureFired(context, signatureKey)))
            && repeatDaily
            && !timeHHMM.isEmpty()
        ) {
            triggerAtMs = computeNextOccurrenceMs(timeHHMM, nowMs + 60_000L);
            // Update signatureKey date prefix for tomorrow so tomorrow's alarm can fire cleanly
            String tomorrowDateStr = formatDateYYYYMMDD(triggerAtMs);
            signatureKey = tomorrowDateStr + "_" + id + "_" + timeHHMM;
        }

        if (triggerAtMs <= nowMs - 60_000L) {
            return;
        }

        Intent intent = new Intent(context, RifqNotificationReceiver.class);
        intent.setAction(ACTION_TRIGGER_NOTIFICATION);
        intent.putExtra("id", id);
        intent.putExtra("notificationId", notificationId);
        intent.putExtra("channelId", channelId);
        intent.putExtra("title", item.optString("title", "رِفْق | RIFQ"));
        intent.putExtra("body", item.optString("body", ""));
        intent.putExtra("screen", item.optString("screen", ""));
        intent.putExtra("ward", item.optString("ward", ""));
        intent.putExtra("dhikrId", item.optString("dhikrId", ""));
        intent.putExtra("signatureKey", signatureKey);
        intent.putExtra("timeHHMM", timeHHMM);
        intent.putExtra("repeatDaily", repeatDaily);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getBroadcast(context, notificationId, intent, flags);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            }
        } catch (SecurityException se) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMs, pi);
            }
        }
    }

    public static void cancelAlarmById(Context context, String id) {
        if (context == null || id == null) return;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        int reqCode = stableNotificationId(id);
        cancelAlarmInternal(context, alarmManager, reqCode);
    }

    private static void cancelAlarmInternal(Context context, AlarmManager alarmManager, int requestCode) {
        Intent intent = new Intent(context, RifqNotificationReceiver.class);
        intent.setAction(ACTION_TRIGGER_NOTIFICATION);
        int flags = PendingIntent.FLAG_NO_CREATE;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent, flags);
        if (pi != null) {
            alarmManager.cancel(pi);
            pi.cancel();
        }
    }

    public static long computeNextOccurrenceMs(String timeHHMM, long referenceNowMs) {
        int hour = 6;
        int minute = 30;
        if (timeHHMM != null && timeHHMM.contains(":")) {
            try {
                String[] parts = timeHHMM.split(":");
                hour = Integer.parseInt(parts[0].trim());
                minute = Integer.parseInt(parts[1].trim());
            } catch (Exception ignored) {
            }
        }

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(referenceNowMs);
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        if (cal.getTimeInMillis() <= referenceNowMs) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis();
    }

    public static String formatDateYYYYMMDD(long timestampMs) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestampMs);
        int y = cal.get(Calendar.YEAR);
        int m = cal.get(Calendar.MONTH) + 1;
        int d = cal.get(Calendar.DAY_OF_MONTH);
        return String.format(java.util.Locale.US, "%04d-%02d-%02d", y, m, d);
    }
}
