package com.rifq.app.auth;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Native Android Google Sign-In Capacitor Plugin for «رِفْق | RIFQ».
 *
 * Provides native Android account selection without opening WebView redirects or reloading the app:
 * 1. Primary: Google Play Services Native Account Picker (`GoogleSignInClient`) requesting `idToken` + `email` + `profile`.
 * 2. Automatic Native AccountManager Fallback (if APK is signed with a custom keystore whose SHA-1 causes ApiException 10 / 12500):
 *    Uses Android's built-in `AccountManager.newChooseAccountIntent` for `com.google` accounts and
 *    obtains a fresh OAuth2 access token via `GoogleAuthUtil.getToken` so `signInWithCredential`
 *    in Firebase Authentication succeeds on any Android device.
 * 3. Persists completed credentials in `SharedPreferences` (`rifq_google_auth_pending`) so even if
 *    Android recreates `MainActivity` under low memory, the sign-in result is never lost.
 */
@CapacitorPlugin(name = "RifqGoogleAuth")
public class RifqGoogleAuthPlugin extends Plugin {

    private static final String DEFAULT_WEB_CLIENT_ID =
        "11057752146-kjtsd4a9t78knhdln703cprrhl68k8hv.apps.googleusercontent.com";
    private static final String OAUTH_SCOPES =
        "oauth2:https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile";
    private static final String PREFS_NAME = "rifq_google_auth_pending";
    private static final String KEY_USE_SYSTEM_PICKER = "use_system_account_picker";

    private final ExecutorService authExecutor = Executors.newSingleThreadExecutor();
    private String lastSelectedAccountEmail = null;

    private GoogleSignInClient buildGoogleSignInClient(Context context, String webClientId) {
        String effectiveClientId = (webClientId != null && !webClientId.trim().isEmpty())
            ? webClientId.trim()
            : DEFAULT_WEB_CLIENT_ID;

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(effectiveClientId)
            .requestEmail()
            .requestProfile()
            .build();

        return GoogleSignIn.getClient(context, gso);
    }

    @PluginMethod
    public void signIn(PluginCall call) {
        Activity activity = getActivity();
        Context context = getContext();
        if (activity == null || context == null) {
            call.reject("ACTIVITY_UNAVAILABLE");
            return;
        }

        clearPendingResult(context);
        String webClientId = call.getString("webClientId", DEFAULT_WEB_CLIENT_ID);
        saveCall(call);

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.getBoolean(KEY_USE_SYSTEM_PICKER, false)) {
            launchSystemAccountPickerFallback(call);
            return;
        }

        try {
            GoogleSignInClient client = buildGoogleSignInClient(context, webClientId);
            // Sign out cached selection so the native Android Google Account chooser always appears
            client.signOut().addOnCompleteListener(activity, task -> {
                try {
                    Intent signInIntent = client.getSignInIntent();
                    startActivityForResult(call, signInIntent, "handleGoogleSignInResult");
                } catch (Exception e) {
                    launchSystemAccountPickerFallback(call);
                }
            });
        } catch (Exception e) {
            launchSystemAccountPickerFallback(call);
        }
    }

    @ActivityCallback
    private void handleGoogleSignInResult(PluginCall call, ActivityResult result) {
        Context context = getContext();
        if (call == null) {
            call = getSavedCall();
        }

        Intent data = result != null ? result.getData() : null;
        try {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            GoogleSignInAccount account = task.getResult(ApiException.class);

            if (account != null) {
                String idToken = account.getIdToken();
                String email = account.getEmail();
                String displayName = account.getDisplayName();
                Uri photoUri = account.getPhotoUrl();
                String photoUrl = photoUri != null ? photoUri.toString() : null;
                Account androidAccount = account.getAccount();

                if (email != null) {
                    lastSelectedAccountEmail = email;
                }

                if (idToken != null && !idToken.isEmpty()) {
                    completeWithSuccess(call, context, idToken, null, email, displayName, photoUrl);
                    return;
                }

                // If idToken is null, retrieve OAuth2 accessToken using the selected Android Account
                if (androidAccount != null && context != null) {
                    fetchAccessTokenForAccount(call, context, androidAccount, displayName, photoUrl);
                    return;
                }
            }

            if (result != null && result.getResultCode() == Activity.RESULT_CANCELED) {
                if (call != null) call.reject("USER_CANCELLED");
                return;
            }

            launchSystemAccountPickerFallback(call);
        } catch (ApiException e) {
            int code = e.getStatusCode();
            // 12501 = SIGN_IN_CANCELLED by user, 16 = CANCELED
            if (code == 12501 || code == 16) {
                if (call != null) {
                    call.reject("USER_CANCELLED");
                }
                return;
            }
            // 10 = DEVELOPER_ERROR (SHA-1 mismatch on custom-signed APK), 12500 = SIGN_IN_FAILED
            // Remember to use System Account Picker directly on this APK build and launch fallback now
            if (context != null && (code == 10 || code == 12500)) {
                try {
                    context
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                        .edit()
                        .putBoolean(KEY_USE_SYSTEM_PICKER, true)
                        .apply();
                } catch (Exception ignored) {
                }
            }
            launchSystemAccountPickerFallback(call);
        } catch (Exception e) {
            launchSystemAccountPickerFallback(call);
        }
    }

    private void launchSystemAccountPickerFallback(PluginCall call) {
        try {
            Intent intent = AccountManager.newChooseAccountIntent(
                null,
                null,
                new String[]{"com.google"},
                null,
                null,
                null,
                null
            );
            startActivityForResult(call, intent, "handleAccountPickerFallbackResult");
        } catch (Exception e) {
            if (call != null) {
                call.reject("SIGN_IN_FAILED: " + e.getMessage());
            }
        }
    }

    @ActivityCallback
    private void handleAccountPickerFallbackResult(PluginCall call, ActivityResult result) {
        Context context = getContext();
        if (call == null) {
            call = getSavedCall();
        }
        if (result == null || result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            if (call != null) {
                call.reject("USER_CANCELLED");
            }
            return;
        }

        String accountName = result.getData().getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
        String accountType = result.getData().getStringExtra(AccountManager.KEY_ACCOUNT_TYPE);
        if (accountName == null || accountName.trim().isEmpty()) {
            if (call != null) {
                call.reject("NO_ACCOUNT_SELECTED");
            }
            return;
        }

        lastSelectedAccountEmail = accountName;
        Account selectedAccount = new Account(
            accountName,
            accountType != null ? accountType : "com.google"
        );

        if (context != null) {
            fetchAccessTokenForAccount(call, context, selectedAccount, null, null);
        } else if (call != null) {
            call.reject("CONTEXT_UNAVAILABLE");
        }
    }

    private void fetchAccessTokenForAccount(
        final PluginCall call,
        final Context context,
        final Account account,
        final String displayName,
        final String photoUrl
    ) {
        authExecutor.execute(() -> {
            try {
                String token = GoogleAuthUtil.getToken(context, account, OAUTH_SCOPES);
                if (token != null && !token.isEmpty()) {
                    try {
                        GoogleAuthUtil.clearToken(context, token);
                        String freshToken = GoogleAuthUtil.getToken(context, account, OAUTH_SCOPES);
                        if (freshToken != null && !freshToken.isEmpty()) {
                            token = freshToken;
                        }
                    } catch (UserRecoverableAuthException re) {
                        throw re;
                    } catch (Exception ignored) {
                    }
                }
                final String finalAccessToken = token;
                Activity activity = getActivity();
                if (activity != null) {
                    activity.runOnUiThread(() ->
                        completeWithSuccess(call, context, null, finalAccessToken, account.name, displayName, photoUrl)
                    );
                } else {
                    completeWithSuccess(call, context, null, finalAccessToken, account.name, displayName, photoUrl);
                }
            } catch (UserRecoverableAuthException recoverableException) {
                Intent consentIntent = recoverableException.getIntent();
                Activity activity = getActivity();
                if (activity != null && consentIntent != null && call != null) {
                    activity.runOnUiThread(() -> {
                        saveCall(call);
                        startActivityForResult(call, consentIntent, "handleUserRecoverableConsentResult");
                    });
                } else if (call != null) {
                    call.reject("CONSENT_REQUIRED");
                }
            } catch (Exception e) {
                if (call != null) {
                    call.reject("TOKEN_ERROR: " + e.getMessage());
                }
            }
        });
    }

    @ActivityCallback
    private void handleUserRecoverableConsentResult(PluginCall call, ActivityResult result) {
        Context context = getContext();
        if (call == null) {
            call = getSavedCall();
        }
        if (result == null || result.getResultCode() != Activity.RESULT_OK) {
            if (call != null) {
                call.reject("USER_CANCELLED");
            }
            return;
        }
        if (lastSelectedAccountEmail != null && context != null) {
            Account account = new Account(lastSelectedAccountEmail, "com.google");
            fetchAccessTokenForAccount(call, context, account, null, null);
        } else if (call != null) {
            call.reject("NO_ACCOUNT_SELECTED");
        }
    }

    private void completeWithSuccess(
        PluginCall call,
        Context context,
        String idToken,
        String accessToken,
        String email,
        String displayName,
        String photoUrl
    ) {
        savePendingResult(context, idToken, accessToken, email, displayName, photoUrl);

        JSObject ret = new JSObject();
        ret.put("idToken", idToken);
        ret.put("accessToken", accessToken);
        ret.put("email", email);
        ret.put("displayName", displayName);
        ret.put("photoUrl", photoUrl);

        if (call != null) {
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void consumePendingAuthResult(PluginCall call) {
        Context context = getContext();
        JSObject ret = new JSObject();
        if (context == null) {
            ret.put("hasPending", false);
            call.resolve(ret);
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        long savedAt = prefs.getLong("savedAt", 0L);
        String idToken = prefs.getString("idToken", null);
        String accessToken = prefs.getString("accessToken", null);
        String email = prefs.getString("email", null);
        String displayName = prefs.getString("displayName", null);
        String photoUrl = prefs.getString("photoUrl", null);

        // Clear pending tokens while preserving KEY_USE_SYSTEM_PICKER
        clearPendingResult(context);

        boolean isFresh = (System.currentTimeMillis() - savedAt) < 180_000L;
        boolean hasToken = (idToken != null && !idToken.isEmpty()) || (accessToken != null && !accessToken.isEmpty());

        if (isFresh && hasToken) {
            ret.put("hasPending", true);
            ret.put("idToken", idToken);
            ret.put("accessToken", accessToken);
            ret.put("email", email);
            ret.put("displayName", displayName);
            ret.put("photoUrl", photoUrl);
        } else {
            ret.put("hasPending", false);
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void signOut(PluginCall call) {
        Context context = getContext();
        Activity activity = getActivity();
        if (context != null) {
            clearPendingResult(context);
            try {
                GoogleSignInClient client = buildGoogleSignInClient(context, DEFAULT_WEB_CLIENT_ID);
                if (activity != null) {
                    client.signOut().addOnCompleteListener(activity, task -> call.resolve());
                    return;
                } else {
                    client.signOut();
                }
            } catch (Exception ignored) {
            }
        }
        call.resolve();
    }

    private void savePendingResult(
        Context context,
        String idToken,
        String accessToken,
        String email,
        String displayName,
        String photoUrl
    ) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit()
                .putString("idToken", idToken)
                .putString("accessToken", accessToken)
                .putString("email", email)
                .putString("displayName", displayName)
                .putString("photoUrl", photoUrl)
                .putLong("savedAt", System.currentTimeMillis())
                .apply();
        } catch (Exception ignored) {
        }
    }

    private void clearPendingResult(Context context) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit()
                .remove("idToken")
                .remove("accessToken")
                .remove("email")
                .remove("displayName")
                .remove("photoUrl")
                .remove("savedAt")
                .apply();
        } catch (Exception ignored) {
        }
    }
}
