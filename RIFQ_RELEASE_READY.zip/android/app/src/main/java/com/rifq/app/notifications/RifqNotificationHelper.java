package com.rifq.app.notifications;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.rifq.app.MainActivity;
import com.rifq.app.audioathkar.RifqAudioAthkarReceiver;
import com.rifq.app.audioathkar.RifqAudioAthkarService;

/**
 * Builds and dispatches real Android System Notifications in the Notification Shade,
 * Lock Screen, Status Bar, and Notification History, while also synchronizing with
 * the in-app RIFQ Notification Center ("مركز التذكيرات والإشعارات").
 */
public class RifqNotificationHelper {

    public static final String EXTRA_FROM_NOTIFICATION_TAP = "rifq_notification_tap";
    public static final String EXTRA_NOTIF_ID = "notif_id";
    public static final String EXTRA_NOTIF_TITLE = "notif_title";
    public static final String EXTRA_NOTIF_BODY = "notif_body";
    public static final String EXTRA_NOTIF_SCREEN = "notif_screen";
    public static final String EXTRA_NOTIF_WARD = "notif_ward";
    public static final String EXTRA_NOTIF_DHIKR_ID = "notif_dhikr_id";
    public static final String EXTRA_NOTIF_CHANNEL_ID = "notif_channel_id";
    public static final String EXTRA_NOTIF_SIGNATURE_KEY = "notif_signature_key";

    /**
     * Checks whether POST_NOTIFICATIONS is granted (on Android 13+) AND system notifications are enabled.
     */
    public static boolean canPostSystemNotifications(Context context) {
        if (context == null) return false;
        if (Build.VERSION.SDK_INT >= 33) {
            int perm = ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            );
            if (perm != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return NotificationManagerCompat.from(context).areNotificationsEnabled();
    }

    /**
     * Displays a real Android System Notification in the OS status bar / notification shade.
     *
     * @return true if the notification was actually posted to Android NotificationManager; false otherwise.
     */
    public static boolean showSystemNotification(
        Context context,
        int notificationId,
        String rawChannelId,
        String title,
        String body,
        String screen,
        String ward,
        String dhikrId,
        String signatureKey,
        boolean bypassChannelCheck,
        boolean recordInAppCenter
    ) {
        if (context == null) return false;

        // 1. Ensure all Android Notification Channels exist
        RifqNotificationChannels.createAllChannels(context);
        String channelId = RifqNotificationChannels.normalizeChannelId(rawChannelId);

        // 2. Check deduplication signature if provided
        if (signatureKey != null && !signatureKey.trim().isEmpty()) {
            if (RifqNotificationPrefs.hasSignatureFired(context, signatureKey)) {
                return false;
            }
        }

        // 3. Check app-level channel toggle & quiet hours unless bypassed (e.g., manual test notification)
        if (!bypassChannelCheck) {
            if (!RifqNotificationPrefs.isChannelEnabledInApp(context, channelId)) {
                return false;
            }
            if (
                RifqNotificationPrefs.isWithinQuietHours(context) &&
                !RifqNotificationChannels.CHANNEL_PRAYER.equals(channelId)
            ) {
                // During Quiet Hours, record in-app if requested, but suppress external push sound/shade
                if (recordInAppCenter) {
                    recordAndBroadcastInApp(context, String.valueOf(notificationId), title, body, screen, ward, dhikrId, signatureKey);
                }
                return false;
            }
        }

        // 4. Verify Android System Notification permission & channel state
        if (!canPostSystemNotifications(context)) {
            return false;
        }
        if (!RifqNotificationChannels.isChannelEnabledInSystem(context, channelId)) {
            return false;
        }

        // 5. Mark signature fired so it is never duplicated
        if (signatureKey != null && !signatureKey.trim().isEmpty()) {
            RifqNotificationPrefs.markSignatureFired(context, signatureKey);
        }

        // 6. Build deep-link PendingIntent to MainActivity
        Intent tapIntent = new Intent(context, MainActivity.class);
        tapIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        tapIntent.putExtra(EXTRA_FROM_NOTIFICATION_TAP, true);
        tapIntent.putExtra(EXTRA_NOTIF_ID, String.valueOf(notificationId));
        tapIntent.putExtra(EXTRA_NOTIF_TITLE, title != null ? title : "رِفْق | RIFQ");
        tapIntent.putExtra(EXTRA_NOTIF_BODY, body != null ? body : "");
        tapIntent.putExtra(EXTRA_NOTIF_SCREEN, screen != null ? screen : "");
        tapIntent.putExtra(EXTRA_NOTIF_WARD, ward != null ? ward : "");
        tapIntent.putExtra(EXTRA_NOTIF_DHIKR_ID, dhikrId != null ? dhikrId : "");
        tapIntent.putExtra(EXTRA_NOTIF_CHANNEL_ID, channelId);
        if (signatureKey != null) {
            tapIntent.putExtra(EXTRA_NOTIF_SIGNATURE_KEY, signatureKey);
        }

        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            piFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent contentPendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            tapIntent,
            piFlags
        );

        // 7. Resolve custom monochrome small icon (@drawable/ic_stat_rifq_notification)
        int smallIconRes = context.getResources().getIdentifier(
            "ic_stat_rifq_notification",
            "drawable",
            context.getPackageName()
        );
        if (smallIconRes == 0) {
            smallIconRes = android.R.drawable.ic_popup_reminder;
        }

        String safeTitle = (title != null && !title.trim().isEmpty()) ? title.trim() : "رِفْق | RIFQ";
        String safeBody = (body != null) ? body.trim() : "";

        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
            .setSmallIcon(smallIconRes)
            .setContentTitle(safeTitle)
            .setContentText(safeBody)
            .setStyle(new NotificationCompat.BigTextStyle()
                .setBigContentTitle(safeTitle)
                .bigText(safeBody))
            .setColor(0xFF5B5FEF)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(
                RifqNotificationChannels.CHANNEL_PRAYER.equals(channelId)
                    ? NotificationCompat.CATEGORY_ALARM
                    : NotificationCompat.CATEGORY_REMINDER
            )
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setShowWhen(true)
            .setWhen(System.currentTimeMillis())
            .setDefaults(Notification.DEFAULT_ALL)
            .setVibrate(new long[] { 0, 160, 80, 200 })
            .setContentIntent(contentPendingIntent);

        if (soundUri != null) {
            builder.setSound(soundUri);
        }

        if (
            RifqNotificationChannels.CHANNEL_ADHKAR.equals(channelId) ||
            RifqNotificationChannels.CHANNEL_REMINDERS.equals(channelId)
        ) {
            Intent speakIntent = new Intent(context, RifqAudioAthkarReceiver.class);
            speakIntent.setAction(RifqAudioAthkarReceiver.ACTION_SPEAK_SPECIFIC_DHIKR);
            speakIntent.putExtra(RifqAudioAthkarService.EXTRA_DHIKR_TEXT, safeBody);
            speakIntent.putExtra(RifqAudioAthkarService.EXTRA_DHIKR_TITLE, safeTitle);
            speakIntent.putExtra(RifqAudioAthkarService.EXTRA_DHIKR_SOURCE, "رِفْق | RIFQ");
            PendingIntent speakPi = PendingIntent.getBroadcast(
                context,
                notificationId + 50000,
                speakIntent,
                piFlags
            );

            Intent stopIntent = new Intent(context, RifqAudioAthkarReceiver.class);
            stopIntent.setAction(RifqAudioAthkarService.ACTION_STOP_AUDIO_DHIKR);
            PendingIntent stopPi = PendingIntent.getBroadcast(
                context,
                88410,
                stopIntent,
                piFlags
            );

            builder.addAction(0, "🔊 استماع للذكر", speakPi);
            builder.addAction(0, "⏹ إيقاف الصوت", stopPi);
        }

        try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build());
        } catch (SecurityException se) {
            return false;
        } catch (Exception e) {
            return false;
        }

        // 8. Also record in RIFQ In-App Notification Center if requested (e.g. background alarm or FCM)
        if (recordInAppCenter) {
            recordAndBroadcastInApp(
                context,
                String.valueOf(notificationId),
                safeTitle,
                safeBody,
                screen,
                ward,
                dhikrId,
                signatureKey
            );
        }

        return true;
    }

    private static void recordAndBroadcastInApp(
        Context context,
        String id,
        String title,
        String body,
        String screen,
        String ward,
        String dhikrId,
        String signatureKey
    ) {
        long nowMs = System.currentTimeMillis();
        RifqNotificationPrefs.enqueuePendingInAppNotification(
            context,
            id,
            title,
            body,
            screen,
            ward,
            dhikrId,
            signatureKey,
            nowMs
        );
        RifqNotificationsPlugin.notifyInAppNotificationReceived(
            id,
            title,
            body,
            screen,
            ward,
            dhikrId,
            signatureKey,
            nowMs
        );
    }

    /**
     * Cancels all active notifications belonging to a specific channel or notification ID.
     */
    public static void cancelNotificationById(Context context, int notificationId) {
        if (context == null) return;
        try {
            NotificationManagerCompat.from(context).cancel(notificationId);
        } catch (Exception ignored) {
        }
    }

    public static void cancelAllNotifications(Context context) {
        if (context == null) return;
        try {
            NotificationManagerCompat.from(context).cancelAll();
        } catch (Exception ignored) {
        }
    }
}
