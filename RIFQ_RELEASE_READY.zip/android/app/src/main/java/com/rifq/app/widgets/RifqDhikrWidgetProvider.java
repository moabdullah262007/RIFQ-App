package com.rifq.app.widgets;

/**
 * Official Android Home Screen Widget Provider for RIFQ Daily Dhikr («ذكر اليوم المبارك»).
 */
public class RifqDhikrWidgetProvider extends RifqBaseWidgetProvider {
    @Override
    protected String getDefaultWidgetType() {
        return "dhikr";
    }
}
