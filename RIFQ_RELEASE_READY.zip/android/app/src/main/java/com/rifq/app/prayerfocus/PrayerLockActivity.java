package com.rifq.app.prayerfocus;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import java.lang.ref.WeakReference;
import java.util.Locale;

/**
 * Official Android Native Kiosk / Lock Task Screen for RIFQ Prayer Device Lock («وضع قفل الجهاز وقت الصلاة»).
 *
 * Key Guarantees (Requirements 1-20):
 * 1. Enters Android official Lock Task Mode (startLockTask()) immediately when Lock Task is permitted
 *    by DevicePolicyManager (Device Owner / Dedicated Device mode), natively blocking Home, Recent Apps,
 *    and app switching at the OS level.
 * 2. Source of truth for time is strictly:
 *    - adhanTimestamp (startTimeMs)
 *    - endTimestamp = adhanTimestamp + 20 minutes (endTimeMs)
 *    - Active while System.currentTimeMillis() < endTimestamp
 * 3. Displays the calm RIFQ Prayer screen:
 *    - 🕌
 *    - حان وقت الصلاة
 *    - اسم الصلاة (مثال: صلاة الظهر)
 *    - الأذان: 12:35
 *    - ينتهي وضع الصلاة: 12:55
 *    - المتبقي: 14:49
 * 4. Automatically exits Lock Task Mode (stopLockTask()) and finishes at exact endTimestamp (12:55:00)
 *    without waiting for user interaction, Firebase, or network.
 * 5. Always allows Emergency Calls / SOS (Requirement 20).
 */
public class PrayerLockActivity extends Activity {

    private static volatile WeakReference<PrayerLockActivity> activeInstanceRef = new WeakReference<>(null);

    private final Handler uiTickHandler = new Handler(Looper.getMainLooper());
    private TextView remainingTimeValueView;
    private TextView protectionBadgeView;
    private String prayerNameAr = "الظهر";
    private long adhanTimestamp = 0L;
    private long endTimestamp = 0L;
    private OnBackInvokedCallback backInvokedCallback;
    private BroadcastReceiver releaseReceiver;

    private final Runnable uiClockRunnable = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            if (!PrayerFocusPrefs.isEnabled(PrayerLockActivity.this) || now >= endTimestamp) {
                exitLockTaskAndFinishImmediately();
                return;
            }
            updateTimeLabels(now);
            uiTickHandler.postDelayed(this, 250L);
        }
    };

    public static boolean isCurrentlyShowing() {
        PrayerLockActivity act = activeInstanceRef.get();
        return act != null && !act.isFinishing() && !act.isDestroyed();
    }

    public static void finishActiveInstanceAndStopLockTask() {
        final PrayerLockActivity act = activeInstanceRef.get();
        if (act != null) {
            act.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    act.exitLockTaskAndFinishImmediately();
                }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);
        activeInstanceRef = new WeakReference<>(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        }

        registerBackBlockHandler();
        registerReleaseBroadcastReceiver();

        if (!hydrateTimestampsFromTruth(getIntent())) {
            exitLockTaskAndFinishImmediately();
            return;
        }

        buildPrayerDeviceLockUi();
        enterNativeLockTaskIfPermitted();
        startTimestampDrivenUiTicker();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        overridePendingTransition(0, 0);
        setIntent(intent);
        activeInstanceRef = new WeakReference<>(this);

        if (!hydrateTimestampsFromTruth(intent)) {
            exitLockTaskAndFinishImmediately();
            return;
        }

        buildPrayerDeviceLockUi();
        enterNativeLockTaskIfPermitted();
        startTimestampDrivenUiTicker();
    }

    @Override
    protected void onResume() {
        super.onResume();
        overridePendingTransition(0, 0);
        activeInstanceRef = new WeakReference<>(this);

        if (!hydrateTimestampsFromTruth(getIntent())) {
            exitLockTaskAndFinishImmediately();
            return;
        }

        enterNativeLockTaskIfPermitted();
        startTimestampDrivenUiTicker();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            long now = System.currentTimeMillis();
            if (now < endTimestamp && PrayerFocusPrefs.isEnabled(this)) {
                enterNativeLockTaskIfPermitted();
            } else {
                exitLockTaskAndFinishImmediately();
            }
        }
    }

    /**
     * Reads authoritative adhanTimestamp and endTimestamp from PrayerFocusPrefs (or Intent fallback).
     * Returns true ONLY if currentTime < endTimestamp.
     */
    private boolean hydrateTimestampsFromTruth(Intent intent) {
        long now = System.currentTimeMillis();
        PrayerFocusPrefs.ActiveFocusWindow active = PrayerFocusPrefs.getCurrentActiveWindow(this);

        if (active != null && now < active.endTimeMs) {
            prayerNameAr = active.prayerNameAr;
            adhanTimestamp = active.startTimeMs;
            endTimestamp = active.endTimeMs;
            return true;
        }

        if (intent != null) {
            long intentStart = intent.getLongExtra("adhanTimestamp", intent.getLongExtra("startTimeMs", 0L));
            long intentEnd = intent.getLongExtra("endTimestamp", intent.getLongExtra("endTimeMs", 0L));
            String pName = intent.getStringExtra("prayerNameAr");
            if (intentStart > 0L && intentEnd > intentStart && now < intentEnd && PrayerFocusPrefs.isEnabled(this)) {
                if (pName != null && !pName.isEmpty()) {
                    prayerNameAr = pName;
                }
                adhanTimestamp = intentStart;
                endTimestamp = intentEnd;
                return true;
            }
        }

        return false;
    }

    /**
     * Enters official Android Lock Task Mode (Kiosk Mode) when permitted by DevicePolicyManager.
     * Never shows a fake lock or pins unwhitelisted screens that could confuse the user.
     */
    private void enterNativeLockTaskIfPermitted() {
        try {
            if (PrayerDeviceAdminReceiver.isDeviceOwner(this)) {
                PrayerDeviceAdminReceiver.configureKioskLockTaskPolicy(this);
            }
            if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP &&
                PrayerDeviceAdminReceiver.isLockTaskPermitted(this) &&
                !PrayerDeviceAdminReceiver.isLockTaskActive(this)
            ) {
                startLockTask();
                PrayerFocusPrefs.getPrefs(this).edit()
                    .putBoolean(PrayerFocusPrefs.KEY_LOCK_TASK_ACTIVE, true)
                    .apply();
            }
            if (protectionBadgeView != null) {
                boolean isKioskLocked = PrayerDeviceAdminReceiver.isLockTaskActive(this);
                protectionBadgeView.setText(
                    isKioskLocked
                        ? "🔒 وضع قفل الجهاز الكامل (Kiosk Lock Task Mode) مفعّل"
                        : "🔒 وضع قفل الجهاز وقت الصلاة نشط"
                );
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Exits Android Lock Task Mode (if active) and closes PrayerLockActivity immediately.
     */
    private void exitLockTaskAndFinishImmediately() {
        uiTickHandler.removeCallbacks(uiClockRunnable);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && PrayerDeviceAdminReceiver.isLockTaskActive(this)) {
                stopLockTask();
            }
        } catch (Exception ignored) {
        }
        PrayerFocusPrefs.getPrefs(this).edit()
            .putBoolean(PrayerFocusPrefs.KEY_LOCK_TASK_ACTIVE, false)
            .apply();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        } else {
            finish();
        }
        overridePendingTransition(0, 0);
    }

    private void registerBackBlockHandler() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            backInvokedCallback = new OnBackInvokedCallback() {
                @Override
                public void onBackInvoked() {
                    // Block Back exit while currentTime < endTimestamp
                    if (System.currentTimeMillis() >= endTimestamp || !PrayerFocusPrefs.isEnabled(PrayerLockActivity.this)) {
                        exitLockTaskAndFinishImmediately();
                    }
                }
            };
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                backInvokedCallback
            );
        }
    }

    private void registerReleaseBroadcastReceiver() {
        unregisterReleaseBroadcastReceiver();
        releaseReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                exitLockTaskAndFinishImmediately();
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(PrayerDeviceLockEnforcer.ACTION_RELEASE_PRAYER_DEVICE_LOCK);
        filter.addAction(PrayerFocusAlarmReceiver.ACTION_FOCUS_END);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(releaseReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(releaseReceiver, filter);
        }
    }

    private void unregisterReleaseBroadcastReceiver() {
        if (releaseReceiver != null) {
            try {
                unregisterReceiver(releaseReceiver);
            } catch (Exception ignored) {
            }
            releaseReceiver = null;
        }
    }

    private boolean isDarkMode() {
        int nightModeFlags = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return nightModeFlags == Configuration.UI_MODE_NIGHT_YES;
    }

    private void buildPrayerDeviceLockUi() {
        boolean dark = isDarkMode();
        int screenBgColor = dark ? Color.parseColor("#141522") : Color.parseColor("#F7F7FC");
        int cardBgColor = dark ? Color.parseColor("#1E2035") : Color.WHITE;
        int cardBorderColor = dark ? Color.parseColor("#2E3152") : Color.parseColor("#E6E6F0");
        int primaryTextColor = dark ? Color.parseColor("#F7F7FC") : Color.parseColor("#25263A");
        int secondaryTextColor = dark ? Color.parseColor("#A5A8C2") : Color.parseColor("#77798C");
        int accentPurple = Color.parseColor("#5B5FEF");
        int infoBoxBgColor = dark ? Color.parseColor("#272A4A") : Color.parseColor("#EEEEFF");
        int rowBgColor = dark ? Color.parseColor("#181A2C") : Color.parseColor("#F7F7FC");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(screenBgColor);
        int pad = dp(22);
        root.setPadding(pad, pad, pad, pad);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        int cardPad = dp(24);
        card.setPadding(cardPad, cardPad, cardPad, cardPad);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(cardBgColor);
        cardBg.setCornerRadius(dp(28));
        cardBg.setStroke(dp(1), cardBorderColor);
        card.setBackground(cardBg);

        // 1. Mosque Icon 🕌
        TextView iconView = new TextView(this);
        iconView.setText("🕌");
        iconView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 52);
        iconView.setGravity(Gravity.CENTER);
        card.addView(iconView);

        // 2. Protection Status Badge
        protectionBadgeView = new TextView(this);
        boolean isKioskLocked = PrayerDeviceAdminReceiver.isLockTaskActive(this);
        protectionBadgeView.setText(
            isKioskLocked
                ? "🔒 وضع قفل الجهاز الكامل (Kiosk Lock Task Mode) مفعّل"
                : "🔒 وضع قفل الجهاز وقت الصلاة نشط"
        );
        protectionBadgeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        protectionBadgeView.setTypeface(Typeface.DEFAULT_BOLD);
        protectionBadgeView.setTextColor(accentPurple);
        protectionBadgeView.setGravity(Gravity.CENTER);
        protectionBadgeView.setPadding(dp(12), dp(6), dp(12), dp(2));
        card.addView(protectionBadgeView);

        // 3. Prayer Name (مثال: صلاة الظهر)
        TextView prayerTitleView = new TextView(this);
        prayerTitleView.setText("صلاة " + prayerNameAr);
        prayerTitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        prayerTitleView.setTypeface(Typeface.DEFAULT_BOLD);
        prayerTitleView.setTextColor(primaryTextColor);
        prayerTitleView.setGravity(Gravity.CENTER);
        prayerTitleView.setPadding(0, dp(6), 0, dp(2));
        card.addView(prayerTitleView);

        // 4. Subtitle: حان وقت الصلاة
        TextView subtitleView = new TextView(this);
        subtitleView.setText("حان وقت الصلاة");
        subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        subtitleView.setTypeface(Typeface.DEFAULT_BOLD);
        subtitleView.setTextColor(accentPurple);
        subtitleView.setGravity(Gravity.CENTER);
        card.addView(subtitleView);

        TextView descView = new TextView(this);
        descView.setText("الجهاز في وضع الصلاة لمدة 20 دقيقة منذ الأذان للتفرغ لأداء الصلاة بخشوع. يُفتح الجهاز تلقائيًا فور انتهاء الوقت.");
        descView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        descView.setTextColor(secondaryTextColor);
        descView.setGravity(Gravity.CENTER);
        descView.setPadding(dp(6), dp(6), dp(6), dp(12));
        card.addView(descView);

        // 5. Adhan Time & End Time Box (الأذان: 12:35 | ينتهي وضع الصلاة: 12:55)
        LinearLayout timesContainer = new LinearLayout(this);
        timesContainer.setOrientation(LinearLayout.VERTICAL);
        timesContainer.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable timesBg = new GradientDrawable();
        timesBg.setColor(rowBgColor);
        timesBg.setCornerRadius(dp(16));
        timesBg.setStroke(dp(1), cardBorderColor);
        timesContainer.setBackground(timesBg);
        LinearLayout.LayoutParams timesParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        timesContainer.setLayoutParams(timesParams);

        TextView adhanTimeRow = new TextView(this);
        adhanTimeRow.setText("الأذان: " + PrayerFocusPrefs.formatTimeHHMM(adhanTimestamp));
        adhanTimeRow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        adhanTimeRow.setTypeface(Typeface.DEFAULT_BOLD);
        adhanTimeRow.setTextColor(primaryTextColor);
        adhanTimeRow.setGravity(Gravity.CENTER);
        timesContainer.addView(adhanTimeRow);

        TextView endTimeRow = new TextView(this);
        endTimeRow.setText("ينتهي وضع الصلاة: " + PrayerFocusPrefs.formatTimeHHMM(endTimestamp));
        endTimeRow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        endTimeRow.setTypeface(Typeface.DEFAULT_BOLD);
        endTimeRow.setTextColor(primaryTextColor);
        endTimeRow.setGravity(Gravity.CENTER);
        endTimeRow.setPadding(0, dp(4), 0, 0);
        timesContainer.addView(endTimeRow);

        card.addView(timesContainer);

        // 6. Remaining Time Highlight Box (المتبقي: 14:49)
        LinearLayout remainingBox = new LinearLayout(this);
        remainingBox.setOrientation(LinearLayout.VERTICAL);
        remainingBox.setGravity(Gravity.CENTER);
        remainingBox.setPadding(dp(20), dp(16), dp(20), dp(16));
        GradientDrawable remBg = new GradientDrawable();
        remBg.setColor(infoBoxBgColor);
        remBg.setCornerRadius(dp(18));
        remainingBox.setBackground(remBg);
        LinearLayout.LayoutParams remParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        remParams.topMargin = dp(12);
        remainingBox.setLayoutParams(remParams);

        TextView remLabelView = new TextView(this);
        remLabelView.setText("المتبقي:");
        remLabelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        remLabelView.setTextColor(secondaryTextColor);
        remLabelView.setGravity(Gravity.CENTER);
        remainingBox.addView(remLabelView);

        remainingTimeValueView = new TextView(this);
        remainingTimeValueView.setText(formatRemainingMMSS(endTimestamp - System.currentTimeMillis()));
        remainingTimeValueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        remainingTimeValueView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        remainingTimeValueView.setTextColor(dark ? Color.WHITE : Color.parseColor("#4145C7"));
        remainingTimeValueView.setGravity(Gravity.CENTER);
        remainingTimeValueView.setPadding(0, dp(2), 0, 0);
        remainingBox.addView(remainingTimeValueView);

        card.addView(remainingBox);

        // 7. Emergency Call / SOS Button (Always Accessible — Requirement 20)
        Button emergencyBtn = new Button(this);
        emergencyBtn.setText("📞 مكالمات الطوارئ / SOS");
        emergencyBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        emergencyBtn.setTypeface(Typeface.DEFAULT_BOLD);
        emergencyBtn.setTextColor(Color.parseColor("#D95C6A"));
        emergencyBtn.setAllCaps(false);
        GradientDrawable emergBg = new GradientDrawable();
        emergBg.setColor(dark ? Color.parseColor("#2A1820") : Color.parseColor("#FFF5F6"));
        emergBg.setCornerRadius(dp(14));
        emergBg.setStroke(dp(1), Color.parseColor("#F5C2C7"));
        emergencyBtn.setBackground(emergBg);
        LinearLayout.LayoutParams emergParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(46)
        );
        emergParams.topMargin = dp(16);
        emergencyBtn.setLayoutParams(emergParams);
        emergencyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchEmergencyDialerSafely();
            }
        });
        card.addView(emergencyBtn);

        root.addView(card);
        setContentView(root);
    }

    private void launchEmergencyDialerSafely() {
        try {
            Intent emergencyIntent = new Intent("android.intent.action.EMERGENCY_DIAL");
            emergencyIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(emergencyIntent);
            return;
        } catch (Exception ignored) {
        }
        try {
            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(dialIntent);
        } catch (Exception ignored) {
        }
    }

    private void updateTimeLabels(long nowMs) {
        if (remainingTimeValueView != null) {
            long remMs = Math.max(0L, endTimestamp - nowMs);
            remainingTimeValueView.setText(formatRemainingMMSS(remMs));
        }
    }

    private String formatRemainingMMSS(long remainingMs) {
        if (remainingMs <= 0L) {
            return "00:00";
        }
        long totalSeconds = (long) Math.ceil(remainingMs / 1000.0);
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format(Locale.US, "%02d:%02d", minutes, seconds);
    }

    private void startTimestampDrivenUiTicker() {
        uiTickHandler.removeCallbacks(uiClockRunnable);
        uiTickHandler.post(uiClockRunnable);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Block Back button from exiting while currentTime < endTimestamp
        if (System.currentTimeMillis() >= endTimestamp || !PrayerFocusPrefs.isEnabled(this)) {
            exitLockTaskAndFinishImmediately();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            if (System.currentTimeMillis() < endTimestamp && PrayerFocusPrefs.isEnabled(this)) {
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        uiTickHandler.removeCallbacks(uiClockRunnable);
        unregisterReleaseBroadcastReceiver();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && backInvokedCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backInvokedCallback);
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            getResources().getDisplayMetrics()
        );
    }
}
