package com.rifq.app.prayerfocus;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.telecom.TelecomManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Shared native storage, 20-minute exact Prayer Device Lock window evaluation,
 * and dynamic Emergency / SOS exemption engine for «رِفْق | RIFQ».
 *
 * Key Guarantees:
 * - Exact 20-minute lock window: endTimestamp = adhanTimestamp + 20 minutes.
 * - Never starts a new 20-minute window on unlock or reboot mid-prayer.
 * - At any moment: if (currentTime < endTimestamp) -> ACTIVE, else -> INACTIVE.
 * - Blocks Home Launcher, Recent Apps, and all non-exempt apps during the 20-minute window.
 * - Always permits Emergency Calls, SOS, and active Telecom phone calls (Requirement 20).
 */
public class PrayerFocusPrefs {
    public static final String PREFS_NAME = "rifq_prayer_focus_native_prefs";

    /**
     * Exact 20-minute Prayer Device Lock duration from Adhan timestamp:
     * endTimestamp = adhanTimestamp + 20 minutes (1,200,000 ms).
     */
    public static final int DEFAULT_LOCK_DURATION_MINUTES = 20;
    public static final long DEFAULT_LOCK_DURATION_MS = 20L * 60L * 1000L;

    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_ACCESSIBILITY_CONSENT = "accessibility_consent";
    public static final String KEY_SERVICE_RUNNING = "service_running";
    public static final String KEY_LOCK_TASK_ACTIVE = "lock_task_active";
    public static final String KEY_DURATION_MODE = "duration_mode"; // Default: "20" (20 minutes exact)
    public static final String KEY_DURATION_MINUTES = "duration_minutes"; // Default: 20 minutes
    public static final String KEY_DISMISSED_WINDOW_ID = "dismissed_window_id";
    public static final String KEY_DISMISSED_UNTIL_MS = "dismissed_until_ms";
    public static final String KEY_PRAYER_TOGGLES = "prayer_toggles_json";
    public static final String KEY_PRAYER_SOUND_MODES = "prayer_sound_modes_json";
    public static final String KEY_ADHAN_SOUND_ENABLED = "adhan_sound_enabled";
    public static final String KEY_SCHEDULED_WINDOWS = "scheduled_windows_json";
    public static final String KEY_CITY_LAT_BITS = "city_lat_bits";
    public static final String KEY_CITY_LNG_BITS = "city_lng_bits";
    public static final String KEY_CITY_NAME_AR = "city_name_ar";
    public static final String KEY_CALC_METHOD = "calc_method";
    public static final String KEY_MADHAB = "madhab";
    public static final String KEY_MANUAL_OFFSETS = "manual_offsets_json";
    public static final String KEY_CURRENT_FOREGROUND_PKG = "current_foreground_package";

    public static final String KEY_ACTIVE_LOCK_WINDOW_ID = "active_lock_window_id";
    public static final String KEY_ACTIVE_LOCK_PRAYER_KEY = "active_lock_prayer_key";
    public static final String KEY_ACTIVE_LOCK_PRAYER_NAME = "active_lock_prayer_name";
    public static final String KEY_ACTIVE_LOCK_START_MS = "active_lock_start_ms";
    public static final String KEY_ACTIVE_LOCK_END_MS = "active_lock_end_ms";

    public static final String KEY_MANUAL_SESSION_START_MS = "manual_session_start_ms";
    public static final String KEY_MANUAL_SESSION_END_MS = "manual_session_end_ms";
    public static final String KEY_MANUAL_SESSION_PRAYER_KEY = "manual_session_prayer_key";
    public static final String KEY_MANUAL_SESSION_PRAYER_NAME = "manual_session_prayer_name";

    public static final String KEY_PENDING_HARVEST_PRAYER_KEY = "pending_harvest_prayer_key";
    public static final String KEY_PENDING_HARVEST_PRAYER_NAME = "pending_harvest_prayer_name";
    public static final String KEY_PENDING_HARVEST_DATE = "pending_harvest_date";
    public static final String KEY_FIRED_ADHAN_SIGNATURES = "fired_adhan_signatures_json";

    /**
     * Critical Emergency, SOS, Telecom, and RIFQ packages that are ALWAYS permitted
     * so Prayer Device Lock never blocks Emergency Calls or SOS (Requirement 20).
     * Note: Home Launchers and normal apps are NOT exempt during Prayer Device Lock.
     */
    private static final Set<String> CORE_EXEMPT_PACKAGES = new HashSet<>(Arrays.asList(
        "com.rifq.app",
        "com.android.phone",
        "com.android.server.telecom",
        "com.android.incallui",
        "com.google.android.dialer",
        "com.android.dialer",
        "com.samsung.android.dialer",
        "com.samsung.android.incallui",
        "com.android.emergency",
        "com.sec.android.app.emergencymode",
        "com.google.android.apps.safetyhub",
        "com.android.cellbroadcastreceiver",
        "com.google.android.cellbroadcastreceiver"
    ));

    private static volatile Set<String> cachedDynamicExemptPackages = Collections.emptySet();
    private static volatile long lastDynamicExemptCacheTimeMs = 0L;
    private static final long DYNAMIC_CACHE_TTL_MS = 60_000L;

    public static SharedPreferences getPrefs(Context context) {
        Context storageCtx = context;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && context != null && !context.isDeviceProtectedStorage()) {
            // Mirror critical lock timestamps in default context while supporting Direct Boot recovery
            storageCtx = context;
        }
        return storageCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context context) {
        return getPrefs(context).getBoolean(KEY_ENABLED, false);
    }

    public static int getLockDurationMinutes(Context context) {
        int mins = getPrefs(context).getInt(KEY_DURATION_MINUTES, DEFAULT_LOCK_DURATION_MINUTES);
        return mins > 0 ? mins : DEFAULT_LOCK_DURATION_MINUTES;
    }

    public static String formatTimeHHMM(long timestampMs) {
        if (timestampMs <= 0L) return "";
        return new SimpleDateFormat("HH:mm", Locale.US).format(new Date(timestampMs));
    }

    public static String formatTimeHHMMSS(long timestampMs) {
        if (timestampMs <= 0L) return "";
        return new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(timestampMs));
    }

    /**
     * Dynamically resolves and caches Emergency Dialer, SOS, and Telecom packages
     * so emergency calls are never blocked (Requirement 20).
     */
    private static Set<String> getDynamicExemptPackages(Context context) {
        long now = System.currentTimeMillis();
        if (now - lastDynamicExemptCacheTimeMs < DYNAMIC_CACHE_TTL_MS && !cachedDynamicExemptPackages.isEmpty()) {
            return cachedDynamicExemptPackages;
        }

        Set<String> dynamicSet = new HashSet<>();
        if (context == null) return dynamicSet;

        try {
            dynamicSet.add(context.getPackageName().toLowerCase(Locale.US));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                TelecomManager tm = (TelecomManager) context.getSystemService(Context.TELECOM_SERVICE);
                if (tm != null) {
                    String defaultDialer = tm.getDefaultDialerPackage();
                    if (defaultDialer != null && !defaultDialer.isEmpty()) {
                        dynamicSet.add(defaultDialer.toLowerCase(Locale.US));
                    }
                }
            }

            PackageManager pm = context.getPackageManager();
            if (pm != null) {
                addResolvedPackagesForIntent(pm, new Intent("android.intent.action.EMERGENCY_DIAL"), dynamicSet);
                addResolvedPackagesForIntent(pm, new Intent("android.telephony.action.EMERGENCY_ASSISTANCE"), dynamicSet);
                addResolvedPackagesForIntent(pm, new Intent("com.android.phone.EmergencyDialer.DIAL"), dynamicSet);
                addResolvedPackagesForIntent(pm, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")), dynamicSet);
            }
        } catch (Exception ignored) {
        }

        cachedDynamicExemptPackages = dynamicSet;
        lastDynamicExemptCacheTimeMs = now;
        return dynamicSet;
    }

    private static void addResolvedPackagesForIntent(PackageManager pm, Intent intent, Set<String> outSet) {
        try {
            List<ResolveInfo> list = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
            if (list != null) {
                for (ResolveInfo info : list) {
                    if (info != null && info.activityInfo != null && info.activityInfo.packageName != null) {
                        outSet.add(info.activityInfo.packageName.toLowerCase(Locale.US));
                    }
                }
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Authoritative check during Prayer Device Lock:
     * Returns true ONLY if the foreground package/activity is:
     * 1. RIFQ itself (PrayerLockActivity)
     * 2. Emergency Dialer / SOS / Telecom Phone Call UI
     * 3. Android Keyguard (SystemUI ONLY while Keyguard is locked so the user can enter PIN/biometric,
     *    after which PrayerLockActivity immediately takes over).
     *
     * Home Launcher, Recent Apps, and all other apps are NOT exempt and are immediately redirected
     * to PrayerLockActivity / Lock Task Mode!
     */
    public static boolean isExemptFromPrayerLock(Context context, String packageName, String className) {
        if (packageName == null || packageName.trim().isEmpty()) {
            return true;
        }
        String pkg = packageName.trim().toLowerCase(Locale.US);

        // 1. RIFQ itself & PrayerLockActivity
        if ("com.rifq.app".equals(pkg)) {
            return true;
        }
        if (context != null && pkg.equalsIgnoreCase(context.getPackageName())) {
            return true;
        }
        if (className != null) {
            String cls = className.trim();
            String clsLower = cls.toLowerCase(Locale.US);
            if (
                cls.contains("PrayerLockActivity") ||
                cls.contains("com.rifq.app") ||
                clsLower.contains("emergency") ||
                clsLower.contains("incall")
            ) {
                return true;
            }
        }

        // 2. Allow SystemUI ONLY while Keyguard is locked (never break Android Keyguard credential entry).
        // Once Keyguard is unlocked, SystemUI (Recents / Notification Shade) is NOT exempt!
        if ("com.android.systemui".equals(pkg) || "android".equals(pkg)) {
            if (context != null && PrayerDeviceAdminReceiver.isKeyguardLocked(context)) {
                return true;
            }
            return false;
        }

        // 3. Static core Emergency / SOS / Telecom exemptions
        if (CORE_EXEMPT_PACKAGES.contains(pkg)) {
            return true;
        }

        // 4. Dynamically resolved Emergency / Dialer / SOS packages
        if (context != null && getDynamicExemptPackages(context).contains(pkg)) {
            return true;
        }

        // 5. Pattern safety net for OEM Emergency / SOS / InCallUI packages
        if (
            pkg.contains("incallui") ||
            pkg.contains("telecom") ||
            pkg.contains("emergency") ||
            pkg.contains("sos") ||
            pkg.contains("safetyhub") ||
            pkg.contains("cellbroadcast")
        ) {
            return true;
        }

        return false;
    }

    public static boolean isProtectedSystemOrEmergencyPackage(String packageName) {
        return isExemptFromPrayerLock(null, packageName, null);
    }

    public static synchronized boolean hasAdhanFiredForWindow(Context context, String windowId) {
        if (windowId == null || windowId.trim().isEmpty()) return false;
        String raw = getPrefs(context).getString(KEY_FIRED_ADHAN_SIGNATURES, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                if (windowId.equals(arr.optString(i, ""))) {
                    return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    public static synchronized void markAdhanFiredForWindow(Context context, String windowId) {
        if (windowId == null || windowId.trim().isEmpty()) return;
        SharedPreferences prefs = getPrefs(context);
        String raw = prefs.getString(KEY_FIRED_ADHAN_SIGNATURES, "[]");
        JSONArray nextArr = new JSONArray();
        try {
            JSONArray existing = new JSONArray(raw);
            int startIdx = Math.max(0, existing.length() - 40);
            for (int i = startIdx; i < existing.length(); i++) {
                String item = existing.optString(i, "");
                if (!item.isEmpty() && !item.equals(windowId)) {
                    nextArr.put(item);
                }
            }
        } catch (Exception ignored) {
        }
        nextArr.put(windowId);
        prefs.edit().putString(KEY_FIRED_ADHAN_SIGNATURES, nextArr.toString()).apply();
    }

    public static class ActiveFocusWindow {
        public final String windowId;
        public final String prayerKey;
        public final String prayerNameAr;
        public final long startTimeMs; // adhanTimestamp
        public final long endTimeMs;   // endTimestamp = adhanTimestamp + 20 minutes

        public ActiveFocusWindow(
            String windowId,
            String prayerKey,
            String prayerNameAr,
            long startTimeMs,
            long endTimeMs
        ) {
            this.windowId = windowId;
            this.prayerKey = prayerKey;
            this.prayerNameAr = prayerNameAr;
            this.startTimeMs = startTimeMs;
            this.endTimeMs = endTimeMs;
        }

        public long getRemainingMs() {
            return Math.max(0L, endTimeMs - System.currentTimeMillis());
        }

        public long getRemainingMinutes() {
            long remMs = getRemainingMs();
            return Math.max(0L, (long) Math.ceil(remMs / 60000.0));
        }

        public String getLockStartTimeFormatted() {
            return formatTimeHHMM(startTimeMs);
        }

        public String getLockEndTimeFormatted() {
            return formatTimeHHMM(endTimeMs);
        }
    }

    /**
     * Records an active 20-minute Prayer Device Lock window in SharedPreferences.
     * Note: Never overwrites an already-active window's startTimeMs/endTimeMs with a fresh 20 minutes!
     */
    public static void setActiveLockWindow(
        Context context,
        String windowId,
        String prayerKey,
        String prayerNameAr,
        long startTimeMs,
        long endTimeMs
    ) {
        getPrefs(context).edit()
            .putString(KEY_ACTIVE_LOCK_WINDOW_ID, windowId != null ? windowId : "")
            .putString(KEY_ACTIVE_LOCK_PRAYER_KEY, prayerKey != null ? prayerKey : "dhuhr")
            .putString(KEY_ACTIVE_LOCK_PRAYER_NAME, prayerNameAr != null ? prayerNameAr : "الصلاة")
            .putLong(KEY_ACTIVE_LOCK_START_MS, startTimeMs)
            .putLong(KEY_ACTIVE_LOCK_END_MS, endTimeMs)
            .apply();
    }

    /**
     * Clears the active Prayer Device Lock window when currentTime >= endTimestamp.
     */
    public static void clearActiveLockWindow(Context context) {
        getPrefs(context).edit()
            .putLong(KEY_ACTIVE_LOCK_END_MS, 0L)
            .putLong(KEY_MANUAL_SESSION_END_MS, 0L)
            .putBoolean(KEY_LOCK_TASK_ACTIVE, false)
            .apply();
    }

    /**
     * Authoritative check for Prayer Device Lock:
     * Evaluates whether currentTime is strictly inside [adhanTimestamp, endTimestamp)
     * where endTimestamp = adhanTimestamp + 20 minutes.
     *
     * Never starts a new 20-minute timer on unlock or reboot!
     */
    public static ActiveFocusWindow getCurrentActiveWindow(Context context) {
        SharedPreferences prefs = getPrefs(context);
        if (!prefs.getBoolean(KEY_ENABLED, false)) {
            return null;
        }

        long now = System.currentTimeMillis();
        long dismissedUntil = prefs.getLong(KEY_DISMISSED_UNTIL_MS, 0L);
        String dismissedWinId = prefs.getString(KEY_DISMISSED_WINDOW_ID, "");

        // 1. Check alarm-activated 20-minute lock state
        long activeLockEnd = prefs.getLong(KEY_ACTIVE_LOCK_END_MS, 0L);
        long activeLockStart = prefs.getLong(KEY_ACTIVE_LOCK_START_MS, 0L);
        if (activeLockStart > 0L && now >= activeLockStart && now < activeLockEnd && activeLockEnd > dismissedUntil) {
            String winId = prefs.getString(KEY_ACTIVE_LOCK_WINDOW_ID, "alarm_" + activeLockStart);
            if (!winId.equals(dismissedWinId)) {
                String pKey = prefs.getString(KEY_ACTIVE_LOCK_PRAYER_KEY, "dhuhr");
                String pName = prefs.getString(KEY_ACTIVE_LOCK_PRAYER_NAME, "الصلاة");
                return new ActiveFocusWindow(winId, pKey, pName, activeLockStart, activeLockEnd);
            }
        }

        // 2. Check manual test/immediate lock session
        long manualEnd = prefs.getLong(KEY_MANUAL_SESSION_END_MS, 0L);
        long manualStart = prefs.getLong(KEY_MANUAL_SESSION_START_MS, 0L);
        if (manualStart > 0L && now >= manualStart && now < manualEnd) {
            String pKey = prefs.getString(KEY_MANUAL_SESSION_PRAYER_KEY, "dhuhr");
            String pName = prefs.getString(KEY_MANUAL_SESSION_PRAYER_NAME, "الصلاة");
            return new ActiveFocusWindow("manual_" + manualStart, pKey, pName, manualStart, manualEnd);
        }

        // 3. Check scheduled prayer windows synced from RIFQ's astronomical prayer calculator
        String windowsJson = prefs.getString(KEY_SCHEDULED_WINDOWS, "[]");
        JSONArray arr = null;
        long latestEndMs = 0L;
        try {
            arr = new JSONArray(windowsJson);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj != null) {
                    long endMs = obj.optLong("endTimeMs", 0L);
                    if (endMs > latestEndMs) latestEndMs = endMs;
                }
            }
        } catch (Exception ignored) {
        }

        // If stored windows are empty or in the past (e.g. offline for days or after reboot),
        // compute today's and tomorrow's 20-minute prayer windows natively!
        if (arr == null || arr.length() == 0 || latestEndMs < now) {
            arr = NativePrayerTimeCalculator.computeTodayAndTomorrowWindows(context);
        }

        try {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                boolean prayerEnabled = obj.optBoolean("enabled", true);
                if (!prayerEnabled) continue;

                String winId = obj.optString("id", "");
                if (!winId.isEmpty() && winId.equals(dismissedWinId)) continue;

                long startMs = obj.optLong("startTimeMs", 0L);
                long endMs = obj.optLong("endTimeMs", 0L);
                if (startMs > 0L && endMs > startMs && now >= startMs && now < endMs && endMs > dismissedUntil) {
                    String pKey = obj.optString("prayerKey", "dhuhr");
                    String pName = obj.optString("prayerNameAr", "الصلاة");
                    // Persist the exact astronomical startMs and endMs so any subsequent unlock or reboot
                    // reads the exact same [startMs, endMs] window without ever resetting it!
                    setActiveLockWindow(context, winId, pKey, pName, startMs, endMs);
                    return new ActiveFocusWindow(winId, pKey, pName, startMs, endMs);
                }
            }
        } catch (Exception ignored) {
        }

        return null;
    }
}
