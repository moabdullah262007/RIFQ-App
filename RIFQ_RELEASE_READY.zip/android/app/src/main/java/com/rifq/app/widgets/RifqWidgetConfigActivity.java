package com.rifq.app.widgets;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Official Android `APPWIDGET_CONFIGURE` Activity & In-App Native Widget Configuration Screen
 * for «رِفْق | RIFQ» Home Screen Widgets.
 *
 * Allows users to select:
 * 1. Widget Type (`tasbeeh` | `prayer` | `dhikr` | `multi`)
 * 2. Target Prayer (`next` | `fajr` | `sunrise` | `dhuhr` | `asr` | `maghrib` | `isha`)
 * 3. Stats Display Mode (`today_count` | `streak` | `lifetime` | `completed_athkar`)
 * 4. Dhikr Phrase (built-in Prophetic Athkar + user's synced custom Athkar)
 * 5. Widget Theme (`navy` | `gold` | `midnight` | `cream`)
 * 6. Widget Size (`auto` | `small` | `medium` | `large`)
 *
 * Persists all settings to `SharedPreferences` (`RifqWidgetPrefs`) so every `AppWidgetProvider`
 * reads them immediately and updates its `RemoteViews`.
 */
public class RifqWidgetConfigActivity extends Activity {

    public static final String EXTRA_LAUNCHED_FROM_APP = "launched_from_rifq_app";
    public static final String EXTRA_PRESELECT_TYPE = "preselect_type";
    public static final String EXTRA_PRESELECT_SIZE = "preselect_size";
    public static final String EXTRA_PRESELECT_THEME = "preselect_theme";
    public static final String EXTRA_PRESELECT_DHIKR = "preselect_dhikr";
    public static final String EXTRA_PRESELECT_PRAYER = "preselect_prayer";
    public static final String EXTRA_PRESELECT_STATS_MODE = "preselect_stats_mode";

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private boolean launchedFromApp = false;
    private Class<?> providerClass = RifqTasbeehWidgetProvider.class;

    private String selectedType = "tasbeeh";
    private String selectedSize = "auto";
    private String selectedTheme = "navy";
    private String selectedDhikr = RifqWidgetPrefs.TASBEEH_PRESET_PHRASES[0];
    private String selectedPrayer = "next";
    private String selectedStatsMode = "today_count";

    private final List<OptionChip> typeChips = new ArrayList<>();
    private final List<OptionChip> prayerChips = new ArrayList<>();
    private final List<OptionChip> statsChips = new ArrayList<>();
    private final List<OptionChip> sizeChips = new ArrayList<>();
    private final List<OptionChip> themeChips = new ArrayList<>();
    private final List<OptionChip> dhikrChips = new ArrayList<>();

    private static class OptionChip {
        final String key;
        final TextView view;

        OptionChip(String key, TextView view) {
            this.key = key;
            this.view = view;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent launchIntent = getIntent();
        Bundle extras = launchIntent != null ? launchIntent.getExtras() : null;
        if (extras != null) {
            appWidgetId = extras.getInt(
                AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID
            );
            launchedFromApp = extras.getBoolean(EXTRA_LAUNCHED_FROM_APP, false);
        }

        // Default cancel result as required by Android AppWidget host contract
        Intent cancelResult = new Intent();
        cancelResult.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_CANCELED, cancelResult);

        // If neither a valid appWidgetId nor an explicit in-app launch, exit cleanly
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID && !launchedFromApp) {
            finish();
            return;
        }

        // Detect default type from the AppWidgetProviderInfo if launched for a specific appWidgetId
        RifqWidgetPrefs.WidgetInstanceConfig globalDef = RifqWidgetPrefs.getGlobalDefaultConfig(this);
        String providerDefaultType = globalDef.type != null ? globalDef.type : "tasbeeh";

        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        if (manager != null && appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID && appWidgetId != 0) {
            AppWidgetProviderInfo info = manager.getAppWidgetInfo(appWidgetId);
            if (info != null && info.provider != null) {
                String clsName = info.provider.getClassName();
                if (clsName.contains("Prayer")) {
                    providerDefaultType = "prayer";
                    providerClass = RifqPrayerWidgetProvider.class;
                } else if (clsName.contains("Dhikr")) {
                    providerDefaultType = "dhikr";
                    providerClass = RifqDhikrWidgetProvider.class;
                } else if (clsName.contains("Multi")) {
                    providerDefaultType = "multi";
                    providerClass = RifqMultiWidgetProvider.class;
                } else {
                    providerDefaultType = "tasbeeh";
                    providerClass = RifqTasbeehWidgetProvider.class;
                }
            }
        }

        RifqWidgetPrefs.WidgetInstanceConfig existing = (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID && appWidgetId != 0)
            ? RifqWidgetPrefs.getWidgetConfig(this, appWidgetId, providerDefaultType)
            : globalDef;

        selectedType = existing.type != null ? existing.type : providerDefaultType;
        selectedSize = existing.size != null ? existing.size : "auto";
        selectedTheme = existing.theme != null ? existing.theme : "navy";
        selectedPrayer = existing.targetPrayer != null ? existing.targetPrayer : "next";
        selectedStatsMode = existing.statsMode != null ? existing.statsMode : "today_count";
        if (existing.customDhikr != null && !existing.customDhikr.isEmpty()) {
            selectedDhikr = existing.customDhikr;
        } else {
            selectedDhikr = RifqWidgetPrefs.getTasbeehSnapshot(this).activeDhikr;
        }

        // Apply any explicit pre-selections passed from the in-app 'Widget Settings' screen
        if (extras != null) {
            String preType = extras.getString(EXTRA_PRESELECT_TYPE, null);
            String preSize = extras.getString(EXTRA_PRESELECT_SIZE, null);
            String preTheme = extras.getString(EXTRA_PRESELECT_THEME, null);
            String preDhikr = extras.getString(EXTRA_PRESELECT_DHIKR, null);
            String prePrayer = extras.getString(EXTRA_PRESELECT_PRAYER, null);
            String preStats = extras.getString(EXTRA_PRESELECT_STATS_MODE, null);
            if (preType != null && !preType.isEmpty()) selectedType = preType;
            if (preSize != null && !preSize.isEmpty()) selectedSize = preSize;
            if (preTheme != null && !preTheme.isEmpty()) selectedTheme = preTheme;
            if (preDhikr != null && !preDhikr.isEmpty()) selectedDhikr = preDhikr;
            if (prePrayer != null && !prePrayer.isEmpty()) selectedPrayer = prePrayer;
            if (preStats != null && !preStats.isEmpty()) selectedStatsMode = preStats;
        }

        buildConfigUi();
        refreshSelectionStyles();
    }

    private void buildConfigUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.parseColor("#0F172A"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int pad = dp(20);
        root.setPadding(pad, dp(28), pad, pad);

        // Header Card
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable headerBg = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{Color.parseColor("#5B5FEF"), Color.parseColor("#4145C7")}
        );
        headerBg.setCornerRadius(dp(22));
        header.setBackground(headerBg);
        header.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView title = new TextView(this);
        title.setText(
            (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID && appWidgetId != 0)
                ? "إعداد ويدجت «رِفْق | RIFQ» (#" + appWidgetId + ")"
                : "إعدادات ويدجت الشاشة الرئيسية «رِفْق | RIFQ»"
        );
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title);

        TextView sub = new TextView(this);
        sub.setText("اختر نوع الويدجت، والصلاة أو الإحصائية أو الذكر الذي ترغب بعرضه على شاشة هاتفك الرئيسية. يتم حفظ الإعدادات فوراً في SharedPreferences وتحديث الويدجت تلقائياً.");
        sub.setTextColor(Color.parseColor("#E0E7FF"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        sub.setPadding(0, dp(6), 0, 0);
        header.addView(sub);

        root.addView(header);

        // Section 1: Widget Type
        addSectionHeader(root, "١. اختر نوع الويدجت (Widget Type):");
        addChipOption(root, typeChips, "tasbeeh", "📿 ويدجت التسبيح والإحصائيات (عداد تفاعلي مع زر +)", () -> {
            selectedType = "tasbeeh";
            refreshSelectionStyles();
        });
        addChipOption(root, typeChips, "prayer", "🕌 ويدجت مواقيت الصلاة والأذان (الصلاة والعد التنازلي)", () -> {
            selectedType = "prayer";
            refreshSelectionStyles();
        });
        addChipOption(root, typeChips, "dhikr", "✨ ويدجت ذكر اليوم المبارك (مع الفضل والمصدر والنسخ)", () -> {
            selectedType = "dhikr";
            refreshSelectionStyles();
        });
        addChipOption(root, typeChips, "multi", "🌟 الويدجت الشامل (التسبيح + الصلاة + ذكر اليوم معاً)", () -> {
            selectedType = "multi";
            refreshSelectionStyles();
        });

        // Section 2: Select Which Prayer to Display
        addSectionHeader(root, "٢. اختر الصلاة المعروضة في ويدجت الصلاة:");
        addChipOption(root, prayerChips, "next", "⏱ الصلاة القادمة تلقائياً (الافتراضي الذكي)", () -> {
            selectedPrayer = "next";
            refreshSelectionStyles();
        });
        addChipOption(root, prayerChips, "fajr", "🌌 صلاة الفجر (عرض موعد الفجر والعد التنازلي له)", () -> {
            selectedPrayer = "fajr";
            refreshSelectionStyles();
        });
        addChipOption(root, prayerChips, "sunrise", "🌅 الشروق (موعد شروق الشمس وصلاة الضحى)", () -> {
            selectedPrayer = "sunrise";
            refreshSelectionStyles();
        });
        addChipOption(root, prayerChips, "dhuhr", "☀️ صلاة الظهر (عرض موعد الظهر والعد التنازلي له)", () -> {
            selectedPrayer = "dhuhr";
            refreshSelectionStyles();
        });
        addChipOption(root, prayerChips, "asr", "🌤 صلاة العصر (عرض موعد العصر والعد التنازلي له)", () -> {
            selectedPrayer = "asr";
            refreshSelectionStyles();
        });
        addChipOption(root, prayerChips, "maghrib", "🌇 صلاة المغرب (عرض موعد المغرب والعد التنازلي له)", () -> {
            selectedPrayer = "maghrib";
            refreshSelectionStyles();
        });
        addChipOption(root, prayerChips, "isha", "🌙 صلاة العشاء (عرض موعد العشاء والعد التنازلي له)", () -> {
            selectedPrayer = "isha";
            refreshSelectionStyles();
        });

        // Section 3: Select Which Stats Metric to Display
        addSectionHeader(root, "٣. اختر الإحصائية الرئيسية في ويدجت التسبيح والشامل:");
        addChipOption(root, statsChips, "today_count", "📿 عداد تسبيحات اليوم ونسبة إنجاز الهدف اليومي", () -> {
            selectedStatsMode = "today_count";
            refreshSelectionStyles();
        });
        addChipOption(root, statsChips, "streak", "🔥 سلسلة المواظبة اليومية (عدد الأيام المتتالية)", () -> {
            selectedStatsMode = "streak";
            refreshSelectionStyles();
        });
        addChipOption(root, statsChips, "lifetime", "🏆 الحصاد الكلي (إجمالي التسبيحات منذ البدء)", () -> {
            selectedStatsMode = "lifetime";
            refreshSelectionStyles();
        });
        addChipOption(root, statsChips, "completed_athkar", "✨ إنجاز الأوراد (عدد الأذكار المكتملة اليوم)", () -> {
            selectedStatsMode = "completed_athkar";
            refreshSelectionStyles();
        });

        // Section 4: Select Which Dhikr to Display
        addSectionHeader(root, "٤. اختر الذكر المعروض في الويدجت:");
        Set<String> allPhrases = new LinkedHashSet<>();
        for (String preset : RifqWidgetPrefs.TASBEEH_PRESET_PHRASES) {
            allPhrases.add(preset);
        }
        List<RifqWidgetPrefs.BuiltInDhikr> syncedAthkar = RifqWidgetPrefs.getAllAvailableAthkar(this);
        for (RifqWidgetPrefs.BuiltInDhikr item : syncedAthkar) {
            if (item != null && item.text != null && !item.text.trim().isEmpty()) {
                allPhrases.add(item.text.trim());
            }
        }
        for (final String phrase : allPhrases) {
            addChipOption(root, dhikrChips, phrase, phrase, () -> {
                selectedDhikr = phrase;
                refreshSelectionStyles();
            });
        }

        // Section 5: Widget Theme
        addSectionHeader(root, "٥. النمط اللوني للهوية:");
        addChipOption(root, themeChips, "navy", "🔵 الأزرق الملكي (الهوية الرسمية لرِفْق)", () -> {
            selectedTheme = "navy";
            refreshSelectionStyles();
        });
        addChipOption(root, themeChips, "gold", "🟡 الذهب الخالص (أناقة مذهبة فاخرة)", () -> {
            selectedTheme = "gold";
            refreshSelectionStyles();
        });
        addChipOption(root, themeChips, "midnight", "🌑 السواد الليلي (مريح للعين وخلفيات داكنة)", () -> {
            selectedTheme = "midnight";
            refreshSelectionStyles();
        });
        addChipOption(root, themeChips, "cream", "⚪ البيج الهادئ (فاتح وناعم)", () -> {
            selectedTheme = "cream";
            refreshSelectionStyles();
        });

        // Section 6: Widget Size
        addSectionHeader(root, "٦. حجم التخطيط:");
        addChipOption(root, sizeChips, "auto", "📐 تلقائي متجاوب (يتكيف مع أبعاد الويدجت على الشاشة)", () -> {
            selectedSize = "auto";
            refreshSelectionStyles();
        });
        addChipOption(root, sizeChips, "small", "▫ صغير (2x2 مدمج)", () -> {
            selectedSize = "small";
            refreshSelectionStyles();
        });
        addChipOption(root, sizeChips, "medium", "▬ متوسط (4x2 شريط أفقي عريض)", () -> {
            selectedSize = "medium";
            refreshSelectionStyles();
        });
        addChipOption(root, sizeChips, "large", "⬛ كبير (4x4 بطاقة موسعة)", () -> {
            selectedSize = "large";
            refreshSelectionStyles();
        });

        // Save & Confirm Button
        TextView confirmBtn = new TextView(this);
        confirmBtn.setText(
            (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID && appWidgetId != 0)
                ? "✓ حفظ الإعدادات وتحديث الويدجت (#" + appWidgetId + ")"
                : "✓ حفظ الإعدادات وتطبيقها على ويدجت الشاشة الرئيسية"
        );
        confirmBtn.setGravity(Gravity.CENTER);
        confirmBtn.setTextColor(Color.parseColor("#25263A"));
        confirmBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        confirmBtn.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable btnBg = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{Color.parseColor("#E8B84A"), Color.parseColor("#F3CE75")}
        );
        btnBg.setCornerRadius(dp(16));
        confirmBtn.setBackground(btnBg);
        confirmBtn.setPadding(dp(16), dp(14), dp(16), dp(14));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        btnLp.topMargin = dp(22);
        btnLp.bottomMargin = dp(20);
        confirmBtn.setLayoutParams(btnLp);
        confirmBtn.setOnClickListener(v -> confirmAndFinish());
        root.addView(confirmBtn);

        scroll.addView(root);
        setContentView(scroll);
    }

    private void addSectionHeader(LinearLayout parent, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#E8B84A"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.topMargin = dp(18);
        lp.bottomMargin = dp(8);
        tv.setLayoutParams(lp);
        parent.addView(tv);
    }

    private void addChipOption(
        LinearLayout parent,
        List<OptionChip> group,
        String key,
        String label,
        Runnable onSelect
    ) {
        TextView chip = new TextView(this);
        chip.setText(label);
        chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        chip.setTypeface(Typeface.DEFAULT_BOLD);
        chip.setPadding(dp(14), dp(11), dp(14), dp(11));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.bottomMargin = dp(6);
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> onSelect.run());
        parent.addView(chip);
        group.add(new OptionChip(key, chip));
    }

    private void refreshSelectionStyles() {
        applyGroupStyle(typeChips, selectedType);
        applyGroupStyle(prayerChips, selectedPrayer);
        applyGroupStyle(statsChips, selectedStatsMode);
        applyGroupStyle(sizeChips, selectedSize);
        applyGroupStyle(themeChips, selectedTheme);
        applyGroupStyle(dhikrChips, selectedDhikr);
    }

    private void applyGroupStyle(List<OptionChip> group, String activeKey) {
        for (OptionChip item : group) {
            boolean isSelected = item.key.equalsIgnoreCase(activeKey);
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(14));
            if (isSelected) {
                bg.setColor(Color.parseColor("#5B5FEF"));
                bg.setStroke(dp(2), Color.parseColor("#E8B84A"));
                item.view.setTextColor(Color.WHITE);
            } else {
                bg.setColor(Color.parseColor("#1E293B"));
                bg.setStroke(dp(1), Color.parseColor("#334155"));
                item.view.setTextColor(Color.parseColor("#CBD5E1"));
            }
            item.view.setBackground(bg);
        }
    }

    private void confirmAndFinish() {
        // 1. Always persist global default widget preferences in SharedPreferences
        RifqWidgetPrefs.saveGlobalDefaultConfig(
            this,
            selectedType,
            selectedSize,
            selectedTheme,
            selectedDhikr,
            selectedPrayer,
            selectedStatsMode
        );

        AppWidgetManager manager = AppWidgetManager.getInstance(this);

        if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID && appWidgetId != 0) {
            // 2a. Save configuration for this specific appWidgetId
            RifqWidgetPrefs.saveWidgetConfig(
                this,
                appWidgetId,
                selectedType,
                selectedSize,
                selectedTheme,
                selectedDhikr,
                selectedPrayer,
                selectedStatsMode
            );

            if (manager != null) {
                android.widget.RemoteViews views = RifqWidgetRenderer.buildWidgetRemoteViews(
                    this,
                    manager,
                    appWidgetId,
                    providerClass,
                    selectedType
                );
                manager.updateAppWidget(appWidgetId, views);
            }
        } else if (manager != null) {
            // 2b. Launched from in-app 'Widget Settings' globally: apply to all placed widgets
            Class<?>[] providers = new Class<?>[]{
                RifqTasbeehWidgetProvider.class,
                RifqPrayerWidgetProvider.class,
                RifqDhikrWidgetProvider.class,
                RifqMultiWidgetProvider.class
            };
            for (Class<?> prov : providers) {
                ComponentName cn = new ComponentName(this, prov);
                int[] ids = manager.getAppWidgetIds(cn);
                if (ids == null) continue;
                for (int id : ids) {
                    RifqWidgetPrefs.saveWidgetConfig(
                        this,
                        id,
                        selectedType,
                        selectedSize,
                        selectedTheme,
                        selectedDhikr,
                        selectedPrayer,
                        selectedStatsMode
                    );
                }
            }
        }

        // 3. Refresh all placed Home Screen widgets & schedule alarms
        RifqWidgetRenderer.updateAllPlacedWidgets(this);
        RifqBaseWidgetProvider.scheduleNextPrayerTransitionAlarm(this);

        // 4. Notify Capacitor bridge so the React 'Widget Settings' page updates immediately
        RifqWidgetsPlugin.notifyWidgetConfigSaved(
            appWidgetId,
            selectedType,
            selectedSize,
            selectedTheme,
            selectedDhikr,
            selectedPrayer,
            selectedStatsMode
        );

        Intent resultValue = new Intent();
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, resultValue);
        finish();
    }

    private int dp(int value) {
        return Math.round(
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                getResources().getDisplayMetrics()
            )
        );
    }
}
