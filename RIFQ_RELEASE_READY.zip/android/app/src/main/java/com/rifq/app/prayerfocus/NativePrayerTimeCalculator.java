package com.rifq.app.prayerfocus;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Native Astronomical Prayer Time Calculator for RIFQ Prayer & Focus Mode.
 * Ensures that even if RIFQ is closed for days, or the device reboots, or the timezone changes,
 * Android Native can independently calculate accurate prayer focus windows using the user's
 * saved RIFQ location, calculation method, and madhab.
 */
public class NativePrayerTimeCalculator {

    private static double deg2rad(double d) {
        return (d * Math.PI) / 180.0;
    }

    private static double rad2deg(double r) {
        return (r * 180.0) / Math.PI;
    }

    private static double normalizeAngle(double a) {
        double b = a - 360.0 * Math.floor(a / 360.0);
        return b < 0 ? b + 360.0 : b;
    }

    private static double normalizeHours(double h) {
        double b = h - 24.0 * Math.floor(h / 24.0);
        return b < 0 ? b + 24.0 : b;
    }

    private static double getJulianDate(int year, int month, int day) {
        int y = year;
        int m = month;
        if (m <= 2) {
            y -= 1;
            m += 12;
        }
        int a = (int) Math.floor(y / 100.0);
        int b = 2 - a + (int) Math.floor(a / 4.0);
        return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + day + b - 1524.5;
    }

    private static double[] getSunPosition(double jd) {
        double d = jd - 2451545.0;
        double g = normalizeAngle(357.529 + 0.98560028 * d);
        double q = normalizeAngle(280.459 + 0.98564736 * d);
        double l = normalizeAngle(q + 1.915 * Math.sin(deg2rad(g)) + 0.020 * Math.sin(deg2rad(2 * g)));
        double e = 23.439 - 0.00000036 * d;
        double ra = rad2deg(Math.atan2(Math.cos(deg2rad(e)) * Math.sin(deg2rad(l)), Math.cos(deg2rad(l)))) / 15.0;
        double eqt = q / 15.0 - normalizeHours(ra);
        double decl = rad2deg(Math.asin(Math.sin(deg2rad(e)) * Math.sin(deg2rad(l))));
        return new double[]{decl, eqt};
    }

    private static double computeHourAngle(double lat, double decl, double angle) {
        double num = -Math.sin(deg2rad(angle)) - Math.sin(deg2rad(lat)) * Math.sin(deg2rad(decl));
        double den = Math.cos(deg2rad(lat)) * Math.cos(deg2rad(decl));
        double val = Math.max(-1.0, Math.min(1.0, num / den));
        return rad2deg(Math.acos(val)) / 15.0;
    }

    private static double computeAsrHourAngle(double lat, double decl, int shadowFactor) {
        double angle = -rad2deg(Math.atan(1.0 / (shadowFactor + Math.tan(deg2rad(Math.abs(lat - decl))))));
        return computeHourAngle(lat, decl, angle);
    }

    private static double[] getMethodParams(String method) {
        // Returns {fajrAngle, ishaAngle, ishaIntervalMinutes}
        if ("UmmAlQura".equalsIgnoreCase(method)) return new double[]{18.5, 0.0, 90.0};
        if ("MuslimWorldLeague".equalsIgnoreCase(method)) return new double[]{18.0, 17.0, 0.0};
        if ("Karachi".equalsIgnoreCase(method)) return new double[]{18.0, 18.0, 0.0};
        if ("NorthAmerica".equalsIgnoreCase(method)) return new double[]{15.0, 15.0, 0.0};
        if ("Dubai".equalsIgnoreCase(method)) return new double[]{18.2, 18.2, 0.0};
        if ("Qatar".equalsIgnoreCase(method)) return new double[]{18.0, 0.0, 90.0};
        if ("Kuwait".equalsIgnoreCase(method)) return new double[]{18.0, 17.5, 0.0};
        if ("Turkey".equalsIgnoreCase(method)) return new double[]{18.0, 17.0, 0.0};
        if ("Singapore".equalsIgnoreCase(method)) return new double[]{20.0, 18.0, 0.0};
        // Default: Egyptian General Authority of Survey
        return new double[]{19.5, 17.5, 0.0};
    }

    private static long hoursToTimestamp(Calendar dayCal, double fractionalHours, int offsetMinutes) {
        Calendar c = (Calendar) dayCal.clone();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long totalMs = Math.round((fractionalHours * 3600.0 + offsetMinutes * 60.0) * 1000.0);
        return c.getTimeInMillis() + totalMs;
    }

    /**
     * Recomputes today's and tomorrow's prayer focus windows natively and updates SharedPreferences.
     */
    public static JSONArray computeTodayAndTomorrowWindows(Context context) {
        SharedPreferences prefs = PrayerFocusPrefs.getPrefs(context);
        double lat = Double.longBitsToDouble(
            prefs.getLong(PrayerFocusPrefs.KEY_CITY_LAT_BITS, Double.doubleToLongBits(30.0444))
        );
        double lng = Double.longBitsToDouble(
            prefs.getLong(PrayerFocusPrefs.KEY_CITY_LNG_BITS, Double.doubleToLongBits(31.2357))
        );
        String method = prefs.getString(PrayerFocusPrefs.KEY_CALC_METHOD, "Egyptian");
        String madhab = prefs.getString(PrayerFocusPrefs.KEY_MADHAB, "shafi");
        String durationMode = prefs.getString(
            PrayerFocusPrefs.KEY_DURATION_MODE,
            String.valueOf(PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES)
        );
        int durationMinutes = prefs.getInt(
            PrayerFocusPrefs.KEY_DURATION_MINUTES,
            PrayerFocusPrefs.DEFAULT_LOCK_DURATION_MINUTES
        );

        JSONObject togglesObj;
        try {
            togglesObj = new JSONObject(prefs.getString(PrayerFocusPrefs.KEY_PRAYER_TOGGLES, "{}"));
        } catch (Exception e) {
            togglesObj = new JSONObject();
        }

        JSONObject offsetsObj;
        try {
            offsetsObj = new JSONObject(prefs.getString(PrayerFocusPrefs.KEY_MANUAL_OFFSETS, "{}"));
        } catch (Exception e) {
            offsetsObj = new JSONObject();
        }

        JSONArray result = new JSONArray();
        Calendar cal = Calendar.getInstance();
        for (int dayOffset = 0; dayOffset <= 1; dayOffset++) {
            Calendar targetCal = (Calendar) cal.clone();
            targetCal.add(Calendar.DAY_OF_YEAR, dayOffset);
            appendDayWindows(
                targetCal,
                lat,
                lng,
                method,
                madhab,
                durationMode,
                durationMinutes,
                togglesObj,
                offsetsObj,
                result
            );
        }

        prefs.edit().putString(PrayerFocusPrefs.KEY_SCHEDULED_WINDOWS, result.toString()).apply();
        return result;
    }

    private static void appendDayWindows(
        Calendar dayCal,
        double lat,
        double lng,
        String method,
        String madhab,
        String durationMode,
        int durationMinutes,
        JSONObject togglesObj,
        JSONObject offsetsObj,
        JSONArray outArray
    ) {
        int year = dayCal.get(Calendar.YEAR);
        int month = dayCal.get(Calendar.MONTH) + 1;
        int day = dayCal.get(Calendar.DAY_OF_MONTH);

        TimeZone tz = dayCal.getTimeZone();
        double tzOffsetHours = tz.getOffset(dayCal.getTimeInMillis()) / 3600000.0;

        double jd = getJulianDate(year, month, day) - lng / (15.0 * 24.0);
        double[] sun = getSunPosition(jd + 0.5);
        double decl = sun[0];
        double eqt = sun[1];

        double[] params = getMethodParams(method);
        double dhuhrH = 12.0 + tzOffsetHours - lng / 15.0 - eqt;
        double sunriseAngle = 0.833;
        double sunriseHa = computeHourAngle(lat, decl, sunriseAngle);
        double sunriseH = dhuhrH - sunriseHa;
        double maghribH = dhuhrH + sunriseHa;

        double fajrHa = computeHourAngle(lat, decl, params[0]);
        double fajrH = dhuhrH - fajrHa;

        int shadowFactor = "hanafi".equalsIgnoreCase(madhab) ? 2 : 1;
        double asrHa = computeAsrHourAngle(lat, decl, shadowFactor);
        double asrH = dhuhrH + asrHa;

        double ishaH;
        if (params[2] > 0) {
            ishaH = maghribH + params[2] / 60.0;
        } else {
            double ishaHa = computeHourAngle(lat, decl, params[1]);
            ishaH = dhuhrH + ishaHa;
        }

        long fajrMs = hoursToTimestamp(dayCal, fajrH, offsetsObj.optInt("fajr", 0));
        long sunriseMs = hoursToTimestamp(dayCal, sunriseH, offsetsObj.optInt("sunrise", 0));
        long dhuhrMs = hoursToTimestamp(dayCal, dhuhrH + 2.0 / 60.0, offsetsObj.optInt("dhuhr", 0));
        long asrMs = hoursToTimestamp(dayCal, asrH, offsetsObj.optInt("asr", 0));
        long maghribMs = hoursToTimestamp(dayCal, maghribH + 1.0 / 60.0, offsetsObj.optInt("maghrib", 0));
        long ishaMs = hoursToTimestamp(dayCal, ishaH, offsetsObj.optInt("isha", 0));

        // Tomorrow Fajr for Isha middle-of-the-night calculation
        long tomorrowFajrMs = fajrMs + 24L * 3600L * 1000L;
        long nightDurationMs = tomorrowFajrMs - maghribMs;
        long middleOfNightMs = maghribMs + nightDurationMs / 2L;
        long ishaNaturalEndMs = middleOfNightMs > ishaMs ? middleOfNightMs : tomorrowFajrMs;

        String dateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(dayCal.getTime());

        String[] keys = new String[]{"fajr", "dhuhr", "asr", "maghrib", "isha"};
        String[] namesAr = new String[]{"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
        long[] starts = new long[]{fajrMs, dhuhrMs, asrMs, maghribMs, ishaMs};
        long[] naturalEnds = new long[]{sunriseMs, asrMs, maghribMs, ishaMs, ishaNaturalEndMs};

        boolean useFixedMinutes = !"until_end_of_prayer".equalsIgnoreCase(durationMode) && durationMinutes > 0;

        for (int i = 0; i < keys.length; i++) {
            String pKey = keys[i];
            long sMs = starts[i];
            long natEndMs = naturalEnds[i];
            long eMs = useFixedMinutes
                ? Math.min(natEndMs, sMs + (long) durationMinutes * 60000L)
                : natEndMs;

            boolean enabled = togglesObj.optBoolean(pKey, true);
            try {
                JSONObject win = new JSONObject();
                win.put("id", dateStr + "_" + pKey);
                win.put("dateStr", dateStr);
                win.put("prayerKey", pKey);
                win.put("prayerNameAr", namesAr[i]);
                win.put("startTimeMs", sMs);
                win.put("endTimeMs", eMs);
                win.put("durationMinutes", Math.max(1L, Math.round((eMs - sMs) / 60000.0)));
                win.put("enabled", enabled);
                outArray.put(win);
            } catch (Exception ignored) {
            }
        }
    }
}
