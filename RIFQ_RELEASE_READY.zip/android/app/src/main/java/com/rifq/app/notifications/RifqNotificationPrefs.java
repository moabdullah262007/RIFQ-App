package com.rifq.app.notifications;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Iterator;

/**
 * Persistent Android SharedPreferences store for «رِفْق | RIFQ» Notifications.
 * Stores:
 * - Scheduled notifications (so AlarmManager & BootReceiver can restore all alarms after device reboot or time change)
 * - Fired notification signatures (to guarantee zero duplicate notifications across Native & WebView)
 * - Channel enable/disable preferences
 * - Quiet hours preferences
 * - Pending in-app notifications (fired while the app was in background/closed so Notification Center records them)
 * - Pending deep-link navigation target (when the user taps an Android system notification)
 */
public class RifqNotificationPrefs {

    public static final String PREFS_NAME = "rifq_notifications_native_prefs";

    public static final String KEY_SCHEDULED_ITEMS_JSON = "scheduled_items_json";
    public static final String KEY_FIRED_SIGNATURES_JSON = "fired_signatures_json";
    public static final String KEY_PENDING_IN_APP_JSON = "pending_in_app_notifications_json";
    public static final String KEY_PENDING_NAVIGATION_JSON = "pending_launch_navigation_json";
    public static final String KEY_PENDING_WIRD_INVITE_JSON = "pending_wird_invite_deep_link_json";
    public static final String KEY_QUIET_HOURS_ENABLED = "quiet_hours_enabled";
    public static final String KEY_QUIET_HOURS_START = "quiet_hours_start";
    public static final String KEY_QUIET_HOURS_END = "quiet_hours_end";
    public static final String KEY_HAS_ASKED_POST_NOTIF = "has_asked_post_notifications";

    private static final long THREE_DAYS_MS = 3L * 24L * 60L * 60L * 1000L;

    public static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static boolean isChannelEnabledInApp(Context context, String rawChannelId) {
        String normalized = RifqNotificationChannels.normalizeChannelId(rawChannelId);
        return getPrefs(context).getBoolean("channel_enabled_" + normalized, true);
    }

    public static void setChannelEnabledInApp(Context context, String rawChannelId, boolean enabled) {
        String normalized = RifqNotificationChannels.normalizeChannelId(rawChannelId);
        getPrefs(context).edit().putBoolean("channel_enabled_" + normalized, enabled).apply();
    }

    public static void setQuietHours(Context context, boolean enabled, String start, String end) {
        getPrefs(context).edit()
            .putBoolean(KEY_QUIET_HOURS_ENABLED, enabled)
            .putString(KEY_QUIET_HOURS_START, start != null ? start : "23:00")
            .putString(KEY_QUIET_HOURS_END, end != null ? end : "04:30")
            .apply();
    }

    public static boolean isWithinQuietHours(Context context) {
        SharedPreferences prefs = getPrefs(context);
        if (!prefs.getBoolean(KEY_QUIET_HOURS_ENABLED, false)) {
            return false;
        }
        String startStr = prefs.getString(KEY_QUIET_HOURS_START, "23:00");
        String endStr = prefs.getString(KEY_QUIET_HOURS_END, "04:30");

        java.util.Calendar cal = java.util.Calendar.getInstance();
        int currentMins = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE);
        int startMins = parseTimeToMinutes(startStr);
        int endMins = parseTimeToMinutes(endStr);

        if (startMins <= endMins) {
            return currentMins >= startMins && currentMins <= endMins;
        }
        return currentMins >= startMins || currentMins <= endMins;
    }

    private static int parseTimeToMinutes(String timeStr) {
        if (timeStr == null || !timeStr.contains(":")) return 0;
        try {
            String[] parts = timeStr.split(":");
            int h = Integer.parseInt(parts[0].trim());
            int m = Integer.parseInt(parts[1].trim());
            return h * 60 + m;
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Checks if a notification signatureKey has already been fired.
     */
    public static synchronized boolean hasSignatureFired(Context context, String signatureKey) {
        if (signatureKey == null || signatureKey.trim().isEmpty()) return false;
        String raw = getPrefs(context).getString(KEY_FIRED_SIGNATURES_JSON, "{}");
        try {
            JSONObject map = new JSONObject(raw);
            return map.has(signatureKey.trim());
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Records a signatureKey as fired and prunes entries older than 3 days.
     */
    public static synchronized void markSignatureFired(Context context, String signatureKey) {
        if (signatureKey == null || signatureKey.trim().isEmpty()) return;
        SharedPreferences prefs = getPrefs(context);
        String raw = prefs.getString(KEY_FIRED_SIGNATURES_JSON, "{}");
        long nowMs = System.currentTimeMillis();
        try {
            JSONObject map = new JSONObject(raw);
            JSONObject cleaned = new JSONObject();
            Iterator<String> keys = map.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                long ts = map.optLong(k, 0L);
                if (nowMs - ts <= THREE_DAYS_MS) {
                    cleaned.put(k, ts);
                }
            }
            cleaned.put(signatureKey.trim(), nowMs);
            prefs.edit().putString(KEY_FIRED_SIGNATURES_JSON, cleaned.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /**
     * Saves the full list of scheduled notification items.
     */
    public static synchronized void saveScheduledItems(Context context, JSONArray items) {
        getPrefs(context).edit()
            .putString(KEY_SCHEDULED_ITEMS_JSON, items != null ? items.toString() : "[]")
            .apply();
    }

    public static synchronized JSONArray getScheduledItems(Context context) {
        String raw = getPrefs(context).getString(KEY_SCHEDULED_ITEMS_JSON, "[]");
        try {
            return new JSONArray(raw);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    /**
     * Queues a fired notification for the in-app Notification Center ("مركز التذكيرات والإشعارات")
     * so notifications fired while the app was closed/in background appear inside RIFQ Notification Center.
     */
    public static synchronized void enqueuePendingInAppNotification(
        Context context,
        String id,
        String title,
        String message,
        String screen,
        String ward,
        String dhikrId,
        String signatureKey,
        long timestampMs
    ) {
        SharedPreferences prefs = getPrefs(context);
        String raw = prefs.getString(KEY_PENDING_IN_APP_JSON, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            // Prevent duplicate entries in pending queue
            for (int i = 0; i < arr.length(); i++) {
                JSONObject existing = arr.optJSONObject(i);
                if (existing != null) {
                    if (signatureKey != null && !signatureKey.isEmpty() && signatureKey.equals(existing.optString("signatureKey"))) {
                        return;
                    }
                    if (id != null && !id.isEmpty() && id.equals(existing.optString("id"))) {
                        return;
                    }
                }
            }

            JSONObject item = new JSONObject();
            item.put("id", id != null && !id.isEmpty() ? id : "native_" + timestampMs);
            item.put("title", title != null ? title : "رِفْق");
            item.put("message", message != null ? message : "");
            item.put("screen", screen != null ? screen : "");
            item.put("ward", ward != null ? ward : "");
            item.put("dhikrId", dhikrId != null ? dhikrId : "");
            item.put("signatureKey", signatureKey != null ? signatureKey : "");
            item.put("timestamp", timestampMs);

            // Keep latest 50 items
            JSONArray nextArr = new JSONArray();
            nextArr.put(item);
            for (int i = 0; i < Math.min(arr.length(), 49); i++) {
                nextArr.put(arr.get(i));
            }
            prefs.edit().putString(KEY_PENDING_IN_APP_JSON, nextArr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static synchronized JSONArray consumePendingInAppNotifications(Context context) {
        SharedPreferences prefs = getPrefs(context);
        String raw = prefs.getString(KEY_PENDING_IN_APP_JSON, "[]");
        prefs.edit().putString(KEY_PENDING_IN_APP_JSON, "[]").apply();
        try {
            return new JSONArray(raw);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    /**
     * Stores deep-link navigation target when the user taps an Android notification from the Notification Shade.
     */
    public static synchronized void setPendingNavigation(
        Context context,
        String screen,
        String ward,
        String dhikrId,
        String notificationId
    ) {
        try {
            JSONObject nav = new JSONObject();
            nav.put("screen", screen != null ? screen : "");
            nav.put("ward", ward != null ? ward : "");
            nav.put("dhikrId", dhikrId != null ? dhikrId : "");
            nav.put("notificationId", notificationId != null ? notificationId : "");
            nav.put("timestamp", System.currentTimeMillis());
            getPrefs(context).edit().putString(KEY_PENDING_NAVIGATION_JSON, nav.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static synchronized JSONObject consumePendingNavigation(Context context) {
        SharedPreferences prefs = getPrefs(context);
        String raw = prefs.getString(KEY_PENDING_NAVIGATION_JSON, null);
        if (raw == null || raw.isEmpty()) return null;
        prefs.edit().remove(KEY_PENDING_NAVIGATION_JSON).apply();
        try {
            return new JSONObject(raw);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Stores pending WIRD group invite code received via Android App Link / Deep Link (?wirdJoin=INVITE_CODE).
     */
    public static synchronized void setPendingWirdInvite(
        Context context,
        String inviteCode,
        String rawUrl
    ) {
        if (inviteCode == null || inviteCode.trim().isEmpty()) return;
        try {
            JSONObject obj = new JSONObject();
            obj.put("inviteCode", inviteCode.trim().toUpperCase());
            obj.put("url", rawUrl != null ? rawUrl : "");
            obj.put("timestamp", System.currentTimeMillis());
            getPrefs(context).edit().putString(KEY_PENDING_WIRD_INVITE_JSON, obj.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static synchronized JSONObject consumePendingWirdInvite(Context context) {
        SharedPreferences prefs = getPrefs(context);
        String raw = prefs.getString(KEY_PENDING_WIRD_INVITE_JSON, null);
        if (raw == null || raw.isEmpty()) return null;
        prefs.edit().remove(KEY_PENDING_WIRD_INVITE_JSON).apply();
        try {
            return new JSONObject(raw);
        } catch (Exception e) {
            return null;
        }
    }
}
