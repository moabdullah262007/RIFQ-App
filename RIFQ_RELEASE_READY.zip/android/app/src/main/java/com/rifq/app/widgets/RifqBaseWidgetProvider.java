package com.rifq.app.widgets;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.widget.RemoteViews;

/**
 * Base Android Native `AppWidgetProvider` for all 4 RIFQ Home Screen Widgets.
 *
 * Works 100% natively in the background (when RIFQ is open, backgrounded, or closed,
 * offline, or after device reboot) without relying on any JavaScript timers.
 */
public abstract class RifqBaseWidgetProvider extends AppWidgetProvider {

    private static final int REQUEST_CODE_PRAYER_TRANSITION_ALARM = 7910;

    protected abstract String getDefaultWidgetType();

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        if (context == null || appWidgetManager == null || appWidgetIds == null) return;
        String defaultType = getDefaultWidgetType();
        for (int appWidgetId : appWidgetIds) {
            RifqWidgetPrefs.applyPendingPinConfigIfRecent(context, appWidgetId, defaultType);
            RemoteViews views = RifqWidgetRenderer.buildWidgetRemoteViews(
                context,
                appWidgetManager,
                appWidgetId,
                getClass(),
                defaultType
            );
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
        scheduleNextPrayerTransitionAlarm(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(
        Context context,
        AppWidgetManager appWidgetManager,
        int appWidgetId,
        Bundle newOptions
    ) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions);
        if (context == null || appWidgetManager == null) return;
        RemoteViews views = RifqWidgetRenderer.buildWidgetRemoteViews(
            context,
            appWidgetManager,
            appWidgetId,
            getClass(),
            getDefaultWidgetType()
        );
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        if (context == null || appWidgetIds == null) return;
        for (int id : appWidgetIds) {
            RifqWidgetPrefs.deleteWidgetConfig(context, id);
        }
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        if (context != null) {
            scheduleNextPrayerTransitionAlarm(context);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (context == null || intent == null || intent.getAction() == null) return;

        String action = intent.getAction();
        int appWidgetId = intent.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        );

        if (RifqWidgetRenderer.ACTION_INCREMENT_TASBEEH.equals(action)) {
            RifqWidgetPrefs.WidgetInstanceConfig cfg = (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID)
                ? RifqWidgetPrefs.getWidgetConfig(context, appWidgetId, getDefaultWidgetType())
                : null;
            String customDhikr = (cfg != null && cfg.customDhikr != null && !cfg.customDhikr.isEmpty())
                ? cfg.customDhikr
                : null;

            RifqWidgetPrefs.TasbeehSnapshot snap = RifqWidgetPrefs.incrementTasbeehAtomically(
                context,
                1,
                customDhikr
            );
            if (snap.vibrationEnabled) {
                triggerSubtleHaptic(context);
            }
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
            RifqWidgetsPlugin.notifyNativeTasbeehIncremented(snap);
        } else if (RifqWidgetRenderer.ACTION_CYCLE_TASBEEH_DHIKR.equals(action)) {
            RifqWidgetPrefs.cycleTasbeehDhikr(
                context,
                appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID ? appWidgetId : 0
            );
            triggerSubtleHaptic(context);
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
        } else if (RifqWidgetRenderer.ACTION_NEXT_DHIKR.equals(action)) {
            RifqWidgetPrefs.advanceToNextDhikr(
                context,
                appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID ? appWidgetId : 0
            );
            triggerSubtleHaptic(context);
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
        } else if (RifqWidgetRenderer.ACTION_SPEAK_DHIKR.equals(action)) {
            triggerSubtleHaptic(context);
            if (com.rifq.app.audioathkar.RifqAudioAthkarPrefs.isCurrentlyPlaying(context)) {
                com.rifq.app.audioathkar.RifqAudioAthkarService.stopSpeakingNow(context);
            } else {
                RifqWidgetPrefs.BuiltInDhikr dhikr = RifqWidgetPrefs.getCurrentDhikrForWidget(
                    context,
                    appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID ? appWidgetId : 0
                );
                com.rifq.app.audioathkar.RifqAudioAthkarService.speakDhikrNow(
                    context,
                    dhikr.text,
                    "ذكر اليوم من ويدجت رِفْق",
                    dhikr.source,
                    null,
                    true,
                    false
                );
            }
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
        } else if (RifqWidgetRenderer.ACTION_COPY_DHIKR.equals(action)) {
            RifqWidgetPrefs.BuiltInDhikr dhikr = RifqWidgetPrefs.getCurrentDhikrForWidget(
                context,
                appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID ? appWidgetId : 0
            );
            try {
                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText(
                        "ذكر من رِفْق",
                        dhikr.text + "\n(" + dhikr.source + ")\nمن تطبيق رِفْق | RIFQ"
                    );
                    clipboard.setPrimaryClip(clip);
                }
                RifqWidgetPrefs.getPrefs(context).edit()
                    .putLong(RifqWidgetPrefs.KEY_COPY_FEEDBACK_UNTIL_MS, System.currentTimeMillis() + 2500L)
                    .commit();
            } catch (Exception ignored) {
            }
            triggerSubtleHaptic(context);
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
        } else if (RifqWidgetRenderer.ACTION_WIDGET_PINNED.equals(action)) {
            if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                RifqWidgetPrefs.applyPendingPinConfigIfRecent(context, appWidgetId, getDefaultWidgetType());
            }
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
            scheduleNextPrayerTransitionAlarm(context);
            RifqWidgetsPlugin.notifyWidgetPinned(appWidgetId, getDefaultWidgetType());
        } else if (
            RifqWidgetRenderer.ACTION_REFRESH_WIDGET.equals(action) ||
            RifqWidgetRenderer.ACTION_AUTO_UPDATE_PRAYER_TRANSITION.equals(action) ||
            Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_MY_PACKAGE_REPLACED.equals(action) ||
            Intent.ACTION_TIME_CHANGED.equals(action) ||
            Intent.ACTION_TIMEZONE_CHANGED.equals(action) ||
            Intent.ACTION_DATE_CHANGED.equals(action) ||
            Intent.ACTION_USER_PRESENT.equals(action) ||
            "android.intent.action.QUICKBOOT_POWERON".equals(action)
        ) {
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
            scheduleNextPrayerTransitionAlarm(context);
        }
    }

    /**
     * Schedules an Android `AlarmManager` wakeup for the next 15-minute boundary or exact
     * Next Prayer transition time so the Prayer & Multi widgets always stay up to date
     * without using any continuous background timer.
     */
    public static void scheduleNextPrayerTransitionAlarm(Context context) {
        if (context == null) return;
        try {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            RifqWidgetPrayerCalculator.PrayerWidgetSnapshot snap = RifqWidgetPrayerCalculator.calculateSnapshot(context);
            long now = System.currentTimeMillis();
            long fifteenMinsLater = now + 15L * 60_000L;
            long triggerAt = (snap.nextPrayerTimeMs > now && snap.nextPrayerTimeMs < fifteenMinsLater)
                ? snap.nextPrayerTimeMs + 1500L
                : fifteenMinsLater;

            Intent intent = new Intent(context, RifqPrayerWidgetProvider.class);
            intent.setAction(RifqWidgetRenderer.ACTION_AUTO_UPDATE_PRAYER_TRANSITION);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent pi = PendingIntent.getBroadcast(
                context,
                REQUEST_CODE_PRAYER_TRANSITION_ALARM,
                intent,
                flags
            );
            am.set(AlarmManager.RTC, triggerAt, pi);
        } catch (Exception ignored) {
        }
    }

    private static void triggerSubtleHaptic(Context context) {
        try {
            Vibrator vibrator = null;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                VibratorManager vm = (VibratorManager) context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vibrator = vm.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(18);
                }
            }
        } catch (Exception ignored) {
        }
    }
}
