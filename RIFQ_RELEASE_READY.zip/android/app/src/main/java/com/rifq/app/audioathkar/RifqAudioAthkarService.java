package com.rifq.app.audioathkar;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import androidx.core.app.NotificationCompat;
import com.rifq.app.MainActivity;
import com.rifq.app.R;
import com.rifq.app.notifications.RifqNotificationChannels;
import com.rifq.app.notifications.RifqNotificationHelper;
import com.rifq.app.notifications.RifqNotificationsPlugin;
import com.rifq.app.widgets.RifqWidgetRenderer;
import java.util.Locale;
import java.util.Set;

/**
 * Android Native Service for Spoken Audio Athkar («خدمة الأذكار الصوتية الأصلية على جهاز المستخدم»).
 *
 * Capabilities:
 * 1. Device-level playback via Android Native `TextToSpeech` + `AudioAttributes` (works over
 *    Phone Speaker, Bluetooth, or Headphones even when RIFQ is closed or the screen is locked).
 * 2. Smart Arabic Male Voice selection from `tts.getVoices()` with calm pitch & rate tuning.
 * 3. Proper Android `AudioFocusRequest` (`AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK`) and automatic
 *    `abandonAudioFocusRequest` immediately upon completion or interruption.
 * 4. Zero overlap: flushes any previous utterance and immediately stops if a phone call starts.
 * 5. Immediate Stop action (`ACTION_STOP_AUDIO_DHIKR`) accessible from Notification, Widget, or App.
 */
public class RifqAudioAthkarService extends Service implements TextToSpeech.OnInitListener {

    public static final String ACTION_SPEAK_DHIKR = "com.rifq.app.audioathkar.ACTION_SPEAK_DHIKR";
    public static final String ACTION_STOP_AUDIO_DHIKR = "com.rifq.app.audioathkar.ACTION_STOP_AUDIO_DHIKR";

    public static final String EXTRA_DHIKR_TEXT = "extra_dhikr_text";
    public static final String EXTRA_DHIKR_TITLE = "extra_dhikr_title";
    public static final String EXTRA_DHIKR_SOURCE = "extra_dhikr_source";
    public static final String EXTRA_DHIKR_ID = "extra_dhikr_id";
    public static final String EXTRA_CATEGORY_OVERRIDE = "extra_category_override";
    public static final String EXTRA_IS_MANUAL_TRIGGER = "extra_is_manual_trigger";
    public static final String EXTRA_SHOW_TEXT_NOTIFICATION = "extra_show_text_notification";

    private static final int ACTIVE_AUDIO_CONTROL_NOTIF_ID = 88401;
    private static final int PERSISTENT_DHIKR_NOTIF_ID = 88402;
    private static final String UTTERANCE_ID_PREFIX = "rifq_dhikr_utterance_";

    private TextToSpeech tts;
    private boolean isTtsInitialized = false;
    private PendingSpeechRequest pendingRequest = null;

    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private PowerManager.WakeLock wakeLock;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private static class PendingSpeechRequest {
        final String id;
        final String title;
        final String text;
        final String source;
        final boolean isManual;
        final boolean showTextNotification;

        PendingSpeechRequest(
            String id,
            String title,
            String text,
            String source,
            boolean isManual,
            boolean showTextNotification
        ) {
            this.id = id;
            this.title = title;
            this.text = text;
            this.source = source;
            this.isManual = isManual;
            this.showTextNotification = showTextNotification;
        }
    }

    private final AudioManager.OnAudioFocusChangeListener audioFocusChangeListener = focusChange -> {
        if (
            focusChange == AudioManager.AUDIOFOCUS_LOSS ||
            focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT
        ) {
            // Immediately stop spoken Dhikr if a phone call or high-priority audio takes focus
            stopCurrentSpeechAndCleanup();
        }
    };

    /**
     * Convenience helper to start speaking a specific Dhikr (or pick the next non-repeating Dhikr)
     * from anywhere in Native Android (AlarmReceiver, NotificationReceiver, Widget, or Plugin).
     */
    public static void speakDhikrNow(
        Context context,
        String text,
        String title,
        String source,
        String categoryOverride,
        boolean isManualTrigger,
        boolean showTextNotification
    ) {
        if (context == null) return;
        if (!RifqAudioAthkarPrefs.canPlayAudioNow(context, isManualTrigger)) {
            return;
        }
        try {
            Intent intent = new Intent(context, RifqAudioAthkarService.class);
            intent.setAction(ACTION_SPEAK_DHIKR);
            if (text != null && !text.trim().isEmpty()) {
                intent.putExtra(EXTRA_DHIKR_TEXT, text.trim());
            }
            if (title != null && !title.trim().isEmpty()) {
                intent.putExtra(EXTRA_DHIKR_TITLE, title.trim());
            }
            if (source != null && !source.trim().isEmpty()) {
                intent.putExtra(EXTRA_DHIKR_SOURCE, source.trim());
            }
            if (categoryOverride != null && !categoryOverride.trim().isEmpty()) {
                intent.putExtra(EXTRA_CATEGORY_OVERRIDE, categoryOverride.trim());
            }
            intent.putExtra(EXTRA_IS_MANUAL_TRIGGER, isManualTrigger);
            intent.putExtra(EXTRA_SHOW_TEXT_NOTIFICATION, showTextNotification);
            context.startService(intent);
        } catch (Exception ignored) {
        }
    }

    /**
     * Immediately stops any active spoken Dhikr on the device.
     */
    public static void stopSpeakingNow(Context context) {
        if (context == null) return;
        try {
            RifqAudioAthkarPrefs.setPlayingState(context, false, "", "");
            CancelNotificationHelper.cancelControlNotification(context);
            RifqWidgetRenderer.updateAllPlacedWidgets(context);
            RifqNotificationsPlugin.notifyAudioAthkarStateChanged(context);

            Intent intent = new Intent(context, RifqAudioAthkarService.class);
            intent.setAction(ACTION_STOP_AUDIO_DHIKR);
            context.startService(intent);
        } catch (Exception ignored) {
        }
    }

    private static class CancelNotificationHelper {
        static void cancelControlNotification(Context context) {
            try {
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    nm.cancel(ACTIVE_AUDIO_CONTROL_NOTIF_ID);
                }
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        initTtsEngine();
    }

    private void initTtsEngine() {
        try {
            tts = new TextToSpeech(getApplicationContext(), this);
        } catch (Exception ignored) {
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || intent.getAction() == null) {
            stopSelfResult(startId);
            return START_NOT_STICKY;
        }

        String action = intent.getAction();
        if (ACTION_STOP_AUDIO_DHIKR.equals(action)) {
            stopCurrentSpeechAndCleanup();
            stopSelf();
            return START_NOT_STICKY;
        }

        if (ACTION_SPEAK_DHIKR.equals(action)) {
            boolean isManual = intent.getBooleanExtra(EXTRA_IS_MANUAL_TRIGGER, false);
            if (!RifqAudioAthkarPrefs.canPlayAudioNow(this, isManual)) {
                stopSelfResult(startId);
                return START_NOT_STICKY;
            }

            String text = intent.getStringExtra(EXTRA_DHIKR_TEXT);
            String title = intent.getStringExtra(EXTRA_DHIKR_TITLE);
            String source = intent.getStringExtra(EXTRA_DHIKR_SOURCE);
            String id = intent.getStringExtra(EXTRA_DHIKR_ID);
            String categoryOverride = intent.getStringExtra(EXTRA_CATEGORY_OVERRIDE);
            boolean showTextNotif = intent.getBooleanExtra(EXTRA_SHOW_TEXT_NOTIFICATION, false);

            if (text == null || text.trim().isEmpty()) {
                RifqAudioAthkarCatalog.AudioDhikrEntry picked =
                    RifqAudioAthkarCatalog.pickNextNonRepeatingDhikr(this, categoryOverride);
                id = picked.id;
                title = picked.title;
                text = picked.text;
                source = picked.source;
            } else {
                if (id == null || id.isEmpty()) id = "custom_spoken";
                if (title == null || title.isEmpty()) title = "ذكر مبارك من رِفْق";
                if (source == null || source.isEmpty()) source = "رِفْق | RIFQ";
            }

            PendingSpeechRequest request = new PendingSpeechRequest(
                id,
                title,
                text,
                source,
                isManual,
                showTextNotif
            );

            if (isTtsInitialized && tts != null) {
                executeSpeechRequest(request);
            } else {
                pendingRequest = request;
                if (tts == null) {
                    initTtsEngine();
                }
            }
        }

        return START_NOT_STICKY;
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && tts != null) {
            isTtsInitialized = true;
            configureArabicMaleVoice();
            setupUtteranceListener();

            if (pendingRequest != null) {
                PendingSpeechRequest req = pendingRequest;
                pendingRequest = null;
                executeSpeechRequest(req);
            }
        } else {
            isTtsInitialized = false;
            stopCurrentSpeechAndCleanup();
            stopSelf();
        }
    }

    /**
     * Requirement 3: Inspects available Arabic TTS voices on the user's Android device
     * and selects the clearest Arabic male voice available without inventing non-existent voices.
     */
    private void configureArabicMaleVoice() {
        if (tts == null) return;
        RifqAudioAthkarPrefs.AudioAthkarConfig cfg = RifqAudioAthkarPrefs.loadConfig(this);

        Locale arabicSa = new Locale("ar", "SA");
        Locale arabicGeneral = new Locale("ar");
        int langResult = tts.setLanguage(arabicSa);
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(arabicGeneral);
        }

        String selectedVoiceSummary = "الصوت العربي الافتراضي للنظام";
        boolean matchedMale = false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null && !voices.isEmpty()) {
                    Voice bestVoice = null;
                    int bestScore = -1;

                    for (Voice v : voices) {
                        if (v == null || v.getLocale() == null) continue;
                        String lang = v.getLocale().getLanguage();
                        if (lang == null || !lang.toLowerCase(Locale.US).startsWith("ar")) {
                            continue;
                        }

                        String vName = v.getName() != null ? v.getName().toLowerCase(Locale.US) : "";
                        int score = 10;

                        // If user explicitly chose a preferred voice name and it exists on this device
                        if (
                            cfg.preferredVoiceName != null &&
                            !cfg.preferredVoiceName.isEmpty() &&
                            v.getName().equalsIgnoreCase(cfg.preferredVoiceName)
                        ) {
                            bestVoice = v;
                            bestScore = 1000;
                            matchedMale = isLikelyMaleVoiceName(vName);
                            break;
                        }

                        // Prefer local installed voices that don't require network
                        if (!v.isNetworkConnectionRequired()) {
                            score += 25;
                        }

                        // High quality voices
                        if (v.getQuality() >= Voice.QUALITY_HIGH) {
                            score += 20;
                        } else if (v.getQuality() >= Voice.QUALITY_NORMAL) {
                            score += 10;
                        }

                        // Known Arabic Male TTS voice identifiers across Google/Android/Samsung engines:
                        // Google TTS Arabic male voices: ar-xa-x-ard-local, ar-xa-x-are-local, ar-xa-x-ard-network, etc.
                        if (isLikelyMaleVoiceName(vName)) {
                            score += 60;
                        } else if (isLikelyFemaleVoiceName(vName)) {
                            score -= 20;
                        }

                        if (score > bestScore) {
                            bestScore = score;
                            bestVoice = v;
                        }
                    }

                    if (bestVoice != null) {
                        tts.setVoice(bestVoice);
                        matchedMale = isLikelyMaleVoiceName(bestVoice.getName().toLowerCase(Locale.US));
                        selectedVoiceSummary = matchedMale
                            ? "صوت رجل عربي واضح (" + bestVoice.getName() + ")"
                            : "صوت عربي هادئ (" + bestVoice.getName() + ")";
                    }
                }
            } catch (Exception ignored) {
            }
        }

        // Calm, clear, dignified cadence suitable for RIFQ Athkar
        // If the device only had a neutral/default Arabic voice, a slightly deeper pitch (0.88f-0.92f)
        // provides a calm, warm, masculine resonance without distortion.
        float targetPitch = matchedMale ? cfg.speechPitch : Math.min(cfg.speechPitch, 0.89f);
        tts.setPitch(targetPitch);
        tts.setSpeechRate(cfg.speechRate);

        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build();
        tts.setAudioAttributes(attrs);

        RifqAudioAthkarPrefs.getPrefs(this).edit()
            .putString(RifqAudioAthkarPrefs.KEY_DETECTED_VOICE_SUMMARY, selectedVoiceSummary)
            .putBoolean(RifqAudioAthkarPrefs.KEY_IS_MALE_VOICE_MATCHED, matchedMale)
            .apply();
    }

    private boolean isLikelyMaleVoiceName(String lowerName) {
        if (lowerName == null) return false;
        return (
            lowerName.contains("male") && !lowerName.contains("female") ||
            lowerName.contains("ar-xa-x-ard") ||
            lowerName.contains("ar-xa-x-are") ||
            lowerName.contains("ar-xa-x-arf") ||
            lowerName.contains("naayf") ||
            lowerName.contains("maged") ||
            lowerName.contains("tarik") ||
            lowerName.contains("hamdan") ||
            lowerName.contains("omar") ||
            lowerName.contains("-m-") ||
            lowerName.endsWith("_m")
        );
    }

    private boolean isLikelyFemaleVoiceName(String lowerName) {
        if (lowerName == null) return false;
        return (
            lowerName.contains("female") ||
            lowerName.contains("ar-xa-x-arc") ||
            lowerName.contains("ar-xa-x-arz") ||
            lowerName.contains("laila") ||
            lowerName.contains("mariam") ||
            lowerName.contains("salma") ||
            lowerName.contains("zeina") ||
            lowerName.contains("hoda")
        );
    }

    private void setupUtteranceListener() {
        if (tts == null) return;
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                mainHandler.post(() -> {
                    RifqWidgetRenderer.updateAllPlacedWidgets(getApplicationContext());
                    RifqNotificationsPlugin.notifyAudioAthkarStateChanged(getApplicationContext());
                });
            }

            @Override
            public void onDone(String utteranceId) {
                mainHandler.post(() -> {
                    stopCurrentSpeechAndCleanup();
                    stopSelf();
                });
            }

            @Override
            public void onError(String utteranceId) {
                mainHandler.post(() -> {
                    stopCurrentSpeechAndCleanup();
                    stopSelf();
                });
            }

            @Override
            public void onStop(String utteranceId, boolean interrupted) {
                mainHandler.post(() -> {
                    stopCurrentSpeechAndCleanup();
                });
            }
        });
    }

    private void executeSpeechRequest(PendingSpeechRequest req) {
        if (tts == null || req == null || req.text == null || req.text.trim().isEmpty()) {
            stopCurrentSpeechAndCleanup();
            stopSelf();
            return;
        }

        // Re-apply latest user speed/pitch/voice settings before speaking
        configureArabicMaleVoice();

        // Request Android AudioFocus (AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        if (!requestTransientAudioFocus()) {
            stopCurrentSpeechAndCleanup();
            stopSelf();
            return;
        }

        acquireShortWakeLock();

        String cleanSpokenText = prepareArabicTextForCalmTts(req.text);
        RifqAudioAthkarPrefs.setPlayingState(this, true, req.text, req.source);

        // Post notification with immediate "⏹ إيقاف الصوت" button
        postPlaybackNotification(req);

        RifqWidgetRenderer.updateAllPlacedWidgets(this);
        RifqNotificationsPlugin.notifyAudioAthkarStateChanged(this);

        RifqAudioAthkarPrefs.AudioAthkarConfig cfg = RifqAudioAthkarPrefs.loadConfig(this);
        Bundle params = new Bundle();
        params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, cfg.volume);
        params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC);

        String utteranceId = UTTERANCE_ID_PREFIX + System.currentTimeMillis();
        // QUEUE_FLUSH guarantees we never play two Athkar simultaneously
        tts.speak(cleanSpokenText, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
    }

    /**
     * Cleans decorative symbols (like ornamental brackets or ligatures that some TTS engines spell out)
     * while preserving full Arabic diacritics (Tashkeel) and replacing ﷺ with full spoken Salawat.
     */
    private String prepareArabicTextForCalmTts(String rawText) {
        if (rawText == null) return "";
        return rawText
            .replace("ﷺ", " صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ ")
            .replace("ﷻ", " جَلَّ جَلَالُهُ ")
            .replace("«", " ")
            .replace("»", " ")
            .replace("﴿", " ")
            .replace("﴾", " ")
            .replace("ۗ", " ، ")
            .replace("ۖ", " ، ")
            .replace("❂", " ")
            .replace("❖", " ")
            .replaceAll("\\s+", " ")
            .trim();
    }

    private void postPlaybackNotification(PendingSpeechRequest req) {
        try {
            RifqNotificationChannels.createAllChannels(this);
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            // Immediate Stop PendingIntent
            Intent stopIntent = new Intent(this, RifqAudioAthkarReceiver.class);
            stopIntent.setAction(ACTION_STOP_AUDIO_DHIKR);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }
            PendingIntent stopPendingIntent = PendingIntent.getBroadcast(this, 88410, stopIntent, flags);

            // Open App PendingIntent
            Intent openIntent = new Intent(this, MainActivity.class);
            openIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            openIntent.putExtra(RifqNotificationHelper.EXTRA_FROM_NOTIFICATION_TAP, true);
            openIntent.putExtra(RifqNotificationHelper.EXTRA_NOTIF_SCREEN, "moment_dhikr");
            PendingIntent openPendingIntent = PendingIntent.getActivity(this, 88411, openIntent, flags);

            // 1. If showTextNotification is requested (e.g. "text_and_audio" mode), post the persistent Dhikr card notification
            if (req.showTextNotification) {
                Intent replayIntent = new Intent(this, RifqAudioAthkarReceiver.class);
                replayIntent.setAction(RifqAudioAthkarReceiver.ACTION_SPEAK_SPECIFIC_DHIKR);
                replayIntent.putExtra(EXTRA_DHIKR_TEXT, req.text);
                replayIntent.putExtra(EXTRA_DHIKR_TITLE, req.title);
                replayIntent.putExtra(EXTRA_DHIKR_SOURCE, req.source);
                PendingIntent replayPi = PendingIntent.getBroadcast(this, 88412, replayIntent, flags);

                NotificationCompat.Builder textBuilder = new NotificationCompat.Builder(this, RifqNotificationChannels.CHANNEL_ADHKAR)
                    .setSmallIcon(R.drawable.ic_stat_rifq_notification)
                    .setColor(0xFF5B5FEF)
                    .setContentTitle("🔊 " + (req.title != null ? req.title : "ذكر مبارك من رِفْق"))
                    .setContentText(req.text)
                    .setSubText("رِفْق | " + (req.source != null ? req.source : "الأذكار الصوتية"))
                    .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(req.text + (req.source != null && !req.source.isEmpty() ? "\n\n📖 " + req.source : "")))
                    .setContentIntent(openPendingIntent)
                    .setAutoCancel(true)
                    .addAction(0, "⏹ إيقاف الصوت", stopPendingIntent)
                    .addAction(0, "🔊 إعادة الاستماع", replayPi);

                nm.notify(PERSISTENT_DHIKR_NOTIF_ID, textBuilder.build());
            }

            // 2. Always post a silent, ongoing playback control bar while audio is actively speaking
            // so the user has an immediate "⏹ إيقاف الصوت فوراً" button in the shade & lockscreen,
            // which automatically disappears the instant the Dhikr finishes!
            NotificationCompat.Builder controlBuilder = new NotificationCompat.Builder(this, RifqNotificationChannels.CHANNEL_ADHKAR)
                .setSmallIcon(R.drawable.ic_stat_rifq_notification)
                .setColor(0xFF5B5FEF)
                .setContentTitle("🔊 يُتلى الآن ذكر من رِفْق")
                .setContentText(req.text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(req.text))
                .setSilent(true)
                .setOngoing(false)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(openPendingIntent)
                .addAction(0, "⏹ إيقاف الصوت فوراً", stopPendingIntent);

            nm.notify(ACTIVE_AUDIO_CONTROL_NOTIF_ID, controlBuilder.build());
        } catch (Exception ignored) {
        }
    }

    private boolean requestTransientAudioFocus() {
        if (audioManager == null) return true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();
                audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .setWillPauseWhenDucked(false)
                    .setOnAudioFocusChangeListener(audioFocusChangeListener, mainHandler)
                    .build();
                int res = audioManager.requestAudioFocus(audioFocusRequest);
                return res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            } else {
                int res = audioManager.requestAudioFocus(
                    audioFocusChangeListener,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                );
                return res == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            }
        } catch (Exception ignored) {
            return true;
        }
    }

    private void abandonTransientAudioFocus() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
                audioManager.abandonAudioFocusRequest(audioFocusRequest);
                audioFocusRequest = null;
            } else {
                audioManager.abandonAudioFocus(audioFocusChangeListener);
            }
        } catch (Exception ignored) {
        }
    }

    private void acquireShortWakeLock() {
        try {
            releaseShortWakeLock();
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "rifq:audio_athkar_wakelock");
                wakeLock.setReferenceCounted(false);
                // Maximum 35 seconds safety timeout
                wakeLock.acquire(35_000L);
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseShortWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
            wakeLock = null;
        } catch (Exception ignored) {
        }
    }

    private void stopCurrentSpeechAndCleanup() {
        try {
            if (tts != null) {
                tts.stop();
            }
        } catch (Exception ignored) {
        }
        abandonTransientAudioFocus();
        releaseShortWakeLock();
        RifqAudioAthkarPrefs.setPlayingState(this, false, "", "");
        CancelNotificationHelper.cancelControlNotification(this);
        RifqWidgetRenderer.updateAllPlacedWidgets(this);
        RifqNotificationsPlugin.notifyAudioAthkarStateChanged(this);
    }

    @Override
    public void onDestroy() {
        stopCurrentSpeechAndCleanup();
        try {
            if (tts != null) {
                tts.shutdown();
                tts = null;
            }
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
