# Release Signing — رِفْق | RIFQ

لا يوجد Keystore داخل المشروع عمدًا. استخدم Keystore خاصًا بك واحفظه خارج Git.

Linux/macOS:
```bash
export RIFQ_KEYSTORE_PATH="/absolute/path/rifq-release-key.jks"
export RIFQ_KEYSTORE_PASSWORD="YOUR_KEYSTORE_PASSWORD"
export RIFQ_KEY_ALIAS="rifq_release_key"
export RIFQ_KEY_PASSWORD="YOUR_KEY_PASSWORD"
./build-release.sh
```

Windows PowerShell:
```powershell
$env:RIFQ_KEYSTORE_PATH="C:\path\rifq-release-key.jks"
$env:RIFQ_KEYSTORE_PASSWORD="YOUR_KEYSTORE_PASSWORD"
$env:RIFQ_KEY_ALIAS="rifq_release_key"
$env:RIFQ_KEY_PASSWORD="YOUR_KEY_PASSWORD"
.\build-release.ps1
```

النواتج:
`android/app/build/outputs/apk/release/app-release.apk`
`android/app/build/outputs/bundle/release/app-release.aab`
