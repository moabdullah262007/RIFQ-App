$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$required = @('RIFQ_KEYSTORE_PATH','RIFQ_KEYSTORE_PASSWORD','RIFQ_KEY_ALIAS','RIFQ_KEY_PASSWORD')
foreach ($name in $required) {
  $v = (Get-Item "Env:$name" -ErrorAction SilentlyContinue).Value
  if ([string]::IsNullOrWhiteSpace($v)) { throw "Missing $name" }
}
npm install
npm run build
npx cap sync android
Set-Location android
.\gradlew.bat clean assembleRelease bundleRelease
Write-Host "APK: $PSScriptRoot\android\app\build\outputs\apk\release\app-release.apk"
Write-Host "AAB: $PSScriptRoot\android\app\build\outputs\bundle\release\app-release.aab"
