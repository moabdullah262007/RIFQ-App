import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const SVG_PATH = path.resolve('public/app-icon.svg');
const RES_DIR = path.resolve('android/app/src/main/res');

const DENSITIES = [
  { name: 'mipmap-mdpi', iconSize: 48, fgSize: 108 },
  { name: 'mipmap-hdpi', iconSize: 72, fgSize: 162 },
  { name: 'mipmap-xhdpi', iconSize: 96, fgSize: 216 },
  { name: 'mipmap-xxhdpi', iconSize: 144, fgSize: 324 },
  { name: 'mipmap-xxxhdpi', iconSize: 192, fgSize: 432 },
];

async function generate() {
  console.log('Generating Android Launcher Icons from public/app-icon.svg...');
  const svgBuffer = fs.readFileSync(SVG_PATH);

  for (const d of DENSITIES) {
    const dir = path.join(RES_DIR, d.name);
    fs.mkdirSync(dir, { recursive: true });

    // 1. ic_launcher.png
    await sharp(svgBuffer)
      .resize(d.iconSize, d.iconSize)
      .png()
      .toFile(path.join(dir, 'ic_launcher.png'));

    // 2. ic_launcher_round.png
    const circleBuffer = Buffer.from(
      `<svg><circle cx="${d.iconSize / 2}" cy="${d.iconSize / 2}" r="${d.iconSize / 2}" fill="white"/></svg>`
    );
    await sharp(svgBuffer)
      .resize(d.iconSize, d.iconSize)
      .composite([{ input: circleBuffer, blend: 'dest-in' }])
      .png()
      .toFile(path.join(dir, 'ic_launcher_round.png'));

    // 3. ic_launcher_foreground.png (for adaptive icon)
    await sharp(svgBuffer)
      .resize(Math.round(d.fgSize * 0.72), Math.round(d.fgSize * 0.72))
      .extend({
        top: Math.round(d.fgSize * 0.14),
        bottom: Math.round(d.fgSize * 0.14),
        left: Math.round(d.fgSize * 0.14),
        right: Math.round(d.fgSize * 0.14),
        background: { r: 0, g: 0, b: 0, alpha: 0 },
      })
      .resize(d.fgSize, d.fgSize)
      .png()
      .toFile(path.join(dir, 'ic_launcher_foreground.png'));

    console.log(`Generated icons for ${d.name}`);
  }

  // 4. mipmap-anydpi-v26 for adaptive icons
  const anydpiDir = path.join(RES_DIR, 'mipmap-anydpi-v26');
  fs.mkdirSync(anydpiDir, { recursive: true });

  const adaptiveXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
</adaptive-icon>
`;

  fs.writeFileSync(path.join(anydpiDir, 'ic_launcher.xml'), adaptiveXml);
  fs.writeFileSync(path.join(anydpiDir, 'ic_launcher_round.xml'), adaptiveXml);

  // 5. ic_launcher_background color
  const valuesDir = path.join(RES_DIR, 'values');
  fs.mkdirSync(valuesDir, { recursive: true });
  const colorsXmlPath = path.join(valuesDir, 'ic_launcher_background.xml');
  const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#FFFDF9</color>
</resources>
`;
  fs.writeFileSync(colorsXmlPath, colorsXml);

  // 6. Play Store 512x512 icon
  const playstoreIconDir = path.resolve('android/app');
  await sharp(svgBuffer)
    .resize(512, 512)
    .png()
    .toFile(path.join(playstoreIconDir, 'playstore-icon.png'));

  console.log('Successfully generated all Android Launcher & Adaptive Icons!');
}

generate().catch((err) => {
  console.error('Error generating icons:', err);
  process.exit(1);
});
