# دليل بناء وتجهيز تطبيق رِفْق | RIFQ لنظام Android ومتجر Google Play

تطبيق **رِفْق | RIFQ** مبني كـ Production-Ready Native Android Application عبر Capacitor وAndroid Native Components مع دعم كامل لمواقيت الصلاة، الأذكار، حصاد الأعمال، والويدجت (App Widgets) على الشاشة الرئيسية.

---

## 1. المتطلبات الأساسية للبيئة (Prerequisites)

- **Node.js**: الإصدار 18 أو 20 أو 22 LTS
- **Java Development Kit (JDK)**: الإصدار JDK 17 أو JDK 21 (موصى بـ OpenJDK 17)
- **Android Studio**: أحدث إصدار (Ladybug / Koala أو أحدث) مع:
  - Android SDK Platform 35 (Android 15)
  - Android SDK Build-Tools 35.0.0
  - Android SDK Command-line Tools
- **بيئة المتغيرات**:
  ```bash
  export ANDROID_HOME=$HOME/Android/Sdk
  export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
  ```

---

## 2. خطوات التثبيت والبناء المبدئي (Web & Capacitor Sync)

1. **تثبيت الاعتماديات:**
   ```bash
   npm install
   ```

2. **بناء نسخة الويب الإنتاجية (Production Web Build):**
   ```bash
   npm run build
   ```

3. **مزامنة الأصول وPlugins مع مشروع Android:**
   ```bash
   npm run cap:sync
   # أو
   npx cap sync android
   ```

---

## 3. طريقة بناء APK للاختبار (Debug APK)

لبناء ملف APK تجريبي للتثبيت المباشر على الأجهزة عبر ADB أو المشاركة للاختبار:

```bash
npm run android:debug
```
أو من داخل مجلد `android`:
```bash
cd android
./gradlew assembleDebug
```

**📍 مكان ملف APK الناتج:**
```
android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 4. طريقة إنشاء Keystore للتوقيع الرقمي (Release Signing)

لإنشاء ملف Keystore رسمي خاص بك لتوقيع التطبيق لمتجر Google Play:

```bash
keytool -genkeypair -v \
  -keystore rifq-release-key.jks \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias rifq_release_key
```

سيطلب منك إدخال كلمة مرور ومعلومات جهة الإصدار، ثم سينتج ملف `rifq-release-key.jks`.

---

## 5. طريقة ربط بيانات التوقيع (Signing) بأمان تام

لحماية بيانات الاعتماد من التسريب وعدم رفع كلمات المرور داخل Git أو الكود، يعتمد المشروع على المتغيرات البيئية:

في نظام Linux / macOS:
```bash
export RIFQ_KEYSTORE_PATH="/path/to/rifq-release-key.jks"
export RIFQ_KEYSTORE_PASSWORD="كلمة_مرور_المخزن"
export RIFQ_KEY_ALIAS="rifq_release_key"
export RIFQ_KEY_PASSWORD="كلمة_مرور_المفتاح"
```

في نظام Windows (PowerShell):
```powershell
$env:RIFQ_KEYSTORE_PATH="C:\path\to\rifq-release-key.jks"
$env:RIFQ_KEYSTORE_PASSWORD="كلمة_مرور_المخزن"
$env:RIFQ_KEY_ALIAS="rifq_release_key"
$env:RIFQ_KEY_PASSWORD="كلمة_مرور_المفتاح"
```

*(في حال عدم توفر متغيرات التوقيع أثناء البناء المحلي التجريبي، سيقوم Gradle تلقائيًا بالبناء بدون أن يتوقف الخطأ).*

---

## 6. طريقة بناء APK Release

```bash
npm run android:release
```
أو:
```bash
cd android
./gradlew assembleRelease
```

**📍 مكان ملف APK Release الناتج:**
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## 7. طريقة بناء حزمة النشر لمتجر Google Play (Android App Bundle - AAB)

ملف **AAB** هو التنسيق الإلزامي المعتمد من Google Play للنشر الرسمي، حيث يقوم المتجر بتوليد نسخ APK مخصصة لكل جهاز لتقليل الحجم.

لبناء ملف AAB:
```bash
npm run android:bundle
# أو
npm run android:aab
```
أو من داخل مجلد `android`:
```bash
cd android
./gradlew bundleRelease
```

**📍 مكان ملف AAB الناتج:**
```
android/app/build/outputs/bundle/release/app-release.aab
```

---

## 8. خطوات رفع AAB إلى Google Play Console

1. سجل الدخول إلى [Google Play Console](https://play.google.com/console).
2. اختر تطبيق **رِفْق | RIFQ** (أو اضغط **Create App** باسم التطبيق: `رِفْق | RIFQ` والمعرف `com.rifq.app`).
3. من القائمة الجانبية، توجّه إلى **Production** (أو **Internal testing** للاختبار الداخلي).
4. اضغط على **Create new release**.
5. ارفع ملف `app-release.aab` الموجود في:
   `android/app/build/outputs/bundle/release/app-release.aab`
6. أدخل تفاصيل الإصدار (Release name: `1.0.0` - Release notes باللغة العربية والإنجليزية).
7. اضغط **Next** ثم **Save** ثم **Review release** ثم **Start rollout to Production**.

---

## 9. معلومات الهوية والإصدار المعتمدة (App Specs)

- **Package Name (Application ID):** `com.rifq.app`
- **Application Label:** `رِفْق | RIFQ`
- **versionName:** `1.0.0`
- **versionCode:** `1`
- **minSdkVersion:** `24` (Android 7.0+)
- **compileSdkVersion:** `35` (Android 15)
- **targetSdkVersion:** `35` (متوافق مع أحدث معايير متطلبات Google Play)
- **R8 / ProGuard:** مفعّل مع القواعد الموثقة في `proguard-rules.pro`.
