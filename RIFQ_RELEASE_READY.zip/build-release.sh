#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
for v in RIFQ_KEYSTORE_PATH RIFQ_KEYSTORE_PASSWORD RIFQ_KEY_ALIAS RIFQ_KEY_PASSWORD; do
  if [[ -z "${!v:-}" ]]; then echo "ERROR: $v is missing"; exit 2; fi
done
npm install
npm run build
npx cap sync android
cd android
./gradlew clean assembleRelease bundleRelease
echo "APK: $ROOT/android/app/build/outputs/apk/release/app-release.apk"
echo "AAB: $ROOT/android/app/build/outputs/bundle/release/app-release.aab"
