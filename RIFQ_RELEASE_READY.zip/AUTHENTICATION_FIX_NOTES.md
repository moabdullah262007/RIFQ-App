# RIFQ Authentication Fix

## Code fix applied
- Android Google Sign-In now resolves the custom Capacitor `RifqGoogleAuth` plugin through `registerPlugin()` instead of the legacy `window.Capacitor.Plugins` lookup.
- This prevents Android from silently falling back to the WebView Google popup when the native plugin is actually registered in `MainActivity`.
- Email/password Firebase Auth and password-reset code were preserved as real Firebase Auth calls.

## Important external Firebase setup
The ZIP does not contain `android/app/google-services.json`, and Firebase Console configuration is not part of the project files. For Google Sign-In on Android, the Firebase/Google Cloud project must have:
- Google sign-in provider enabled.
- An Android OAuth client for package `com.rifq.app` with the SHA-1/SHA-256 fingerprints of the APK signing certificate.
- The existing Web OAuth client ID used for `requestIdToken`.
- Email/Password provider enabled for email login and password reset.

I could not perform a real Gradle build in this environment because the Gradle wrapper distribution is not cached and external network access is unavailable.
