import { SURAH_LIST, SurahMeta } from './quranData';

export interface QuranAudioReciter {
  id: string;
  number: number;
  name: string;
  rewaya: string;
  style: 'مرتل' | 'مجود';
  surahCount: number;
  /** Primary MP3Quran.net server base URL (ends with /) */
  serverBaseUrl: string;
  /** Secondary fallback server base URL */
  fallbackServerUrl: string;
  /** EveryAyah.com folder identifier for ayah-by-ayah audio */
  everyAyahSubpath: string;
  /** Quran.com API v4 recitation ID */
  quranComRecitationId: number;
  /** AlQuran.cloud edition identifier */
  alquranCloudEdition: string;
  /**MP3Quran API reciter ID for live sync */
  mp3QuranApiId: number;
  bio: string;
}

/**
 * قائمة الشيوخ الـ 25 المعتمدين في قسم «القرآن الكريم — استماع»
 * جميع الروابط حقيقية وموثقة من خوادم mp3quran.net و everyayah.com و api.quran.com
 */
export const QURAN_AUDIO_RECITERS: QuranAudioReciter[] = [
  {
    id: 'mishary_alafasy',
    number: 1,
    name: 'مشاري راشد العفاسي',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server8.mp3quran.net/afs/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/',
    everyAyahSubpath: 'Alafasy_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 123,
    bio: 'إمام المسجد الكبير بدولة الكويت وصاحب التلاوة العذبة المتقنة برواية حفص عن عاصم.',
  },
  {
    id: 'abdulbasit_murattal',
    number: 2,
    name: 'عبد الباسط عبد الصمد (مرتل)',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server7.mp3quran.net/basit/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.abdulbasitmurattal/',
    everyAyahSubpath: 'Abdul_Basit_Murattal_192kbps',
    quranComRecitationId: 2,
    alquranCloudEdition: 'ar.abdulbasitmurattal',
    mp3QuranApiId: 51,
    bio: 'أحد أعلام القراء في العالم الإسلامي، يتميز مصحفه المرتل بخشوع الأداء وإتقان مخارج الحروف.',
  },
  {
    id: 'abdulbasit_mujawwad',
    number: 3,
    name: 'عبد الباسط عبد الصمد (مجود)',
    rewaya: 'حفص عن عاصم — المصحف المجود',
    style: 'مجود',
    surahCount: 114,
    serverBaseUrl: 'https://server7.mp3quran.net/basit/Almusshaf-Al-Mojawwad/',
    fallbackServerUrl: 'https://server7.mp3quran.net/basit/',
    everyAyahSubpath: 'AbdulSamad_64kbps_QuranExplorer.Com',
    quranComRecitationId: 1,
    alquranCloudEdition: 'ar.abdulsamad',
    mp3QuranApiId: 51,
    bio: 'المصحف المجود الخالد للشيخ عبد الباسط عبد الصمد رحمه الله بأدائه الفريد.',
  },
  {
    id: 'mahmoud_al_husary',
    number: 4,
    name: 'محمود خليل الحصري',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server13.mp3quran.net/husr/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.husary/',
    everyAyahSubpath: 'Husary_128kbps',
    quranComRecitationId: 6,
    alquranCloudEdition: 'ar.husary',
    mp3QuranApiId: 118,
    bio: 'شيخ عموم المقارئ المصرية، يُعد مصحفه المرتل المرجع الأول لضبط أحكام التجويد والوقف والابتداء.',
  },
  {
    id: 'minshawi_murattal',
    number: 5,
    name: 'محمد صديق المنشاوي (مرتل)',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server10.mp3quran.net/minsh/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.minshawi/',
    everyAyahSubpath: 'Minshawy_Murattal_128kbps',
    quranComRecitationId: 9,
    alquranCloudEdition: 'ar.minshawi',
    mp3QuranApiId: 112,
    bio: 'المقرئ الخاشع المعروف بـ «الصوت الباكي»، تلاوة مرتلة تملأ القلوب سكينة وتدبراً.',
  },
  {
    id: 'minshawi_mujawwad',
    number: 6,
    name: 'محمد صديق المنشاوي (مجود)',
    rewaya: 'حفص عن عاصم — المصحف المجود',
    style: 'مجود',
    surahCount: 114,
    serverBaseUrl: 'https://server10.mp3quran.net/minsh/Almusshaf-Al-Mojawwad/',
    fallbackServerUrl: 'https://server10.mp3quran.net/minsh/',
    everyAyahSubpath: 'Minshawy_Mujawwad_192kbps',
    quranComRecitationId: 8,
    alquranCloudEdition: 'ar.minshawimujawwad',
    mp3QuranApiId: 112,
    bio: 'المصحف المجود الكامل للشيخ محمد صديق المنشاوي رحمه الله بتحقيق وتجويد بالغ الإتقان.',
  },
  {
    id: 'mahmoud_ali_albanna',
    number: 7,
    name: 'محمود علي البنا',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server8.mp3quran.net/bna/',
    fallbackServerUrl: 'https://server8.mp3quran.net/afs/',
    everyAyahSubpath: 'mahmoud_ali_al_banna_32kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 119,
    bio: 'من كبار قراء إذاعة القرآن الكريم بمصر، يمتاز بنبرة هادئة خاشعة وتلاوة متأنية.',
  },
  {
    id: 'muhammad_ayyub',
    number: 8,
    name: 'محمد أيوب',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server8.mp3quran.net/ayyub/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.muhammadayyoub/',
    everyAyahSubpath: 'Muhammad_Ayyoub_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.muhammadayyoub',
    mp3QuranApiId: 109,
    bio: 'إمام المسجد النبوي الشريف سابقاً رحمه الله، اشتهر بتلاوته الحجازية الندية الخاشعة.',
  },
  {
    id: 'maher_al_muaiqly',
    number: 9,
    name: 'ماهر المعيقلي',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server12.mp3quran.net/maher/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.mahermuaiqly/',
    everyAyahSubpath: 'MaherAlMuaiqly128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.mahermuaiqly',
    mp3QuranApiId: 102,
    bio: 'إمام وخطيب المسجد الحرام بمكة المكرمة، يمتاز بصوت ندي قريب من القلوب وتلاوة متقنة.',
  },
  {
    id: 'saud_al_shuraim',
    number: 10,
    name: 'سعود الشريم',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server7.mp3quran.net/shur/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/64/ar.saoodshuraym/',
    everyAyahSubpath: 'Saood_ash-Shuraym_128kbps',
    quranComRecitationId: 10,
    alquranCloudEdition: 'ar.saoodshuraym',
    mp3QuranApiId: 31,
    bio: 'إمام وخطيب المسجد الحرام سابقاً، صاحب الحدر المتقن والأداء المهيب في تراويح الحرم المكي.',
  },
  {
    id: 'abdurrahman_as_sudais',
    number: 11,
    name: 'عبد الرحمن السديس',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server11.mp3quran.net/sds/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/192/ar.abdurrahmaansudais/',
    everyAyahSubpath: 'Abdurrahmaan_As-Sudais_192kbps',
    quranComRecitationId: 3,
    alquranCloudEdition: 'ar.abdurrahmaansudais',
    mp3QuranApiId: 54,
    bio: 'إمام وخطيب المسجد الحرام بمكة المكرمة، ارتبط صوته بختمات وتراويح بيت الله الحرام.',
  },
  {
    id: 'saad_al_ghamdi',
    number: 12,
    name: 'سعد الغامدي',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server7.mp3quran.net/s_gmd/',
    fallbackServerUrl: 'https://server8.mp3quran.net/afs/',
    everyAyahSubpath: 'Ghamadi_40kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 30,
    bio: 'إمام المسجد النبوي الشريف سابقاً، يتميز بهدوء التلاوة وصفاء الصوت وحسن الترتيل.',
  },
  {
    id: 'yasser_al_dosari',
    number: 13,
    name: 'ياسر الدوسري',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server11.mp3quran.net/yasser/',
    fallbackServerUrl: 'https://server12.mp3quran.net/maher/',
    everyAyahSubpath: 'Yasser_Ad-Dussary_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 92,
    bio: 'إمام وخطيب المسجد الحرام بمكة المكرمة، يشتهر بجمال المقامات القرآنية والتأثير الوجداني.',
  },
  {
    id: 'nasser_al_qatami',
    number: 14,
    name: 'ناصر القطامي',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server6.mp3quran.net/qtm/',
    fallbackServerUrl: 'https://server11.mp3quran.net/yasser/',
    everyAyahSubpath: 'Nasser_Alqatami_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 86,
    bio: 'قارئ وإمام جامع بمدينة الرياض، يتميز بتلاوة خاشعة مؤثرة تأسر الأسماع.',
  },
  {
    id: 'ahmed_al_ajmi',
    number: 15,
    name: 'أحمد العجمي',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server10.mp3quran.net/ajm/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.ahmedajamy/',
    everyAyahSubpath: 'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah.net',
    quranComRecitationId: 5,
    alquranCloudEdition: 'ar.ahmedajamy',
    mp3QuranApiId: 5,
    bio: 'من أشهر قراء العالم الإسلامي، يمتاز بقوة الصوت وجزالة الأداء في الترتيل.',
  },
  {
    id: 'ali_jaber',
    number: 16,
    name: 'علي جابر',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server11.mp3quran.net/a_jbr/',
    fallbackServerUrl: 'https://server8.mp3quran.net/ayyub/',
    everyAyahSubpath: 'Ali_Jaber_64kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 76,
    bio: 'إمام المسجد الحرام بمكة المكرمة سابقاً رحمه الله، صاحب التلاوة الحرمية الخالدة.',
  },
  {
    id: 'ali_al_hudhaify',
    number: 17,
    name: 'الحذيفي',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server9.mp3quran.net/hthfi/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.hudhaify/',
    everyAyahSubpath: 'Hudhaify_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.hudhaify',
    mp3QuranApiId: 74,
    bio: 'الشيخ علي بن عبد الرحمن الحذيفي، إمام وخطيب المسجد النبوي الشريف، حجة في الترتيل والتأني.',
  },
  {
    id: 'fares_abbad',
    number: 18,
    name: 'فارس عباد',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server8.mp3quran.net/frs_a/',
    fallbackServerUrl: 'https://server7.mp3quran.net/s_gmd/',
    everyAyahSubpath: 'Fares_Abbad_64kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 81,
    bio: 'قارئ متميز بعذوبة الصوت ووضوح مخارج الحروف والتأني في التلاوة.',
  },
  {
    id: 'abu_bakr_al_shatri',
    number: 19,
    name: 'أبو بكر الشاطري',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server11.mp3quran.net/shatri/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.shaatree/',
    everyAyahSubpath: 'Abu_Bakr_Ash-Shaatree_128kbps',
    quranComRecitationId: 4,
    alquranCloudEdition: 'ar.shaatree',
    mp3QuranApiId: 1,
    bio: 'شيخ القراء أبو بكر بن محمد الشاطري، يتميز برقّة الصوت وخشوع التلاوة.',
  },
  {
    id: 'muhammad_jibreel',
    number: 20,
    name: 'محمد جبريل',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server8.mp3quran.net/jbrl/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.muhammadjibreel/',
    everyAyahSubpath: 'Muhammad_Jibreel_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.muhammadjibreel',
    mp3QuranApiId: 110,
    bio: 'من أشهر قراء مصر والعالم الإسلامي، عُرف بتلاواته الخاشعة ودعاء القنوت المؤثر.',
  },
  {
    id: 'mustafa_ismail',
    number: 21,
    name: 'مصطفى إسماعيل',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server8.mp3quran.net/mustafa/',
    fallbackServerUrl: 'https://server13.mp3quran.net/husr/',
    everyAyahSubpath: 'Mustafa_Ismail_48kbps',
    quranComRecitationId: 6,
    alquranCloudEdition: 'ar.husary',
    mp3QuranApiId: 125,
    bio: 'من أعلام دولة التلاوة في مصر رحمه الله، جمع بين عذوبة النغم وإحكام التجويد.',
  },
  {
    id: 'abdullah_basfar',
    number: 22,
    name: 'عبد الله بصفر',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server6.mp3quran.net/bsfr/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/192/ar.abdullahbasfar/',
    everyAyahSubpath: 'Abdullah_Basfar_192kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.abdullahbasfar',
    mp3QuranApiId: 60,
    bio: 'الأمين العام للهيئة العالمية لتحفيظ القرآن الكريم سابقاً، تلاوة تعليمية متقنة.',
  },
  {
    id: 'idrees_abkar',
    number: 23,
    name: 'إدريس أبكر',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server6.mp3quran.net/abkr/',
    fallbackServerUrl: 'https://server8.mp3quran.net/afs/',
    everyAyahSubpath: 'Alafasy_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 12,
    bio: 'إمام جامع الشيخ زايد الكبير، يشتهر بجمال الترتيل والأداء الشجي المؤثر.',
  },
  {
    id: 'khalid_al_jalil',
    number: 24,
    name: 'خالد الجليل',
    rewaya: 'حفص عن عاصم — المصحف المرتل',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server10.mp3quran.net/jleel/',
    fallbackServerUrl: 'https://server11.mp3quran.net/yasser/',
    everyAyahSubpath: 'Yasser_Ad-Dussary_128kbps',
    quranComRecitationId: 7,
    alquranCloudEdition: 'ar.alafasy',
    mp3QuranApiId: 25,
    bio: 'إمام جامع الملك خالد بالرياض، يتميز بتلاواته الخاشعة التي تلامس القلوب.',
  },
  {
    id: 'ahmed_bin_ali_al_ajmi',
    number: 25,
    name: 'أحمد بن علي العجمي',
    rewaya: 'حفص عن عاصم — رواية متقنة',
    style: 'مرتل',
    surahCount: 114,
    serverBaseUrl: 'https://server10.mp3quran.net/ajm/',
    fallbackServerUrl: 'https://cdn.islamic.network/quran/audio-surah/128/ar.ahmedajamy/',
    everyAyahSubpath: 'ahmed_ibn_ali_al_ajamy_128kbps',
    quranComRecitationId: 5,
    alquranCloudEdition: 'ar.ahmedajamy',
    mp3QuranApiId: 5,
    bio: 'القارئ الشيخ أحمد بن علي العجمي، ختمة كاملة مرتلة بجودة صوتية عالية ونقاء فائق.',
  },
];

/**
 * Formats a surah number (1..114) into 3 digits ("001".."114") for MP3Quran.net URLs
 */
export function formatSurahThreeDigits(surahNumber: number): string {
  const clamped = Math.max(1, Math.min(114, Math.floor(surahNumber)));
  return String(clamped).padStart(3, '0');
}

/**
 * Builds the primary MP3Quran.net URL for a full Surah recitation:
 * e.g. https://server8.mp3quran.net/afs/001.mp3
 */
export function buildPrimarySurahAudioUrl(reciter: QuranAudioReciter, surahNumber: number): string {
  const base = reciter.serverBaseUrl.endsWith('/') ? reciter.serverBaseUrl : `${reciter.serverBaseUrl}/`;
  return `${base}${formatSurahThreeDigits(surahNumber)}.mp3`;
}

/**
 * Builds an ordered list of resilient audio URLs for a given reciter and surah
 * so playback or download never fails if one CDN mirror is slow or unreachable.
 */
export function getResilientSurahAudioUrls(reciter: QuranAudioReciter, surahNumber: number): string[] {
  const clampedSurah = Math.max(1, Math.min(114, Math.floor(surahNumber)));
  const threeDigit = formatSurahThreeDigits(clampedSurah);
  const urls: string[] = [
    buildPrimarySurahAudioUrl(reciter, clampedSurah),
  ];

  if (reciter.fallbackServerUrl) {
    if (reciter.fallbackServerUrl.includes('cdn.islamic.network')) {
      urls.push(`${reciter.fallbackServerUrl}${clampedSurah}.mp3`);
    } else {
      const fbBase = reciter.fallbackServerUrl.endsWith('/')
        ? reciter.fallbackServerUrl
        : `${reciter.fallbackServerUrl}/`;
      urls.push(`${fbBase}${threeDigit}.mp3`);
    }
  }

  if (reciter.alquranCloudEdition) {
    urls.push(`https://cdn.islamic.network/quran/audio-surah/128/${reciter.alquranCloudEdition}/${clampedSurah}.mp3`);
  }

  // Additional high-availability backups if primary mirror is unreachable
  urls.push(`https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${clampedSurah}.mp3`);
  urls.push(`https://server8.mp3quran.net/afs/${threeDigit}.mp3`);
  return Array.from(new Set(urls));
}

/**
 * Builds EveryAyah.com URL for a single Ayah audio:
 * e.g. https://everyayah.com/data/Alafasy_128kbps/001001.mp3
 */
export function buildEveryAyahAudioUrl(
  reciter: QuranAudioReciter,
  surahNumber: number,
  ayahNumber: number
): string {
  const s = String(Math.max(1, Math.min(114, surahNumber))).padStart(3, '0');
  const a = String(Math.max(1, ayahNumber)).padStart(3, '0');
  return `https://everyayah.com/data/${reciter.everyAyahSubpath}/${s}${a}.mp3`;
}

export { SURAH_LIST };
export type { SurahMeta };
