// Data structure for Holy Quran (114 Surahs)
export interface SurahMeta {
  number: number;
  name: string;
  englishName: string;
  revelationType: 'Meccan' | 'Medinan';
  numberOfAyahs: number;
  juz: number;
  page: number;
}

export interface AyahItem {
  numberInSurah: number;
  globalNumber: number;
  text: string;
  translationEn?: string;
  translationFr?: string;
  translationUr?: string;
  tafseer?: string;
  juz: number;
  page?: number;
}

export interface SurahDetail extends SurahMeta {
  bismillahPre: boolean;
  ayahs: AyahItem[];
}

export interface BookmarkItem {
  id: string;
  surahNumber: number;
  surahName: string;
  ayahNumber: number;
  ayahText: string;
  timestamp: number;
  note?: string;
}

export interface KhatmahTracker {
  startDate: string;
  targetDays: number;
  currentJuz: number;
  currentSurahNumber: number;
  completedAyahsCount: number;
  readSurahs: number[]; // surah numbers
  notes: string;
}

export interface ReciterOption {
  id: string;
  name: string;
  identifier: string; // alquran.cloud edition identifier
  subpath: string; // EveryAyah subpath
}

export const QURAN_RECITERS: ReciterOption[] = [
  {
    id: 'alafasy',
    name: 'الشيخ مشاري راشد العفاسي',
    identifier: 'ar.alafasy',
    subpath: 'Alafasy_128kbps',
  },
  {
    id: 'abdulbasit',
    name: 'الشيخ عبد الباسط عبد الصمد (مرتل)',
    identifier: 'ar.abdulbasitmurattal',
    subpath: 'Abdul_Basit_Murattal_192kbps',
  },
  {
    id: 'husary',
    name: 'الشيخ محمود خليل الحصري',
    identifier: 'ar.husary',
    subpath: 'Husary_128kbps',
  },
  {
    id: 'minshawi',
    name: 'الشيخ محمد صديق المنشاوي (مرتل)',
    identifier: 'ar.minshawi',
    subpath: 'Minshawy_Murattal_128kbps',
  },
  {
    id: 'ghamadi',
    name: 'الشيخ سعد الغامدي',
    identifier: 'ar.saadalghamidi',
    subpath: 'Ghamadi_40kbps',
  },
  {
    id: 'maher',
    name: 'الشيخ ماهر المعيقلي',
    identifier: 'ar.mahermuaiqly',
    subpath: 'MaherAlMuaiqly128kbps',
  },
];

export const SURAH_LIST: SurahMeta[] = [
  { number: 1, name: 'الفَاتِحَة', englishName: 'Al-Faatiha', revelationType: 'Meccan', numberOfAyahs: 7, juz: 1, page: 1 },
  { number: 2, name: 'البَقَرَة', englishName: 'Al-Baqara', revelationType: 'Medinan', numberOfAyahs: 286, juz: 1, page: 2 },
  { number: 3, name: 'آل عِمْرَان', englishName: 'Aal-i-Imraan', revelationType: 'Medinan', numberOfAyahs: 200, juz: 3, page: 50 },
  { number: 4, name: 'النِّسَاء', englishName: 'An-Nisaa', revelationType: 'Medinan', numberOfAyahs: 176, juz: 4, page: 77 },
  { number: 5, name: 'المَائِدَة', englishName: 'Al-Maaida', revelationType: 'Medinan', numberOfAyahs: 120, juz: 6, page: 106 },
  { number: 6, name: 'الأَنْعَام', englishName: 'Al-An\'aam', revelationType: 'Meccan', numberOfAyahs: 165, juz: 7, page: 128 },
  { number: 7, name: 'الأَعْرَاف', englishName: 'Al-A\'raaf', revelationType: 'Meccan', numberOfAyahs: 206, juz: 8, page: 151 },
  { number: 8, name: 'الأَنْفَال', englishName: 'Al-Anfaal', revelationType: 'Medinan', numberOfAyahs: 75, juz: 9, page: 177 },
  { number: 9, name: 'التَّوْبَة', englishName: 'At-Tawba', revelationType: 'Medinan', numberOfAyahs: 129, juz: 10, page: 187 },
  { number: 10, name: 'يُونُس', englishName: 'Yunus', revelationType: 'Meccan', numberOfAyahs: 109, juz: 11, page: 208 },
  { number: 11, name: 'هُود', englishName: 'Hud', revelationType: 'Meccan', numberOfAyahs: 123, juz: 11, page: 221 },
  { number: 12, name: 'يُوسُف', englishName: 'Yusuf', revelationType: 'Meccan', numberOfAyahs: 111, juz: 12, page: 235 },
  { number: 13, name: 'الرَّعْد', englishName: 'Ar-Ra\'d', revelationType: 'Medinan', numberOfAyahs: 43, juz: 13, page: 249 },
  { number: 14, name: 'إِبْرَاهِيم', englishName: 'Ibrahim', revelationType: 'Meccan', numberOfAyahs: 52, juz: 13, page: 255 },
  { number: 15, name: 'الحِجْر', englishName: 'Al-Hijr', revelationType: 'Meccan', numberOfAyahs: 99, juz: 14, page: 262 },
  { number: 16, name: 'النَّحْل', englishName: 'An-Nahl', revelationType: 'Meccan', numberOfAyahs: 128, juz: 14, page: 267 },
  { number: 17, name: 'الإِسْرَاء', englishName: 'Al-Israa', revelationType: 'Meccan', numberOfAyahs: 111, juz: 15, page: 282 },
  { number: 18, name: 'الكَهْف', englishName: 'Al-Kahf', revelationType: 'Meccan', numberOfAyahs: 110, juz: 15, page: 293 },
  { number: 19, name: 'مَرْيَم', englishName: 'Maryam', revelationType: 'Meccan', numberOfAyahs: 98, juz: 16, page: 305 },
  { number: 20, name: 'طه', englishName: 'Taa-Haa', revelationType: 'Meccan', numberOfAyahs: 135, juz: 16, page: 312 },
  { number: 21, name: 'الأَنْبِيَاء', englishName: 'Al-Anbiyaa', revelationType: 'Meccan', numberOfAyahs: 112, juz: 17, page: 322 },
  { number: 22, name: 'الحَجّ', englishName: 'Al-Hajj', revelationType: 'Medinan', numberOfAyahs: 78, juz: 17, page: 332 },
  { number: 23, name: 'المُؤْمِنُون', englishName: 'Al-Muminoon', revelationType: 'Meccan', numberOfAyahs: 118, juz: 18, page: 342 },
  { number: 24, name: 'النُّور', englishName: 'An-Noor', revelationType: 'Medinan', numberOfAyahs: 64, juz: 18, page: 350 },
  { number: 25, name: 'الفُرْقَان', englishName: 'Al-Furqaan', revelationType: 'Meccan', numberOfAyahs: 77, juz: 18, page: 359 },
  { number: 26, name: 'الشُّعَرَاء', englishName: 'Ash-Shu\'araa', revelationType: 'Meccan', numberOfAyahs: 227, juz: 19, page: 367 },
  { number: 27, name: 'النَّمْل', englishName: 'An-Naml', revelationType: 'Meccan', numberOfAyahs: 93, juz: 19, page: 377 },
  { number: 28, name: 'القَصَص', englishName: 'Al-Qasas', revelationType: 'Meccan', numberOfAyahs: 88, juz: 20, page: 385 },
  { number: 29, name: 'العَنْكَبُوت', englishName: 'Al-Ankaboot', revelationType: 'Meccan', numberOfAyahs: 69, juz: 20, page: 396 },
  { number: 30, name: 'الرُّوم', englishName: 'Ar-Room', revelationType: 'Meccan', numberOfAyahs: 60, juz: 21, page: 404 },
  { number: 31, name: 'لُقْمَان', englishName: 'Luqman', revelationType: 'Meccan', numberOfAyahs: 34, juz: 21, page: 411 },
  { number: 32, name: 'السَّجْدَة', englishName: 'As-Sajda', revelationType: 'Meccan', numberOfAyahs: 30, juz: 21, page: 415 },
  { number: 33, name: 'الأَحْزَاب', englishName: 'Al-Ahzaab', revelationType: 'Medinan', numberOfAyahs: 73, juz: 21, page: 418 },
  { number: 34, name: 'سَبَأ', englishName: 'Saba', revelationType: 'Meccan', numberOfAyahs: 54, juz: 22, page: 428 },
  { number: 35, name: 'فَاطِر', englishName: 'Faatir', revelationType: 'Meccan', numberOfAyahs: 45, juz: 22, page: 434 },
  { number: 36, name: 'يس', englishName: 'Yaseen', revelationType: 'Meccan', numberOfAyahs: 83, juz: 22, page: 440 },
  { number: 37, name: 'الصَّافَّات', englishName: 'As-Saaffaat', revelationType: 'Meccan', numberOfAyahs: 182, juz: 23, page: 446 },
  { number: 38, name: 'ص', englishName: 'Saad', revelationType: 'Meccan', numberOfAyahs: 88, juz: 23, page: 453 },
  { number: 39, name: 'الزُّمَر', englishName: 'Az-Zumar', revelationType: 'Meccan', numberOfAyahs: 75, juz: 23, page: 458 },
  { number: 40, name: 'غَافِر', englishName: 'Ghafir', revelationType: 'Meccan', numberOfAyahs: 85, juz: 24, page: 467 },
  { number: 41, name: 'فُصِّلَت', englishName: 'Fussilat', revelationType: 'Meccan', numberOfAyahs: 54, juz: 24, page: 477 },
  { number: 42, name: 'الشُّورَى', englishName: 'Ash-Shura', revelationType: 'Meccan', numberOfAyahs: 53, juz: 25, page: 483 },
  { number: 43, name: 'الزُّخْرُف', englishName: 'Az-Zukhruf', revelationType: 'Meccan', numberOfAyahs: 89, juz: 25, page: 489 },
  { number: 44, name: 'الدُّخَان', englishName: 'Ad-Dukhaan', revelationType: 'Meccan', numberOfAyahs: 59, juz: 25, page: 496 },
  { number: 45, name: 'الجَاثِيَة', englishName: 'Al-Jaathiya', revelationType: 'Meccan', numberOfAyahs: 37, juz: 25, page: 499 },
  { number: 46, name: 'الأَحْقَاف', englishName: 'Al-Ahqaaf', revelationType: 'Meccan', numberOfAyahs: 35, juz: 26, page: 502 },
  { number: 47, name: 'مُحَمَّد', englishName: 'Muhammad', revelationType: 'Medinan', numberOfAyahs: 38, juz: 26, page: 507 },
  { number: 48, name: 'الفَتْح', englishName: 'Al-Fath', revelationType: 'Medinan', numberOfAyahs: 29, juz: 26, page: 511 },
  { number: 49, name: 'الحُجُرَات', englishName: 'Al-Hujuraat', revelationType: 'Medinan', numberOfAyahs: 18, juz: 26, page: 515 },
  { number: 50, name: 'ق', englishName: 'Qaaf', revelationType: 'Meccan', numberOfAyahs: 45, juz: 26, page: 518 },
  { number: 51, name: 'الذَّارِيَات', englishName: 'Adh-Dhaariyat', revelationType: 'Meccan', numberOfAyahs: 60, juz: 26, page: 520 },
  { number: 52, name: 'الطُّور', englishName: 'At-Toor', revelationType: 'Meccan', numberOfAyahs: 49, juz: 27, page: 523 },
  { number: 53, name: 'النَّجْم', englishName: 'An-Najm', revelationType: 'Meccan', numberOfAyahs: 62, juz: 27, page: 526 },
  { number: 54, name: 'القَمَر', englishName: 'Al-Qamar', revelationType: 'Meccan', numberOfAyahs: 55, juz: 27, page: 528 },
  { number: 55, name: 'الرَّحْمَن', englishName: 'Ar-Rahmaan', revelationType: 'Medinan', numberOfAyahs: 78, juz: 27, page: 531 },
  { number: 56, name: 'الوَاقِعَة', englishName: 'Al-Waaqia', revelationType: 'Meccan', numberOfAyahs: 96, juz: 27, page: 534 },
  { number: 57, name: 'الحَدِيد', englishName: 'Al-Hadid', revelationType: 'Medinan', numberOfAyahs: 29, juz: 27, page: 537 },
  { number: 58, name: 'المُجَادِلَة', englishName: 'Al-Mujaadila', revelationType: 'Medinan', numberOfAyahs: 22, juz: 28, page: 542 },
  { number: 59, name: 'الحَشْر', englishName: 'Al-Hashr', revelationType: 'Medinan', numberOfAyahs: 24, juz: 28, page: 545 },
  { number: 60, name: 'المُمْتَحَنَة', englishName: 'Al-Mumtahana', revelationType: 'Medinan', numberOfAyahs: 13, juz: 28, page: 549 },
  { number: 61, name: 'الصَّفّ', englishName: 'As-Saff', revelationType: 'Medinan', numberOfAyahs: 14, juz: 28, page: 551 },
  { number: 62, name: 'الجُمُعَة', englishName: 'Al-Jumu\'a', revelationType: 'Medinan', numberOfAyahs: 11, juz: 28, page: 553 },
  { number: 63, name: 'المُنَافِقُون', englishName: 'Al-Munaafiqoon', revelationType: 'Medinan', numberOfAyahs: 11, juz: 28, page: 554 },
  { number: 64, name: 'التَّغَابُن', englishName: 'At-Taghaabun', revelationType: 'Medinan', numberOfAyahs: 18, juz: 28, page: 556 },
  { number: 65, name: 'الطَّلَاق', englishName: 'At-Talaaq', revelationType: 'Medinan', numberOfAyahs: 12, juz: 28, page: 558 },
  { number: 66, name: 'التَّحْرِيم', englishName: 'At-Tahrim', revelationType: 'Medinan', numberOfAyahs: 12, juz: 28, page: 560 },
  { number: 67, name: 'المُلْك', englishName: 'Al-Mulk', revelationType: 'Meccan', numberOfAyahs: 30, juz: 29, page: 562 },
  { number: 68, name: 'القَلَم', englishName: 'Al-Qalam', revelationType: 'Meccan', numberOfAyahs: 52, juz: 29, page: 564 },
  { number: 69, name: 'الحَاقَّة', englishName: 'Al-Haaqqa', revelationType: 'Meccan', numberOfAyahs: 52, juz: 29, page: 566 },
  { number: 70, name: 'المَعَارِج', englishName: 'Al-Ma\'aarij', revelationType: 'Meccan', numberOfAyahs: 44, juz: 29, page: 568 },
  { number: 71, name: 'نُوح', englishName: 'Nooh', revelationType: 'Meccan', numberOfAyahs: 28, juz: 29, page: 570 },
  { number: 72, name: 'الجِنّ', englishName: 'Al-Jinn', revelationType: 'Meccan', numberOfAyahs: 28, juz: 29, page: 572 },
  { number: 73, name: 'المُزَّمِّل', englishName: 'Al-Muzzammil', revelationType: 'Meccan', numberOfAyahs: 20, juz: 29, page: 574 },
  { number: 74, name: 'المُدَّثِّر', englishName: 'Al-Muddaththir', revelationType: 'Meccan', numberOfAyahs: 56, juz: 29, page: 575 },
  { number: 75, name: 'القِيَامَة', englishName: 'Al-Qiyaama', revelationType: 'Meccan', numberOfAyahs: 40, juz: 29, page: 577 },
  { number: 76, name: 'الإِنْسَان', englishName: 'Al-Insaan', revelationType: 'Medinan', numberOfAyahs: 31, juz: 29, page: 578 },
  { number: 77, name: 'المُرْسَلَات', englishName: 'Al-Mursalaat', revelationType: 'Meccan', numberOfAyahs: 50, juz: 29, page: 580 },
  { number: 78, name: 'النَّبَأ', englishName: 'An-Naba', revelationType: 'Meccan', numberOfAyahs: 40, juz: 30, page: 582 },
  { number: 79, name: 'النَّازِعَات', englishName: 'An-Naazi\'aat', revelationType: 'Meccan', numberOfAyahs: 46, juz: 30, page: 583 },
  { number: 80, name: 'عَبَسَ', englishName: 'Abasa', revelationType: 'Meccan', numberOfAyahs: 42, juz: 30, page: 585 },
  { number: 81, name: 'التَّكْوِير', englishName: 'At-Takwir', revelationType: 'Meccan', numberOfAyahs: 29, juz: 30, page: 586 },
  { number: 82, name: 'الانْفِطَار', englishName: 'Al-Infitaar', revelationType: 'Meccan', numberOfAyahs: 19, juz: 30, page: 587 },
  { number: 83, name: 'المُطَفِّفِين', englishName: 'Al-Mutaffifin', revelationType: 'Meccan', numberOfAyahs: 36, juz: 30, page: 587 },
  { number: 84, name: 'الانْشِقَاق', englishName: 'Al-Inshiqaaq', revelationType: 'Meccan', numberOfAyahs: 25, juz: 30, page: 589 },
  { number: 85, name: 'البُرُوج', englishName: 'Al-Burooj', revelationType: 'Meccan', numberOfAyahs: 22, juz: 30, page: 590 },
  { number: 86, name: 'الطَّارِق', englishName: 'At-Taariq', revelationType: 'Meccan', numberOfAyahs: 17, juz: 30, page: 591 },
  { number: 87, name: 'الأَعْلَى', englishName: 'Al-A\'laa', revelationType: 'Meccan', numberOfAyahs: 19, juz: 30, page: 591 },
  { number: 88, name: 'الغَاشِيَة', englishName: 'Al-Ghaashiya', revelationType: 'Meccan', numberOfAyahs: 26, juz: 30, page: 592 },
  { number: 89, name: 'الفَجْر', englishName: 'Al-Fajr', revelationType: 'Meccan', numberOfAyahs: 30, juz: 30, page: 593 },
  { number: 90, name: 'البَلَد', englishName: 'Al-Balad', revelationType: 'Meccan', numberOfAyahs: 20, juz: 30, page: 594 },
  { number: 91, name: 'الشَّمْس', englishName: 'Ash-Shams', revelationType: 'Meccan', numberOfAyahs: 15, juz: 30, page: 595 },
  { number: 92, name: 'اللَّيْل', englishName: 'Al-Layl', revelationType: 'Meccan', numberOfAyahs: 21, juz: 30, page: 595 },
  { number: 93, name: 'الضُّحَى', englishName: 'Ad-Dhuhaa', revelationType: 'Meccan', numberOfAyahs: 11, juz: 30, page: 596 },
  { number: 94, name: 'الشَّرْح', englishName: 'Ash-Sharh', revelationType: 'Meccan', numberOfAyahs: 8, juz: 30, page: 596 },
  { number: 95, name: 'التِّين', englishName: 'At-Tin', revelationType: 'Meccan', numberOfAyahs: 8, juz: 30, page: 597 },
  { number: 96, name: 'العَلَق', englishName: 'Al-Alaq', revelationType: 'Meccan', numberOfAyahs: 19, juz: 30, page: 597 },
  { number: 97, name: 'القَدْر', englishName: 'Al-Qadr', revelationType: 'Meccan', numberOfAyahs: 5, juz: 30, page: 598 },
  { number: 98, name: 'البَيِّنَة', englishName: 'Al-Bayyina', revelationType: 'Medinan', numberOfAyahs: 8, juz: 30, page: 598 },
  { number: 99, name: 'الزَّلْزَلَة', englishName: 'Az-Zalzala', revelationType: 'Medinan', numberOfAyahs: 8, juz: 30, page: 599 },
  { number: 100, name: 'العَادِيَات', englishName: 'Al-Aadiyaat', revelationType: 'Meccan', numberOfAyahs: 11, juz: 30, page: 599 },
  { number: 101, name: 'القَارِعَة', englishName: 'Al-Qaari\'a', revelationType: 'Meccan', numberOfAyahs: 11, juz: 30, page: 600 },
  { number: 102, name: 'التَّكَاثُر', englishName: 'At-Takaathur', revelationType: 'Meccan', numberOfAyahs: 8, juz: 30, page: 600 },
  { number: 103, name: 'العَصْر', englishName: 'Al-Asr', revelationType: 'Meccan', numberOfAyahs: 3, juz: 30, page: 601 },
  { number: 104, name: 'الهُمَزَة', englishName: 'Al-Humaza', revelationType: 'Meccan', numberOfAyahs: 9, juz: 30, page: 601 },
  { number: 105, name: 'الفِيل', englishName: 'Al-Fil', revelationType: 'Meccan', numberOfAyahs: 5, juz: 30, page: 601 },
  { number: 106, name: 'قُرَيْش', englishName: 'Quraish', revelationType: 'Meccan', numberOfAyahs: 4, juz: 30, page: 602 },
  { number: 107, name: 'المَاعُون', englishName: 'Al-Maa\'oon', revelationType: 'Meccan', numberOfAyahs: 7, juz: 30, page: 602 },
  { number: 108, name: 'الكَوْثَر', englishName: 'Al-Kawthar', revelationType: 'Meccan', numberOfAyahs: 3, juz: 30, page: 602 },
  { number: 109, name: 'الكَافِرُون', englishName: 'Al-Kaafiroon', revelationType: 'Meccan', numberOfAyahs: 6, juz: 30, page: 603 },
  { number: 110, name: 'النَّصْر', englishName: 'An-Nasr', revelationType: 'Medinan', numberOfAyahs: 3, juz: 30, page: 603 },
  { number: 111, name: 'المَسَد', englishName: 'Al-Masad', revelationType: 'Meccan', numberOfAyahs: 5, juz: 30, page: 603 },
  { number: 112, name: 'الإِخْلَاص', englishName: 'Al-Ikhlaas', revelationType: 'Meccan', numberOfAyahs: 4, juz: 30, page: 604 },
  { number: 113, name: 'الفَلَق', englishName: 'Al-Falaq', revelationType: 'Meccan', numberOfAyahs: 5, juz: 30, page: 604 },
  { number: 114, name: 'النَّاس', englishName: 'An-Naas', revelationType: 'Meccan', numberOfAyahs: 6, juz: 30, page: 604 },
];

// Offline pre-packaged Surahs for immediate offline instant access
export const OFFLINE_SURAHS: Record<number, SurahDetail> = {
  1: {
    number: 1,
    name: 'الفَاتِحَة',
    englishName: 'Al-Faatiha',
    revelationType: 'Meccan',
    numberOfAyahs: 7,
    juz: 1,
    page: 1,
    bismillahPre: false,
    ayahs: [
      {
        numberInSurah: 1,
        globalNumber: 1,
        text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
        translationEn: 'In the name of Allah, the Entirely Merciful, the Especially Merciful.',
        translationFr: 'Au nom d\'Allah, le Tout Miséricordieux, le Très Miséricordieux.',
        translationUr: 'اللہ کے نام سے جو رحمان و رحیم ہے۔',
        tafseer: 'سورة الفاتحة مفتتح كتاب الله، ابتدأها الله ببسم الله الرحمن الرحيم تعليماً لعباده أن يبتدئوا أعمالهم وأقوالهم باسمه تبارك وتعالى واستعانة به.',
        juz: 1,
        page: 1,
      },
      {
        numberInSurah: 2,
        globalNumber: 2,
        text: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
        translationEn: '[All] praise is [due] to Allah, Lord of the worlds -',
        translationFr: 'Louange à Allah, Seigneur de l\'univers.',
        translationUr: 'سب تعریف اللہ کے لیے ہے جو تمام جہانوں کا پالنے والا ہے۔',
        tafseer: 'الثناء الكامل والمحامد كلها مستحقة لله وحده، خالق الخلائق ومالكهم ومدبر أمورهم ومربيهم بنعمه الظاهرة والباطنة.',
        juz: 1,
        page: 1,
      },
      {
        numberInSurah: 3,
        globalNumber: 3,
        text: 'الرَّحْمَٰنِ الرَّحِيمِ',
        translationEn: 'The Entirely Merciful, the Especially Merciful,',
        translationFr: 'Le Tout Miséricordieux, le Très Miséricordieux,',
        translationUr: 'بڑا مہربان نہایت رحم والا ہے۔',
        tafseer: 'الرحمن الذي وسعت رحمته كل شيء في الدنيا، والرحيم بالمؤمنين يوم القيامة خاصة.',
        juz: 1,
        page: 1,
      },
      {
        numberInSurah: 4,
        globalNumber: 4,
        text: 'مَالِكِ يَوْمِ الدِّينِ',
        translationEn: 'Sovereign of the Day of Recompense.',
        translationFr: 'Maître du Jour de la rétribution.',
        translationUr: 'بدلے کے دن (قیامت) کا مالک ہے۔',
        tafseer: 'الملك المتصرف وحده يوم الجزاء والحساب، يوم لا تملك نفس لنفس شيئاً والأمر يومئذ لله.',
        juz: 1,
        page: 1,
      },
      {
        numberInSurah: 5,
        globalNumber: 5,
        text: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
        translationEn: 'It is You we worship and You we ask for help.',
        translationFr: 'C\'est Toi [Seul] que nous adorons, et c\'est Toi [Seul] dont nous implorons secours.',
        translationUr: 'ہم تیری ہی عبادت کرتے ہیں اور تجھ ہی سے مدد مانگتے ہیں۔',
        tafseer: 'نخصك وحدك بالعبادة والطاعة، ولا نتوجه بالاستعانة والتوكل إلا إليك سبحانك في كل أمورنا.',
        juz: 1,
        page: 1,
      },
      {
        numberInSurah: 6,
        globalNumber: 6,
        text: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
        translationEn: 'Guide us to the straight path -',
        translationFr: 'Guide-nous dans le droit chemin,',
        translationUr: 'ہمیں سیدھے راستے کی ہدایت فرما۔',
        tafseer: 'دلنا وأرشدنا ووفقنا وثبتنا على الطريق الواضح القويم الموصل إلى رضاك وجنتك، وهو دين الإسلام الحق.',
        juz: 1,
        page: 1,
      },
      {
        numberInSurah: 7,
        globalNumber: 7,
        text: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
        translationEn: 'The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.',
        translationFr: 'le chemin de ceux que Tu as comblés de faveurs, non pas de ceux qui ont encouru Ta colère, ni des égarés.',
        translationUr: 'ان لوگوں کا راستہ جن پر تو نے انعام فرمایا، نہ ان کا جن پر غضب ہوا اور نہ گمراہوں کا۔',
        tafseer: 'طريق النبيين والصدّيقين والشهداء والصالحين، لا طريق المعاندين المغضوب عليهم كاليهود، ولا طريق الضالين عن الحق كالنصارى.',
        juz: 1,
        page: 1,
      },
    ],
  },
  112: {
    number: 112,
    name: 'الإِخْلَاص',
    englishName: 'Al-Ikhlaas',
    revelationType: 'Meccan',
    numberOfAyahs: 4,
    juz: 30,
    page: 604,
    bismillahPre: true,
    ayahs: [
      {
        numberInSurah: 1,
        globalNumber: 6222,
        text: 'قُلْ هُوَ اللَّهُ أَحَدٌ',
        translationEn: 'Say, "He is Allah, [who is] One,',
        translationFr: 'Dis: «Il est Allah, Unique.',
        translationUr: 'کہہ دیجیے کہ وہ اللہ ایک ہے۔',
        tafseer: 'قل أيها الرسول للناس: هو الله المتفرد بالألوهية والربوبية والأسماء والصفات، لا شريك له.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 2,
        globalNumber: 6223,
        text: 'اللَّهُ الصَّمَدُ',
        translationEn: 'Allah, the Eternal Refuge.',
        translationFr: 'Allah, Le Seul à être imploré pour ce que nous désirons.',
        translationUr: 'اللہ بے نیاز (سب کا سہارا) ہے۔',
        tafseer: 'الله السيد المقصود وحده في الحوائج والرغائب لكمال غناه وقدرته وسؤدده.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 3,
        globalNumber: 6224,
        text: 'لَمْ يَلِدْ وَلَمْ يُولَدْ',
        translationEn: 'He neither begets nor is born,',
        translationFr: 'Il n\'a jamais engendré, n\'a pas été engendré non plus.',
        translationUr: 'نہ اس کی کوئی اولاد ہے اور نہ وہ کسی کی اولاد ہے۔',
        tafseer: 'ليس له ولد، ولم يولد من أحد؛ لأنه الأول الذي ليس قبله شيء ولا ولد له لكمال غناه وعظمته.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 4,
        globalNumber: 6225,
        text: 'وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ',
        translationEn: 'Nor is there to Him any equivalent."',
        translationFr: 'Et nul n\'est égal à Lui».',
        translationUr: 'اور نہ کوئی اس کا ہمسر ہے۔',
        tafseer: 'وليس له مماثل ولا نظير ولا شبيه في ذاته ولا في صفاته ولا في أفعاله جل وعلا.',
        juz: 30,
        page: 604,
      },
    ],
  },
  113: {
    number: 113,
    name: 'الفَلَق',
    englishName: 'Al-Falaq',
    revelationType: 'Meccan',
    numberOfAyahs: 5,
    juz: 30,
    page: 604,
    bismillahPre: true,
    ayahs: [
      {
        numberInSurah: 1,
        globalNumber: 6226,
        text: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ',
        translationEn: 'Say, "I seek refuge in the Lord of daybreak',
        translationFr: 'Dis: «Je cherche protection auprès du Seigneur de l\'aube naissante,',
        translationUr: 'کہہ دیجیے کہ میں صبح کے رب کی پناہ مانگتا ہوں۔',
        tafseer: 'قل: أعتصم وأتحصن برب الصبح الذي يفلقه من ظلمة الليل.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 2,
        globalNumber: 6227,
        text: 'مِن شَرِّ مَا خَلَقَ',
        translationEn: 'From the evil of that which He created',
        translationFr: 'contre le mal des êtres qu\'Il a créés,',
        translationUr: 'ہر اس چیز کے شر سے جو اس نے پیدا کی۔',
        tafseer: 'من شر جميع المخلوقات المؤذية وأذاها.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 3,
        globalNumber: 6228,
        text: 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ',
        translationEn: 'And from the evil of darkness when it settles',
        translationFr: 'contre le mal de l\'obscurité quand elle s\'approfondit,',
        translationUr: 'اور اندھیری رات کے شر سے جب وہ چھا جائے۔',
        tafseer: 'ومن شر الليل إذا دخل بظلامه وما ينتشر فيه من الشرور والمكاره.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 4,
        globalNumber: 6229,
        text: 'وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ',
        translationEn: 'And from the evil of the blowers in knots',
        translationFr: 'contre le mal de celles qui soufflent [les sorcières] sur les nœuds,',
        translationUr: 'اور گرہوں میں پھونکنے والیوں کے شر سے۔',
        tafseer: 'ومن شر السواحر اللاتي ينفثن في العقد بقصد السحر والإيذاء.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 5,
        globalNumber: 6230,
        text: 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ',
        translationEn: 'And from the evil of an envier when he envies."',
        translationFr: 'et contre le mal de l\'envieux quand il envie».',
        translationUr: 'اور حسد کرنے والے کے شر سے جب وہ حسد کرے۔',
        tafseer: 'ومن شر كل حاسد يكره نعمة الله على عباده ويسعى لزوالها أو إيقاع الضرر بهم.',
        juz: 30,
        page: 604,
      },
    ],
  },
  114: {
    number: 114,
    name: 'النَّاس',
    englishName: 'An-Naas',
    revelationType: 'Meccan',
    numberOfAyahs: 6,
    juz: 30,
    page: 604,
    bismillahPre: true,
    ayahs: [
      {
        numberInSurah: 1,
        globalNumber: 6231,
        text: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ',
        translationEn: 'Say, "I seek refuge in the Lord of mankind,',
        translationFr: 'Dis: «Je cherche protection auprès du Seigneur des hommes.',
        translationUr: 'کہہ دیجیے کہ میں انسانوں کے رب کی پناہ مانگتا ہوں۔',
        tafseer: 'قل: أعتصم وألتجئ إلى رب الناس وخالقهم ومدبر أمورهم.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 2,
        globalNumber: 6232,
        text: 'مَلِكِ النَّاسِ',
        translationEn: 'The Sovereign of mankind,',
        translationFr: 'Le Souverain des hommes,',
        translationUr: 'انسانوں کے بادشاہ کی۔',
        tafseer: 'ملك الناس المتصرف فيهم النافذ فيهم أمره وقضاؤه.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 3,
        globalNumber: 6233,
        text: 'إِلَٰهِ النَّاسِ',
        translationEn: 'The God of mankind,',
        translationFr: 'Dieu des hommes,',
        translationUr: 'انسانوں کے معبود برحق کی۔',
        tafseer: 'إلههم الحق ومعبودهم الذي لا معبود سواه بحق.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 4,
        globalNumber: 6234,
        text: 'مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ',
        translationEn: 'From the evil of the retreating whisperer -',
        translationFr: 'contre le mal du mauvais conseiller, furtif,',
        translationUr: 'پیچھے ہٹ جانے والے وسوسہ ڈالنے والے کے شر سے۔',
        tafseer: 'من شر الشيطان الذي يوسوس في الصدور بالشر، ويختفي ويخنس إذا ذكر العبد ربه.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 5,
        globalNumber: 6235,
        text: 'الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ',
        translationEn: 'Who whispers into the breasts of mankind -',
        translationFr: 'qui souffle le mal dans les poitrines des hommes,',
        translationUr: 'جو لوگوں کے سینوں میں وسوسے ڈالتا ہے۔',
        tafseer: 'الذي يبث الشر والشكوك والأوهام في قلوب بني آدم ونفوسهم.',
        juz: 30,
        page: 604,
      },
      {
        numberInSurah: 6,
        globalNumber: 6236,
        text: 'مِنَ الْجِنَّةِ وَالنَّاسِ',
        translationEn: 'From among the jinn and mankind."',
        translationFr: 'qu\'il soit, (le conseiller), parmi les djinns, ou les hommes».',
        translationUr: 'خواہ وہ جنوں میں سے ہو یا انسانوں میں سے۔',
        tafseer: 'وهؤلاء الشياطين الوسواسون يكونون من شياطين الجن، ويكونون أيضاً من شياطين الإنس الذين يزينون الباطل.',
        juz: 30,
        page: 604,
      },
    ],
  },
};
