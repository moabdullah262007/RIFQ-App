import { PrayerKey } from '../types';

export interface PrayerMeta {
  key: PrayerKey;
  nameAr: string;
  nameEn: string;
  arabicNameDecorated: string;
  timeOfDayText: string;
  rakats: number;
  sunanBefore: string;
  sunanAfter: string;
  hadithVirtue: string;
  hadithSource: string;
  icon: string;
  gradient: string;
}

export const PRAYERS_METADATA: Record<PrayerKey, PrayerMeta> = {
  fajr: {
    key: 'fajr',
    nameAr: 'الفجر',
    nameEn: 'Fajr',
    arabicNameDecorated: 'صَلاةُ الفَجْر',
    timeOfDayText: 'من طلوع الفجر الصادق إلى طلوع الشمس',
    rakats: 2,
    sunanBefore: 'ركعتان سنة مؤكدة («ركعتا الفجر خير من الدنيا وما فيها»)',
    sunanAfter: 'لا توجد نافلة بعد الفجر حتى تطلع الشمس وترتفع',
    hadithVirtue: '«من صلى الصبح فهو في ذمة الله»، و«بشر المشائين في الظلم إلى المساجد بالنور التام يوم القيامة».',
    hadithSource: 'صحيح مسلم وسنن أبي داود',
    icon: '🌅',
    gradient: 'from-amber-700 via-indigo-950 to-slate-900'
  },
  sunrise: {
    key: 'sunrise',
    nameAr: 'الشروق',
    nameEn: 'Sunrise',
    arabicNameDecorated: 'شُرُوقُ الشَّمْس',
    timeOfDayText: 'انتهاء وقت الفجر وخروج قرص الشمس',
    rakats: 0,
    sunanBefore: 'يُكره الصلاة أثناء طلوع قرص الشمس حتى ترتفع قيد رمح (نحو 15 دقيقة)',
    sunanAfter: 'صلاة الضحى (ركعتان إلى ثماني ركعات)',
    hadithVirtue: '«من صلى الفجر في جماعة ثم قعد يذكر الله حتى تطلع الشمس ثم صلى ركعتين كانت له كأجر حجة وعمرة تامة تامة تامة».',
    hadithSource: 'سنن الترمذي - حسن',
    icon: '☀️',
    gradient: 'from-amber-500 via-orange-400 to-amber-600'
  },
  dhuhr: {
    key: 'dhuhr',
    nameAr: 'الظهر',
    nameEn: 'Dhuhr',
    arabicNameDecorated: 'صَلاةُ الظُّهْر',
    timeOfDayText: 'من زوال الشمس عن وسط السماء حتى مصير ظل الشيء مثله',
    rakats: 4,
    sunanBefore: '4 ركعات سنة مؤكدة قبل الظهر (ركعتان ثم ركعتان)',
    sunanAfter: 'ركعتان بعد الظهر سنة مؤكدة (أو 4 ركعات لفضلها العظيم)',
    hadithVirtue: '«من حافظ على أربع ركعات قبل الظهر وأربع بعدها حرمه الله على النار».',
    hadithSource: 'سنن الترمذي والنسائي - صحيح',
    icon: '🕛',
    gradient: 'from-sky-500 via-blue-600 to-indigo-700'
  },
  asr: {
    key: 'asr',
    nameAr: 'العصر',
    nameEn: 'Asr',
    arabicNameDecorated: 'صَلاةُ العَصْر (الصلاة الوسطى)',
    timeOfDayText: 'من مصير ظل الشيء مثله إلى اصفرار الشمس وغروبها',
    rakats: 4,
    sunanBefore: '4 ركعات مستحبة («رحم الله امرأ صلى قبل العصر أربعاً»)',
    sunanAfter: 'لا نافلة بعد العصر حتى تغرب الشمس',
    hadithVirtue: '«من صلى البردين (الفجر والعصر) دخل الجنة»، وقال تعالى: ﴿حَافِظُوا عَلَى الصَّلَوَاتِ وَالصَّلَاةِ الْوُسْطَىٰ﴾.',
    hadithSource: 'صحيح البخاري ومسلم',
    icon: '🌇',
    gradient: 'from-amber-600 via-orange-600 to-amber-900'
  },
  maghrib: {
    key: 'maghrib',
    nameAr: 'المغرب',
    nameEn: 'Maghrib',
    arabicNameDecorated: 'صَلاةُ المَغْرِب',
    timeOfDayText: 'من مغيب كامل قرص الشمس إلى مغيب الشفق الأحمر',
    rakats: 3,
    sunanBefore: 'ركعتان خفيفتان مستحبتان بين الأذان والإقامة',
    sunanAfter: 'ركعتان بعد المغرب سنة مؤكدة',
    hadithVirtue: 'وقت إجابة واستجابة للصائمين ومسارعة في الخيرات، وصلاة أوابين خاشعين.',
    hadithSource: 'صحيح البخاري ومسند أحمد',
    icon: '🌆',
    gradient: 'from-rose-600 via-purple-900 to-indigo-950'
  },
  isha: {
    key: 'isha',
    nameAr: 'العشاء',
    nameEn: 'Isha',
    arabicNameDecorated: 'صَلاةُ العِشَاء',
    timeOfDayText: 'من مغيب الشفق الأحمر إلى نصف الليل أو ثلثه الأول',
    rakats: 4,
    sunanBefore: 'ركعتان مستحبتان بين الأذان والإقامة',
    sunanAfter: 'ركعتان بعد العشاء سنة مؤكدة، ثم صلاة الوتر وقيام الليل',
    hadithVirtue: '«من صلى العشاء في جماعة فكأنما قام نصف الليل، ومن صلى الصبح في جماعة فكأنما صلى الليل كله».',
    hadithSource: 'صحيح مسلم',
    icon: '🌃',
    gradient: 'from-indigo-950 via-slate-900 to-[#0A192F]'
  }
};

export interface PostPrayerDhikr {
  id: string;
  title: string;
  text: string;
  repeat: number;
  virtue: string;
  source: string;
}

export const POST_PRAYER_ATHKAR: PostPrayerDhikr[] = [
  {
    id: 'post-1',
    title: 'الاستغفار والسلام',
    text: 'أَسْتَغْفِرُ اللَّهَ، أَسْتَغْفِرُ اللَّهَ، أَسْتَغْفِرُ اللَّهَ.. اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالإِكْرَامِ.',
    repeat: 1,
    virtue: 'كان رسول الله ﷺ إذا انصرف من صلاته استغفر ثلاثاً وقال هذا الذكر الطيب المبارك.',
    source: 'صحيح مسلم (591)'
  },
  {
    id: 'post-2',
    title: 'التهليل وتوحيد الملك والقدرة',
    text: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، اللَّهُمَّ لَا مَانِعَ لِمَا أَعْطَيْتَ، وَلَا مُعْطِيَ لِمَا مَنَعْتَ، وَلَا يَنْفَعُ ذَا الْجَدِّ مِنْكَ الْجَدُّ.',
    repeat: 1,
    virtue: 'دعاء خالص بالتوحيد والافتقار إلى الله وحده لا شريك له.',
    source: 'صحيح البخاري (844) ومسلم (593)'
  },
  {
    id: 'post-3',
    title: 'التهليل ونفي الشرك وإخلاص الدين',
    text: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ، لَا إِلَهَ إِلَّا اللَّهُ، وَلَا نَعْبُدُ إِلَّا إِيَّاهُ، لَهُ النِّعْمَةُ وَلَهُ الْفَضْلُ وَلَهُ الثَّنَاءُ الْحَسَنُ، لَا إِلَهَ إِلَّا اللَّهُ مُخْلِصِينَ لَهُ الدِّينَ وَلَوْ كَرِهَ الْكَافِرُونَ.',
    repeat: 1,
    virtue: 'كان ابن الزبير يُهلل بهن دبر كل صلاة حين يسلّم.',
    source: 'صحيح مسلم (594)'
  },
  {
    id: 'post-4',
    title: 'التسبيح والتحميد والتكبير وتمام المائة',
    text: '«سُبْحَانَ اللَّهِ» (٣٣ مرة)، «الْحَمْدُ لِلَّهِ» (٣٣ مرة)، «اللَّهُ أَكْبَرُ» (٣٣ مرة).. وتَمَامُ الْمِائَةِ: «لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ».',
    repeat: 1,
    virtue: '«غُفِرَتْ خَطَايَاهُ وَإِنْ كَانَتْ مِثْلَ زَبَدِ الْبَحْرِ».',
    source: 'صحيح مسلم (597)'
  },
  {
    id: 'post-5',
    title: 'آية الكرسي العظيمة',
    text: '﴿اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ﴾.',
    repeat: 1,
    virtue: '«مَنْ قَرَأَ آيَةَ الْكُرْسِيِّ فِي دُبُرِ كُلِّ صَلَاةٍ مَكْتُوبَةٍ لَمْ يَمْنَعْهُ مِنْ دُخُولِ الْجَنَّةِ إِلَّا أَنْ يَمُوتَ».',
    source: 'سنن النسائي الكبرى - صححه الألباني'
  },
  {
    id: 'post-6',
    title: 'قراءة المعوذات والإخلاص',
    text: 'قراءة ﴿قُلْ هُوَ اللَّهُ أَحَدٌ﴾ و ﴿قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ﴾ و ﴿قُلْ أَعُوذُ بِرَبِّ النَّاسِ﴾ (مرة بعد الظهر والعصر والعشاء، وثلاث مرات بعد الفجر والمغرب).',
    repeat: 1,
    virtue: 'عن عقبة بن عامر قال: «أمرني رسول الله ﷺ أن أقرأ بالمعوذات دبر كل صلاة».',
    source: 'سنن أبي داود والترمذي - صحيح'
  },
  {
    id: 'post-7',
    title: 'سؤال الإعانة على الذكر والشكر وحسن العبادة',
    text: 'اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ، وَشُكْرِكَ، وَحُسْنِ عِبَادَتِكَ.',
    repeat: 1,
    virtue: 'وصية الحبيب المصطفى ﷺ لمعاذ بن جبل: «يا معاذ، والله إني لأحبك، فلا تدعن في دبر كل صلاة أن تقول..».',
    source: 'سنن أبي داود والنسائي - صحيح'
  }
];

export interface IslamicOccasion {
  id: string;
  nameAr: string;
  hijriDay: number;
  hijriMonth: number; // 1 = Muharram .. 12 = Dhul Hijjah
  hijriMonthName: string;
  description: string;
  virtues: string[];
}

export const ISLAMIC_OCCASIONS: IslamicOccasion[] = [
  {
    id: 'ramadan',
    nameAr: 'غرة شهر رمضان المبارك',
    hijriDay: 1,
    hijriMonth: 9,
    hijriMonthName: 'رمضان',
    description: 'شهر الصيام والقرآن والرحمات ومضاعفة الأجور والعتق من النيران.',
    virtues: ['تفتح فيه أبواب الجنة وتغلق أبواب النار', 'فيه ليلة القدر خير من ألف شهر', 'فريضة الصيام ركن الإسلام']
  },
  {
    id: 'laylat-al-qadr',
    nameAr: 'ليالي القدر والوتر العظيمة',
    hijriDay: 27,
    hijriMonth: 9,
    hijriMonthName: 'رمضان',
    description: 'العشر الأواخر من رمضان وخاصة الليالي الوترية أرجى ليلة القدر.',
    virtues: ['خير من ألف شهر (عبادة أكثر من 83 عاماً)', 'تتنزل الملائكة والروح فيها بإذن ربهم من كل أمر']
  },
  {
    id: 'eid-al-fitr',
    nameAr: 'عيد الفطر المبارك',
    hijriDay: 1,
    hijriMonth: 10,
    hijriMonthName: 'شوال',
    description: 'يوم الجائزة والفرح بإتمام صيام شهر رمضان وزكاة الفطر.',
    virtues: ['يوم شكر وفرح ووصل للأرحام', 'صلاة العيد وسماع الخطبة', 'إظهار الفرح المشروع']
  },
  {
    id: 'arafah',
    nameAr: 'يوم عرفة المبارك',
    hijriDay: 9,
    hijriMonth: 12,
    hijriMonthName: 'ذو الحجة',
    description: 'أفضل أيام العام، يقف فيه حجاج بيت الله الحرام على صعيد عرفات.',
    virtues: ['صيام يوم عرفة يكفر السنة الماضية والباقية لغير الحاج', 'خير الدعاء دعاء يوم عرفة', 'أكثر يوم يعتق الله فيه عباداً من النار']
  },
  {
    id: 'eid-al-adha',
    nameAr: 'عيد الأضحى المبارك (يوم النحر)',
    hijriDay: 10,
    hijriMonth: 12,
    hijriMonthName: 'ذو الحجة',
    description: 'أعظم الأيام عند الله، يوم الحج الأكبر ونحر الأضاحي وذكر الله تعالى.',
    virtues: ['أعظم الأيام عند الله يوم النحر ثم يوم القر', 'إراقة دماء الأضاحي تقرباً لله', 'التكبير والتهليل في أيام التشريق']
  },
  {
    id: 'ashura',
    nameAr: 'يوم عاشوراء',
    hijriDay: 10,
    hijriMonth: 1,
    hijriMonthName: 'محرم',
    description: 'اليوم الذي نجى الله فيه نبيّه موسى عليه السلام وقومه من فرعون وجنوده.',
    virtues: ['صيام عاشوراء أحتسب على الله أن يكفر السنة التي قبله', 'يستحب صيام التاسع معه مخالفة لليهود']
  },
  {
    id: 'hijri-new-year',
    nameAr: 'رأس السنة الهجرية الجديدة',
    hijriDay: 1,
    hijriMonth: 1,
    hijriMonthName: 'محرم',
    description: 'ذكرى الهجرة النبوية الشريفة من مكة المكرمة إلى المدينة المنورة وتأسيس الدولة الإسلامية.',
    virtues: ['شهر الله المحرم من الأشهر الحرم', 'أفضل الصيام بعد رمضان صيام شهر الله المحرم']
  },
  {
    id: 'mawlid',
    nameAr: 'ذكرى المولد النبوي الشريف',
    hijriDay: 12,
    hijriMonth: 3,
    hijriMonthName: 'ربيع الأول',
    description: 'مولد خير البرية ورحمة الله للعالمين سيدنا محمد ﷺ.',
    virtues: ['استذكار سيرته العطرة', 'الإكثار من الصلاة والسلام عليه', 'التخلق بأخلاقه الكريمة']
  },
  {
    id: 'isra-miraj',
    nameAr: 'ذكرى الإسراء والمعراج',
    hijriDay: 27,
    hijriMonth: 7,
    hijriMonthName: 'رجب',
    description: 'معجزة الإسراء من المسجد الحرام إلى المسجد الأقصى والعروج إلى السماوات العلى وفرض الصلاة.',
    virtues: ['فرض الصلوات الخمس في هذه الليلة المباركة', 'مكانة المسجد الأقصى والقدس الشريف في قلب كل مسلم']
  },
  {
    id: 'nisf-shaban',
    nameAr: 'ليلة النصف من شعبان',
    hijriDay: 15,
    hijriMonth: 8,
    hijriMonthName: 'شعبان',
    description: 'ليلة يغفر الله فيها لخلقه إلا لمشرك أو مشاحن.',
    virtues: ['سعة مغفرة الله تعالى', 'تطهير القلوب وسلامة الصدور من الشحناء والبغضاء']
  }
];

export interface MuadhinOption {
  id: string;
  nameAr: string;
  scholarAr: string;
  cityAr: string;
  audioUrl: string;
  backupAudioUrl?: string;
  durationText: string;
  approxDurationSec: number;
  descriptionAr: string;
  badgeText?: string;
}

export const MUADHIN_OPTIONS: MuadhinOption[] = [
  {
    id: 'abdulbaset',
    nameAr: 'أذان الشيخ عبد الباسط عبد الصمد',
    scholarAr: 'الشيخ عبد الباسط عبد الصمد',
    cityAr: 'مصر - تلاوة خاشعة تاريخية',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/049-.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/041--.mp3',
    durationText: '3:45',
    approxDurationSec: 225,
    descriptionAr: 'الأذان المصري التاريخي الخاشع بصوت قيثارة السماء الشيخ عبد الباسط عبد الصمد رحمه الله',
    badgeText: 'أذان تاريخي'
  },
  {
    id: 'refaat',
    nameAr: 'أذان الشيخ محمد رفعت',
    scholarAr: 'الشيخ محمد رفعت',
    cityAr: 'القاهرة - مصر (إذاعة القرآن الكريم)',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/042--.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_Divers_up-by-muslem/042--.mp3',
    durationText: '3:24',
    approxDurationSec: 204,
    descriptionAr: 'أذان المغرب الرمضاني التاريخي الخالد من القاهرة بصوت قيثارة السماء الشيخ محمد رفعت',
    badgeText: 'رمضاني خالد'
  },
  {
    id: 'ali-mullah',
    nameAr: 'أذان الحرم المكي (الشيخ علي أحمد ملا)',
    scholarAr: 'الشيخ علي أحمد ملا',
    cityAr: 'المسجد الحرام - مكة المكرمة',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/047--.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/033--.mp3',
    durationText: '2:56',
    approxDurationSec: 176,
    descriptionAr: 'الأذان الحجازي المهيب من المسجد الحرام بمكة المكرمة بصوت شيخ مؤذني الحرم الشيخ علي ملا',
    badgeText: 'الحرم المكي'
  },
  {
    id: 'sudais',
    nameAr: 'أذان الحرم المكي (الشيخ عبد الرحمن السديس)',
    scholarAr: 'الشيخ عبد الرحمن السديس',
    cityAr: 'الحرم المكي الشريف - مكة المكرمة',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/019--1.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/056--3.mp3',
    durationText: '3:56',
    approxDurationSec: 236,
    descriptionAr: 'أذان وتكبيرات روحانية عطرة من رحاب المسجد الحرام بإمامة ورئاسة شؤون الحرمين',
    badgeText: 'مكة المكرمة'
  },
  {
    id: 'alafasy',
    nameAr: 'أذان الشيخ مشاري بن راشد العفاسي',
    scholarAr: 'الشيخ مشاري راشد العفاسي',
    cityAr: 'دولة الكويت - المسجد الكبير',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/074-1_-.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/038-1.mp3',
    durationText: '3:07',
    approxDurationSec: 187,
    descriptionAr: 'أذان عذب شجي مؤثر في مقام الحجاز بصوت الشيخ مشاري راشد العفاسي',
    badgeText: 'صوت شجي'
  },
  {
    id: 'minshawi',
    nameAr: 'أذان الشيخ محمد صديق المنشاوي',
    scholarAr: 'الشيخ محمد صديق المنشاوي',
    cityAr: 'مصر - الصوت الباكي الخاشع',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/048-.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/050-.mp3',
    durationText: '4:07',
    approxDurationSec: 247,
    descriptionAr: 'أذان نادر يفيض خشوعاً وإخباتاً بصوت الشيخ محمد صديق المنشاوي رحمه الله',
    badgeText: 'خشوع فائق'
  },
  {
    id: 'muaiqly',
    nameAr: 'أذان المسجد النبوي (الشيخ ماهر المعيقلي)',
    scholarAr: 'الشيخ ماهر المعيقلي',
    cityAr: 'المسجد النبوي الشريف - المدينة المنورة',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/034--.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/018-.mp3',
    durationText: '4:39',
    approxDurationSec: 279,
    descriptionAr: 'أذان الفجر العطر من رحاب المسجد النبوي الشريف بالمدينة المنورة ومكة المكرمة',
    badgeText: 'المسجد النبوي'
  },
  {
    id: 'ajmi',
    nameAr: 'أذان الشيخ أحمد بن علي العجمي',
    scholarAr: 'الشيخ أحمد العجمي',
    cityAr: 'المنطقة الشرقية - المملكة العربية السعودية',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/035-.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/001-.mp3',
    durationText: '3:25',
    approxDurationSec: 205,
    descriptionAr: 'أذان خاشع بصوت هادئ ومريح للنفس بصوت القارئ الشيخ أحمد العجمي',
    badgeText: 'صوت عذب'
  },
  {
    id: 'hussary',
    nameAr: 'أذان الشيخ محمود خليل الحصري',
    scholarAr: 'الشيخ محمود خليل الحصري',
    cityAr: 'مصر - شيخ عموم المقارئ المصرية',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/044--.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_Divers_up-by-muslem/044--.mp3',
    durationText: '2:08',
    approxDurationSec: 128,
    descriptionAr: 'أذان القاهرة الوقور المتقن للأحكام والتجويد بصوت الشيخ محمود خليل الحصري رحمه الله',
    badgeText: 'متقن ووقور'
  },
  {
    id: 'aqsa',
    nameAr: 'أذان المسجد الأقصى المبارك (ناجي قزاز)',
    scholarAr: 'الشيخ ناجي قزاز',
    cityAr: 'القدس الشريف - المسجد الأقصى',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/045--.mp3',
    backupAudioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/046--.mp3',
    durationText: '3:05',
    approxDurationSec: 185,
    descriptionAr: 'أذان المسجد الأقصى المبارك أولى القبلتين وثالث الحرمين الشريفين بصوت مؤذن الأقصى',
    badgeText: 'المسجد الأقصى'
  }
];
