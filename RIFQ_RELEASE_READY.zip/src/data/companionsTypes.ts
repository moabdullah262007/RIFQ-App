export type CompanionCategoryId =
  | 'khulafa'
  | 'ashara'
  | 'sabiqun'
  | 'commanders'
  | 'scholars'
  | 'sahabiyat'
  | 'ummahat'
  | 'narrators';

export interface CompanionCategory {
  id: CompanionCategoryId;
  name: string;
  icon: string;
  description: string;
  countLabel: string;
}

export interface CompanionStory {
  id: string;
  companion_id: string;
  title: string;
  content: string;
  reference: string;
  order_number: number;
}

export interface CompanionHadith {
  text: string;
  source: string;
}

export interface CompanionProfile {
  id: string;
  category_ids: CompanionCategoryId[];
  name: string;
  full_name: string;
  title: string;
  birth_date: string;
  death_date: string;
  birth_place: string;
  bio: string;
  virtues: string[];
  stories: CompanionStory[];
  hadiths_count: string;
  hadiths: CompanionHadith[];
  death_details: string;
  lessons: string[];
  sources: string[];
  order_number: number;
  gender: 'male' | 'female';
}

export const COMPANION_CATEGORIES: CompanionCategory[] = [
  {
    id: 'khulafa',
    name: 'الخلفاء الراشدون',
    icon: 'khulafa',
    description: 'الخلفاء الأربعة الهداة المهديون الذين حملوا راية الأمة بعد النبي صلى الله عليه وسلم',
    countLabel: '4 صحابة',
  },
  {
    id: 'ashara',
    name: 'العشرة المبشرون بالجنة',
    icon: 'ashara',
    description: 'الصحابة الكرام الذين بشّرهم النبي صلى الله عليه وسلم بالجنة في حديث واحد',
    countLabel: '10 صحابة',
  },
  {
    id: 'sabiqun',
    name: 'السابقون الأولون',
    icon: 'sabiqun',
    description: 'الطليعة الأولى التي سبقت إلى الإسلام وصبرت على الأذى في مكة المكرمة',
    countLabel: '7 صحابة',
  },
  {
    id: 'commanders',
    name: 'القادة العسكريون',
    icon: 'commanders',
    description: 'قادة الفتوحات الإسلامية الذين دكّوا حصون كسرى وقيصر بنصر الله',
    countLabel: '5 صحابة',
  },
  {
    id: 'scholars',
    name: 'علماء الصحابة',
    icon: 'scholars',
    description: 'أئمة التفسير والفقه والقضاء وجمع القرآن الكريم من أصحاب النبي صلى الله عليه وسلم',
    countLabel: '7 صحابة',
  },
  {
    id: 'sahabiyat',
    name: 'الصحابيات الجليلات',
    icon: 'sahabiyat',
    description: 'نماذج خالدة في الإيمان والصبر والفداء والعلم من نساء الصحابة رضي الله عنهن',
    countLabel: '7 صحابيات',
  },
  {
    id: 'ummahat',
    name: 'أمهات المؤمنين',
    icon: 'ummahat',
    description: 'أزواج النبي صلى الله عليه وسلم الطاهرات المطهرات في الدنيا والآخرة',
    countLabel: '10 أمهات',
  },
  {
    id: 'narrators',
    name: 'رواة الحديث',
    icon: 'narrators',
    description: 'المكثرون من حفظ ورواية السنة النبوية المطهرة وتبليغها للأمة',
    countLabel: '6 صحابة',
  },
];
