/**
 * Production-ready Flutter Audio & Notification module for Islamic Prayer Alerts & Real MP3 Adhan Audio.
 * Uses just_audio, audio_service, dio, path_provider, and flutter_local_notifications.
 */

export const FLUTTER_PUBSPEC_SNIPPET = `dependencies:
  flutter:
    sdk: flutter
  # Audio Playback & Background Service
  just_audio: ^0.9.36
  audio_service: ^0.18.12
  # Offline File Downloading & Storage
  dio: ^5.4.1
  path_provider: ^2.1.2
  # Local Notifications & Permissions
  flutter_local_notifications: ^17.2.2
  permission_handler: ^11.3.1
  timezone: ^0.9.4
  flutter_timezone: ^3.0.1
  shared_preferences: ^2.3.2`;

export const FLUTTER_NOTIFICATION_SERVICE_CODE = `import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_service/audio_service.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';

enum PrayerType { fajr, sunrise, dhuhr, asr, maghrib, isha }
enum AlertSoundMode { fullAdhan, takbeerOnly, gentleChime, silent }

class MuadhinModel {
  final String id;
  final String nameAr;
  final String scholarAr;
  final String audioUrl;
  final String durationText;

  const MuadhinModel({
    required this.id,
    required this.nameAr,
    required this.scholarAr,
    required this.audioUrl,
    required this.durationText,
  });
}

const List<MuadhinModel> kMuadhinList = [
  MuadhinModel(
    id: 'abdulbaset',
    nameAr: 'أذان الشيخ عبد الباسط عبد الصمد',
    scholarAr: 'الشيخ عبد الباسط عبد الصمد',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/049-.mp3',
    durationText: '3:45',
  ),
  MuadhinModel(
    id: 'refaat',
    nameAr: 'أذان الشيخ محمد رفعت',
    scholarAr: 'الشيخ محمد رفعت',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/042--.mp3',
    durationText: '3:24',
  ),
  MuadhinModel(
    id: 'ali-mullah',
    nameAr: 'أذان الحرم المكي (الشيخ علي ملا)',
    scholarAr: 'الشيخ علي أحمد ملا',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/047--.mp3',
    durationText: '2:56',
  ),
  MuadhinModel(
    id: 'sudais',
    nameAr: 'أذان الحرم المكي (الشيخ عبد الرحمن السديس)',
    scholarAr: 'الشيخ عبد الرحمن السديس',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/019--1.mp3',
    durationText: '3:56',
  ),
  MuadhinModel(
    id: 'alafasy',
    nameAr: 'أذان الشيخ مشاري بن راشد العفاسي',
    scholarAr: 'الشيخ مشاري راشد العفاسي',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/074-1_-.mp3',
    durationText: '3:07',
  ),
  MuadhinModel(
    id: 'minshawi',
    nameAr: 'أذان الشيخ محمد صديق المنشاوي',
    scholarAr: 'الشيخ محمد صديق المنشاوي',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/048-.mp3',
    durationText: '4:07',
  ),
  MuadhinModel(
    id: 'muaiqly',
    nameAr: 'أذان المسجد النبوي (الشيخ ماهر المعيقلي)',
    scholarAr: 'الشيخ ماهر المعيقلي',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/034--.mp3',
    durationText: '4:39',
  ),
  MuadhinModel(
    id: 'ajmi',
    nameAr: 'أذان الشيخ أحمد بن علي العجمي',
    scholarAr: 'الشيخ أحمد العجمي',
    audioUrl: 'https://archive.org/download/AdhaN_M_up-by-muslem/035-.mp3',
    durationText: '3:25',
  ),
];

/// 1. Offline Adhan File Caching Service (dio + path_provider)
class AdhanDownloadManager {
  static final AdhanDownloadManager instance = AdhanDownloadManager._();
  AdhanDownloadManager._();

  final Dio _dio = Dio();

  Future<String> getAdhanDirectory() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('\${docs.path}/adhan_audio');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir.path;
  }

  Future<File?> getCachedFile(String muadhinId) async {
    final dir = await getAdhanDirectory();
    final file = File('\$dir/\$muadhinId.mp3');
    if (await file.exists() && await file.length() > 10000) {
      return file;
    }
    return null;
  }

  Future<File> downloadAndCache({
    required MuadhinModel muadhin,
    void Function(int received, int total)? onProgress,
  }) async {
    final dir = await getAdhanDirectory();
    final filePath = '\$dir/\${muadhin.id}.mp3';
    final targetFile = File(filePath);

    await _dio.download(
      muadhin.audioUrl,
      filePath,
      onReceiveProgress: (received, total) {
        if (onProgress != null && total > 0) {
          onProgress(received, total);
        }
      },
    );

    return targetFile;
  }

  Future<bool> deleteCached(String muadhinId) async {
    final file = await getCachedFile(muadhinId);
    if (file != null && await file.exists()) {
      await file.delete();
      return true;
    }
    return false;
  }
}

/// 2. Background Audio Handler using audio_service & just_audio
class AdhanAudioHandler extends BaseAudioHandler with SeekHandler {
  final AudioPlayer _player = AudioPlayer();

  AdhanAudioHandler() {
    _init();
  }

  void _init() {
    _player.playbackEventStream.listen((PlaybackEvent event) {
      final playing = _player.playing;
      playbackState.add(playbackState.value.copyWith(
        controls: [
          MediaControl.rewind,
          if (playing) MediaControl.pause else MediaControl.play,
          MediaControl.stop,
        ],
        systemActions: const {MediaAction.seek},
        androidCompactActionIndices: const [1, 2],
        processingState: const {
          ProcessingState.idle: AudioProcessingState.idle,
          ProcessingState.loading: AudioProcessingState.loading,
          ProcessingState.buffering: AudioProcessingState.buffering,
          ProcessingState.ready: AudioProcessingState.ready,
          ProcessingState.completed: AudioProcessingState.completed,
        }[_player.processingState]!,
        playing: playing,
        updatePosition: _player.position,
        bufferedPosition: _player.bufferedPosition,
        speed: _player.speed,
      ));
    });

    _player.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        stop();
      }
    });
  }

  /// Play real Adhan with offline cache check
  Future<void> playAdhan({
    required MuadhinModel muadhin,
    String? prayerName,
    AlertSoundMode soundMode = AlertSoundMode.fullAdhan,
    double volume = 0.9,
  }) async {
    await _player.setVolume(volume);

    // Check offline cache first
    final cached = await AdhanDownloadManager.instance.getCachedFile(muadhin.id);
    if (cached != null) {
      await _player.setFilePath(cached.path);
    } else {
      await _player.setUrl(muadhin.audioUrl);
      // Auto cache in background for next time
      AdhanDownloadManager.instance.downloadAndCache(muadhin: muadhin).catchError((e) {});
    }

    mediaItem.add(MediaItem(
      id: muadhin.id,
      album: 'مسبحة رفيق المسلم',
      title: prayerName != null ? 'أذان صلاة \$prayerName' : 'أذان الصلاة',
      artist: muadhin.nameAr,
      artUri: Uri.parse('asset:///assets/images/app_icon.png'),
    ));

    await _player.play();

    // If Takbeer only mode, stop after 26 seconds
    if (soundMode == AlertSoundMode.takbeerOnly) {
      Future.delayed(const Duration(seconds: 26), () {
        if (_player.playing) stop();
      });
    }
  }

  @override
  Future<void> play() => _player.play();

  @override
  Future<void> pause() => _player.pause();

  @override
  Future<void> stop() async {
    await _player.stop();
    await super.stop();
  }

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  Future<void> setVolume(double val) => _player.setVolume(val);
}

/// 3. Notification Service
class PrayerNotificationService {
  PrayerNotificationService._();
  static final PrayerNotificationService instance = PrayerNotificationService._();

  final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  late final AdhanAudioHandler audioHandler;

  Future<void> initialize() async {
    tz.initializeTimeZones();
    final timeZoneName = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(timeZoneName));

    audioHandler = await AudioService.init(
      builder: () => AdhanAudioHandler(),
      config: const AudioServiceConfig(
        androidNotificationChannelId: 'com.rafiq.muslim.adhan_channel',
        androidNotificationChannelName: 'أذان الصلوات المفروضة',
        androidNotificationOngoing: true,
        androidStopForegroundOnPause: true,
      ),
    );

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    await _notificationsPlugin.initialize(
      const InitializationSettings(android: androidSettings, iOS: iosSettings),
    );
  }

  Future<void> triggerAdhan({
    required String prayerName,
    required MuadhinModel muadhin,
    AlertSoundMode soundMode = AlertSoundMode.fullAdhan,
    double volume = 0.9,
  }) async {
    // 1. Play real MP3 adhan
    await audioHandler.playAdhan(
      muadhin: muadhin,
      prayerName: prayerName,
      soundMode: soundMode,
      volume: volume,
    );

    // 2. Display High-Priority Notification
    const androidDetails = AndroidNotificationDetails(
      'com.rafiq.muslim.adhan_channel',
      'أذان الصلوات المفروضة',
      channelDescription: 'تنبيهات دخول وقت الأذان بالصوت الكامل',
      importance: Importance.max,
      priority: Priority.high,
      playSound: false, // Handled via just_audio for full control
      enableVibration: true,
    );

    await _notificationsPlugin.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000,
      'حان موعد أذان \$prayerName 🕌',
      'صوت \${muadhin.nameAr} • حي على الصلاة',
      const NotificationDetails(android: androidDetails),
    );
  }
}`;

export const FLUTTER_ANDROID_SETUP_GUIDE = `<!-- 1. AndroidManifest.xml: أذونات التشغيل في الخلفية وخدمة الصوت -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- أذونات التنبيهات والصوت والتشغيل في الخلفية -->
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>

    <application ...>
        <!-- خدمة تشغيل الصوت في الخلفية (audio_service) -->
        <service
            android:name="com.ryanheise.audioservice.AudioService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="true">
            <intent-filter>
                <action android:name="android.media.browse.MediaBrowserService" />
            </intent-filter>
        </service>

        <receiver
            android:name="com.ryanheise.audioservice.MediaButtonReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MEDIA_BUTTON" />
            </intent-filter>
        </receiver>
    </application>
</manifest>

<!-- 2. iOS Info.plist: Background Audio Modes -->
<dict>
    <key>UIBackgroundModes</key>
    <array>
        <string>audio</string>
        <string>fetch</string>
        <string>remote-notification</string>
    </array>
</dict>`;
