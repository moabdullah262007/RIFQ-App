import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  auth,
  onAuthStateChanged,
  User,
  signOut,
  ensureUserCloudDoc,
  UserCloudProfile,
  doc,
  db,
  getAuthErrorMessage,
  consumePendingNativeGoogleAuth,
  signOutNativeGoogleAccount,
} from '../utils/firebase';
import { onSnapshot } from 'firebase/firestore';
import {
  verifyAdminAccess,
  syncCurrentDeviceNotificationStatus,
} from '../utils/adminService';
import {
  syncUserDataWithFirestore,
  pushUserDataToFirestore,
  applyCloudSnapshotToLocal,
  switchActiveUserStorageContext,
  saveIsolatedAccountSnapshot,
  hasLocalMutationId,
  isCloudSyncInProgress,
} from '../utils/cloudSync';
import { isStorageCloudHydrating } from '../utils/storage';

export type AuthModalMode = 'login' | 'signup' | 'forgot' | 'verification';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserCloudProfile | null;
  isAdmin: boolean;
  adminChecking: boolean;
  loading: boolean;
  isAuthModalOpen: boolean;
  authModalMode: AuthModalMode;
  syncStatus: 'idle' | 'syncing' | 'synced' | 'error';
  lastSyncedAt: number | null;
  authError: string | null;
  setAuthError: (err: string | null) => void;
  clearAuthError: () => void;
  openAuthModal: (mode?: AuthModalMode) => void;
  closeAuthModal: () => void;
  refreshUserProfile: () => Promise<void>;
  verifyAdminNow: () => Promise<boolean>;
  triggerCloudSync: () => Promise<boolean>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserCloudProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [adminChecking, setAdminChecking] = useState<boolean>(true);
  const [loading, setLoading] = useState(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<AuthModalMode>('login');
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'synced' | 'error'>('idle');
  const [lastSyncedAt, setLastSyncedAt] = useState<number | null>(null);
  const [authError, setAuthErrorState] = useState<string | null>(null);

  const pushDebounceRef = useRef<number | null>(null);
  const currentUidRef = useRef<string>('guest');
  const lastProcessedSnapshotKeyRef = useRef<string>('');

  const clearAuthError = useCallback(() => {
    setAuthErrorState(null);
  }, []);

  const setAuthError = useCallback((err: string | null) => {
    if (!err) {
      setAuthErrorState(null);
    } else {
      setAuthErrorState(getAuthErrorMessage(err));
    }
  }, []);

  // Trigger full two-way Cloud Sync for the active user
  const triggerCloudSync = useCallback(async (): Promise<boolean> => {
    if (!currentUser) return false;
    setSyncStatus('syncing');
    try {
      const res = await syncUserDataWithFirestore(currentUser.uid);
      if (res.success) {
        setSyncStatus('synced');
        setLastSyncedAt(res.syncedAt);
        return true;
      } else {
        setSyncStatus('error');
        return false;
      }
    } catch (e) {
      console.warn('Cloud sync error in AuthProvider:', e);
      setSyncStatus('error');
      return false;
    }
  }, [currentUser]);

  // Refresh User Profile from Firestore
  const refreshUserProfile = useCallback(async () => {
    if (!currentUser) {
      setUserProfile(null);
      setIsAdmin(false);
      return;
    }
    try {
      const p = await ensureUserCloudDoc(currentUser);
      setUserProfile(p);
      const adminRes = await verifyAdminAccess(currentUser);
      setIsAdmin(adminRes.isAdmin);
    } catch (e) {
      console.warn('Error fetching cloud profile:', e);
    }
  }, [currentUser]);

  // Explicit on-demand server verification of Admin privileges
  const verifyAdminNow = useCallback(async (): Promise<boolean> => {
    const activeUser = auth.currentUser || currentUser;
    if (!activeUser) {
      setIsAdmin(false);
      setAdminChecking(false);
      return false;
    }
    setAdminChecking(true);
    try {
      const res = await verifyAdminAccess(activeUser);
      setIsAdmin(res.isAdmin);
      return res.isAdmin;
    } catch {
      setIsAdmin(false);
      return false;
    } finally {
      setAdminChecking(false);
    }
  }, [currentUser]);

  // Auth State Listener: Handles account switching, per-user Misbaha & Athkar isolation, and initial Firestore sync
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      async (user) => {
        const targetUid = user ? user.uid : 'guest';
        currentUidRef.current = targetUid;
        lastProcessedSnapshotKeyRef.current = '';

        // 1. Immediately isolate outgoing user's data and load incoming user's local snapshot
        switchActiveUserStorageContext(targetUid);

        setCurrentUser(user);
        setLoading(false);
        clearAuthError();

        if (user) {
          setIsAuthModalOpen(false);
          setSyncStatus('syncing');
          setAdminChecking(true);
          try {
            const [profile, adminRes] = await Promise.all([
              ensureUserCloudDoc(user),
              verifyAdminAccess(user),
            ]);
            setUserProfile(profile);
            setIsAdmin(adminRes.isAdmin);
            setAdminChecking(false);

            // Sync real device notification state for accurate admin device stats
            syncCurrentDeviceNotificationStatus(user);

            // 2. Synchronize this user's isolated Misbaha, Athkar, and Settings with Firestore
            const res = await syncUserDataWithFirestore(user.uid);
            setSyncStatus(res.success ? 'synced' : 'idle');
            setLastSyncedAt(res.syncedAt);
          } catch (e) {
            console.warn('Could not bootstrap user doc:', e);
            setAdminChecking(false);
            setSyncStatus('error');
          }
        } else {
          setUserProfile(null);
          setIsAdmin(false);
          setAdminChecking(false);
          setSyncStatus('idle');
          setLastSyncedAt(Date.now());
        }
      },
      (error) => {
        console.warn('onAuthStateChanged error:', error);
        setLoading(false);
        setAdminChecking(false);
        setAuthErrorState(getAuthErrorMessage(error));
      }
    );

    return () => unsubscribe();
  }, [clearAuthError]);

  // Recover any pending native Android Google Sign-In result on cold/warm resume or Activity recreation
  useEffect(() => {
    let checkingPending = false;
    const checkPendingNativeAuth = async () => {
      if (checkingPending || auth.currentUser) return;
      checkingPending = true;
      try {
        const cred = await consumePendingNativeGoogleAuth();
        if (cred?.user) {
          setIsAuthModalOpen(false);
        }
      } catch {
        // ignore
      } finally {
        checkingPending = false;
      }
    };

    checkPendingNativeAuth();

    const handleResumeOrFocus = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') {
        checkPendingNativeAuth();
      }
    };

    window.addEventListener('focus', handleResumeOrFocus);
    document.addEventListener('visibilitychange', handleResumeOrFocus);
    return () => {
      window.removeEventListener('focus', handleResumeOrFocus);
      document.removeEventListener('visibilitychange', handleResumeOrFocus);
    };
  }, []);

  // Real-time listener on /admins/{uid} so role grants/revocations reflect immediately
  useEffect(() => {
    if (!currentUser) {
      setIsAdmin(false);
      return;
    }
    const adminRef = doc(db, 'admins', currentUser.uid);
    const unsubAdmin = onSnapshot(
      adminRef,
      (snap) => {
        if (snap.exists() && snap.data()?.role === 'admin') {
          setIsAdmin(true);
        } else {
          // Re-verify in case of primary bootstrapped admin
          verifyAdminAccess(currentUser).then((r) => setIsAdmin(r.isAdmin));
        }
      },
      () => {
        // Ignore listener errors if offline
      }
    );
    return () => unsubAdmin();
  }, [currentUser]);

  // Real-time Firestore listener on `users/{uid}` for instant settings, Misbaha, and Athkar sync across devices & account switches
  useEffect(() => {
    if (!currentUser) return;

    const uid = currentUser.uid;
    const userDocRef = doc(db, 'users', uid);

    const unsubDoc = onSnapshot(
      userDocRef,
      (snap) => {
        if (!snap.exists()) return;
        // Ignore local latency-compensated writes originating from this browser tab
        if (snap.metadata.hasPendingWrites) return;

        const data = snap.data() as UserCloudProfile;
        const remoteMutationId = data.lastMutationId || '';
        const snapshotDedupeKey = `${uid}_${remoteMutationId}_${data.updatedAt || ''}_${data.lastSyncedAt || ''}`;

        if (snapshotDedupeKey === lastProcessedSnapshotKeyRef.current) {
          return;
        }
        lastProcessedSnapshotKeyRef.current = snapshotDedupeKey;

        setUserProfile((prev) => {
          if (prev && prev.updatedAt === data.updatedAt && prev.lastMutationId === data.lastMutationId) {
            return prev;
          }
          return data;
        });

        // Apply snapshot to local storage ONLY if it is not an echo of our own local mutation and not mid-sync
        if (!hasLocalMutationId(remoteMutationId) && !isCloudSyncInProgress()) {
          applyCloudSnapshotToLocal(uid, data as unknown as Record<string, unknown>);
          setLastSyncedAt(data.lastSyncedAt || Date.now());
          setSyncStatus('synced');
        }
      },
      (error) => {
        console.warn('Firestore profile snapshot error:', error);
      }
    );

    return () => unsubDoc();
  }, [currentUser]);

  // Automatic real-time push to Firestore whenever the user updates Misbaha, Athkar, or Settings locally
  useEffect(() => {
    const scheduleCloudPush = (delayMs: number) => {
      const activeUid = currentUidRef.current;
      saveIsolatedAccountSnapshot(activeUid);

      if (!currentUser || activeUid === 'guest') {
        return;
      }

      if (pushDebounceRef.current) {
        window.clearTimeout(pushDebounceRef.current);
      }

      pushDebounceRef.current = window.setTimeout(() => {
        pushDebounceRef.current = null;
        if (isStorageCloudHydrating() || isCloudSyncInProgress()) return;
        pushUserDataToFirestore(currentUser.uid).then((res) => {
          if (res.success) {
            setSyncStatus('synced');
            setLastSyncedAt(res.syncedAt);
          }
        });
      }, delayMs);
    };

    const handleLocalMutation = (e: Event) => {
      if (isStorageCloudHydrating() || isCloudSyncInProgress()) return;
      const customEv = e as CustomEvent<{ domain?: string; immediate?: boolean }>;
      const isImmediate =
        customEv.detail?.immediate || customEv.detail?.domain === 'settings';
      scheduleCloudPush(isImmediate ? 250 : 500);
    };

    window.addEventListener('rifq-local-data-mutated', handleLocalMutation);

    return () => {
      if (pushDebounceRef.current) {
        window.clearTimeout(pushDebounceRef.current);
      }
      window.removeEventListener('rifq-local-data-mutated', handleLocalMutation);
    };
  }, [currentUser]);

  const openAuthModal = (mode: AuthModalMode = 'login') => {
    clearAuthError();
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const logout = async () => {
    try {
      if (currentUser) {
        // Flush latest user data to Firestore & isolated local snapshot before signing out
        saveIsolatedAccountSnapshot(currentUser.uid);
        await pushUserDataToFirestore(currentUser.uid);
      }
      await signOutNativeGoogleAccount();
      await signOut(auth);
    } catch (e) {
      console.warn('Error during signOut:', e);
    } finally {
      switchActiveUserStorageContext('guest');
      setCurrentUser(null);
      setUserProfile(null);
      setIsAdmin(false);
      setAdminChecking(false);
      setSyncStatus('idle');
      setLastSyncedAt(Date.now());
      clearAuthError();
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        adminChecking,
        loading,
        isAuthModalOpen,
        authModalMode,
        syncStatus,
        lastSyncedAt,
        authError,
        setAuthError,
        clearAuthError,
        openAuthModal,
        closeAuthModal,
        refreshUserProfile,
        verifyAdminNow,
        triggerCloudSync,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
}
