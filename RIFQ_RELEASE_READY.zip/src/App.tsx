import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { SidebarDrawer } from './components/SidebarDrawer';
import { SplashScreen } from './components/SplashScreen';
import { OnboardingModal } from './components/OnboardingModal';
import { FirstRunAuthModal } from './components/Onboarding/FirstRunAuthModal';
import { PermissionsFlowModal } from './components/Permissions/PermissionsFlowModal';
import { 
  hasCompletedPermissionsFlow, 
  setCompletedPermissionsFlow, 
  resetPermissionsFlowForTesting 
} from './utils/permissionManager';
import { HomeScreen } from './components/Home/HomeScreen';
import { TasbeehCentral } from './components/TasbeehCentral';
import { AthkarExplorer } from './components/AthkarExplorer';
import { WardView } from './components/WardView';
import { HarvestView } from './components/HarvestView';
import { MyJourneyMainView } from './components/Journey/MyJourneyMainView';
import { StatsView } from './components/StatsView';
import { SettingsView } from './components/SettingsView';
import { DailyRemindersView } from './components/Reminders/DailyRemindersView';
import { NotificationModal } from './components/NotificationModal';
import { BottomNav } from './components/BottomNav';
import { QuranMainView } from './components/Quran/QuranMainView';
import { HadithMainView } from './components/Hadith/HadithMainView';
import { ArbainNawawiyaView } from './components/Hadith/ArbainNawawiyaView';
import { initArbainNawawiyaSqliteTables } from './utils/arbainNawawiyaSqlite';
import { QuranAudioView } from './components/Quran/QuranAudioView';
import { initQuranAudioSqliteTables } from './utils/quranAudioSqlite';
import { MuslimWomanView } from './components/MuslimWoman/MuslimWomanView';
import { WuduPrayerMainView } from './components/WuduPrayer/WuduPrayerMainView';
import { AsmaaAllahMainView } from './components/AsmaaAllah/AsmaaAllahMainView';
import { AtharTayyibMainView } from './components/AtharTayyib/AtharTayyibMainView';
import { checkAndFireAtharTayyibReminders } from './utils/atharTayyibStorage';
import { AmanaMainView } from './components/Amana/AmanaMainView';
import { checkAndFireAmanaReminders } from './utils/amanaStorage';
import { PrayerTimesMainView } from './components/Prayers/PrayerTimesMainView';
import { MomentDhikrScreen } from './components/MomentDhikr/MomentDhikrScreen';
import { HisnAlMuslimMainView } from './components/HisnAlMuslim/HisnAlMuslimMainView';
import { WirdMainView } from './components/Wird/WirdMainView';
import { GharibMainView } from './components/GharibQuran/GharibMainView';
import { TajweedTadabburView } from './components/Tajweed/TajweedTadabburView';
import { ZakatMawarithView } from './components/Fiqh/ZakatMawarithView';
import { HijriFastingView } from './components/Fiqh/HijriFastingView';
import { HajjUmrahView } from './components/Fiqh/HajjUmrahView';
import { RuqyahMedicineView } from './components/Fiqh/RuqyahMedicineView';
import { FiqhMuyassarView } from './components/Fiqh/FiqhMuyassarView';
import { CompanionsStoriesView } from './components/Companions/CompanionsStoriesView';
import { PropheticBiographyView } from './components/PropheticBiography/PropheticBiographyView';
import { WasayaView } from './components/Wasaya/WasayaView';
import { KidsStoriesView } from './components/KidsStories/KidsStoriesView';
import { OurHistoryView } from './components/History/OurHistoryView';
import { DuaCornerView } from './components/DuaCorner/DuaCornerView';
import { DeveloperCredits } from './components/DeveloperCredits';
import { DeveloperCreditsView } from './components/DeveloperCreditsView';
import { ProfileView } from './components/Profile/ProfileView';
import { AdminDashboardView } from './components/Admin/AdminDashboardView';
import { UserReportModal } from './components/Reports/UserReportModal';
import {
  subscribeToLiveAdminNotifications,
  fetchGlobalSystemConfig,
  SystemConfigRecord,
} from './utils/adminService';
import { WidgetsMainView } from './components/Widgets/WidgetsMainView';
import { StandaloneWidgetView } from './components/Widgets/StandaloneWidgetView';
import { initNativeWidgetsBridge } from './utils/widgetService';
import {
  initWirdDeepLinkBridge,
  extractWirdInviteCodeFromUrl,
  savePendingWirdInviteCode,
  getPendingWirdInviteCode,
} from './utils/wirdInviteService';
import { AuthModal } from './components/Auth/AuthModal';
import { AppLockGate } from './components/Auth/AppLockGate';
import { AuthProvider, useAuth } from './context/AuthContext';
import { isGoogleAuthRecentlyInFlight } from './utils/firebase';
import { ThemeProvider } from './context/ThemeContext';
import { PostPrayerHarvestPromptModal } from './components/PrayerFocus/PostPrayerHarvestPromptModal';
import { PrayerFocusModeOverlay } from './components/PrayerFocus/PrayerFocusModeOverlay';
import { PostPrayerAthkarModal } from './components/Prayers/PostPrayerAthkarModal';
import { DailyToastNotification } from './components/DailyToastNotification';
import { checkAndTriggerDailyToast } from './utils/dailyAyahHadithToastService';
import {
  loadPendingHarvestPrompt,
  PendingPrayerHarvestPrompt,
  startInAppPrayerMode,
} from './utils/prayerFocusService';

import { ScreenType, UserSettings, DailyRecord, DhikrItem, WardType, NotificationItem, WidgetType, WidgetTheme, WidgetSize, PrayerKey, CompanionCategoryId } from './types';
import { 
  loadSettings, 
  saveSettings, 
  loadHistory, 
  getTodayRecord, 
  recordTasbeehCount, 
  calculateStreaks, 
  loadFavorites, 
  toggleFavorite, 
  loadCustomAthkar, 
  addCustomDhikr, 
  loadNotifications, 
  markNotificationsAsRead, 
  getAllAthkar, 
  getTodayDateString, 
  saveHistory, 
  addNotification,
  initCompanionsSqliteTables,
  initMisbahaSqliteTables
} from './utils/storage';
import { checkAndFireChildAppointmentNotifications } from './utils/childPlantSqlite';
import { 
  initPushNotifications, 
  checkAndFireScheduledReminders,
  checkAndFireQuranAndDailyBenefitNotifications,
  subscribeToNotificationSettings,
  saveUnifiedNotificationSettings,
  hasNotificationFired,
  markNotificationFired,
  triggerPushNotification,
  syncFullNotificationScheduleWithServiceWorker
} from './utils/notifications';
import { checkDueDailyReminders } from './utils/dailyRemindersService';
import { 
  startDhikrNotificationScheduler, 
  stopDhikrNotificationScheduler 
} from './utils/momentDhikrService';
import { updateMisbahaSettingsInSqlite } from './utils/misbahaSqlite';
import { 
  startPrayerScheduler, 
  stopPrayerScheduler 
} from './utils/prayerScheduler';
import { 
  stopAdhanAudio,
  startOrResumeAdhanAudio,
  pauseAdhanAudio,
  subscribeToAdhanPlayer,
  AdhanPlayerState
} from './utils/prayerAudio';
import { Sun, Moon, ArrowLeft, X, VolumeX, Volume2, Play, Pause, Square, Compass } from 'lucide-react';

function MainApp() {
  const { currentUser, userProfile, isAdmin, isAuthModalOpen, closeAuthModal, authModalMode, openAuthModal, lastSyncedAt, logout } = useAuth();

  // First-Run Mandatory Sequence:
  // 【1】Splash Screen (2-3s) -> 【2】Onboarding -> 【3】Auth -> 【4】Permissions -> 【5】Main App
  type FirstRunStep = 'splash' | 'onboarding' | 'auth' | 'permissions' | 'done';
  const [firstRunStep, setFirstRunStep] = useState<FirstRunStep>(() => {
    try {
      if (window.location.pathname === '/admin' || window.location.pathname.startsWith('/admin/')) {
        return 'done';
      }
      const initialInvite = extractWirdInviteCodeFromUrl();
      if (initialInvite) {
        savePendingWirdInviteCode(initialInvite);
        return 'done';
      }
      // Never replay splash/onboarding if returning from Google Sign-In or already shown in this session
      const splashAlreadyShown = sessionStorage.getItem('rifq_splash_shown_session_v1') === '1';
      if (isGoogleAuthRecentlyInFlight() || splashAlreadyShown) {
        const slidesDone =
          localStorage.getItem('rifq_onboarding_completed_v1') === 'true' ||
          localStorage.getItem('rifq_onboarding_slides_done_v1') === 'true' ||
          loadSettings().hasCompletedOnboarding;
        if (slidesDone && hasCompletedPermissionsFlow()) {
          return 'done';
        }
        if (isGoogleAuthRecentlyInFlight()) {
          return hasCompletedPermissionsFlow() ? 'done' : 'permissions';
        }
        if (slidesDone) {
          return hasCompletedPermissionsFlow() ? 'done' : 'permissions';
        }
      }
    } catch {
      // ignore
    }
    return 'splash';
  });

  // Check if URL specifies standalone widget mode (?widget=tasbeeh / ?widget=prayer / ?widget=dhikr / ?widget=multi)
  const [standaloneWidget, setStandaloneWidget] = useState<{
    type: WidgetType;
    theme: WidgetTheme;
    size: WidgetSize;
  } | null>(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const widgetParam = params.get('widget');
      if (widgetParam && ['tasbeeh', 'prayer', 'dhikr', 'multi'].includes(widgetParam)) {
        const theme = (params.get('theme') as WidgetTheme) || 'navy';
        const size = (params.get('size') as WidgetSize) || 'medium';
        return { type: widgetParam as WidgetType, theme, size };
      }
    } catch {
      // ignore
    }
    return null;
  });

  // App Navigation & Modals
  const [currentScreen, setCurrentScreen] = useState<ScreenType>(() => {
    try {
      if (window.location.pathname === '/admin' || window.location.pathname.startsWith('/admin/')) {
        return 'admin';
      }
      const params = new URLSearchParams(window.location.search);
      if (params.get('screen') === 'admin') {
        return 'admin';
      }
      const inviteCode = extractWirdInviteCodeFromUrl() || getPendingWirdInviteCode();
      if (inviteCode || params.get('screen') === 'wird') {
        if (inviteCode) savePendingWirdInviteCode(inviteCode);
        return 'wird';
      }
    } catch {
      // ignore
    }
    return 'home';
  });
  const [globalAnnouncement, setGlobalAnnouncement] = useState<SystemConfigRecord | null>(null);
  const [dismissedAnnouncement, setDismissedAnnouncement] = useState<boolean>(false);
  const [isAppealModalOpen, setIsAppealModalOpen] = useState<boolean>(false);
  const [selectedWardType, setSelectedWardType] = useState<WardType>('morning');
  const [selectedMomentDhikrId, setSelectedMomentDhikrId] = useState<string | null>(null);
  const [selectedCompanionId, setSelectedCompanionId] = useState<string | null>(null);
  const [selectedCompanionCategory, setSelectedCompanionCategory] = useState<CompanionCategoryId | 'all' | 'favorites'>('all');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [activeReminderAlert, setActiveReminderAlert] = useState<{
    title: string;
    message: string;
    ward: WardType;
  } | null>(null);
  const [activeAdhanAlert, setActiveAdhanAlert] = useState<{
    prayerKey: PrayerKey;
    prayerNameAr: string;
    cityName: string;
    timeStr: string;
  } | null>(null);
  const [adhanPlayerState, setAdhanPlayerState] = useState<AdhanPlayerState | null>(null);
  const [isGlobalPostAthkarOpen, setIsGlobalPostAthkarOpen] = useState(false);
  const [pendingHarvestPrompt, setPendingHarvestPrompt] = useState<PendingPrayerHarvestPrompt | null>(
    loadPendingHarvestPrompt
  );

  useEffect(() => {
    const handleHarvestPrompt = () => {
      setPendingHarvestPrompt(loadPendingHarvestPrompt());
    };
    window.addEventListener('rifq-prayer-harvest-prompt', handleHarvestPrompt);
    return () => window.removeEventListener('rifq-prayer-harvest-prompt', handleHarvestPrompt);
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToAdhanPlayer((state) => {
      setAdhanPlayerState(state);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  // App persistent states
  const [settings, setSettings] = useState<UserSettings>(loadSettings);
  const [history, setHistory] = useState<Record<string, DailyRecord>>(loadHistory);
  const [favorites, setFavorites] = useState<string[]>(loadFavorites);
  const [customAthkar, setCustomAthkar] = useState<DhikrItem[]>(loadCustomAthkar);
  const [notifications, setNotifications] = useState<NotificationItem[]>(loadNotifications);

  // Reactively reload local states when cloud synchronization or account switching occurs
  useEffect(() => {
    const syncLocalAppState = () => {
      setSettings((prev) => {
        const next = loadSettings();
        return JSON.stringify(prev) === JSON.stringify(next) ? prev : next;
      });
      setHistory((prev) => {
        const next = loadHistory();
        return JSON.stringify(prev) === JSON.stringify(next) ? prev : next;
      });
      setFavorites((prev) => {
        const next = loadFavorites();
        return JSON.stringify(prev) === JSON.stringify(next) ? prev : next;
      });
      setCustomAthkar((prev) => {
        const next = loadCustomAthkar();
        return JSON.stringify(prev) === JSON.stringify(next) ? prev : next;
      });
    };

    if (lastSyncedAt) {
      syncLocalAppState();
    }

    window.addEventListener('rifq-user-data-synced', syncLocalAppState);
    window.addEventListener('rifq-widget-increments-merged', syncLocalAppState);
    return () => {
      window.removeEventListener('rifq-user-data-synced', syncLocalAppState);
      window.removeEventListener('rifq-widget-increments-merged', syncLocalAppState);
    };
  }, [lastSyncedAt]);

  // Today's reactive record
  const todayRecord = useMemo(() => {
    return getTodayRecord(history);
  }, [history]);

  // Streak calculation
  const { currentStreak } = useMemo(() => {
    return calculateStreaks(history);
  }, [history]);

  // Unread notification count
  const unreadCount = useMemo(() => {
    return notifications.filter(n => !n.read).length;
  }, [notifications]);

  // Consolidated Athkar list
  const allAthkarList = useMemo(() => {
    return getAllAthkar(customAthkar);
  }, [customAthkar]);

  // Handle Splash Screen finish based on first-run completion
  const handleSplashFinish = useCallback(() => {
    try {
      sessionStorage.setItem('rifq_splash_shown_session_v1', '1');
    } catch {
      // ignore
    }
    const onboardingDone =
      settings.hasCompletedOnboarding ||
      localStorage.getItem('rifq_onboarding_completed_v1') === 'true' ||
      localStorage.getItem('rifq_onboarding_slides_done_v1') === 'true' ||
      Boolean(currentUser);
    const permissionsDone = hasCompletedPermissionsFlow();

    if (onboardingDone && permissionsDone) {
      setFirstRunStep('done');
    } else if (onboardingDone && !permissionsDone) {
      setFirstRunStep(currentUser ? 'permissions' : 'auth');
    } else {
      setFirstRunStep('onboarding');
    }
  }, [settings.hasCompletedOnboarding, currentUser]);

  // Apply font preference to document body
  useEffect(() => {
    if (settings.themeFont === 'amiri') {
      document.body.classList.add('font-amiri');
      document.body.classList.remove('font-tajawal');
    } else {
      document.body.classList.add('font-tajawal');
      document.body.classList.remove('font-amiri');
    }
  }, [settings.themeFont]);

  // Initialize notifications, 5-daily dhikr scheduler, global prayer Adhan scheduler & service worker message listener
  useEffect(() => {
    initCompanionsSqliteTables();
    initMisbahaSqliteTables();
    initArbainNawawiyaSqliteTables();
    initQuranAudioSqliteTables();
    initPushNotifications();
    initNativeWidgetsBridge();
    startDhikrNotificationScheduler();

    startPrayerScheduler((info) => {
      setNotifications(loadNotifications());
      setActiveAdhanAlert(info);
      if (info.prayerKey !== 'sunrise') {
        startInAppPrayerMode({
          prayerKey: info.prayerKey,
          prayerNameAr: info.prayerNameAr,
          durationMinutes: 45,
        });
      }
    });

    const cleanupWirdDeepLink = initWirdDeepLinkBridge((inviteCode) => {
      if (inviteCode) {
        savePendingWirdInviteCode(inviteCode);
        setFirstRunStep('done');
        setCurrentScreen('wird');
      }
    });

    // Check URL parameters & pathname for direct deep-linking (including /admin and ?wirdJoin=INVITE_CODE)
    try {
      const params = new URLSearchParams(window.location.search);
      const inviteCode = extractWirdInviteCodeFromUrl();
      if (
        window.location.pathname === '/admin' ||
        window.location.pathname.startsWith('/admin/') ||
        params.get('screen') === 'admin'
      ) {
        setCurrentScreen('admin');
      } else if (inviteCode || params.get('screen') === 'wird') {
        if (inviteCode) {
          savePendingWirdInviteCode(inviteCode);
        }
        setFirstRunStep('done');
        setCurrentScreen('wird');
      } else if (params.get('screen') === 'moment_dhikr') {
        const id = params.get('dhikrId');
        if (id) setSelectedMomentDhikrId(id);
        setCurrentScreen('moment_dhikr');
      } else if (params.get('screen') === 'ward') {
        const wardParam = params.get('ward') as WardType | null;
        if (wardParam) setSelectedWardType(wardParam);
        setCurrentScreen('ward');
      } else if (params.get('screen')) {
        setCurrentScreen(params.get('screen') as ScreenType);
      }
    } catch {
      // ignore
    }

    // Load global announcement config from Firestore (/system_config/app_settings)
    fetchGlobalSystemConfig()
      .then((cfg) => {
        if (cfg && cfg.announcementEnabled) {
          setGlobalAnnouncement(cfg);
        }
      })
      .catch(() => {});

    const handleOpenWardEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ wardType: WardType }>;
      if (customEvent.detail && customEvent.detail.wardType) {
        setSelectedWardType(customEvent.detail.wardType);
        setCurrentScreen('ward');
      }
    };

    const handleMomentDhikrEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ dhikrId?: string }>;
      if (customEvent.detail && customEvent.detail.dhikrId) {
        setSelectedMomentDhikrId(customEvent.detail.dhikrId);
      }
      setCurrentScreen('moment_dhikr');
    };

    const handleNavigatePrayersEvent = () => {
      setCurrentScreen('prayers');
    };

    const handleNavigateScreenEvent = (e: Event) => {
      const customEvent = e as CustomEvent<{ screen?: ScreenType; dhikrId?: string }>;
      if (customEvent.detail?.dhikrId) {
        setSelectedMomentDhikrId(customEvent.detail.dhikrId);
      }
      if (customEvent.detail?.screen) {
        setCurrentScreen(customEvent.detail.screen);
      }
    };

    const handleNotificationsUpdatedEvent = () => {
      setNotifications(loadNotifications());
    };

    window.addEventListener('mushaba-navigate-ward', handleOpenWardEvent);
    window.addEventListener('rifq-navigate-moment-dhikr', handleMomentDhikrEvent);
    window.addEventListener('rifq-navigate-prayers', handleNavigatePrayersEvent);
    window.addEventListener('rifq-navigate-screen', handleNavigateScreenEvent);
    window.addEventListener('rifq-notifications-updated', handleNotificationsUpdatedEvent);

    if ('serviceWorker' in navigator) {
      const handleSwMessage = (event: MessageEvent) => {
        if (event.data) {
          if (event.data.type === 'SW_NOTIFICATION_FIRED' && event.data.signatureKey) {
            markNotificationFired(event.data.signatureKey);
            if (event.data.title && event.data.body) {
              const updated = addNotification({
                title: event.data.title,
                message: event.data.body,
                time: 'الآن',
                read: false,
                type: 'reminder',
                actionWard: event.data.ward as WardType | undefined,
                actionScreen: event.data.screen as ScreenType | undefined,
                actionDhikrId: event.data.dhikrId,
                signatureKey: event.data.signatureKey,
              });
              setNotifications(updated);
            }
          } else if (event.data.type === 'NAVIGATE_PRAYERS') {
            setCurrentScreen('prayers');
          } else if (event.data.type === 'NAVIGATE_MOMENT_DHIKR') {
            if (event.data.dhikrId) setSelectedMomentDhikrId(event.data.dhikrId);
            setCurrentScreen('moment_dhikr');
          } else if (event.data.action === 'NAVIGATE_WARD' && event.data.wardType) {
            setSelectedWardType(event.data.wardType as WardType);
            setCurrentScreen('ward');
          } else if (event.data.type === 'NAVIGATE_SCREEN' && event.data.screen) {
            if (event.data.dhikrId) {
              setSelectedMomentDhikrId(event.data.dhikrId);
            }
            setCurrentScreen(event.data.screen as ScreenType);
          } else if (event.data.type === 'ADHAN_CONTROL') {
            if (event.data.command === 'stop') {
              stopAdhanAudio();
            } else if (event.data.command === 'play') {
              startOrResumeAdhanAudio(event.data.prayerNameAr);
              if (event.data.prayerNameAr) {
                setActiveAdhanAlert({
                  prayerKey: 'fajr',
                  prayerNameAr: event.data.prayerNameAr,
                  cityName: event.data.cityName || 'مدينتك',
                  timeStr: event.data.timeStr || 'الآن',
                });
              }
            }
          } else if (event.data.type === 'PRAYER_TIME_ENTERED') {
            if (event.data.signatureKey) {
              markNotificationFired(event.data.signatureKey);
            }
            setActiveAdhanAlert({
              prayerKey: (event.data.prayerKey as PrayerKey) || 'fajr',
              prayerNameAr: event.data.prayerNameAr || 'الصلاة',
              cityName: event.data.cityName || 'مدينتك',
              timeStr: event.data.timeStr || 'الآن',
            });
          }
        }
      };
      navigator.serviceWorker.addEventListener('message', handleSwMessage);

      return () => {
        cleanupWirdDeepLink();
        stopPrayerScheduler();
        stopDhikrNotificationScheduler();
        window.removeEventListener('mushaba-navigate-ward', handleOpenWardEvent);
        window.removeEventListener('rifq-navigate-moment-dhikr', handleMomentDhikrEvent);
        window.removeEventListener('rifq-navigate-prayers', handleNavigatePrayersEvent);
        window.removeEventListener('rifq-navigate-screen', handleNavigateScreenEvent);
        window.removeEventListener('rifq-notifications-updated', handleNotificationsUpdatedEvent);
        navigator.serviceWorker.removeEventListener('message', handleSwMessage);
      };
    }

    return () => {
      cleanupWirdDeepLink();
      stopPrayerScheduler();
      stopDhikrNotificationScheduler();
      window.removeEventListener('mushaba-navigate-ward', handleOpenWardEvent);
      window.removeEventListener('rifq-navigate-moment-dhikr', handleMomentDhikrEvent);
      window.removeEventListener('rifq-navigate-prayers', handleNavigatePrayersEvent);
      window.removeEventListener('rifq-navigate-screen', handleNavigateScreenEvent);
      window.removeEventListener('rifq-notifications-updated', handleNotificationsUpdatedEvent);
    };
  }, []);

  // Keep App.tsx settings state synchronized when unified notification settings change anywhere in the app
  useEffect(() => {
    const unsubscribe = subscribeToNotificationSettings(() => {
      setSettings((prev) => {
        const next = loadSettings();
        return JSON.stringify(prev) === JSON.stringify(next) ? prev : next;
      });
    });
    return () => unsubscribe();
  }, []);

  // Subscribe to real-time Admin Broadcast & Targeted Notifications from Firestore (/admin_notifications)
  useEffect(() => {
    if (!currentUser?.uid) return;
    const unsubAdminNotifs = subscribeToLiveAdminNotifications(currentUser.uid, (notif) => {
      const sigKey = `admin_notif_${notif.id}`;
      if (hasNotificationFired(sigKey)) return;

      // Only fire notifications created within the last 48 hours to avoid spamming old history on fresh device login
      if (notif.createdAt) {
        const createdMs = new Date(notif.createdAt).getTime();
        if (!isNaN(createdMs) && Date.now() - createdMs > 48 * 60 * 60 * 1000) {
          markNotificationFired(sigKey);
          return;
        }
      }

      markNotificationFired(sigKey);
      const updated = addNotification({
        title: notif.title,
        message: notif.message,
        time: 'الآن',
        read: false,
        type: notif.type || 'general',
        actionScreen: notif.actionScreen || undefined,
        actionWard: notif.actionWard || undefined,
        signatureKey: sigKey,
      });
      setNotifications(updated);

      triggerPushNotification({
        title: notif.title,
        message: notif.message,
        tag: sigKey,
        screen: notif.actionScreen || undefined,
        ward: notif.actionWard || undefined,
      }).catch(() => {});
    });

    return () => unsubAdminNotifs();
  }, [currentUser?.uid]);

  // Periodic & precision-timed check for morning, evening, sleep, Quran, Faida, Dua, and custom daily reminders
  useEffect(() => {
    const runReminderCheck = async () => {
      await checkAndFireScheduledReminders(settings, (reminder) => {
        const updated = addNotification({
          title: reminder.title,
          message: reminder.message,
          time: 'الآن',
          read: false,
          type: 'reminder',
          actionWard: reminder.ward,
          actionScreen: 'ward',
          signatureKey: reminder.signatureKey,
        });
        setNotifications(updated);
        setActiveReminderAlert(reminder);
      });

      await checkAndFireQuranAndDailyBenefitNotifications(() => {
        setNotifications(loadNotifications());
      });

      await checkDueDailyReminders((item) => {
        setNotifications(loadNotifications());
        setActiveReminderAlert({
          title: `تذكير يومي: ${item.title}`,
          message: item.dhikrOrDuaText,
          ward: item.linkedWard || 'morning',
        });
      });

      await checkAndFireChildAppointmentNotifications(() => {
        setNotifications(loadNotifications());
      });

      checkAndFireAtharTayyibReminders();
      checkAndFireAmanaReminders();
      checkAndTriggerDailyToast();
    };

    runReminderCheck();
    const interval = setInterval(runReminderCheck, 15000);

    const handlePrecisionWakeup = () => {
      runReminderCheck();
    };
    const handleVisibilityResume = () => {
      if (document.visibilityState === 'visible') {
        runReminderCheck();
      }
    };

    window.addEventListener('rifq-run-scheduled-checks-now', handlePrecisionWakeup);
    window.addEventListener('focus', handlePrecisionWakeup);
    document.addEventListener('visibilitychange', handleVisibilityResume);

    return () => {
      clearInterval(interval);
      window.removeEventListener('rifq-run-scheduled-checks-now', handlePrecisionWakeup);
      window.removeEventListener('focus', handlePrecisionWakeup);
      document.removeEventListener('visibilitychange', handleVisibilityResume);
    };
  }, [settings]);

  const handleUpdateSettings = useCallback((newPartial: Partial<UserSettings>) => {
    setSettings((prev) => {
      const latestFromStorage = loadSettings();
      const updated = { ...prev, ...latestFromStorage, ...newPartial };
      saveSettings(updated);

      if (
        newPartial.morningReminderTime !== undefined ||
        newPartial.eveningReminderTime !== undefined
      ) {
        saveUnifiedNotificationSettings({
          ...(newPartial.morningReminderTime !== undefined
            ? { morningAthkarTime: newPartial.morningReminderTime }
            : {}),
          ...(newPartial.eveningReminderTime !== undefined
            ? { eveningAthkarTime: newPartial.eveningReminderTime }
            : {}),
        });
      } else {
        syncFullNotificationScheduleWithServiceWorker();
      }

      return updated;
    });
  }, []);

  const handleRestartFirstRunFlow = useCallback(() => {
    resetPermissionsFlowForTesting();
    handleUpdateSettings({ hasCompletedOnboarding: false });
    setFirstRunStep('onboarding');
  }, [handleUpdateSettings]);

  const handleIncrement = useCallback((dhikrText: string, amount = 1, isWardCompletion = false) => {
    const res = recordTasbeehCount(dhikrText, amount, isWardCompletion);
    setHistory({ ...res.history });
  }, []);

  const handleDecrement = useCallback(() => {
    setHistory((prev) => {
      const today = getTodayDateString();
      const rec = { ...prev[today] };
      if (rec && rec.totalCount > 0) {
        rec.totalCount = Math.max(0, rec.totalCount - 1);
        const updated = { ...prev, [today]: rec };
        saveHistory(updated);
        return updated;
      }
      return prev;
    });
  }, []);

  const handleResetTodayCounter = useCallback(() => {
    setHistory((prev) => {
      const today = getTodayDateString();
      const rec = { ...prev[today] };
      if (rec) {
        rec.totalCount = 0;
        rec.dhikrCounts = {};
        rec.freeCount = 0;
        rec.hourlyCounts = new Array(24).fill(0);
        const updated = { ...prev, [today]: rec };
        saveHistory(updated);
        return updated;
      }
      return prev;
    });
  }, []);

  const handleToggleFavorite = useCallback((id: string) => {
    const updated = toggleFavorite(id);
    setFavorites([...updated]);
  }, []);

  const handleAddCustom = useCallback((item: { text: string; countTarget: number; source: string; category: DhikrItem['category'] }) => {
    const updated = addCustomDhikr(item);
    setCustomAthkar([...updated]);
  }, []);

  const handleMarkAllNotificationsRead = useCallback(() => {
    const updated = markNotificationsAsRead();
    setNotifications([...updated]);
  }, []);

  const handleResetAllData = useCallback(() => {
    localStorage.clear();
    setSettings(loadSettings());
    setHistory(loadHistory());
    setFavorites([]);
    setCustomAthkar([]);
    setNotifications([]);
    setCurrentScreen('tasbeeh');
  }, []);

  const handleRestoreBackup = useCallback((jsonData: string): boolean => {
    try {
      const parsed = JSON.parse(jsonData);
      if (parsed.settings) {
        saveSettings(parsed.settings);
        setSettings(parsed.settings);
      }
      if (parsed.history) {
        saveHistory(parsed.history);
        setHistory(parsed.history);
      }
      if (parsed.favorites) {
        localStorage.setItem('mushaba_favorites_v1', JSON.stringify(parsed.favorites));
        setFavorites(parsed.favorites);
      }
      if (parsed.customAthkar) {
        localStorage.setItem('mushaba_custom_athkar_v1', JSON.stringify(parsed.customAthkar));
        setCustomAthkar(parsed.customAthkar);
      }
      return true;
    } catch {
      return false;
    }
  }, []);

  const handleSelectWard = (wardType: WardType) => {
    setSelectedWardType(wardType);
    setCurrentScreen('ward');
    setIsNotificationsOpen(false);
  };

  if (standaloneWidget) {
    return (
      <StandaloneWidgetView
        widgetType={standaloneWidget.type}
        theme={standaloneWidget.theme}
        size={standaloneWidget.size}
        onOpenFullApp={() => {
          try {
            window.history.replaceState({}, '', window.location.pathname);
          } catch {
            // ignore
          }
          setStandaloneWidget(null);
        }}
      />
    );
  }

  return (
    <ThemeProvider
      externalSettingsThemeId={settings.themeId}
      externalSettingsThemeMode={settings.themeMode}
      onUpdateUserSettings={handleUpdateSettings}
    >
    <div
      style={{
        backgroundColor: 'var(--theme-background)',
        color: 'var(--theme-text)',
      }}
      className="min-h-screen bg-[#F7F7FC] text-[#25263A] flex flex-col selection:bg-[#5B5FEF]/20 relative font-tajawal antialiased transition-colors duration-250"
    >
      {/* ─── MANDATORY FIRST-RUN ORDER ─── */}
      {/* 【1】Splash Screen (2-3 ثوانٍ) */}
      {firstRunStep === 'splash' && (
        <SplashScreen onFinish={handleSplashFinish} />
      )}

      {/* 【2】Onboarding (شاشات الترحيب) */}
      {firstRunStep === 'onboarding' && (
        <OnboardingModal
          onComplete={() => {
            try {
              localStorage.setItem('rifq_onboarding_slides_done_v1', 'true');
              localStorage.setItem('rifq_onboarding_completed_v1', 'true');
            } catch {
              // ignore
            }
            handleUpdateSettings({ hasCompletedOnboarding: true });
            setFirstRunStep('auth');
          }}
        />
      )}

      {/* 【3】تسجيل الدخول / إنشاء حساب */}
      {firstRunStep === 'auth' && (
        <FirstRunAuthModal
          onComplete={() => {
            try {
              localStorage.setItem('rifq_onboarding_slides_done_v1', 'true');
              localStorage.setItem('rifq_onboarding_completed_v1', 'true');
            } catch {
              // ignore
            }
            handleUpdateSettings({ hasCompletedOnboarding: true });
            setFirstRunStep(hasCompletedPermissionsFlow() ? 'done' : 'permissions');
          }}
          onOpenFullAuth={(mode) => openAuthModal(mode)}
        />
      )}

      {/* 【4】شاشات طلب الأذونات (واحدة تلو الأخرى) */}
      {firstRunStep === 'permissions' && (
        <PermissionsFlowModal
          onComplete={() => {
            try {
              localStorage.setItem('rifq_onboarding_slides_done_v1', 'true');
              localStorage.setItem('rifq_onboarding_completed_v1', 'true');
            } catch {
              // ignore
            }
            handleUpdateSettings({ hasCompletedOnboarding: true });
            setCompletedPermissionsFlow();
            setFirstRunStep('done');
          }}
        />
      )}

      {/* Header Bar */}
      <Navbar
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
        onOpenSidebar={() => setIsSidebarOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadCount={unreadCount}
      />

      {/* Navigation Drawer */}
      <SidebarDrawer
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        currentScreen={currentScreen}
        onSelectScreen={setCurrentScreen}
        onSelectWard={handleSelectWard}
      />

      {/* Global In-App Ward Reminder Toast Banner */}
      {activeReminderAlert && (
        <div className="fixed top-16 right-4 left-4 z-40 max-w-md mx-auto animate-bounce-subtle" dir="rtl">
          <div className="p-4 rounded-2xl bg-white text-[#25263A] shadow-xl border border-[#E6E6F0] flex items-start justify-between gap-3">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] flex items-center justify-center text-[#5B5FEF] shrink-0">
                {activeReminderAlert.ward === 'morning' ? <Sun className="w-5 h-5 text-[#E8B84A]" /> : <Moon className="w-5 h-5 text-[#5B5FEF]" />}
              </div>
              <div className="space-y-1">
                <div className="font-bold text-sm text-[#5B5FEF]">
                  {activeReminderAlert.title}
                </div>
                <div className="text-xs text-[#77798C] leading-relaxed">
                  {activeReminderAlert.message}
                </div>
                <div className="pt-2">
                  <button
                    onClick={() => {
                      handleSelectWard(activeReminderAlert.ward);
                      setActiveReminderAlert(null);
                    }}
                    className="px-3.5 py-1.5 bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
                  >
                    <span>قراءة الورد المبارك الآن</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveReminderAlert(null)}
              className="p-1 rounded-lg hover:bg-[#F7F7FC] text-[#77798C] transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Global Daily Quran Ayah & Prophetic Hadith In-App Toast Notification */}
      <DailyToastNotification />

      {/* Notification Center Modal */}
      <NotificationModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        onMarkAllRead={handleMarkAllNotificationsRead}
        onOpenWard={handleSelectWard}
        onNavigateScreen={(screen, dhikrId) => {
          if (dhikrId) {
            setSelectedMomentDhikrId(dhikrId);
          }
          setCurrentScreen(screen);
          setIsNotificationsOpen(false);
        }}
        onOpenSettings={() => setCurrentScreen('daily_reminders')}
      />

      {/* Real Firebase Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={closeAuthModal}
        initialMode={authModalMode}
      />

      {/* Post-Prayer Focus Harvest Prompt Modal («هل أديت صلاة ...؟») */}
      <PostPrayerHarvestPromptModal
        prompt={pendingHarvestPrompt}
        onClose={() => setPendingHarvestPrompt(null)}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-4 py-5 md:py-8 mb-16">
        {/* Global Admin Announcement Banner (/system_config/app_settings) */}
        {globalAnnouncement &&
          globalAnnouncement.announcementEnabled &&
          !dismissedAnnouncement &&
          (globalAnnouncement.announcementTitle || globalAnnouncement.announcementMessage) && (
            <div
              className={`mb-5 p-4 rounded-2xl border flex items-start justify-between gap-3 animate-fade-in ${
                globalAnnouncement.announcementType === 'warning'
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : globalAnnouncement.announcementType === 'celebration'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-[#EEEEFF] border-[#5B5FEF]/30 text-[#25263A]'
              }`}
              dir="rtl"
            >
              <div className="space-y-1">
                {globalAnnouncement.announcementTitle && (
                  <div className="font-black text-xs sm:text-sm">
                    📢 {globalAnnouncement.announcementTitle}
                  </div>
                )}
                {globalAnnouncement.announcementMessage && (
                  <p className="text-xs leading-relaxed opacity-90">
                    {globalAnnouncement.announcementMessage}
                  </p>
                )}
              </div>
              <button
                type="button"
                onClick={() => setDismissedAnnouncement(true)}
                className="p-1 rounded-lg hover:bg-black/5 text-current cursor-pointer shrink-0"
                aria-label="إغلاق التنبيه"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

        {/* Real Account Suspension / Ban Enforcement Gate */}
        {currentUser &&
        !isAdmin &&
        (userProfile?.accountStatus === 'suspended' || userProfile?.accountStatus === 'banned') ? (
          <div className="max-w-lg mx-auto py-12 px-4 text-center space-y-5 font-tajawal" dir="rtl">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-red-200 shadow-lg space-y-4">
              <div className="w-16 h-16 rounded-3xl bg-red-50 text-[#D95C6A] border border-red-200 flex items-center justify-center mx-auto text-2xl font-black">
                !
              </div>
              <h2 className="text-xl font-black text-[#25263A]">
                {userProfile.accountStatus === 'banned'
                  ? 'تم حظر هذا الحساب من قِبل الإدارة'
                  : 'تم إيقاف هذا الحساب مؤقتاً'}
              </h2>
              <p className="text-xs text-[#77798C] leading-relaxed">
                {userProfile.statusReason
                  ? `السبب المسجل: ${userProfile.statusReason}`
                  : 'تم تقييد صلاحيات هذا الحساب السحابي من قِبل إدارة تطبيق رِفْق.'}
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAppealModalOpen(true)}
                  className="px-5 py-2.5 rounded-2xl bg-[#5B5FEF] text-white text-xs font-black cursor-pointer"
                >
                  تقديم طلب مراجعة للإدارة
                </button>
                <button
                  type="button"
                  onClick={() => logout()}
                  className="px-5 py-2.5 rounded-2xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold cursor-pointer"
                >
                  تسجيل الخروج
                </button>
              </div>
            </div>
            <UserReportModal
              isOpen={isAppealModalOpen}
              onClose={() => setIsAppealModalOpen(false)}
              defaultCategory="account"
            />
          </div>
        ) : (
          <>
        {currentScreen === 'admin' && (
          <AdminDashboardView
            onBack={() => {
              try {
                if (window.location.pathname.startsWith('/admin')) {
                  window.history.replaceState({}, '', '/');
                }
              } catch {
                // ignore
              }
              setCurrentScreen('home');
            }}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'home' && (
          <HomeScreen
            onNavigate={setCurrentScreen}
            onSelectWard={handleSelectWard}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
            onOpenSidebar={() => setIsSidebarOpen(true)}
            unreadCount={unreadCount}
            onOpenMomentDhikr={(dhikrId) => {
              setSelectedMomentDhikrId(dhikrId || null);
              setCurrentScreen('moment_dhikr');
            }}
            onOpenCompanion={(companionId, category) => {
              setSelectedCompanionId(companionId || null);
              setSelectedCompanionCategory(category || 'all');
              setCurrentScreen('companions_stories');
            }}
          />
        )}

        {currentScreen === 'moment_dhikr' && (
          <MomentDhikrScreen
            initialDhikrId={selectedMomentDhikrId}
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'hisn_almuslim' && (
          <HisnAlMuslimMainView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'profile' && (
          <ProfileView
            onNavigate={setCurrentScreen}
            onOpenAuth={() => openAuthModal('login')}
          />
        )}

        {currentScreen === 'tasbeeh' && (
          <TasbeehCentral
            todayRecord={todayRecord}
            settings={settings}
            onIncrement={handleIncrement}
            onDecrement={handleDecrement}
            onResetCounter={handleResetTodayCounter}
            onNavigate={setCurrentScreen}
            currentStreak={currentStreak}
            onUpdateSettings={handleUpdateSettings}
            onOpenSidebar={() => setIsSidebarOpen(true)}
          />
        )}

        {currentScreen === 'daily_reminders' && (
          <DailyRemindersView
            onBack={() => setCurrentScreen('home')}
            onNavigate={setCurrentScreen}
            onOpenWard={handleSelectWard}
            onSelectTasbeehDhikr={(dhikrText, targetCount) => {
              updateMisbahaSettingsInSqlite({
                current_dhikr: dhikrText,
                current_target: targetCount,
              });
              handleUpdateSettings({
                rosaryDhikr: dhikrText,
                rosaryTarget: targetCount,
              });
              setCurrentScreen('tasbeeh');
            }}
          />
        )}

        {currentScreen === 'prayers' && (
          <PrayerTimesMainView
            onBackToTasbih={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'athkar' && (
          <AthkarExplorer
            athkarList={allAthkarList}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onNavigate={setCurrentScreen}
            settings={settings}
            onRecordIncrement={handleIncrement}
          />
        )}

        {currentScreen === 'quran' && (
          <QuranMainView
            onNavigateHome={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'muslim_woman' && (
          <MuslimWomanView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'wudu_prayer' && (
          <WuduPrayerMainView
            onBackToHome={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'athar_tayyib' && (
          <AtharTayyibMainView
            onBackToHome={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'amana' && (
          <AmanaMainView
            onBackToHome={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'asmaa_allah' && (
          <AsmaaAllahMainView
            onBackToHome={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'hadith' && (
          <HadithMainView
            onNavigateHome={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'ward' && (
          <WardView
            initialWardType={selectedWardType}
            customAthkar={customAthkar}
            onAddCustomDhikr={handleAddCustom}
            onNavigate={setCurrentScreen}
            settings={settings}
            onRecordIncrement={handleIncrement}
          />
        )}

        {currentScreen === 'wird' && (
          <WirdMainView
            onSelectWard={handleSelectWard}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'gharib_quran' && (
          <GharibMainView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'tajweed' && (
          <TajweedTadabburView
            initialTab="tajweed"
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'tadabbur' && (
          <TajweedTadabburView
            initialTab="tadabbur"
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'zakat_mawarith' && (
          <ZakatMawarithView
            onBack={() => setCurrentScreen('home')}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'hijri_fasting' && (
          <HijriFastingView
            onBack={() => setCurrentScreen('home')}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'hajj_umrah' && (
          <HajjUmrahView
            onBack={() => setCurrentScreen('home')}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'ruqyah_medicine' && (
          <RuqyahMedicineView
            onBack={() => setCurrentScreen('home')}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'companions_stories' && (
          <CompanionsStoriesView
            initialCompanionId={selectedCompanionId}
            initialCategory={selectedCompanionCategory}
            onBack={() => {
              setSelectedCompanionId(null);
              setCurrentScreen('home');
            }}
          />
        )}

        {currentScreen === 'prophetic_biography' && (
          <PropheticBiographyView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'our_history' && (
          <OurHistoryView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'dua_corner' && (
          <DuaCornerView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'wasaya' && (
          <WasayaView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'kids_stories' && (
          <KidsStoriesView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'fiqh_muyassar' && (
          <FiqhMuyassarView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'arbain_nawawiya' && (
          <ArbainNawawiyaView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'quran_audio' && (
          <QuranAudioView
            onBack={() => setCurrentScreen('home')}
          />
        )}

        {currentScreen === 'harvest' && (
          <HarvestView
            history={history}
            todayRecord={todayRecord}
            settings={settings}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'journey' && (
          <MyJourneyMainView
            onBack={() => setCurrentScreen('home')}
            onNavigate={setCurrentScreen}
            onSelectWard={handleSelectWard}
          />
        )}

        {currentScreen === 'stats' && (
          <StatsView
            history={history}
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'settings' && (
          <SettingsView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onResetAllData={handleResetAllData}
            onNavigate={setCurrentScreen}
            onRestoreBackup={handleRestoreBackup}
            onRestartFirstRunFlow={handleRestartFirstRunFlow}
          />
        )}

        {currentScreen === 'widgets' && (
          <WidgetsMainView
            onNavigate={setCurrentScreen}
          />
        )}

        {currentScreen === 'credits' && (
          <DeveloperCreditsView
            onBack={() => setCurrentScreen('settings')}
            onNavigate={setCurrentScreen}
          />
        )}

        {/* Developer Credits subtle footer on other screens */}
        {currentScreen !== 'settings' && currentScreen !== 'credits' && currentScreen !== 'hadith' && currentScreen !== 'profile' && currentScreen !== 'admin' && (
          <DeveloperCredits 
            compact 
            onOpenFullCredits={() => setCurrentScreen('credits')}
            className="mt-8 mb-2 opacity-80 hover:opacity-100 transition-opacity" 
          />
        )}
          </>
        )}
      </main>

      {/* Live Prayer Adhan Alert Toast with Full Audio Start/Pause/Stop Controls */}
      {activeAdhanAlert && (
        <aside 
          aria-label="تنبيه الأذان الحالي"
          className="fixed top-4 left-3 right-3 max-w-lg mx-auto z-50 bg-white text-[#25263A] p-4 rounded-2xl shadow-xl border border-[#E6E6F0] flex flex-col gap-3 animate-fade-in" 
          dir="rtl"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-[#5B5FEF] shrink-0">
                {adhanPlayerState?.isPlaying ? (
                  <Volume2 className="w-5 h-5 animate-pulse text-[#5B5FEF]" />
                ) : (
                  <Compass className="w-5 h-5 text-[#5B5FEF]" />
                )}
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-black text-[#5B5FEF] flex items-center gap-1.5">
                  <span>حان الآن أذان صلاة {activeAdhanAlert.prayerNameAr} ({activeAdhanAlert.timeStr})</span>
                </h4>
                <p className="text-[11px] text-[#77798C] mt-0.5">
                  بتوقيت {activeAdhanAlert.cityName} • حي على الصلاة، حي على الفلاح
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setActiveAdhanAlert(null)}
              className="p-1.5 rounded-lg hover:bg-[#F7F7FC] text-[#77798C] hover:text-[#25263A] transition-colors cursor-pointer shrink-0"
              title="إغلاق الإشعار"
              aria-label="إغلاق الإشعار"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Dedicated Adhan Audio Controls Bar inside Popup Notification */}
          <div className="flex items-center justify-between gap-2 pt-2.5 border-t border-[#E6E6F0] flex-wrap">
            <div className="flex items-center gap-2">
              {/* Start / Play / Pause Button */}
              {adhanPlayerState?.isPlaying ? (
                <button
                  type="button"
                  onClick={() => pauseAdhanAudio()}
                  className="px-3 py-1.5 rounded-xl bg-[#E8B84A] hover:brightness-95 text-[#25263A] text-xs font-black transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 shadow-xs"
                  title="إيقاف مؤقت لصوت الأذان"
                >
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>إيقاف مؤقت</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => startOrResumeAdhanAudio(activeAdhanAlert.prayerNameAr)}
                  className="px-3.5 py-1.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 shadow-xs"
                  title="بدء تشغيل صوت الأذان"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{adhanPlayerState?.isPaused ? 'متابعة الأذان' : 'بدء الأذان'}</span>
                </button>
              )}

              {/* Stop Adhan Audio Button */}
              <button
                type="button"
                onClick={() => stopAdhanAudio()}
                disabled={!adhanPlayerState?.isPlaying && !adhanPlayerState?.isPaused}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  adhanPlayerState?.isPlaying || adhanPlayerState?.isPaused
                    ? 'bg-[#D95C6A] hover:brightness-95 text-white active:scale-95 shadow-xs'
                    : 'bg-[#F7F7FC] text-[#77798C]/60 cursor-not-allowed'
                }`}
                title="إيقاف صوت الأذان نهائياً"
              >
                <Square className="w-3 h-3 fill-current" />
                <span>إيقاف الأذان</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  if (activeAdhanAlert.prayerKey !== 'sunrise') {
                    startInAppPrayerMode({
                      prayerKey: activeAdhanAlert.prayerKey,
                      prayerNameAr: activeAdhanAlert.prayerNameAr,
                      durationMinutes: 45,
                    });
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                title="تفعيل وضع الصلاة والخشوع وحجب الإشعارات"
              >
                <span>وضع الخشوع 🔕</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveAdhanAlert(null);
                  setCurrentScreen('prayers');
                }}
                className="px-3 py-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#E2E2FF] text-[#4145C7] text-xs font-bold transition-colors cursor-pointer"
              >
                عرض المواقيت
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* Special Prayer & Reverence Mode Overlay (Countdown Timer + Non-Essential Notifications Silence + Post-Prayer Athkar) */}
      <PrayerFocusModeOverlay
        onOpenFullAthkarModal={() => setIsGlobalPostAthkarOpen(true)}
      />

      {/* Global Post-Prayer Athkar Full Modal */}
      <PostPrayerAthkarModal
        isOpen={isGlobalPostAthkarOpen}
        onClose={() => setIsGlobalPostAthkarOpen(false)}
      />

      {/* Bottom Sticky Navigation Bar */}
      <BottomNav
        currentScreen={currentScreen}
        onNavigate={setCurrentScreen}
      />
    </div>
    </ThemeProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppLockGate>
        <MainApp />
      </AppLockGate>
    </AuthProvider>
  );
}
