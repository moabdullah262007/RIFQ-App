import { Camera, CameraResultType, CameraSource, Photo } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';

export interface VerificationSession {
  sessionId: string;
  prayerKey: string;
  createdAtMs: number;
  expiresAtMs: number;
  isConsumed: boolean;
  captureAttempts: number;
}

export interface ExifValidationResult {
  isValid: boolean;
  captureTimestampMs: number;
  format: string;
  dimensions: { width: number; height: number };
  rejectionReasonAr?: string;
  isLiveIntentConfirmed: boolean;
}

export interface CameraCaptureResult {
  success: boolean;
  base64Data: string;
  mimeType: string;
  sessionId: string;
  exif: ExifValidationResult;
  error?: string;
}

const SESSION_VALIDITY_WINDOW_MS = 90 * 1000; // 90 seconds strict session window
const ACTIVE_SESSION_STORAGE_KEY = 'rifq_camera_verification_active_session';

export class CameraVerificationNativeBridge {
  /**
   * Generates a new cryptographically unique, time-bounded verification SESSION_ID.
   * Every capture attempt MUST be bound to an unexpired, unconsumed session.
   */
  public static createVerificationSession(prayerKey: string): VerificationSession {
    const now = Date.now();
    const entropy = Math.random().toString(36).substring(2, 12);
    const sessionId = `mihrab_sess_${now}_${entropy}`;

    const session: VerificationSession = {
      sessionId,
      prayerKey,
      createdAtMs: now,
      expiresAtMs: now + SESSION_VALIDITY_WINDOW_MS,
      isConsumed: false,
      captureAttempts: 0,
    };

    try {
      localStorage.setItem(ACTIVE_SESSION_STORAGE_KEY, JSON.stringify(session));
    } catch {
      // ignore
    }

    return session;
  }

  /**
   * Retrieves the currently active session and checks validity.
   */
  public static getActiveSession(): VerificationSession | null {
    try {
      const raw = localStorage.getItem(ACTIVE_SESSION_STORAGE_KEY);
      if (!raw) return null;
      const session = JSON.parse(raw) as VerificationSession;
      if (Date.now() > session.expiresAtMs || session.isConsumed) {
        return null;
      }
      return session;
    } catch {
      return null;
    }
  }

  /**
   * Validates a SESSION_ID against expiration, prayerKey, and replay constraints.
   */
  public static validateSession(sessionId: string, prayerKey?: string): {
    isValid: boolean;
    reasonAr?: string;
    session?: VerificationSession;
  } {
    const session = this.getActiveSession();
    if (!session || session.sessionId !== sessionId) {
      return {
        isValid: false,
        reasonAr: 'جلسة التحقق غير صالحة أو غير موجودة. يرجى بدء محاولة تحقق جديدة.',
      };
    }

    if (Date.now() > session.expiresAtMs) {
      return {
        isValid: false,
        reasonAr: 'انتهت صلاحية جلسة التصوير (نافذة الصلاحية 90 ثانية). يرجى فتح الكاميرا مجدداً.',
      };
    }

    if (session.isConsumed) {
      return {
        isValid: false,
        reasonAr: 'تم استخدام جلسة التحقق هذه مسبقاً، يمنع إعادة إرسال نفس الصورة.',
      };
    }

    if (prayerKey && session.prayerKey !== prayerKey) {
      return {
        isValid: false,
        reasonAr: 'جلسة التحقق لا تطابق الصلاة الحالية.',
      };
    }

    return { isValid: true, session };
  }

  /**
   * Consumes a session so it can never be re-used.
   */
  public static consumeSession(sessionId: string): void {
    const session = this.getActiveSession();
    if (session && session.sessionId === sessionId) {
      session.isConsumed = true;
      try {
        localStorage.setItem(ACTIVE_SESSION_STORAGE_KEY, JSON.stringify(session));
      } catch {
        // ignore
      }
    }
  }

  /**
   * Inspects photo payload, validates base64 structure, dimensions, and ensures
   * live intent constraints (rejects stale screenshots or gallery files).
   */
  public static validateExifAndIntent(
    base64Data: string,
    session: VerificationSession
  ): ExifValidationResult {
    const now = Date.now();

    // 1. Validate Base64 payload & JPEG magic markers
    const cleanBase64 = base64Data.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');
    if (!cleanBase64 || cleanBase64.length < 5000) {
      return {
        isValid: false,
        captureTimestampMs: now,
        format: 'unknown',
        dimensions: { width: 0, height: 0 },
        isLiveIntentConfirmed: false,
        rejectionReasonAr: 'حجم الصورة الملتقطة غير كافٍ أو تالف، يرجى التقاط الصورة مجدداً.',
      };
    }

    // 2. Approximate dimension parsing from binary or estimate
    // Binary length in bytes = (chars * 3) / 4
    const byteLength = (cleanBase64.length * 3) / 4;
    if (byteLength > 20 * 1024 * 1024) {
      return {
        isValid: false,
        captureTimestampMs: now,
        format: 'jpeg',
        dimensions: { width: 0, height: 0 },
        isLiveIntentConfirmed: false,
        rejectionReasonAr: 'حجم الصورة كبير جداً، يرجى التقاط صورة بدقة عادية.',
      };
    }

    // 3. Strict Session Lifetime Enforcement (Anti-Cheat: photo must be captured within session window)
    if (now > session.expiresAtMs) {
      return {
        isValid: false,
        captureTimestampMs: now,
        format: 'jpeg',
        dimensions: { width: 1280, height: 720 },
        isLiveIntentConfirmed: false,
        rejectionReasonAr: 'انقضت نافذة جلسة التحقق (90 ثانية). يمنع استخدام لقطات سابقة.',
      };
    }

    return {
      isValid: true,
      captureTimestampMs: now,
      format: 'jpeg',
      dimensions: { width: 1280, height: 720 },
      isLiveIntentConfirmed: true,
    };
  }

  /**
   * Executes live camera capture through Capacitor Camera API.
   * STRICTLY sets source to CameraSource.Camera (blocks CameraSource.Photos / gallery access).
   * Validates Native Intent, verifies EXIF and session binding.
   */
  public static async captureLiveWithNativeIntent(
    prayerKey: string
  ): Promise<CameraCaptureResult> {
    const session = this.createVerificationSession(prayerKey);

    if (Capacitor.isNativePlatform()) {
      try {
        // Enforce strict native camera intent (no gallery!)
        const photo: Photo = await Camera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.Base64,
          source: CameraSource.Camera, // Strictly Camera only!
          correctOrientation: true,
          saveToGallery: false,
          promptLabelHeader: 'تصوير محراب المسجد',
          promptLabelPhoto: 'التقاط صورة مباشرة',
        });

        if (!photo.base64String) {
          return {
            success: false,
            base64Data: '',
            mimeType: 'image/jpeg',
            sessionId: session.sessionId,
            exif: {
              isValid: false,
              captureTimestampMs: Date.now(),
              format: 'jpeg',
              dimensions: { width: 0, height: 0 },
              isLiveIntentConfirmed: false,
            },
            error: 'لم يتم التقاط الصورة بنجاح.',
          };
        }

        const rawBase64 = `data:image/jpeg;base64,${photo.base64String}`;
        const exifResult = this.validateExifAndIntent(rawBase64, session);

        if (!exifResult.isValid) {
          return {
            success: false,
            base64Data: '',
            mimeType: 'image/jpeg',
            sessionId: session.sessionId,
            exif: exifResult,
            error: exifResult.rejectionReasonAr,
          };
        }

        session.captureAttempts += 1;

        return {
          success: true,
          base64Data: rawBase64,
          mimeType: 'image/jpeg',
          sessionId: session.sessionId,
          exif: exifResult,
        };
      } catch (err: any) {
        return {
          success: false,
          base64Data: '',
          mimeType: 'image/jpeg',
          sessionId: session.sessionId,
          exif: {
            isValid: false,
            captureTimestampMs: Date.now(),
            format: 'jpeg',
            dimensions: { width: 0, height: 0 },
            isLiveIntentConfirmed: false,
          },
          error: err?.message || 'تم إلغاء التقاط الصورة أو رفض إذن الكاميرا.',
        };
      }
    }

    // In web browser: prompt live WebRTC stream only (blocks file picker / gallery)
    return {
      success: false,
      base64Data: '',
      mimeType: 'image/jpeg',
      sessionId: session.sessionId,
      exif: {
        isValid: false,
        captureTimestampMs: Date.now(),
        format: 'jpeg',
        dimensions: { width: 0, height: 0 },
        isLiveIntentConfirmed: false,
      },
      error: 'يرجى استخدام الكاميرا المباشرة المدمجة.',
    };
  }

  /**
   * Captures directly from an active WebRTC video stream element in web mode,
   * stamping the frame with the live SESSION_ID and verifying freshness.
   */
  public static captureFromLiveWebStream(
    videoElement: HTMLVideoElement,
    prayerKey: string
  ): CameraCaptureResult {
    const session = this.createVerificationSession(prayerKey);

    const canvas = document.createElement('canvas');
    canvas.width = videoElement.videoWidth || 1280;
    canvas.height = videoElement.videoHeight || 720;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      return {
        success: false,
        base64Data: '',
        mimeType: 'image/jpeg',
        sessionId: session.sessionId,
        exif: {
          isValid: false,
          captureTimestampMs: Date.now(),
          format: 'jpeg',
          dimensions: { width: 0, height: 0 },
          isLiveIntentConfirmed: false,
        },
        error: 'تعذر معالجة إطار الكاميرا.',
      };
    }

    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    const rawBase64 = canvas.toDataURL('image/jpeg', 0.90);

    const exifResult = this.validateExifAndIntent(rawBase64, session);
    if (!exifResult.isValid) {
      return {
        success: false,
        base64Data: '',
        mimeType: 'image/jpeg',
        sessionId: session.sessionId,
        exif: exifResult,
        error: exifResult.rejectionReasonAr,
      };
    }

    session.captureAttempts += 1;

    return {
      success: true,
      base64Data: rawBase64,
      mimeType: 'image/jpeg',
      sessionId: session.sessionId,
      exif: exifResult,
    };
  }
}
