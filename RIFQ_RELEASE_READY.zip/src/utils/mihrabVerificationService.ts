import { registerPlugin, Capacitor } from '@capacitor/core';
import { FocusPrayerKey } from './prayerFocusService';
import {
  triggerPushNotification,
  RIFQ_NOTIFICATION_CHANNELS,
  isNotificationChannelEnabled,
} from './notifications';
import { addNotification } from './storage';
import { savePrayerTrackerStatus } from './prayerFocusService';

export const MIHRAB_LOCK_DURATION_MS = 20 * 60 * 1000; // 20 minutes locked
export const MIHRAB_TOTAL_DURATION_MS = 45 * 60 * 1000; // 45 minutes auto-close

export const ACTION_MIHRAB_CAMERA_UNLOCKED = 'org.rifq.app.ACTION_MIHRAB_CAMERA_UNLOCKED';
export const ACTION_MIHRAB_AUTO_EXPIRED = 'org.rifq.app.ACTION_MIHRAB_AUTO_EXPIRED';

export const MIHRAB_SESSION_STORAGE_KEY = 'rifq_mihrab_active_session_v2';

export interface MihrabVerificationSession {
  prayerKey: FocusPrayerKey;
  prayerNameAr: string;
  prayerStartTimeMs: number;
  verificationAvailableAtMs: number;
  verificationDeadlineMs: number;
  isCameraUnlocked: boolean;
  isAutoExpired: boolean;
  isVerified: boolean;
  verifiedAtMs?: number;
  sessionId?: string;
}

export interface MihrabTimingInfo {
  isLocked: boolean;
  isAvailable: boolean;
  isExpired: boolean;
  msUntilAvailable: number;
  msUntilDeadline: number;
  elapsedMinutesSinceAdhan: number;
  lockedCountdownFormatted: string;
  deadlineCountdownFormatted: string;
  progressPercentToUnlock: number;
}

/**
 * Native Capacitor AlarmManager & BroadcastReceiver plugin interface
 * for background persistence and precise Android alarms.
 */
export interface NativeMihrabAlarmBridgePlugin {
  scheduleMihrabAlarms(options: {
    prayerKey: string;
    prayerNameAr: string;
    prayerStartTimeMs: number;
    unlockTimestampMs: number;
    expireTimestampMs: number;
    actionUnlock: string;
    actionExpire: string;
  }): Promise<{ scheduled: boolean; unlockAlarmSet: boolean; expireAlarmSet: boolean }>;

  cancelMihrabAlarms(): Promise<{ cancelled: boolean }>;
  
  getNativeMihrabState(): Promise<{
    isActive: boolean;
    isCameraUnlocked: boolean;
    isAutoExpired: boolean;
    elapsedMs: number;
  }>;
}

let nativeAlarmBridge: NativeMihrabAlarmBridgePlugin | null = null;
if (Capacitor.isPluginAvailable('NativeMihrabAlarmBridge')) {
  nativeAlarmBridge = registerPlugin<NativeMihrabAlarmBridgePlugin>('NativeMihrabAlarmBridge');
}

/**
 * Formats milliseconds into mm:ss
 */
function formatTimeMinSec(ms: number): string {
  const totalSecs = Math.floor(Math.max(0, ms) / 1000);
  const mins = Math.floor(totalSecs / 60);
  const secs = totalSecs % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export class MihrabVerificationService {
  private static tickerTimer: ReturnType<typeof setInterval> | null = null;

  /**
   * Starts a new Mihrab verification lifecycle when a prayer Adhan begins.
   * Stores prayerStartTime, sets unlock at +20m and deadline at +45m,
   * registers AlarmManager alarms, and initializes background monitoring.
   */
  public static startSession(
    prayerKey: FocusPrayerKey,
    prayerNameAr: string,
    startTimeMs: number = Date.now()
  ): MihrabVerificationSession {
    const verificationAvailableAtMs = startTimeMs + MIHRAB_LOCK_DURATION_MS;
    const verificationDeadlineMs = startTimeMs + MIHRAB_TOTAL_DURATION_MS;

    const session: MihrabVerificationSession = {
      prayerKey,
      prayerNameAr,
      prayerStartTimeMs: startTimeMs,
      verificationAvailableAtMs,
      verificationDeadlineMs,
      isCameraUnlocked: false,
      isAutoExpired: false,
      isVerified: false,
    };

    this.saveSession(session);
    this.scheduleAlarms(session);
    this.startBackgroundTicker();

    return session;
  }

  /**
   * Retrieves the current stored Mihrab verification session.
   */
  public static getSession(): MihrabVerificationSession | null {
    try {
      const raw = localStorage.getItem(MIHRAB_SESSION_STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw) as MihrabVerificationSession;
    } catch {
      return null;
    }
  }

  /**
   * Saves the session and broadcasts a change event.
   */
  public static saveSession(session: MihrabVerificationSession | null): void {
    try {
      if (!session) {
        localStorage.removeItem(MIHRAB_SESSION_STORAGE_KEY);
      } else {
        localStorage.setItem(MIHRAB_SESSION_STORAGE_KEY, JSON.stringify(session));
      }
    } catch {
      // ignore
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('rifq-mihrab-session-changed', { detail: session })
      );
    }
  }

  /**
   * Computes strict timing rules:
   * - < 20 min from prayerStartTime: camera verification = LOCKED
   * - 20 to 45 min from prayerStartTime: camera verification = UNLOCKED / AVAILABLE
   * - >= 45 min: AUTO EXPIRED
   */
  public static getTiming(
    session: MihrabVerificationSession | null = this.getSession(),
    currentMs: number = Date.now()
  ): MihrabTimingInfo {
    if (!session) {
      return {
        isLocked: false,
        isAvailable: false,
        isExpired: false,
        msUntilAvailable: 0,
        msUntilDeadline: 0,
        elapsedMinutesSinceAdhan: 0,
        lockedCountdownFormatted: '00:00',
        deadlineCountdownFormatted: '00:00',
        progressPercentToUnlock: 0,
      };
    }

    const prayerStart = session.prayerStartTimeMs;
    const availableAt = session.verificationAvailableAtMs;
    const deadline = session.verificationDeadlineMs;

    const isLocked = currentMs < availableAt;
    const isExpired = currentMs >= deadline;
    const isAvailable = !isLocked && !isExpired && !session.isVerified;

    const msUntilAvailable = Math.max(0, availableAt - currentMs);
    const msUntilDeadline = Math.max(0, deadline - currentMs);
    const elapsedMs = Math.max(0, currentMs - prayerStart);
    const elapsedMinutesSinceAdhan = Math.floor(elapsedMs / 60000);

    const progressPercentToUnlock = Math.min(
      100,
      Math.max(0, Math.round((elapsedMs / MIHRAB_LOCK_DURATION_MS) * 100))
    );

    return {
      isLocked,
      isAvailable,
      isExpired,
      msUntilAvailable,
      msUntilDeadline,
      elapsedMinutesSinceAdhan,
      lockedCountdownFormatted: formatTimeMinSec(msUntilAvailable),
      deadlineCountdownFormatted: formatTimeMinSec(msUntilDeadline),
      progressPercentToUnlock,
    };
  }

  /**
   * Schedules precise alarms via AlarmManager (Capacitor Native bridge)
   * with BroadcastReceiver actions.
   */
  public static async scheduleAlarms(session: MihrabVerificationSession): Promise<void> {
    if (nativeAlarmBridge) {
      try {
        await nativeAlarmBridge.scheduleMihrabAlarms({
          prayerKey: session.prayerKey,
          prayerNameAr: session.prayerNameAr,
          prayerStartTimeMs: session.prayerStartTimeMs,
          unlockTimestampMs: session.verificationAvailableAtMs,
          expireTimestampMs: session.verificationDeadlineMs,
          actionUnlock: ACTION_MIHRAB_CAMERA_UNLOCKED,
          actionExpire: ACTION_MIHRAB_AUTO_EXPIRED,
        });
      } catch (e) {
        console.warn('Native AlarmManager registration:', e);
      }
    }
  }

  /**
   * Background lifecycle evaluation ticker.
   * Dispatches push notifications when camera unlocks (at 20m) and auto-expires (at 45m).
   */
  public static startBackgroundTicker(): void {
    if (this.tickerTimer) return;

    this.tickerTimer = setInterval(() => {
      this.evaluateLifecycle();
    }, 1000);
  }

  public static async evaluateLifecycle(): Promise<void> {
    const session = this.getSession();
    if (!session || session.isVerified) return;

    const now = Date.now();
    const timing = this.getTiming(session, now);

    // 1. Transition: Camera unlocked at 20 min mark
    if (timing.isAvailable && !session.isCameraUnlocked) {
      session.isCameraUnlocked = true;
      this.saveSession(session);

      if (isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.adhan)) {
        await triggerPushNotification({
          title: `محراب المسجد متاح للتصوير الآن 📷 (${session.prayerNameAr})`,
          message: `مضت 20 دقيقة على صلاة ${session.prayerNameAr}. يمكنك الآن فتح الكاميرا وتصوير محراب المسجد لإنهاء وضع الصلاة وتأكيد صلاة الجماعة.`,
          tag: `mihrab-unlock-${session.prayerKey}`,
          screen: 'prayers',
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhan,
        });
      }

      addNotification({
        title: `التحقق بالمحراب متاح الآن 🕌`,
        message: `يمكنك الآن التقاط صورة لمحراب المسجد لصلاة ${session.prayerNameAr} لرفع وضع القفل.`,
        time: 'الآن',
        read: false,
        type: 'reminder',
        actionScreen: 'prayers',
      });
    }

    // 2. Transition: Auto-expired at 45 min mark
    if (timing.isExpired && !session.isAutoExpired) {
      session.isAutoExpired = true;
      this.saveSession(session);

      if (isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.adhan)) {
        await triggerPushNotification({
          title: `انتهى وضع صلاة ${session.prayerNameAr} تلقائياً ⏰`,
          message: `انقضت 45 دقيقة من وقت الأذان وتم إنهاء قفل التطبيقات تلقائياً. تقبل الله طاعتك.`,
          tag: `mihrab-expire-${session.prayerKey}`,
          screen: 'prayers',
          channelId: RIFQ_NOTIFICATION_CHANNELS.adhan,
        });
      }

      addNotification({
        title: `انتهى وضع صلاة ${session.prayerNameAr} ⏰`,
        message: `مرت 45 دقيقة من وقت الأذان وانتهى وضع الصلاة تلقائياً.`,
        time: 'الآن',
        read: false,
        type: 'reminder',
        actionScreen: 'prayers',
      });

      // Clear alarms
      if (nativeAlarmBridge) {
        nativeAlarmBridge.cancelMihrabAlarms().catch(() => {});
      }
    }
  }

  /**
   * Called when verification succeeds via AI Vision.
   */
  public static markVerificationSuccess(details: {
    reasonAr: string;
    confidence: number;
    detectedFeatures: string[];
    sessionId?: string;
  }): void {
    const session = this.getSession();
    if (!session) return;

    session.isVerified = true;
    session.verifiedAtMs = Date.now();
    session.sessionId = details.sessionId;
    this.saveSession(session);

    const todayStr = new Date().toISOString().split('T')[0];
    savePrayerTrackerStatus(todayStr, session.prayerKey, 'mosque');

    if (nativeAlarmBridge) {
      nativeAlarmBridge.cancelMihrabAlarms().catch(() => {});
    }
  }
}
