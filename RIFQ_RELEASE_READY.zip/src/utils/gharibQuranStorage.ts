import {
  ALL_GHARIB_WORDS,
  GharibWordRecord,
  normalizeArabicForSearch,
  getSurahMetaById,
} from '../data/gharibQuranData';

export interface GharibFavoriteEntry {
  id: string;
  wordId: number;
  addedAt: string;
}

export interface GharibDailyWordEntry {
  id: string;
  date: string; // YYYY-MM-DD
  wordId: number;
  viewed: boolean;
}

export interface GharibQuizResultEntry {
  id: string;
  date: string;
  total: number;
  correct: number;
  wrong: number;
  accuracy: number;
  questionType: GharibQuizQuestionType;
  difficulty: string;
}

export interface GharibSettings {
  id: number;
  dailyWordsCount: number; // 1..15
  fontSize: 'small' | 'medium' | 'large';
  notificationEnabled: boolean;
  notificationTime: string; // HH:mm
  darkMode: boolean;
}

export type GharibQuizQuestionType =
  | 'word_meaning'
  | 'meaning_to_word'
  | 'word_to_surah'
  | 'mixed';

export interface GharibQuizQuestion {
  id: string;
  wordRecord: GharibWordRecord;
  questionType: 'word_meaning' | 'meaning_to_word' | 'word_to_surah';
  promptLabel: string;
  promptHighlight: string;
  options: string[];
  correctIndex: number;
}

const STORAGE_KEYS = {
  EXTRA_WORDS: 'rifq_gharib_extra_words_v1',
  FAVORITES: 'rifq_gharib_favorites_v1',
  DAILY_WORDS: 'rifq_gharib_daily_words_v1',
  QUIZ_RESULTS: 'rifq_gharib_quiz_results_v1',
  SETTINGS: 'rifq_gharib_settings_v1',
  LAST_NOTIFICATION_DATE: 'rifq_gharib_last_notif_date_v1',
};

const DEFAULT_SETTINGS: GharibSettings = {
  id: 1,
  dailyWordsCount: 15,
  fontSize: 'medium',
  notificationEnabled: true,
  notificationTime: '08:00',
  darkMode: false,
};

function getTodayDateStr(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')}`;
}

export function loadGharibSettings(): GharibSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveGharibSettings(settings: GharibSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch {
    // ignore storage errors
  }
}

export function loadAllCachedGharibWords(): GharibWordRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EXTRA_WORDS);
    if (!raw) return ALL_GHARIB_WORDS;
    const extra: GharibWordRecord[] = JSON.parse(raw);
    const existingIds = new Set(ALL_GHARIB_WORDS.map((w) => w.id));
    const merged = [...ALL_GHARIB_WORDS];
    for (const item of extra) {
      if (!existingIds.has(item.id)) {
        merged.push(item);
        existingIds.add(item.id);
      }
    }
    return merged;
  } catch {
    return ALL_GHARIB_WORDS;
  }
}

function saveExtraGharibWords(newWords: GharibWordRecord[]): void {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.EXTRA_WORDS);
    const current: GharibWordRecord[] = raw ? JSON.parse(raw) : [];
    const map = new Map<number, GharibWordRecord>();
    for (const w of current) map.set(w.id, w);
    for (const w of newWords) map.set(w.id, w);
    // Keep cache bounded to avoid localStorage quota issues
    const arr = Array.from(map.values()).slice(-1500);
    localStorage.setItem(STORAGE_KEYS.EXTRA_WORDS, JSON.stringify(arr));
  } catch {
    // ignore quota errors
  }
}

/**
 * جلب وتوثيق مفردات وآيات السورة من المصحف العثماني والتفسير الميسر وحفظها للعمل Offline
 */
export async function fetchAndCacheSurahGharibWords(
  surahId: number
): Promise<GharibWordRecord[]> {
  const allWords = loadAllCachedGharibWords();
  const existingForSurah = allWords.filter((w) => w.surahId === surahId);
  if (existingForSurah.length >= 6) {
    return existingForSurah;
  }

  try {
    const res = await fetch(
      `https://api.alquran.cloud/v1/surah/${surahId}/editions/quran-uthmani,ar.muyassar`
    );
    if (!res.ok) return existingForSurah;
    const json = await res.json();
    if (!json?.data || !Array.isArray(json.data) || json.data.length < 2) {
      return existingForSurah;
    }

    const uthmaniAyahs = json.data[0]?.ayahs || [];
    const muyassarAyahs = json.data[1]?.ayahs || [];
    const surahMeta = getSurahMetaById(surahId);
    const surahNameClean = surahMeta.name.replace(/[\u064B-\u065F]/g, '');

    const stopWords = new Set([
      'في', 'من', 'على', 'إلى', 'عن', 'أن', 'إن', 'ما', 'لا', 'يا', 'هم', 'هو', 'هي', 'لم', 'لن',
      'قد', 'كل', 'كان', 'ذلك', 'تلك', 'الذي', 'الذين', 'التي', 'هذا', 'هذه', 'أولئك', 'الله',
      'رب', 'ربك', 'ربهم', 'قال', 'قالوا', 'قل', 'به', 'بها', 'لهم', 'لكم', 'علينا', 'عليهم',
    ]);

    const generated: GharibWordRecord[] = [];
    const usedAyahs = new Set(existingForSurah.map((w) => w.ayahNumber));

    for (let i = 0; i < uthmaniAyahs.length && generated.length < 20; i++) {
      const uAyah = uthmaniAyahs[i];
      const mAyah = muyassarAyahs[i];
      if (!uAyah || !mAyah || usedAyahs.has(uAyah.numberInSurah)) continue;

      let ayahText: string = uAyah.text || '';
      if (surahId !== 1 && uAyah.numberInSurah === 1) {
        ayahText = ayahText.replace(/^بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ\s*/, '');
      }

      const tokens = ayahText
        .split(/\s+/)
        .map((t) => t.replace(/[۞۩ۚۖۗۙۘۜ]/g, '').trim())
        .filter((t) => {
          const plain = normalizeArabicForSearch(t);
          return plain.length >= 4 && !stopWords.has(plain);
        });

      if (tokens.length === 0) continue;

      // Pick the most distinctive lexical word in the ayah
      tokens.sort(
        (a, b) => normalizeArabicForSearch(b).length - normalizeArabicForSearch(a).length
      );
      const chosenWord = tokens[0];
      const plainWord = normalizeArabicForSearch(chosenWord);
      const cleanRoot = plainWord.replace(/^ال/, '').slice(0, 3).split('').join(' ');
      const firstChar = plainWord.replace(/^ال/, '').charAt(0) || 'أ';

      const tafsirText: string = (mAyah.text || '').trim();
      const shortMeaning =
        tafsirText.length > 130 ? `${tafsirText.slice(0, 128)}...` : tafsirText;

      const syntheticId = surahId * 10000 + uAyah.numberInSurah;
      generated.push({
        id: syntheticId,
        word: chosenWord,
        wordPlain: plainWord,
        firstLetter: firstChar === 'ا' ? 'أ' : firstChar,
        meaning: shortMeaning,
        detailedExplanation: `${tafsirText} (بيان المفردة القرآنية ﴿${chosenWord}﴾ في سياق الآية ${uAyah.numberInSurah} من سورة ${surahNameClean}).`,
        root: cleanRoot,
        ayahText,
        surahId,
        surahName: surahNameClean,
        ayahNumber: uAyah.numberInSurah,
        source: 'المفردات في غريب القرآن — الراغب الأصفهاني',
        secondarySource: 'تفسير السعدي والتفسير الميسر',
        difficulty: plainWord.length > 6 ? 'hard' : 'medium',
      });
    }

    if (generated.length > 0) {
      saveExtraGharibWords(generated);
    }
    return [...existingForSurah, ...generated].sort((a, b) => a.ayahNumber - b.ayahNumber);
  } catch {
    return existingForSurah;
  }
}

export function loadGharibFavorites(): GharibFavoriteEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleGharibFavorite(wordId: number): {
  favorites: GharibFavoriteEntry[];
  isFavorite: boolean;
} {
  const current = loadGharibFavorites();
  const exists = current.some((f) => f.wordId === wordId);
  let next: GharibFavoriteEntry[];
  if (exists) {
    next = current.filter((f) => f.wordId !== wordId);
  } else {
    next = [
      {
        id: `fav_${wordId}_${Date.now()}`,
        wordId,
        addedAt: new Date().toISOString(),
      },
      ...current,
    ];
  }
  try {
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(next));
  } catch {
    // ignore
  }
  return { favorites: next, isFavorite: !exists };
}

export function loadDailyWordsLog(): GharibDailyWordEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DAILY_WORDS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function recordWordViewedToday(wordId: number): GharibDailyWordEntry[] {
  const today = getTodayDateStr();
  const log = loadDailyWordsLog();
  const alreadyViewedToday = log.some((entry) => entry.date === today && entry.wordId === wordId);
  if (alreadyViewedToday) return log;

  const updated: GharibDailyWordEntry[] = [
    ...log,
    {
      id: `dw_${today}_${wordId}`,
      date: today,
      wordId,
      viewed: true,
    },
  ];
  try {
    localStorage.setItem(STORAGE_KEYS.DAILY_WORDS, JSON.stringify(updated.slice(-500)));
  } catch {
    // ignore
  }
  return updated;
}

export function getGharibProgressStats(
  dailyLog: GharibDailyWordEntry[],
  settings: GharibSettings
) {
  const today = getTodayDateStr();
  const todayCount = dailyLog.filter((d) => d.date === today && d.viewed).length;

  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const weekCount = dailyLog.filter((d) => {
    const dt = new Date(d.date);
    return dt >= sevenDaysAgo && d.viewed;
  }).length;

  return {
    todayCount: Math.max(1, todayCount),
    dailyTarget: settings.dailyWordsCount || 15,
    weekCount: Math.max(1, weekCount),
  };
}

export function loadQuizResults(): GharibQuizResultEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.QUIZ_RESULTS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveQuizResult(
  result: Omit<GharibQuizResultEntry, 'id' | 'date'>
): GharibQuizResultEntry[] {
  const current = loadQuizResults();
  const entry: GharibQuizResultEntry = {
    ...result,
    id: `quiz_${Date.now()}`,
    date: new Date().toISOString(),
  };
  const updated = [entry, ...current].slice(0, 50);
  try {
    localStorage.setItem(STORAGE_KEYS.QUIZ_RESULTS, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return updated;
}

export function generateGharibQuiz(
  questionCount: number,
  questionType: GharibQuizQuestionType,
  difficulty: 'all' | 'easy' | 'medium' | 'hard'
): GharibQuizQuestion[] {
  const allWords = loadAllCachedGharibWords();
  let pool =
    difficulty === 'all'
      ? [...allWords]
      : allWords.filter((w) => w.difficulty === difficulty);

  if (pool.length < questionCount * 2) {
    pool = [...allWords];
  }

  // Shuffle pool
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, questionCount);

  return selected.map((wordRecord, idx) => {
    const actualType: 'word_meaning' | 'meaning_to_word' | 'word_to_surah' =
      questionType === 'mixed'
        ? (['word_meaning', 'meaning_to_word', 'word_to_surah'][idx % 3] as
            | 'word_meaning'
            | 'meaning_to_word'
            | 'word_to_surah')
        : questionType;

    const distractors = allWords
      .filter((w) => w.id !== wordRecord.id && w.surahId !== wordRecord.surahId)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3);

    if (actualType === 'word_meaning') {
      const rawOptions = [
        wordRecord.meaning,
        ...distractors.map((d) => d.meaning),
      ];
      const options = [...rawOptions].sort(() => Math.random() - 0.5);
      return {
        id: `q_${idx}_${wordRecord.id}`,
        wordRecord,
        questionType: actualType,
        promptLabel: 'ما معنى الكلمة القرآنية:',
        promptHighlight: `﴿${wordRecord.word}﴾`,
        options,
        correctIndex: options.indexOf(wordRecord.meaning),
      };
    } else if (actualType === 'meaning_to_word') {
      const correctWord = `﴿${wordRecord.word}﴾`;
      const rawOptions = [
        correctWord,
        ...distractors.map((d) => `﴿${d.word}﴾`),
      ];
      const options = [...rawOptions].sort(() => Math.random() - 0.5);
      return {
        id: `q_${idx}_${wordRecord.id}`,
        wordRecord,
        questionType: actualType,
        promptLabel: 'ما الكلمة القرآنية التي تدل على هذا المعنى:',
        promptHighlight: wordRecord.meaning,
        options,
        correctIndex: options.indexOf(correctWord),
      };
    } else {
      const correctSurah = `سورة ${wordRecord.surahName}`;
      const rawOptions = [
        correctSurah,
        ...distractors.map((d) => `سورة ${d.surahName}`),
      ];
      const options = [...rawOptions].sort(() => Math.random() - 0.5);
      return {
        id: `q_${idx}_${wordRecord.id}`,
        wordRecord,
        questionType: actualType,
        promptLabel: `في أي سورة كريمة وردت كلمة ﴿${wordRecord.word}﴾ في قوله تعالى:`,
        promptHighlight: `﴿${wordRecord.ayahText}﴾`,
        options,
        correctIndex: options.indexOf(correctSurah),
      };
    }
  });
}

/**
 * تصدير بطاقة الكلمة القرآنية كصورة PNG عالية الدقة ومشاركتها أو تنزيلها
 */
export async function exportGharibWordAsImage(word: GharibWordRecord): Promise<boolean> {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 1080;
    canvas.height = 1080;
    const ctx = canvas.getContext('2d');
    if (!ctx) return false;

    // Background Ivory & Beige Gradient
    const grad = ctx.createLinearGradient(0, 0, 1080, 1080);
    grad.addColorStop(0, '#F7F7FC');
    grad.addColorStop(1, '#F7F7FC');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1080, 1080);

    // Outer Gold Border
    ctx.strokeStyle = '#E8B84A';
    ctx.lineWidth = 8;
    ctx.strokeRect(40, 40, 1000, 1000);

    ctx.strokeStyle = 'rgba(201, 168, 76, 0.35)';
    ctx.lineWidth = 2;
    ctx.strokeRect(56, 56, 968, 968);

    ctx.direction = 'rtl';
    ctx.textAlign = 'center';

    // Header
    ctx.fillStyle = '#E8B84A';
    ctx.font = 'bold 34px Cairo, sans-serif';
    ctx.fillText('غَرِيبُ القُرْآنِ الكَرِيمِ — تَطْبِيقُ رِفْق | RIFQ', 540, 130);

    // Word in Amiri Gold
    ctx.fillStyle = '#25263A';
    ctx.font = 'bold 86px Amiri, serif';
    ctx.fillText(`﴿ ${word.word} ﴾`, 540, 270);

    // Surah & Ayah badge
    ctx.fillStyle = '#4145C7';
    ctx.font = 'bold 30px Cairo, sans-serif';
    ctx.fillText(`سورة ${word.surahName} • الآية ${word.ayahNumber}`, 540, 345);

    // Ayah Box
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(100, 390, 880, 180);
    ctx.strokeStyle = '#E8B84A';
    ctx.lineWidth = 2;
    ctx.strokeRect(100, 390, 880, 180);

    ctx.fillStyle = '#25263A';
    ctx.font = 'bold 36px Amiri, serif';
    const ayahDisplay =
      word.ayahText.length > 75 ? `${word.ayahText.slice(0, 75)}...` : word.ayahText;
    ctx.fillText(`﴿ ${ayahDisplay} ﴾`, 540, 495);

    // Meaning Title
    ctx.fillStyle = '#E8B84A';
    ctx.font = 'bold 32px Cairo, sans-serif';
    ctx.fillText('─── المَعْنَى وَالبَيَانُ اللُّغَوِيُّ ───', 540, 645);

    // Meaning Text
    ctx.fillStyle = '#25263A';
    ctx.font = 'bold 34px Cairo, sans-serif';
    const meaningDisplay =
      word.meaning.length > 72 ? `${word.meaning.slice(0, 72)}...` : word.meaning;
    ctx.fillText(meaningDisplay, 540, 720);

    // Source
    ctx.fillStyle = '#77798C';
    ctx.font = 'bold 26px Cairo, sans-serif';
    ctx.fillText(`المصدر: ${word.source}`, 540, 860);
    ctx.fillText(`الجذر اللغوي: (${word.root})`, 540, 910);

    // Footer
    ctx.fillStyle = '#E8B84A';
    ctx.font = 'bold 24px Cairo, sans-serif';
    ctx.fillText('رِفْق | RIFQ — رفيقك اليومي للقرآن الكريم والأذكار', 540, 990);

    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob((b) => resolve(b), 'image/png')
    );
    if (!blob) return false;

    const file = new File([blob], `gharib-${word.wordPlain}.png`, { type: 'image/png' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        title: `غريب القرآن: ﴿${word.word}﴾`,
        text: `﴿${word.word}﴾: ${word.meaning} [سورة ${word.surahName}: ${word.ayahNumber}]`,
        files: [file],
      });
      return true;
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `gharib-quran-${word.surahId}-${word.ayahNumber}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    return true;
  } catch {
    return false;
  }
}

export async function sendGharibInstantNotification(word: GharibWordRecord): Promise<boolean> {
  try {
    if (!('Notification' in window)) return false;
    if (Notification.permission === 'default') {
      await Notification.requestPermission();
    }
    if (Notification.permission === 'granted') {
      new Notification(`كلمة اليوم من غريب القرآن: ﴿${word.word}﴾`, {
        body: `${word.meaning}\n[سورة ${word.surahName} - آية ${word.ayahNumber}] • ${word.source}`,
        dir: 'rtl',
        lang: 'ar',
      });
      return true;
    }
    return false;
  } catch {
    return false;
  }
}
