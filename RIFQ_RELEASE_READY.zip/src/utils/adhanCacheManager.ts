import { MuadhinOption, MUADHIN_OPTIONS } from '../data/prayersData';

const CACHE_NAME = 'rafiq-adhan-audio-v2';
const CACHED_IDS_STORAGE_KEY = 'rafiq_cached_muadhin_ids_v2';

type CacheChangeListener = () => void;
const cacheListeners = new Set<CacheChangeListener>();

export function subscribeToCacheChanges(listener: CacheChangeListener) {
  cacheListeners.add(listener);
  return () => {
    cacheListeners.delete(listener);
  };
}

function notifyCacheListeners() {
  cacheListeners.forEach((fn) => {
    try {
      fn();
    } catch (e) {
      console.error(e);
    }
  });
}

function getStoredCachedIds(): string[] {
  try {
    const raw = localStorage.getItem(CACHED_IDS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function setStoredCachedIds(ids: string[]) {
  try {
    localStorage.setItem(CACHED_IDS_STORAGE_KEY, JSON.stringify(ids));
  } catch {
    // Ignored
  }
}

/**
 * Checks if a Muadhin's audio file is cached locally
 */
export async function isMuadhinCached(muadhinId: string): Promise<boolean> {
  const stored = getStoredCachedIds();
  if (stored.includes(muadhinId)) return true;

  if (typeof window === 'undefined' || !('caches' in window)) {
    return false;
  }

  try {
    const cache = await caches.open(CACHE_NAME);
    const target = MUADHIN_OPTIONS.find((m) => m.id === muadhinId);
    if (!target) return false;

    const match = await cache.match(target.audioUrl);
    if (match) {
      if (!stored.includes(muadhinId)) {
        setStoredCachedIds([...stored, muadhinId]);
      }
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

/**
 * Downloads a Muadhin's MP3 file with progress tracking and caches it offline
 */
export async function downloadMuadhinAudio(
  muadhin: MuadhinOption,
  onProgress?: (percent: number) => void
): Promise<string> {
  const urlsToTry = [muadhin.audioUrl, muadhin.backupAudioUrl].filter(Boolean) as string[];
  let lastError: Error | null = null;

  for (const url of urlsToTry) {
    try {
      if (onProgress) onProgress(5);

      const response = await fetch(url, { mode: 'cors' });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status} when downloading adhan file`);
      }

      const contentLength = response.headers.get('content-length');
      const totalBytes = contentLength ? parseInt(contentLength, 10) : 0;

      let blob: Blob;

      if (response.body && totalBytes > 0) {
        const reader = response.body.getReader();
        const chunks: Uint8Array[] = [];
        let receivedBytes = 0;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) {
            chunks.push(value);
            receivedBytes += value.length;
            const percent = Math.min(99, Math.round((receivedBytes / totalBytes) * 100));
            if (onProgress) onProgress(percent);
          }
        }

        blob = new Blob(chunks, { type: 'audio/mpeg' });
      } else {
        blob = await response.blob();
        if (onProgress) onProgress(90);
      }

      // Store in Cache Storage
      if (typeof window !== 'undefined' && 'caches' in window) {
        const cache = await caches.open(CACHE_NAME);
        const headers = new Headers({
          'Content-Type': 'audio/mpeg',
          'Content-Length': blob.size.toString(),
          'X-Rafiq-Muadhin-Id': muadhin.id
        });
        const cachedResponse = new Response(blob, { headers });
        await cache.put(muadhin.audioUrl, cachedResponse);
      }

      // Track cached ID in local list
      const stored = getStoredCachedIds();
      if (!stored.includes(muadhin.id)) {
        setStoredCachedIds([...stored, muadhin.id]);
      }

      if (onProgress) onProgress(100);
      notifyCacheListeners();

      return URL.createObjectURL(blob);
    } catch (err: unknown) {
      console.warn(`Failed downloading from ${url}:`, err);
      lastError = err instanceof Error ? err : new Error(String(err));
    }
  }

  throw lastError || new Error('تعذر تحميل ملف الأذان. يرجى التحقق من الاتصال بالإنترنت.');
}

/**
 * Deletes a cached Muadhin's audio file from local storage
 */
export async function deleteMuadhinAudio(muadhinId: string): Promise<boolean> {
  const target = MUADHIN_OPTIONS.find((m) => m.id === muadhinId);
  let deleted = false;

  if (target && typeof window !== 'undefined' && 'caches' in window) {
    try {
      const cache = await caches.open(CACHE_NAME);
      const res1 = await cache.delete(target.audioUrl);
      const res2 = target.backupAudioUrl ? await cache.delete(target.backupAudioUrl) : false;
      deleted = res1 || res2;
    } catch (e) {
      console.warn('Failed to delete from cache:', e);
    }
  }

  const stored = getStoredCachedIds();
  setStoredCachedIds(stored.filter((id) => id !== muadhinId));
  notifyCacheListeners();
  return deleted;
}

/**
 * Retrieves a playable audio URL: cached local blob if available, otherwise direct streaming URL
 */
export async function getPlayableAudioUrl(muadhin: MuadhinOption): Promise<string> {
  if (typeof window !== 'undefined' && 'caches' in window) {
    try {
      const cache = await caches.open(CACHE_NAME);
      const match = await cache.match(muadhin.audioUrl);
      if (match) {
        const blob = await match.blob();
        return URL.createObjectURL(blob);
      }
    } catch (e) {
      console.warn('Cache lookup failed, streaming directly:', e);
    }
  }
  return muadhin.audioUrl;
}

/**
 * Retrieves statistics about cached adhan audio files
 */
export async function getCacheStorageStats(): Promise<{ count: number; totalBytes: number }> {
  if (typeof window === 'undefined' || !('caches' in window)) {
    return { count: 0, totalBytes: 0 };
  }

  try {
    const cache = await caches.open(CACHE_NAME);
    const requests = await cache.keys();
    let totalBytes = 0;

    for (const req of requests) {
      const res = await cache.match(req);
      if (res) {
        const blob = await res.blob();
        totalBytes += blob.size;
      }
    }

    return { count: requests.length, totalBytes };
  } catch {
    return { count: 0, totalBytes: 0 };
  }
}

/**
 * Returns array of all currently cached Muadhin IDs
 */
export async function getCachedMuadhinIds(): Promise<string[]> {
  const stored = getStoredCachedIds();
  if (typeof window === 'undefined' || !('caches' in window)) {
    return stored;
  }

  try {
    const cache = await caches.open(CACHE_NAME);
    const requests = await cache.keys();
    const foundIds: string[] = [];

    for (const req of requests) {
      const match = MUADHIN_OPTIONS.find((m) => m.audioUrl === req.url);
      if (match) foundIds.push(match.id);
    }

    const merged = Array.from(new Set([...stored, ...foundIds]));
    setStoredCachedIds(merged);
    return merged;
  } catch {
    return stored;
  }
}
