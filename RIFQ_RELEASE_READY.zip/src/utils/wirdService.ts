import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { getTodayDateString } from './storage';
import { WirdGroupIconId } from '../components/Wird/WirdIcons';

export type WirdPlanType = 'khatma' | 'juz_amma' | 'surah_custom' | 'custom';

export interface QuranSurahOption {
  number: number;
  name: string;
  startPage: number;
  endPage: number;
}

export const QURAN_SURAH_OPTIONS: QuranSurahOption[] = [
  { number: 2, name: 'سورة البقرة', startPage: 2, endPage: 49 },
  { number: 3, name: 'سورة آل عمران', startPage: 50, endPage: 76 },
  { number: 4, name: 'سورة النساء', startPage: 77, endPage: 106 },
  { number: 5, name: 'سورة المائدة', startPage: 106, endPage: 127 },
  { number: 6, name: 'سورة الأنعام', startPage: 128, endPage: 150 },
  { number: 18, name: 'سورة الكهف', startPage: 293, endPage: 304 },
  { number: 36, name: 'سورة يس', startPage: 440, endPage: 445 },
  { number: 56, name: 'سورة الواقعة', startPage: 534, endPage: 537 },
  { number: 67, name: 'سورة الملك', startPage: 562, endPage: 564 },
];

// Standard 604-page Madinah Mushaf Juz boundaries
export const JUZ_START_PAGES: number[] = [
  1, 22, 42, 62, 82, 102, 121, 142, 162, 182,
  201, 222, 242, 262, 282, 302, 322, 342, 362, 382,
  402, 422, 442, 462, 482, 502, 522, 542, 562, 582,
];

export const JUZ_NAMES_AR: string[] = [
  'الجزء الأول', 'الجزء الثاني', 'الجزء الثالث', 'الجزء الرابع', 'الجزء الخامس',
  'الجزء السادس', 'الجزء السابع', 'الجزء الثامن', 'الجزء التاسع', 'الجزء العاشر',
  'الجزء الحادي عشر', 'الجزء الثاني عشر', 'الجزء الثالث عشر', 'الجزء الرابع عشر', 'الجزء الخامس عشر',
  'الجزء السادس عشر', 'الجزء السابع عشر', 'الجزء الثامن عشر', 'الجزء التاسع عشر', 'الجزء العشرون',
  'الجزء الحادي والعشرون', 'الجزء الثاني والعشرون', 'الجزء الثالث والعشرون', 'الجزء الرابع والعشرون', 'الجزء الخامس والعشرون',
  'الجزء السادس والعشرون', 'الجزء السابع والعشرون', 'الجزء الثامن والعشرون', 'الجزء التاسع والعشرون', 'الجزء الثلاثون (عمّ)',
];

// Approximate Surah names by page range in the 604-page Mushaf
export function getSurahNameForPage(page: number): string {
  if (page === 1) return 'سورة الفاتحة';
  if (page <= 49) return 'سورة البقرة';
  if (page <= 76) return 'سورة آل عمران';
  if (page <= 106) return 'سورة النساء';
  if (page <= 127) return 'سورة المائدة';
  if (page <= 150) return 'سورة الأنعام';
  if (page <= 176) return 'سورة الأعراف';
  if (page <= 186) return 'سورة الأنفال';
  if (page <= 207) return 'سورة التوبة';
  if (page <= 221) return 'سورة يونس';
  if (page <= 235) return 'سورة هود';
  if (page <= 248) return 'سورة يوسف';
  if (page <= 254) return 'سورة الرعد';
  if (page <= 261) return 'سورة إبراهيم';
  if (page <= 267) return 'سورة الحجر';
  if (page <= 281) return 'سورة النحل';
  if (page <= 293) return 'سورة الإسراء';
  if (page <= 304) return 'سورة الكهف';
  if (page <= 312) return 'سورة مريم';
  if (page <= 321) return 'سورة طه';
  if (page <= 331) return 'سورة الأنبياء';
  if (page <= 341) return 'سورة الحج';
  if (page <= 349) return 'سورة المؤمنون';
  if (page <= 359) return 'سورة النور';
  if (page <= 366) return 'سورة الفرقان';
  if (page <= 376) return 'سورة الشعراء';
  if (page <= 385) return 'سورة النمل';
  if (page <= 396) return 'سورة القصص';
  if (page <= 404) return 'سورة العنكبوت';
  if (page <= 410) return 'سورة الروم';
  if (page <= 414) return 'سورة لقمان';
  if (page <= 417) return 'سورة السجدة';
  if (page <= 427) return 'سورة الأحزاب';
  if (page <= 434) return 'سورة سبأ';
  if (page <= 440) return 'سورة فاطر';
  if (page <= 445) return 'سورة يس';
  if (page <= 452) return 'سورة الصافات';
  if (page <= 458) return 'سورة ص';
  if (page <= 467) return 'سورة الزمر';
  if (page <= 476) return 'سورة غافر';
  if (page <= 482) return 'سورة فصلت';
  if (page <= 489) return 'سورة الشورى';
  if (page <= 495) return 'سورة الزخرف';
  if (page <= 498) return 'سورة الدخان';
  if (page <= 502) return 'سورة الجاثية';
  if (page <= 506) return 'سورة الأحقاف';
  if (page <= 510) return 'سورة محمد';
  if (page <= 515) return 'سورة الفتح';
  if (page <= 517) return 'سورة الحجرات';
  if (page <= 520) return 'سورة ق';
  if (page <= 523) return 'سورة الذاريات';
  if (page <= 525) return 'سورة الطور';
  if (page <= 528) return 'سورة النجم';
  if (page <= 531) return 'سورة القمر';
  if (page <= 534) return 'سورة الرحمن';
  if (page <= 537) return 'سورة الواقعة';
  if (page <= 541) return 'سورة الحديد';
  if (page <= 561) return 'جزء المجادلة';
  if (page <= 581) return 'جزء تبارك';
  return 'جزء عمّ';
}

export function getJuzForPage(page: number): number {
  for (let i = JUZ_START_PAGES.length - 1; i >= 0; i--) {
    if (page >= JUZ_START_PAGES[i]) {
      return i + 1;
    }
  }
  return 1;
}

export function getJuzPageRange(juzNumber: number): { startPage: number; endPage: number } {
  const idx = Math.max(0, Math.min(29, juzNumber - 1));
  const startPage = JUZ_START_PAGES[idx];
  const endPage = idx === 29 ? 604 : JUZ_START_PAGES[idx + 1] - 1;
  return { startPage, endPage };
}

export type WirdReadingStatus = 'not_started' | 'reading' | 'completed';

export interface WirdMemberDoc {
  userId: string;
  displayName: string;
  avatar?: string;
  joinedAt: string;
  role: 'admin' | 'member';
  isActive: boolean;
  dailyProgress: number; // pages completed today
  completedDaysCount: number;
  currentPage?: number | null;
  readingStatus?: WirdReadingStatus;
  startTime?: string | null;
  lastActivity?: string | null;
  progressPercent?: number;
}

export interface WirdDistributionDoc {
  id: string;
  wirdId?: string;
  groupId?: string;
  userId: string;
  userName: string;
  dayNumber: number;
  partNumber: number;
  surahName: string;
  pageFrom: number;
  pageTo: number;
  startTime?: string | null;
  lastActivity?: string | null;
  currentPage?: number | null;
  highestPageReached?: number;
  visitedPages?: number[];
  progress?: number;
  status?: WirdReadingStatus;
  isCompleted: boolean;
  completedAt: string | null;
}

export interface WirdDailyProgressDoc {
  dayNumber: number;
  date: string;
  completedMembers: number;
  totalMembers: number;
  isFullCompleted: boolean;
}

export interface WirdMessageDoc {
  id: string;
  userId: string;
  userName: string;
  message: string;
  category: 'dua' | 'encouragement' | 'general';
  createdAt: string;
}

export interface WirdActivityLogDoc {
  id: string;
  userId: string;
  userName: string;
  actionType: 'create_group' | 'join_group' | 'complete_wird' | 'redistribute' | 'promote_admin' | 'remove_member' | 'next_day' | 'edit_group';
  details: string;
  createdAt: string;
}

export interface WirdJoinRequestDoc {
  id: string;
  userId: string;
  userName: string;
  userEmail?: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
}

export interface WirdGroupDoc {
  id: string;
  groupName: string;
  groupCode: string;
  inviteCode?: string;
  adminId: string;
  adminName: string;
  adminIds?: string[];
  memberIds?: string[];
  membersCount?: number;
  description: string;
  planType: WirdPlanType;
  customSurahName?: string;
  startPageRange: number;
  endPageRange: number;
  totalPages: number;
  targetDays: number;
  currentDay: number;
  icon: WirdGroupIconId;
  isPublic: boolean;
  joinCode: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  createdAt: string;
  isUserCreatedV3?: boolean;
  // Subcollections hydrated in state
  members: WirdMemberDoc[];
  distribution: WirdDistributionDoc[];
  dailyProgressHistory: WirdDailyProgressDoc[];
  messages: WirdMessageDoc[];
  activityLog: WirdActivityLogDoc[];
  joinRequests: WirdJoinRequestDoc[];
}

const OFFLINE_WIRD_GROUPS_KEY = 'rifq_real_wird_groups_v3_clean';
const LEGACY_WIRD_KEYS = [
  'rifq_real_wird_groups_v2',
  'rifq_wird_groups_v1',
  'rifq_wird_groups',
  'wird_groups',
];

// In-memory cache to guarantee instant state consistency even if localStorage quota is full
let memoryWirdGroups: WirdGroupDoc[] | null = null;

/**
 * Normalize an invite code strictly to uppercase alphanumeric characters without spaces or invisible marks
 */
export function normalizeWirdInviteCode(raw: string | undefined | null): string {
  const input = (raw || '').trim();
  if (!input) return '';
  const urlMatch = input.match(/[?&](?:wirdJoin|joinCode)=([A-Za-z0-9_-]+)/i);
  if (urlMatch && urlMatch[1]) {
    return urlMatch[1].replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  }
  return input.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
}

/**
 * Resolve the effective member userId in a group (handles transitions between
 * 'local_authenticated_reader' and an authenticated Firebase UID without ever
 * impersonating another member in multi-member groups)
 */
export function resolveEffectiveMemberUserId(
  group: Pick<WirdGroupDoc, 'adminId' | 'members' | 'distribution'>,
  userId: string
): string {
  if (!userId) return 'local_authenticated_reader';
  if (group.members.some((m) => m.userId === userId)) {
    return userId;
  }
  if (
    group.members.length === 1 &&
    group.members[0].userId === 'local_authenticated_reader'
  ) {
    return 'local_authenticated_reader';
  }
  return userId;
}

/**
 * Load cached real groups from memory/localStorage (Strictly no mock or demo data)
 */
export function loadCachedWirdGroups(): WirdGroupDoc[] {
  try {
    // Purge any legacy or pre-seeded group keys from localStorage
    for (const oldKey of LEGACY_WIRD_KEYS) {
      if (localStorage.getItem(oldKey) !== null) {
        localStorage.removeItem(oldKey);
      }
    }

    const raw = localStorage.getItem(OFFLINE_WIRD_GROUPS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        const valid = parsed.filter(
          (g) => g && g.isActive !== false && g.isUserCreatedV3 === true
        );
        if (memoryWirdGroups && memoryWirdGroups.length > 0) {
          const map = new Map<string, WirdGroupDoc>();
          valid.forEach((g) => map.set(g.id, g));
          memoryWirdGroups.forEach((g) => {
            if (g && g.isActive !== false && g.isUserCreatedV3 === true) {
              map.set(g.id, g);
            }
          });
          const merged = Array.from(map.values());
          memoryWirdGroups = merged;
          return merged;
        }
        memoryWirdGroups = valid;
        return valid;
      }
    }
  } catch {
    // ignore
  }
  return memoryWirdGroups ? [...memoryWirdGroups] : [];
}

export function saveCachedWirdGroups(groups: WirdGroupDoc[]): void {
  const cleanGroups = groups.filter(
    (g) => g && g.isActive !== false && g.isUserCreatedV3 === true
  );
  memoryWirdGroups = [...cleanGroups];
  try {
    localStorage.setItem(OFFLINE_WIRD_GROUPS_KEY, JSON.stringify(cleanGroups));
  } catch {
    // If localStorage quota is exceeded due to cached Quran pages, evict old page caches and retry
    try {
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith('rifq_quran_page_v3_')) {
          keysToRemove.push(k);
        }
      }
      keysToRemove.forEach((k) => localStorage.removeItem(k));
      localStorage.setItem(OFFLINE_WIRD_GROUPS_KEY, JSON.stringify(cleanGroups));
    } catch {
      // memoryWirdGroups still holds the authoritative state
    }
  }
}

export function generateUniqueJoinCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

/**
 * Generate a 6-character uppercase invite code and verify in Firestore that no active group uses it
 */
export async function generateVerifiedUniqueInviteCode(): Promise<string> {
  for (let attempt = 0; attempt < 6; attempt++) {
    const candidate = generateUniqueJoinCode();
    try {
      const [byInvite, byJoin] = await Promise.all([
        getDocs(query(collection(db, 'groups'), where('inviteCode', '==', candidate), limit(1))),
        getDocs(query(collection(db, 'groups'), where('joinCode', '==', candidate), limit(1))),
      ]);
      if (byInvite.empty && byJoin.empty) {
        return candidate;
      }
    } catch {
      return candidate;
    }
  }
  return generateUniqueJoinCode();
}

export function getPlanLabel(planType: WirdPlanType, customSurahName?: string): string {
  switch (planType) {
    case 'khatma':
      return 'ختمة كاملة (30 جزء)';
    case 'juz_amma':
      return 'جزء عم (الجزء 30)';
    case 'surah_custom':
      return customSurahName ? `سور محددة (${customSurahName})` : 'سور محددة';
    case 'custom':
      return 'خطة مخصصة';
  }
}

/**
 * Calculate equal page/part distribution for all active members on the group's currentDay
 * Preserves any active reading session fields (startTime, lastActivity, currentPage, highestPageReached, progress, status)
 */
export function calculateDistributionForGroup(
  group: Pick<
    WirdGroupDoc,
    'id' | 'startPageRange' | 'endPageRange' | 'totalPages' | 'targetDays' | 'currentDay'
  > & { id?: string },
  activeMembers: WirdMemberDoc[],
  existingDistribution: WirdDistributionDoc[] = []
): WirdDistributionDoc[] {
  if (activeMembers.length === 0) return [];

  const totalPlanPages = Math.max(1, group.endPageRange - group.startPageRange + 1);
  const targetDays = Math.max(1, group.targetDays);
  const currentDay = Math.max(1, Math.min(targetDays, group.currentDay || 1));

  // Proportional, contiguous page allocation across all targetDays
  let dayStartPage: number;
  let dayEndPage: number;

  if (totalPlanPages >= targetDays) {
    const startOffset = Math.floor(((currentDay - 1) * totalPlanPages) / targetDays);
    const endOffset = Math.floor((currentDay * totalPlanPages) / targetDays) - 1;
    dayStartPage = Math.min(group.endPageRange, group.startPageRange + startOffset);
    dayEndPage = Math.min(
      group.endPageRange,
      Math.max(dayStartPage, group.startPageRange + Math.max(startOffset, endOffset))
    );
  } else {
    // When plan has fewer pages than targetDays (e.g. short surah), cycle/distribute cleanly
    const pageOffset = (currentDay - 1) % totalPlanPages;
    dayStartPage = Math.min(group.endPageRange, group.startPageRange + pageOffset);
    dayEndPage = dayStartPage;
  }

  const totalDayPages = Math.max(1, dayEndPage - dayStartPage + 1);
  const memberCount = activeMembers.length;
  const basePagesPerMember = Math.floor(totalDayPages / memberCount);
  const remainder = totalDayPages % memberCount;

  let cursor = dayStartPage;
  const result: WirdDistributionDoc[] = [];

  activeMembers.forEach((member, idx) => {
    const extra = idx < remainder ? 1 : 0;
    const count = Math.max(1, basePagesPerMember + extra);
    const pageFrom = Math.min(dayEndPage, cursor);
    const pageTo = Math.min(dayEndPage, pageFrom + count - 1);
    cursor = Math.min(dayEndPage, pageTo + 1);

    const existing = existingDistribution.find(
      (d) => d.userId === member.userId && d.dayNumber === currentDay
    );

    const partNumber = getJuzForPage(pageFrom);
    const surahName = getSurahNameForPage(pageFrom);
    const wirdId = `${currentDay}_${member.userId}`;
    const isCompleted = existing ? Boolean(existing.isCompleted) : false;
    const prevHighest = existing?.highestPageReached
      ? Math.max(pageFrom, Math.min(pageTo, existing.highestPageReached))
      : 0;
    const prevCurrent = existing?.currentPage
      ? Math.max(pageFrom, Math.min(pageTo, existing.currentPage))
      : null;
    const totalAssigned = Math.max(1, pageTo - pageFrom + 1);
    const pagesRead = isCompleted
      ? totalAssigned
      : prevHighest >= pageFrom
      ? Math.max(1, prevHighest - pageFrom + 1)
      : 0;
    const computedProgress = isCompleted
      ? 100
      : prevHighest >= pageFrom
      ? Math.min(100, Math.round((pagesRead / totalAssigned) * 100))
      : 0;
    const status: WirdReadingStatus = isCompleted
      ? 'completed'
      : existing?.startTime
      ? 'reading'
      : 'not_started';

    result.push({
      id: wirdId,
      wirdId,
      groupId: group.id || existing?.groupId || '',
      userId: member.userId,
      userName: member.displayName,
      dayNumber: currentDay,
      partNumber,
      surahName,
      pageFrom,
      pageTo,
      startTime: existing?.startTime || null,
      lastActivity: existing?.lastActivity || null,
      currentPage: isCompleted ? pageTo : prevCurrent,
      highestPageReached: isCompleted ? pageTo : prevHighest,
      visitedPages: Array.isArray(existing?.visitedPages) ? existing.visitedPages : [],
      progress: computedProgress,
      status,
      isCompleted,
      completedAt: existing ? existing.completedAt : null,
    });
  });

  return result;
}

export async function ensureGroupSyncedInFirestore(group: WirdGroupDoc): Promise<void> {
  await syncGroupToFirestore(group);
}

/**
 * Sync a full WirdGroupDoc and its subcollections to Firestore.
 * Preserves the group's permanent inviteCode / joinCode and writes memberIds, adminIds, and membersCount.
 */
async function syncGroupToFirestore(
  group: WirdGroupDoc,
  options?: { throwOnError?: boolean }
): Promise<void> {
  try {
    const cleanJoinCode = normalizeWirdInviteCode(
      group.inviteCode || group.joinCode || group.groupCode
    );
    const activeMembers = group.members.filter((m) => m.isActive !== false);
    const memberIds = Array.from(new Set(activeMembers.map((m) => m.userId).filter(Boolean)));
    const adminIds = Array.from(
      new Set([
        group.adminId,
        ...activeMembers.filter((m) => m.role === 'admin').map((m) => m.userId),
      ].filter(Boolean))
    );

    const groupRef = doc(db, 'groups', group.id);
    const writeOps: Promise<unknown>[] = [
      setDoc(
        groupRef,
        {
          groupName: group.groupName || '',
          groupCode: cleanJoinCode,
          inviteCode: cleanJoinCode,
          joinCode: cleanJoinCode,
          adminId: group.adminId || '',
          adminName: group.adminName || '',
          adminIds,
          memberIds,
          membersCount: activeMembers.length,
          description: group.description || '',
          planType: group.planType || 'khatma',
          customSurahName: group.customSurahName || '',
          startPageRange: Number(group.startPageRange) || 1,
          endPageRange: Number(group.endPageRange) || 604,
          totalPages: Number(group.totalPages) || 604,
          targetDays: Number(group.targetDays) || 30,
          currentDay: Number(group.currentDay) || 1,
          icon: group.icon || 'mushaf_pen',
          isPublic: group.isPublic !== false,
          startDate: group.startDate || getTodayDateString(),
          endDate: group.endDate || getTodayDateString(),
          isActive: group.isActive !== false,
          createdAt: group.createdAt || new Date().toISOString(),
          isUserCreatedV3: true,
        },
        { merge: true }
      ),
    ];

    // Sync members subcollection in parallel (regular members only write their own doc; admins sync all)
    const callerUid = auth.currentUser?.uid || '';
    const isCallerAdmin =
      !callerUid ||
      group.adminId === callerUid ||
      adminIds.includes(callerUid);

    for (const m of activeMembers) {
      if (!isCallerAdmin && m.userId !== callerUid) {
        continue;
      }
      writeOps.push(
        setDoc(
          doc(db, 'groups', group.id, 'members', m.userId),
          {
            userId: m.userId,
            displayName: m.displayName || '',
            avatar: m.avatar || '',
            joinedAt: m.joinedAt || new Date().toISOString(),
            role: m.role || 'member',
            isActive: m.isActive !== false,
            dailyProgress: Number(m.dailyProgress) || 0,
            completedDaysCount: Number(m.completedDaysCount) || 0,
            currentPage: m.currentPage ?? null,
            readingStatus: m.readingStatus || 'not_started',
            startTime: m.startTime || null,
            lastActivity: m.lastActivity || null,
            progressPercent: Number(m.progressPercent) || 0,
          },
          { merge: true }
        )
      );
    }

    // Sync current & recent day distributions in parallel
    for (const d of group.distribution) {
      if (d.dayNumber === group.currentDay || d.dayNumber === group.currentDay - 1) {
        const distStatus: WirdReadingStatus = d.isCompleted
          ? 'completed'
          : d.status === 'reading' || d.startTime
          ? 'reading'
          : 'not_started';
        writeOps.push(
          setDoc(
            doc(db, 'groups', group.id, 'distribution', d.id),
            {
              id: d.id,
              wirdId: d.wirdId || d.id,
              groupId: group.id,
              userId: d.userId,
              userName: d.userName || '',
              dayNumber: Number(d.dayNumber) || 1,
              partNumber: Number(d.partNumber) || 1,
              surahName: d.surahName || 'سورة الفاتحة',
              pageFrom: Number(d.pageFrom) || 1,
              pageTo: Number(d.pageTo) || 1,
              startTime: d.startTime || null,
              lastActivity: d.lastActivity || null,
              currentPage: d.currentPage ?? null,
              highestPageReached: Number(d.highestPageReached) || 0,
              visitedPages: Array.isArray(d.visitedPages) ? d.visitedPages.slice(0, 604) : [],
              progress: d.isCompleted ? 100 : Number(d.progress) || 0,
              status: distStatus,
              isCompleted: Boolean(d.isCompleted),
              completedAt: d.completedAt || null,
            },
            { merge: true }
          )
        );
      }
    }

    // Sync dailyProgress subcollection in parallel
    for (const dp of group.dailyProgressHistory) {
      writeOps.push(
        setDoc(
          doc(db, 'groups', group.id, 'dailyProgress', `day_${dp.dayNumber}`),
          {
            dayNumber: Number(dp.dayNumber) || 1,
            date: dp.date || getTodayDateString(),
            completedMembers: Number(dp.completedMembers) || 0,
            totalMembers: Number(dp.totalMembers) || 1,
            isFullCompleted: Boolean(dp.isFullCompleted),
          },
          { merge: true }
        )
      );
    }

    // Sync latest activity log item if present
    if (group.activityLog.length > 0) {
      const latestLog = group.activityLog[0];
      writeOps.push(
        setDoc(doc(db, 'groups', group.id, 'activityLog', latestLog.id), {
          id: latestLog.id,
          userId: latestLog.userId || '',
          userName: latestLog.userName || '',
          actionType: latestLog.actionType,
          details: latestLog.details || '',
          createdAt: latestLog.createdAt || new Date().toISOString(),
        })
      );
    }

    if (options?.throwOnError) {
      await Promise.all(writeOps);
    } else {
      await Promise.allSettled(writeOps);
    }
  } catch (err) {
    if (options?.throwOnError) {
      throw err;
    }
  }
}

/**
 * Hydrate a single Firestore group document with all its subcollections
 */
async function hydrateFirestoreGroupDoc(
  groupId: string,
  data: Record<string, any>
): Promise<WirdGroupDoc> {
  const [membersSnap, distSnap, progSnap, msgSnap, logSnap, reqSnap] = await Promise.all([
    getDocs(collection(db, 'groups', groupId, 'members')),
    getDocs(collection(db, 'groups', groupId, 'distribution')),
    getDocs(collection(db, 'groups', groupId, 'dailyProgress')),
    getDocs(collection(db, 'groups', groupId, 'messages')),
    getDocs(collection(db, 'groups', groupId, 'activityLog')),
    getDocs(collection(db, 'groups', groupId, 'joinRequests')),
  ]);

  const members: WirdMemberDoc[] = membersSnap.docs
    .map((d) => d.data() as WirdMemberDoc)
    .filter((m) => m.isActive !== false);

  const distribution: WirdDistributionDoc[] = distSnap.docs.map((d) => {
    const raw = d.data();
    const isCompleted = Boolean(raw.isCompleted || raw.status === 'completed');
    const status: WirdReadingStatus = isCompleted
      ? 'completed'
      : raw.status === 'reading' || raw.startTime
      ? 'reading'
      : 'not_started';
    return {
      id: d.id,
      wirdId: raw.wirdId || d.id,
      groupId,
      userId: raw.userId || '',
      userName: raw.userName || '',
      dayNumber: Number(raw.dayNumber) || 1,
      partNumber: Number(raw.partNumber) || 1,
      surahName: raw.surahName || 'سورة الفاتحة',
      pageFrom: Number(raw.pageFrom) || 1,
      pageTo: Number(raw.pageTo) || 1,
      startTime: raw.startTime || null,
      lastActivity: raw.lastActivity || null,
      currentPage: raw.currentPage ?? null,
      highestPageReached: Number(raw.highestPageReached) || 0,
      visitedPages: Array.isArray(raw.visitedPages) ? raw.visitedPages : [],
      progress: isCompleted ? 100 : Number(raw.progress) || 0,
      status,
      isCompleted,
      completedAt: raw.completedAt || null,
    };
  });

  const dailyProgressHistory: WirdDailyProgressDoc[] = progSnap.docs.map(
    (d) => d.data() as WirdDailyProgressDoc
  );

  const messages: WirdMessageDoc[] = msgSnap.docs
    .map((d) => ({ id: d.id, ...d.data() } as WirdMessageDoc))
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));

  const activityLog: WirdActivityLogDoc[] = logSnap.docs
    .map((d) => ({ id: d.id, ...d.data() } as WirdActivityLogDoc))
    .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));

  const joinRequests: WirdJoinRequestDoc[] = reqSnap.docs
    .map((d) => ({ id: d.id, ...d.data() } as WirdJoinRequestDoc))
    .filter((r) => r.status === 'pending');

  const resolvedCode = normalizeWirdInviteCode(
    data.inviteCode || data.joinCode || data.groupCode || ''
  );

  // Backfill inviteCode / joinCode / memberIds on the group document if missing
  if (
    resolvedCode &&
    (data.inviteCode !== resolvedCode ||
      data.joinCode !== resolvedCode ||
      !Array.isArray(data.memberIds))
  ) {
    const activeIds = members.map((m) => m.userId).filter(Boolean);
    const adminIds = Array.from(
      new Set([
        data.adminId,
        ...members.filter((m) => m.role === 'admin').map((m) => m.userId),
      ].filter(Boolean))
    );
    void setDoc(
      doc(db, 'groups', groupId),
      {
        inviteCode: resolvedCode,
        joinCode: resolvedCode,
        groupCode: resolvedCode,
        memberIds: activeIds,
        adminIds,
        membersCount: activeIds.length,
        isUserCreatedV3: true,
      },
      { merge: true }
    ).catch(() => {});
  }

  return {
    id: groupId,
    groupName: data.groupName || '',
    groupCode: resolvedCode,
    inviteCode: resolvedCode,
    joinCode: resolvedCode,
    adminId: data.adminId || '',
    adminName: data.adminName || '',
    adminIds: Array.isArray(data.adminIds) ? data.adminIds : [data.adminId].filter(Boolean),
    memberIds: members.map((m) => m.userId),
    membersCount: members.length,
    description: data.description || '',
    planType: (data.planType as WirdPlanType) || 'khatma',
    customSurahName: data.customSurahName || '',
    startPageRange: Number(data.startPageRange) || 1,
    endPageRange: Number(data.endPageRange) || 604,
    totalPages: Number(data.totalPages) || 604,
    targetDays: Number(data.targetDays) || 30,
    currentDay: Number(data.currentDay) || 1,
    icon: (data.icon as WirdGroupIconId) || 'mushaf_pen',
    isPublic: data.isPublic !== false,
    startDate: data.startDate || getTodayDateString(),
    endDate: data.endDate || getTodayDateString(),
    isActive: data.isActive !== false,
    createdAt: data.createdAt || new Date().toISOString(),
    isUserCreatedV3: true,
    members,
    distribution,
    dailyProgressHistory,
    messages,
    activityLog,
    joinRequests,
  };
}

/**
 * Fetch all active groups from Firestore and ensure any locally-created groups are synced to Firestore
 */
export async function fetchAllRealWirdGroups(): Promise<WirdGroupDoc[]> {
  const localGroups = loadCachedWirdGroups();
  const currentUid = auth.currentUser?.uid || '';
  const currentName =
    auth.currentUser?.displayName ||
    auth.currentUser?.email?.split('@')[0] ||
    'قارئ رِفْق';

  try {
    const q = query(collection(db, 'groups'), where('isActive', '==', true));
    const snap = await getDocs(q);

    const remoteGroups: WirdGroupDoc[] = [];
    for (const gDoc of snap.docs) {
      const data = gDoc.data();
      if (data.isActive === false) continue;
      const hydrated = await hydrateFirestoreGroupDoc(gDoc.id, data);
      remoteGroups.push(hydrated);
    }

    const mergedMap = new Map<string, WirdGroupDoc>();
    remoteGroups.forEach((g) => mergedMap.set(g.id, g));

    // If any local group was created on this device (e.g. before auth token resolved or while offline)
    // and is not in Firestore yet, migrate its local creator ID to the real UID and push it to Firestore immediately!
    for (const localG of localGroups) {
      const remoteG = mergedMap.get(localG.id);
      if (!remoteG) {
        let migrated = { ...localG };
        if (currentUid) {
          const isCreatorLocal =
            migrated.adminId === 'local_authenticated_reader' ||
            migrated.adminId === currentUid;
          if (isCreatorLocal) {
            migrated = {
              ...migrated,
              adminId: currentUid,
              adminName:
                migrated.adminName && migrated.adminName !== 'قارئ رِفْق'
                  ? migrated.adminName
                  : currentName,
              inviteCode: normalizeWirdInviteCode(migrated.joinCode || migrated.groupCode),
              joinCode: normalizeWirdInviteCode(migrated.joinCode || migrated.groupCode),
              groupCode: normalizeWirdInviteCode(migrated.joinCode || migrated.groupCode),
              members: migrated.members.map((m) =>
                m.userId === 'local_authenticated_reader'
                  ? { ...m, userId: currentUid, displayName: m.displayName || currentName }
                  : m
              ),
              distribution: migrated.distribution.map((d) =>
                d.userId === 'local_authenticated_reader'
                  ? {
                      ...d,
                      id: `${d.dayNumber}_${currentUid}`,
                      wirdId: `${d.dayNumber}_${currentUid}`,
                      userId: currentUid,
                    }
                  : d
              ),
            };
            await syncGroupToFirestore(migrated);
            mergedMap.set(migrated.id, migrated);
          }
        } else {
          mergedMap.set(localG.id, localG);
        }
      }
    }

    const merged = Array.from(mergedMap.values()).filter((g) => g.isActive !== false);
    saveCachedWirdGroups(merged);
    return merged;
  } catch {
    return localGroups;
  }
}

/**
 * Subscribe to real-time updates for a specific Wird group and all its subcollections in Firestore.
 * Immediately notifies admin and members when any member joins, starts reading, flips a page, completes reading, or is removed.
 */
export function subscribeToWirdGroupRealtime(
  groupId: string,
  onUpdate: (group: WirdGroupDoc | null) => void
): () => void {
  if (!groupId) return () => {};

  let isDisposed = false;
  let debounceTimer: number | null = null;

  const triggerHydrate = () => {
    if (isDisposed) return;
    if (debounceTimer !== null) {
      window.clearTimeout(debounceTimer);
    }
    debounceTimer = window.setTimeout(async () => {
      if (isDisposed) return;
      try {
        const gSnap = await getDoc(doc(db, 'groups', groupId));
        if (!gSnap.exists() || gSnap.data()?.isActive === false) {
          onUpdate(null);
          return;
        }
        const hydrated = await hydrateFirestoreGroupDoc(groupId, gSnap.data());
        const cached = loadCachedWirdGroups();
        const idx = cached.findIndex((g) => g.id === groupId);
        if (idx >= 0) {
          cached[idx] = hydrated;
          saveCachedWirdGroups(cached);
        } else {
          saveCachedWirdGroups([hydrated, ...cached]);
        }
        if (!isDisposed) {
          onUpdate(hydrated);
        }
      } catch {
        // ignore transient offline snapshot error
      }
    }, 120);
  };

  const unsubs = [
    onSnapshot(doc(db, 'groups', groupId), triggerHydrate, () => {}),
    onSnapshot(collection(db, 'groups', groupId, 'members'), triggerHydrate, () => {}),
    onSnapshot(collection(db, 'groups', groupId, 'distribution'), triggerHydrate, () => {}),
    onSnapshot(collection(db, 'groups', groupId, 'dailyProgress'), triggerHydrate, () => {}),
    onSnapshot(collection(db, 'groups', groupId, 'messages'), triggerHydrate, () => {}),
    onSnapshot(collection(db, 'groups', groupId, 'activityLog'), triggerHydrate, () => {}),
    onSnapshot(collection(db, 'groups', groupId, 'joinRequests'), triggerHydrate, () => {}),
  ];

  return () => {
    isDisposed = true;
    if (debounceTimer !== null) {
      window.clearTimeout(debounceTimer);
    }
    unsubs.forEach((u) => {
      try {
        u();
      } catch {
        // ignore
      }
    });
  };
}

/**
 * Create a new real group in Firestore with a verified unique inviteCode and automatic part distribution
 */
export async function createRealWirdGroup(params: {
  groupName: string;
  description: string;
  planType: WirdPlanType;
  customSurahName?: string;
  customStartPage?: number;
  customEndPage?: number;
  targetDays: number;
  startDate: string;
  icon: WirdGroupIconId;
  isPublic: boolean;
  adminId: string;
  adminName: string;
  adminAvatar?: string;
}): Promise<WirdGroupDoc> {
  const realAdminUid = auth.currentUser?.uid || params.adminId;
  if (!realAdminUid || realAdminUid === 'local_authenticated_reader') {
    throw new Error('AUTH_REQUIRED');
  }

  let startPageRange = 1;
  let endPageRange = 604;

  if (params.planType === 'khatma') {
    startPageRange = 1;
    endPageRange = 604;
  } else if (params.planType === 'juz_amma') {
    startPageRange = 582;
    endPageRange = 604;
  } else if (params.planType === 'surah_custom') {
    const found = QURAN_SURAH_OPTIONS.find((s) => s.name === params.customSurahName);
    if (found) {
      startPageRange = found.startPage;
      endPageRange = found.endPage;
    }
  } else if (params.planType === 'custom') {
    startPageRange = Math.max(1, Math.min(604, params.customStartPage || 1));
    endPageRange = Math.max(startPageRange, Math.min(604, params.customEndPage || 604));
  }

  const totalPages = endPageRange - startPageRange + 1;
  const targetDays = Math.max(1, params.targetDays || 30);
  const joinCode = await generateVerifiedUniqueInviteCode();
  const nowIso = new Date().toISOString();

  const startObj = new Date(params.startDate || Date.now());
  const endObj = new Date(startObj.getTime() + targetDays * 24 * 60 * 60 * 1000);
  const endDate = endObj.toISOString().split('T')[0];

  const adminMember: WirdMemberDoc = {
    userId: realAdminUid,
    displayName: params.adminName,
    avatar: params.adminAvatar || '',
    joinedAt: nowIso,
    role: 'admin',
    isActive: true,
    dailyProgress: 0,
    completedDaysCount: 0,
    currentPage: null,
    readingStatus: 'not_started',
    startTime: null,
    lastActivity: null,
    progressPercent: 0,
  };

  const groupId = `wird_${Date.now()}_${joinCode.toLowerCase()}`;

  const baseGroup = {
    id: groupId,
    startPageRange,
    endPageRange,
    totalPages,
    targetDays,
    currentDay: 1,
  };

  const distribution = calculateDistributionForGroup(baseGroup, [adminMember]);

  const initialProgress: WirdDailyProgressDoc = {
    dayNumber: 1,
    date: getTodayDateString(),
    completedMembers: 0,
    totalMembers: 1,
    isFullCompleted: false,
  };

  const initialLog: WirdActivityLogDoc = {
    id: `log_${Date.now()}`,
    userId: realAdminUid,
    userName: params.adminName,
    actionType: 'create_group',
    details: `قام ${params.adminName} بإنشاء مجموعة «${params.groupName.trim()}» (${getPlanLabel(
      params.planType,
      params.customSurahName
    )})`,
    createdAt: nowIso,
  };

  const newGroup: WirdGroupDoc = {
    id: groupId,
    groupName: params.groupName.trim(),
    groupCode: joinCode,
    inviteCode: joinCode,
    joinCode,
    adminId: realAdminUid,
    adminName: params.adminName,
    adminIds: [realAdminUid],
    memberIds: [realAdminUid],
    membersCount: 1,
    description: params.description.trim() || getPlanLabel(params.planType, params.customSurahName),
    planType: params.planType,
    customSurahName: params.customSurahName,
    startPageRange,
    endPageRange,
    totalPages,
    targetDays,
    currentDay: 1,
    icon: params.icon,
    isPublic: params.isPublic,
    startDate: params.startDate || getTodayDateString(),
    endDate,
    isActive: true,
    createdAt: nowIso,
    isUserCreatedV3: true,
    members: [adminMember],
    distribution,
    dailyProgressHistory: [initialProgress],
    messages: [],
    activityLog: [initialLog],
    joinRequests: [],
  };

  // Persist to Firestore first so the group and inviteCode are 100% real and queryable by any device/user
  await syncGroupToFirestore(newGroup, { throwOnError: true });

  const currentGroups = loadCachedWirdGroups();
  saveCachedWirdGroups([newGroup, ...currentGroups]);

  return newGroup;
}

/**
 * Redistribute parts equally among all active members in a group
 */
export async function redistributeParts(
  groupId: string,
  actorUserId?: string,
  actorUserName?: string
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === groupId);
  if (idx === -1) return null;

  const group = groups[idx];
  const activeMembers = group.members.filter((m) => m.isActive !== false);
  const newDist = calculateDistributionForGroup(group, activeMembers, group.distribution);
  const otherDaysDist = group.distribution.filter((d) => d.dayNumber !== group.currentDay);

  const completedCount = newDist.filter((d) => d.isCompleted).length;
  const updatedProgressHistory = [...group.dailyProgressHistory];
  const dayProgIdx = updatedProgressHistory.findIndex((p) => p.dayNumber === group.currentDay);
  const dayProg: WirdDailyProgressDoc = {
    dayNumber: group.currentDay,
    date: getTodayDateString(),
    completedMembers: completedCount,
    totalMembers: activeMembers.length,
    isFullCompleted: activeMembers.length > 0 && completedCount === activeMembers.length,
  };
  if (dayProgIdx >= 0) {
    updatedProgressHistory[dayProgIdx] = dayProg;
  } else {
    updatedProgressHistory.push(dayProg);
  }

  const newLogs = [...group.activityLog];
  if (actorUserId && actorUserName) {
    const logItem: WirdActivityLogDoc = {
      id: `log_${Date.now()}`,
      userId: actorUserId,
      userName: actorUserName,
      actionType: 'redistribute',
      details: `تمت إعادة توزيع الأجزاء بالتساوي على ${activeMembers.length} أعضاء لليوم ${group.currentDay}`,
      createdAt: new Date().toISOString(),
    };
    newLogs.unshift(logItem);
    void setDoc(doc(db, 'groups', groupId, 'activityLog', logItem.id), logItem).catch(() => {});
  }

  const updatedGroup: WirdGroupDoc = {
    ...group,
    memberIds: activeMembers.map((m) => m.userId),
    membersCount: activeMembers.length,
    distribution: [...newDist, ...otherDaysDist],
    dailyProgressHistory: updatedProgressHistory,
    activityLog: newLogs,
  };

  groups[idx] = updatedGroup;
  saveCachedWirdGroups(groups);
  await syncGroupToFirestore(updatedGroup);

  return updatedGroup;
}

/**
 * Fetch a real WirdGroupDoc from Firestore by its 6-character inviteCode / joinCode.
 * Searches inviteCode, joinCode, groupCode, and active groups in Firestore with full normalization.
 */
export async function fetchWirdGroupByJoinCode(
  rawCode: string
): Promise<WirdGroupDoc | null> {
  const code = normalizeWirdInviteCode(rawCode);
  if (!code) return null;

  // Ensure any unsynced local groups created on this device are synced to Firestore first
  await fetchAllRealWirdGroups();

  try {
    let matchedDoc = null as (typeof snapInvite.docs)[0] | null;

    // 1. Search by `inviteCode == code`
    const qInviteCode = query(collection(db, 'groups'), where('inviteCode', '==', code));
    const snapInvite = await getDocs(qInviteCode);
    if (!snapInvite.empty) {
      matchedDoc = snapInvite.docs.find((d) => d.data()?.isActive !== false) || null;
    }

    // 2. Search by `joinCode == code`
    if (!matchedDoc) {
      const qJoinCode = query(collection(db, 'groups'), where('joinCode', '==', code));
      const snapJoin = await getDocs(qJoinCode);
      if (!snapJoin.empty) {
        matchedDoc = snapJoin.docs.find((d) => d.data()?.isActive !== false) || null;
      }
    }

    // 3. Search by `groupCode == code`
    if (!matchedDoc) {
      const qGroupCode = query(collection(db, 'groups'), where('groupCode', '==', code));
      const snapGroupCode = await getDocs(qGroupCode);
      if (!snapGroupCode.empty) {
        matchedDoc = snapGroupCode.docs.find((d) => d.data()?.isActive !== false) || null;
      }
    }

    // 4. Fallback scan of active groups in Firestore in case of case/formatting differences or ID suffix
    if (!matchedDoc) {
      const allActiveSnap = await getDocs(
        query(collection(db, 'groups'), where('isActive', '==', true))
      );
      matchedDoc =
        allActiveSnap.docs.find((d) => {
          const data = d.data();
          if (data?.isActive === false) return false;
          const docCode = normalizeWirdInviteCode(
            data.inviteCode || data.joinCode || data.groupCode || ''
          );
          if (docCode === code) return true;
          if (d.id.toUpperCase().endsWith(`_${code}`)) return true;
          return false;
        }) || null;
    }

    if (matchedDoc) {
      return await hydrateFirestoreGroupDoc(matchedDoc.id, matchedDoc.data());
    }
  } catch {
    // Offline fallback below
  }

  return null;
}

/**
 * Join group by invitation code — 100% real Firestore membership implementation:
 * 1. Sanitize code (trim, strip invisible marks, uppercase)
 * 2. Search in Firestore by inviteCode / joinCode
 * 3. If not found in Firestore: return { error: 'كود الدعوة غير صالح' }
 * 4. If already a member in Firestore: return { alreadyMember: true, success: 'أنت عضو بالفعل في هذه المجموعة', group }
 * 5. If public: write membership & updated memberIds/membersCount to Firestore + redistributeParts
 * 6. If private: write joinRequest to Firestore
 */
export async function joinByCode(
  rawCode: string,
  userId: string,
  userName: string,
  userEmail?: string
): Promise<{
  error?: string;
  success?: string;
  group?: WirdGroupDoc;
  pending?: boolean;
  alreadyMember?: boolean;
}> {
  const code = normalizeWirdInviteCode(rawCode);
  if (!code) {
    return { error: 'كود الدعوة غير صالح' };
  }

  const realUid = auth.currentUser?.uid || userId;
  if (!realUid || realUid === 'local_authenticated_reader') {
    return { error: 'يرجى تسجيل الدخول أولاً للانضمام إلى المجموعة.' };
  }

  // 1. Direct query in Firestore by inviteCode / joinCode
  const targetGroup = await fetchWirdGroupByJoinCode(code);

  if (!targetGroup) {
    return { error: 'كود الدعوة غير صالح' };
  }

  // 2. Check if already a member in Firestore
  let isAlreadyMember = targetGroup.members.some(
    (m) => m.userId === realUid && m.isActive !== false
  );
  if (!isAlreadyMember) {
    try {
      const memberDocSnap = await getDoc(
        doc(db, 'groups', targetGroup.id, 'members', realUid)
      );
      if (
        memberDocSnap.exists() &&
        memberDocSnap.data()?.isActive !== false
      ) {
        isAlreadyMember = true;
      }
    } catch {
      // ignore
    }
  }

  if (isAlreadyMember) {
    const localGroups = loadCachedWirdGroups();
    const existingIdx = localGroups.findIndex((g) => g.id === targetGroup.id);
    if (existingIdx >= 0) {
      localGroups[existingIdx] = targetGroup;
      saveCachedWirdGroups(localGroups);
    } else {
      saveCachedWirdGroups([targetGroup, ...localGroups]);
    }
    return {
      success: 'أنت عضو بالفعل في هذه المجموعة',
      alreadyMember: true,
      group: targetGroup,
    };
  }

  const nowIso = new Date().toISOString();

  // 3. If public group -> execute real Firestore membership write + automatic equal redistribution
  if (targetGroup.isPublic) {
    const newMember: WirdMemberDoc = {
      userId: realUid,
      displayName: userName,
      joinedAt: nowIso,
      role: 'member',
      isActive: true,
      dailyProgress: 0,
      completedDaysCount: 0,
      currentPage: null,
      readingStatus: 'not_started',
      startTime: null,
      lastActivity: null,
      progressPercent: 0,
    };

    const joinLog: WirdActivityLogDoc = {
      id: `log_${Date.now()}`,
      userId: realUid,
      userName,
      actionType: 'join_group',
      details: `انضم ${userName} إلى المجموعة بكود الدعوة (${code}) وتمت إعادة توزيع الأجزاء تلقائياً`,
      createdAt: nowIso,
    };

    const updatedMembersList = [...targetGroup.members, newMember];
    const updatedMemberIds = Array.from(
      new Set(updatedMembersList.filter((m) => m.isActive !== false).map((m) => m.userId))
    );

    // Execute real Firestore writes for membership, group member count, and activity log
    try {
      await setDoc(doc(db, 'groups', targetGroup.id, 'members', realUid), newMember);
      await setDoc(
        doc(db, 'groups', targetGroup.id, 'activityLog', joinLog.id),
        joinLog
      );
      await setDoc(
        doc(db, 'groups', targetGroup.id),
        {
          memberIds: updatedMemberIds,
          membersCount: updatedMemberIds.length,
        },
        { merge: true }
      );
    } catch {
      return {
        error: 'تعذر حفظ عضويتك في قاعدة البيانات، يرجى التحقق من الاتصال والمحاولة مرة أخرى.',
      };
    }

    const hydratedGroup: WirdGroupDoc = {
      ...targetGroup,
      isUserCreatedV3: true,
      memberIds: updatedMemberIds,
      membersCount: updatedMemberIds.length,
      members: updatedMembersList,
      activityLog: [joinLog, ...targetGroup.activityLog],
    };

    const localGroups = loadCachedWirdGroups();
    const gIdx = localGroups.findIndex((g) => g.id === targetGroup.id);
    if (gIdx >= 0) {
      localGroups[gIdx] = hydratedGroup;
      saveCachedWirdGroups(localGroups);
    } else {
      saveCachedWirdGroups([hydratedGroup, ...localGroups]);
    }

    const updatedGroup = await redistributeParts(targetGroup.id, realUid, userName);
    return {
      success: 'تم الانضمام للمجموعة بنجاح وإعادة توزيع الأجزاء تلقائياً',
      group: updatedGroup || hydratedGroup,
    };
  } else {
    // 4. If private group -> send real join request to admin in Firestore
    const alreadyRequested = targetGroup.joinRequests.find(
      (r) => r.userId === realUid && r.status === 'pending'
    );
    if (alreadyRequested) {
      return {
        success: 'تم إرسال طلب الانضمام مسبقاً وهو قيد مراجعة المشرف',
        pending: true,
      };
    }

    const reqDoc: WirdJoinRequestDoc = {
      id: `req_${realUid}_${Date.now()}`,
      userId: realUid,
      userName,
      userEmail: userEmail || '',
      status: 'pending',
      requestedAt: nowIso,
    };

    try {
      await setDoc(
        doc(db, 'groups', targetGroup.id, 'joinRequests', reqDoc.id),
        reqDoc
      );
    } catch {
      return {
        error: 'تعذر إرسال طلب الانضمام إلى قاعدة البيانات، يرجى المحاولة مرة أخرى.',
      };
    }

    const localGroups = loadCachedWirdGroups();
    const gIdx = localGroups.findIndex((g) => g.id === targetGroup.id);
    if (gIdx >= 0) {
      localGroups[gIdx].joinRequests.push(reqDoc);
      saveCachedWirdGroups(localGroups);
    } else {
      const hydratedGroup: WirdGroupDoc = {
        ...targetGroup,
        isUserCreatedV3: true,
        joinRequests: [...targetGroup.joinRequests, reqDoc],
      };
      saveCachedWirdGroups([hydratedGroup, ...localGroups]);
    }

    return {
      success: 'تم إرسال طلب الانضمام لمشرف المجموعة الخاصة بنجاح',
      pending: true,
    };
  }
}

/**
 * Evaluate whether a member has genuinely started and reached the end of their assigned Wird today,
 * which is required before enabling the "انتهاء القراءة" button.
 */
export function evaluateMemberReadingCompletionEligibility(
  group: WirdGroupDoc,
  userId: string
): {
  allowed: boolean;
  hasStarted: boolean;
  isCompleted: boolean;
  pageFrom: number;
  pageTo: number;
  currentPageReached: number;
  progressPercent: number;
  reason: string;
} {
  const effectiveUserId = resolveEffectiveMemberUserId(group, userId);
  const dist = group.distribution.find(
    (d) => d.userId === effectiveUserId && d.dayNumber === group.currentDay
  );
  const member = group.members.find((m) => m.userId === effectiveUserId);

  if (!dist) {
    return {
      allowed: false,
      hasStarted: false,
      isCompleted: false,
      pageFrom: 1,
      pageTo: 1,
      currentPageReached: 0,
      progressPercent: 0,
      reason: 'ابدأ قراءة الورد أولًا حتى تتمكن من إنهاء القراءة.',
    };
  }

  const pageFrom = Math.max(1, dist.pageFrom);
  const pageTo = Math.max(pageFrom, dist.pageTo);
  const totalAssigned = Math.max(1, pageTo - pageFrom + 1);
  const isCompleted = Boolean(dist.isCompleted || dist.status === 'completed');

  if (isCompleted) {
    return {
      allowed: false,
      hasStarted: true,
      isCompleted: true,
      pageFrom,
      pageTo,
      currentPageReached: pageTo,
      progressPercent: 100,
      reason: 'تم إتمام قراءة هذا الورد بالفعل.',
    };
  }

  const hasSessionStart = Boolean(
    (dist.startTime && dist.lastActivity) ||
      (member?.startTime && member?.lastActivity)
  );
  const highestPage = Math.max(
    dist.highestPageReached || 0,
    dist.currentPage || 0,
    member?.currentPage || 0
  );

  if (!hasSessionStart || highestPage < pageFrom) {
    return {
      allowed: false,
      hasStarted: false,
      isCompleted: false,
      pageFrom,
      pageTo,
      currentPageReached: 0,
      progressPercent: 0,
      reason: 'ابدأ قراءة الورد أولًا حتى تتمكن من إنهاء القراءة.',
    };
  }

  const pagesRead = Math.min(totalAssigned, Math.max(1, highestPage - pageFrom + 1));
  const progressPercent = Math.min(
    100,
    Math.round((pagesRead / totalAssigned) * 100)
  );

  if (highestPage < pageTo) {
    return {
      allowed: false,
      hasStarted: true,
      isCompleted: false,
      pageFrom,
      pageTo,
      currentPageReached: highestPage,
      progressPercent,
      reason: `أكمل قراءة صفحات الورد حتى الصفحة ${pageTo} (وصلت إلى ص ${highestPage} من ${pageTo}) لتتمكن من إنهاء القراءة.`,
    };
  }

  return {
    allowed: true,
    hasStarted: true,
    isCompleted: false,
    pageFrom,
    pageTo,
    currentPageReached: pageTo,
    progressPercent: 100,
    reason: 'أتممت قراءة صفحات الورد، يمكنك الآن الضغط على انتهاء القراءة.',
  };
}

/**
 * Complete reading the assigned Wird for a member on the current day.
 * Strictly verifies that a real reading session exists in Firestore and that the member reached pageTo.
 */
export async function completeMemberWirdReading(
  groupId: string,
  userId: string,
  userName: string
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === groupId);
  if (idx === -1) return null;

  const group = groups[idx];
  const effectiveUserId = resolveEffectiveMemberUserId(group, userId);
  const nowIso = new Date().toISOString();

  // Verify directly against Firestore distribution doc if online
  const wirdDocId = `${group.currentDay}_${effectiveUserId}`;
  try {
    const remoteDistSnap = await getDoc(
      doc(db, 'groups', groupId, 'distribution', wirdDocId)
    );
    if (remoteDistSnap.exists()) {
      const rData = remoteDistSnap.data();
      const localIdx = group.distribution.findIndex((d) => d.id === wirdDocId);
      if (localIdx >= 0) {
        group.distribution[localIdx] = {
          ...group.distribution[localIdx],
          startTime: rData.startTime || group.distribution[localIdx].startTime || null,
          lastActivity:
            rData.lastActivity || group.distribution[localIdx].lastActivity || null,
          currentPage:
            rData.currentPage ?? group.distribution[localIdx].currentPage ?? null,
          highestPageReached: Math.max(
            Number(rData.highestPageReached) || 0,
            group.distribution[localIdx].highestPageReached || 0
          ),
          isCompleted: Boolean(
            rData.isCompleted || group.distribution[localIdx].isCompleted
          ),
          status:
            rData.status ||
            group.distribution[localIdx].status ||
            'not_started',
        };
      }
    }
  } catch {
    // use hydrated state
  }

  const eligibility = evaluateMemberReadingCompletionEligibility(group, effectiveUserId);
  if (eligibility.isCompleted) {
    // Already completed today — do not duplicate completion count or logs
    return group;
  }
  if (!eligibility.allowed) {
    throw new Error(eligibility.reason);
  }

  let completedPagesCount = 0;
  let partNum = 1;
  let pageRangeText = '';
  let wasAlreadyCompletedToday = false;

  const updatedDist = group.distribution.map((d) => {
    if (d.userId === effectiveUserId && d.dayNumber === group.currentDay) {
      wasAlreadyCompletedToday = Boolean(d.isCompleted || d.status === 'completed');
      completedPagesCount = Math.max(1, d.pageTo - d.pageFrom + 1);
      partNum = d.partNumber;
      pageRangeText = `ص ${d.pageFrom} إلى ص ${d.pageTo}`;
      return {
        ...d,
        wirdId: d.id,
        groupId,
        startTime: d.startTime || nowIso,
        lastActivity: nowIso,
        currentPage: d.pageTo,
        highestPageReached: d.pageTo,
        progress: 100,
        status: 'completed' as WirdReadingStatus,
        isCompleted: true,
        completedAt: d.completedAt || nowIso,
      };
    }
    return d;
  });

  const updatedMembers = group.members.map((m) => {
    if (m.userId === effectiveUserId) {
      return {
        ...m,
        dailyProgress: completedPagesCount || Math.max(1, m.dailyProgress || 1),
        currentPage: eligibility.pageTo,
        readingStatus: 'completed' as WirdReadingStatus,
        lastActivity: nowIso,
        progressPercent: 100,
        completedDaysCount: wasAlreadyCompletedToday
          ? Math.max(1, m.completedDaysCount || 1)
          : (m.completedDaysCount || 0) + 1,
      };
    }
    return m;
  });

  const currentDayDists = updatedDist.filter((d) => d.dayNumber === group.currentDay);
  const completedMembersCount = currentDayDists.filter((d) => d.isCompleted).length;
  const totalActiveMembers = updatedMembers.filter((m) => m.isActive !== false).length;

  const updatedProgressHistory = [...group.dailyProgressHistory];
  const dpIdx = updatedProgressHistory.findIndex((p) => p.dayNumber === group.currentDay);
  const dpItem: WirdDailyProgressDoc = {
    dayNumber: group.currentDay,
    date: getTodayDateString(),
    completedMembers: completedMembersCount,
    totalMembers: totalActiveMembers,
    isFullCompleted: totalActiveMembers > 0 && completedMembersCount === totalActiveMembers,
  };
  if (dpIdx >= 0) {
    updatedProgressHistory[dpIdx] = dpItem;
  } else {
    updatedProgressHistory.push(dpItem);
  }

  const logEntry: WirdActivityLogDoc = {
    id: `log_${Date.now()}`,
    userId: effectiveUserId,
    userName,
    actionType: 'complete_wird',
    details: `أتم ${userName} قراءة ورده لليوم ${group.currentDay} (الجزء ${partNum} • ${pageRangeText})`,
    createdAt: nowIso,
  };

  const updatedGroup: WirdGroupDoc = {
    ...group,
    members: updatedMembers,
    distribution: updatedDist,
    dailyProgressHistory: updatedProgressHistory,
    activityLog: wasAlreadyCompletedToday
      ? group.activityLog
      : [logEntry, ...group.activityLog],
  };

  groups[idx] = updatedGroup;
  saveCachedWirdGroups(groups);

  // Persist completion to Firestore immediately
  await syncGroupToFirestore(updatedGroup);

  return updatedGroup;
}

/**
 * 【1】تحميل ورد العضو المخصص من Firestore مباشرة والتحقق من ملكيته
 * Queries `groups/{groupId}/distribution` where `userId == userId` and `dayNumber == currentDay`
 */
export async function getUserWird(
  groupId: string,
  userId: string,
  currentDayParam?: number
): Promise<WirdDistributionDoc | null> {
  if (!groupId || !userId) return null;

  let resolvedDay = currentDayParam;

  const cachedGroups = loadCachedWirdGroups();
  const cachedGroup = cachedGroups.find((g) => g.id === groupId);
  const effectiveUserId = cachedGroup
    ? resolveEffectiveMemberUserId(cachedGroup, userId)
    : userId;

  const targetLocalDay = resolvedDay || cachedGroup?.currentDay || 1;
  const localDist = cachedGroup
    ? cachedGroup.distribution.find(
        (d) => d.userId === effectiveUserId && d.dayNumber === targetLocalDay
      )
    : undefined;

  try {
    if (!resolvedDay) {
      if (cachedGroup?.currentDay) {
        resolvedDay = cachedGroup.currentDay;
      } else {
        const groupSnap = await getDoc(doc(db, 'groups', groupId));
        if (groupSnap.exists()) {
          resolvedDay = Number(groupSnap.data()?.currentDay) || 1;
        }
      }
    }

    const activeDay = resolvedDay || 1;

    // 1. Check deterministic ID `{dayNumber}_{effectiveUserId}` in Firestore first
    const directDoc = await getDoc(
      doc(db, 'groups', groupId, 'distribution', `${activeDay}_${effectiveUserId}`)
    );
    if (directDoc.exists()) {
      const data = directDoc.data();
      const pageFrom = Math.max(1, Math.min(604, Number(data.pageFrom) || 1));
      const pageTo = Math.max(pageFrom, Math.min(604, Number(data.pageTo) || pageFrom));
      const isCompleted = Boolean(data.isCompleted || data.status === 'completed');
      const status: WirdReadingStatus = isCompleted
        ? 'completed'
        : data.status === 'reading' || data.startTime
        ? 'reading'
        : 'not_started';

      return {
        id: directDoc.id,
        wirdId: String(data.wirdId || directDoc.id),
        groupId,
        userId: String(data.userId || effectiveUserId),
        userName: String(data.userName || ''),
        dayNumber: Number(data.dayNumber) || activeDay,
        partNumber: Number(data.partNumber) || getJuzForPage(pageFrom),
        surahName: String(data.surahName || getSurahNameForPage(pageFrom)),
        pageFrom,
        pageTo,
        startTime: data.startTime ? String(data.startTime) : null,
        lastActivity: data.lastActivity ? String(data.lastActivity) : null,
        currentPage: data.currentPage ? Number(data.currentPage) : null,
        highestPageReached: Number(data.highestPageReached) || 0,
        visitedPages: Array.isArray(data.visitedPages) ? data.visitedPages : [],
        progress: isCompleted ? 100 : Number(data.progress) || 0,
        status,
        isCompleted,
        completedAt: data.completedAt ? String(data.completedAt) : null,
      };
    }
  } catch {
    // Offline fallback below
  }

  return localDist || null;
}

/**
 * Start a real Reading Session in Firestore when a member opens the Mushaf reader for their assigned Wird.
 */
export async function startMemberWirdReadingSession(
  groupId: string,
  userId: string
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const group = groups.find((g) => g.id === groupId);
  const effId = group ? resolveEffectiveMemberUserId(group, userId) : userId;
  const dist = group?.distribution.find(
    (d) => d.userId === effId && d.dayNumber === (group?.currentDay || 1)
  );
  const startPage = dist?.currentPage || dist?.pageFrom || 1;
  return await updateMemberReadingPage(groupId, effId, startPage);
}

/**
 * Record & update a real Reading Session in Firestore when the member opens the Mushaf
 * and navigates through the pages of their assigned Wird.
 */
export async function updateMemberReadingPage(
  groupId: string,
  userId: string,
  currentPage: number
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === groupId);
  if (idx === -1) return null;

  const group = groups[idx];
  const effectiveUserId = resolveEffectiveMemberUserId(group, userId);
  const dist = group.distribution.find(
    (d) => d.userId === effectiveUserId && d.dayNumber === group.currentDay
  );
  if (!dist) return group;

  const nowIso = new Date().toISOString();
  const clampedPage = Math.max(dist.pageFrom, Math.min(dist.pageTo, currentPage));
  const prevHighest = Math.max(dist.highestPageReached || 0, clampedPage);
  const totalAssignedPages = Math.max(1, dist.pageTo - dist.pageFrom + 1);
  const pagesReadSoFar = Math.min(
    totalAssignedPages,
    Math.max(1, prevHighest - dist.pageFrom + 1)
  );
  const progressPct = dist.isCompleted
    ? 100
    : Math.min(100, Math.round((pagesReadSoFar / totalAssignedPages) * 100));
  const prevVisited = Array.isArray(dist.visitedPages) ? dist.visitedPages : [];
  const nextVisited = Array.from(new Set([...prevVisited, clampedPage])).sort(
    (a, b) => a - b
  );
  const nextStatus: WirdReadingStatus = dist.isCompleted ? 'completed' : 'reading';
  const sessionStartTime = dist.startTime || nowIso;

  const updatedDistribution = group.distribution.map((d) => {
    if (d.userId === effectiveUserId && d.dayNumber === group.currentDay) {
      return {
        ...d,
        wirdId: d.id,
        groupId,
        startTime: sessionStartTime,
        lastActivity: nowIso,
        currentPage: clampedPage,
        highestPageReached: prevHighest,
        visitedPages: nextVisited,
        progress: progressPct,
        status: nextStatus,
      };
    }
    return d;
  });

  const updatedMembers = group.members.map((m) => {
    if (m.userId === effectiveUserId) {
      const nextProgress = dist.isCompleted
        ? totalAssignedPages
        : Math.max(m.dailyProgress || 0, pagesReadSoFar);
      return {
        ...m,
        dailyProgress: nextProgress,
        currentPage: clampedPage,
        readingStatus: nextStatus,
        startTime: m.startTime || sessionStartTime,
        lastActivity: nowIso,
        progressPercent: progressPct,
      };
    }
    return m;
  });

  groups[idx] = {
    ...group,
    members: updatedMembers,
    distribution: updatedDistribution,
  };
  saveCachedWirdGroups(groups);

  const myMember = updatedMembers.find((m) => m.userId === effectiveUserId);
  const myDist = updatedDistribution.find(
    (d) => d.userId === effectiveUserId && d.dayNumber === group.currentDay
  );

  try {
    await Promise.all([
      myMember
        ? setDoc(doc(db, 'groups', groupId, 'members', effectiveUserId), myMember, {
            merge: true,
          })
        : Promise.resolve(),
      myDist
        ? setDoc(
            doc(db, 'groups', groupId, 'distribution', myDist.id),
            {
              id: myDist.id,
              wirdId: myDist.id,
              groupId,
              userId: myDist.userId,
              userName: myDist.userName,
              dayNumber: myDist.dayNumber,
              partNumber: myDist.partNumber,
              surahName: myDist.surahName,
              pageFrom: myDist.pageFrom,
              pageTo: myDist.pageTo,
              startTime: myDist.startTime,
              lastActivity: myDist.lastActivity,
              currentPage: myDist.currentPage,
              highestPageReached: myDist.highestPageReached,
              visitedPages: myDist.visitedPages,
              progress: myDist.progress,
              status: myDist.status,
              isCompleted: myDist.isCompleted,
              completedAt: myDist.completedAt,
            },
            { merge: true }
          )
        : Promise.resolve(),
    ]);
  } catch {
    // offline cache updated
  }

  return groups[idx];
}

/**
 * Post a message to the group's Wall of Messages (Dua / Encouragement / General)
 */
export async function postWirdGroupMessage(params: {
  groupId: string;
  userId: string;
  userName: string;
  message: string;
  category: 'dua' | 'encouragement' | 'general';
}): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === params.groupId);
  if (idx === -1) return null;

  const nowIso = new Date().toISOString();
  const msgDoc: WirdMessageDoc = {
    id: `msg_${Date.now()}`,
    userId: params.userId,
    userName: params.userName,
    message: params.message.trim(),
    category: params.category,
    createdAt: nowIso,
  };

  groups[idx].messages = [msgDoc, ...groups[idx].messages];
  saveCachedWirdGroups(groups);

  await setDoc(doc(db, 'groups', params.groupId, 'messages', msgDoc.id), msgDoc).catch(() => {});

  return { ...groups[idx] };
}

/**
 * Admin: Finish the current day and advance group to the next day with new parts distribution
 */
export async function advanceGroupDay(
  groupId: string,
  adminId: string,
  adminName: string
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === groupId);
  if (idx === -1) return null;

  const group = groups[idx];
  const finishedDay = group.currentDay || 1;
  const nowIso = new Date().toISOString();
  const todayStr = getTodayDateString();
  const activeMembers = group.members.filter((m) => m.isActive !== false);

  // Track which members were already marked completed on finishedDay so we don't double-count completedDaysCount
  const alreadyCompletedUserIds = new Set(
    group.distribution
      .filter((d) => d.dayNumber === finishedDay && d.isCompleted)
      .map((d) => d.userId)
  );

  // Mark all finishedDay distributions as completed
  const finalizedPreviousDist = group.distribution.map((d) => {
    if (d.dayNumber === finishedDay) {
      return {
        ...d,
        status: 'completed' as WirdReadingStatus,
        progress: 100,
        isCompleted: true,
        completedAt: d.completedAt || nowIso,
      };
    }
    return d;
  });

  // Update dailyProgressHistory for finishedDay as 100% completed
  const updatedProgressHistory = [...group.dailyProgressHistory];
  const finishedDpIdx = updatedProgressHistory.findIndex(
    (p) => p.dayNumber === finishedDay
  );
  const finishedDpItem: WirdDailyProgressDoc = {
    dayNumber: finishedDay,
    date: todayStr,
    completedMembers: activeMembers.length,
    totalMembers: activeMembers.length,
    isFullCompleted: true,
  };
  if (finishedDpIdx >= 0) {
    updatedProgressHistory[finishedDpIdx] = finishedDpItem;
  } else {
    updatedProgressHistory.push(finishedDpItem);
  }

  const isAtFinalTargetDay = finishedDay >= group.targetDays;
  const wasFinalDayAlreadyCompleted =
    activeMembers.length > 0 && alreadyCompletedUserIds.size >= activeMembers.length;

  // If on the final day and it wasn't completed yet, complete the final day without wiping it
  if (isAtFinalTargetDay && !wasFinalDayAlreadyCompleted) {
    const completedFinalMembers = group.members.map((m) => {
      if (m.isActive === false) return m;
      const distForMember = finalizedPreviousDist.find(
        (d) => d.userId === m.userId && d.dayNumber === finishedDay
      );
      const pagesCount = distForMember
        ? Math.max(1, distForMember.pageTo - distForMember.pageFrom + 1)
        : Math.max(1, m.dailyProgress || 1);
      return {
        ...m,
        dailyProgress: pagesCount,
        readingStatus: 'completed' as WirdReadingStatus,
        progressPercent: 100,
        completedDaysCount: alreadyCompletedUserIds.has(m.userId)
          ? Math.max(1, m.completedDaysCount || 1)
          : (m.completedDaysCount || 0) + 1,
      };
    });

    const logEntry: WirdActivityLogDoc = {
      id: `log_${Date.now()}`,
      userId: adminId,
      userName: adminName,
      actionType: 'next_day',
      details: `أتمت المجموعة بقيادة ${adminName} اليوم الأخير (${finishedDay} من ${group.targetDays}) واكتملت الختمة المباركة بنجاح`,
      createdAt: nowIso,
    };

    const finalGroup: WirdGroupDoc = {
      ...group,
      members: completedFinalMembers,
      distribution: finalizedPreviousDist,
      dailyProgressHistory: updatedProgressHistory,
      activityLog: [logEntry, ...group.activityLog],
    };

    groups[idx] = finalGroup;
    saveCachedWirdGroups(groups);
    await syncGroupToFirestore(finalGroup);
    return finalGroup;
  }

  // Advance to nextDay (or wrap around to Day 1 if starting a new Khatma after completing the final day)
  const nextDay = isAtFinalTargetDay ? 1 : finishedDay + 1;

  const updatedMembersForNextDay = group.members.map((m) => {
    if (m.isActive === false) return m;
    const incrementedDays = alreadyCompletedUserIds.has(m.userId)
      ? Math.max(1, m.completedDaysCount || 1)
      : (m.completedDaysCount || 0) + 1;
    return {
      ...m,
      dailyProgress: 0,
      currentPage: null,
      readingStatus: 'not_started' as WirdReadingStatus,
      startTime: null,
      lastActivity: null,
      progressPercent: 0,
      completedDaysCount: incrementedDays,
    };
  });

  const updatedBase: WirdGroupDoc = {
    ...group,
    currentDay: nextDay,
    members: updatedMembersForNextDay,
  };

  const nextActiveMembers = updatedMembersForNextDay.filter((m) => m.isActive !== false);
  const nextDist = calculateDistributionForGroup(updatedBase, nextActiveMembers, []);

  // Initialize dailyProgressHistory entry for nextDay
  const nextDpIdx = updatedProgressHistory.findIndex((p) => p.dayNumber === nextDay);
  const nextDpItem: WirdDailyProgressDoc = {
    dayNumber: nextDay,
    date: todayStr,
    completedMembers: 0,
    totalMembers: nextActiveMembers.length,
    isFullCompleted: false,
  };
  if (nextDpIdx >= 0) {
    updatedProgressHistory[nextDpIdx] = nextDpItem;
  } else {
    updatedProgressHistory.push(nextDpItem);
  }

  const sampleNext = nextDist[0];
  const nextRangeSummary = sampleNext
    ? ` (الصفحات ${sampleNext.pageFrom} → ${ nextDist[nextDist.length - 1]?.pageTo || sampleNext.pageTo })`
    : '';

  const logEntry: WirdActivityLogDoc = {
    id: `log_${Date.now()}`,
    userId: adminId,
    userName: adminName,
    actionType: 'next_day',
    details: isAtFinalTargetDay
      ? `بدأ ${adminName} دورة ختمة جديدة من اليوم 1${nextRangeSummary}`
      : `أنهى ${adminName} اليوم ${finishedDay} وبدأ توزيع أوراد اليوم ${nextDay}${nextRangeSummary}`,
    createdAt: nowIso,
  };

  const finalGroup: WirdGroupDoc = {
    ...updatedBase,
    distribution: [
      ...nextDist,
      ...finalizedPreviousDist.filter((d) => d.dayNumber !== nextDay),
    ],
    dailyProgressHistory: updatedProgressHistory,
    activityLog: [logEntry, ...group.activityLog],
  };

  groups[idx] = finalGroup;
  saveCachedWirdGroups(groups);
  await syncGroupToFirestore(finalGroup);

  return finalGroup;
}

/**
 * Admin: Promote member to admin (strictly requires caller to be group admin)
 */
export async function promoteGroupMemberToAdmin(
  groupId: string,
  targetUserId: string,
  actorId: string,
  actorName: string
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === groupId);
  if (idx === -1) return null;

  const group = groups[idx];
  const actorMember = group.members.find((m) => m.userId === actorId);
  const isAuthorizedAdmin =
    group.adminId === actorId ||
    (Array.isArray(group.adminIds) && group.adminIds.includes(actorId)) ||
    actorMember?.role === 'admin';
  if (!isAuthorizedAdmin) {
    throw new Error('غير مصرح لك بترقية الأعضاء. هذه الصلاحية لمشرف المجموعة فقط.');
  }

  let promotedName = '';
  groups[idx].members = groups[idx].members.map((m) => {
    if (m.userId === targetUserId) {
      promotedName = m.displayName;
      return { ...m, role: 'admin' };
    }
    return m;
  });

  const updatedAdminIds = Array.from(
    new Set([
      group.adminId,
      ...groups[idx].members.filter((m) => m.role === 'admin').map((m) => m.userId),
    ])
  );
  groups[idx].adminIds = updatedAdminIds;

  const logEntry: WirdActivityLogDoc = {
    id: `log_${Date.now()}`,
    userId: actorId,
    userName: actorName,
    actionType: 'promote_admin',
    details: `تمت ترقية العضو ${promotedName} إلى مشرف في المجموعة`,
    createdAt: new Date().toISOString(),
  };
  groups[idx].activityLog.unshift(logEntry);

  saveCachedWirdGroups(groups);
  await syncGroupToFirestore(groups[idx]);
  return { ...groups[idx] };
}

/**
 * Admin: Remove member from Firestore and automatically redistribute parts among remaining members.
 * Strictly verifies that actorId is the group owner/admin and executes real Firestore deletions.
 */
export async function removeGroupMemberAndRedistribute(
  groupId: string,
  targetUserId: string,
  actorId: string,
  actorName: string
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === groupId);
  if (idx === -1) return null;

  const group = groups[idx];
  const realActorUid = auth.currentUser?.uid || actorId;
  const actorMember = group.members.find((m) => m.userId === realActorUid);
  const isAuthorizedAdmin =
    group.adminId === realActorUid ||
    (Array.isArray(group.adminIds) && group.adminIds.includes(realActorUid)) ||
    actorMember?.role === 'admin';

  if (!isAuthorizedAdmin) {
    throw new Error('غير مصرح لك بإزالة أعضاء المجموعة. هذه الصلاحية لمشرف المجموعة فقط.');
  }

  if (targetUserId === group.adminId) {
    throw new Error('لا يمكن إزالة مؤسس المجموعة.');
  }

  const removedMember = group.members.find((m) => m.userId === targetUserId);
  const currentDayDistId = `${group.currentDay}_${targetUserId}`;

  // 1. Delete membership and current day distribution from Firestore first
  await Promise.all([
    deleteDoc(doc(db, 'groups', groupId, 'members', targetUserId)),
    deleteDoc(doc(db, 'groups', groupId, 'distribution', currentDayDistId)).catch(() => {}),
  ]);

  // 2. Update group members, memberIds, adminIds, and membersCount
  const remainingMembers = group.members.filter((m) => m.userId !== targetUserId);
  const remainingDist = group.distribution.filter((d) => d.userId !== targetUserId);
  const remainingMemberIds = remainingMembers
    .filter((m) => m.isActive !== false)
    .map((m) => m.userId);
  const remainingAdminIds = Array.from(
    new Set([
      group.adminId,
      ...remainingMembers.filter((m) => m.role === 'admin').map((m) => m.userId),
    ])
  );

  const logEntry: WirdActivityLogDoc = {
    id: `log_${Date.now()}`,
    userId: realActorUid,
    userName: actorName,
    actionType: 'remove_member',
    details: `قام المشرف ${actorName} بإزالة العضو «${removedMember?.displayName || targetUserId}» وإعادة توزيع الأجزاء تلقائياً`,
    createdAt: new Date().toISOString(),
  };

  groups[idx] = {
    ...group,
    members: remainingMembers,
    memberIds: remainingMemberIds,
    adminIds: remainingAdminIds,
    membersCount: remainingMemberIds.length,
    distribution: remainingDist,
    activityLog: [logEntry, ...group.activityLog],
  };
  saveCachedWirdGroups(groups);

  await setDoc(
    doc(db, 'groups', groupId),
    {
      memberIds: remainingMemberIds,
      adminIds: remainingAdminIds,
      membersCount: remainingMemberIds.length,
    },
    { merge: true }
  );
  await setDoc(doc(db, 'groups', groupId, 'activityLog', logEntry.id), logEntry).catch(
    () => {}
  );

  return await redistributeParts(groupId, realActorUid, actorName);
}

/**
 * Admin: Handle join request (Approve -> add member + redistribute, Reject -> mark rejected)
 */
export async function handleGroupJoinRequest(params: {
  groupId: string;
  requestId: string;
  approve: boolean;
  adminId: string;
  adminName: string;
}): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === params.groupId);
  if (idx === -1) return null;

  const reqItem = groups[idx].joinRequests.find((r) => r.id === params.requestId);
  if (!reqItem) return groups[idx];

  groups[idx].joinRequests = groups[idx].joinRequests.filter((r) => r.id !== params.requestId);

  if (params.approve) {
    const newMember: WirdMemberDoc = {
      userId: reqItem.userId,
      displayName: reqItem.userName,
      joinedAt: new Date().toISOString(),
      role: 'member',
      isActive: true,
      dailyProgress: 0,
      completedDaysCount: 0,
    };
    groups[idx].members.push(newMember);
    groups[idx].activityLog.unshift({
      id: `log_${Date.now()}`,
      userId: params.adminId,
      userName: params.adminName,
      actionType: 'join_group',
      details: `وافق المشرف على انضمام ${reqItem.userName} وتم توزيع الأجزاء تلقائياً`,
      createdAt: new Date().toISOString(),
    });
  }

  saveCachedWirdGroups(groups);
  void updateDoc(doc(db, 'groups', params.groupId, 'joinRequests', params.requestId), {
    status: params.approve ? 'approved' : 'rejected',
  }).catch(() => {});

  if (params.approve) {
    return await redistributeParts(params.groupId);
  }
  return { ...groups[idx] };
}

/**
 * Admin: Update group settings
 */
export async function updateWirdGroupSettings(
  groupId: string,
  updates: {
    groupName: string;
    description: string;
    planType: WirdPlanType;
    customSurahName?: string;
    targetDays: number;
    icon: WirdGroupIconId;
    isPublic: boolean;
  },
  actorId: string,
  actorName: string
): Promise<WirdGroupDoc | null> {
  const groups = loadCachedWirdGroups();
  const idx = groups.findIndex((g) => g.id === groupId);
  if (idx === -1) return null;

  let startPageRange = groups[idx].startPageRange;
  let endPageRange = groups[idx].endPageRange;

  if (updates.planType === 'khatma') {
    startPageRange = 1;
    endPageRange = 604;
  } else if (updates.planType === 'juz_amma') {
    startPageRange = 582;
    endPageRange = 604;
  } else if (updates.planType === 'surah_custom' && updates.customSurahName) {
    const found = QURAN_SURAH_OPTIONS.find((s) => s.name === updates.customSurahName);
    if (found) {
      startPageRange = found.startPage;
      endPageRange = found.endPage;
    }
  }

  const totalPages = endPageRange - startPageRange + 1;

  groups[idx] = {
    ...groups[idx],
    groupName: updates.groupName.trim(),
    description: updates.description.trim(),
    planType: updates.planType,
    customSurahName: updates.customSurahName,
    startPageRange,
    endPageRange,
    totalPages,
    targetDays: Math.max(1, updates.targetDays),
    icon: updates.icon,
    isPublic: updates.isPublic,
    activityLog: [
      {
        id: `log_${Date.now()}`,
        userId: actorId,
        userName: actorName,
        actionType: 'edit_group',
        details: `قام المشرف ${actorName} بتحديث إعدادات المجموعة وخطة الورد`,
        createdAt: new Date().toISOString(),
      },
      ...groups[idx].activityLog,
    ],
  };

  saveCachedWirdGroups(groups);
  return await redistributeParts(groupId);
}

/**
 * Admin: Delete group permanently
 */
export async function deleteWirdGroup(groupId: string): Promise<void> {
  const groups = loadCachedWirdGroups().filter((g) => g.id !== groupId);
  saveCachedWirdGroups(groups);
  try {
    await deleteDoc(doc(db, 'groups', groupId));
  } catch {
    // offline fallback
  }
}

/**
 * Cache and retrieve Quran Mushaf Page (604 pages Uthmani) in Firestore `quranPages/{pageNumber}` + localStorage
 */
export interface CachedMushafPageData {
  pageNumber: number;
  juzNumber: number;
  surahName: string;
  surahNumber: number;
  verseFrom: number;
  verseTo: number;
  text: string;
  ayahs: Array<{
    number: number;
    numberInSurah: number;
    text: string;
    surah: { number: number; name: string };
  }>;
}

function normalizeCachedMushafPage(raw: any, safePage: number): CachedMushafPageData | null {
  if (!raw || !Array.isArray(raw.ayahs) || raw.ayahs.length === 0) {
    return null;
  }
  const fallbackSurahName = raw.surahName || getSurahNameForPage(safePage);
  const fallbackSurahNumber =
    typeof raw.surahNumber === 'number' && raw.surahNumber > 0 ? raw.surahNumber : 1;

  const normalizedAyahs = raw.ayahs
    .filter(Boolean)
    .map((a: any, idx: number) => {
      const numberInSurah =
        typeof a.numberInSurah === 'number'
          ? a.numberInSurah
          : typeof a.number === 'number'
          ? a.number
          : idx + 1;
      const number =
        typeof a.number === 'number'
          ? a.number
          : safePage * 100 + numberInSurah;
      const surahNumber =
        typeof a?.surah?.number === 'number'
          ? a.surah.number
          : fallbackSurahNumber;
      const surahName =
        typeof a?.surah?.name === 'string' && a.surah.name.trim()
          ? a.surah.name
          : fallbackSurahName;

      return {
        number,
        numberInSurah,
        text: typeof a.text === 'string' ? a.text : '',
        surah: {
          number: surahNumber,
          name: surahName,
        },
      };
    });

  if (normalizedAyahs.length === 0) return null;

  const firstAyah = normalizedAyahs[0];
  const lastAyah = normalizedAyahs[normalizedAyahs.length - 1];

  return {
    pageNumber: safePage,
    juzNumber:
      typeof raw.juzNumber === 'number' && raw.juzNumber > 0
        ? raw.juzNumber
        : getJuzForPage(safePage),
    surahName: firstAyah.surah.name || fallbackSurahName,
    surahNumber: firstAyah.surah.number || fallbackSurahNumber,
    verseFrom: firstAyah.numberInSurah || 1,
    verseTo: lastAyah.numberInSurah || 1,
    text:
      typeof raw.text === 'string' && raw.text.trim()
        ? raw.text
        : normalizedAyahs.map((a: any) => `${a.text} (${a.numberInSurah})`).join(' '),
    ayahs: normalizedAyahs,
  };
}

export async function fetchAndSyncMushafPage(pageNumber: number): Promise<CachedMushafPageData> {
  const safePage = Math.max(1, Math.min(604, Number(pageNumber) || 1));
  const localKey = `rifq_quran_page_v3_${safePage}`;

  // 1. Check localStorage cache first for 60 FPS instant offline support
  try {
    const localRaw = localStorage.getItem(localKey);
    if (localRaw) {
      const normalized = normalizeCachedMushafPage(JSON.parse(localRaw), safePage);
      if (normalized) {
        return normalized;
      }
    }
  } catch {
    // ignore
  }

  // 2. Check Firestore `quranPages/{pageNumber}`
  try {
    const pageSnap = await getDoc(doc(db, 'quranPages', String(safePage)));
    if (pageSnap.exists()) {
      const normalized = normalizeCachedMushafPage(pageSnap.data(), safePage);
      if (normalized) {
        try {
          localStorage.setItem(localKey, JSON.stringify(normalized));
        } catch {
          // ignore
        }
        return normalized;
      }
    }
  } catch {
    // ignore
  }

  // 3. Fetch from AlQuran Cloud Uthmani API and persist to both localStorage and Firestore `quranPages/{pageNumber}`
  const res = await fetch(`https://api.alquran.cloud/v1/page/${safePage}/quran-uthmani`);
  const json = await res.json();
  if (json.code !== 200 || !json.data?.ayahs) {
    throw new Error('تعذر تحميل صفحة المصحف الشريف');
  }

  const pageData = normalizeCachedMushafPage(
    {
      pageNumber: safePage,
      juzNumber: getJuzForPage(safePage),
      surahName: json.data.ayahs[0]?.surah?.name || getSurahNameForPage(safePage),
      surahNumber: json.data.ayahs[0]?.surah?.number || 1,
      ayahs: json.data.ayahs,
    },
    safePage
  );

  if (!pageData) {
    throw new Error('تعذر تحميل صفحة المصحف الشريف');
  }

  try {
    localStorage.setItem(localKey, JSON.stringify(pageData));
  } catch {
    // ignore
  }

  try {
    await setDoc(doc(db, 'quranPages', String(safePage)), {
      juzNumber: pageData.juzNumber,
      surahName: pageData.surahName,
      surahNumber: pageData.surahNumber,
      verseFrom: pageData.verseFrom,
      verseTo: pageData.verseTo,
      text: pageData.text,
      ayahs: pageData.ayahs,
    });
  } catch {
    // ignore
  }

  return pageData;
}
