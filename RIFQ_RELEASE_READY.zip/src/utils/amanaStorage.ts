import { triggerPushNotification, syncFullNotificationScheduleWithServiceWorker, ScheduledSwNotificationItem, RIFQ_NOTIFICATION_CHANNELS } from './notifications';
import { isBiometricAvailable, promptBiometricAuth } from './appLock';

export type DebtType = 'receivable' | 'payable'; // 'receivable' = لي مال عنده, 'payable' = عليّ مال له
export type DebtStatus = 'due' | 'partially_paid' | 'paid';

export interface DebtPayment {
  id: string;
  amount: number;
  currency: string;
  paymentDate: string; // YYYY-MM-DD
  note?: string;
  createdAt: number;
}

export interface DebtRecord {
  id: string;
  personName: string;
  type: DebtType;
  totalAmount: number;
  currency: string;
  description: string;
  recordDate: string; // YYYY-MM-DD
  dueDate?: string; // YYYY-MM-DD
  status: DebtStatus;
  notes?: string;
  payments: DebtPayment[];
  reminderEnabled?: boolean;
  reminderTime?: string; // e.g. "10:00"
  reminderDaysBefore?: number; // 0 = day of due date, 1 = 1 day before, 3 = 3 days before
  lastReminderFiredDate?: string;
  createdAt: number;
  updatedAt: number;
}

export type TrustItemType = 'physical' | 'document' | 'key' | 'device' | 'money' | 'other';
export type TrustStatus = 'in_custody' | 'returned';

export interface TrustRecord {
  id: string;
  ownerName: string;
  title: string;
  itemType: TrustItemType;
  safeLocation: string; // e.g. "درج المكتب", "الخزنة", etc.
  receivedDate: string; // YYYY-MM-DD
  returnDueDate?: string; // YYYY-MM-DD
  status: TrustStatus;
  returnedDate?: string; // YYYY-MM-DD
  notes?: string;
  reminderEnabled?: boolean;
  reminderTime?: string; // e.g. "10:00"
  lastReminderFiredDate?: string;
  createdAt: number;
  updatedAt: number;
}

export interface AmanaVaultSettings {
  isEnabled: boolean;
  pinHash?: string;
  pinSalt?: string;
  biometricEnabled: boolean;
  autoLockMinutes: number; // 0 = immediate when leaving, 3 = 3 min, 5 = 5 min, 15 = 15 min
  lastUnlockedTimestamp?: number;
}

export interface AmanaDataState {
  debts: DebtRecord[];
  trusts: TrustRecord[];
  vaultSettings: AmanaVaultSettings;
  version: number;
}

const AMANA_STORAGE_KEY = 'rifq_amana_local_vault_v1';

const DEFAULT_VAULT_SETTINGS: AmanaVaultSettings = {
  isEnabled: false,
  biometricEnabled: false,
  autoLockMinutes: 5,
};

const DEFAULT_AMANA_STATE: AmanaDataState = {
  debts: [],
  trusts: [],
  vaultSettings: DEFAULT_VAULT_SETTINGS,
  version: 1,
};

export const COMMON_CURRENCIES = [
  { code: 'EGP', nameAr: 'جنيه مصري', symbol: 'ج.م' },
  { code: 'SAR', nameAr: 'ريال سعودي', symbol: 'ر.س' },
  { code: 'AED', nameAr: 'درهم إماراتي', symbol: 'د.إ' },
  { code: 'KWD', nameAr: 'دينار كويتي', symbol: 'د.ك' },
  { code: 'QAR', nameAr: 'ريال قطري', symbol: 'ر.ق' },
  { code: 'USD', nameAr: 'دولار أمريكي', symbol: '$' },
  { code: 'EUR', nameAr: 'يورو', symbol: '€' },
  { code: 'JOD', nameAr: 'دينار أردني', symbol: 'د.أ' },
  { code: 'OMR', nameAr: 'ريال عماني', symbol: 'ر.ع' },
  { code: 'BHD', nameAr: 'دينار بحريني', symbol: 'د.ب' },
  { code: 'LYD', nameAr: 'دينار ليبي', symbol: 'د.ل' },
  { code: 'DZD', nameAr: 'دينار جزائري', symbol: 'د.ج' },
  { code: 'MAD', nameAr: 'درهم مغربي', symbol: 'د.م' },
  { code: 'TND', nameAr: 'دينار تونسي', symbol: 'د.ت' },
  { code: 'IQD', nameAr: 'دينار عراقي', symbol: 'د.ع' },
  { code: 'YER', nameAr: 'ريال يمني', symbol: 'ر.ي' },
  { code: 'TRY', nameAr: 'ليرة تركية', symbol: '₺' },
  { code: 'GBP', nameAr: 'جنيه إسترليني', symbol: '£' },
];

/**
 * دالة تجزئة وتشفير الرقم السري (SHA-256 مع Salt فريد) لمنع التخزين الصريح تماماً
 */
export async function hashVaultPin(pin: string, existingSalt?: string): Promise<{ hash: string; salt: string }> {
  const salt = existingSalt || Array.from(window.crypto.getRandomValues(new Uint8Array(16)))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');

  const encoder = new TextEncoder();
  const data = encoder.encode(`${salt}:${pin}:rifq_amana_secure_salt`);
  const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hash = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');

  return { hash, salt };
}

/**
 * التحقق من صحة الرقم السري المدخل
 */
export async function verifyVaultPin(enteredPin: string, storedHash: string, storedSalt: string): Promise<boolean> {
  const { hash } = await hashVaultPin(enteredPin, storedSalt);
  return hash === storedHash;
}

/**
 * تحميل بيانات أمانة المحفوظة محلياً فقط على الجهاز
 */
export function loadAmanaState(): AmanaDataState {
  if (typeof window === 'undefined') return { ...DEFAULT_AMANA_STATE };
  try {
    const raw = localStorage.getItem(AMANA_STORAGE_KEY);
    if (!raw) return { ...DEFAULT_AMANA_STATE };
    const parsed = JSON.parse(raw);
    return {
      debts: Array.isArray(parsed.debts) ? parsed.debts : [],
      trusts: Array.isArray(parsed.trusts) ? parsed.trusts : [],
      vaultSettings: { ...DEFAULT_VAULT_SETTINGS, ...(parsed.vaultSettings || {}) },
      version: parsed.version || 1,
    };
  } catch {
    return { ...DEFAULT_AMANA_STATE };
  }
}

/**
 * حفظ بيانات أمانة محلياً مع تحديث مزامنة التنبيهات
 */
export function saveAmanaState(state: AmanaDataState): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(AMANA_STORAGE_KEY, JSON.stringify(state));
    syncAmanaRemindersWithSystem(state.debts, state.trusts);
  } catch (err) {
    console.warn('Could not save Amana state locally:', err);
  }
}

/**
 * حساب مبالغ الدين: المدفوع، المتبقي، والحالة التلقائية
 */
export function calculateDebtBalance(debt: DebtRecord): {
  paidAmount: number;
  remainingAmount: number;
  status: DebtStatus;
} {
  const paidAmount = (debt.payments || []).reduce((acc, p) => acc + (Number(p.amount) || 0), 0);
  const total = Number(debt.totalAmount) || 0;
  const remainingAmount = Math.max(0, total - paidAmount);

  let status: DebtStatus = 'due';
  if (remainingAmount <= 0 && total > 0) {
    status = 'paid';
  } else if (paidAmount > 0) {
    status = 'partially_paid';
  }

  return {
    paidAmount,
    remainingAmount,
    status,
  };
}

/**
 * إضافة أو تحديث دين
 */
export function saveDebtRecord(record: DebtRecord): void {
  const state = loadAmanaState();
  const now = Date.now();
  const { status } = calculateDebtBalance(record);
  const updatedRecord = { ...record, status, updatedAt: now };

  const idx = state.debts.findIndex((d) => d.id === record.id);
  if (idx >= 0) {
    state.debts[idx] = updatedRecord;
  } else {
    state.debts.unshift(updatedRecord);
  }

  saveAmanaState(state);
}

/**
 * تسجيل دفعة جديدة داخل دين معين
 */
export function recordDebtPayment(debtId: string, payment: Omit<DebtPayment, 'id' | 'createdAt'>): DebtRecord | null {
  const state = loadAmanaState();
  const idx = state.debts.findIndex((d) => d.id === debtId);
  if (idx === -1) return null;

  const target = state.debts[idx];
  const now = Date.now();
  const newPayment: DebtPayment = {
    ...payment,
    id: `pay_${now}_${Math.random().toString(36).slice(2, 6)}`,
    createdAt: now,
  };

  const updatedPayments = [...(target.payments || []), newPayment];
  const tempDebt = { ...target, payments: updatedPayments };
  const { status } = calculateDebtBalance(tempDebt);

  const updatedDebt: DebtRecord = {
    ...tempDebt,
    status,
    updatedAt: now,
  };

  state.debts[idx] = updatedDebt;
  saveAmanaState(state);
  return updatedDebt;
}

/**
 * حذف دفعة مسجلة من دين
 */
export function deleteDebtPayment(debtId: string, paymentId: string): DebtRecord | null {
  const state = loadAmanaState();
  const idx = state.debts.findIndex((d) => d.id === debtId);
  if (idx === -1) return null;

  const target = state.debts[idx];
  const updatedPayments = (target.payments || []).filter((p) => p.id !== paymentId);
  const tempDebt = { ...target, payments: updatedPayments };
  const { status } = calculateDebtBalance(tempDebt);

  const updatedDebt: DebtRecord = {
    ...tempDebt,
    status,
    updatedAt: Date.now(),
  };

  state.debts[idx] = updatedDebt;
  saveAmanaState(state);
  return updatedDebt;
}

/**
 * حذف دين بالكامل
 */
export function deleteDebtRecord(debtId: string): void {
  const state = loadAmanaState();
  state.debts = state.debts.filter((d) => d.id !== debtId);
  saveAmanaState(state);
}

/**
 * إضافة أو تحديث أمانة
 */
export function saveTrustRecord(record: TrustRecord): void {
  const state = loadAmanaState();
  const now = Date.now();
  const updatedRecord = { ...record, updatedAt: now };

  const idx = state.trusts.findIndex((t) => t.id === record.id);
  if (idx >= 0) {
    state.trusts[idx] = updatedRecord;
  } else {
    state.trusts.unshift(updatedRecord);
  }

  saveAmanaState(state);
}

/**
 * تغيير حالة الأمانة (تمت إعادتها / بحوزتي)
 */
export function toggleTrustStatus(trustId: string, status: TrustStatus): TrustRecord | null {
  const state = loadAmanaState();
  const idx = state.trusts.findIndex((t) => t.id === trustId);
  if (idx === -1) return null;

  const now = Date.now();
  const todayStr = new Date().toISOString().split('T')[0];

  const updated: TrustRecord = {
    ...state.trusts[idx],
    status,
    returnedDate: status === 'returned' ? todayStr : undefined,
    updatedAt: now,
  };

  state.trusts[idx] = updated;
  saveAmanaState(state);
  return updated;
}

/**
 * حذف أمانة
 */
export function deleteTrustRecord(trustId: string): void {
  const state = loadAmanaState();
  state.trusts = state.trusts.filter((t) => t.id !== trustId);
  saveAmanaState(state);
}

/**
 * تحديث إعدادات الخزنة
 */
export function saveVaultSettings(settings: AmanaVaultSettings): void {
  const state = loadAmanaState();
  state.vaultSettings = { ...state.vaultSettings, ...settings };
  saveAmanaState(state);
}

/**
 * تجميع أرصدة الديون بحسب كل عملة بشكل مستقل تماماً
 * مهم: لا يتم جمع عملات مختلفة مع بعضها البعض.
 */
export interface CurrencyDebtSummary {
  currency: string;
  receivableTotal: number;
  receivablePaid: number;
  receivableRemaining: number;
  payableTotal: number;
  payablePaid: number;
  payableRemaining: number;
}

export function groupDebtsByCurrency(debts: DebtRecord[]): CurrencyDebtSummary[] {
  const map = new Map<string, CurrencyDebtSummary>();

  for (const d of debts) {
    const cur = (d.currency || 'EGP').toUpperCase();
    if (!map.has(cur)) {
      map.set(cur, {
        currency: cur,
        receivableTotal: 0,
        receivablePaid: 0,
        receivableRemaining: 0,
        payableTotal: 0,
        payablePaid: 0,
        payableRemaining: 0,
      });
    }

    const item = map.get(cur)!;
    const { paidAmount, remainingAmount } = calculateDebtBalance(d);

    if (d.type === 'receivable') {
      item.receivableTotal += d.totalAmount || 0;
      item.receivablePaid += paidAmount;
      item.receivableRemaining += remainingAmount;
    } else {
      item.payableTotal += d.totalAmount || 0;
      item.payablePaid += paidAmount;
      item.payableRemaining += remainingAmount;
    }
  }

  return Array.from(map.values());
}

/**
 * مزامنة تذكيرات الديون والأمانات مع نظام التنبيهات الموحد (Android Local Notifications & Service Worker)
 */
export function syncAmanaRemindersWithSystem(debts?: DebtRecord[], trusts?: TrustRecord[]): void {
  if (typeof window === 'undefined') return;

  const state = loadAmanaState();
  const debtList = debts || state.debts;
  const trustList = trusts || state.trusts;

  const scheduleItems: ScheduledSwNotificationItem[] = [];
  const now = new Date();
  const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

  // تذكيرات الديون المستحقة
  for (const debt of debtList) {
    if (!debt.reminderEnabled || !debt.dueDate || debt.status === 'paid') continue;

    const timeStr = debt.reminderTime || '10:00';
    const [h, m] = timeStr.split(':').map(Number);
    const dueDateObj = new Date(debt.dueDate);
    const daysBefore = debt.reminderDaysBefore || 0;

    // حساب تاريخ التنبيه
    const alertDate = new Date(dueDateObj.getFullYear(), dueDateObj.getMonth(), dueDateObj.getDate() - daysBefore, h || 10, m || 0, 0, 0);

    const isReceivable = debt.type === 'receivable';
    const actionText = isReceivable ? `استحقاق سداد مبلغ لي عند ${debt.personName}` : `موعد سداد دين عليّ لـ ${debt.personName}`;

    scheduleItems.push({
      id: `amana_debt_${debt.id}`,
      signatureKey: `amana_debt_${debt.id}_${debt.dueDate}_${timeStr}`,
      channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
      title: `تذكير أمانة 📜 • ${actionText}`,
      body: `المبلغ: ${debt.totalAmount} ${debt.currency} • الاستحقاق: ${debt.dueDate}`,
      timestamp: alertDate.getTime(),
      timeHHMM: timeStr,
      repeatDaily: false,
      enabled: true,
      tag: `rifq-amana-debt-${debt.id}-${todayStr}`,
      screen: 'amana',
      dhikrId: debt.id,
    });
  }

  // تذكيرات الأمانات
  for (const trust of trustList) {
    if (!trust.reminderEnabled || !trust.returnDueDate || trust.status === 'returned') continue;

    const timeStr = trust.reminderTime || '10:00';
    const [h, m] = timeStr.split(':').map(Number);
    const dueDateObj = new Date(trust.returnDueDate);
    const alertDate = new Date(dueDateObj.getFullYear(), dueDateObj.getMonth(), dueDateObj.getDate(), h || 10, m || 0, 0, 0);

    scheduleItems.push({
      id: `amana_trust_${trust.id}`,
      signatureKey: `amana_trust_${trust.id}_${trust.returnDueDate}_${timeStr}`,
      channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
      title: `تذكير أمانة 📦 • موعد إعادة أمانة`,
      body: `الأمانة: ${trust.title} لصاحبها ${trust.ownerName} • المحفوظة في: ${trust.safeLocation}`,
      timestamp: alertDate.getTime(),
      timeHHMM: timeStr,
      repeatDaily: false,
      enabled: true,
      tag: `rifq-amana-trust-${trust.id}-${todayStr}`,
      screen: 'amana',
      dhikrId: trust.id,
    });
  }

  if (scheduleItems.length > 0) {
    syncFullNotificationScheduleWithServiceWorker(scheduleItems);
  }
}

/**
 * فحص وإطلاق تذكيرات أمانة المستحقة اليوم أثناء عمل التطبيق
 */
export function checkAndFireAmanaReminders(): void {
  if (typeof window === 'undefined') return;
  try {
    const state = loadAmanaState();
    const now = new Date();
    const currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

    let hasUpdates = false;

    // فحص الديون
    for (const debt of state.debts) {
      if (!debt.reminderEnabled || !debt.dueDate || debt.status === 'paid') continue;
      if (debt.lastReminderFiredDate === todayStr) continue;

      const timeStr = debt.reminderTime || '10:00';
      const daysBefore = debt.reminderDaysBefore || 0;

      // حساب اليوم المستهدف للإشعار
      const dueDt = new Date(debt.dueDate);
      const targetDt = new Date(dueDt.getFullYear(), dueDt.getMonth(), dueDt.getDate() - daysBefore);
      const targetStr = `${targetDt.getFullYear()}-${String(targetDt.getMonth() + 1).padStart(2, '0')}-${String(targetDt.getDate()).padStart(2, '0')}`;

      if (todayStr === targetStr && currentHHMM === timeStr) {
        const isReceivable = debt.type === 'receivable';
        const actionText = isReceivable ? `استحقاق سداد مبلغ لك عند ${debt.personName}` : `موعد سداد دين عليك لصالح ${debt.personName}`;

        triggerPushNotification({
          title: `تذكير أمانة 📜 • ${actionText}`,
          message: `المبلغ: ${debt.totalAmount} ${debt.currency} • تاريخ الاستحقاق: ${debt.dueDate}`,
          tag: `rifq-amana-debt-${debt.id}-${todayStr}`,
          screen: 'amana',
          channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
          recordInCenter: true,
        });

        debt.lastReminderFiredDate = todayStr;
        hasUpdates = true;
      }
    }

    // فحص الأمانات
    for (const trust of state.trusts) {
      if (!trust.reminderEnabled || !trust.returnDueDate || trust.status === 'returned') continue;
      if (trust.lastReminderFiredDate === todayStr) continue;

      const timeStr = trust.reminderTime || '10:00';
      if (todayStr === trust.returnDueDate && currentHHMM === timeStr) {
        triggerPushNotification({
          title: `تذكير أمانة 📦 • موعد إعادة أمانة`,
          message: `حان موعد إعادة «${trust.title}» لصاحبها ${trust.ownerName} (مكان الحفظ: ${trust.safeLocation})`,
          tag: `rifq-amana-trust-${trust.id}-${todayStr}`,
          screen: 'amana',
          channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
          recordInCenter: true,
        });

        trust.lastReminderFiredDate = todayStr;
        hasUpdates = true;
      }
    }

    if (hasUpdates) {
      saveAmanaState(state);
    }
  } catch (err) {
    console.warn('Error in checkAndFireAmanaReminders:', err);
  }
}
