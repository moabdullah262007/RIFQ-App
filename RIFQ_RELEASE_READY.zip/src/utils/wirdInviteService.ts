import { Capacitor, registerPlugin, PluginListenerHandle } from '@capacitor/core';
import { getRifqPublicOrigin, isLocalOrInternalHost } from '../config/rifqAppConfig';

interface RifqNativeInviteBridgePlugin {
  consumePendingWirdInvite(): Promise<{
    hasPending: boolean;
    inviteCode?: string;
    url?: string;
    timestamp?: number;
  }>;
  shareNative(options: {
    title?: string;
    text: string;
    url?: string;
    dialogTitle?: string;
  }): Promise<{
    shared: boolean;
    error?: string;
  }>;
  openExternalUrl(options: { url: string }): Promise<{
    opened: boolean;
    error?: string;
  }>;
  addListener(
    eventName: 'wirdInviteDeepLink',
    listenerFunc: (data: { inviteCode: string; url: string; timestamp: number }) => void
  ): Promise<PluginListenerHandle>;
}

const RifqNativeBridge = registerPlugin<RifqNativeInviteBridgePlugin>('RifqNotifications');

const PENDING_WIRD_INVITE_STORAGE_KEY = 'rifq_pending_wird_join_code_v1';

/**
 * تنظيف وتوحيد كود الدعوة:
 * - يستخرج الكود تلقائيًا إذا قام المستخدم بلصق رابط الدعوة الكامل (?wirdJoin=CODE) أو نص رسالة الدعوة
 * - يزيل المسافات وعلامات الاتجاه الخفية (RTL/LTR marks) والرموز غير الأبجدية الرقمية
 * - يحول الأحرف إلى كبيرة (Uppercase)
 */
export function sanitizeWirdInviteCode(rawCode: string): string {
  const input = (rawCode || '').trim();
  if (!input) return '';

  // 1. إذا احتوى النص المدخل على رابط به معامل wirdJoin أو joinCode
  const urlMatch = input.match(/[?&](?:wirdJoin|joinCode)=([A-Za-z0-9_-]+)/i);
  if (urlMatch && urlMatch[1]) {
    return urlMatch[1].replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  }

  // 2. إذا احتوى النص على عبارة "كود الدعوة: XXXXXX"
  const labelMatch = input.match(/كود\s*الدعوة\s*[:：]\s*([A-Za-z0-9]+)/i);
  if (labelMatch && labelMatch[1]) {
    return labelMatch[1].replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  }

  // 3. إزالة أي مسافات أو رموز اتجاه خفية (مثل \u200f و \u200e و #) والإبقاء على الأحرف والأرقام فقط
  return input.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
}

/**
 * توليد رابط الدعوة الحقيقي لمجموعة وِرد بناءً على الدومين الرسمي المركزي لتطبيق رِفْق
 * صيغة الرابط: https://YOUR_REAL_RIFQ_DOMAIN/?wirdJoin=INVITE_CODE
 * يضمن عدم توليد localhost نهائيًا.
 */
export function buildWirdGroupInviteUrl(joinCode: string): string {
  const cleanCode = sanitizeWirdInviteCode(joinCode);
  const baseOrigin = getRifqPublicOrigin();

  try {
    const url = new URL('/' , `${baseOrigin}/`);
    if (isLocalOrInternalHost(url.hostname)) {
      throw new Error('Localhost is not allowed in production invite URLs');
    }
    url.searchParams.set('wirdJoin', cleanCode);
    return url.toString();
  } catch {
    return `${baseOrigin}/?wirdJoin=${encodeURIComponent(cleanCode)}`;
  }
}

/**
 * توليد نص رسالة الدعوة الحقيقي مع رابط الانضمام المباشر
 */
export function buildWirdGroupInviteMessage(params: {
  groupName: string;
  joinCode: string;
}): string {
  const cleanName = (params.groupName || '').trim();
  const cleanCode = sanitizeWirdInviteCode(params.joinCode);
  const inviteUrl = buildWirdGroupInviteUrl(cleanCode);

  return [
    `انضم إلينا في مجموعة «${cleanName}» في قسم وِرد بتطبيق رِفْق | RIFQ`,
    '',
    `كود الدعوة: ${cleanCode}`,
    '',
    'رابط الانضمام المباشر:',
    inviteUrl,
  ].join('\n');
}

/**
 * توليد رابط مشاركة الدعوة عبر واتساب (WhatsApp Share URL)
 */
export function buildWirdWhatsAppShareUrl(params: {
  groupName: string;
  joinCode: string;
}): string {
  const message = buildWirdGroupInviteMessage(params);
  return `https://wa.me/?text=${encodeURIComponent(message)}`;
}

/**
 * توليد رابط مشاركة الدعوة عبر تيليجرام (Telegram Share URL الحقيقي)
 * يحتوي على رابط الدعوة الحقيقي في حقل url ونص الدعوة والكود في حقل text.
 */
export function buildWirdTelegramShareUrl(params: {
  groupName: string;
  joinCode: string;
}): string {
  const cleanName = (params.groupName || '').trim();
  const cleanCode = sanitizeWirdInviteCode(params.joinCode);
  const inviteUrl = buildWirdGroupInviteUrl(cleanCode);
  const textBody = [
    `انضم إلينا في مجموعة «${cleanName}» في قسم وِرد بتطبيق رِفْق | RIFQ`,
    '',
    `كود الدعوة: ${cleanCode}`,
  ].join('\n');

  return `https://t.me/share/url?url=${encodeURIComponent(inviteUrl)}&text=${encodeURIComponent(
    textBody
  )}`;
}

/**
 * فتح رابط مشاركة خارجي (واتساب / تيليجرام) عبر نظام أندرويد الأصلي أو المتصفح
 */
export async function openWirdExternalShareUrl(url: string): Promise<void> {
  if (!url) return;
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await RifqNativeBridge.openExternalUrl({ url });
      if (res?.opened) return;
    } catch {
      // fallback below
    }
  }
  if (typeof window !== 'undefined') {
    window.location.href = url;
  }
}

/**
 * مشاركة دعوة المجموعة عبر التطبيقات باستخدام Android Native Share / Web Share API الحقيقي
 * بدون استخدام Toast أو محاكاة للمشاركة.
 */
export async function shareWirdGroupInviteNatively(params: {
  groupName: string;
  joinCode: string;
}): Promise<boolean> {
  const cleanName = (params.groupName || '').trim();
  const cleanCode = sanitizeWirdInviteCode(params.joinCode);
  const inviteUrl = buildWirdGroupInviteUrl(cleanCode);
  const message = buildWirdGroupInviteMessage({ groupName: cleanName, joinCode: cleanCode });
  const title = `دعوة للانضمام لمجموعة «${cleanName}» — وِرد | رِفْق`;

  // 1. على نظام أندرويد (Capacitor Native): استخدم Android Native Share Sheet الحقيقي (Intent.ACTION_SEND)
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await RifqNativeBridge.shareNative({
        title,
        text: message,
        url: inviteUrl,
        dialogTitle: 'مشاركة دعوة المجموعة عبر التطبيقات',
      });
      if (res?.shared) {
        return true;
      }
    } catch {
      // fallback to navigator.share if available
    }
  }

  // 2. استخدام Web Share API الرسمي في المتصفحات الداعمة
  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      await navigator.share({
        title,
        text: message,
        url: inviteUrl,
      });
      return true;
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        return true;
      }
    }
  }

  return false;
}

/**
 * حفظ واسترجاع ومسح كود الدعوة المعلق (يُستخدم عند فتح رابط دعوة قبل تسجيل الدخول أو أثناء تشغيل التطبيق)
 */
export function savePendingWirdInviteCode(rawCode: string): string {
  const clean = sanitizeWirdInviteCode(rawCode);
  if (!clean) return '';
  try {
    localStorage.setItem(PENDING_WIRD_INVITE_STORAGE_KEY, clean);
  } catch {
    // ignore
  }
  return clean;
}

export function getPendingWirdInviteCode(): string | null {
  try {
    const val = localStorage.getItem(PENDING_WIRD_INVITE_STORAGE_KEY);
    if (val && val.trim()) {
      return sanitizeWirdInviteCode(val);
    }
  } catch {
    // ignore
  }
  return null;
}

export function clearPendingWirdInviteCode(): void {
  try {
    localStorage.removeItem(PENDING_WIRD_INVITE_STORAGE_KEY);
  } catch {
    // ignore
  }
}

/**
 * استخراج كود الدعوة من رابط المتصفح الحالي إن وُجد (?wirdJoin=INVITE_CODE)
 */
export function extractWirdInviteCodeFromUrl(urlOrSearch?: string): string | null {
  try {
    const target =
      urlOrSearch !== undefined
        ? urlOrSearch
        : typeof window !== 'undefined'
        ? window.location.href
        : '';
    if (!target) return null;

    if (target.startsWith('?')) {
      const params = new URLSearchParams(target);
      const raw = params.get('wirdJoin') || params.get('joinCode');
      return raw ? sanitizeWirdInviteCode(raw) : null;
    }

    const parsed = new URL(target, getRifqPublicOrigin());
    const fromQuery =
      parsed.searchParams.get('wirdJoin') || parsed.searchParams.get('joinCode');
    if (fromQuery) {
      return sanitizeWirdInviteCode(fromQuery);
    }

    // Check hash params if any
    if (parsed.hash && parsed.hash.includes('wirdJoin=')) {
      const hashQuery = parsed.hash.split('?')[1] || parsed.hash.replace(/^#/, '');
      const hashParams = new URLSearchParams(hashQuery);
      const fromHash = hashParams.get('wirdJoin') || hashParams.get('joinCode');
      if (fromHash) {
        return sanitizeWirdInviteCode(fromHash);
      }
    }
  } catch {
    // ignore
  }
  return null;
}

/**
 * تنظيف معامل wirdJoin من شريط العنوان بعد التقاطه حتى لا يتكرر فتحه عند تحديث الصفحة يدويًا
 */
export function clearWirdInviteQueryFromWindowUrl(): void {
  if (typeof window === 'undefined') return;
  try {
    const url = new URL(window.location.href);
    if (url.searchParams.has('wirdJoin') || url.searchParams.has('joinCode')) {
      url.searchParams.delete('wirdJoin');
      url.searchParams.delete('joinCode');
      const nextSearch = url.searchParams.toString();
      const nextUrl = `${url.pathname}${nextSearch ? `?${nextSearch}` : ''}${url.hash || ''}`;
      window.history.replaceState({}, '', nextUrl);
    }
  } catch {
    // ignore
  }
}

/**
 * تهيئة جسر Deep Link / Android App Link لاستقبال روابط الدعوات في جميع حالات التطبيق:
 * - التطبيق مغلق (Cold Start)
 * - التطبيق في الخلفية (Background -> Foreground)
 * - التطبيق مفتوح (Foreground)
 */
export function initWirdDeepLinkBridge(
  onInviteReceived: (inviteCode: string) => void
): () => void {
  let listenerHandle: PluginListenerHandle | null = null;

  const dispatchInvite = (rawCode?: string | null) => {
    const clean = sanitizeWirdInviteCode(rawCode || '');
    if (!clean) return;
    savePendingWirdInviteCode(clean);
    clearWirdInviteQueryFromWindowUrl();
    onInviteReceived(clean);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('rifq-wird-invite-deep-link', {
          detail: { inviteCode: clean },
        })
      );
    }
  };

  // 1. فحص رابط الويب الحالي عند التشغيل
  const webCode = extractWirdInviteCodeFromUrl();
  if (webCode) {
    dispatchInvite(webCode);
  }

  // 2. فحص واستهلاك أي رابط Deep Link معلق من Android Native عند التشغيل أو العودة للواجهة
  const checkAndroidPendingInvite = async () => {
    if (!Capacitor.isNativePlatform()) return;
    try {
      const pending = await RifqNativeBridge.consumePendingWirdInvite();
      if (pending?.hasPending && pending.inviteCode) {
        dispatchInvite(pending.inviteCode);
      }
    } catch {
      // ignore on web
    }
  };

  void checkAndroidPendingInvite();

  // 3. الاستماع الفوري لحدث فتح رابط دعوة والتطبيق في الخلفية أو مفتوح على أندرويد
  if (Capacitor.isNativePlatform()) {
    RifqNativeBridge.addListener('wirdInviteDeepLink', (data) => {
      if (data?.inviteCode) {
        dispatchInvite(data.inviteCode);
      }
    })
      .then((h) => {
        listenerHandle = h;
      })
      .catch(() => {});
  }

  // 4. فحص عند عودة التطبيق للواجهة (Visibility / Focus) أو تغير الرابط (popstate)
  const handleResumeOrPopState = () => {
    const currentUrlCode = extractWirdInviteCodeFromUrl();
    if (currentUrlCode) {
      dispatchInvite(currentUrlCode);
    }
    void checkAndroidPendingInvite();
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('focus', handleResumeOrPopState);
    window.addEventListener('popstate', handleResumeOrPopState);
  }
  if (typeof document !== 'undefined') {
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        handleResumeOrPopState();
      }
    });
  }

  return () => {
    if (listenerHandle) {
      void listenerHandle.remove();
    }
    if (typeof window !== 'undefined') {
      window.removeEventListener('focus', handleResumeOrPopState);
      window.removeEventListener('popstate', handleResumeOrPopState);
    }
  };
}
