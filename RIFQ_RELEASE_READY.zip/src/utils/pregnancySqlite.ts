import {
  getNotificationPermission,
  requestNotificationPermission,
  triggerPushNotification,
} from './notifications';

/**
 * ══════════════════════════════════════════════════════════════════════════
 * قاعدة البيانات الحقيقية والموسوعة الطبية والشرعية الموثقة لقسم الحمل «رحلتك»
 * - بدون أي بيانات وهمية أو أرقام ثابتة (100% من مدخلات المستخدمة الفعلية)
 * - 9 جداول متكاملة + إشعارات حقيقية عبر Notification API / Service Worker
 * ══════════════════════════════════════════════════════════════════════════
 */

export interface PregnancyProfileRow {
  id: number;
  calculationMethod: 'lmp' | 'due_date';
  lmpDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  prePregnancyWeight?: number;
  heightCm?: number;
  bloodType: string;
  doctorName: string;
  hospitalName: string;
  createdAt: string;
}

export interface PregnancyWeightRow {
  id: number;
  pregnancyId: number;
  date: string;
  week: number;
  weightKg: number;
  bloodPressure: string;
  notes: string;
  createdAt: string;
}

export interface PregnancySymptomRow {
  id: number;
  pregnancyId: number;
  date: string;
  week: number;
  symptoms: string[];
  severity: 'mild' | 'moderate' | 'severe';
  waterCups: number;
  folicAcidTaken: boolean;
  ironTaken: boolean;
  calciumTaken: boolean;
  notes: string;
  createdAt: string;
}

export interface FetalKickRow {
  id: number;
  pregnancyId: number;
  date: string;
  startTime: string;
  endTime: string;
  durationSeconds: number;
  kicksCount: number;
  notes: string;
  createdAt: string;
}

export interface ContractionRow {
  id: number;
  pregnancyId: number;
  date: string;
  startTime: string;
  endTime: string;
  durationSeconds: number;
  intervalSeconds?: number;
  intensity: 'mild' | 'moderate' | 'strong';
  createdAt: string;
}

export interface PregnancyAppointmentRow {
  id: number;
  pregnancyId: number;
  title: string;
  doctorOrLab: string;
  appointmentType: 'checkup' | 'ultrasound' | 'lab' | 'vaccine';
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  notes: string;
  reminderEnabled: boolean;
  isCompleted: boolean;
  notified?: boolean;
  createdAt: string;
}

export interface HospitalBagItemRow {
  id: number;
  pregnancyId: number;
  category: 'mother' | 'baby' | 'documents';
  itemName: string;
  isPacked: boolean;
  createdAt: string;
}

export interface PregnancyNoteRow {
  id: number;
  pregnancyId: number;
  week: number;
  date: string;
  title: string;
  content: string;
  createdAt: string;
}

export interface PregnancyReminderRow {
  reminderKey: 'folic_iron' | 'water' | 'kicks' | 'dua';
  title: string;
  subtitle: string;
  time: string; // HH:mm
  enabled: boolean;
  lastFiredDate?: string;
}

export interface PregnancyDatabaseState {
  profile: PregnancyProfileRow | null;
  weights: PregnancyWeightRow[];
  symptoms: PregnancySymptomRow[];
  kicks: FetalKickRow[];
  contractions: ContractionRow[];
  appointments: PregnancyAppointmentRow[];
  bagItems: HospitalBagItemRow[];
  notes: PregnancyNoteRow[];
  reminders: PregnancyReminderRow[];
  pinEnabled: boolean;
  pinCode: string | null;
}

const STORAGE_KEY = 'rifq_pregnancy_journey_sqlite_v1';

const DEFAULT_REMINDERS: PregnancyReminderRow[] = [
  {
    reminderKey: 'folic_iron',
    title: 'تذكير فيتامينات الحمل وحمض الفوليك',
    subtitle: 'تذكير يومي بمكملاتكِ الموصوفة من الطبيبة',
    time: '10:00',
    enabled: false,
  },
  {
    reminderKey: 'water',
    title: 'تذكير شرب الماء والترطيب',
    subtitle: 'للحفاظ على ترطيب جسمكِ والسائل الأمنيوسي',
    time: '13:00',
    enabled: false,
  },
  {
    reminderKey: 'kicks',
    title: 'تذكير متابعة وعدّ حركات الجنين',
    subtitle: 'وقت هادئ للاطمئنان على نشاط جنينكِ اليومي',
    time: '20:00',
    enabled: false,
  },
  {
    reminderKey: 'dua',
    title: 'تذكير دعاء الحامل وورد السكينة',
    subtitle: 'لحظات إيمانية للدعاء بحفظ جنينكِ وتيسير حملكِ',
    time: '17:00',
    enabled: false,
  },
];

export const DEFAULT_HOSPITAL_BAG: Record<'mother' | 'baby' | 'documents', string[]> = {
  mother: [
    'ملابس قطنية مريحة ومفتوحة من الأمام للرضاعة (3 أطقم)',
    'حجاب قطني مريح وشال دافئ',
    'فوط صحية مخصصة لما بعد الولادة (كثافة عالية)',
    'ملابس داخلية قطنية مريحة وعالية الخصر',
    'حمالات صدر مخصصة للرضاعة وفوط ثدي قطنية',
    'حذاء خفيف مانع للانزلاق للمشي في الغرفة',
    'أدوات العناية الشخصية (فرشاة أسنان، مرطب شفاه، مشط، منشفة)',
    'شاحن هاتف بسلك طويل',
  ],
  baby: [
    'أطقم ملابس داخلية وخارجية قطنية للمولود (4 أطقم مقاس Newborn)',
    'بطانية ناعمة ولفة قماط قطنية (2)',
    'قبعة قطنية وجوارب وقفازات ناعمة لحماية الوجه',
    'حفاضات مقاس حديثي الولادة (Newborn)',
    'مناديل مبللة مائية خالية من العطور ومنشفة ناعمة',
    'مقعد السيارة المخصص لحديثي الولادة للعودة بأمان',
  ],
  documents: [
    'بطاقة الهوية الشخصية للأم والأب ودفتر العائلة',
    'بطاقة التأمين الصحي أو خطاب تحويل المستشفى',
    'ملف متابعة الحمل كاملًا (نتائج التحاليل، فصيلة الدم، وصور السونار)',
    'خطة الولادة وأرقام التواصل مع الطبيبة والمستشفى',
    'تمر وماء زمزم أو ماء شرب للتحنيك والتقوية',
  ],
};

export function loadPregnancyDb(): PregnancyDatabaseState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return {
        profile: null,
        weights: [],
        symptoms: [],
        kicks: [],
        contractions: [],
        appointments: [],
        bagItems: [],
        notes: [],
        reminders: DEFAULT_REMINDERS,
        pinEnabled: false,
        pinCode: null,
      };
    }
    const parsed = JSON.parse(raw) as Partial<PregnancyDatabaseState>;
    return {
      profile: parsed.profile ?? null,
      weights: Array.isArray(parsed.weights) ? parsed.weights : [],
      symptoms: Array.isArray(parsed.symptoms) ? parsed.symptoms : [],
      kicks: Array.isArray(parsed.kicks) ? parsed.kicks : [],
      contractions: Array.isArray(parsed.contractions) ? parsed.contractions : [],
      appointments: Array.isArray(parsed.appointments) ? parsed.appointments : [],
      bagItems: Array.isArray(parsed.bagItems) ? parsed.bagItems : [],
      notes: Array.isArray(parsed.notes) ? parsed.notes : [],
      reminders:
        Array.isArray(parsed.reminders) && parsed.reminders.length > 0
          ? parsed.reminders
          : DEFAULT_REMINDERS,
      pinEnabled: Boolean(parsed.pinEnabled),
      pinCode: parsed.pinCode ?? null,
    };
  } catch {
    return {
      profile: null,
      weights: [],
      symptoms: [],
      kicks: [],
      contractions: [],
      appointments: [],
      bagItems: [],
      notes: [],
      reminders: DEFAULT_REMINDERS,
      pinEnabled: false,
      pinCode: null,
    };
  }
}

export function savePregnancyDb(state: PregnancyDatabaseState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore storage errors
  }
}

export function wipePregnancyDb(): PregnancyDatabaseState {
  const empty: PregnancyDatabaseState = {
    profile: null,
    weights: [],
    symptoms: [],
    kicks: [],
    contractions: [],
    appointments: [],
    bagItems: [],
    notes: [],
    reminders: DEFAULT_REMINDERS,
    pinEnabled: false,
    pinCode: null,
  };
  savePregnancyDb(empty);
  return empty;
}

export interface PregnancyCalculation {
  currentWeek: number; // 1..40
  extraDays: number; // 0..6
  totalDaysPassed: number;
  remainingDays: number;
  progressPercent: number; // 0..100
  trimester: 1 | 2 | 3;
  trimesterTitle: string;
  lmpDate: string;
  dueDate: string;
}

export function calculatePregnancyStats(profile: PregnancyProfileRow): PregnancyCalculation {
  const lmp = new Date(profile.lmpDate + 'T00:00:00');
  const due = new Date(profile.dueDate + 'T00:00:00');
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const diffMs = today.getTime() - lmp.getTime();
  const daysPassed = Math.max(0, Math.min(294, Math.floor(diffMs / (1000 * 60 * 60 * 24))));
  const currentWeek = Math.max(1, Math.min(40, Math.floor(daysPassed / 7) + 1));
  const extraDays = daysPassed % 7;

  const remMs = due.getTime() - today.getTime();
  const remainingDays = Math.max(0, Math.min(280, Math.ceil(remMs / (1000 * 60 * 60 * 24))));
  const progressPercent = Math.max(0, Math.min(100, Math.round((daysPassed / 280) * 100)));

  let trimester: 1 | 2 | 3 = 1;
  let trimesterTitle = 'الثلث الأول';
  if (currentWeek >= 28) {
    trimester = 3;
    trimesterTitle = 'الثلث الثالث';
  } else if (currentWeek >= 14) {
    trimester = 2;
    trimesterTitle = 'الثلث الثاني';
  }

  return {
    currentWeek,
    extraDays,
    totalDaysPassed: daysPassed,
    remainingDays,
    progressPercent,
    trimester,
    trimesterTitle,
    lmpDate: profile.lmpDate,
    dueDate: profile.dueDate,
  };
}

export function formatArabicDateIso(iso: string): string {
  try {
    const d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString('ar-EG', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  } catch {
    return iso;
  }
}

export async function scheduleRealPregnancyNotification(
  title: string,
  body: string
): Promise<boolean> {
  let perm = getNotificationPermission();
  if (perm !== 'granted') {
    perm = await requestNotificationPermission();
  }
  if (perm !== 'granted') {
    return false;
  }
  return await triggerPushNotification({
    title,
    message: body,
    tag: `rifq-pregnancy-${Date.now()}`,
  });
}

export function checkAndFirePregnancyNotifications(): void {
  if (getNotificationPermission() !== 'granted') return;
  const db = loadPregnancyDb();
  const now = new Date();
  const todayIso = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')}`;
  const nowHm = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(
    2,
    '0'
  )}`;

  let changed = false;

  // فحص مواعيد الطبيبة
  for (const appt of db.appointments) {
    if (
      appt.reminderEnabled &&
      !appt.isCompleted &&
      !appt.notified &&
      appt.date === todayIso &&
      appt.time <= nowHm
    ) {
      appt.notified = true;
      changed = true;
      void triggerPushNotification({
        title: 'موعد متابعة الحمل — رحلتكِ',
        message: appt.doctorOrLab ? `${appt.title} لدى ${appt.doctorOrLab}` : appt.title,
        tag: `pregnancy-appt-${appt.id}`,
      });
    }
  }

  // فحص التذكيرات اليومية
  for (const rem of db.reminders) {
    if (rem.enabled && rem.lastFiredDate !== todayIso && rem.time === nowHm) {
      rem.lastFiredDate = todayIso;
      changed = true;
      void triggerPushNotification({
        title: rem.title,
        message: rem.subtitle,
        tag: `pregnancy-rem-${rem.reminderKey}-${todayIso}`,
      });
    }
  }

  if (changed) {
    savePregnancyDb(db);
  }
}

export const MANDATORY_MEDICAL_DISCLAIMER =
  'تنبيه طبي هام: جميع المعلومات الواردة للتثقيف الصحي العام من مراجع طبية معتمدة (ACOG / WHO / Mayo Clinic)، ولا تغني بأي حال عن استشارة الطبيب المختص. استشيري الطبيب عند أي عارض صحي.';

export interface PregnancyWeekInfo {
  week: number;
  trimester: 1 | 2 | 3;
  sizeComparison: string;
  lengthEstimate: string;
  weightEstimate: string;
  fetalDevelopment: string;
  motherChanges: string;
  medicalTip: string;
  medicalSource: string;
}

export const PREGNANCY_40_WEEKS: PregnancyWeekInfo[] = [
  {
    week: 1,
    trimester: 1,
    sizeComparison: 'بداية الحساب الطبي (أول يوم لآخر دورة)',
    lengthEstimate: 'غير مقاس بعد',
    weightEstimate: 'غير مقاس بعد',
    fetalDevelopment:
      'يبدأ حساب عمر الحمل طبياً من أول يوم لآخر دورة شهرية (قاعدة نيجيلي)، حيث يستعد الجسم للإباضة وتهيئة بطانة الرحم.',
    motherChanges: 'نزول الدورة الشهرية المعتادة وبداية نشاط الهرمونات المنظمة للتبويض.',
    medicalTip:
      'ابدئي بتناول 400 ميكروجرام من حمض الفوليك يومياً بعد استشارة الطبيب للوقاية من عيوب الأنبوب العصبي.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 2,
    trimester: 1,
    sizeComparison: 'مرحلة الإباضة والاستعداد للإخصاب',
    lengthEstimate: 'مجهري',
    weightEstimate: 'مجهري',
    fetalDevelopment:
      'تنضج البويضة وتنطلق في نهاية هذا الأسبوع استعداداً للتلقيح في قناة فالوب.',
    motherChanges:
      'زيادة طفيفة في إفرازات عنق الرحم وارتفاع طفيف في درجة حرارة الجسم الأساسية وقت الإباضة.',
    medicalTip:
      'احرصي على التغذية المتوازنة وشرب الماء الكافي وتجنب التدخين والأدوية غير الموصوفة.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 3,
    trimester: 1,
    sizeComparison: 'نقطة مجهرية (الكيسة الأريمية)',
    lengthEstimate: '0.1 ملم',
    weightEstimate: 'أقل من 1 جم',
    fetalDevelopment:
      'يلتقي الحيوان المنوي بالبويضة لتكوين البويضة المخصبة (الزيجوت) التي تنقسم سريعاً أثناء رحلتها نحو الرحم.',
    motherChanges: 'لا تظهر أعراض واضحة غالباً، وقد تشعر بعض النساء بتقلصات خفيفة جداً.',
    medicalTip: 'استمري على حمض الفوليك وتجنبي الأشعة السينية أو الأدوية دون استشارة الطبيب.',
    medicalSource: 'Mayo Clinic — دليل الحمل أسبوعاً بأسبوع',
  },
  {
    week: 4,
    trimester: 1,
    sizeComparison: 'بذرة الخشخاش',
    lengthEstimate: '0.1 سم',
    weightEstimate: 'أقل من 1 جم',
    fetalDevelopment:
      'تنغرس الكيسة الأريمية في جدار الرحم، وتبدأ المشيمة والكيس الأمنيوسي في التكون لحماية الجنين وتغذيته.',
    motherChanges:
      'غياب الدورة الشهرية وإفراز هرمون الحمل (hCG) الذي يظهر في اختبار الحمل المنزلي أو الدم.',
    medicalTip:
      'عند ظهور نتيجة إيجابية لاختبار الحمل، احجزي موعداً أولياً لدى طبيبة النساء والولادة.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 5,
    trimester: 1,
    sizeComparison: 'بذرة السمسم',
    lengthEstimate: '0.2 سم',
    weightEstimate: 'أقل من 1 جم',
    fetalDevelopment:
      'يتشكل الأنبوب العصبي (الذي سيصبح الدماغ والحبل الشوكي) ويبدأ القلب الأولي في التكون والنبض.',
    motherChanges:
      'بداية الشعور بالإرهاق، ليونة الثديين، أو غثيان الصباح المبكر نتيجة ارتفاع هرمونات الحمل.',
    medicalTip: 'قسّمي وجباتكِ إلى 5-6 وجبات صغيرة خفيفة لتخفيف الغثيان الصباحي.',
    medicalSource: 'Mayo Clinic / منظمة الصحة العالمية (WHO)',
  },
  {
    week: 6,
    trimester: 1,
    sizeComparison: 'حبة العدس',
    lengthEstimate: '0.5 سم',
    weightEstimate: 'أقل من 1 جم',
    fetalDevelopment:
      'ينبض القلب بانتظام (نحو 110 نبضة/دقيقة)، وتظهر براعم صغيرة ستشكل الذراعين والساقين، وتبدأ ملامح الوجه بالتشكل.',
    motherChanges:
      'زيادة الرغبة في التبول، تقلبات المزاج، ووضوح غثيان الصباح لدى كثير من الحوامل.',
    medicalTip:
      'اشربي السوائل الدافئة والماء على دفعات صغيرة، وراجعي الطبيب إذا كان القيء شديداً.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 7,
    trimester: 1,
    sizeComparison: 'حبة التوت الأزرق',
    lengthEstimate: '1.0 سم',
    weightEstimate: '1 جم',
    fetalDevelopment:
      'ينمو الدماغ والرأس بسرعة، وتتمايز براعم اليدين والقدمين، وتبدأ الكليتان الأوليتان في التشكل.',
    motherChanges: 'الوحم أو النفور من بعض الروائح والأطعمة، وزيادة إفراز اللعاب أحياناً.',
    medicalTip: 'احصلي على قسط وافر من الراحة والنوم، وتجنبي الروائح التي تثير الغثيان.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 8,
    trimester: 1,
    sizeComparison: 'حبة التوت العليق',
    lengthEstimate: '1.6 سم',
    weightEstimate: '1.5 جم',
    fetalDevelopment:
      'تتشكل أصابع اليدين والقدمين (تكون ملتحمة بغشاء رقيق)، وتبدأ الرئتان في تكوين التفرعات الهوائية الأولية.',
    motherChanges: 'زيادة حجم الدم في جسم الأم، والشعور بالانتفاخ الخفيف وتغير حجم الثديين.',
    medicalTip:
      'قومي بإجراء الفحوصات المخبرية الأساسية للثلث الأول (صورة الدم، الفصيلة، تحليل البول) بإشراف الطبيبة.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 9,
    trimester: 1,
    sizeComparison: 'حبة الكرز',
    lengthEstimate: '2.3 سم',
    weightEstimate: '2 جم',
    fetalDevelopment:
      'تكتمل الحجرات الأربع للقلب، وتتشكل الجفون التي تغطي العينين، وتظهر المفاصل الأساسية كالمرفقين والركبتين.',
    motherChanges: 'بلوغ هرمونات الحمل ذروتها في هذه الفترة مما قد يزيد الشعور بالتعب والنعاس.',
    medicalTip: 'ارتدي حمالة صدر قطنية مريحة وداعمة، وواظبي على شرب 8-10 أكواب ماء يومياً.',
    medicalSource: 'Mayo Clinic / ACOG',
  },
  {
    week: 10,
    trimester: 1,
    sizeComparison: 'حبة الفراولة',
    lengthEstimate: '3.1 سم',
    weightEstimate: '4 جم',
    fetalDevelopment:
      'ينتقل الصغير علمياً من مرحلة «المضغة» إلى «الجنين»، وتنفصل الأصابع تماماً وتبدأ براعم الأسنان بالتكون داخل اللثة.',
    motherChanges: 'قد تلاحظين بروز الأوردة السطحية نتيجة زيادة تدفق الدم لتغذية الجنين.',
    medicalTip: 'أكثري من الأطعمة الغنية بالكالسيوم وفيتامين د لدعم تكون عظام الجنين وأسنانه.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 11,
    trimester: 1,
    sizeComparison: 'ثمرة التين',
    lengthEstimate: '4.1 سم',
    weightEstimate: '7 جم',
    fetalDevelopment:
      'يركل الجنين ويتمدد داخل الكيس الأمنيوسي (حركات دقيقة لا تشعرين بها بعد)، وتبدأ الأظافر الدقيقة بالظهور.',
    motherChanges:
      'يبدأ الغثيان في الهدوء تدريجياً لدى بعض الأمهات، مع احتمال ظهور حموضة خفيفة أو إمساك.',
    medicalTip: 'تناولي الألياف الطبيعية (الخضروات الورقية والحبوب الكاملة) للوقاية من الإمساك.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 12,
    trimester: 1,
    sizeComparison: 'حبة الليمون الأخضر (اللايم)',
    lengthEstimate: '5.4 سم',
    weightEstimate: '14 جم',
    fetalDevelopment:
      'تتطور ردود الفعل الانعكاسية للجنين، ويبدأ نخاع العظم في إنتاج خلايا الدم البيضاء، وتعمل الكليتان على إفراز البول.',
    motherChanges:
      'يرتفع قاع الرحم فوق عظم الحوض، فيخف الضغط قليلاً على المثانة وتتحسن مستويات الطاقة.',
    medicalTip:
      'استشيري طبيبتكِ حول سونار نهاية الثلث الأول (الأسبوع 11-13) للاطمئنان على سلامة النمو.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 13,
    trimester: 1,
    sizeComparison: 'حبة الخوخ الصغير',
    lengthEstimate: '7.4 سم',
    weightEstimate: '23 جم',
    fetalDevelopment:
      'تتشكل بصمات الأصابع الفريدة للجنين، وتتمايز الأحبال الصوتية، وتنمو الأمعاء داخل تجويف البطن.',
    motherChanges:
      'نهاية الثلث الأول من الحمل، وبداية بروز خفيف في أسفل البطن وعودة الشهية الطبيعية.',
    medicalTip:
      'ناقشي مع طبيبتكِ البدء بمكملات الحديد والكالسيوم المناسبة مع دخول الثلث الثاني.',
    medicalSource: 'منظمة الصحة العالمية (WHO) / ACOG',
  },
  {
    week: 14,
    trimester: 2,
    sizeComparison: 'حبة الليمون الأصفر',
    lengthEstimate: '8.7 سم',
    weightEstimate: '43 جم',
    fetalDevelopment:
      'بداية الثلث الثاني؛ يستطيع الجنين تحريك عضلات وجهه ومص إبهامه، ويبدأ شعر ناعم (الزغب) بتغطية جسمه لحمايته.',
    motherChanges:
      'انحسار ملحوظ في الغثيان الصباحي وتحسن النشاط العام، مع بداية زيادة الوزن المنتظمة.',
    medicalTip: 'مارسي المشي الخفيف لمدة 20-30 دقيقة يومياً إذا سمحت طبيبتكِ بذلك.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 15,
    trimester: 2,
    sizeComparison: 'ثمرة التفاح',
    lengthEstimate: '10.1 سم',
    weightEstimate: '70 جم',
    fetalDevelopment:
      'تتصلب العظام تدريجياً (التعظم)، وتصبح الأذنان في موضعهما الطبيعي على جانبي الرأس، ويستشعر الجنين الضوء عبر جفونه.',
    motherChanges:
      'قد تشعرين باحتقان خفيف في الأنف أو حساسية في اللثة بسبب التغيرات الهرمونية وزيادة تدفق الدم.',
    medicalTip: 'استخدمي فرشاة أسنان ناعمة واهتمي بصحة الفم واللثة خلال الحمل.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 16,
    trimester: 2,
    sizeComparison: 'ثمرة الأفوكادو',
    lengthEstimate: '11.6 سم',
    weightEstimate: '100 جم',
    fetalDevelopment:
      'ينتصب الرأس والرقبة بشكل أكثر استقامة، ويضخ قلب الجنين نحو 25 لتراً من الدم يومياً، وتتحرك العينان ببطء.',
    motherChanges:
      'قد تبدأ بعض الأمهات بالشعور بأول رفرفة خفيفة لحركة الجنين (تسمى الارتكاض Quickening).',
    medicalTip:
      'ابدئي بالنوم على جانبكِ (ويفضل الجانب الأيسر) لتحسين تدفق الدم للمشيمة والجنين.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 17,
    trimester: 2,
    sizeComparison: 'ثمرة الكمثرى',
    lengthEstimate: '13.0 سم',
    weightEstimate: '140 جم',
    fetalDevelopment:
      'تبدأ طبقة الدهون البنية بالتكون تحت جلد الجنين لتنظيم حرارة جسمه، وتتقوى مهارات المص والبلع.',
    motherChanges:
      'تمدد أربطة الرحم قد يسبب ألماً خفيفاً وعابراً في جانبي أسفل البطن عند الحركة السريعة.',
    medicalTip: 'غيّري وضعيتكِ بهدوء عند القيام من السرير أو الكرسي لتقليل شد أربطة الرحم.',
    medicalSource: 'Mayo Clinic / ACOG',
  },
  {
    week: 18,
    trimester: 2,
    sizeComparison: 'ثمرة الفلفل الحلو',
    lengthEstimate: '14.2 سم',
    weightEstimate: '190 جم',
    fetalDevelopment:
      'تتطور عظام الأذن الداخلية والنهايات العصبية السمعية، فيبدأ الجنين بسماع نبضات قلبكِ وصوت تدفق الدم.',
    motherChanges:
      'انخفاض طفيف في ضغط الدم قد يسبب دوخة عند الوقوف المفاجئ، ووضوح حركة الجنين أكثر.',
    medicalTip: 'احجزي موعد السونار التفصيلي لفحص أعضاء الجنين (يُجرى عادة بين الأسبوع 18 و22).',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 19,
    trimester: 2,
    sizeComparison: 'ثمرة المانجو',
    lengthEstimate: '15.3 سم',
    weightEstimate: '240 جم',
    fetalDevelopment:
      'تتكون طبقة دهنية بيضاء واقية تسمى «الطلاء الدهني» (Vernix Caseosa) لحماية بشرة الجنين من السائل الأمنيوسي.',
    motherChanges:
      'بروز البطن بوضوح، وقد تلاحظين تصبغات جلدية طبيعية كخط الحمل الداكن في منتصف البطن.',
    medicalTip: 'استخدمي واقي شمس لطيفاً ورطّبي بشرة البطن بزيت طبيعي آمن لتقليل الجفاف والحكة.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 20,
    trimester: 2,
    sizeComparison: 'ثمرة الموز',
    lengthEstimate: '25.6 سم (من الرأس للقدم)',
    weightEstimate: '300 جم',
    fetalDevelopment:
      'منتصف رحلة الحمل (50%)! يبتلع الجنين كميات صغيرة من السائل الأمنيوسي لتدريب جهازه الهضمي، وتنتظم فترات نومه ويقظته.',
    motherChanges: 'يصل أعلى الرحم إلى مستوى السرة، وتصبح ركلات الجنين وحركاته محسوسة بوضوح.',
    medicalTip:
      'احرصي على تناول الأطعمة الغنية بالحديد مع فيتامين C لتعزيز امتصاصه والوقاية من فقر الدم.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 21,
    trimester: 2,
    sizeComparison: 'ثمرة الجزر الكبيرة',
    lengthEstimate: '26.7 سم',
    weightEstimate: '360 جم',
    fetalDevelopment:
      'تكتمل الحواجب والجفون، وتصبح حركات الذراعين والساقين أكثر تناسقاً بفضل تطور المراكز العصبية في الدماغ.',
    motherChanges: 'قد تظهر تشنجات خفيفة في عضلة الساق أثناء الليل أو انتفاخ بسيط في الكاحلين.',
    medicalTip:
      'مددي عضلات الساق قبل النوم واشربي كفايتكِ من الماء، واستشيري طبيبتكِ حول المغنيسيوم والكالسيوم.',
    medicalSource: 'Mayo Clinic / ACOG',
  },
  {
    week: 22,
    trimester: 2,
    sizeComparison: 'ثمرة البابايا الصغيرة',
    lengthEstimate: '27.8 سم',
    weightEstimate: '430 جم',
    fetalDevelopment:
      'تتطور حاسة اللمس لدى الجنين فيتحسس وجهه والحبل السري، وتزداد قوة قبضة يديه، ويسمع صوتكِ عند قراءة القرآن والدعاء.',
    motherChanges:
      'زيادة حجم الرحم قد تسبب ضغطاً خفيفاً على المعدة وشعوراً بالامتلاء سريعاً بعد الطعام.',
    medicalTip: 'تجنبي الاستلقاء مباشرة بعد الأكل لتقليل ارتجاع المريء وحرقة المعدة.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 23,
    trimester: 2,
    sizeComparison: 'ثمرة الجريب فروت',
    lengthEstimate: '28.9 سم',
    weightEstimate: '500 جم',
    fetalDevelopment:
      'تبدأ الحويصلات الهوائية في الرئتين بالتشكل وإنتاج مادة السورفاكتانت الضرورية لتنفس الهواء بعد الولادة.',
    motherChanges: 'قد تشعرين بتقلصات غير مؤلمة وعشوائية تسمى «تقلصات براكستون هيكس» التدريبية.',
    medicalTip: 'الإكثار من شرب الماء وتغيير الوضعية يساعدان على تهدئة تقلصات براكستون هيكس.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 24,
    trimester: 2,
    sizeComparison: 'كوز الذرة',
    lengthEstimate: '30.0 سم',
    weightEstimate: '600 جم',
    fetalDevelopment:
      'تتطور الأذن الداخلية المسؤولة عن التوازن، فيدرك الجنين وضعيته داخل الرحم، وتظهر براعم التذوق على لسانه.',
    motherChanges: 'يرتفع الرحم فوق السرة، وقد تلاحظين جفافاً في العينين أو البشرة.',
    medicalTip:
      'يُجرى بين الأسبوع 24 و28 فحص تحمل الجلوكوز للكشف المبكر عن سكر الحمل؛ نسّقي موعده مع طبيبتكِ.',
    medicalSource: 'منظمة الصحة العالمية (WHO) / ACOG',
  },
  {
    week: 25,
    trimester: 2,
    sizeComparison: 'ثمرة اللفت الكبيرة',
    lengthEstimate: '34.6 سم',
    weightEstimate: '660 جم',
    fetalDevelopment:
      'يكتسب جلد الجنين لوناً وردياً مع امتلاء الشعيرات الدموية وتراكم الدهون، ويستجيب للأصوات المألوفة بالحركة.',
    motherChanges: 'زيادة كثافة شعر الأم بفضل هرمونات الحمل، مع احتمال زيادة آلام أسفل الظهر.',
    medicalTip: 'استخدمي وسادة داعمة خلف الظهر أثناء الجلوس وتجنبي الوقوف لفترات طويلة.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 26,
    trimester: 2,
    sizeComparison: 'حزمة البصل الأخضر',
    lengthEstimate: '35.6 سم',
    weightEstimate: '760 جم',
    fetalDevelopment:
      'يفتح الجنين عينيه لأول مرة ويرمش، وتستمر الرئتان والجهاز المناعي في النضج التدريجي.',
    motherChanges: 'قد تشعرين بضيق خفيف في التنفس عند بذل مجهود بسبب ارتفاع الحجاب الحاجز.',
    medicalTip:
      'راقبي ضغط الدم بانتظام في زيارات المتابعة، وانتبهي لأي تورم مفاجئ في الوجه أو اليدين.',
    medicalSource: 'Mayo Clinic / ACOG',
  },
  {
    week: 27,
    trimester: 2,
    sizeComparison: 'رأس القرنبيط',
    lengthEstimate: '36.6 سم',
    weightEstimate: '875 جم',
    fetalDevelopment:
      'نهاية الثلث الثاني؛ ينشط الدماغ بشكل ملحوظ، وقد تشعرين بحركات إيقاعية خفيفة هي «حازوقة الجنين» الطبيعية.',
    motherChanges: 'زيادة الحاجة للراحة مع اقتراب الثلث الأخير من الحمل.',
    medicalTip:
      'إذا كانت فصيلة دمكِ سالبة (Rh-)، استشيري طبيبتكِ حول إبرة Anti-D الوقائية في الأسبوع 28.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 28,
    trimester: 3,
    sizeComparison: 'ثمرة الباذنجان الكبير',
    lengthEstimate: '37.6 سم',
    weightEstimate: '1000 جم (1 كجم)',
    fetalDevelopment:
      'بداية الثلث الثالث! يصل وزن الجنين إلى كيلوجرام تقريباً، وتتشكل الرموش ويزداد عدد التلافيف الدماغية.',
    motherChanges:
      'تبدأ زيارات المتابعة الطبية كل أسبوعين (من الأسبوع 28 حتى 36)، مع زيادة الشعور بثقل البطن.',
    medicalTip:
      'ابدئي بتخصيص وقت يومي لعدّ حركات الجنين (10 حركات خلال ساعتين في وقت نشاطه المعتاد).',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 29,
    trimester: 3,
    sizeComparison: 'ثمرة القرع العسلي',
    lengthEstimate: '38.6 سم',
    weightEstimate: '1150 جم',
    fetalDevelopment:
      'تزداد قوة العضلات والعظام، فيمتص الجنين يومياً نحو 250 ملجم من الكالسيوم لتقوية هيكله العظمي.',
    motherChanges: 'قد تزداد حرقة المعدة والإمساك أو صعوبة إيجاد وضعية نوم مريحة.',
    medicalTip: 'استخدمي وسادة الحمل بين الركبتين وتحت البطن أثناء النوم على الجانب.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 30,
    trimester: 3,
    sizeComparison: 'رأس الملفوف (الكرنب)',
    lengthEstimate: '39.9 سم',
    weightEstimate: '1320 جم',
    fetalDevelopment:
      'يتولى نخاع عظم الجنين إنتاج خلايا الدم الحمراء بالكامل، ويبدأ شعر الزغب بالتناقص تدريجياً.',
    motherChanges:
      'تغير مركز ثقل الجسم مع كبر حجم البطن، مما يتطلب التمهل أثناء المشي وصعود الدرج.',
    medicalTip: 'ارتدي أحذية مريحة مسطحة وابدئي بتجهيز قائمة حقيبة الولادة بهدوء.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 31,
    trimester: 3,
    sizeComparison: 'ثمرة جوز الهند',
    lengthEstimate: '41.1 سم',
    weightEstimate: '1500 جم',
    fetalDevelopment:
      'تعمل الحواس الخمس للجنين بكفاءة، وتتسع حدقة العين وتستجيب للضوء، ويكتسب الجنين وزناً أسرع.',
    motherChanges:
      'قد تلاحظين خروج قطرات بسيطة من «اللبأ» (الحليب الأولي الغني بالأجسام المضادة) من الثديين.',
    medicalTip: 'حافظي على نظافة وجفاف منطقة الثدي، ولا تقومي بعصره أثناء الحمل.',
    medicalSource: 'Mayo Clinic / WHO',
  },
  {
    week: 32,
    trimester: 3,
    sizeComparison: 'ثمرة الشمام',
    lengthEstimate: '42.4 سم',
    weightEstimate: '1700 جم',
    fetalDevelopment:
      'تكتمل أظافر اليدين والقدمين، ويصبح الجلد ناعماً غير متجعد بفضل طبقة الدهون الصحية تحته.',
    motherChanges:
      'ضيق المساحة داخل الرحم يجعل الحركات تبدو كالتفاف وتمدد قوي بدلاً من الركلات السريعة.',
    medicalTip:
      'استمري في مراقبة انتظام حركة الجنين يومياً، وراجعي الطبيب فوراً إذا لاحظتِ قلة حركته.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 33,
    trimester: 3,
    sizeComparison: 'ثمرة الأناناس',
    lengthEstimate: '43.7 سم',
    weightEstimate: '1920 جم',
    fetalDevelopment:
      'تتصلب جميع عظام الجسم ما عدا عظام الجمجمة التي تظل مرنة لتسهيل مرور الرأس عبر قناة الولادة.',
    motherChanges: 'زيادة عدد مرات التبول ليلاً وارتفاع معدل الأيض مما قد يشعركِ بالدفء الزائد.',
    medicalTip: 'قللي شرب السوائل في الساعة الأخيرة قبل النوم مع تعويضها خلال ساعات النهار.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 34,
    trimester: 3,
    sizeComparison: 'ثمرة الكنتالوب الكبيرة',
    lengthEstimate: '45.0 سم',
    weightEstimate: '2150 جم',
    fetalDevelopment:
      'يتطور الجهاز العصبي المركزي والرئتان بدرجة عالية، وغالباً ما يتخذ الجنين وضعية الرأس لأسفل استعداداً للولادة.',
    motherChanges: 'ثقل في منطقة الحوض وإرهاق أسرع عند الوقوف.',
    medicalTip: 'ارفعي قدميكِ على وسادة عند الجلوس لتخفيف تورم الكاحلين الفسيولوجي.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 35,
    trimester: 3,
    sizeComparison: 'ثمرة البطيخ الأصفر',
    lengthEstimate: '46.2 سم',
    weightEstimate: '2380 جم',
    fetalDevelopment:
      'تكتمل الكليتان تماماً، ويقوم الكبد بمعالجة الفضلات، ويكتسب الجنين نحو 200-250 جم أسبوعياً.',
    motherChanges: 'تزيد زيارات المتابعة لتصبح أسبوعية اعتباراً من الأسبوع القادم.',
    medicalTip: 'أكملي تجهيز حقيبة المستشفى لكِ وللمولود والمستندات الطبية الضرورية.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 36,
    trimester: 3,
    sizeComparison: 'رأس الخس الروماني الكبير',
    lengthEstimate: '47.4 سم',
    weightEstimate: '2620 جم',
    fetalDevelopment:
      'تقوى عضلات المص والبلع استعداداً للرضاعة الطبيعية، وتستقر الدورة الدموية والجهاز المناعي.',
    motherChanges:
      'قد ينزل رأس الجنين في الحوض («التخفف» Lightening)، فيصبح التنفس أسهل ويزداد الضغط على المثانة.',
    medicalTip: 'تعرّفي على علامات المخاض الحقيقي والفرق بينه وبين التقلصات التدريبية مع طبيبتكِ.',
    medicalSource: 'Mayo Clinic / ACOG',
  },
  {
    week: 37,
    trimester: 3,
    sizeComparison: 'حزمة السلق الكاملة',
    lengthEstimate: '48.6 سم',
    weightEstimate: '2860 جم',
    fetalDevelopment:
      'بداية الشهر التاسع المكتمل مبكراً؛ يتدرب الجنين على حركات التنفس وإمساك الأشياء بأصابعه.',
    motherChanges: 'زيادة الإفرازات المهبلية الطبيعية وتهيؤ عنق الرحم تدريجياً للولادة.',
    medicalTip: 'احرصي على الراحة النفسية وكثرة الذكر والدعاء بتيسير الولادة وتمام العافية.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 38,
    trimester: 3,
    sizeComparison: 'ثمرة اليقطين المتوسط',
    lengthEstimate: '49.8 سم',
    weightEstimate: '3080 جم',
    fetalDevelopment:
      'تكتمل وظائف الأعضاء الحيوية، ويتكون الحبل الصوتي ليكون مستعداً لأول صرخة حياة عند الولادة.',
    motherChanges: 'الشعور بضغط أو وخز خفيف في الحوض مع استقرار رأس الجنين.',
    medicalTip:
      'استخدمي مؤقت الانقباضات في التطبيق إذا شعرتِ بانقباضات منتظمة لتحديد توقيتها بدقة.',
    medicalSource: 'Mayo Clinic — دليل الحمل الطبي',
  },
  {
    week: 39,
    trimester: 3,
    sizeComparison: 'ثمرة البطيخ الصغيرة',
    lengthEstimate: '50.7 سم',
    weightEstimate: '3280 جم',
    fetalDevelopment:
      'يُصنف الجنين الآن «مكتمل النمو» (Full Term)، وتستمر الأجسام المضادة بالانتقال إليه عبر المشيمة لتعزيز مناعته.',
    motherChanges: 'ترقب علامات الولادة مثل انتظام الطلق أو نزول السدادة المخاطية أو ماء الجنين.',
    medicalTip:
      'توجهي للمستشفى فوراً عند نزول ماء الرأس أو انتظام الانقباضات كل 5 دقائق لمدة ساعة.',
    medicalSource: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    week: 40,
    trimester: 3,
    sizeComparison: 'ثمرة البطيخ الكاملة',
    lengthEstimate: '51.2 سم',
    weightEstimate: '3460 جم',
    fetalDevelopment:
      'موعد الولادة المتوقع! جنينكِ مكتمل ومستعد للقاء العالم بإذن الله. (تذكري أن الولادة الطبيعية قد تحدث قبل هذا الموعد أو بعده بأسبوع تحت إشراف الطبيب).',
    motherChanges:
      'استعداد كامل للجسم للولادة؛ تابعي مع طبيبتكِ تقييم السائل الأمنيوسي ونبض الجنين.',
    medicalTip:
      'أكثري من الدعاء والاستغفار، والتزمي بتعليمات طبيبتكِ لمتابعة ما بعد الأسبوع الأربعين إن لزم الأمر.',
    medicalSource: 'منظمة الصحة العالمية (WHO) / ACOG',
  },
];

export const RECOMMENDED_CHECKUPS = [
  {
    trimester: 1,
    title: 'تحاليل الدم الشاملة وفصيلة الدم وعامل Rh',
    timingWeeks: 'الأسبوع 6 – 10',
    description:
      'يشمل صورة الدم الكاملة (CBC) للكشف عن فقر الدم، وتحديد الفصيلة وعامل ريسوس (Rh)، وتحليل السكر الصائم، ووظائف الغدة الدرقية، وتحليل البول.',
    source: 'منظمة الصحة العالمية (WHO) / ACOG',
  },
  {
    trimester: 1,
    title: 'السونار الأولي وتأكيد عمر الحمل والنبض',
    timingWeeks: 'الأسبوع 7 – 12',
    description:
      'تأكيد موقع الحمل داخل الرحم، سماع نبض الجنين، وتحديد عمر الحمل وموعد الولادة المتوقع بدقة.',
    source: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    trimester: 1,
    title: 'فحص الشفافية القفوية بالسونار (NT Scan)',
    timingWeeks: 'الأسبوع 11 – 13',
    description: 'قياس سماكة السائل خلف رقبة الجنين للاطمئنان المبكر على سلامة النمو والتكوين.',
    source: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    trimester: 2,
    title: 'السونار التفصيلي لأعضاء الجنين (Anomaly Scan)',
    timingWeeks: 'الأسبوع 18 – 22',
    description:
      'فحص شامل ودقيق لقلب الجنين، الدماغ، العمود الفقري، الكليتين، الأطراف، وموضع المشيمة وكمية السائل الأمنيوسي.',
    source: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    trimester: 2,
    title: 'فحص تحمل الجلوكوز (سكر الحمل) وصورة الدم',
    timingWeeks: 'الأسبوع 24 – 28',
    description:
      'فحص أساسي للكشف عن سكري الحمل، وإعادة فحص الهيموجلوبين لعلاج أي نقص في الحديد قبل الثلث الثالث.',
    source: 'منظمة الصحة العالمية (WHO) / ACOG',
  },
  {
    trimester: 3,
    title: 'حقنة Anti-D للأم ذات الفصيلة السالبة (Rh-)',
    timingWeeks: 'الأسبوع 28',
    description:
      'تُعطى للأم التي تحمل فصيلة دم سالبة لحماية الجنين والحمول المستقبلية من تكوّن الأجسام المضادة.',
    source: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    trimester: 3,
    title: 'متابعة نمو الجنين ووضعيته وقياس ضغط الدم',
    timingWeeks: 'الأسبوع 32 – 40',
    description:
      'تقييم وزن الجنين، اتجاه الرأس، كمية السائل الأمنيوسي، ومراقبة ضغط الدم والزلال للوقاية من تسمم الحمل.',
    source: 'منظمة الصحة العالمية (WHO) / ACOG',
  },
];

export const ESSENTIAL_NUTRIENTS = [
  {
    name: 'حمض الفوليك (فيتامين B9)',
    dailyNeed: '400 – 600 ميكروجرام يومياً',
    importance:
      'ضروري لانقسام الخلايا والوقاية من عيوب الأنبوب العصبي (الدماغ والحبل الشوكي) لدى الجنين خاصة في الثلث الأول.',
    naturalSources: 'السبانخ، الخضروات الورقية الداكنة، العدس، الحمص، البرتقال، والحبوب المدعمة.',
    source: 'منظمة الصحة العالمية (WHO) / ACOG',
  },
  {
    name: 'الحديد (Iron)',
    dailyNeed: '27 ملجم يومياً',
    importance:
      'يدخل في تكوين الهيموجلوبين لنقل الأكسجين للجنين والمشيمة ويحمي الأم من فقر الدم والإرهاق.',
    naturalSources:
      'اللحوم الحمراء المطهية جيداً، العدس، الفاصوليا، السبانخ، التمر، مع تناول فيتامين C لتحسين الامتصاص.',
    source: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    name: 'الكالسيوم وفيتامين (د)',
    dailyNeed: '1000 ملجم كالسيوم + 600 وحدة فيتامين د',
    importance:
      'بناء عظام الجنين وأسنانه، والحفاظ على كثافة عظام الأم وانتظام عمل العضلات والأعصاب.',
    naturalSources:
      'الحليب والزبادي والأجبان المبسترة، السمسم، اللوز، السلمون المطهي، والتعرض المعتدل لأشعة الشمس.',
    source: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    name: 'البروتين والأحماض الدهنية (أوميجا 3 - DHA)',
    dailyNeed: '70 – 100 جم بروتين + 200 ملجم DHA',
    importance: 'نمو أنسجة الجنين وتطور الدماغ وشبكية العين بشكل سليم.',
    naturalSources:
      'البيض المطهي تماماً، الدواجن، الأسماك منخفضة الزئبق (كالسلمون والسردين المطهيين)، الجوز، والبقوليات.',
    source: 'إدارة الغذاء والدواء (FDA) / ACOG',
  },
];

export const FOODS_TO_AVOID = [
  {
    title: 'اللحوم والدواجن والبيض غير المطهو جيداً',
    reason: 'تجنباً لخطر البكتيريا (السالمونيلا والليستيريا) وطفيلي التوكسوبلازما.',
    source: 'FDA / ACOG',
  },
  {
    title: 'الأجبان والحليب غير المبستر',
    reason:
      'قد تحتوي على بكتيريا الليستيريا الخطيرة على الحمل؛ اختاري دائماً المنتجات المكتوب عليها «مبستر».',
    source: 'منظمة الصحة العالمية (WHO)',
  },
  {
    title: 'الأسماك عالية الزئبق (كالقرش وأبو سيف والماكريل الملكي)',
    reason: 'الزئبق المرتفع قد يؤثر سلباً على تطور الجهاز العصبي للجنين.',
    source: 'إدارة الغذاء والدواء (FDA)',
  },
  {
    title: 'الإفراط في الكافيين (الحد الأقصى 200 ملجم يومياً)',
    reason: 'ما يعادل كوباً واحداً صغيراً من القهوة؛ لأن الإفراط قد يرفع ضغط الدم ويقلل امتصاص الحديد.',
    source: 'الكلية الأمريكية لأطباء النساء والتوليد (ACOG)',
  },
  {
    title: 'تناول أي أدوية أو أعشاب مركزة دون استشارة الطبيب',
    reason: 'بعض الأدوية المسكنة والأعشاب قد تسبب تقلصات رحمية أو تؤثر على الجنين.',
    source: 'منظمة الصحة العالمية (WHO)',
  },
];

export const URGENT_WARNING_SIGNS = [
  {
    sign: 'نزيف مهبلي أو نزول سوائل مائية من المهبل',
    detail: 'في أي أسبوع من الحمل يستوجب التقييم الطبي الفوري.',
  },
  {
    sign: 'صداع شديد مستمر مع تشوش في الرؤية أو زغللة',
    detail: 'قد يكون مؤشراً على ارتفاع ضغط الدم أو تسمم الحمل.',
  },
  {
    sign: 'تورم مفاجئ وملحوظ في الوجه أو اليدين أو حول العينين',
    detail: 'يستدعي قياس ضغط الدم وفحص الزلال لدى الطبيب فوراً.',
  },
  {
    sign: 'انخفاض ملحوظ أو توقف في حركة الجنين المعتادة',
    detail: 'خاصة في الثلث الثالث (أقل من 10 حركات خلال ساعتين في وقت نشاطه).',
  },
  {
    sign: 'ألم شديد ومستمر في البطن أو انقباضات منتظمة قبل الأسبوع 37',
    detail: 'لاستبعاد المخاض المبكر وتلقي الرعاية الطبية اللازمة.',
  },
  {
    sign: 'ارتفاع درجة الحرارة (حمى) أو حرقة شديدة أثناء التبول',
    detail: 'لعلاج أي التهاب مبكراً بأدوية آمنة يصفها الطبيب.',
  },
];

export const PREGNANCY_DUAS_AND_FIQH = [
  {
    category: 'dua' as const,
    title: 'دعاء طلب الذرية الطيبة الصالحة',
    arabicText: '﴿رَبِّ هَبْ لِي مِن لَّدُنكَ ذُرِّيَّةً طَيِّبَةً إِنَّكَ سَمِيعُ الدُّعَاءِ﴾',
    explanation:
      'دعاء نبي الله زكريا عليه السلام في طلب الذرية الطيبة المباركة في دينها وخلقها وعافيتها.',
    source: 'سورة آل عمران: الآية 38',
  },
  {
    category: 'dua' as const,
    title: 'دعاء قرة العين في الأزواج والذرية',
    arabicText:
      '﴿رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا﴾',
    explanation: 'من دعاء عباد الرحمن في القرآن الكريم بصلاح الذرية وسلامتها وهدايتها.',
    source: 'سورة الفرقان: الآية 74',
  },
  {
    category: 'dua' as const,
    title: 'شكر الله والدعاء بصلاح الذرية (آية الأحقاف)',
    arabicText:
      '﴿رَبِّ أَوْزِعْنِي أَنْ أَشْكُرَ نِعْمَتَكَ الَّتِي أَنْعَمْتَ عَلَيَّ وَعَلَىٰ وَالِدَيَّ وَأَنْ أَعْمَلَ صَالِحًا تَرْضَاهُ وَأَصْلِحْ لِي فِي ذُرِّيَّتِي إِنِّي تُبْتُ إِلَيْكَ وَإِنِّي مِنَ الْمُسْلِمِينَ﴾',
    explanation:
      'جاءت هذه الآية الكريمة بعد ذكر حمل الأم ووضعه كرهاً، وفيها الجمع بين شكر النعمة والدعاء بصلاح الذرية.',
    source: 'سورة الأحقاف: الآية 15',
  },
  {
    category: 'dua' as const,
    title: 'دعاء تفريج الكرب وتيسير العسير (عند التعب والطلق)',
    arabicText:
      '«لَا إِلَهَ إِلَّا اللَّهُ الْعَظِيمُ الْحَلِيمُ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ الْعَرْشِ الْعَظِيمِ، لَا إِلَهَ إِلَّا اللَّهُ رَبُّ السَّمَاوَاتِ وَرَبُّ الْأَرْضِ وَرَبُّ الْعَرْشِ الْكَرِيمِ»',
    explanation:
      'حديث صحيح كان النبي ﷺ يدعو به عند الكرب والشدة، وهو من أعظم ما تدعو به الحامل عند تعب الحمل وعند المخاض.',
    source: 'صحيح البخاري (6346) وصحيح مسلم (2730)',
  },
  {
    category: 'dua' as const,
    title: 'دعاء التيسير: اللهم لا سهل إلا ما جعلته سهلاً',
    arabicText:
      '«اللَّهُمَّ لَا سَهْلَ إِلَّا مَا جَعَلْتَهُ سَهْلًا، وَأَنْتَ تَجْعَلُ الْحَزْنَ إِذَا شِئْتَ سَهْلًا»',
    explanation: 'دعاء جامع لتيسير الأمور الصعبة وتفويض الأمر لله سبحانه في تيسير الحمل والولادة.',
    source: 'رواه ابن حبان في صحيحه (974) وصححه الألباني',
  },
  {
    category: 'dua' as const,
    title: 'تعويذ الجنين والمولود بكلمات الله التامة',
    arabicText:
      '«أُعِيذُكَ بِكَلِمَاتِ اللَّهِ التَّامَّةِ، مِنْ كُلِّ شَيْطَانٍ وَهَامَّةٍ، وَمِنْ كُلِّ عَيْنٍ لَامَّةٍ»',
    explanation:
      'كان النبي ﷺ يعوّذ بهما الحسن والحسين رضي الله عنهما، ويُشرع للأم والأب تحصين طفلهما به.',
    source: 'صحيح البخاري (3371)',
  },
  {
    category: 'fiqh' as const,
    title: 'صلاة الحامل إذا شقّ عليها القيام أو السجود',
    arabicText:
      'قال النبي ﷺ لعمران بن حصين رضي الله عنه: «صَلِّ قَائِمًا، فَإِنْ لَمْ تَسْتَطِعْ فَقَاعِدًا، فَإِنْ لَمْ تَسْتَطِعْ فَعَلَى جَنْبٍ»',
    explanation:
      'تجب الصلاة على الحامل في وقتها؛ فإن شقّ عليها القيام لثقل الحمل أو الدوار جاز لها أن تصلي جالسة وتومئ بالركوع والسجود إذا عجزت عن السجود على الأرض، ولا تسقط عنها الصلاة ما دام عقلها حاضراً.',
    source: 'صحيح البخاري (1117) — المجمع الفقهي الإسلامي',
  },
  {
    category: 'fiqh' as const,
    title: 'حكم صيام الحامل في رمضان إذا خافت على نفسها أو جنينها',
    arabicText:
      'قال النبي ﷺ: «إِنَّ اللَّهَ وَضَعَ عَنِ الْمُسَافِرِ نِصْفَ الصَّلَاةِ وَالصَّوْمَ، وَعَنِ الْحُبْلَى وَالْمُرْضِعِ»',
    explanation:
      'إذا خافت الحامل على نفسها أو جنينها الضرر من الصيام بتقدير الطبيب الثقة أو غلبة الظن، يرخص لها الفطر وتقضي الأيام التي أفطرتها متى استطاعت بعد الولادة.',
    source: 'رواه أبو داود (2408) والترمذي (715) وحسنه',
  },
  {
    category: 'fiqh' as const,
    title: 'أحكام الدم أثناء الحمل وعند الولادة والنفاس',
    arabicText:
      'النفاس هو الدم الخارج بسبب الولادة (معها أو بعدها أو قبلها بيومين أو ثلاثة مع أمارة المخاض).',
    explanation:
      'الدم الذي قد تراه الحامل في أشهر الحمل الأولى بدون مخاض يُعدّ عند جمهور الفقهاء دم فساد (استحاضة) تتوضأ فيه لكل صلاة وتصلي. أما الدم المصاحب للطلق والولادة وما بعدها فهو نفاس تترك فيه الصلاة والصيام حتى تطهر (أو تتم أربعين يوماً عند الجمهور).',
    source: 'الموسوعة الفقهية الكويتية / فقه السنة',
  },
  {
    category: 'fiqh' as const,
    title: 'سنن استقبال المولود: التحنيك، التسمية، والعقيقة',
    arabicText:
      'قال النبي ﷺ: «كُلُّ غُلَامٍ رَهِينَةٌ بِعَقِيقَتِهِ، تُذْبَحُ عَنْهُ يَوْمَ سَابِعِهِ، وَيُحْلَقُ، وَيُسَمَّى»',
    explanation:
      'يُستحب عند ولادة الطفل تحنيكه بيسير من تمر، واختيار اسم حسن له، والعقيقة عنه في اليوم السابع (شاتان عن الغلام وشاة عن الجارية لمن استطاع)، وحلق شعر رأسه والتصدق بوزنه فضة.',
    source: 'رواه أبو داود (2838) والترمذي (1522) وصححه',
  },
];
