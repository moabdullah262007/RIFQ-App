export interface MihrabVerificationResponse {
  success: boolean;
  isMosqueMihrab: boolean;
  confidence: number;
  reasonAr: string;
  detectedFeatures: string[];
  error?: string;
}

/**
 * Sends a captured image of the mosque mihrab to the real AI Vision server endpoint (/api/verify-mihrab)
 * powered by Gemini 3.8 Flash.
 */
export async function verifyMosqueMihrabWithVision(
  imageBase64: string,
  prayerKey: string,
  prayerNameAr: string
): Promise<MihrabVerificationResponse> {
  try {
    const res = await fetch('/api/verify-mihrab', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        imageBase64,
        mimeType: 'image/jpeg',
        prayerKey,
        prayerNameAr,
      }),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      return {
        success: false,
        isMosqueMihrab: false,
        confidence: 0,
        reasonAr:
          errData?.reasonAr ||
          'تعذر الاتصال بخدمة التحقق الذكي عبر الخادم. يرجى التأكد من تشغيل الخادم والاتصال بالإنترنت.',
        detectedFeatures: [],
        error: errData?.error || `HTTP error ${res.status}`,
      };
    }

    const data: MihrabVerificationResponse = await res.json();
    return data;
  } catch (err: any) {
    console.error('Failed to verify mihrab vision:', err);
    return {
      success: false,
      isMosqueMihrab: false,
      confidence: 0,
      reasonAr: 'حدث خطأ في الاتصال بالشبكة أثناء إرسال الصورة للتحقق.',
      detectedFeatures: [],
      error: err?.message,
    };
  }
}
