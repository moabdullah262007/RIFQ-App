import { TahfeezPlan, TahfeezReviewItem, TahfeezStats } from '../types';
import { SURAH_LIST, AyahItem } from '../data/quranData';

const PLANS_KEY = 'rifq_tahfeez_plans_v2_real';
const REVIEWS_KEY = 'rifq_tahfeez_reviews_v2_real';
const STATS_KEY = 'rifq_tahfeez_stats_v2_real';
const RECITER_KEY = 'rifq_tahfeez_reciter_v1';

const LEGACY_TAHFEEZ_KEYS = [
  'rifq_tahfeez_plans_v1',
  'rifq_tahfeez_reviews_v1',
  'rifq_tahfeez_stats_v1',
];

function purgeLegacyTahfeezKeys(): void {
  try {
    for (const k of LEGACY_TAHFEEZ_KEYS) {
      if (localStorage.getItem(k) !== null) {
        localStorage.removeItem(k);
      }
    }
  } catch {
    // ignore
  }
}

export interface ReciterInfo {
  id: string;
  name: string;
  subname: string;
  subfolder: string; // for everyayah.com
}

export const TAHFEEZ_RECITERS: ReciterInfo[] = [
  {
    id: 'alafasy',
    name: 'مشاري راشد العفاسي',
    subname: 'حفص عن عاصم (مرتل)',
    subfolder: 'Alafasy_128kbps',
  },
  {
    id: 'abdulbasit',
    name: 'عبد الباسط عبد الصمد',
    subname: 'المصحف المرتل',
    subfolder: 'Abdul_Basit_Murattal_192kbps',
  },
  {
    id: 'husary',
    name: 'محمود خليل الحصري',
    subname: 'المصحف المعلم / المرتل',
    subfolder: 'Husary_128kbps',
  },
  {
    id: 'minshawy',
    name: 'محمد صديق المنشاوي',
    subname: 'المصحف المرتل الخاشع',
    subfolder: 'Minshawy_Murattal_128kbps',
  },
];

// Spaced Repetition stages: Day 0, 1, 3, 7, 14, 30
export const SPACED_INTERVALS = [
  { day: 0, title: 'حفظ جديد (اليوم 0)' },
  { day: 1, title: 'مراجعة أولى (اليوم 1)' },
  { day: 3, title: 'مراجعة ثانية (اليوم 3)' },
  { day: 7, title: 'مراجعة ثالثة (اليوم 7)' },
  { day: 14, title: 'مراجعة رابعة (اليوم 14)' },
  { day: 30, title: 'مراجعة نهائية (اليوم 30)' },
];

export function getAudioAyahUrl(reciterId: string, surahNum: number, ayahNum: number): string {
  const reciter = TAHFEEZ_RECITERS.find((r) => r.id === reciterId) || TAHFEEZ_RECITERS[0];
  const sStr = String(surahNum).padStart(3, '0');
  const aStr = String(ayahNum).padStart(3, '0');
  return `https://everyayah.com/data/${reciter.subfolder}/${sStr}${aStr}.mp3`;
}

const MOCK_PLAN_IDS = new Set(['plan_mulk', 'plan_kahf', 'plan_juz30']);
const MOCK_REVIEW_IDS = new Set(['rev_1', 'rev_2', 'rev_3']);

export function loadTahfeezPlans(): TahfeezPlan[] {
  purgeLegacyTahfeezKeys();
  try {
    const raw = localStorage.getItem(PLANS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter((p) => p && !MOCK_PLAN_IDS.has(p.id));
      }
    }
  } catch (e) {
    console.warn(e);
  }
  return [];
}

export function saveTahfeezPlans(plans: TahfeezPlan[]): void {
  try {
    localStorage.setItem(PLANS_KEY, JSON.stringify(plans));
  } catch (e) {
    console.warn(e);
  }
}

export function loadTahfeezReviews(): TahfeezReviewItem[] {
  purgeLegacyTahfeezKeys();
  try {
    const raw = localStorage.getItem(REVIEWS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed.filter(
          (r) => r && !MOCK_REVIEW_IDS.has(r.id) && !MOCK_PLAN_IDS.has(r.planId)
        );
      }
    }
  } catch (e) {
    console.warn(e);
  }
  return [];
}

export function saveTahfeezReviews(reviews: TahfeezReviewItem[]): void {
  try {
    localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
  } catch (e) {
    console.warn(e);
  }
}

export function loadTahfeezStats(): TahfeezStats {
  purgeLegacyTahfeezKeys();
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.warn(e);
  }
  return {
    totalMemorizedAyahs: 0,
    totalMemorizedJuz: 0,
    completedSurahsCount: 0,
    streakDays: 0,
    totalRepetitions: 0,
    quizzesPassed: 0,
  };
}

export function saveTahfeezStats(stats: TahfeezStats): void {
  try {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  } catch (e) {
    console.warn(e);
  }
}

export function loadSelectedTahfeezReciter(): string {
  try {
    return localStorage.getItem(RECITER_KEY) || 'alafasy';
  } catch {
    return 'alafasy';
  }
}

export function saveSelectedTahfeezReciter(reciterId: string): void {
  try {
    localStorage.setItem(RECITER_KEY, reciterId);
  } catch (e) {
    console.warn(e);
  }
}
