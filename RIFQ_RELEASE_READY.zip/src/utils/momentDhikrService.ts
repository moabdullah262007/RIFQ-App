import { MOMENT_DHIKR_DATABASE, MomentDhikrItem } from '../data/momentDhikrData';
import {
  isNotificationChannelEnabled,
  RIFQ_NOTIFICATION_CHANNELS,
  hasNotificationFired,
  markNotificationFired,
  syncFullNotificationScheduleWithServiceWorker,
  triggerPushNotification,
  NotificationManager,
} from './notifications';
import { addNotification } from './storage';

const SETTINGS_STORAGE_KEY = 'rifq_dhikr_notification_settings_v1';
const HISTORY_STORAGE_KEY = 'rifq_dhikr_notification_history_v1';
const LOG_STORAGE_KEY = 'rifq_dhikr_notifications_log_v1';
const FAVORITES_STORAGE_KEY = 'rifq_dhikr_moment_favorites_v1';
const LAST_SLOT_DATE_PREFIX = 'rifq_dhikr_slot_fired_';

export interface DhikrNotificationSettings {
  enabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  fajrTime: string; // "05:00"
  duhaTime: string; // "09:00"
  dhuhrTime: string; // "13:00"
  asrTime: string; // "17:00"
  nightTime: string; // "21:00"
}

export interface NotificationLogItem {
  id: string;
  dhikrId: string;
  dhikrText: string;
  source: string;
  slotLabel: string;
  sentAt: string; // ISO string
  opened: boolean;
}

const DEFAULT_SETTINGS: DhikrNotificationSettings = {
  enabled: true,
  soundEnabled: true,
  vibrationEnabled: true,
  fajrTime: '05:00',
  duhaTime: '09:00',
  dhuhrTime: '13:00',
  asrTime: '17:00',
  nightTime: '21:00',
};

// ─── Settings Storage ───
export function loadDhikrNotificationSettings(): DhikrNotificationSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    }
  } catch (e) {
    console.debug('Failed to parse dhikr notification settings', e);
  }
  return DEFAULT_SETTINGS;
}

export function saveDhikrNotificationSettings(settings: DhikrNotificationSettings): void {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    syncFullNotificationScheduleWithServiceWorker();
  } catch (e) {
    console.debug('Failed to save dhikr notification settings', e);
  }
}

// ─── Favorites ───
export function loadMomentFavorites(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return [];
}

export function toggleMomentFavorite(dhikrId: string): boolean {
  const favs = loadMomentFavorites();
  const exists = favs.includes(dhikrId);
  const updated = exists ? favs.filter((id) => id !== dhikrId) : [...favs, dhikrId];
  try {
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return !exists;
}

// ─── History & Rotation Algorithm ───
interface HistoryRecord {
  lastDate: string; // YYYY-MM-DD
  servedIdsToday: string[];
  allServedIds: string[];
}

function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function loadHistory(): HistoryRecord {
  const today = getTodayString();
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (raw) {
      const parsed: HistoryRecord = JSON.parse(raw);
      if (parsed.lastDate !== today) {
        parsed.lastDate = today;
        parsed.servedIdsToday = [];
      }
      return parsed;
    }
  } catch {
    // ignore
  }
  return {
    lastDate: today,
    servedIdsToday: [],
    allServedIds: [],
  };
}

function saveHistory(history: HistoryRecord): void {
  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
  } catch {
    // ignore
  }
}

/**
 * Selects an authentic dhikr for a given slot or request with no duplicates today
 */
export function getNextDiverseDhikr(
  preferredSlot?: 'fajr' | 'duha' | 'dhuhr' | 'asr' | 'night'
): MomentDhikrItem {
  const history = loadHistory();
  const favorites = loadMomentFavorites();

  // If specific slot requested, check slot matching items first
  let candidates = MOMENT_DHIKR_DATABASE;
  if (preferredSlot) {
    const slotMatches = candidates.filter((item) => item.timeSlot === preferredSlot);
    if (slotMatches.length > 0) {
      const unservedTodaySlot = slotMatches.filter((i) => !history.servedIdsToday.includes(i.id));
      if (unservedTodaySlot.length > 0) {
        candidates = unservedTodaySlot;
      } else {
        candidates = slotMatches;
      }
    }
  }

  // Filter out dhikrs already shown today to guarantee zero same-day repetition
  let eligible = candidates.filter((item) => !history.servedIdsToday.includes(item.id));
  if (eligible.length === 0) {
    eligible = MOMENT_DHIKR_DATABASE.filter((item) => !history.servedIdsToday.includes(item.id));
  }

  if (eligible.length === 0) {
    history.servedIdsToday = [];
    eligible = MOMENT_DHIKR_DATABASE;
  }

  // Prioritize favorites 30% of the time if available
  const favoriteCandidates = eligible.filter((item) => favorites.includes(item.id));
  let chosen: MomentDhikrItem;
  if (favoriteCandidates.length > 0 && Math.random() < 0.35) {
    chosen = favoriteCandidates[Math.floor(Math.random() * favoriteCandidates.length)];
  } else {
    const unservedEver = eligible.filter((item) => !history.allServedIds.includes(item.id));
    if (unservedEver.length > 0) {
      chosen = unservedEver[Math.floor(Math.random() * unservedEver.length)];
    } else {
      chosen = eligible[Math.floor(Math.random() * eligible.length)];
    }
  }

  // Update history
  history.servedIdsToday.push(chosen.id);
  if (!history.allServedIds.includes(chosen.id)) {
    history.allServedIds.push(chosen.id);
  }
  if (history.allServedIds.length >= MOMENT_DHIKR_DATABASE.length) {
    history.allServedIds = [chosen.id];
  }
  saveHistory(history);

  return chosen;
}

/**
 * Gets the current active Dhikr of the Moment according to the current time of day
 */
export function getCurrentMomentDhikr(): MomentDhikrItem {
  const now = new Date();
  const hour = now.getHours();

  if (hour >= 4 && hour < 8) {
    return MOMENT_DHIKR_DATABASE.find((d) => d.id === 'morning-1') || MOMENT_DHIKR_DATABASE[0];
  } else if (hour >= 8 && hour < 12) {
    return MOMENT_DHIKR_DATABASE.find((d) => d.id === 'morning-3') || MOMENT_DHIKR_DATABASE[2];
  } else if (hour >= 12 && hour < 16) {
    return MOMENT_DHIKR_DATABASE.find((d) => d.id === 'general-5') || MOMENT_DHIKR_DATABASE[12];
  } else if (hour >= 16 && hour < 20) {
    return MOMENT_DHIKR_DATABASE.find((d) => d.id === 'evening-2') || MOMENT_DHIKR_DATABASE[10];
  } else {
    return MOMENT_DHIKR_DATABASE.find((d) => d.id === 'sleep-1') || MOMENT_DHIKR_DATABASE[11];
  }
}

// ─── Notification Logs ───
export function loadNotificationLogs(): NotificationLogItem[] {
  try {
    const raw = localStorage.getItem(LOG_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    // ignore
  }
  return [];
}

export function recordNotificationLog(
  log: Omit<NotificationLogItem, 'id' | 'sentAt' | 'opened'>
): void {
  const logs = loadNotificationLogs();
  const newLog: NotificationLogItem = {
    id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    ...log,
    sentAt: new Date().toISOString(),
    opened: false,
  };
  const updated = [newLog, ...logs].slice(0, 50);
  try {
    localStorage.setItem(LOG_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
}

export function markNotificationLogOpened(dhikrId: string): void {
  const logs = loadNotificationLogs();
  const updated = logs.map((l) => (l.dhikrId === dhikrId ? { ...l, opened: true } : l));
  try {
    localStorage.setItem(LOG_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
}

// ─── Audio & Vibration (100% Offline via Web Audio & Navigator) ───
export function playNotificationChime(): void {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    const tones = [523.25, 659.25, 783.99, 1046.5];
    const startTime = ctx.currentTime + 0.05;

    tones.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, startTime + idx * 0.12);

      gain.gain.setValueAtTime(0, startTime + idx * 0.12);
      gain.gain.linearRampToValueAtTime(0.2, startTime + idx * 0.12 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, startTime + idx * 0.12 + 1.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime + idx * 0.12);
      osc.stop(startTime + idx * 0.12 + 1.3);
    });
  } catch (err) {
    console.debug('Notification audio playback failed:', err);
  }
}

export function triggerNotificationHaptic(): void {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([120, 80, 200]);
    } catch {
      // ignore
    }
  }
}

// ─── Real Notification Dispatcher ───
export interface DispatchDhikrNotificationParams {
  title: string;
  dhikr: MomentDhikrItem;
  slotLabel: string;
  signatureKey?: string;
  bypassChannelCheck?: boolean;
}

export async function dispatchRealDhikrNotification({
  title,
  dhikr,
  slotLabel,
  signatureKey,
  bypassChannelCheck = false,
}: DispatchDhikrNotificationParams): Promise<boolean> {
  if (!bypassChannelCheck && !isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.azkar)) {
    return false;
  }

  const settings = loadDhikrNotificationSettings();

  if (settings.soundEnabled) {
    playNotificationChime();
  }

  if (settings.vibrationEnabled) {
    triggerNotificationHaptic();
  }

  recordNotificationLog({
    dhikrId: dhikr.id,
    dhikrText: dhikr.text,
    source: dhikr.source,
    slotLabel,
  });

  // Record in in-app Notification Center ("مركز التذكيرات والإشعارات")
  addNotification({
    title,
    message: `${dhikr.text} — ${dhikr.source}`,
    time: 'الآن',
    read: false,
    type: 'reminder',
    actionScreen: 'moment_dhikr',
    actionDhikrId: dhikr.id,
    signatureKey,
  });

  const bodyText = `${dhikr.text}\n— ${dhikr.source}`;
  const tag = `rifq-moment-dhikr-${dhikr.id}-${Date.now()}`;

  // Dispatch real Android System Notification (or Web Notification)
  return await triggerPushNotification({
    title,
    message: bodyText,
    screen: 'moment_dhikr',
    dhikrId: dhikr.id,
    channelId: RIFQ_NOTIFICATION_CHANNELS.azkar,
    signatureKey,
    tag,
    bypassChannelCheck,
    recordInCenter: false, // Already added to in-app Notification Center above
  });
}

// ─── Test Notification ───
export async function sendTestMomentNotification(): Promise<{
  success: boolean;
  message: string;
}> {
  let enabled = await NotificationManager.areNotificationsEnabled();
  if (!enabled) {
    enabled = await NotificationManager.requestPermission();
    if (!enabled) {
      return {
        success: false,
        message: 'إشعارات الجهاز متوقفة — يرجى السماح بالإشعارات من إعدادات التطبيق.',
      };
    }
  }

  const testDhikr = getNextDiverseDhikr('duha');
  const dispatched = await dispatchRealDhikrNotification({
    title: '🌅 رِفْق | ذكر اللحظة (إشعار تجريبي)',
    dhikr: testDhikr,
    slotLabel: 'إشعار تجريبي فوري',
    bypassChannelCheck: true,
  });

  if (dispatched) {
    return {
      success: true,
      message: 'تم إرسال إشعار ذكر اللحظة في شريط إشعارات الجهاز ومركز التذكيرات بنجاح!',
    };
  } else {
    return {
      success: false,
      message: 'تعذر إظهار الإشعار في نظام الجهاز — تحقق من السماح بالإشعارات.',
    };
  }
}

// ─── Scheduler Engine ───
let schedulerIntervalId: number | null = null;

function timeToMinutes(timeStr: string): number {
  if (!timeStr || !timeStr.includes(':')) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/**
 * Checks the 5 scheduled notification times and fires if due
 */
export async function checkAndTriggerDueDhikrNotifications(): Promise<void> {
  if (!isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.azkar)) return;

  const settings = loadDhikrNotificationSettings();
  if (!settings.enabled) return;

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const todayDate = getTodayString();

  const slotTimes: {
    slot: 'fajr' | 'duha' | 'dhuhr' | 'asr' | 'night';
    time: string;
    title: string;
    labelAr: string;
  }[] = [
    {
      slot: 'fajr',
      time: settings.fajrTime,
      title: '🌅 رِفْق | بداية يومك بذكر الله',
      labelAr: 'إشعار الفجر',
    },
    {
      slot: 'duha',
      time: settings.duhaTime,
      title: '☀️ رِفْق | لا تنسَ ذكر الله',
      labelAr: 'إشعار الضحى',
    },
    {
      slot: 'dhuhr',
      time: settings.dhuhrTime,
      title: '🕛 رِفْق | وقت الذكر',
      labelAr: 'إشعار الظهر',
    },
    {
      slot: 'asr',
      time: settings.asrTime,
      title: '🌇 رِفْق | ذكر المساء',
      labelAr: 'إشعار العصر',
    },
    {
      slot: 'night',
      time: settings.nightTime,
      title: '🌙 رِفْق | قبل النوم',
      labelAr: 'إشعار الليل',
    },
  ];

  for (const { slot, time, title, labelAr } of slotTimes) {
    const scheduledMinutes = timeToMinutes(time);
    const sig = `${todayDate}_moment_${slot}_${time}`;
    const key = `${LAST_SLOT_DATE_PREFIX}${slot}`;
    const lastFired = localStorage.getItem(key);

    // Resilient window: from scheduled minute up to 45 minutes after
    if (
      currentMinutes >= scheduledMinutes &&
      currentMinutes <= scheduledMinutes + 45 &&
      lastFired !== sig &&
      !hasNotificationFired(sig)
    ) {
      localStorage.setItem(key, sig);
      markNotificationFired(sig);
      const dhikr = getNextDiverseDhikr(slot);
      await dispatchRealDhikrNotification({
        title,
        dhikr,
        slotLabel: labelAr,
      });
    }
  }
}

/**
 * Starts the background timer in the application
 */
export function startDhikrNotificationScheduler(): void {
  if (schedulerIntervalId) return;

  // Run initial check
  checkAndTriggerDueDhikrNotifications();

  // Check every 20 seconds for clock accuracy
  schedulerIntervalId = window.setInterval(() => {
    checkAndTriggerDueDhikrNotifications();
  }, 20 * 1000);
}

export function stopDhikrNotificationScheduler(): void {
  if (schedulerIntervalId) {
    clearInterval(schedulerIntervalId);
    schedulerIntervalId = null;
  }
}
