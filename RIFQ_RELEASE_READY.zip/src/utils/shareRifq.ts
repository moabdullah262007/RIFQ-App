/**
 * Official RIFQ Share Utility (📤 مشاركة رِفْق)
 *
 * CRITICAL RULE:
 * Never share Google AI Studio URLs, Cloud Run preview URLs (`*.run.app`),
 * localhost, or development URLs (`window.location.href`).
 * Always use the official RIFQ Telegram channel: https://t.me/RIFQ_App
 */

import {
  buildWirdGroupInviteUrl,
  sanitizeWirdInviteCode,
  shareWirdGroupInviteNatively,
} from './wirdInviteService';

export const OFFICIAL_RIFQ_TELEGRAM_CHANNEL = 'https://t.me/RIFQ_App';
export const OFFICIAL_RIFQ_TELEGRAM_BOT = 'https://t.me/Quuran4_bot';
export const OFFICIAL_RIFQ_BOT_USERNAME = '@Quuran4_bot';

export const RIFQ_OFFICIAL_LINKS = {
  telegramChannel: OFFICIAL_RIFQ_TELEGRAM_CHANNEL,
  telegramBot: OFFICIAL_RIFQ_TELEGRAM_BOT,
  telegramBotHandle: OFFICIAL_RIFQ_BOT_USERNAME,
} as const;

export function getOfficialRifqShareText(): string {
  return [
    '🌙 جرّب تطبيق رِفْق',
    'تطبيق إسلامي يجمع القرآن والأذكار والمواقيت والعديد من المحتويات والأدوات المفيدة.',
    '',
    'تابع قناة رِفْق:',
    OFFICIAL_RIFQ_TELEGRAM_CHANNEL,
  ].join('\n');
}

export function getRifqShareMessage(): string {
  return getOfficialRifqShareText();
}

export function getRifqWhatsAppShareUrl(): string {
  return `https://wa.me/?text=${encodeURIComponent(getOfficialRifqShareText())}`;
}

export function getRifqTelegramShareUrl(): string {
  return `https://t.me/share/url?url=${encodeURIComponent(
    OFFICIAL_RIFQ_TELEGRAM_CHANNEL
  )}&text=${encodeURIComponent(
    '🌙 جرّب تطبيق رِفْق\nتطبيق إسلامي يجمع القرآن والأذكار والمواقيت والعديد من المحتويات والأدوات المفيدة.'
  )}`;
}

export function getRifqGroupInviteShareText(params: {
  groupName: string;
  category: string;
  inviteCode: string;
  description?: string;
}): string {
  const cleanCode = sanitizeWirdInviteCode(params.inviteCode);
  const inviteUrl = buildWirdGroupInviteUrl(cleanCode);
  const lines = [
    `انضم إلينا في مجموعة «${params.groupName}» في قسم وِرد بتطبيق رِفْق | RIFQ`,
  ];
  if (params.category && params.category.trim()) {
    lines.push(`🏷️ النوع: ${params.category}`);
  }
  if (params.description && params.description.trim()) {
    lines.push(`📝 الوصف: ${params.description.trim()}`);
  }
  lines.push(
    '',
    `كود الدعوة: ${cleanCode}`,
    '',
    'رابط الانضمام المباشر:',
    inviteUrl
  );
  return lines.join('\n');
}

/**
 * Shares the official RIFQ message using Android / Web Share API or clipboard fallback.
 * Never leaks AI Studio or preview URLs.
 */
export async function shareRifqApp(): Promise<'shared' | 'copied'> {
  const text = getOfficialRifqShareText();

  if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
    try {
      await navigator.share({
        title: 'رِفْق | RIFQ',
        text,
      });
      return 'shared';
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        return 'shared';
      }
    }
  }

  if (typeof navigator !== 'undefined' && navigator.clipboard) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // ignore clipboard error
    }
  }
  return 'copied';
}

/**
 * Shares a specific RIFQ Group invite code using Android Native Share / Web Share API.
 */
export async function shareRifqGroupInvite(params: {
  groupName: string;
  category: string;
  inviteCode: string;
  description?: string;
}): Promise<'shared' | 'copied'> {
  const shared = await shareWirdGroupInviteNatively({
    groupName: params.groupName,
    joinCode: params.inviteCode,
  });
  if (shared) {
    return 'shared';
  }

  const text = getRifqGroupInviteShareText(params);
  if (typeof navigator !== 'undefined' && navigator.clipboard) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // ignore clipboard error
    }
  }
  return 'copied';
}
