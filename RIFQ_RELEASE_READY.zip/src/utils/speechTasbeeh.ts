// Utility and types for Voice/Speech Recognition in Tasbeeh

export interface DhikrMatch {
  key: string;
  display: string;
  matchedCount: number;
}

export function normalizeArabic(text: string): string {
  if (!text) return '';
  return text
    // Remove diacritics (tashkeel)
    .replace(/[\u064B-\u065F\u0670]/g, '')
    // Normalize Alef forms (أ, إ, آ -> ا)
    .replace(/[إأآا]/g, 'ا')
    // Normalize Taa Marbuta (ة -> ه)
    .replace(/ة/g, 'ه')
    // Normalize Yaa (ى -> ي)
    .replace(/ى/g, 'ي')
    // Remove punctuation
    .replace(/[.,/#!$%^&*;:{}=\-_`~()؟،ـ]/g, ' ')
    // Normalize spaces
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

export interface DhikrRule {
  key: string;
  display: string;
  keywords: string[];
}

export const KNOWN_DHIKR_RULES: DhikrRule[] = [
  {
    key: 'سبحان الله',
    display: 'سُبْحَانَ اللَّهِ',
    keywords: ['سبحان الله', 'سبحانك', 'سبحان', 'تسبيح'],
  },
  {
    key: 'الحمد لله',
    display: 'الْحَمْدُ لِلَّهِ',
    keywords: ['الحمد لله', 'الحمدلله', 'الحمد', 'حمد'],
  },
  {
    key: 'الله أكبر',
    display: 'اللَّهُ أَكْبَرُ',
    keywords: ['الله اكبر', 'الله أكبر', 'اكبر', 'تكبير'],
  },
  {
    key: 'لا إله إلا الله',
    display: 'لَا إِلَهَ إِلَّا اللَّهُ',
    keywords: ['لا اله الا الله', 'لا إله إلا الله', 'تهليل', 'لا اله'],
  },
  {
    key: 'أستغفر الله',
    display: 'أَسْتَغْفِرُ اللَّهَ',
    keywords: ['استغفر الله', 'أستغفر الله', 'استغفر', 'استغفار', 'اتوب'],
  },
  {
    key: 'لا حول ولا قوة إلا بالله',
    display: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    keywords: ['لا حول ولا قوه الا بالله', 'لا حول ولا قوة إلا بالله', 'لا حول', 'حوقله', 'حوقلة'],
  },
  {
    key: 'اللهم صل وسلم على نبينا محمد',
    display: 'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
    keywords: ['اللهم صل', 'صلي على محمد', 'صل على محمد', 'صلي وسلم', 'اللهم صلي'],
  },
  {
    key: 'سبحان الله وبحمده',
    display: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
    keywords: ['سبحان الله وبحمده', 'وبحمده'],
  },
];

/**
 * Detects if a speech transcript matches any known dhikr or the active preset.
 */
export function detectDhikrInTranscript(
  rawTranscript: string, 
  activePresetText?: string
): DhikrMatch | null {
  const normalizedTranscript = normalizeArabic(rawTranscript);
  if (!normalizedTranscript) return null;

  // 1. First priority: check if user is saying the active preset
  if (activePresetText) {
    const normActive = normalizeArabic(activePresetText);
    if (normActive && (normalizedTranscript.includes(normActive) || normActive.includes(normalizedTranscript))) {
      // Estimate occurrences
      const occurrences = Math.max(1, (normalizedTranscript.match(new RegExp(normActive, 'g')) || []).length);
      return {
        key: activePresetText,
        display: activePresetText,
        matchedCount: occurrences,
      };
    }
  }

  // 2. Check known rules
  for (const rule of KNOWN_DHIKR_RULES) {
    for (const kw of rule.keywords) {
      const normKw = normalizeArabic(kw);
      if (normalizedTranscript.includes(normKw)) {
        return {
          key: rule.key,
          display: rule.display,
          matchedCount: 1,
        };
      }
    }
  }

  return null;
}
