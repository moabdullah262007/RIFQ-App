import { AUTHENTIC_HADITHS } from '../data/hadithsData';
import { HadithItem } from '../types/hadith';

const FAVORITES_KEY = 'rafiq_hadith_favorites';
const FONT_SIZE_KEY = 'rafiq_hadith_font_size';

export function loadHadithFavorites(): string[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveHadithFavorites(favs: string[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favs));
  } catch {}
}

export function toggleHadithFavorite(id: string): boolean {
  const favs = loadHadithFavorites();
  const index = favs.indexOf(id);
  let isFav = false;
  if (index > -1) {
    favs.splice(index, 1);
    isFav = false;
  } else {
    favs.push(id);
    isFav = true;
  }
  saveHadithFavorites(favs);
  return isFav;
}

export function getSavedFontSize(): number {
  if (typeof window === 'undefined') return 19;
  try {
    const raw = localStorage.getItem(FONT_SIZE_KEY);
    return raw ? parseInt(raw, 10) : 19;
  } catch {
    return 19;
  }
}

export function setSavedFontSize(size: number) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(FONT_SIZE_KEY, size.toString());
  } catch {}
}

/**
 * Deterministically pick Hadith of the Day from Sahih Bukhari or Sahih Muslim only (من الصحيحين فقط)
 */
export function getHadithOfTheDay(dayOffset = 0): HadithItem {
  // Only hadiths from Bukhari or Muslim with grade 'صحيح'
  const sahihayn = AUTHENTIC_HADITHS.filter(
    h => h.grade === 'صحيح' && (h.source.includes('البخاري') || h.source.includes('مسلم'))
  );

  const pool = sahihayn.length > 0 ? sahihayn : AUTHENTIC_HADITHS;
  
  const today = new Date();
  const dayOfYear = Math.floor(
    (today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)
  );

  const selectedIndex = Math.abs((dayOfYear + dayOffset) % pool.length);
  return pool[selectedIndex];
}
