import { triggerPushNotification, syncFullNotificationScheduleWithServiceWorker, ScheduledSwNotificationItem, RIFQ_NOTIFICATION_CHANNELS } from './notifications';

export interface DeceasedRecord {
  id: string;
  name: string;
  gender: 'male' | 'female';
  relationship?: string;
  deathDate?: string;
  photoDataUrl?: string | null;
  shortBio?: string;
  memories?: string;
  notes?: string;
  prayerCount: number;
  lastPrayedAt?: number | null;
  prayerLogs: Array<{ id: string; timestamp: number }>;
  reminder: {
    enabled: boolean;
    time: string; // e.g. "17:00"
    days: number[]; // 0 = Sunday, 1 = Monday, ..., 5 = Friday, 6 = Saturday (empty = all days)
    lastFiredDate?: string;
  };
  createdAt: number;
  updatedAt: number;
}

export interface AuthenticSupplication {
  id: string;
  category: 'quran' | 'sunnah';
  maleText: string;
  femaleText: string;
  source: string;
  hadithNumber?: string | number;
  grade?: string;
  referenceSurah?: string;
  referenceAyah?: number;
  explanation?: string;
}

const STORAGE_KEY = 'rifq_athar_tayyib_records_v1';

/**
 * قائمة الأدعية الصحيحة والموثقة للمتوفى من القرآن الكريم والسنة النبوية المطهرة.
 * جميع النصوص مخرّجة بدقة بأرقام الآيات ومصادر كتب الحديث المعتمدة.
 */
export const AUTHENTIC_DECEASED_SUPPLICATIONS: AuthenticSupplication[] = [
  {
    id: 'dua_quran_parents',
    category: 'quran',
    maleText: '﴿ رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا ﴾',
    femaleText: '﴿ رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا ﴾',
    source: 'القرآن الكريم — سورة الإسراء',
    referenceSurah: 'سورة الإسراء',
    referenceAyah: 24,
    explanation: 'دعاء قرآني جامع للوالدين بالرحمة والمغفرة جزاء تربيتهما وإحسانهما.',
  },
  {
    id: 'dua_quran_ibrahim',
    category: 'quran',
    maleText: '﴿ رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ ﴾',
    femaleText: '﴿ رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ ﴾',
    source: 'القرآن الكريم — سورة إبراهيم',
    referenceSurah: 'سورة إبراهيم',
    referenceAyah: 41,
    explanation: 'من دعاء نبي الله إبراهيم عليه السلام لنفسه ووالديه ولجميع المؤمنين والمؤمنات.',
  },
  {
    id: 'dua_quran_hashr',
    category: 'quran',
    maleText: '﴿ رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا الَّذِينَ سَبَقُونَا بِالْإِيمَانِ وَلَا تَجْعَلْ فِي قُلُوبِنَا غِلًّا لِّلَّذِينَ آمَنُوا رَبَّنَا إِنَّكَ رَءُوفٌ رَّحِيمٌ ﴾',
    femaleText: '﴿ رَبَّنَا اغْفِرْ لَنَا وَلِإِخْوَانِنَا الَّذِينَ سَبَقُونَا بِالْإِيمَانِ وَلَا تَجْعَلْ فِي قُلُوبِنَا غِلًّا لِّلَّذِينَ آمَنُوا رَبَّنَا إِنَّكَ رَءُوفٌ رَّحِيمٌ ﴾',
    source: 'القرآن الكريم — سورة الحشر',
    referenceSurah: 'سورة الحشر',
    referenceAyah: 10,
    explanation: 'دعاء التابعين لمن سبقوهم من سلف الأمة بالرحمة وحسن المنقلب وسلامة الصدور.',
  },
  {
    id: 'dua_quran_nuh',
    category: 'quran',
    maleText: '﴿ رَّبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَلِمَن دَخَلَ بَيْتِيَ مُؤْمِنًا وَلِلْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ ﴾',
    femaleText: '﴿ رَّبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَلِمَن دَخَلَ بَيْتِيَ مُؤْمِنًا وَلِلْمُؤْمِنِينَ وَالْمُؤْمِنَاتِ ﴾',
    source: 'القرآن الكريم — سورة نوح',
    referenceSurah: 'سورة نوح',
    referenceAyah: 28,
    explanation: 'دعاء نوح عليه السلام بالمغفرة الشاملة له ولوالديه ولكل مؤمن ومؤمنة.',
  },
  {
    id: 'dua_muslim_awf',
    category: 'sunnah',
    maleText: '«اللَّهُمَّ اغْفِرْ لَهُ وَارْحَمْهُ، وَعَافِهِ وَاعْفُ عَنْهُ، وَأَكْرِمْ نُزُلَهُ، وَوَسِّعْ مُدْخَلَهُ، وَاغْسِلْهُ بِالْمَاءِ وَالثَّلْجِ وَالْبَرَدِ، وَنَقِّهِ مِنَ الْخَطَايَا كَمَا نَقَّيْتَ الثَّوْبَ الأَبْيَضَ مِنَ الدَّنَسِ، وَأَبْدِلْهُ دَارًا خَيْرًا مِنْ دَارِهِ، وَأَهْلاً خَيْرًا مِنْ أَهْلِهِ، وَزَوْجًا خَيْرًا مِنْ زَوْجِهِ، وَأَدْخِلْهُ الْجَنَّةَ، وَأَعِذْهُ مِنْ عَذَابِ الْقَبْرِ، أَوْ مِنْ عَذَابِ النَّارِ»',
    femaleText: '«اللَّهُمَّ اغْفِرْ لَهَا وَارْحَمْهَا، وَعَافِهَا وَاعْفُ عَنْهَا، وَأَكْرِمْ نُزُلَهَا، وَوَسِّعْ مُدْخَلَهَا، وَاغْسِلْهَا بِالْمَاءِ وَالثَّلْجِ وَالْبَرَدِ، وَنَقِّهَا مِنَ الْخَطَايَا كَمَا نَقَّيْتَ الثَّوْبَ الأَبْيَضَ مِنَ الدَّنَسِ، وَأَبْدِلْهَا دَارًا خَيْرًا مِنْ دَارِهَا، وَأَهْلاً خَيْرًا مِنْ أَهْلِهَا، وَزَوْجًا خَيْرًا مِنْ زَوْجِهَا، وَأَدْخِلْهَا الْجَنَّةَ، وَأَعِذْهَا مِنْ عَذَابِ الْقَبْرِ، أَوْ مِنْ عَذَابِ النَّارِ»',
    source: 'صحيح مسلم',
    hadithNumber: 963,
    grade: 'صحيح',
    explanation: 'من أعظم الأدعية النبوية للميت في صلاة الجنازة، رواه عوف بن مالك الأشجعي رضي الله عنه.',
  },
  {
    id: 'dua_abudawood_living_dead',
    category: 'sunnah',
    maleText: '«اللَّهُمَّ اغْفِرْ لِحَيِّنَا وَمَيِّتِنَا، وَشَاهِدِنَا وَغَائِبِنَا، وَصَغِيرِنَا وَكَبِيرِنَا، وَذَكَرِنَا وَأُنْثَانَا، اللَّهُمَّ مَنْ أَحْيَيْتَهُ مِنَّا فَأَحْيِهِ عَلَى الإِسْلامِ، وَمَنْ تَوَفَّيْتَهُ مِنَّا فَتَوَفَّهُ عَلَى الإِيمَانِ، اللَّهُمَّ لا تَحْرِمْنَا أَجْرَهُ وَلا تُضِلَّنَا بَعْدَهُ»',
    femaleText: '«اللَّهُمَّ اغْفِرْ لِحَيِّنَا وَمَيِّتِنَا، وَشَاهِدِنَا وَغَائِبِنَا، وَصَغِيرِنَا وَكَبِيرِنَا، وَذَكَرِنَا وَأُنْثَانَا، اللَّهُمَّ مَنْ أَحْيَيْتَهُ مِنَّا فَأَحْيِهِ عَلَى الإِسْلامِ، وَمَنْ تَوَفَّيْتَهُ مِنَّا فَتَوَفَّهُ عَلَى الإِيمَانِ، اللَّهُمَّ لا تَحْرِمْنَا أَجْرَهَا وَلا تُضِلَّنَا بَعْدَهَا»',
    source: 'سنن أبي داود (٣٢٠١) وسنن الترمذي (١٠٢٤)',
    hadithNumber: 3201,
    grade: 'صحيح (صححه الألباني)',
    explanation: 'دعاء جامع مأثور عن النبي ﷺ يشمل الأحياء والأموات بالثبات وحسن الخاتمة.',
  },
  {
    id: 'dua_abudawood_wathilah',
    category: 'sunnah',
    maleText: '«اللَّهُمَّ إِنَّهُ فِي ذِمَّتِكَ وَحَبْلِ جِوَارِكَ، فَقِهِ مِنْ فِتْنَةِ الْقَبْرِ وَعَذَابِ النَّارِ، وَأَنْتَ أَهْلُ الْوَفَاءِ وَالْحَقِّ، فَاغْفِرْ لَهُ وَارْحَمْهُ، إِنَّكَ أَنْتَ الْغَفُورُ الرَّحِيمُ»',
    femaleText: '«اللَّهُمَّ إِنَّهَا فِي ذِمَّتِكَ وَحَبْلِ جِوَارِكِ، فَقِهَا مِنْ فِتْنَةِ الْقَبْرِ وَعَذَابِ النَّارِ، وَأَنْتَ أَهْلُ الْوَفَاءِ وَالْحَقِّ، فَاغْفِرْ لَهَا وَارْحَمْهَا، إِنَّكَ أَنْتَ الْغَفُورُ الرَّحِيمُ»',
    source: 'سنن أبي داود (٣٢٠٢) وابن ماجه (١٤٩٩)',
    hadithNumber: 3202,
    grade: 'صحيح (صححه الألباني)',
    explanation: 'حديث واثلة بن الأسقع رضي الله عنه في الاستجارة برحمة الله وأمانه للمتوفى.',
  },
  {
    id: 'dua_muslim_abu_salama',
    category: 'sunnah',
    maleText: '«اللَّهُمَّ اغْفِرْ لَهُ، وَارْفَعْ دَرَجَتَهُ فِي الْمَهْدِيِّينَ، وَاخْلُفْهُ فِي عَقِبِهِ فِي الْغَابِرِينَ، وَاغْفِرْ لَنَا وَلَهُ يَا رَبَّ الْعَالَمِينَ، وَافْسَحْ لَهُ فِي قَبْرِهِ وَنَوِّرْ لَهُ فِيهِ»',
    femaleText: '«اللَّهُمَّ اغْفِرْ لَهَا، وَارْفَعْ دَرَجَتَهَا فِي الْمَهْدِيِّينَ، وَاخْلُفْهَا فِي عَقِبِهَا فِي الْغَابِرِينَ، وَاغْفِرْ لَنَا وَلَهَا يَا رَبَّ الْعَالَمِينَ، وَافْسَحْ لَهَا فِي قَبْرِهَا وَنَوِّرْ لَهَا فِيهِ»',
    source: 'صحيح مسلم',
    hadithNumber: 920,
    grade: 'صحيح',
    explanation: 'من دعاء النبي ﷺ بالفسحة والنور ورفعة الدرجات في المهديين.',
  },
  {
    id: 'dua_hakim_needy',
    category: 'sunnah',
    maleText: '«اللَّهُمَّ عَبْدُكَ وَابْنُ أَمَتِكَ احْتَاجَ إِلَى رَحْمَتِكَ، وَأَنْتَ غَنِيٌّ عَنْ عَذَابِهِ، إِنْ كَانَ مُحْسِنًا فَزِدْ فِي إِحْسَانِهِ، وَإِنْ كَانَ مُسِيئًا فَتَجَاوَزْ عَنْهُ»',
    femaleText: '«اللَّهُمَّ أَمَتُكَ وَابْنَةُ عَبْدِكَ احْتَاجَتْ إِلَى رَحْمَتِكَ، وَأَنْتَ غَنِيٌّ عَنْ عَذَابِهَا، إِنْ كَانَتْ مُحْسِنَةً فَزِدْ فِي إِحْسَانِهَا، وَإِنْ كَانَتْ مُسِيئَةً فَتَجَاوَزْ عَنْهَا»',
    source: 'المستدرك على الصحيحين للحاكم (١٣٢٨)',
    hadithNumber: 1328,
    grade: 'صحيح الإسناد (وافقه الذهبي وصححه الألباني في أحكام الجنائز)',
    explanation: 'دعاء مبارك بالافتقار إلى رحمة الله والتجاوز عن السيئات ومضاعفة الحسنات.',
  },
  {
    id: 'dua_rawdah_jannah',
    category: 'sunnah',
    maleText: '«اللَّهُمَّ اجْعَلْ قَبْرَهُ رَوْضَةً مِنْ رِيَاضِ الْجَنَّةِ، وَلَا تَجْعَلْهُ حُفْرَةً مِنْ حُفَرِ النَّارِ، وَأَنْزِلْ عَلَيْهِ الرَّحْمَةَ وَالضِّيَاءَ وَالنُّورَ»',
    femaleText: '«اللَّهُمَّ اجْعَلْ قَبْرَهَا رَوْضَةً مِنْ رِيَاضِ الْجَنَّةِ، وَلَا تَجْعَلْهُ حُفْرَةً مِنْ حُفَرِ النَّارِ، وَأَنْزِلْ عَلَيْهَا الرَّحْمَةَ وَالضِّيَاءَ وَالنُّورَ»',
    source: 'دعاء مأثور مستنبط من حديث القبر روضة من رياض الجنة (سنن الترمذي: ٣١٥٣)',
    grade: 'مأثور حسن المعنى',
    explanation: 'سؤال الله تبارك وتعالى أن يكون البرزخ أماناً ونعيماً وروضة خضراء مبشرة برضوان الله.',
  },
];

export function getAtharTayyibDuaText(dua: AuthenticSupplication, gender: 'male' | 'female'): string {
  return gender === 'female' ? dua.femaleText : dua.maleText;
}

/**
 * تحميل سجلات المتوفين المحفوظة محلياً على جهاز المستخدم حصراً
 */
export function loadAtharTayyibRecords(): DeceasedRecord[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed;
  } catch {
    return [];
  }
}

/**
 * حفظ قائمة سجلات المتوفين محلياً
 */
export function saveAllAtharTayyibRecords(records: DeceasedRecord[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    syncAtharTayyibRemindersWithSystem(records);
  } catch (err) {
    // If quota exceeded due to large photo, try to keep data intact
    console.warn('Local storage write warning in Athar Tayyib:', err);
  }
}

/**
 * جلب سجل متوفى بالمعرف
 */
export function getDeceasedById(id: string): DeceasedRecord | null {
  const records = loadAtharTayyibRecords();
  return records.find((r) => r.id === id) || null;
}

/**
 * إضافة أو تحديث سجل متوفى
 */
export function saveDeceasedRecord(record: DeceasedRecord): void {
  const records = loadAtharTayyibRecords();
  const index = records.findIndex((r) => r.id === record.id);
  const now = Date.now();
  const updatedRecord = { ...record, updatedAt: now };

  if (index >= 0) {
    records[index] = updatedRecord;
  } else {
    records.unshift(updatedRecord);
  }

  saveAllAtharTayyibRecords(records);
}

/**
 * حذف سجل متوفى
 */
export function deleteDeceasedRecord(id: string): void {
  const records = loadAtharTayyibRecords();
  const filtered = records.filter((r) => r.id !== id);
  saveAllAtharTayyibRecords(filtered);
}

/**
 * تسجيل دعاء فعلي حقيقي للمتوفى وزيادة العداد
 */
export function recordPrayerForDeceased(id: string): DeceasedRecord | null {
  const records = loadAtharTayyibRecords();
  const index = records.findIndex((r) => r.id === id);
  if (index === -1) return null;

  const target = records[index];
  const now = Date.now();
  const updated: DeceasedRecord = {
    ...target,
    prayerCount: (target.prayerCount || 0) + 1,
    lastPrayedAt: now,
    prayerLogs: [
      { id: `log_${now}_${Math.random().toString(36).slice(2, 6)}`, timestamp: now },
      ...(target.prayerLogs || []).slice(0, 99), // الاحتفاظ بآخر 100 دعاء
    ],
    updatedAt: now,
  };

  records[index] = updated;
  saveAllAtharTayyibRecords(records);
  return updated;
}

/**
 * ضغط ومعالجة الصورة محلياً داخل المتصفح بأعلى دقة وأقل حجم (WebP / JPEG)، دون أي إرسال خارجي.
 */
export async function compressMemorialPhoto(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        try {
          const maxDim = 480;
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(e.target?.result as string);
            return;
          }

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, width, height);

          // Use WebP with high quality if supported, otherwise JPEG
          const dataUrl = canvas.toDataURL('image/webp', 0.88);
          resolve(dataUrl);
        } catch {
          resolve(e.target?.result as string);
        }
      };
      img.onerror = () => reject(new Error('فشل تحميل ملف الصورة.'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('فشل قراءة الملف.'));
    reader.readAsDataURL(file);
  });
}

/**
 * مزامنة مواعيد تذكير الدعاء مع نظام الإشعارات المحلي (Android AlarmManager و Service Worker)
 */
export function syncAtharTayyibRemindersWithSystem(records?: DeceasedRecord[]): void {
  if (typeof window === 'undefined') return;
  const list = records || loadAtharTayyibRecords();
  const activeReminders = list.filter((r) => r.reminder?.enabled && r.reminder?.time);

  if (activeReminders.length === 0) {
    return;
  }

  const now = new Date();
  const currentDayOfWeek = now.getDay(); // 0 = Sunday..6 = Saturday
  const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

  const scheduleItems: ScheduledSwNotificationItem[] = [];

  for (const item of activeReminders) {
    const days = item.reminder.days || [];
    const isDayApplicable = days.length === 0 || days.includes(currentDayOfWeek);
    if (!isDayApplicable) continue;

    const [h, m] = item.reminder.time.split(':').map(Number);
    const scheduledDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h || 0, m || 0, 0, 0);

    const pron = item.gender === 'female' ? 'لها' : 'له';
    const pronEnd = item.gender === 'female' ? 'وارحمها' : 'وارحمه';

    scheduleItems.push({
      id: `athar_tayyib_${item.id}`,
      signatureKey: `athar_${item.id}_${todayStr}_${item.reminder.time}`,
      channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
      title: `تذكير بالدعاء 🕊️ • ${item.name}`,
      body: `اللهم اغفر لـ ${item.name} ${pronEnd}، واجعل قبره روضة من رياض الجنة. انقر للدعاء ${pron}.`,
      timestamp: scheduledDate.getTime(),
      timeHHMM: item.reminder.time,
      repeatDaily: true,
      enabled: true,
      tag: `rifq-athar-${item.id}-${todayStr}`,
      screen: 'athar_tayyib',
      dhikrId: item.id,
    });
  }

  if (scheduleItems.length > 0) {
    syncFullNotificationScheduleWithServiceWorker(scheduleItems);
  }
}

/**
 * فحص وإطلاق تذكيرات الدعاء المستحقة في الدقيقة الحالية (للتوافق المباشر أثناء فتح التطبيق)
 */
export function checkAndFireAtharTayyibReminders(): void {
  if (typeof window === 'undefined') return;
  try {
    const records = loadAtharTayyibRecords();
    const now = new Date();
    const currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const currentDayOfWeek = now.getDay();

    let hasUpdates = false;

    for (const item of records) {
      if (!item.reminder?.enabled || !item.reminder?.time) continue;

      const days = item.reminder.days || [];
      const isDayApplicable = days.length === 0 || days.includes(currentDayOfWeek);
      if (!isDayApplicable) continue;

      if (item.reminder.time === currentHHMM && item.reminder.lastFiredDate !== todayStr) {
        const pron = item.gender === 'female' ? 'لها' : 'له';
        const pronEnd = item.gender === 'female' ? 'وارحمها' : 'وارحمه';

        triggerPushNotification({
          title: `أثر طيّب 🕊️ • تذكير بالدعاء لـ ${item.name}`,
          message: `اللهم اغفر لـ ${item.name} ${pronEnd} واجمعنا به في الفردوس الأعلى.`,
          tag: `rifq-athar-pray-${item.id}-${todayStr}`,
          screen: 'athar_tayyib',
          channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
          recordInCenter: true,
        });

        item.reminder.lastFiredDate = todayStr;
        hasUpdates = true;
      }
    }

    if (hasUpdates) {
      saveAllAtharTayyibRecords(records);
    }
  } catch (err) {
    console.warn('Error checking athar tayyib reminders:', err);
  }
}
