import {
  triggerPushNotification,
  isNotificationChannelEnabled,
  RIFQ_NOTIFICATION_CHANNELS,
  hasNotificationFired,
  markNotificationFired,
  syncFullNotificationScheduleWithServiceWorker,
  loadUnifiedNotificationSettings,
} from './notifications';
import { addNotification } from './storage';
import { WardType } from '../types';

const DAILY_REMINDERS_LIST_KEY = 'rifq_daily_reminders_list_v1';
const DAILY_REMINDERS_PREFS_KEY = 'rifq_daily_reminders_prefs_v1';
const FIRED_REMINDERS_LOG_KEY = 'rifq_daily_reminders_fired_dates_v1';

export type ReminderCategory =
  | 'tasbeeh'
  | 'dua'
  | 'morning_evening'
  | 'istighfar'
  | 'salawat'
  | 'sleep';

export interface DailyReminderItem {
  id: string;
  title: string;
  dhikrOrDuaText: string;
  category: ReminderCategory;
  time: string; // "HH:MM" 24-hour format
  enabled: boolean;
  daysOfWeek: number[]; // 0 (Sunday) .. 6 (Saturday)
  targetCount: number;
  linkedWard?: WardType;
  isCustom?: boolean;
}

export interface DailyReminderPreferences {
  masterEnabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  systemPushEnabled: boolean;
  quietHoursEnabled: boolean;
  quietHoursStart: string; // e.g. "23:00"
  quietHoursEnd: string; // e.g. "04:30"
  snoozeMinutes: number; // e.g. 10
}

export const DEFAULT_REMINDER_PREFERENCES: DailyReminderPreferences = {
  masterEnabled: true,
  soundEnabled: true,
  vibrationEnabled: true,
  systemPushEnabled: true,
  quietHoursEnabled: false,
  quietHoursStart: '23:00',
  quietHoursEnd: '04:30',
  snoozeMinutes: 10,
};

export const INITIAL_DAILY_REMINDERS: DailyReminderItem[] = [
  {
    id: 'rem_morning_athkar',
    title: 'أذكار الصباح المباركة',
    dhikrOrDuaText:
      'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
    category: 'morning_evening',
    time: '06:30',
    enabled: true,
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    targetCount: 1,
    linkedWard: 'morning',
  },
  {
    id: 'rem_duha_tasbeeh',
    title: 'ورد التسبيح اليومي (الضحى)',
    dhikrOrDuaText: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
    category: 'tasbeeh',
    time: '09:30',
    enabled: true,
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    targetCount: 100,
  },
  {
    id: 'rem_dhuhr_istighfar',
    title: 'ورد الاستغفار والتوبة',
    dhikrOrDuaText:
      'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ',
    category: 'istighfar',
    time: '13:30',
    enabled: true,
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    targetCount: 100,
  },
  {
    id: 'rem_evening_athkar',
    title: 'أذكار المساء والتحصين',
    dhikrOrDuaText:
      'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ',
    category: 'morning_evening',
    time: '17:30',
    enabled: true,
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    targetCount: 1,
    linkedWard: 'evening',
  },
  {
    id: 'rem_night_salawat',
    title: 'الصلاة على النبي ﷺ والدعاء الجامع',
    dhikrOrDuaText:
      'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ — رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ',
    category: 'salawat',
    time: '20:30',
    enabled: true,
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    targetCount: 33,
  },
  {
    id: 'rem_sleep_athkar',
    title: 'أذكار النوم وخواتيم اليوم',
    dhikrOrDuaText:
      'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا — سُبْحَانَ اللَّهِ (٣٣) وَالْحَمْدُ لِلَّهِ (٣٣) وَاللَّهُ أَكْبَرُ (٣٤)',
    category: 'sleep',
    time: '22:00',
    enabled: true,
    daysOfWeek: [0, 1, 2, 3, 4, 5, 6],
    targetCount: 33,
    linkedWard: 'sleep',
  },
];

export const PRESET_DUAS_AND_TASBIHS: {
  title: string;
  text: string;
  category: ReminderCategory;
  target: number;
}[] = [
  {
    title: 'سيد الاستغفار',
    text: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ',
    category: 'dua',
    target: 1,
  },
  {
    title: 'الباقيات الصالحات',
    text: 'سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ',
    category: 'tasbeeh',
    target: 100,
  },
  {
    title: 'الحوقلة (كنز من كنوز الجنة)',
    text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ',
    category: 'tasbeeh',
    target: 100,
  },
  {
    title: 'دعاء تفريج الكرب (دعاء يونس)',
    text: 'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
    category: 'dua',
    target: 33,
  },
  {
    title: 'التهليل والتوحيد المأثور',
    text: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    category: 'tasbeeh',
    target: 100,
  },
  {
    title: 'دعاء الهداية والعفاف والغنى',
    text: 'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى',
    category: 'dua',
    target: 3,
  },
];

export function loadDailyReminders(): DailyReminderItem[] {
  try {
    const raw = localStorage.getItem(DAILY_REMINDERS_LIST_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Error loading daily reminders:', e);
  }
  saveDailyReminders(INITIAL_DAILY_REMINDERS);
  return INITIAL_DAILY_REMINDERS;
}

export function saveDailyReminders(list: DailyReminderItem[]): void {
  try {
    localStorage.setItem(DAILY_REMINDERS_LIST_KEY, JSON.stringify(list));
    syncFullNotificationScheduleWithServiceWorker();
  } catch (e) {
    console.warn('Error saving daily reminders:', e);
  }
}

export function loadReminderPreferences(): DailyReminderPreferences {
  try {
    const raw = localStorage.getItem(DAILY_REMINDERS_PREFS_KEY);
    const unified = loadUnifiedNotificationSettings();
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_REMINDER_PREFERENCES,
        ...parsed,
        masterEnabled: unified.remindersChannelEnabled && (parsed.masterEnabled ?? true),
      };
    }
    return {
      ...DEFAULT_REMINDER_PREFERENCES,
      masterEnabled: unified.remindersChannelEnabled,
    };
  } catch (e) {
    console.warn('Error loading reminder preferences:', e);
  }
  return DEFAULT_REMINDER_PREFERENCES;
}

export function saveReminderPreferences(prefs: DailyReminderPreferences): void {
  try {
    localStorage.setItem(DAILY_REMINDERS_PREFS_KEY, JSON.stringify(prefs));
    syncFullNotificationScheduleWithServiceWorker();
  } catch (e) {
    console.warn('Error saving reminder preferences:', e);
  }
}

function parseTimeToMinutes(timeStr: string): number {
  const [h, m] = (timeStr || '00:00').split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/**
 * Checks if current time falls within user's configured Quiet Hours (وقت الهدوء)
 */
export function isWithinQuietHours(prefs: DailyReminderPreferences, now = new Date()): boolean {
  if (!prefs.quietHoursEnabled) return false;
  const currentMins = now.getHours() * 60 + now.getMinutes();
  const startMins = parseTimeToMinutes(prefs.quietHoursStart);
  const endMins = parseTimeToMinutes(prefs.quietHoursEnd);

  if (startMins <= endMins) {
    return currentMins >= startMins && currentMins <= endMins;
  }
  // Crosses midnight (e.g. 23:00 to 04:30)
  return currentMins >= startMins || currentMins <= endMins;
}

function getFiredMap(): Record<string, string> {
  try {
    const raw = localStorage.getItem(FIRED_REMINDERS_LOG_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function markReminderFiredToday(reminderId: string, dateTimeKey: string): void {
  try {
    const map = getFiredMap();
    map[reminderId] = dateTimeKey;
    localStorage.setItem(FIRED_REMINDERS_LOG_KEY, JSON.stringify(map));
  } catch {
    // ignore
  }
}

/**
 * Fires a specific reminder respecting user sound/vibration/push/quiet-hours preferences
 */
export async function fireDailyReminderItem(
  item: DailyReminderItem,
  prefs = loadReminderPreferences(),
  onInAppAlert?: (item: DailyReminderItem) => void,
  signatureKey?: string
): Promise<void> {
  const quiet = isWithinQuietHours(prefs);

  // Record in notification center
  addNotification({
    title: `تذكير: ${item.title}`,
    message: `${item.dhikrOrDuaText} (${
      item.targetCount > 1 ? `${item.targetCount} مرة` : 'ورد يومي'
    })`,
    time: 'الآن',
    read: false,
    type: 'reminder',
    actionWard: item.linkedWard,
    actionScreen: item.linkedWard ? 'ward' : 'daily_reminders',
    signatureKey,
  });

  if (!quiet && prefs.systemPushEnabled) {
    const channelId =
      item.category === 'morning_evening' || item.category === 'sleep'
        ? RIFQ_NOTIFICATION_CHANNELS.azkar
        : RIFQ_NOTIFICATION_CHANNELS.reminders;

    await triggerPushNotification({
      title: `تذكير رِفْق • ${item.title}`,
      message: item.dhikrOrDuaText,
      ward: item.linkedWard,
      screen: item.linkedWard ? 'ward' : 'daily_reminders',
      channelId,
      tag: `daily-rem-${item.id}`,
      signatureKey,
    });
  }

  if (onInAppAlert) {
    onInAppAlert(item);
  }
}

/**
 * Checks all enabled daily reminders against the current time and triggers any due reminder
 */
export async function checkDueDailyReminders(
  onInAppAlert?: (item: DailyReminderItem) => void
): Promise<void> {
  if (!isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.reminders)) return;

  const prefs = loadReminderPreferences();
  if (!prefs.masterEnabled) return;

  const now = new Date();
  const dayOfWeek = now.getDay();
  const currentMins = now.getHours() * 60 + now.getMinutes();
  const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')}`;

  const reminders = loadDailyReminders();
  const firedMap = getFiredMap();

  for (const rem of reminders) {
    if (!rem.enabled) continue;
    if (!rem.daysOfWeek.includes(dayOfWeek)) continue;

    // Morning, Evening, and Sleep Athkar are handled by checkAndFireScheduledReminders
    // to prevent firing two overlapping notifications at the exact same minute.
    if (
      rem.id === 'rem_morning_athkar' ||
      rem.id === 'rem_evening_athkar' ||
      rem.id === 'rem_sleep_athkar'
    ) {
      continue;
    }

    const scheduledMins = parseTimeToMinutes(rem.time);
    const fireSignature = `${todayStr}_${rem.id}_${rem.time}`;

    // Resilient window: from scheduled minute up to 60 minutes after (so background tabs never miss it)
    if (
      currentMins >= scheduledMins &&
      currentMins <= scheduledMins + 60 &&
      firedMap[rem.id] !== fireSignature &&
      !hasNotificationFired(fireSignature)
    ) {
      markReminderFiredToday(rem.id, fireSignature);
      markNotificationFired(fireSignature);
      await fireDailyReminderItem(rem, prefs, onInAppAlert, fireSignature);
    }
  }
}

export function formatTime12HourArabic(time24: string): string {
  if (!time24 || !time24.includes(':')) return time24;
  const [hStr, mStr] = time24.split(':');
  const h = parseInt(hStr, 10);
  const period = h >= 12 ? 'م' : 'ص';
  const h12 = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return `${h12}:${mStr} ${period}`;
}
