import {
  UserSettings,
  DailyRecord,
  RankInfo,
  DhikrItem,
  NotificationItem,
  CompanionCategoryId,
  CompanionCategory,
  CompanionStory,
  CompanionHadith,
  CompanionProfile,
  CompanionCategorySqliteRow,
  CompanionSqliteRow,
  CompanionStorySqliteRow,
  CompanionFavoriteSqliteRow,
} from '../types';
import { RANKS, EXPLORER_ATHKAR, MORNING_ATHKAR, EVENING_ATHKAR, SLEEP_ATHKAR, PRAYER_ATHKAR } from '../data/athkarData';
import {
  ALL_COMPANIONS,
  COMPANION_CATEGORIES,
  normalizeArabicText,
} from '../data/companionsData';
import { syncRosaryWithUserSettings } from './rosaryStorage';
import {
  notifyDailyTasbeehGoalCompleted,
  notifyWirdGoalCompleted,
} from './goalAndAchievementNotificationService';

const SETTINGS_KEY = 'mushaba_settings_v1';
const HISTORY_KEY = 'mushaba_history_v1';
const CUSTOM_ATHKAR_KEY = 'mushaba_custom_athkar_v1';
const FAVORITES_KEY = 'mushaba_favorites_v1';
const NOTIFICATIONS_KEY = 'mushaba_notifications_v1';
const CURRENT_WARD_PROGRESS_KEY = 'mushaba_ward_progress_v1';

let isHydratingStorageFromCloud = false;

export function setStorageCloudHydrationLock(locked: boolean): void {
  isHydratingStorageFromCloud = locked;
}

export function isStorageCloudHydrating(): boolean {
  return isHydratingStorageFromCloud;
}

function notifyLocalDataMutation(domain: 'settings' | 'athkar' | 'history'): void {
  if (!isHydratingStorageFromCloud && typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-local-data-mutated', {
        detail: { domain, immediate: domain === 'settings' },
      })
    );
  }
}

export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getDefaultSettings(): UserSettings {
  return {
    soundEnabled: true,
    soundVolume: 0.75,
    soundType: 'wood',
    vibrationEnabled: true,
    vibrationLevel: 'medium',
    themeFont: 'tajawal',
    defaultTarget: 100,
    dailyGoal: 100,
    weeklyGoal: 3000,
    monthlyGoal: 15000,
    hasCompletedOnboarding: false,
    morningReminderTime: '06:30',
    eveningReminderTime: '17:30',
    remindersEnabled: true,
    pushNotificationsEnabled: true,
    rosaryDhikr: 'سُبْحَانَ اللَّهِ',
    rosaryTarget: 100,
    rosarySoundEnabled: true,
    rosaryVibrationEnabled: true,
    rosaryTheme: 'gold',
    rosaryDarkMode: false,
    themeId: 'default',
    themeMode: 'light',
  };
}

export function loadSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return getDefaultSettings();
    return { ...getDefaultSettings(), ...JSON.parse(raw) };
  } catch {
    return getDefaultSettings();
  }
}

export function saveSettings(settings: UserSettings): void {
  try {
    const prevRaw = localStorage.getItem(SETTINGS_KEY);
    const nextRaw = JSON.stringify(settings);
    localStorage.setItem(SETTINGS_KEY, nextRaw);
    syncRosaryWithUserSettings(settings);
    if (prevRaw !== nextRaw) {
      notifyLocalDataMutation('settings');
    }
  } catch {
    // ignore
  }
}

export function loadHistory(): Record<string, DailyRecord> {
  const today = getTodayDateString();
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Clean legacy fake seeded history if it contains the artificial 7 count or fake seed keys
      if (parsed['2026-09-08'] || (parsed[today]?.totalCount === 7 && parsed[today]?.freeCount === 7)) {
        localStorage.removeItem(HISTORY_KEY);
      } else {
        if (!parsed[today]) {
          parsed[today] = {
            date: today,
            totalCount: 0,
            sessionsCount: 0,
            completedAthkarCount: 0,
            freeCount: 0,
            hourlyCounts: new Array(24).fill(0),
            dhikrCounts: {},
          };
        }
        return parsed;
      }
    }
  } catch {
    // fallback
  }

  // Pure zero-start authentic initial history (0 counts, 0 sessions, 0 cycles)
  const initialHistory: Record<string, DailyRecord> = {};
  initialHistory[today] = {
    date: today,
    totalCount: 0,
    sessionsCount: 0,
    completedAthkarCount: 0,
    freeCount: 0,
    hourlyCounts: new Array(24).fill(0),
    dhikrCounts: {},
  };

  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(initialHistory));
  } catch {
    // ignore
  }

  return initialHistory;
}

export function saveHistory(history: Record<string, DailyRecord>): void {
  try {
    const prevRaw = localStorage.getItem(HISTORY_KEY);
    const nextRaw = JSON.stringify(history);
    localStorage.setItem(HISTORY_KEY, nextRaw);
    if (prevRaw !== nextRaw) {
      notifyLocalDataMutation('history');
    }
  } catch {
    // ignore
  }
}

export function getTodayRecord(history: Record<string, DailyRecord>): DailyRecord {
  const today = getTodayDateString();
  if (history[today]) {
    return history[today];
  }
  const newRecord: DailyRecord = {
    date: today,
    totalCount: 0,
    sessionsCount: 0,
    completedAthkarCount: 0,
    freeCount: 0,
    hourlyCounts: new Array(24).fill(0),
    dhikrCounts: {},
  };
  history[today] = newRecord;
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  } catch {
    // ignore
  }
  return newRecord;
}

export function recordTasbeehCount(
  dhikrText: string,
  increment = 1,
  isWardCompletion = false
): { history: Record<string, DailyRecord>; todayRecord: DailyRecord; grandTotal: number } {
  const history = loadHistory();
  const today = getTodayDateString();
  const todayRecord = getTodayRecord(history);
  const hour = new Date().getHours();

  todayRecord.totalCount += increment;
  todayRecord.hourlyCounts[hour] = (todayRecord.hourlyCounts[hour] || 0) + increment;
  todayRecord.dhikrCounts[dhikrText] = (todayRecord.dhikrCounts[dhikrText] || 0) + increment;
  
  if (isWardCompletion) {
    todayRecord.completedAthkarCount += 1;
  } else {
    todayRecord.freeCount += increment;
  }

  history[today] = todayRecord;
  saveHistory(history);

  // Check and notify for Daily Tasbeeh Goal completion
  try {
    const settings = loadSettings();
    const dailyGoal = settings.dailyGoal || 100;
    if (todayRecord.totalCount >= dailyGoal) {
      notifyDailyTasbeehGoalCompleted(todayRecord.totalCount, dailyGoal).catch(() => {});
    }
    if (isWardCompletion) {
      notifyWirdGoalCompleted(dhikrText || 'ورد الأذكار').catch(() => {});
    }
  } catch {
    // ignore
  }

  const grandTotal = Object.values(history).reduce((acc, rec) => acc + rec.totalCount, 0);

  return { history, todayRecord, grandTotal };
}

export function calculateTotalLifetimeTasbeeh(history: Record<string, DailyRecord>): number {
  return Object.values(history).reduce((acc, rec) => acc + (rec.totalCount || 0), 0);
}

export function calculateStreaks(history: Record<string, DailyRecord>): { currentStreak: number; longestStreak: number } {
  const dates = Object.keys(history)
    .filter(d => (history[d]?.totalCount || 0) > 0)
    .sort();

  if (dates.length === 0) return { currentStreak: 0, longestStreak: 0 };

  let currentStreak = 0;
  let longestStreak = 0;
  let tempStreak = 0;

  const todayStr = getTodayDateString();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  // Calculate longest continuous consecutive sequence
  for (let i = 0; i < dates.length; i++) {
    if (i === 0) {
      tempStreak = 1;
    } else {
      const prev = new Date(dates[i - 1]);
      const curr = new Date(dates[i]);
      const diffDays = Math.round((curr.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        tempStreak++;
      } else {
        tempStreak = 1;
      }
    }
    if (tempStreak > longestStreak) {
      longestStreak = tempStreak;
    }
  }

  // Calculate current streak
  let checkDate = new Date();
  // Check if today has count, or yesterday
  const hasToday = (history[todayStr]?.totalCount || 0) > 0;
  const hasYesterday = (history[yesterdayStr]?.totalCount || 0) > 0;

  if (hasToday || hasYesterday) {
    if (!hasToday) {
      checkDate = yesterday;
    }
    while (true) {
      const dateStr = checkDate.toISOString().split('T')[0];
      if ((history[dateStr]?.totalCount || 0) > 0) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        break;
      }
    }
  }

  return { currentStreak, longestStreak: Math.max(longestStreak, currentStreak) };
}

export function getCurrentRank(totalTasbeeh: number): {
  currentRank: RankInfo;
  nextRank: RankInfo | null;
  progressPercent: number;
  remainingToNext: number;
} {
  let currentRank = RANKS[0];
  let nextRank: RankInfo | null = RANKS[1];

  for (let i = 0; i < RANKS.length; i++) {
    if (totalTasbeeh >= RANKS[i].min) {
      currentRank = RANKS[i];
      nextRank = RANKS[i + 1] || null;
    }
  }

  if (!nextRank) {
    return {
      currentRank,
      nextRank: null,
      progressPercent: 100,
      remainingToNext: 0,
    };
  }

  const range = nextRank.min - currentRank.min;
  const progress = Math.max(0, totalTasbeeh - currentRank.min);
  const progressPercent = Math.min(100, Math.round((progress / range) * 100));
  const remainingToNext = Math.max(0, nextRank.min - totalTasbeeh);

  return {
    currentRank,
    nextRank,
    progressPercent,
    remainingToNext,
  };
}

export function saveFavorites(favs: string[]): void {
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(favs));
    notifyLocalDataMutation('athkar');
  } catch {
    // ignore
  }
}

export function saveCustomAthkar(items: DhikrItem[]): void {
  try {
    localStorage.setItem(CUSTOM_ATHKAR_KEY, JSON.stringify(items));
    notifyLocalDataMutation('athkar');
  } catch {
    // ignore
  }
}

export function calculateRank(totalTasbeeh: number): RankInfo {
  return getCurrentRank(totalTasbeeh).currentRank;
}

export function loadFavorites(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : ['q-1', 's-1'];
  } catch {
    return ['q-1', 's-1'];
  }
}

export function toggleFavorite(id: string): string[] {
  const current = loadFavorites();
  let updated: string[];
  if (current.includes(id)) {
    updated = current.filter(item => item !== id);
  } else {
    updated = [...current, id];
  }
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
    notifyLocalDataMutation('athkar');
  } catch {
    // ignore
  }
  return updated;
}

export function loadCustomAthkar(): DhikrItem[] {
  try {
    const raw = localStorage.getItem(CUSTOM_ATHKAR_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addCustomDhikr(item: Omit<DhikrItem, 'id' | 'countDone' | 'isCustom'>): DhikrItem[] {
  const current = loadCustomAthkar();
  const newItem: DhikrItem = {
    ...item,
    id: 'custom-' + Date.now(),
    countDone: 0,
    isCustom: true,
  };
  const updated = [newItem, ...current];
  try {
    localStorage.setItem(CUSTOM_ATHKAR_KEY, JSON.stringify(updated));
    notifyLocalDataMutation('athkar');
  } catch {
    // ignore
  }
  return updated;
}

export function updateCustomDhikr(id: string, updates: Partial<DhikrItem>): DhikrItem[] {
  const current = loadCustomAthkar();
  const updated = current.map((item) => (item.id === id ? { ...item, ...updates } : item));
  try {
    localStorage.setItem(CUSTOM_ATHKAR_KEY, JSON.stringify(updated));
    notifyLocalDataMutation('athkar');
  } catch {
    // ignore
  }
  return updated;
}

export function deleteCustomDhikr(id: string): DhikrItem[] {
  const current = loadCustomAthkar();
  const updated = current.filter((item) => item.id !== id);
  try {
    localStorage.setItem(CUSTOM_ATHKAR_KEY, JSON.stringify(updated));
    notifyLocalDataMutation('athkar');
  } catch {
    // ignore
  }
  return updated;
}

export function loadNotifications(): NotificationItem[] {
  try {
    const raw = localStorage.getItem(NOTIFICATIONS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Filter out legacy seeded demo items (n-1, n-2, n-3) if present
        const cleaned = parsed.filter(
          (item: NotificationItem) =>
            item && item.id !== 'n-1' && item.id !== 'n-2' && item.id !== 'n-3'
        );
        if (cleaned.length !== parsed.length) {
          localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(cleaned));
        }
        return cleaned;
      }
    }
  } catch {
    // fallback
  }
  return [];
}

export function addNotification(item: Omit<NotificationItem, 'id'> & { id?: string }): NotificationItem[] {
  const current = loadNotifications();

  // Deduplicate if signatureKey or id already exists in the notification center
  if (item.signatureKey) {
    const duplicateSig = current.find((n) => n.signatureKey === item.signatureKey);
    if (duplicateSig) {
      return current;
    }
  }
  if (item.id) {
    const duplicateId = current.find((n) => n.id === item.id);
    if (duplicateId) {
      return current;
    }
  }
  // Also prevent immediate identical title + message duplicate within the top 2 items if both have time === 'الآن'
  if (
    current.length > 0 &&
    current[0].title === item.title &&
    current[0].message === item.message &&
    current[0].time === 'الآن' &&
    item.time === 'الآن'
  ) {
    return current;
  }

  const newItem: NotificationItem = {
    ...item,
    id: item.id || 'n-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
  };
  const updated = [newItem, ...current.slice(0, 49)];
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(updated));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('rifq-in-app-notifications-updated', { detail: updated })
      );
    }
  } catch {
    // ignore
  }
  return updated;
}

export function markNotificationsAsRead(): NotificationItem[] {
  const notifs = loadNotifications().map(n => ({ ...n, read: true }));
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifs));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('rifq-in-app-notifications-updated', { detail: notifs })
      );
    }
  } catch {
    // ignore
  }
  return notifs;
}

export function loadWardProgress(): Record<string, number> {
  try {
    const today = getTodayDateString();
    const raw = localStorage.getItem(`${CURRENT_WARD_PROGRESS_KEY}_${today}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function saveWardProgress(progress: Record<string, number>): void {
  try {
    const today = getTodayDateString();
    localStorage.setItem(`${CURRENT_WARD_PROGRESS_KEY}_${today}`, JSON.stringify(progress));
    notifyLocalDataMutation('athkar');
  } catch {
    // ignore
  }
}

export function getAllAthkar(customItems: DhikrItem[] = []): DhikrItem[] {
  return [
    ...EXPLORER_ATHKAR,
    ...MORNING_ATHKAR,
    ...EVENING_ATHKAR,
    ...SLEEP_ATHKAR,
    ...PRAYER_ATHKAR,
    ...customItems,
  ];
}

// ═══════════════════════════════════════════════════════════════════════════
// إدارة قاعدة البيانات المحلية (SQLite / IndexedDB + LocalStorage) لقسم «قصص الصحابة»
// تشمل الجداول:
// 1. companions_categories (التصنيفات الفرعية الثمانية)
// 2. companions (الاسم، السيرة، الفضائل، المصادر، المرويات، والمفضلة)
// 3. companions_stories (القصص والمواقف الموثقة ومصادرها)
// 4. companions_favorites (سجل الصحابة المفضلين)
// ═══════════════════════════════════════════════════════════════════════════

export const COMPANIONS_SQLITE_DDL_SCHEMA = `-- 1. جدول تصنيفات الصحابة (companions_categories)
CREATE TABLE IF NOT EXISTS companions_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  icon TEXT NOT NULL,
  description TEXT NOT NULL,
  count_label TEXT NOT NULL,
  order_number INTEGER NOT NULL
);

-- 2. جدول بيانات الصحابة وتراجمهم (companions)
CREATE TABLE IF NOT EXISTS companions (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL,
  category_ids_json TEXT NOT NULL,
  name TEXT NOT NULL,
  full_name TEXT NOT NULL,
  title TEXT NOT NULL,
  birth_date TEXT NOT NULL,
  death_date TEXT NOT NULL,
  birth_place TEXT NOT NULL,
  bio TEXT NOT NULL,
  virtues_json TEXT NOT NULL,
  hadiths_count TEXT NOT NULL,
  hadiths_json TEXT NOT NULL,
  death_details TEXT NOT NULL,
  lessons_json TEXT NOT NULL,
  sources_json TEXT NOT NULL,
  gender TEXT NOT NULL,
  order_number INTEGER NOT NULL,
  is_favorite INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (category_id) REFERENCES companions_categories(id)
);
CREATE INDEX IF NOT EXISTS idx_companions_category ON companions(category_id);
CREATE INDEX IF NOT EXISTS idx_companions_favorite ON companions(is_favorite);
CREATE INDEX IF NOT EXISTS idx_companions_name ON companions(name);

-- 3. جدول قصص ومواقف الصحابة الموثقة (companions_stories)
CREATE TABLE IF NOT EXISTS companions_stories (
  id TEXT PRIMARY KEY,
  companion_id TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  reference TEXT NOT NULL,
  order_number INTEGER NOT NULL,
  FOREIGN KEY (companion_id) REFERENCES companions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_companions_stories_companion ON companions_stories(companion_id, order_number);

-- 4. جدول المفضلة للصحابة (companions_favorites)
CREATE TABLE IF NOT EXISTS companions_favorites (
  id TEXT PRIMARY KEY,
  companion_id TEXT NOT NULL UNIQUE,
  added_at TEXT NOT NULL,
  FOREIGN KEY (companion_id) REFERENCES companions(id) ON DELETE CASCADE
);`;

const COMPANIONS_IDB_NAME = 'rifq_companions_sqlite_db_v1';
const COMPANIONS_IDB_VERSION = 1;
const STORE_COMPANIONS_CATEGORIES = 'companions_categories';
const STORE_COMPANIONS = 'companions';
const STORE_COMPANIONS_STORIES = 'companions_stories';
const STORE_COMPANIONS_FAVORITES = 'companions_favorites';

const LS_COMPANIONS_SCHEMA_VERSION_KEY = 'rifq_sqlite_companions_schema_version_v1';
const LS_COMPANIONS_CATEGORIES_TABLE_KEY = 'rifq_sqlite_companions_categories_table_v1';
const LS_COMPANIONS_TABLE_KEY = 'rifq_sqlite_companions_table_v1';
const LS_COMPANIONS_STORIES_TABLE_KEY = 'rifq_sqlite_companions_stories_table_v1';
const LS_COMPANIONS_FAVORITES_TABLE_KEY = 'rifq_sqlite_companions_favorites_table_v1';
const LEGACY_COMPANIONS_FAVORITES_KEY = 'rifq_companions_favorites_v1';
const CURRENT_COMPANIONS_SCHEMA_VERSION = '1.0.0';

let memoryCategoriesTable: CompanionCategorySqliteRow[] | null = null;
let memoryCompanionsTable: CompanionSqliteRow[] | null = null;
let memoryStoriesTable: CompanionStorySqliteRow[] | null = null;
let memoryFavoritesTable: CompanionFavoriteSqliteRow[] | null = null;

function openCompanionsSqliteIndexedDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    try {
      const req = window.indexedDB.open(COMPANIONS_IDB_NAME, COMPANIONS_IDB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_COMPANIONS_CATEGORIES)) {
          db.createObjectStore(STORE_COMPANIONS_CATEGORIES, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORE_COMPANIONS)) {
          const store = db.createObjectStore(STORE_COMPANIONS, { keyPath: 'id' });
          store.createIndex('by_category', 'category_id', { unique: false });
          store.createIndex('by_favorite', 'is_favorite', { unique: false });
          store.createIndex('by_name', 'name', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_COMPANIONS_STORIES)) {
          const sStore = db.createObjectStore(STORE_COMPANIONS_STORIES, { keyPath: 'id' });
          sStore.createIndex('by_companion', 'companion_id', { unique: false });
        }
        if (!db.objectStoreNames.contains(STORE_COMPANIONS_FAVORITES)) {
          const fStore = db.createObjectStore(STORE_COMPANIONS_FAVORITES, { keyPath: 'id' });
          fStore.createIndex('by_companion', 'companion_id', { unique: true });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function syncTablesToIndexedDb(
  categories: CompanionCategorySqliteRow[],
  companions: CompanionSqliteRow[],
  stories: CompanionStorySqliteRow[],
  favorites: CompanionFavoriteSqliteRow[]
): void {
  openCompanionsSqliteIndexedDb().then((db) => {
    if (!db) return;
    try {
      const tx = db.transaction(
        [
          STORE_COMPANIONS_CATEGORIES,
          STORE_COMPANIONS,
          STORE_COMPANIONS_STORIES,
          STORE_COMPANIONS_FAVORITES,
        ],
        'readwrite'
      );
      const catStore = tx.objectStore(STORE_COMPANIONS_CATEGORIES);
      const compStore = tx.objectStore(STORE_COMPANIONS);
      const storyStore = tx.objectStore(STORE_COMPANIONS_STORIES);
      const favStore = tx.objectStore(STORE_COMPANIONS_FAVORITES);

      for (const c of categories) catStore.put(c);
      for (const comp of companions) compStore.put(comp);
      for (const s of stories) storyStore.put(s);
      favStore.clear();
      for (const f of favorites) favStore.put(f);
    } catch {
      // ignore IndexedDB quota or transaction errors
    }
  });
}

function mapCompanionProfileToSqliteRow(
  profile: CompanionProfile,
  isFav: boolean
): CompanionSqliteRow {
  return {
    id: profile.id,
    category_id: profile.category_ids[0] || 'khulafa',
    category_ids_json: JSON.stringify(profile.category_ids),
    name: profile.name,
    full_name: profile.full_name,
    title: profile.title,
    birth_date: profile.birth_date,
    death_date: profile.death_date,
    birth_place: profile.birth_place,
    bio: profile.bio,
    virtues_json: JSON.stringify(profile.virtues),
    hadiths_count: profile.hadiths_count,
    hadiths_json: JSON.stringify(profile.hadiths),
    death_details: profile.death_details,
    lessons_json: JSON.stringify(profile.lessons),
    sources_json: JSON.stringify(profile.sources),
    gender: profile.gender,
    order_number: profile.order_number,
    is_favorite: isFav ? 1 : 0,
  };
}

function mapSqliteRowToCompanionProfile(
  row: CompanionSqliteRow,
  storyRows: CompanionStorySqliteRow[]
): CompanionProfile & { isFavorite: boolean } {
  let categoryIds: CompanionCategoryId[] = [row.category_id as CompanionCategoryId];
  try {
    const parsed = JSON.parse(row.category_ids_json);
    if (Array.isArray(parsed) && parsed.length > 0) {
      categoryIds = parsed;
    }
  } catch {
    // fallback to primary category_id
  }

  let virtues: string[] = [];
  try {
    virtues = JSON.parse(row.virtues_json) || [];
  } catch {
    virtues = [];
  }

  let hadiths: CompanionHadith[] = [];
  try {
    hadiths = JSON.parse(row.hadiths_json) || [];
  } catch {
    hadiths = [];
  }

  let lessons: string[] = [];
  try {
    lessons = JSON.parse(row.lessons_json) || [];
  } catch {
    lessons = [];
  }

  let sources: string[] = [];
  try {
    sources = JSON.parse(row.sources_json) || [];
  } catch {
    sources = [];
  }

  const stories: CompanionStory[] = storyRows
    .filter((s) => s.companion_id === row.id)
    .sort((a, b) => a.order_number - b.order_number)
    .map((s) => ({
      id: s.id,
      companion_id: s.companion_id,
      title: s.title,
      content: s.content,
      reference: s.reference,
      order_number: s.order_number,
    }));

  return {
    id: row.id,
    category_ids: categoryIds,
    name: row.name,
    full_name: row.full_name,
    title: row.title,
    birth_date: row.birth_date,
    death_date: row.death_date,
    birth_place: row.birth_place,
    bio: row.bio,
    virtues,
    stories,
    hadiths_count: row.hadiths_count,
    hadiths,
    death_details: row.death_details,
    lessons,
    sources,
    order_number: row.order_number,
    gender: row.gender,
    isFavorite: row.is_favorite === 1,
  };
}

/**
 * تهيئة جداول SQLite الخاصة ببيانات الصحابة (الاسم، السيرة، الفضائل، المصادر، القصص، التصنيفات، والمفضلة)
 * وتعبئتها بالبيانات الموثقة عند التشغيل الأول.
 */
export function initCompanionsSqliteTables(): {
  categories: CompanionCategorySqliteRow[];
  companions: CompanionSqliteRow[];
  stories: CompanionStorySqliteRow[];
  favorites: CompanionFavoriteSqliteRow[];
} {
  if (
    memoryCategoriesTable &&
    memoryCompanionsTable &&
    memoryStoriesTable &&
    memoryFavoritesTable
  ) {
    return {
      categories: memoryCategoriesTable,
      companions: memoryCompanionsTable,
      stories: memoryStoriesTable,
      favorites: memoryFavoritesTable,
    };
  }

  let existingFavoriteIds: string[] = [];
  try {
    const rawFavTable = localStorage.getItem(LS_COMPANIONS_FAVORITES_TABLE_KEY);
    if (rawFavTable) {
      const parsedFavs: CompanionFavoriteSqliteRow[] = JSON.parse(rawFavTable);
      if (Array.isArray(parsedFavs)) {
        existingFavoriteIds = parsedFavs.map((f) => f.companion_id);
      }
    } else {
      const legacyFavs = localStorage.getItem(LEGACY_COMPANIONS_FAVORITES_KEY);
      if (legacyFavs) {
        const parsedLegacy: string[] = JSON.parse(legacyFavs);
        if (Array.isArray(parsedLegacy)) {
          existingFavoriteIds = parsedLegacy;
        }
      }
    }
  } catch {
    existingFavoriteIds = [];
  }

  const favSet = new Set(existingFavoriteIds);

  try {
    const schemaVer = localStorage.getItem(LS_COMPANIONS_SCHEMA_VERSION_KEY);
    const rawCats = localStorage.getItem(LS_COMPANIONS_CATEGORIES_TABLE_KEY);
    const rawComps = localStorage.getItem(LS_COMPANIONS_TABLE_KEY);
    const rawStories = localStorage.getItem(LS_COMPANIONS_STORIES_TABLE_KEY);
    const rawFavs = localStorage.getItem(LS_COMPANIONS_FAVORITES_TABLE_KEY);

    if (
      schemaVer === CURRENT_COMPANIONS_SCHEMA_VERSION &&
      rawCats &&
      rawComps &&
      rawStories
    ) {
      const parsedCats: CompanionCategorySqliteRow[] = JSON.parse(rawCats);
      const parsedComps: CompanionSqliteRow[] = JSON.parse(rawComps);
      const parsedStories: CompanionStorySqliteRow[] = JSON.parse(rawStories);
      const parsedFavs: CompanionFavoriteSqliteRow[] = rawFavs ? JSON.parse(rawFavs) : [];

      if (
        Array.isArray(parsedCats) &&
        parsedCats.length > 0 &&
        Array.isArray(parsedComps) &&
        parsedComps.length >= ALL_COMPANIONS.length &&
        Array.isArray(parsedStories) &&
        parsedStories.length > 0
      ) {
        memoryCategoriesTable = parsedCats;
        memoryCompanionsTable = parsedComps;
        memoryStoriesTable = parsedStories;
        memoryFavoritesTable = parsedFavs;
        return {
          categories: parsedCats,
          companions: parsedComps,
          stories: parsedStories,
          favorites: parsedFavs,
        };
      }
    }
  } catch {
    // rebuild tables from canonical seed data
  }

  // بناء الجداول الأولية من البيانات الموثقة (Seed SQLite Tables)
  const categoriesRows: CompanionCategorySqliteRow[] = COMPANION_CATEGORIES.map((c, idx) => ({
    id: c.id,
    name: c.name,
    icon: c.icon,
    description: c.description,
    count_label: c.countLabel,
    order_number: idx + 1,
  }));

  const companionsRows: CompanionSqliteRow[] = ALL_COMPANIONS.map((comp) =>
    mapCompanionProfileToSqliteRow(comp, favSet.has(comp.id))
  );

  const storiesRows: CompanionStorySqliteRow[] = [];
  for (const comp of ALL_COMPANIONS) {
    for (const st of comp.stories) {
      storiesRows.push({
        id: st.id,
        companion_id: comp.id,
        title: st.title,
        content: st.content,
        reference: st.reference,
        order_number: st.order_number,
      });
    }
  }

  const nowIso = new Date().toISOString();
  const favoritesRows: CompanionFavoriteSqliteRow[] = Array.from(favSet).map((compId) => ({
    id: `fav_${compId}`,
    companion_id: compId,
    added_at: nowIso,
  }));

  memoryCategoriesTable = categoriesRows;
  memoryCompanionsTable = companionsRows;
  memoryStoriesTable = storiesRows;
  memoryFavoritesTable = favoritesRows;

  try {
    localStorage.setItem(LS_COMPANIONS_SCHEMA_VERSION_KEY, CURRENT_COMPANIONS_SCHEMA_VERSION);
    localStorage.setItem(LS_COMPANIONS_CATEGORIES_TABLE_KEY, JSON.stringify(categoriesRows));
    localStorage.setItem(LS_COMPANIONS_TABLE_KEY, JSON.stringify(companionsRows));
    localStorage.setItem(LS_COMPANIONS_STORIES_TABLE_KEY, JSON.stringify(storiesRows));
    localStorage.setItem(LS_COMPANIONS_FAVORITES_TABLE_KEY, JSON.stringify(favoritesRows));
    localStorage.setItem(LEGACY_COMPANIONS_FAVORITES_KEY, JSON.stringify(Array.from(favSet)));
  } catch {
    // ignore storage quota errors
  }

  syncTablesToIndexedDb(categoriesRows, companionsRows, storiesRows, favoritesRows);

  return {
    categories: categoriesRows,
    companions: companionsRows,
    stories: storiesRows,
    favorites: favoritesRows,
  };
}

/**
 * استرجاع قائمة تصنيفات الصحابة من جدول companions_categories
 */
export function loadCompanionCategoriesFromStorage(): CompanionCategory[] {
  const { categories } = initCompanionsSqliteTables();
  return [...categories]
    .sort((a, b) => a.order_number - b.order_number)
    .map((row) => ({
      id: row.id as CompanionCategoryId,
      name: row.name,
      icon: row.icon,
      description: row.description,
      countLabel: row.count_label,
    }));
}

/**
 * استرجاع كافة بيانات الصحابة مع قصصهم وحالة المفضلة من جداول SQLite المحلية
 */
export function loadCompanionsFromStorage(): (CompanionProfile & { isFavorite: boolean })[] {
  const { companions, stories } = initCompanionsSqliteTables();
  return [...companions]
    .sort((a, b) => a.order_number - b.order_number)
    .map((row) => mapSqliteRowToCompanionProfile(row, stories));
}

/**
 * استرجاع بيانات صحابي محدد بواسطة المعرف (ID) من قاعدة البيانات المحلية
 */
export function getCompanionByIdFromStorage(
  companionId: string
): (CompanionProfile & { isFavorite: boolean }) | null {
  const { companions, stories } = initCompanionsSqliteTables();
  const row = companions.find((c) => c.id === companionId);
  if (!row) return null;
  return mapSqliteRowToCompanionProfile(row, stories);
}

/**
 * استرجاع القصص الموثقة لصحابي محدد من جدول companions_stories
 */
export function getCompanionStoriesFromStorage(companionId: string): CompanionStory[] {
  const { stories } = initCompanionsSqliteTables();
  return stories
    .filter((s) => s.companion_id === companionId)
    .sort((a, b) => a.order_number - b.order_number)
    .map((s) => ({
      id: s.id,
      companion_id: s.companion_id,
      title: s.title,
      content: s.content,
      reference: s.reference,
      order_number: s.order_number,
    }));
}

/**
 * حفظ أو تحديث قصة في جدول companions_stories المحلي
 */
export function saveCompanionStoryToStorage(story: CompanionStory): CompanionStory[] {
  const tables = initCompanionsSqliteTables();
  const existingIdx = tables.stories.findIndex((s) => s.id === story.id);
  const newRow: CompanionStorySqliteRow = {
    id: story.id,
    companion_id: story.companion_id,
    title: story.title,
    content: story.content,
    reference: story.reference,
    order_number: story.order_number,
  };

  if (existingIdx >= 0) {
    tables.stories[existingIdx] = newRow;
  } else {
    tables.stories.push(newRow);
  }
  memoryStoriesTable = [...tables.stories];

  try {
    localStorage.setItem(LS_COMPANIONS_STORIES_TABLE_KEY, JSON.stringify(memoryStoriesTable));
  } catch {
    // ignore
  }

  syncTablesToIndexedDb(
    tables.categories,
    tables.companions,
    memoryStoriesTable,
    tables.favorites
  );

  return getCompanionStoriesFromStorage(story.companion_id);
}

/**
 * استرجاع معرفات الصحابة المفضلين من جدول companions_favorites
 */
export function loadCompanionFavorites(): string[] {
  const { favorites } = initCompanionsSqliteTables();
  return favorites.map((f) => f.companion_id);
}

/**
 * تبديل حالة المفضلة لصحابي في جدولَي companions و companions_favorites
 */
export function toggleCompanionFavorite(companionId: string): {
  favoriteIds: string[];
  isFavorite: boolean;
} {
  const tables = initCompanionsSqliteTables();
  const exists = tables.favorites.some((f) => f.companion_id === companionId);
  let updatedFavorites: CompanionFavoriteSqliteRow[];

  if (exists) {
    updatedFavorites = tables.favorites.filter((f) => f.companion_id !== companionId);
  } else {
    updatedFavorites = [
      ...tables.favorites,
      {
        id: `fav_${companionId}`,
        companion_id: companionId,
        added_at: new Date().toISOString(),
      },
    ];
  }

  const favSet = new Set(updatedFavorites.map((f) => f.companion_id));
  const updatedCompanions = tables.companions.map((comp) => ({
    ...comp,
    is_favorite: favSet.has(comp.id) ? 1 : 0,
  }));

  memoryFavoritesTable = updatedFavorites;
  memoryCompanionsTable = updatedCompanions;

  const favoriteIds = Array.from(favSet);

  try {
    localStorage.setItem(LS_COMPANIONS_FAVORITES_TABLE_KEY, JSON.stringify(updatedFavorites));
    localStorage.setItem(LS_COMPANIONS_TABLE_KEY, JSON.stringify(updatedCompanions));
    localStorage.setItem(LEGACY_COMPANIONS_FAVORITES_KEY, JSON.stringify(favoriteIds));
  } catch {
    // ignore
  }

  syncTablesToIndexedDb(
    tables.categories,
    updatedCompanions,
    tables.stories,
    updatedFavorites
  );

  return {
    favoriteIds,
    isFavorite: !exists,
  };
}

/**
 * تصفية الصحابة حسب التصنيف الفرعي أو المفضلة أو الكل من جداول SQLite
 */
export function filterCompanionsByCategory(
  categoryId: CompanionCategoryId | 'all' | 'favorites' = 'all'
): (CompanionProfile & { isFavorite: boolean })[] {
  const allCompanions = loadCompanionsFromStorage();
  if (categoryId === 'all') {
    return allCompanions;
  }
  if (categoryId === 'favorites') {
    return allCompanions.filter((c) => c.isFavorite);
  }
  return allCompanions.filter((c) => c.category_ids.includes(categoryId));
}

/**
 * البحث عن صحابي (بالاسم، الكنية، اللقب، السيرة، الفضائل، القصص، الأحاديث، أو المصادر)
 * مع التصفية حسب التصنيف المحدد من قاعدة البيانات المحلية
 */
export function searchCompanionsInStorage(
  query: string,
  categoryId: CompanionCategoryId | 'all' | 'favorites' = 'all'
): (CompanionProfile & { isFavorite: boolean })[] {
  const baseList = filterCompanionsByCategory(categoryId);
  const normalizedQuery = normalizeArabicText(query || '');
  if (!normalizedQuery) {
    return baseList;
  }

  return baseList.filter((c) => {
    const searchableCorpus = normalizeArabicText(
      [
        c.name,
        c.full_name,
        c.title,
        c.bio,
        c.birth_place,
        c.death_details,
        ...c.virtues,
        ...c.stories.map((s) => `${s.title} ${s.content} ${s.reference}`),
        ...c.hadiths.map((h) => `${h.text} ${h.source}`),
        ...c.lessons,
        ...c.sources,
      ].join(' ')
    );
    return searchableCorpus.includes(normalizedQuery);
  });
}

/**
 * إحصائيات جداول SQLite الخاصة بقسم قصص الصحابة
 */
export function getCompanionsSqliteStats(): {
  initialized: boolean;
  categoriesCount: number;
  companionsCount: number;
  storiesCount: number;
  favoritesCount: number;
  ddlSchema: string;
} {
  const tables = initCompanionsSqliteTables();
  return {
    initialized: true,
    categoriesCount: tables.categories.length,
    companionsCount: tables.companions.length,
    storiesCount: tables.stories.length,
    favoritesCount: tables.favorites.length,
    ddlSchema: COMPANIONS_SQLITE_DDL_SCHEMA,
  };
}

export * from './misbahaSqlite';
export * from './wasayaSqlite';
export * from './fiqhMuyassarSqlite';
export * from './arbainNawawiyaSqlite';
