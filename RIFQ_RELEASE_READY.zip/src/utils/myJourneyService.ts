import { PrayerKey, ScreenType, WardType } from '../types';
import {
  loadPrayerTrackerHistory,
  savePrayerTrackerStatus,
} from './prayerFocusService';
import { getTodayDateString, loadHistory } from './storage';
import { MORNING_ATHKAR, EVENING_ATHKAR, SLEEP_ATHKAR, PRAYER_ATHKAR } from '../data/athkarData';

export const MY_JOURNEY_STORAGE_KEY = 'rifq_my_journey_state_v1';

export type JourneyCategory =
  | 'prayer'
  | 'quran'
  | 'athkar'
  | 'good_deeds'
  | 'fasting'
  | 'qiyam'
  | 'knowledge';

export type JourneyDifficulty = 'easy' | 'balanced' | 'advanced';

export type JourneyStatusType = 'not_started' | 'available' | 'in_progress' | 'completed';

export interface JourneyStageDef {
  stageNumber: number;
  title: string;
  description: string;
  startDay: number;
  endDay: number;
  badgeIcon: string;
}

export type TaskAutoSyncSource =
  | { type: 'prayer'; prayerKey: Exclude<PrayerKey, 'sunrise'> }
  | { type: 'ward'; wardType: WardType }
  | { type: 'tasbeeh'; targetCount: number }
  | { type: 'fasting' }
  | { type: 'quran_read'; pagesTarget?: number }
  | { type: 'manual' };

export interface JourneyTaskBlueprint {
  id: string;
  title: string;
  subtitle: string;
  category: JourneyCategory;
  autoSyncSource: TaskAutoSyncSource;
  linkedScreen?: ScreenType;
  linkedWard?: WardType;
  linkedActionLabel?: string;
}

export interface JourneyDayBlueprint {
  dayNumber: number;
  title: string;
  stageNumber: number;
  stageTitle: string;
  reflectionQuote: string;
  reflectionSource: string;
  tasks: JourneyTaskBlueprint[];
}

export interface JourneyDefinition {
  id: string;
  title: string;
  shortTitle: string;
  category: JourneyCategory;
  iconEmoji: string;
  description: string;
  goalText: string;
  durationDays: number;
  difficulty: JourneyDifficulty;
  difficultyLabel: string;
  accentColor: string;
  stages: JourneyStageDef[];
}

export interface JourneyEnrollment {
  journeyId: string;
  startedAtDate: string; // YYYY-MM-DD
  lastActiveAt: string;
  /**
   * Manually checked task IDs per day number (e.g. { "1": ["task_a", "task_b"] })
   * Note: Auto-synced tasks (like 5 prayers, tasbeeh, wards, fasting) also sync with their real stores!
   */
  completedTasksByDay: Record<number, string[]>;
  isCompleted?: boolean;
  completedAtDate?: string;
}

export interface ChallengeEnrollment {
  challengeId: string;
  startedAtDate: string;
  completedDays: number[];
}

export interface MyJourneyPersistedState {
  activeJourneyId: string | null;
  enrollments: Record<string, JourneyEnrollment>;
  challenges: Record<string, ChallengeEnrollment>;
  unlockedAchievementIds: string[];
}

export interface ComputedTaskItem extends JourneyTaskBlueprint {
  isCompleted: boolean;
  statusBadge?: string;
}

export interface ComputedDayStatus {
  dayNumber: number;
  dateStr: string; // YYYY-MM-DD corresponding to this day of the journey
  title: string;
  stageNumber: number;
  stageTitle: string;
  reflectionQuote: string;
  reflectionSource: string;
  state: 'completed' | 'current' | 'partial' | 'missed' | 'locked';
  completedTasksCount: number;
  totalTasksCount: number;
  tasks: ComputedTaskItem[];
}

export interface JourneyAchievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: JourneyCategory | 'general';
  requirementText: string;
  targetDays: number;
  journeyIdHint?: string;
}

export interface ComputedAchievement extends JourneyAchievement {
  isUnlocked: boolean;
  currentProgress: number;
  progressPercent: number;
  remainingCount: number;
}

export interface ComputedJourneySummary {
  definition: JourneyDefinition;
  status: JourneyStatusType;
  statusLabelAr: string;
  statusEmoji: string;
  isEnrolled: boolean;
  isActivePrimary: boolean;
  startedAtDate: string | null;
  currentDayNumber: number;
  maxUnlockedDayNumber: number;
  completedDaysCount: number;
  remainingDaysCount: number;
  progressPercent: number;
  currentStage: JourneyStageDef;
  streakDays: number;
  days: ComputedDayStatus[];
  todayDayStatus: ComputedDayStatus;
  nextAchievement: ComputedAchievement | null;
}

export interface JourneyChallengeDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: JourneyCategory;
  durationDays: number;
  dailyTaskTitle: string;
  virtueText: string;
  linkedScreen: ScreenType;
  linkedActionLabel: string;
}

export interface ComputedChallengeItem extends JourneyChallengeDef {
  isJoined: boolean;
  startedAtDate: string | null;
  completedDaysCount: number;
  currentDayNumber: number;
  progressPercent: number;
  isCompletedToday: boolean;
  isCompletedAll: boolean;
}

// ═══════════════════════════════════════════════════════════════════════════
// 1. كتالوج الرحلات الأصلي في «رِفْق | RIFQ»
// ═══════════════════════════════════════════════════════════════════════════

export const JOURNEY_CATALOG: JourneyDefinition[] = [
  {
    id: 'prayer_30',
    title: 'رحلة المحافظة على الصلاة',
    shortTitle: 'المحافظة على الصلاة',
    category: 'prayer',
    iconEmoji: '🌙',
    description:
      'رحلة إيمانية متدرجة لمدة ٣٠ يومًا لتثبيت الصلوات الخمس في أوقاتها، والارتقاء في الخشوع والسنن الرواتب، مرتبطة مباشرة بمتتبع الصلوات ووضع الصلاة والتركيز في رِفْق.',
    goalText: 'إقامة الصلوات الخمس كاملة في وقتها وبخشوع وطمأنينة لمدة ٣٠ يومًا متتالية.',
    durationDays: 30,
    difficulty: 'balanced',
    difficultyLabel: 'متوازن • ٣٠ يومًا',
    accentColor: '#5B5FEF',
    stages: [
      {
        stageNumber: 1,
        title: 'النداء الأول وتثبيت الأركان',
        description: 'الاستجابة الفورية للأذان وأداء الفرائض الخمس في أوقاتها دون تأخير.',
        startDay: 1,
        endDay: 7,
        badgeIcon: '🌱',
      },
      {
        stageNumber: 2,
        title: 'الطمأنينة وأذكار ختام الصلاة',
        description: 'إتمام الفرائض الخمس مع المواظبة على أذكار ما بعد الصلاة المفروضة.',
        startDay: 8,
        endDay: 15,
        badgeIcon: '🌿',
      },
      {
        stageNumber: 3,
        title: 'السنن الرواتب ونوافل القرب',
        description: 'تعزيز الفرائض الخمس بسنن الرواتب وركعتي الضحى لبناء بيت في الجنة.',
        startDay: 16,
        endDay: 23,
        badgeIcon: '🕌',
      },
      {
        stageNumber: 4,
        title: 'رسوخ الخاشعين والمداومة',
        description: 'اكتمال عقد الثلاثين يومًا بحضور القلب والخشوع التام في كل ركعة.',
        startDay: 24,
        endDay: 30,
        badgeIcon: '👑',
      },
    ],
  },
  {
    id: 'prayer_7',
    title: 'رحلة البداية مع الصلاة (٧ أيام)',
    shortTitle: 'البداية مع الصلاة',
    category: 'prayer',
    iconEmoji: '🕌',
    description:
      'انطلاقة مركزة وميسّرة لمدة أسبوع واحد لمعاهدة النفس على عدم تفويت أي فريضة من الصلوات الخمس.',
    goalText: 'أداء ٣٥ صلاة مفروضة في وقتها على مدار ٧ أيام متواصلة.',
    durationDays: 7,
    difficulty: 'easy',
    difficultyLabel: 'ميسّر • ٧ أيام',
    accentColor: '#5B5FEF',
    stages: [
      {
        stageNumber: 1,
        title: 'يقظة القلب',
        description: 'البدء بضبط مواقيت الصلاة وتهيئة النفس قبل الأذان.',
        startDay: 1,
        endDay: 2,
        badgeIcon: '🌱',
      },
      {
        stageNumber: 2,
        title: 'الانتظام اليومي',
        description: 'المواظبة على الصلوات الخمس كاملة في وسط الأسبوع.',
        startDay: 3,
        endDay: 5,
        badgeIcon: '🌿',
      },
      {
        stageNumber: 3,
        title: 'تمام الأسبوع الأول',
        description: 'إتمام سبعة أيام كاملة بنجاح وثبات.',
        startDay: 6,
        endDay: 7,
        badgeIcon: '🏆',
      },
    ],
  },
  {
    id: 'prayer_90',
    title: 'رحلة رسوخ المصلين (٩٠ يومًا)',
    shortTitle: 'رسوخ المصلين ٩٠ يومًا',
    category: 'prayer',
    iconEmoji: '👑',
    description:
      'رحلة الهمم العالية لمدة ثلاثة أشهر لبناء عادة راسخة لا تنقطع في المحافظة على الفرائض والسنن الرواتب والوتر.',
    goalText: 'التزام كامل بالصلوات الخمس وسننها لمدة ٩٠ يومًا حتى تصبح الصلاة قرة عين.',
    durationDays: 90,
    difficulty: 'advanced',
    difficultyLabel: 'متقدم • ٩٠ يومًا',
    accentColor: '#4145C7',
    stages: [
      {
        stageNumber: 1,
        title: 'تأسيس العهد (الأيام ١ - ١٥)',
        description: 'تثبيت الصلوات الخمس في أوقاتها وضبط المنبهات.',
        startDay: 1,
        endDay: 15,
        badgeIcon: '🌱',
      },
      {
        stageNumber: 2,
        title: 'مجاهدة النفس (الأيام ١٦ - ٣٠)',
        description: 'إتمام الشهر الأول مع أذكار الصلاة وتفعيل وضع التركيز.',
        startDay: 16,
        endDay: 30,
        badgeIcon: '🔥',
      },
      {
        stageNumber: 3,
        title: 'حلاوة المناجاة (الأيام ٣١ - ٦٠)',
        description: 'الشهر الثاني: المحافظة على السنن الرواتب الاثنتي عشرة ركعة.',
        startDay: 31,
        endDay: 60,
        badgeIcon: '🕌',
      },
      {
        stageNumber: 4,
        title: 'الثبات الراسخ (الأيام ٦١ - ٩٠)',
        description: 'الشهر الثالث: الرسوخ التام في الفرائض والنوافل والخشوع.',
        startDay: 61,
        endDay: 90,
        badgeIcon: '👑',
      },
    ],
  },
  {
    id: 'quran_7',
    title: 'رحلة القرآن — أُنس التلاوة (٧ أيام)',
    shortTitle: 'رحلة القرآن (٧ أيام)',
    category: 'quran',
    iconEmoji: '📖',
    description:
      'رحلة أسبوعية مباركة للارتباط اليومي بكتاب الله تلاوةً وتدبرًا واستماعًا، ولو بورد ميسّر لا ينقطع.',
    goalText: 'قراءة ورد قرآني يومي وتدبر آية واحدة كل يوم لمدة ٧ أيام.',
    durationDays: 7,
    difficulty: 'easy',
    difficultyLabel: 'ميسّر • ٧ أيام',
    accentColor: '#E8B84A',
    stages: [
      {
        stageNumber: 1,
        title: 'فتح المصحف',
        description: 'كسر الهجر وبداية الورد اليومي بخشوع.',
        startDay: 1,
        endDay: 2,
        badgeIcon: '📖',
      },
      {
        stageNumber: 2,
        title: 'نور التدبر',
        description: 'الجمع بين التلاوة وفهم المعاني وتدبر الآيات.',
        startDay: 3,
        endDay: 5,
        badgeIcon: '✨',
      },
      {
        stageNumber: 3,
        title: 'بركة المواظبة',
        description: 'إتمام الأسبوع القرآني الأول بثبات.',
        startDay: 6,
        endDay: 7,
        badgeIcon: '🏆',
      },
    ],
  },
  {
    id: 'quran_30',
    title: 'رحلة القرآن — ختمة النور والتدبر (٣٠ يومًا)',
    shortTitle: 'رحلة القرآن (٣٠ يومًا)',
    category: 'quran',
    iconEmoji: '📖',
    description:
      'رحلة متكاملة لمدة ٣٠ يومًا لمصاحبة القرآن الكريم تلاوةً لجزء يومي أو ورد ثابت، مع معرفة غريب القرآن وتدبر آياته.',
    goalText: 'ختم القرآن الكريم أو المواظبة على ورد يومي متصل لمدة ٣٠ يومًا مع التدبر.',
    durationDays: 30,
    difficulty: 'balanced',
    difficultyLabel: 'متوازن • ٣٠ يومًا',
    accentColor: '#E8B84A',
    stages: [
      {
        stageNumber: 1,
        title: 'سبع البدايات (الأيام ١ - ٧)',
        description: 'انطلاقة التلاوة اليومية من سورة الفاتحة والبقرة حتى المائدة.',
        startDay: 1,
        endDay: 7,
        badgeIcon: '🌱',
      },
      {
        stageNumber: 2,
        title: 'نصف المسير (الأيام ٨ - ١٥)',
        description: 'الاستمرار في الورد اليومي مع الوقوف عند آية وفائدة.',
        startDay: 8,
        endDay: 15,
        badgeIcon: '📖',
      },
      {
        stageNumber: 3,
        title: 'رياض السور (الأيام ١٦ - ٢٣)',
        description: 'التلاوة المتدبرة وتعلم كلمات غريب القرآن.',
        startDay: 16,
        endDay: 23,
        badgeIcon: '✨',
      },
      {
        stageNumber: 4,
        title: 'مسك الختام ودعاء الختمة (الأيام ٢٤ - ٣٠)',
        description: 'إتمام الورد الثلاثيني المبارك والفوز بصحبة القرآن.',
        startDay: 24,
        endDay: 30,
        badgeIcon: '👑',
      },
    ],
  },
  {
    id: 'athkar_7',
    title: 'رحلة الأذكار — حصن الذاكرين (٧ أيام)',
    shortTitle: 'رحلة الأذكار (٧ أيام)',
    category: 'athkar',
    iconEmoji: '🤲',
    description:
      'رحلة التحصين اليومي بأذكار الصباح والمساء والنوم والتسبيح، مرتبطة تلقائيًا بأورادك ومسبحتك في رِفْق.',
    goalText: 'المحافظة على أذكار الصباح والمساء و١٠٠ تسبيحة يوميًا لمدة ٧ أيام.',
    durationDays: 7,
    difficulty: 'easy',
    difficultyLabel: 'ميسّر • ٧ أيام',
    accentColor: '#72B7E8',
    stages: [
      {
        stageNumber: 1,
        title: 'تحصين الصباح والمساء',
        description: 'بدء اليوم وختامه بذكر الله وحفظه.',
        startDay: 1,
        endDay: 2,
        badgeIcon: '☀️',
      },
      {
        stageNumber: 2,
        title: 'طمأنينة القلب',
        description: 'المواظبة على التسبيح وأذكار النوم.',
        startDay: 3,
        endDay: 5,
        badgeIcon: '📿',
      },
      {
        stageNumber: 3,
        title: 'الذاكر المحصّن',
        description: 'إتمام سبعة أيام كاملة في حمى الرحمن.',
        startDay: 6,
        endDay: 7,
        badgeIcon: '🏆',
      },
    ],
  },
  {
    id: 'athkar_30',
    title: 'رحلة الأذكار — رياض الذاكرين (٣٠ يومًا)',
    shortTitle: 'رحلة الأذكار (٣٠ يومًا)',
    category: 'athkar',
    iconEmoji: '🤲',
    description:
      'شهر كامل في رياض الذكر والتحصين النبوي: أذكار الصباح والمساء والنوم وبعد الصلاة وغراس الجنة في المسبحة.',
    goalText: 'إحياء اللسان والقلب بذكر الله في جميع أحوال اليوم لمدة ٣٠ يومًا.',
    durationDays: 30,
    difficulty: 'balanced',
    difficultyLabel: 'متوازن • ٣٠ يومًا',
    accentColor: '#72B7E8',
    stages: [
      {
        stageNumber: 1,
        title: 'أوراد طرفي النهار',
        description: 'تثبيت أذكار الصباح والمساء في وقتها.',
        startDay: 1,
        endDay: 7,
        badgeIcon: '☀️',
      },
      {
        stageNumber: 2,
        title: 'غراس الجنة والتسبيح',
        description: 'إتمام الأوراد مع المداومة على الباقيات الصالحات في المسبحة.',
        startDay: 8,
        endDay: 15,
        badgeIcon: '🌴',
      },
      {
        stageNumber: 3,
        title: 'الاستغفار والصلاة على النبي ﷺ',
        description: 'تعظيم نصيب اليوم من الاستغفار والصلاة على الرسول ﷺ.',
        startDay: 16,
        endDay: 23,
        badgeIcon: '📿',
      },
      {
        stageNumber: 4,
        title: 'الذاكرون الله كثيرًا',
        description: 'الرسوخ في الذكر حتى يصبح سجية دائمة.',
        startDay: 24,
        endDay: 30,
        badgeIcon: '👑',
      },
    ],
  },
  {
    id: 'good_deeds_7',
    title: 'رحلة الأعمال الصالحة — غراس الخير (٧ أيام)',
    shortTitle: 'الأعمال الصالحة (٧ أيام)',
    category: 'good_deeds',
    iconEmoji: '🌿',
    description:
      'كل يوم باب من أبواب الخير والإحسان: صدقة، برّ بالوالدين، صلة رحم، كلمة طيبة، ودعاء بظهر الغيب.',
    goalText: 'إنجاز عملين صالحين متعدّيين أو قلبيين كل يوم لمدة ٧ أيام.',
    durationDays: 7,
    difficulty: 'easy',
    difficultyLabel: 'ميسّر • ٧ أيام',
    accentColor: '#2E9E6B',
    stages: [
      {
        stageNumber: 1,
        title: 'بذور الإحسان',
        description: 'البدء بالبر والصدقة والابتسامة.',
        startDay: 1,
        endDay: 2,
        badgeIcon: '🌱',
      },
      {
        stageNumber: 2,
        title: 'نفع الخلق',
        description: 'صلة الرحم وإدخال السرور على مسلم.',
        startDay: 3,
        endDay: 5,
        badgeIcon: '🌿',
      },
      {
        stageNumber: 3,
        title: 'حصاد البر',
        description: 'إتمام أسبوع الأعمال الصالحة المباركة.',
        startDay: 6,
        endDay: 7,
        badgeIcon: '🏆',
      },
    ],
  },
  {
    id: 'good_deeds_30',
    title: 'رحلة الأعمال الصالحة — أبواب البر والإحسان (٣٠ يومًا)',
    shortTitle: 'الأعمال الصالحة (٣٠ يومًا)',
    category: 'good_deeds',
    iconEmoji: '🌿',
    description:
      'ثلاثون يومًا من السعي في أبواب الخير المتنوعة بين الصدقات الخفية، وبر الوالدين، وصلة الأرحام، وغراس الجنة.',
    goalText: 'المواظبة اليومية على صنائع المعروف وأعمال القلوب لمدة ٣٠ يومًا.',
    durationDays: 30,
    difficulty: 'balanced',
    difficultyLabel: 'متوازن • ٣٠ يومًا',
    accentColor: '#2E9E6B',
    stages: [
      {
        stageNumber: 1,
        title: 'برّ الأقربين والصدقة',
        description: 'الإحسان إلى الوالدين والأهل والصدقة اليومية ولو بالقليل.',
        startDay: 1,
        endDay: 7,
        badgeIcon: '🌱',
      },
      {
        stageNumber: 2,
        title: 'طهارة القلب واللسان',
        description: 'الكلمة الطيبة والدعاء للمسلمين بظهر الغيب.',
        startDay: 8,
        endDay: 15,
        badgeIcon: '💚',
      },
      {
        stageNumber: 3,
        title: 'قضاء الحوائج وصلة الرحم',
        description: 'تفقد الأرحام وإعانة المحتاج وإماطة الأذى.',
        startDay: 16,
        endDay: 23,
        badgeIcon: '🌿',
      },
      {
        stageNumber: 4,
        title: 'مفاتيح الخير',
        description: 'إتمام شهر كامل من أبواب البر المتواصلة.',
        startDay: 24,
        endDay: 30,
        badgeIcon: '👑',
      },
    ],
  },
  {
    id: 'fasting_8',
    title: 'رحلة الصيام — باب الريّان (٨ أيام مستهدفة)',
    shortTitle: 'رحلة الصيام',
    category: 'fasting',
    iconEmoji: '🌙',
    description:
      'رحلة صيام التطوع (الاثنين والخميس أو الأيام البيض أو القضاء)، مرتبطة بسجل الصيام الهجري في تطبيق رِفْق.',
    goalText: 'إتمام ٨ أيام من الصيام مع المحافظة على السحور والدعاء عند الإفطار.',
    durationDays: 8,
    difficulty: 'balanced',
    difficultyLabel: 'متوازن • ٨ أيام',
    accentColor: '#5B5FEF',
    stages: [
      {
        stageNumber: 1,
        title: 'تجديد نية الصائم',
        description: 'بدء أول يومين من الصيام التطوعي أو القضاء باحتساب.',
        startDay: 1,
        endDay: 2,
        badgeIcon: '🌙',
      },
      {
        stageNumber: 2,
        title: 'ظمأ الهواجر',
        description: 'المواظبة على أيام الصيام مع حفظ الجوارح والدعاء.',
        startDay: 3,
        endDay: 5,
        badgeIcon: '✨',
      },
      {
        stageNumber: 3,
        title: 'بشرى الريّان',
        description: 'إتمام الأيام الثمانية المباركة.',
        startDay: 6,
        endDay: 8,
        badgeIcon: '🏆',
      },
    ],
  },
  {
    id: 'qiyam_14',
    title: 'رحلة قيام الليل — شرف المؤمن (١٤ يومًا)',
    shortTitle: 'رحلة قيام الليل',
    category: 'qiyam',
    iconEmoji: '🌃',
    description:
      'رحلة الأنس بالله في جوف الليل: صلاة الوتر، ركعتان في السحر، قراءة سورة الملك قبل النوم، والاستغفار بالأسحار.',
    goalText: 'المحافظة على الوتر وقيام الليل وأذكار النوم لمدة ١٤ ليلة متتالية.',
    durationDays: 14,
    difficulty: 'balanced',
    difficultyLabel: 'متوازن • ١٤ ليلة',
    accentColor: '#4145C7',
    stages: [
      {
        stageNumber: 1,
        title: 'الوتر وأذكار النوم',
        description: 'ختم اليوم بصلاة الوتر وأذكار النوم على طهارة.',
        startDay: 1,
        endDay: 4,
        badgeIcon: '🌙',
      },
      {
        stageNumber: 2,
        title: 'ركعتا جوف الليل',
        description: 'القيام بركعتين خفيفتين ومناجاة الله في السحر.',
        startDay: 5,
        endDay: 9,
        badgeIcon: '🌃',
      },
      {
        stageNumber: 3,
        title: 'المستغفرين بالأسحار',
        description: 'إتمام ١٤ ليلة من القيام والوتر والاستغفار.',
        startDay: 10,
        endDay: 14,
        badgeIcon: '👑',
      },
    ],
  },
  {
    id: 'knowledge_14',
    title: 'رحلة طلب العلم — ميراث النبوة (١٤ يومًا)',
    shortTitle: 'رحلة طلب العلم',
    category: 'knowledge',
    iconEmoji: '📚',
    description:
      'رحلة معرفية ماتعة داخل مكتبة رِفْق: قراءة حديث يومي من الأربعين النووية، مسألة من الفقه الميسر، وسيرة صحابي جليل.',
    goalText: 'التفقه اليومي في الحديث والفقه والسيرة والتفسير لمدة ١٤ يومًا.',
    durationDays: 14,
    difficulty: 'balanced',
    difficultyLabel: 'متوازن • ١٤ يومًا',
    accentColor: '#E8B84A',
    stages: [
      {
        stageNumber: 1,
        title: 'أنوار السنة النبوية',
        description: 'مدارسة أحاديث الأربعين النووية ووصايا الرسول ﷺ.',
        startDay: 1,
        endDay: 4,
        badgeIcon: '📜',
      },
      {
        stageNumber: 2,
        title: 'فقه العبادة والقرآن',
        description: 'تعلم أحكام الفقه الميسر وغريب القرآن وأحكام التجويد.',
        startDay: 5,
        endDay: 9,
        badgeIcon: '📚',
      },
      {
        stageNumber: 3,
        title: 'قدوات الصحابة والعلماء',
        description: 'القراءة في سير الصحابة الكرام وإتمام أسبوعي العلم.',
        startDay: 10,
        endDay: 14,
        badgeIcon: '🎓',
      },
    ],
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// 2. التحديات الإيمانية المركزة داخل قسم «رحلتي»
// ═══════════════════════════════════════════════════════════════════════════

export const CHALLENGE_CATALOG: JourneyChallengeDef[] = [
  {
    id: 'challenge_fajr_7',
    title: 'تحدي فجر النور (٧ أيام)',
    description: 'أداء صلاة الفجر في وقتها لمدة ٧ أيام متتالية لتكون في ذمة الله وحفظه.',
    icon: '🌅',
    category: 'prayer',
    durationDays: 7,
    dailyTaskTitle: 'صلاة الفجر في وقتها اليوم',
    virtueText: 'قال ﷺ: «مَنْ صَلَّى الصُّبْحَ فَهُوَ فِي ذِمَّةِ اللَّهِ» (رواه مسلم).',
    linkedScreen: 'prayers',
    linkedActionLabel: 'فتح المواقيت',
  },
  {
    id: 'challenge_morning_evening_7',
    title: 'تحدي درع الذاكرين (٧ أيام)',
    description: 'إتمام أذكار الصباح وأذكار المساء يوميًا لمدة أسبوع كامل دون انقطاع.',
    icon: '🛡️',
    category: 'athkar',
    durationDays: 7,
    dailyTaskTitle: 'أذكار الصباح والمساء اليوم',
    virtueText: 'أذكار الصباح والمساء حصن حصين للمسلم وراحة للقلب في يومه وليلته.',
    linkedScreen: 'ward',
    linkedActionLabel: 'فتح الأوراد',
  },
  {
    id: 'challenge_mulk_7',
    title: 'تحدي سورة الملك المنجية (٧ ليالٍ)',
    description: 'قراءة سورة الملك (تبارك) كل ليلة قبل النوم لمدة ٧ ليالٍ متتالية.',
    icon: '📖',
    category: 'quran',
    durationDays: 7,
    dailyTaskTitle: 'قراءة سورة الملك هذه الليلة',
    virtueText: 'قال ﷺ: «سُورَةٌ مِنَ الْقُرْآنِ ثَلَاثُونَ آيَةً شَفَعَتْ لِرَجُلٍ حَتَّى غُفِرَ لَهُ: تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ».',
    linkedScreen: 'quran',
    linkedActionLabel: 'فتح المصحف',
  },
  {
    id: 'challenge_tasbeeh_7',
    title: 'تحدي غراس الجنة (١٠٠ تسبيحة يوميًا)',
    description: 'إتمام ١٠٠ تسبيحة واستغفار كل يوم في مسبحة رِفْق لمدة ٧ أيام.',
    icon: '📿',
    category: 'athkar',
    durationDays: 7,
    dailyTaskTitle: 'إتمام ١٠٠ تسبيحة في المسبحة اليوم',
    virtueText: 'قال ﷺ: «مَنْ قَالَ سُبْحَانَ اللَّهِ وَبِحَمْدِهِ فِي يَوْمٍ مِائَةَ مَرَّةٍ حُطَّتْ خَطَايَاهُ».',
    linkedScreen: 'tasbeeh',
    linkedActionLabel: 'فتح المسبحة',
  },
  {
    id: 'challenge_witr_7',
    title: 'تحدي ختم اليوم بالوتر (٧ ليالٍ)',
    description: 'المحافظة على صلاة الوتر قبل النوم كل ليلة لمدة أسبوع.',
    icon: '🌃',
    category: 'qiyam',
    durationDays: 7,
    dailyTaskTitle: 'أداء صلاة الوتر هذه الليلة',
    virtueText: 'قال ﷺ: «اجْعَلُوا آخِرَ صَلَاتِكُمْ بِاللَّيْلِ وِتْرًا» (متفق عليه).',
    linkedScreen: 'prayers',
    linkedActionLabel: 'فتح المواقيت',
  },
  {
    id: 'challenge_sadaqah_7',
    title: 'تحدي صنائع المعروف والصدقة (٧ أيام)',
    description: 'تقديم صدقة أو كلمة طيبة أو إعانة لمسلم كل يوم لمدة ٧ أيام.',
    icon: '🌿',
    category: 'good_deeds',
    durationDays: 7,
    dailyTaskTitle: 'صدقة أو معروف خالص لله اليوم',
    virtueText: 'قال ﷺ: «كُلُّ مَعْرُوفٍ صَدَقَةٌ»، و«الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ».',
    linkedScreen: 'tasbeeh',
    linkedActionLabel: 'فتح المسبحة',
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// 3. قائمة الإنجازات والأوسمة (Achievements & Milestones)
// ═══════════════════════════════════════════════════════════════════════════

export const JOURNEY_ACHIEVEMENTS: JourneyAchievement[] = [
  {
    id: 'ach_first_step',
    title: 'بذرة الالتزام',
    description: 'بدء أول رحلة عبادة وإتمام مهام اليوم الأول بنجاح.',
    icon: '🌱',
    category: 'general',
    requirementText: 'إتمام يوم واحد في أي رحلة',
    targetDays: 1,
  },
  {
    id: 'ach_three_days',
    title: 'ثبات البدايات',
    description: 'إتمام ٣ أيام في رحلة إيمانية بهمة ونشاط.',
    icon: '🌿',
    category: 'general',
    requirementText: 'إتمام ٣ أيام في رحلة',
    targetDays: 3,
  },
  {
    id: 'ach_week_flame',
    title: 'شعلة الأسبوع المبارك',
    description: 'إتمام ٧ أيام كاملة في رحلات العبادة.',
    icon: '🔥',
    category: 'general',
    requirementText: 'إتمام ٧ أيام في الرحلات',
    targetDays: 7,
  },
  {
    id: 'ach_prayer_guardian',
    title: 'حارس الصلوات الخمس',
    description: 'إتمام ٧ أيام من المحافظة على الصلوات الخمس في وقتها.',
    icon: '🕌',
    category: 'prayer',
    requirementText: 'إتمام ٧ أيام في رحلة الصلاة',
    targetDays: 7,
    journeyIdHint: 'prayer_30',
  },
  {
    id: 'ach_quran_companion',
    title: 'رفيق القرآن المتدبر',
    description: 'المواظبة على الورد القرآني لمدة ٧ أيام في رحلة القرآن.',
    icon: '📖',
    category: 'quran',
    requirementText: 'إتمام ٧ أيام في رحلة القرآن',
    targetDays: 7,
    journeyIdHint: 'quran_30',
  },
  {
    id: 'ach_athkar_shield',
    title: 'الذاكر المطمئن',
    description: 'المواظبة على الأذكار والتسبيح لمدة ٧ أيام.',
    icon: '🤲',
    category: 'athkar',
    requirementText: 'إتمام ٧ أيام في رحلة الأذكار',
    targetDays: 7,
    journeyIdHint: 'athkar_30',
  },
  {
    id: 'ach_half_month',
    title: 'نصف القمر الإيماني',
    description: 'الوصول إلى ١٥ يومًا مكتملًا في رحلات الطاعة.',
    icon: '🌕',
    category: 'general',
    requirementText: 'إتمام ١٥ يومًا في الرحلات',
    targetDays: 15,
  },
  {
    id: 'ach_good_deeds',
    title: 'غراس الإحسان',
    description: 'إتمام ٧ أيام في رحلة الأعمال الصالحة أو التحديات.',
    icon: '🌴',
    category: 'good_deeds',
    requirementText: 'إتمام ٧ أيام من الأعمال الصالحة',
    targetDays: 7,
    journeyIdHint: 'good_deeds_30',
  },
  {
    id: 'ach_full_journey',
    title: 'تاج التمام والرسوخ',
    description: 'إتمام ٣٠ يومًا أو إنهاء رحلة عبادة كاملة بنسبة ١٠٠٪.',
    icon: '👑',
    category: 'general',
    requirementText: 'إتمام ٣٠ يومًا أو رحلة كاملة',
    targetDays: 30,
  },
];

// ═══════════════════════════════════════════════════════════════════════════
// 4. التأملات الإيمانية اليومية ومولد المهام لكل يوم من أيام الرحلة
// ═══════════════════════════════════════════════════════════════════════════

const DAILY_REFLECTIONS: { quote: string; source: string }[] = [
  {
    quote: '«أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ»',
    source: 'متفق عليه',
  },
  {
    quote: '﴿وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ وَإِنَّهَا لَكَبِيرَةٌ إِلَّا عَلَى الْخَاشِعِينَ﴾',
    source: 'سورة البقرة: ٤٥',
  },
  {
    quote: '«جُعِلَتْ قُرَّةُ عَيْنِي فِي الصَّلَاةِ»',
    source: 'رواه النسائي وأحمد',
  },
  {
    quote: '﴿أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ﴾',
    source: 'سورة الرعد: ٢٨',
  },
  {
    quote: '«اقْرَؤُوا الْقُرْآنَ فَإِنَّهُ يَأْتِي يَوْمَ الْقِيَامَةِ شَفِيعًا لِأَصْحَابِهِ»',
    source: 'صحيح مسلم',
  },
  {
    quote: '﴿وَالَّذِينَ جَاهَدُوا فِينَا لَنَهْدِيَنَّهُمْ سُبُلَنَا وَإِنَّ اللَّهَ لَمَعَ الْمُحْسِنِينَ﴾',
    source: 'سورة العنكبوت: ٦٩',
  },
  {
    quote: '«مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ»',
    source: 'صحيح مسلم',
  },
  {
    quote: '﴿إِنَّ الحَسَنَاتِ يُذْهِبْنَ السَّيِّئَاتِ ذَلِكَ ذِكْرَى لِلذَّاكِرِينَ﴾',
    source: 'سورة هود: ١١٤',
  },
  {
    quote: '«أَقْرَبُ مَا يَكُونُ الْعَبْدُ مِنْ رَبِّهِ وَهُوَ سَاجِدٌ فَأَكْثِرُوا الدُّعَاءَ»',
    source: 'صحيح مسلم',
  },
  {
    quote: '﴿وَسَارِعُوا إِلَى مَغْفِرَةٍ مِنْ رَبِّكُمْ وَجَنَّةٍ عَرْضُهَا السَّمَاوَاتُ وَالأَرْضُ﴾',
    source: 'سورة آل عمران: ١٣٣',
  },
];

export function getJourneyDefinition(journeyId: string): JourneyDefinition {
  return JOURNEY_CATALOG.find((j) => j.id === journeyId) || JOURNEY_CATALOG[0];
}

export function getStageForDay(def: JourneyDefinition, dayNumber: number): JourneyStageDef {
  return (
    def.stages.find((s) => dayNumber >= s.startDay && dayNumber <= s.endDay) ||
    def.stages[def.stages.length - 1]
  );
}

export function getJourneyDayBlueprint(journeyId: string, dayNumber: number): JourneyDayBlueprint {
  const def = getJourneyDefinition(journeyId);
  const stage = getStageForDay(def, dayNumber);
  const reflection = DAILY_REFLECTIONS[(dayNumber - 1) % DAILY_REFLECTIONS.length];

  if (def.category === 'prayer') {
    const tasks: JourneyTaskBlueprint[] = [
      {
        id: 'prayer_fajr',
        title: 'صلاة الفجر',
        subtitle: 'أداء فريضة الفجر في وقتها',
        category: 'prayer',
        autoSyncSource: { type: 'prayer', prayerKey: 'fajr' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      },
      {
        id: 'prayer_dhuhr',
        title: 'صلاة الظهر',
        subtitle: 'أداء فريضة الظهر في وقتها',
        category: 'prayer',
        autoSyncSource: { type: 'prayer', prayerKey: 'dhuhr' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      },
      {
        id: 'prayer_asr',
        title: 'صلاة العصر',
        subtitle: 'المحافظة على الصلاة الوسطى في وقتها',
        category: 'prayer',
        autoSyncSource: { type: 'prayer', prayerKey: 'asr' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      },
      {
        id: 'prayer_maghrib',
        title: 'صلاة المغرب',
        subtitle: 'أداء فريضة المغرب في أول وقتها',
        category: 'prayer',
        autoSyncSource: { type: 'prayer', prayerKey: 'maghrib' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      },
      {
        id: 'prayer_isha',
        title: 'صلاة العشاء',
        subtitle: 'أداء فريضة العشاء بطمأنينة وخشوع',
        category: 'prayer',
        autoSyncSource: { type: 'prayer', prayerKey: 'isha' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      },
    ];

    if (dayNumber >= 8) {
      tasks.push({
        id: 'prayer_athkar_after',
        title: 'أذكار بعد الصلاة المفروضة',
        subtitle: 'التسبيح والتحميد والتكبير وآية الكرسي دبر الصلوات',
        category: 'athkar',
        autoSyncSource: { type: 'ward', wardType: 'prayer' },
        linkedScreen: 'ward',
        linkedWard: 'prayer',
        linkedActionLabel: 'أذكار الصلاة',
      });
    }

    if (dayNumber >= 16) {
      tasks.push({
        id: 'prayer_sunnah_rawatib',
        title: 'السنن الرواتب أو ركعتا الضحى',
        subtitle: 'جبر الفرائض وبناء بيت في الجنة بالسنن الرواتب',
        category: 'prayer',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      });
    }

    return {
      dayNumber,
      title: `اليوم ${dayNumber} — ${stage.title}`,
      stageNumber: stage.stageNumber,
      stageTitle: stage.title,
      reflectionQuote: reflection.quote,
      reflectionSource: reflection.source,
      tasks,
    };
  }

  if (def.category === 'quran') {
    const juzOrPartNum = ((dayNumber - 1) % 30) + 1;
    const tasks: JourneyTaskBlueprint[] = [
      {
        id: 'quran_daily_wird',
        title:
          def.durationDays === 30
            ? `تلاوة ورد الجزء (${juzOrPartNum}) من المصحف`
            : `تلاوة الورد القرآني لليوم (${dayNumber})`,
        subtitle: 'قراءة بتؤدة وترتيل من مصحف رِفْق أو الورد اليومي',
        category: 'quran',
        autoSyncSource: { type: 'quran_read' },
        linkedScreen: 'quran',
        linkedActionLabel: 'فتح المصحف',
      },
      {
        id: 'quran_tadabbur_ayah',
        title: 'تدبر آية وفائدة من ورد اليوم',
        subtitle: 'الوقوف عند معنى آية والعمل بهدايتها في يومك',
        category: 'quran',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'tadabbur',
        linkedActionLabel: 'آية وفائدة',
      },
      {
        id: 'quran_gharib_word',
        title: 'معرفة معنى كلمة من غريب القرآن',
        subtitle: 'فهم مفردات كتاب الله عز وجل',
        category: 'quran',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'gharib_quran',
        linkedActionLabel: 'غريب القرآن',
      },
    ];

    return {
      dayNumber,
      title: `اليوم ${dayNumber} — ${stage.title}`,
      stageNumber: stage.stageNumber,
      stageTitle: stage.title,
      reflectionQuote: reflection.quote,
      reflectionSource: reflection.source,
      tasks,
    };
  }

  if (def.category === 'athkar') {
    const tasks: JourneyTaskBlueprint[] = [
      {
        id: 'athkar_morning',
        title: 'أذكار الصباح كاملة',
        subtitle: 'تحصين الصباح وبداية اليوم بذكر الله',
        category: 'athkar',
        autoSyncSource: { type: 'ward', wardType: 'morning' },
        linkedScreen: 'ward',
        linkedWard: 'morning',
        linkedActionLabel: 'أذكار الصباح',
      },
      {
        id: 'athkar_evening',
        title: 'أذكار المساء كاملة',
        subtitle: 'تحصين المساء والسكينة القلبية',
        category: 'athkar',
        autoSyncSource: { type: 'ward', wardType: 'evening' },
        linkedScreen: 'ward',
        linkedWard: 'evening',
        linkedActionLabel: 'أذكار المساء',
      },
      {
        id: 'athkar_tasbeeh_100',
        title: '١٠٠ تسبيحة واستغفار في المسبحة',
        subtitle: 'سبحان الله وبحمده، أستغفر الله وأتوب إليه',
        category: 'athkar',
        autoSyncSource: { type: 'tasbeeh', targetCount: 100 },
        linkedScreen: 'tasbeeh',
        linkedActionLabel: 'فتح المسبحة',
      },
      {
        id: 'athkar_sleep',
        title: 'أذكار النوم قبل المنام',
        subtitle: 'ختام اليوم بذكر الله على طهارة',
        category: 'athkar',
        autoSyncSource: { type: 'ward', wardType: 'sleep' },
        linkedScreen: 'ward',
        linkedWard: 'sleep',
        linkedActionLabel: 'أذكار النوم',
      },
    ];

    return {
      dayNumber,
      title: `اليوم ${dayNumber} — ${stage.title}`,
      stageNumber: stage.stageNumber,
      stageTitle: stage.title,
      reflectionQuote: reflection.quote,
      reflectionSource: reflection.source,
      tasks,
    };
  }

  if (def.category === 'good_deeds') {
    const deedTopics = [
      'صدقة يومية ولو بالقليل أو إطعام طعام',
      'برّ الوالدين وإدخال السرور على قلبيهما',
      'صلة رحم أو سؤال عن قريب ومريض',
      'دعاء صادق بظهر الغيب لأخيك المسلم',
      'كفّ الأذى، الكلمة الطيبة، وإفشاء السلام',
      'إعانة ذي حاجة أو تفريج كربة',
      'نشر علم نافع أو تذكير بخير',
    ];
    const specificDeed = deedTopics[(dayNumber - 1) % deedTopics.length];

    const tasks: JourneyTaskBlueprint[] = [
      {
        id: 'deed_primary',
        title: specificDeed,
        subtitle: 'عمل صالح خالص لوجه الله الكريم في هذا اليوم',
        category: 'good_deeds',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'harvest',
        linkedActionLabel: 'حصاد الأعمال',
      },
      {
        id: 'deed_garden_plant',
        title: 'غرس شجرة أو نخلة في بستان التسبيح',
        subtitle: 'أكثر من الباقيات الصالحات (٥٠ تسبيحة على الأقل)',
        category: 'athkar',
        autoSyncSource: { type: 'tasbeeh', targetCount: 50 },
        linkedScreen: 'tasbeeh',
        linkedActionLabel: 'فتح المسبحة',
      },
      {
        id: 'deed_dua_muslims',
        title: 'الدعاء للمسلمين والوالدين والاستغفار لهم',
        subtitle: 'دعوة المرء المسلم لأخيه بظهر الغيب مستجابة',
        category: 'good_deeds',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'athkar',
        linkedActionLabel: 'الأدعية',
      },
    ];

    return {
      dayNumber,
      title: `اليوم ${dayNumber} — ${stage.title}`,
      stageNumber: stage.stageNumber,
      stageTitle: stage.title,
      reflectionQuote: reflection.quote,
      reflectionSource: reflection.source,
      tasks,
    };
  }

  if (def.category === 'fasting') {
    const tasks: JourneyTaskBlueprint[] = [
      {
        id: 'fasting_day_log',
        title: `إتمام صيام اليوم (${dayNumber}) إيمانًا واحتسابًا`,
        subtitle: 'من صام يومًا في سبيل الله باعد الله وجهه عن النار سبعين خريفًا',
        category: 'fasting',
        autoSyncSource: { type: 'fasting' },
        linkedScreen: 'hijri_fasting',
        linkedActionLabel: 'التقويم والصيام',
      },
      {
        id: 'fasting_suhoor_dua',
        title: 'أكلة السحور والدعاء عند الإفطار',
        subtitle: 'تسحروا فإن في السحور بركة، وللصائم عند فطره دعوة لا ترد',
        category: 'fasting',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'hijri_fasting',
        linkedActionLabel: 'آداب الصيام',
      },
      {
        id: 'fasting_fajr_maghrib',
        title: 'أداء صلاتي الفجر والمغرب في وقتهما',
        subtitle: 'افتتاح يوم الصيام بصلاة الفجر وختمه بصلاة المغرب',
        category: 'prayer',
        autoSyncSource: { type: 'prayer', prayerKey: 'maghrib' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      },
    ];

    return {
      dayNumber,
      title: `اليوم ${dayNumber} — ${stage.title}`,
      stageNumber: stage.stageNumber,
      stageTitle: stage.title,
      reflectionQuote: reflection.quote,
      reflectionSource: reflection.source,
      tasks,
    };
  }

  if (def.category === 'qiyam') {
    const tasks: JourneyTaskBlueprint[] = [
      {
        id: 'qiyam_witr',
        title: 'أداء صلاة الوتر قبل النوم أو في السحر',
        subtitle: 'إن الله وتر يحب الوتر فأوتروا يا أهل القرآن',
        category: 'qiyam',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'prayers',
        linkedActionLabel: 'المواقيت',
      },
      {
        id: 'qiyam_two_rakaat',
        title: 'صلاة ركعتين في جوف الليل ومناجاة الله',
        subtitle: 'أفضل الصلاة بعد الفريضة صلاة الليل',
        category: 'qiyam',
        autoSyncSource: { type: 'manual' },
        linkedScreen: 'quran',
        linkedActionLabel: 'فتح المصحف',
      },
      {
        id: 'qiyam_sleep_athkar',
        title: 'أذكار النوم والوضوء قبل المنام',
        subtitle: 'النوم على طهارة وذكر الله عز وجل',
        category: 'athkar',
        autoSyncSource: { type: 'ward', wardType: 'sleep' },
        linkedScreen: 'ward',
        linkedWard: 'sleep',
        linkedActionLabel: 'أذكار النوم',
      },
    ];

    return {
      dayNumber,
      title: `الليلة ${dayNumber} — ${stage.title}`,
      stageNumber: stage.stageNumber,
      stageTitle: stage.title,
      reflectionQuote: reflection.quote,
      reflectionSource: reflection.source,
      tasks,
    };
  }

  // knowledge_14
  const tasks: JourneyTaskBlueprint[] = [
    {
      id: 'knowledge_hadith',
      title: `مدارسة حديث من «الأربعون النووية» أو «الأحاديث»`,
      subtitle: 'قراءة الحديث النبوي وفهم معناه وفوائده',
      category: 'knowledge',
      autoSyncSource: { type: 'manual' },
      linkedScreen: 'arbain_nawawiya',
      linkedActionLabel: 'الأربعون النووية',
    },
    {
      id: 'knowledge_fiqh',
      title: 'قراءة مسألة من «الفقه الميسر» أو «أحكام التجويد»',
      subtitle: 'من يرد الله به خيرًا يفقهه في الدين',
      category: 'knowledge',
      autoSyncSource: { type: 'manual' },
      linkedScreen: 'fiqh_muyassar',
      linkedActionLabel: 'الفقه الميسر',
    },
    {
      id: 'knowledge_companion',
      title: 'قراءة موقف أو ترجمة من «قصص الصحابة» أو «وصايا الرسول ﷺ»',
      subtitle: 'الاقتداء بسير خير القرون رضي الله عنهم',
      category: 'knowledge',
      autoSyncSource: { type: 'manual' },
      linkedScreen: 'companions_stories',
      linkedActionLabel: 'قصص الصحابة',
    },
  ];

  return {
    dayNumber,
    title: `اليوم ${dayNumber} — ${stage.title}`,
    stageNumber: stage.stageNumber,
    stageTitle: stage.title,
    reflectionQuote: reflection.quote,
    reflectionSource: reflection.source,
    tasks,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// 5. إدارة الحالة والتخزين المحلي والسحابي (Storage & Real Activity Sync)
// ═══════════════════════════════════════════════════════════════════════════

export function getDefaultMyJourneyState(): MyJourneyPersistedState {
  return {
    activeJourneyId: null,
    enrollments: {},
    challenges: {},
    unlockedAchievementIds: [],
  };
}

export function loadMyJourneyState(): MyJourneyPersistedState {
  try {
    const raw = localStorage.getItem(MY_JOURNEY_STORAGE_KEY);
    if (!raw) return getDefaultMyJourneyState();
    const parsed = JSON.parse(raw);
    return {
      activeJourneyId: parsed.activeJourneyId || null,
      enrollments: parsed.enrollments || {},
      challenges: parsed.challenges || {},
      unlockedAchievementIds: Array.isArray(parsed.unlockedAchievementIds)
        ? parsed.unlockedAchievementIds
        : [],
    };
  } catch {
    return getDefaultMyJourneyState();
  }
}

export function saveMyJourneyState(state: MyJourneyPersistedState): void {
  try {
    localStorage.setItem(MY_JOURNEY_STORAGE_KEY, JSON.stringify(state));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('rifq-journey-updated'));
      window.dispatchEvent(
        new CustomEvent('rifq-local-data-mutated', {
          detail: { domain: 'history', immediate: false },
        })
      );
    }
  } catch {
    // ignore
  }
}

/**
 * Helper to add days to a YYYY-MM-DD string
 */
export function addDaysToDateStr(baseDateStr: string, offsetDays: number): string {
  const parts = baseDateStr.split('-').map(Number);
  if (parts.length !== 3 || parts.some(Number.isNaN)) {
    return getTodayDateString();
  }
  const d = new Date(parts[0], parts[1] - 1, parts[2]);
  d.setDate(d.getDate() + offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Difference in calendar days between two YYYY-MM-DD strings (end - start)
 */
export function diffCalendarDays(startDateStr: string, endDateStr: string): number {
  const s = startDateStr.split('-').map(Number);
  const e = endDateStr.split('-').map(Number);
  if (s.length !== 3 || e.length !== 3) return 0;
  const dStart = new Date(s[0], s[1] - 1, s[2]);
  const dEnd = new Date(e[0], e[1] - 1, e[2]);
  return Math.round((dEnd.getTime() - dStart.getTime()) / (1000 * 60 * 60 * 24));
}

function loadWardProgressForDate(dateStr: string): Record<string, number> {
  try {
    const raw = localStorage.getItem(`mushaba_ward_progress_v1_${dateStr}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function isWardCompletedOnDate(wardType: WardType, dateStr: string): { done: boolean; ratioText: string } {
  const counts = loadWardProgressForDate(dateStr);
  const list = {
    morning: MORNING_ATHKAR,
    evening: EVENING_ATHKAR,
    sleep: SLEEP_ATHKAR,
    prayer: PRAYER_ATHKAR,
  }[wardType];

  if (!list || list.length === 0) return { done: false, ratioText: '' };
  const completedItems = list.filter((item) => (counts[item.id] || 0) >= item.countTarget).length;
  if (completedItems === 0) return { done: false, ratioText: '' };
  return {
    done: completedItems >= Math.ceil(list.length * 0.5),
    ratioText: `${completedItems}/${list.length} أذكار`,
  };
}

function isFastingLoggedOnDate(dateStr: string): boolean {
  try {
    const raw = localStorage.getItem('rifq_hijri_fasting_state');
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    const completed: string[] = Array.isArray(parsed.completedDates) ? parsed.completedDates : [];
    const voluntary: string[] = Array.isArray(parsed.voluntaryFastDates) ? parsed.voluntaryFastDates : [];
    return completed.includes(dateStr) || voluntary.includes(dateStr);
  } catch {
    return false;
  }
}

function toggleFastingLogOnDate(dateStr: string, shouldBeLogged: boolean): void {
  try {
    const raw = localStorage.getItem('rifq_hijri_fasting_state');
    const parsed = raw
      ? JSON.parse(raw)
      : {
          totalDaysOwed: 5,
          completedDates: [],
          voluntaryFastDates: [],
          remindersEnabled: true,
        };
    const voluntary: string[] = Array.isArray(parsed.voluntaryFastDates)
      ? [...parsed.voluntaryFastDates]
      : [];
    if (shouldBeLogged && !voluntary.includes(dateStr)) {
      voluntary.push(dateStr);
    } else if (!shouldBeLogged) {
      const idx = voluntary.indexOf(dateStr);
      if (idx >= 0) voluntary.splice(idx, 1);
    }
    parsed.voluntaryFastDates = voluntary;
    localStorage.setItem('rifq_hijri_fasting_state', JSON.stringify(parsed));
  } catch {
    // ignore
  }
}

function wasQuranReadOnDate(dateStr: string): boolean {
  try {
    const raw = localStorage.getItem('mushaba_quran_last_read_v1');
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    if (!parsed.timestamp) return false;
    const d = new Date(parsed.timestamp);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}` === dateStr;
  } catch {
    return false;
  }
}

/**
 * Evaluates a task's real completion status on a given date using both RIFQ's real activity stores
 * and the user's journey task checkmarks.
 */
export function evaluateTaskCompletion(
  task: JourneyTaskBlueprint,
  dateStr: string,
  manuallyCompletedIds: string[],
  prayerHistory: ReturnType<typeof loadPrayerTrackerHistory>,
  tasbeehHistory: ReturnType<typeof loadHistory>
): { isCompleted: boolean; statusBadge?: string } {
  const isManualChecked = manuallyCompletedIds.includes(task.id);
  const src = task.autoSyncSource;

  if (src.type === 'prayer') {
    const prayerStatus = prayerHistory[dateStr]?.prayers?.[src.prayerKey] || 'none';
    if (prayerStatus === 'mosque') {
      return { isCompleted: true, statusBadge: 'في المسجد 🕌' };
    }
    if (prayerStatus === 'on_time') {
      return { isCompleted: true, statusBadge: 'في وقتها ✓' };
    }
    if (prayerStatus === 'late') {
      return { isCompleted: true, statusBadge: 'تم الأداء ✓' };
    }
    if (isManualChecked) {
      return { isCompleted: true, statusBadge: 'تم الأداء ✓' };
    }
    return { isCompleted: false };
  }

  if (src.type === 'ward') {
    const wardCheck = isWardCompletedOnDate(src.wardType, dateStr);
    if (wardCheck.done) {
      return { isCompleted: true, statusBadge: wardCheck.ratioText || 'مكتمل ✓' };
    }
    if (isManualChecked) {
      return { isCompleted: true, statusBadge: 'مكتمل ✓' };
    }
    return { isCompleted: false, statusBadge: wardCheck.ratioText || undefined };
  }

  if (src.type === 'tasbeeh') {
    const count = tasbeehHistory[dateStr]?.totalCount || 0;
    if (count >= src.targetCount) {
      return { isCompleted: true, statusBadge: `${count} تسبيحة ✓` };
    }
    if (isManualChecked) {
      return { isCompleted: true, statusBadge: 'مكتمل ✓' };
    }
    return {
      isCompleted: false,
      statusBadge: count > 0 ? `${count} / ${src.targetCount}` : undefined,
    };
  }

  if (src.type === 'fasting') {
    if (isFastingLoggedOnDate(dateStr) || isManualChecked) {
      return { isCompleted: true, statusBadge: 'صائم ✓' };
    }
    return { isCompleted: false };
  }

  if (src.type === 'quran_read') {
    if (wasQuranReadOnDate(dateStr) || isManualChecked) {
      return { isCompleted: true, statusBadge: 'تمت القراءة ✓' };
    }
    return { isCompleted: false };
  }

  return {
    isCompleted: isManualChecked,
    statusBadge: isManualChecked ? 'مكتمل ✓' : undefined,
  };
}

/**
 * Starts or resumes a journey and sets it as the active primary journey.
 */
export function startOrSelectJourney(journeyId: string): MyJourneyPersistedState {
  const state = loadMyJourneyState();
  const today = getTodayDateString();

  if (!state.enrollments[journeyId]) {
    state.enrollments[journeyId] = {
      journeyId,
      startedAtDate: today,
      lastActiveAt: new Date().toISOString(),
      completedTasksByDay: {},
    };
  } else {
    state.enrollments[journeyId].lastActiveAt = new Date().toISOString();
  }

  state.activeJourneyId = journeyId;
  saveMyJourneyState(state);
  return state;
}

/**
 * Resets a specific journey so the user can start it fresh from Day 1 today.
 */
export function resetJourneyEnrollment(journeyId: string): MyJourneyPersistedState {
  const state = loadMyJourneyState();
  const today = getTodayDateString();
  state.enrollments[journeyId] = {
    journeyId,
    startedAtDate: today,
    lastActiveAt: new Date().toISOString(),
    completedTasksByDay: {},
  };
  state.activeJourneyId = journeyId;
  saveMyJourneyState(state);
  return state;
}

/**
 * Toggles a task on a valid unlocked day (prevents completing future locked days).
 * Also syncs two-way with RIFQ's real prayer tracker & fasting tracker!
 */
export function toggleJourneyDayTask(
  journeyId: string,
  dayNumber: number,
  taskId: string
): { success: boolean; message?: string; state: MyJourneyPersistedState } {
  const state = loadMyJourneyState();
  const summary = computeJourneyProgress(journeyId, state);

  // Guard: Prevent completing future days that have not arrived yet
  if (dayNumber > summary.maxUnlockedDayNumber) {
    return {
      success: false,
      message: 'هذا اليوم قادم ومقفل حاليًا؛ لا يمكن تسجيل مهام أيام مستقبلية قبل حلول وقتها.',
      state,
    };
  }

  const today = getTodayDateString();
  if (!state.enrollments[journeyId]) {
    state.enrollments[journeyId] = {
      journeyId,
      startedAtDate: today,
      lastActiveAt: new Date().toISOString(),
      completedTasksByDay: {},
    };
    state.activeJourneyId = journeyId;
  }

  const enrollment = state.enrollments[journeyId];
  const dayStatus = summary.days.find((d) => d.dayNumber === dayNumber);
  const taskItem = dayStatus?.tasks.find((t) => t.id === taskId);

  if (!dayStatus || !taskItem) {
    return { success: false, state };
  }

  const currentManualList = [...(enrollment.completedTasksByDay[dayNumber] || [])];
  const nextCompletedState = !taskItem.isCompleted;

  if (nextCompletedState) {
    if (!currentManualList.includes(taskId)) {
      currentManualList.push(taskId);
    }
  } else {
    const idx = currentManualList.indexOf(taskId);
    if (idx >= 0) currentManualList.splice(idx, 1);
  }

  enrollment.completedTasksByDay[dayNumber] = currentManualList;
  enrollment.lastActiveAt = new Date().toISOString();

  // Two-way sync with real stores when task is a prayer or fasting task!
  const src = taskItem.autoSyncSource;
  if (src.type === 'prayer') {
    savePrayerTrackerStatus(
      dayStatus.dateStr,
      src.prayerKey,
      nextCompletedState ? 'on_time' : 'none'
    );
  } else if (src.type === 'fasting') {
    toggleFastingLogOnDate(dayStatus.dateStr, nextCompletedState);
  }

  saveMyJourneyState(state);
  return { success: true, state };
}

/**
 * Computes full, real-time progress for a given journey
 */
export function computeJourneyProgress(
  journeyId: string,
  providedState?: MyJourneyPersistedState
): ComputedJourneySummary {
  const state = providedState || loadMyJourneyState();
  const def = getJourneyDefinition(journeyId);
  const enrollment = state.enrollments[journeyId];
  const todayStr = getTodayDateString();

  const prayerHistory = loadPrayerTrackerHistory();
  const tasbeehHistory = loadHistory();

  const isEnrolled = Boolean(enrollment);
  const isActivePrimary = state.activeJourneyId === journeyId;
  const startedAtDate = enrollment?.startedAtDate || null;

  // Calculate how many real calendar days have elapsed since the user started the journey
  let maxUnlockedDayNumber = 1;
  if (startedAtDate) {
    const elapsed = Math.max(0, diffCalendarDays(startedAtDate, todayStr));
    maxUnlockedDayNumber = Math.min(def.durationDays, elapsed + 1);
  }

  const days: ComputedDayStatus[] = [];
  let completedDaysCount = 0;

  for (let d = 1; d <= def.durationDays; d++) {
    const blueprint = getJourneyDayBlueprint(journeyId, d);
    const dateStr = startedAtDate
      ? addDaysToDateStr(startedAtDate, d - 1)
      : addDaysToDateStr(todayStr, d - 1);

    const manualTasks = enrollment?.completedTasksByDay?.[d] || [];

    const computedTasks: ComputedTaskItem[] = blueprint.tasks.map((t) => {
      // If the user hasn't enrolled yet or the day is in the future (> maxUnlockedDayNumber), tasks are locked
      if (!isEnrolled || d > maxUnlockedDayNumber) {
        return {
          ...t,
          isCompleted: false,
        };
      }
      const evalResult = evaluateTaskCompletion(
        t,
        dateStr,
        manualTasks,
        prayerHistory,
        tasbeehHistory
      );
      return {
        ...t,
        isCompleted: evalResult.isCompleted,
        statusBadge: evalResult.statusBadge,
      };
    });

    const completedTasksCount = computedTasks.filter((t) => t.isCompleted).length;
    const totalTasksCount = computedTasks.length;
    const isDayFullyCompleted = totalTasksCount > 0 && completedTasksCount === totalTasksCount;

    if (isDayFullyCompleted) {
      completedDaysCount++;
    }

    let dayState: ComputedDayStatus['state'] = 'locked';
    if (!isEnrolled) {
      dayState = d === 1 ? 'current' : 'locked';
    } else if (d > maxUnlockedDayNumber) {
      dayState = 'locked';
    } else if (isDayFullyCompleted) {
      dayState = 'completed';
    } else if (d === maxUnlockedDayNumber) {
      dayState = 'current';
    } else if (completedTasksCount > 0) {
      dayState = 'partial';
    } else {
      dayState = 'missed';
    }

    days.push({
      dayNumber: d,
      dateStr,
      title: blueprint.title,
      stageNumber: blueprint.stageNumber,
      stageTitle: blueprint.stageTitle,
      reflectionQuote: blueprint.reflectionQuote,
      reflectionSource: blueprint.reflectionSource,
      state: dayState,
      completedTasksCount,
      totalTasksCount,
      tasks: computedTasks,
    });
  }

  const currentDayNumber = isEnrolled ? maxUnlockedDayNumber : 1;
  const remainingDaysCount = Math.max(0, def.durationDays - completedDaysCount);
  const progressPercent = Math.min(
    100,
    Math.round((completedDaysCount / def.durationDays) * 100)
  );

  // Calculate consecutive completed days streak in this journey
  let streakDays = 0;
  if (isEnrolled) {
    for (let d = maxUnlockedDayNumber; d >= 1; d--) {
      const dayObj = days[d - 1];
      if (dayObj.state === 'completed') {
        streakDays++;
      } else if (d === maxUnlockedDayNumber && dayObj.completedTasksCount > 0) {
        // Today is partially in progress, continue checking yesterday
        continue;
      } else if (d === maxUnlockedDayNumber) {
        continue;
      } else {
        break;
      }
    }
  }

  let status: JourneyStatusType = 'available';
  let statusLabelAr = '▶️ متاحة';
  let statusEmoji = '▶️';

  if (!isEnrolled) {
    status = 'not_started';
    statusLabelAr = '🔒 لم تبدأ';
    statusEmoji = '🔒';
  } else if (completedDaysCount >= def.durationDays) {
    status = 'completed';
    statusLabelAr = '🏆 مكتملة';
    statusEmoji = '🏆';
  } else {
    status = 'in_progress';
    statusLabelAr = '🌱 قيد التقدم';
    statusEmoji = '🌱';
  }

  const currentStage = getStageForDay(def, currentDayNumber);
  const todayDayStatus = days[currentDayNumber - 1] || days[0];

  // Next achievement for this journey
  const milestones = [
    { target: 1, id: 'ach_first_step' },
    { target: 3, id: 'ach_three_days' },
    { target: 7, id: 'ach_week_flame' },
    { target: 15, id: 'ach_half_month' },
    { target: def.durationDays, id: 'ach_full_journey' },
  ];
  const nextMilestone =
    milestones.find((m) => completedDaysCount < m.target) || milestones[milestones.length - 1];
  const achDef =
    JOURNEY_ACHIEVEMENTS.find((a) => a.id === nextMilestone.id) || JOURNEY_ACHIEVEMENTS[0];

  const nextAchievement: ComputedAchievement = {
    ...achDef,
    targetDays: nextMilestone.target,
    isUnlocked: completedDaysCount >= nextMilestone.target,
    currentProgress: completedDaysCount,
    progressPercent: Math.min(100, Math.round((completedDaysCount / nextMilestone.target) * 100)),
    remainingCount: Math.max(0, nextMilestone.target - completedDaysCount),
  };

  return {
    definition: def,
    status,
    statusLabelAr,
    statusEmoji,
    isEnrolled,
    isActivePrimary,
    startedAtDate,
    currentDayNumber,
    maxUnlockedDayNumber,
    completedDaysCount,
    remainingDaysCount,
    progressPercent,
    currentStage,
    streakDays,
    days,
    todayDayStatus,
    nextAchievement,
  };
}

/**
 * Computes all journeys in the catalog
 */
export function computeAllJourneys(
  providedState?: MyJourneyPersistedState
): ComputedJourneySummary[] {
  const state = providedState || loadMyJourneyState();
  return JOURNEY_CATALOG.map((j) => computeJourneyProgress(j.id, state));
}

/**
 * Joins a challenge or logs today's challenge completion
 */
export function joinOrToggleChallengeToday(challengeId: string): MyJourneyPersistedState {
  const state = loadMyJourneyState();
  const today = getTodayDateString();
  const def = CHALLENGE_CATALOG.find((c) => c.id === challengeId);
  if (!def) return state;

  if (!state.challenges[challengeId]) {
    state.challenges[challengeId] = {
      challengeId,
      startedAtDate: today,
      completedDays: [],
    };
    saveMyJourneyState(state);
    return state;
  }

  const ch = state.challenges[challengeId];
  const elapsed = Math.max(0, diffCalendarDays(ch.startedAtDate, today));
  const currentDayNum = Math.min(def.durationDays, elapsed + 1);

  if (ch.completedDays.includes(currentDayNum)) {
    ch.completedDays = ch.completedDays.filter((d) => d !== currentDayNum);
  } else {
    ch.completedDays = [...ch.completedDays, currentDayNum];
  }

  saveMyJourneyState(state);
  return state;
}

/**
 * Computes all challenges with real activity auto-detection
 */
export function computeAllChallenges(
  providedState?: MyJourneyPersistedState
): ComputedChallengeItem[] {
  const state = providedState || loadMyJourneyState();
  const today = getTodayDateString();
  const prayerHistory = loadPrayerTrackerHistory();
  const tasbeehHistory = loadHistory();

  return CHALLENGE_CATALOG.map((def) => {
    const ch = state.challenges[def.id];
    if (!ch) {
      return {
        ...def,
        isJoined: false,
        startedAtDate: null,
        completedDaysCount: 0,
        currentDayNumber: 1,
        progressPercent: 0,
        isCompletedToday: false,
        isCompletedAll: false,
      };
    }

    const elapsed = Math.max(0, diffCalendarDays(ch.startedAtDate, today));
    const currentDayNumber = Math.min(def.durationDays, elapsed + 1);

    // Check real activity for today
    let autoDoneToday = false;
    if (def.id === 'challenge_fajr_7') {
      const fajrStatus = prayerHistory[today]?.prayers?.fajr || 'none';
      autoDoneToday = fajrStatus === 'mosque' || fajrStatus === 'on_time' || fajrStatus === 'late';
    } else if (def.id === 'challenge_morning_evening_7') {
      autoDoneToday =
        isWardCompletedOnDate('morning', today).done &&
        isWardCompletedOnDate('evening', today).done;
    } else if (def.id === 'challenge_tasbeeh_7') {
      autoDoneToday = (tasbeehHistory[today]?.totalCount || 0) >= 100;
    }

    const completedSet = new Set<number>(ch.completedDays);
    if (autoDoneToday) {
      completedSet.add(currentDayNumber);
    }

    const completedDaysCount = completedSet.size;
    const isCompletedToday = completedSet.has(currentDayNumber);
    const progressPercent = Math.min(
      100,
      Math.round((completedDaysCount / def.durationDays) * 100)
    );

    return {
      ...def,
      isJoined: true,
      startedAtDate: ch.startedAtDate,
      completedDaysCount,
      currentDayNumber,
      progressPercent,
      isCompletedToday,
      isCompletedAll: completedDaysCount >= def.durationDays,
    };
  });
}

/**
 * Computes all achievements and returns unlocked + next achievement
 */
export function computeAllAchievements(
  providedState?: MyJourneyPersistedState
): {
  achievements: ComputedAchievement[];
  unlockedCount: number;
  lastUnlocked: ComputedAchievement | null;
  nextToUnlock: ComputedAchievement | null;
} {
  const state = providedState || loadMyJourneyState();
  const summaries = computeAllJourneys(state);
  const challenges = computeAllChallenges(state);

  const totalCompletedJourneyDays = summaries.reduce(
    (sum, s) => sum + s.completedDaysCount,
    0
  );
  const maxCompletedDaysInSingleJourney = summaries.reduce(
    (max, s) => Math.max(max, s.completedDaysCount),
    0
  );
  const anyFullJourneyCompleted = summaries.some((s) => s.status === 'completed');

  const prayerDays = summaries
    .filter((s) => s.definition.category === 'prayer')
    .reduce((sum, s) => sum + s.completedDaysCount, 0);
  const quranDays = summaries
    .filter((s) => s.definition.category === 'quran')
    .reduce((sum, s) => sum + s.completedDaysCount, 0);
  const athkarDays = summaries
    .filter((s) => s.definition.category === 'athkar')
    .reduce((sum, s) => sum + s.completedDaysCount, 0);
  const goodDeedsDays =
    summaries
      .filter((s) => s.definition.category === 'good_deeds')
      .reduce((sum, s) => sum + s.completedDaysCount, 0) +
    challenges.reduce((sum, c) => sum + c.completedDaysCount, 0);

  const achievements: ComputedAchievement[] = JOURNEY_ACHIEVEMENTS.map((ach) => {
    let currentProgress = 0;
    if (ach.id === 'ach_first_step' || ach.id === 'ach_three_days' || ach.id === 'ach_week_flame' || ach.id === 'ach_half_month') {
      currentProgress = Math.max(totalCompletedJourneyDays, maxCompletedDaysInSingleJourney);
    } else if (ach.id === 'ach_prayer_guardian') {
      currentProgress = prayerDays;
    } else if (ach.id === 'ach_quran_companion') {
      currentProgress = quranDays;
    } else if (ach.id === 'ach_athkar_shield') {
      currentProgress = athkarDays;
    } else if (ach.id === 'ach_good_deeds') {
      currentProgress = goodDeedsDays;
    } else if (ach.id === 'ach_full_journey') {
      currentProgress = anyFullJourneyCompleted
        ? ach.targetDays
        : maxCompletedDaysInSingleJourney;
    }

    const isUnlocked = currentProgress >= ach.targetDays;
    const progressPercent = Math.min(
      100,
      Math.round((currentProgress / ach.targetDays) * 100)
    );
    const remainingCount = Math.max(0, ach.targetDays - currentProgress);

    return {
      ...ach,
      isUnlocked,
      currentProgress,
      progressPercent,
      remainingCount,
    };
  });

  const unlockedList = achievements.filter((a) => a.isUnlocked);
  const lockedList = achievements.filter((a) => !a.isUnlocked);

  return {
    achievements,
    unlockedCount: unlockedList.length,
    lastUnlocked: unlockedList.length > 0 ? unlockedList[unlockedList.length - 1] : null,
    nextToUnlock: lockedList.length > 0 ? lockedList[0] : null,
  };
}
