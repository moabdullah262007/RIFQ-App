import { initializeApp, getApps, getApp } from 'firebase/app';
import { registerPlugin, Capacitor } from '@capacitor/core';
import {
  getAuth,
  initializeAuth,
  indexedDBLocalPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  browserPopupRedirectResolver,
  setPersistence,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCredential,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  fetchSignInMethodsForEmail,
  sendEmailVerification,
  sendPasswordResetEmail,
  updateProfile,
  updatePassword,
  updateEmail,
  deleteUser,
  signOut,
  onAuthStateChanged,
  User,
  UserCredential,
} from 'firebase/auth';
import {
  getFirestore,
  initializeFirestore,
  enableNetwork,
  setLogLevel,
  doc,
  getDoc,
  getDocFromServer,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  increment,
} from 'firebase/firestore';
import {
  getStorage,
  ref as storageRef,
  uploadBytesResumable,
  getDownloadURL,
  deleteObject,
} from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

// Suppress noisy internal Firestore offline/WebChannel retry warnings
try {
  setLogLevel('silent');
} catch {
  // Ignore if unsupported
}

// Initialize Firebase App using existing project configuration
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Auth with durable local persistence (IndexedDB + LocalStorage)
// so user sessions persist reliably across app closes/reopens on Web & Capacitor Android
function initFirebaseAuth() {
  try {
    return initializeAuth(app, {
      persistence: [
        indexedDBLocalPersistence,
        browserLocalPersistence,
        browserSessionPersistence,
      ],
      popupRedirectResolver: browserPopupRedirectResolver,
    });
  } catch {
    const existingAuth = getAuth(app);
    setPersistence(existingAuth, browserLocalPersistence).catch(() => {});
    return existingAuth;
  }
}

export const auth = initFirebaseAuth();
auth.languageCode = 'ar';

// Initialize Firestore with auto-detected long polling for reliable connectivity in iframes/proxies/WebViews
function initFirestoreDb() {
  try {
    return initializeFirestore(
      app,
      {
        experimentalAutoDetectLongPolling: true,
        ignoreUndefinedProperties: true,
      },
      firebaseConfig.firestoreDatabaseId
    );
  } catch {
    return getFirestore(app, firebaseConfig.firestoreDatabaseId);
  }
}

export const db = initFirestoreDb();

// Initialize Firebase Storage with fast retry bounds
export const storage = getStorage(app);
try {
  storage.maxUploadRetryTime = 3500;
  storage.maxOperationRetryTime = 3500;
} catch {
  // Ignore if unsupported
}
export { storageRef, uploadBytesResumable, getDownloadURL, deleteObject };

// Firestore error handling per system specifications
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Validate connection to Firestore on boot with automatic network activation & retry
export async function testFirestoreConnection(): Promise<boolean> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return false;
  }
  try {
    await enableNetwork(db).catch(() => {});
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch {
    try {
      await new Promise((resolve) => setTimeout(resolve, 1800));
      if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        return false;
      }
      await enableNetwork(db).catch(() => {});
      await getDocFromServer(doc(db, 'test', 'connection'));
      return true;
    } catch (retryError) {
      if (
        retryError instanceof Error &&
        retryError.message.includes('the client is offline') &&
        (typeof navigator === 'undefined' || navigator.onLine !== false)
      ) {
        // Fallback to cached/regular read without triggering fatal console.error when browser proxy blocks streaming
        await getDoc(doc(db, 'test', 'connection')).catch(() => {});
      }
      return false;
    }
  }
}
testFirestoreConnection();

// Google Auth Provider (Only Google & Email/Password are supported)
export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('email');
googleProvider.addScope('profile');
googleProvider.setCustomParameters({ prompt: 'select_account' });

export const GOOGLE_AUTH_IN_FLIGHT_KEY = 'rifq_google_auth_in_flight_ts';

interface NativeGoogleAuthResult {
  hasPending?: boolean;
  idToken?: string | null;
  accessToken?: string | null;
  email?: string | null;
  displayName?: string | null;
  photoUrl?: string | null;
}

interface RifqGoogleAuthBridge {
  signIn: (options?: { webClientId?: string }) => Promise<NativeGoogleAuthResult>;
  consumePendingAuthResult: () => Promise<NativeGoogleAuthResult>;
  signOut: () => Promise<void>;
}

// IMPORTANT: Capacitor 8 custom plugins must be resolved through registerPlugin().
 // Relying on the legacy window.Capacitor.Plugins object can return undefined even
 // when MainActivity correctly registers the native plugin, which would make Android
 // silently fall back to a WebView popup that cannot complete Google OAuth reliably.
const NativeRifqGoogleAuth = registerPlugin<RifqGoogleAuthBridge>('RifqGoogleAuth');

function getNativeGoogleAuthPlugin(): RifqGoogleAuthBridge | null {
  try {
    if (typeof window === 'undefined' || !Capacitor.isNativePlatform()) return null;
    if (Capacitor.getPlatform() !== 'android') return null;
    return NativeRifqGoogleAuth;
  } catch {
    return null;
  }
}

export function isNativeAndroidAuthAvailable(): boolean {
  return getNativeGoogleAuthPlugin() !== null;
}

export function markGoogleAuthInFlight(): void {
  try {
    localStorage.setItem(GOOGLE_AUTH_IN_FLIGHT_KEY, String(Date.now()));
  } catch {
    // ignore
  }
}

export function clearGoogleAuthInFlight(): void {
  try {
    localStorage.removeItem(GOOGLE_AUTH_IN_FLIGHT_KEY);
  } catch {
    // ignore
  }
}

export function isGoogleAuthRecentlyInFlight(): boolean {
  try {
    const raw = localStorage.getItem(GOOGLE_AUTH_IN_FLIGHT_KEY);
    if (!raw) return false;
    const ts = Number(raw);
    if (Number.isNaN(ts)) return false;
    return Date.now() - ts < 180_000;
  } catch {
    return false;
  }
}

async function exchangeNativeGoogleTokensWithFirebase(
  nativeRes: NativeGoogleAuthResult
): Promise<UserCredential> {
  const idToken = nativeRes.idToken || null;
  const accessToken = nativeRes.accessToken || null;
  if (!idToken && !accessToken) {
    throw new Error('USER_CANCELLED');
  }

  const credential = GoogleAuthProvider.credential(idToken, accessToken);
  const userCred = await signInWithCredential(auth, credential);

  const displayName = nativeRes.displayName || userCred.user.displayName || null;
  const photoURL = nativeRes.photoUrl || userCred.user.photoURL || null;

  if (displayName) {
    setSavedUserDisplayName(userCred.user.uid, displayName);
  }
  if (photoURL) {
    setSavedUserAvatar(userCred.user.uid, photoURL);
  }

  if (
    (displayName && !userCred.user.displayName) ||
    (photoURL && !userCred.user.photoURL && photoURL.length <= 1900)
  ) {
    try {
      await updateProfile(userCred.user, {
        ...(displayName ? { displayName } : {}),
        ...(photoURL && photoURL.length <= 1900 ? { photoURL } : {}),
      });
    } catch {
      // Non-blocking
    }
  }

  await ensureUserCloudDoc(userCred.user, {
    name: displayName || undefined,
    displayName: displayName || undefined,
    email: nativeRes.email || userCred.user.email || undefined,
    photoURL: photoURL || undefined,
    provider: 'google.com',
    providerId: 'google.com',
  });

  return userCred;
}

/**
 * Checks if Android recreated MainActivity while the native Google Account Picker was active,
 * and consumes any pending Google credential stored in native SharedPreferences so login never gets lost.
 */
export async function consumePendingNativeGoogleAuth(): Promise<UserCredential | null> {
  const nativePlugin = getNativeGoogleAuthPlugin();
  if (!nativePlugin) return null;

  try {
    const pending = await nativePlugin.consumePendingAuthResult();
    if (!pending || !pending.hasPending || (!pending.idToken && !pending.accessToken)) {
      return null;
    }
    clearGoogleAuthInFlight();
    return await exchangeNativeGoogleTokensWithFirebase(pending);
  } catch (e) {
    console.warn('Pending native Google auth check note:', e);
    return null;
  }
}

export async function signOutNativeGoogleAccount(): Promise<void> {
  clearGoogleAuthInFlight();
  const nativePlugin = getNativeGoogleAuthPlugin();
  if (!nativePlugin) return;
  try {
    await nativePlugin.signOut();
  } catch {
    // ignore
  }
}

// Helper to load Google Identity Services script dynamically for fallback OAuth token flow
let gisScriptPromise: Promise<void> | null = null;
function loadGoogleIdentityServicesScript(): Promise<void> {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('Window is not available'));
  }
  const win = window as unknown as { google?: { accounts?: { oauth2?: unknown } } };
  if (win.google?.accounts?.oauth2) {
    return Promise.resolve();
  }
  if (gisScriptPromise) return gisScriptPromise;

  gisScriptPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector('script[src="https://accounts.google.com/gsi/client"]');
    if (existing) {
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', () => reject(new Error('Failed to load Google OAuth script')));
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.defer = true;
    script.onload = () => resolve();
    script.onerror = () => {
      gisScriptPromise = null;
      reject(new Error('Failed to load Google OAuth script'));
    };
    document.head.appendChild(script);
  });

  return gisScriptPromise;
}

/**
 * Signs in with Google using real Firebase Authentication:
 * 1. On Capacitor Android APK: Uses native Android `RifqGoogleAuthPlugin` (Google Play Services + AccountManager)
 *    and exchanges the native token via Firebase `signInWithCredential` without opening any WebView page or restarting the app.
 * 2. On Web: Uses `signInWithPopup(auth, googleProvider)` with automatic fallback to Google Identity Services OAuth token client
 *    + `signInWithCredential`.
 */
export async function signInWithGoogleAccount(): Promise<UserCredential> {
  markGoogleAuthInFlight();

  // 1. Native Android Capacitor Flow (No WebView redirect, no app restart)
  const nativePlugin = getNativeGoogleAuthPlugin();
  if (nativePlugin) {
    try {
      const nativeRes = await nativePlugin.signIn({
        webClientId: firebaseConfig.oAuthClientId,
      });
      const cred = await exchangeNativeGoogleTokensWithFirebase(nativeRes);
      clearGoogleAuthInFlight();
      return cred;
    } catch (nativeErr) {
      clearGoogleAuthInFlight();
      throw nativeErr;
    }
  }

  // 2. Web Flow: signInWithPopup -> GIS Fallback -> signInWithCredential
  try {
    const res = await signInWithPopup(auth, googleProvider, browserPopupRedirectResolver);
    clearGoogleAuthInFlight();
    return res;
  } catch (primaryError: unknown) {
    const errObj = primaryError as { code?: string; message?: string };
    const errCode = (errObj?.code || '').toLowerCase();
    const errMsg = (errObj?.message || '').toLowerCase();

    const shouldTryGisFallback =
      errCode === 'auth/unauthorized-domain' ||
      errCode === 'auth/operation-not-supported-in-this-environment' ||
      errCode === 'auth/popup-blocked' ||
      errMsg.includes('unauthorized-domain') ||
      errMsg.includes('unauthorized domain');

    if (!shouldTryGisFallback || !firebaseConfig.oAuthClientId) {
      clearGoogleAuthInFlight();
      throw primaryError;
    }

    try {
      // Fallback: Real Google OAuth2 Token Client -> Firebase signInWithCredential
      await loadGoogleIdentityServicesScript();

      const accessToken = await new Promise<string>((resolve, reject) => {
        const win = window as unknown as {
          google?: {
            accounts?: {
              oauth2?: {
                initTokenClient: (config: {
                  client_id: string;
                  scope: string;
                  prompt?: string;
                  callback: (resp: { access_token?: string; error?: string }) => void;
                  error_callback?: (err: { type?: string; message?: string }) => void;
                }) => { requestAccessToken: () => void };
              };
            };
          };
        };

        const oauth2 = win.google?.accounts?.oauth2;
        if (!oauth2) {
          reject(primaryError);
          return;
        }

        const tokenClient = oauth2.initTokenClient({
          client_id: firebaseConfig.oAuthClientId,
          scope: 'openid email profile',
          prompt: 'select_account',
          callback: (response) => {
            if (response.error || !response.access_token) {
              reject(primaryError);
              return;
            }
            resolve(response.access_token);
          },
          error_callback: () => {
            reject(primaryError);
          },
        });

        tokenClient.requestAccessToken();
      });

      const credential = GoogleAuthProvider.credential(null, accessToken);
      const cred = await signInWithCredential(auth, credential);
      clearGoogleAuthInFlight();
      return cred;
    } catch (fallbackErr) {
      clearGoogleAuthInFlight();
      throw fallbackErr;
    }
  }
}

// Helper to inspect raw error code
export function extractAuthErrorCode(errorOrCode: unknown): string {
  if (!errorOrCode) return '';
  if (typeof errorOrCode === 'string') {
    if (errorOrCode.includes('USER_CANCELLED') || errorOrCode.includes('NO_ACCOUNT_SELECTED')) {
      return 'auth/popup-closed-by-user';
    }
    const match = errorOrCode.match(/(auth\/[a-z0-9-]+)/i);
    if (match) return match[1].toLowerCase();
    if (errorOrCode.includes('PASSWORD_LOGIN_DISABLED') || errorOrCode.includes('OPERATION_NOT_ALLOWED')) {
      return 'auth/operation-not-allowed';
    }
    if (errorOrCode.includes('EMAIL_EXISTS')) {
      return 'auth/email-already-in-use';
    }
    if (errorOrCode.includes('INVALID_LOGIN_CREDENTIALS') || errorOrCode.includes('INVALID_PASSWORD')) {
      return 'auth/invalid-credential';
    }
    if (errorOrCode.includes('USER_NOT_FOUND') || errorOrCode.includes('EMAIL_NOT_FOUND')) {
      return 'auth/user-not-found';
    }
    return errorOrCode.trim().toLowerCase();
  }
  if (typeof errorOrCode === 'object') {
    const err = errorOrCode as { code?: string; message?: string };
    const msg = err.message || '';
    if (msg.includes('USER_CANCELLED') || msg.includes('NO_ACCOUNT_SELECTED')) {
      return 'auth/popup-closed-by-user';
    }
    if (msg.includes('PASSWORD_LOGIN_DISABLED') || msg.includes('OPERATION_NOT_ALLOWED')) {
      return 'auth/operation-not-allowed';
    }
    if (msg.includes('EMAIL_EXISTS')) {
      return 'auth/email-already-in-use';
    }
    if (err.code && typeof err.code === 'string') {
      return err.code.trim().toLowerCase();
    }
    const match = msg.match(/(auth\/[a-z0-9-]+)/i);
    if (match) return match[1].toLowerCase();
  }
  return '';
}

// User-friendly Arabic Authentication Error Translation (No Firebase Console or technical jargon)
export function getAuthErrorMessage(errorOrCode: unknown): string {
  if (!errorOrCode) {
    return 'تعذر تسجيل الدخول، حاول مرة أخرى.';
  }

  if (
    typeof errorOrCode === 'string' &&
    /[\u0600-\u06FF]/.test(errorOrCode) &&
    !errorOrCode.toLowerCase().includes('firebase')
  ) {
    return errorOrCode;
  }

  let code = extractAuthErrorCode(errorOrCode);
  const rawMessage =
    typeof errorOrCode === 'string'
      ? errorOrCode
      : typeof errorOrCode === 'object' && errorOrCode !== null && 'message' in errorOrCode
      ? String((errorOrCode as { message?: unknown }).message || '')
      : '';

  if (!code && rawMessage) {
    const lower = rawMessage.toLowerCase();
    if (lower.includes('user_cancelled') || lower.includes('no_account_selected')) {
      code = 'auth/popup-closed-by-user';
    } else if (
      lower.includes('password_login_disabled') ||
      lower.includes('operation_not_allowed') ||
      lower.includes('operation-not-allowed')
    ) {
      code = 'auth/operation-not-allowed';
    } else if (
      lower.includes('network') ||
      lower.includes('failed to fetch') ||
      lower.includes('offline') ||
      lower.includes('timeout')
    ) {
      code = 'auth/network-request-failed';
    } else if (lower.includes('popup') && (lower.includes('closed') || lower.includes('cancelled'))) {
      code = 'auth/popup-closed-by-user';
    } else if (lower.includes('popup') && (lower.includes('blocked') || lower.includes('denied'))) {
      code = 'auth/popup-blocked';
    } else if (
      lower.includes('invalid-credential') ||
      lower.includes('invalid_login_credentials') ||
      lower.includes('wrong-password')
    ) {
      code = 'auth/invalid-credential';
    }
  }

  switch (code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
      return 'البريد الإلكتروني أو كلمة المرور غير صحيحة. يرجى التأكد من البيانات والمحاولة مرة أخرى.';
    case 'auth/user-not-found':
      return 'لا يوجد حساب مسجل بهذا البريد الإلكتروني. يمكنك إنشاء حساب جديد الآن.';
    case 'auth/invalid-email':
      return 'يرجى إدخال بريد إلكتروني صحيح.';
    case 'auth/missing-email':
      return 'يرجى إدخال البريد الإلكتروني للمتابعة.';
    case 'auth/missing-password':
      return 'يرجى إدخال كلمة المرور للمتابعة.';
    case 'auth/user-disabled':
      return 'تم إيقاف هذا الحساب من قِبل إدارة التطبيق.';
    case 'auth/email-already-in-use':
      return 'هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول أو استعادة كلمة المرور.';
    case 'auth/weak-password':
      return 'كلمة المرور قصيرة جدًا، يجب أن تتكون من 6 أحرف أو أرقام على الأقل.';
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return 'تم إلغاء عملية اختيار الحساب قبل اكتمال تسجيل الدخول.';
    case 'auth/popup-blocked':
      return 'تعذر فتح نافذة تسجيل الدخول، يرجى المحاولة مرة أخرى.';
    case 'auth/account-exists-with-different-credential':
      return 'هذا البريد الإلكتروني مرتبط بحساب Google، يرجى تسجيل الدخول باستخدام زر Google.';
    case 'auth/network-request-failed':
      return 'تعذر تسجيل الدخول، تحقق من اتصالك بالإنترنت وحاول مرة أخرى.';
    case 'auth/too-many-requests':
      return 'تم إيقاف المحاولات مؤقتًا لكثرة الطلبات، يرجى الانتظار قليلًا ثم المحاولة مرة أخرى.';
    case 'auth/requires-recent-login':
      return 'لأمان حسابك، يرجى تسجيل الخروج ثم إعادة تسجيل الدخول للمتابعة.';
    case 'auth/expired-action-code':
      return 'انتهت صلاحية الرابط، يرجى طلب رابط جديد.';
    case 'auth/invalid-action-code':
      return 'الرابط غير صالح أو تم استخدامه مسبقًا.';
    default:
      return 'تعذر تسجيل الدخول، حاول مرة أخرى.';
  }
}

// User Profile Document Interface (Real Firestore Data Only — Never stores passwords)
export interface UserCloudProfile {
  uid: string;
  name?: string | null;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  emailVerified?: boolean;
  provider?: string;
  providerId?: string;
  role?: 'user' | 'admin';
  accountStatus?: 'active' | 'suspended' | 'banned';
  statusReason?: string;
  statusUpdatedAt?: string;
  statusUpdatedBy?: string;
  city?: string;
  country?: string;
  bio?: string;
  createdAt?: string;
  lastLoginAt?: string;
  updatedAt?: string;
  lastActiveAt?: string;
  lastSyncedAt?: number;
  lastMutationId?: string;
  themeId?: string;
  themeMode?: 'light' | 'dark' | 'system';
  themeUpdatedAt?: string;
  stats?: {
    totalTasbeeh: number;
    currentStreak: number;
    longestStreak: number;
    completedAthkar: number;
    rank: string;
    quranCompleted: number;
    hadithsRead: number;
    customAthkarCount: number;
  };
  settings?: Record<string, unknown>;
  notificationSettings?: Record<string, unknown>;
  favorites?: string[];
  customAthkar?: unknown[];
  history?: Record<string, unknown>;
  wardProgress?: Record<string, Record<string, number>>;
  misbahaData?: {
    sessions?: unknown[];
    customAdhkar?: unknown[];
    dailyStats?: unknown[];
    settings?: Record<string, unknown>;
    streak?: Record<string, unknown>;
    rosaryState?: Record<string, unknown>;
    rosaryHistory?: unknown[];
  };
  athkarData?: {
    history?: Record<string, unknown>;
    customAthkar?: unknown[];
    favorites?: string[];
    wardProgress?: Record<string, Record<string, number>>;
    hisnFavAthkar?: string[];
    hisnFavChapters?: number[];
    hadithFavorites?: string[];
  };
}

const USER_AVATAR_STORAGE_PREFIX = 'rifq_user_avatar_';
const USER_NAME_STORAGE_PREFIX = 'rifq_user_display_name_';

export function getSavedUserAvatar(uid?: string | null): string | null {
  if (!uid) return null;
  try {
    return localStorage.getItem(`${USER_AVATAR_STORAGE_PREFIX}${uid}`) || null;
  } catch {
    return null;
  }
}

export function setSavedUserAvatar(uid: string, photoURL: string | null): void {
  if (!uid) return;
  try {
    if (photoURL) {
      localStorage.setItem(`${USER_AVATAR_STORAGE_PREFIX}${uid}`, photoURL);
    } else {
      localStorage.removeItem(`${USER_AVATAR_STORAGE_PREFIX}${uid}`);
    }
  } catch {
    // Ignore storage quota issues
  }
}

export function getSavedUserDisplayName(uid?: string | null): string | null {
  if (!uid) return null;
  try {
    return localStorage.getItem(`${USER_NAME_STORAGE_PREFIX}${uid}`) || null;
  } catch {
    return null;
  }
}

export function setSavedUserDisplayName(uid: string, displayName: string | null): void {
  if (!uid) return;
  try {
    if (displayName) {
      localStorage.setItem(`${USER_NAME_STORAGE_PREFIX}${uid}`, displayName);
    }
  } catch {
    // Ignore
  }
}

/**
 * Decodes and center-crops an uploaded image file to a lightweight 256x256 JPEG data URL
 * so profile pictures upload and sync to Firestore instantaneously without hitting size limits.
 */
export async function compressAvatarFileToDataUrl(
  file: File,
  maxDimension: number = 256,
  quality: number = 0.82
): Promise<string> {
  return new Promise((resolve, reject) => {
    let settled = false;
    const fail = (msg = 'تعذر قراءة الصورة، يرجى اختيار صورة صالحة (JPG أو PNG أو WebP).') => {
      if (settled) return;
      settled = true;
      reject(new Error(msg));
    };

    if (!file || file.size <= 0) {
      fail('الملف المختار فارغ أو غير صالح.');
      return;
    }

    if (file.size > 12 * 1024 * 1024) {
      fail('حجم الصورة كبير جداً (الحد الأقصى 12 ميجابايت).');
      return;
    }

    const timeoutId = setTimeout(() => fail(), 5000);

    const reader = new FileReader();
    reader.onerror = () => {
      clearTimeout(timeoutId);
      fail();
    };
    reader.onload = () => {
      const rawDataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!rawDataUrl || !rawDataUrl.startsWith('data:image/')) {
        clearTimeout(timeoutId);
        fail();
        return;
      }

      const img = new Image();
      img.onerror = () => {
        clearTimeout(timeoutId);
        if (rawDataUrl.length <= 250_000) {
          settled = true;
          resolve(rawDataUrl);
        } else {
          fail();
        }
      };
      img.onload = () => {
        clearTimeout(timeoutId);
        if (settled) return;
        try {
          const srcW = img.naturalWidth || img.width || maxDimension;
          const srcH = img.naturalHeight || img.height || maxDimension;

          const minSide = Math.min(srcW, srcH);
          const sx = Math.max(0, Math.floor((srcW - minSide) / 2));
          const sy = Math.max(0, Math.floor((srcH - minSide) / 2));
          const targetSize = Math.min(maxDimension, minSide || maxDimension);

          const canvas = document.createElement('canvas');
          canvas.width = targetSize;
          canvas.height = targetSize;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            settled = true;
            resolve(rawDataUrl);
            return;
          }

          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, targetSize, targetSize);
          ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, targetSize, targetSize);

          let compressed = canvas.toDataURL('image/jpeg', quality);
          if (compressed.length > 120_000) {
            compressed = canvas.toDataURL('image/jpeg', 0.68);
          }

          settled = true;
          resolve(compressed);
        } catch {
          if (rawDataUrl.length <= 250_000) {
            settled = true;
            resolve(rawDataUrl);
          } else {
            fail();
          }
        }
      };
      img.src = rawDataUrl;
    };

    try {
      reader.readAsDataURL(file);
    } catch {
      clearTimeout(timeoutId);
      fail();
    }
  });
}

/**
 * Safely updates the user's profile picture in LocalStorage, Firestore `users/{uid}`,
 * and Firebase Auth (only when URL is short enough for Firebase Auth's 2048-char limit).
 */
export async function updateUserAvatarEverywhere(
  user: User,
  newPhotoUrl: string
): Promise<void> {
  setSavedUserAvatar(user.uid, newPhotoUrl);

  if (newPhotoUrl.length <= 1900) {
    try {
      await updateProfile(user, { photoURL: newPhotoUrl });
    } catch {
      // Ignore Firebase Auth photoURL length/network errors; Firestore is the primary store
    }
  }

  const userRef = doc(db, 'users', user.uid);
  await setDoc(
    userRef,
    {
      uid: user.uid,
      email: user.email || null,
      displayName:
        getSavedUserDisplayName(user.uid) ||
        user.displayName ||
        (user.email ? user.email.split('@')[0] : 'مستخدم رِفْق'),
      photoURL: newPhotoUrl,
      updatedAt: new Date().toISOString(),
    },
    { merge: true }
  );
}

/**
 * Ensures a real Firestore user document exists at `users/{uid}` linked to the authenticated Firebase UID.
 * - Loads existing user data from Firestore if present.
 * - Creates a clean user document ONLY when needed, using real Firebase Auth fields (UID, displayName, email, photoURL).
 * - Never stores passwords or fake mock data.
 */
export async function ensureUserCloudDoc(
  user: User,
  extraData?: Partial<UserCloudProfile>
): Promise<UserCloudProfile> {
  const localSavedAvatar = getSavedUserAvatar(user.uid);
  const localSavedName = getSavedUserDisplayName(user.uid);
  const derivedName =
    extraData?.displayName ||
    extraData?.name ||
    user.displayName ||
    localSavedName ||
    (user.email ? user.email.split('@')[0] : 'مستخدم رِفْق');
  const derivedPhoto = extraData?.photoURL || localSavedAvatar || user.photoURL || null;
  const primaryProvider =
    extraData?.provider || extraData?.providerId || user.providerData?.[0]?.providerId || 'password';
  const nowIso = new Date().toISOString();

  const initialProfile: UserCloudProfile = {
    uid: user.uid,
    name: derivedName,
    email: user.email || extraData?.email || null,
    displayName: derivedName,
    photoURL: derivedPhoto,
    emailVerified: Boolean(user.emailVerified),
    provider: primaryProvider,
    providerId: primaryProvider,
    role: 'user',
    accountStatus: 'active',
    createdAt: user.metadata?.creationTime
      ? new Date(user.metadata.creationTime).toISOString()
      : nowIso,
    lastLoginAt: nowIso,
    updatedAt: nowIso,
    lastActiveAt: nowIso,
    lastSyncedAt: Date.now(),
    ...extraData,
  };

  try {
    const userRef = doc(db, 'users', user.uid);
    const snap = await getDoc(userRef);

    if (snap.exists()) {
      const existing = snap.data() as UserCloudProfile;
      const effectivePhoto =
        extraData?.photoURL || existing.photoURL || localSavedAvatar || user.photoURL || null;
      const effectiveName =
        extraData?.displayName ||
        extraData?.name ||
        existing.displayName ||
        existing.name ||
        user.displayName ||
        localSavedName ||
        derivedName;
      const effectiveEmail = user.email || existing.email || null;

      if (effectivePhoto) setSavedUserAvatar(user.uid, effectivePhoto);
      if (effectiveName) setSavedUserDisplayName(user.uid, effectiveName);

      // Only update user doc if account is active (suspended/banned users cannot self-update their doc)
      const isAccountRestricted =
        existing.accountStatus === 'suspended' || existing.accountStatus === 'banned';

      if (!isAccountRestricted) {
        const updatePayload: Partial<UserCloudProfile> = {
          ...(extraData || {}),
          uid: user.uid,
          name: effectiveName,
          email: effectiveEmail,
          displayName: effectiveName,
          photoURL: effectivePhoto,
          emailVerified: Boolean(user.emailVerified),
          provider: primaryProvider,
          providerId: primaryProvider,
          createdAt: existing.createdAt || initialProfile.createdAt,
          lastLoginAt: nowIso,
          updatedAt: nowIso,
          lastActiveAt: nowIso,
        };
        await setDoc(userRef, updatePayload, { merge: true });
        return {
          ...existing,
          ...updatePayload,
        };
      }

      return {
        ...existing,
        uid: user.uid,
        name: effectiveName,
        email: effectiveEmail,
        displayName: effectiveName,
        photoURL: effectivePhoto,
        emailVerified: Boolean(user.emailVerified),
      };
    }

    // Document does not exist yet: create real user document in Firestore for this UID
    if (derivedPhoto) setSavedUserAvatar(user.uid, derivedPhoto);
    if (derivedName) setSavedUserDisplayName(user.uid, derivedName);

    await setDoc(userRef, initialProfile, { merge: true });

    // Atomically increment global user counter in /system_stats/global
    try {
      await setDoc(
        doc(db, 'system_stats', 'global'),
        {
          totalUsersCount: increment(1),
          updatedAt: nowIso,
        },
        { merge: true }
      );
    } catch {
      // Non-blocking if offline
    }

    return initialProfile;
  } catch (err) {
    console.warn('Network issue during ensureUserCloudDoc, using authenticated profile:', err);
    return initialProfile;
  }
}

export {
  firebaseConfig,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  fetchSignInMethodsForEmail,
  sendEmailVerification,
  sendPasswordResetEmail,
  updateProfile,
  updatePassword,
  updateEmail,
  deleteUser,
  signOut,
  onAuthStateChanged,
  signInWithPopup,
  signInWithCredential,
  serverTimestamp,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
};
export type { User, UserCredential };
