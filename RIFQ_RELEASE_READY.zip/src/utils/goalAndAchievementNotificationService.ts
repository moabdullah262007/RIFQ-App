import { addNotification } from './storage';
import {
  triggerPushNotification,
  isNotificationChannelEnabled,
  RIFQ_NOTIFICATION_CHANNELS,
  hasNotificationFired,
  markNotificationFired,
} from './notifications';
import { soundManager } from './audio';
import confetti from 'canvas-confetti';

const GOAL_NOTIFICATION_PREFS_KEY = 'rifq_goal_notif_prefs_v1';

export interface GoalNotificationPreferences {
  notifyOnTasbeehGoal: boolean;
  notifyOnPrayerGoal: boolean;
  notifyOnWirdGoal: boolean;
  notifyOnAchievements: boolean;
  soundEnabled: boolean;
}

export const DEFAULT_GOAL_NOTIFICATION_PREFS: GoalNotificationPreferences = {
  notifyOnTasbeehGoal: true,
  notifyOnPrayerGoal: true,
  notifyOnWirdGoal: true,
  notifyOnAchievements: true,
  soundEnabled: true,
};

export function loadGoalNotificationPreferences(): GoalNotificationPreferences {
  try {
    const raw = localStorage.getItem(GOAL_NOTIFICATION_PREFS_KEY);
    if (raw) {
      return { ...DEFAULT_GOAL_NOTIFICATION_PREFS, ...JSON.parse(raw) };
    }
  } catch {
    // fallback
  }
  return DEFAULT_GOAL_NOTIFICATION_PREFS;
}

export function saveGoalNotificationPreferences(prefs: GoalNotificationPreferences): void {
  try {
    localStorage.setItem(GOAL_NOTIFICATION_PREFS_KEY, JSON.stringify(prefs));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('rifq-goal-notif-prefs-updated', { detail: prefs })
      );
    }
  } catch {
    // ignore
  }
}

function getTodayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
    d.getDate()
  ).padStart(2, '0')}`;
}

/**
 * Triggers a celebration confetti burst and sound
 */
function triggerCelebrationEffects(): void {
  try {
    if (typeof window !== 'undefined') {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#5B5FEF', '#4CAF82', '#E8B84A', '#F2994A'],
      });
      soundManager.playCompletionChime();
    }
  } catch {
    // ignore
  }
}

/**
 * Sends a notification when user completes their daily tasbeeh goal (e.g. 100/500/1000)
 */
export async function notifyDailyTasbeehGoalCompleted(
  currentCount: number,
  goalTarget: number
): Promise<boolean> {
  const prefs = loadGoalNotificationPreferences();
  if (!prefs.notifyOnTasbeehGoal) return false;

  const today = getTodayStr();
  const signatureKey = `goal_tasbeeh_${today}_${goalTarget}`;
  if (hasNotificationFired(signatureKey)) return false;

  markNotificationFired(signatureKey);

  const title = '🎉 مبارك! أتممت هدف التسبيح اليومي';
  const body = `ما شاء الله، حققت هدفك اليومي بـ ${currentCount} تسبيحة (الهدف: ${goalTarget})! كتب الله أجرك ونفع بك.`;

  // 1. Record in-app notification center
  addNotification({
    title,
    message: body,
    time: 'الآن',
    read: false,
    type: 'goal',
    actionScreen: 'harvest',
    signatureKey,
  });

  // 2. Celebration effects
  if (prefs.soundEnabled) {
    triggerCelebrationEffects();
  }

  // 3. Web Push / System Notification
  if (isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.reminders)) {
    await triggerPushNotification({
      title,
      message: body,
      screen: 'harvest',
      channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
      tag: `goal-tasbeeh-${today}`,
      signatureKey,
    });
  }

  return true;
}

/**
 * Sends a notification when user completes all 5 daily prayers on time or in mosque
 */
export async function notifyAllPrayersGoalCompleted(): Promise<boolean> {
  const prefs = loadGoalNotificationPreferences();
  if (!prefs.notifyOnPrayerGoal) return false;

  const today = getTodayStr();
  const signatureKey = `goal_prayers_all5_${today}`;
  if (hasNotificationFired(signatureKey)) return false;

  markNotificationFired(signatureKey);

  const title = '🕌 هنيئاً لك! أتممت صلوات اليوم الخمس كلها';
  const body = 'ما شاء الله تبارك الله، أتممت صلوات الفجر والظهر والعصر والمغرب والعشاء! جعلها الله نوراً وبرهاناً لك يوم القيامة.';

  addNotification({
    title,
    message: body,
    time: 'الآن',
    read: false,
    type: 'goal',
    actionScreen: 'prayers',
    signatureKey,
  });

  if (prefs.soundEnabled) {
    triggerCelebrationEffects();
  }

  if (isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.prayer)) {
    await triggerPushNotification({
      title,
      message: body,
      screen: 'prayers',
      channelId: RIFQ_NOTIFICATION_CHANNELS.prayer,
      tag: `goal-prayers-${today}`,
      signatureKey,
    });
  }

  return true;
}

/**
 * Sends a notification when a daily wird or athkar set is completed
 */
export async function notifyWirdGoalCompleted(
  wardName: string,
  wardType?: string
): Promise<boolean> {
  const prefs = loadGoalNotificationPreferences();
  if (!prefs.notifyOnWirdGoal) return false;

  const today = getTodayStr();
  const signatureKey = `goal_wird_${wardType || wardName}_${today}`;
  if (hasNotificationFired(signatureKey)) return false;

  markNotificationFired(signatureKey);

  const title = `📿 تقبل الله! تم إتمام ${wardName}`;
  const body = `أحسنت صنعاً بإتمام ${wardName} كاملاً اليوم. حصنك الله وأثابك خيراً.`;

  addNotification({
    title,
    message: body,
    time: 'الآن',
    read: false,
    type: 'goal',
    actionScreen: 'ward',
    actionWard: (wardType === 'morning' || wardType === 'evening' || wardType === 'sleep') ? wardType : undefined,
    signatureKey,
  });

  if (prefs.soundEnabled) {
    triggerCelebrationEffects();
  }

  if (isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.azkar)) {
    await triggerPushNotification({
      title,
      message: body,
      screen: 'ward',
      ward: (wardType === 'morning' || wardType === 'evening' || wardType === 'sleep') ? wardType : undefined,
      channelId: RIFQ_NOTIFICATION_CHANNELS.azkar,
      tag: `goal-wird-${wardType || 'general'}-${today}`,
      signatureKey,
    });
  }

  return true;
}

/**
 * Sends a notification when a new badge or achievement is unlocked
 */
export async function notifyNewAchievementUnlocked(achievement: {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  description: string;
}): Promise<boolean> {
  const prefs = loadGoalNotificationPreferences();
  if (!prefs.notifyOnAchievements) return false;

  const signatureKey = `achievement_unlocked_${achievement.id}`;
  if (hasNotificationFired(signatureKey)) return false;

  markNotificationFired(signatureKey);

  const title = `🏅 وسام جديد: ${achievement.title} ${achievement.icon}`;
  const body = `مبارك! حققت إنجازاً جديداً: «${achievement.subtitle}» • ${achievement.description}`;

  addNotification({
    title,
    message: body,
    time: 'الآن',
    read: false,
    type: 'achievement',
    actionScreen: 'harvest',
    signatureKey,
  });

  if (prefs.soundEnabled) {
    triggerCelebrationEffects();
  }

  if (isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.updates)) {
    await triggerPushNotification({
      title,
      message: body,
      screen: 'harvest',
      channelId: RIFQ_NOTIFICATION_CHANNELS.updates,
      tag: `achievement-${achievement.id}`,
      signatureKey,
    });
  }

  return true;
}

/**
 * Test button trigger for Goal Completion Notification
 */
export async function sendTestGoalNotification(): Promise<boolean> {
  triggerCelebrationEffects();
  const title = '🎉 تجربة إشعار الهدف: إتمام 100 تسبيحة';
  const body = 'ما شاء الله! هذا نموذج حقيقي لإشعار إنجاز الهدف اليومي في مسبحة رفيق المسلم.';

  addNotification({
    title,
    message: body,
    time: 'الآن',
    read: false,
    type: 'goal',
    actionScreen: 'harvest',
  });

  return await triggerPushNotification({
    title,
    message: body,
    screen: 'harvest',
    channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
    tag: `test-goal-${Date.now()}`,
  });
}

/**
 * Test button trigger for Achievement Unlocked Notification
 */
export async function sendTestAchievementNotification(): Promise<boolean> {
  triggerCelebrationEffects();
  const title = '🏅 تجربة إشعار الوسام: وسام المواظب السبعي';
  const body = 'مبارك! هذا نموذج حقيقي لإشعار الحصول على وسام جديد وإنجاز مبارك في تطبيق رِفْق.';

  addNotification({
    title,
    message: body,
    time: 'الآن',
    read: false,
    type: 'achievement',
    actionScreen: 'harvest',
  });

  return await triggerPushNotification({
    title,
    message: body,
    screen: 'harvest',
    channelId: RIFQ_NOTIFICATION_CHANNELS.updates,
    tag: `test-achievement-${Date.now()}`,
  });
}
