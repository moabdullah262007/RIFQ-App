// Text-to-Speech Engine for Authentic Hadith Recitation in Arabic

class HadithSpeechService {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isPausedState = false;
  private isSpeakingState = false;
  private selectedRate = 1.0;
  private onStateChangeCallback: ((speaking: boolean, paused: boolean) => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
        // Voices loaded
      };
    }
  }

  public isSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  public subscribe(callback: (speaking: boolean, paused: boolean) => void) {
    this.onStateChangeCallback = callback;
  }

  private notify() {
    if (this.onStateChangeCallback) {
      this.onStateChangeCallback(this.isSpeakingState, this.isPausedState);
    }
  }

  public setRate(rate: number) {
    this.selectedRate = Math.max(0.6, Math.min(1.5, rate));
    if (this.isSpeakingState && this.currentUtterance) {
      // Some browsers allow dynamic rate change by restarting
    }
  }

  public getRate(): number {
    return this.selectedRate;
  }

  public speak(
    text: string, 
    rate?: number,
    onStart?: () => void,
    onEnd?: () => void,
    onError?: (err: unknown) => void
  ) {
    if (!this.isSupported()) {
      if (onError) onError(new Error('التعرف الصوتي والقراءة غير مدعومة في هذا المتصفح'));
      return;
    }

    // Cancel any ongoing speech first
    this.stop();

    try {
      const cleanText = text
        .replace(/ﷺ/g, 'صلى الله عليه وسلم')
        .replace(/ﷻ/g, 'جل جلاله')
        .replace(/رضي الله عنه/g, 'رضي الله عنه')
        .replace(/رضي الله عنها/g, 'رضي الله عنها')
        .replace(/رضي الله عنهم/g, 'رضي الله عنهم');

      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = 'ar-SA';
      utterance.rate = rate ?? this.selectedRate;
      utterance.pitch = 1.0;

      // Try finding an Arabic voice
      const voices = window.speechSynthesis.getVoices();
      const arabicVoice = voices.find(v => v.lang.startsWith('ar') || v.name.toLowerCase().includes('arabic'));
      if (arabicVoice) {
        utterance.voice = arabicVoice;
      }

      utterance.onstart = () => {
        this.isSpeakingState = true;
        this.isPausedState = false;
        this.notify();
        if (onStart) onStart();
      };

      utterance.onend = () => {
        this.isSpeakingState = false;
        this.isPausedState = false;
        this.currentUtterance = null;
        this.notify();
        if (onEnd) onEnd();
      };

      utterance.onerror = (e) => {
        this.isSpeakingState = false;
        this.isPausedState = false;
        this.currentUtterance = null;
        this.notify();
        if (onError) onError(e);
      };

      this.currentUtterance = utterance;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      this.isSpeakingState = false;
      this.isPausedState = false;
      this.notify();
      if (onError) onError(e);
    }
  }

  public pause() {
    if (!this.isSupported()) return;
    if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      window.speechSynthesis.pause();
      this.isPausedState = true;
      this.notify();
    }
  }

  public resume() {
    if (!this.isSupported()) return;
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      this.isPausedState = false;
      this.notify();
    }
  }

  public stop() {
    if (!this.isSupported()) return;
    window.speechSynthesis.cancel();
    this.isSpeakingState = false;
    this.isPausedState = false;
    this.currentUtterance = null;
    this.notify();
  }

  public isSpeaking(): boolean {
    return this.isSpeakingState;
  }

  public isPaused(): boolean {
    return this.isPausedState;
  }
}

export const hadithSpeech = new HadithSpeechService();
