import { CameraVerificationNativeBridge } from './cameraVerificationNativeBridge';
import { MihrabVerificationService } from './mihrabVerificationService';

export const MIHRAB_CONFIDENCE_THRESHOLD = 0.85;

export interface MihrabDetectionResult {
  success: boolean;
  isMosqueMihrab: boolean;
  confidence: number;
  passedThreshold: boolean;
  sessionId: string;
  reasonAr: string;
  detectedFeatures: string[];
  prohibitedElementsDetected: string[];
  timestamp: number;
  error?: string;
}

export class MihrabDetectionProcessor {
  /**
   * Processes a live captured image through the secure backend proxy (/api/verify-mihrab)
   * which invokes Gemini Vision API.
   *
   * Enforces:
   * 1. SESSION_ID validity (unexpired, unconsumed).
   * 2. MIHRAB_CONFIDENCE_THRESHOLD >= 0.85.
   * 3. Prohibited elements check (screens, home carpets alone, rooms, lamps, plain walls).
   */
  public static async processVerification(
    imageBase64: string,
    sessionId: string,
    prayerKey: string,
    prayerNameAr: string
  ): Promise<MihrabDetectionResult> {
    const timestamp = Date.now();

    // 1. Enforce SESSION_ID validation
    const sessionValidation = CameraVerificationNativeBridge.validateSession(
      sessionId,
      prayerKey
    );

    if (!sessionValidation.isValid) {
      return {
        success: false,
        isMosqueMihrab: false,
        confidence: 0,
        passedThreshold: false,
        sessionId,
        reasonAr: sessionValidation.reasonAr || 'جلسة التحقق غير صالحة.',
        detectedFeatures: [],
        prohibitedElementsDetected: ['جلسة منتهية الصلاحية أو مكررة'],
        timestamp,
        error: sessionValidation.reasonAr,
      };
    }

    try {
      // 2. Call backend proxy endpoint
      const response = await fetch('/api/verify-mihrab', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imageBase64,
          mimeType: 'image/jpeg',
          prayerKey,
          prayerNameAr,
          sessionId,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        return {
          success: false,
          isMosqueMihrab: false,
          confidence: 0,
          passedThreshold: false,
          sessionId,
          reasonAr:
            errorData?.reasonAr ||
            'تعذر الاتصال بمحرك التحقق البصري عبر الخادم. يرجى المحاولة مرة أخرى.',
          detectedFeatures: [],
          prohibitedElementsDetected: [],
          timestamp,
          error: errorData?.error || `HTTP ${response.status}`,
        };
      }

      const data = await response.json();
      const rawConfidence = typeof data.confidence === 'number' ? data.confidence : 0;
      const prohibitedElements: string[] = Array.isArray(data.prohibitedElementsDetected)
        ? data.prohibitedElementsDetected
        : [];

      // 3. Strict Threshold & Prohibited Elements Enforcement
      const hasProhibitedElements = prohibitedElements.length > 0;
      const passedThreshold =
        Boolean(data.isMosqueMihrab) &&
        rawConfidence >= MIHRAB_CONFIDENCE_THRESHOLD &&
        !hasProhibitedElements;

      const isMosqueMihrab = passedThreshold;

      let reasonAr = data.reasonAr;
      if (hasProhibitedElements) {
        reasonAr = `تم رفض الصورة لوجود عناصر محظورة أو غير مطابقة: ${prohibitedElements.join(
          '، '
        )}. ${data.reasonAr || ''}`.trim();
      } else if (Boolean(data.isMosqueMihrab) && rawConfidence < MIHRAB_CONFIDENCE_THRESHOLD) {
        reasonAr = `نسبة التأكد (${Math.round(
          rawConfidence * 100
        )}%) أقل من الحد الأدنى المعتمد (${Math.round(
          MIHRAB_CONFIDENCE_THRESHOLD * 100
        )}%). يرجى تصوير المحراب بزاوية أقرب وأكثر وضوحاً.`;
      }

      const result: MihrabDetectionResult = {
        success: true,
        isMosqueMihrab,
        confidence: rawConfidence,
        passedThreshold,
        sessionId,
        reasonAr,
        detectedFeatures: Array.isArray(data.detectedFeatures) ? data.detectedFeatures : [],
        prohibitedElementsDetected: prohibitedElements,
        timestamp,
      };

      // 4. If verification succeeded, consume the SESSION_ID and notify the service
      if (isMosqueMihrab) {
        CameraVerificationNativeBridge.consumeSession(sessionId);
        MihrabVerificationService.markVerificationSuccess({
          reasonAr: result.reasonAr,
          confidence: result.confidence,
          detectedFeatures: result.detectedFeatures,
          sessionId,
        });
      }

      return result;
    } catch (err: any) {
      return {
        success: false,
        isMosqueMihrab: false,
        confidence: 0,
        passedThreshold: false,
        sessionId,
        reasonAr: 'حدث خطأ غير متوقع أثناء معالجة التحقق البصري.',
        detectedFeatures: [],
        prohibitedElementsDetected: [],
        timestamp,
        error: err?.message,
      };
    }
  }
}
