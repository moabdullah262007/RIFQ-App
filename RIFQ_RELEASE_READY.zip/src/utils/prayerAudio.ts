import { MuadhinOption, MUADHIN_OPTIONS } from '../data/prayersData';
import { getPlayableAudioUrl } from './adhanCacheManager';

export interface AdhanPlayerState {
  isPlaying: boolean;
  isPaused: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  muadhinName: string;
  muadhinCity: string;
  prayerName?: string;
  soundMode: 'adhan' | 'takbeer' | 'chime' | 'off';
  hasError: boolean;
  errorMessage?: string;
}

let currentAudio: HTMLAudioElement | null = null;
let takbeerTimeout: ReturnType<typeof setTimeout> | null = null;
let savedVolume = 0.9;
let isAudioMuted = false;

let playerState: AdhanPlayerState = {
  isPlaying: false,
  isPaused: false,
  currentTime: 0,
  duration: 0,
  volume: savedVolume,
  isMuted: false,
  muadhinName: '',
  muadhinCity: '',
  prayerName: '',
  soundMode: 'adhan',
  hasError: false
};

type PlayerStateListener = (state: AdhanPlayerState) => void;
const playerListeners = new Set<PlayerStateListener>();

export function subscribeToAdhanPlayer(listener: PlayerStateListener) {
  playerListeners.add(listener);
  // Emit current state immediately
  listener({ ...playerState });
  return () => {
    playerListeners.delete(listener);
  };
}

// Backward compatibility listener
type AudioStateListener = (isPlaying: boolean, muadhinName?: string) => void;
const legacyListeners = new Set<AudioStateListener>();

export function subscribeToAdhanState(listener: AudioStateListener) {
  legacyListeners.add(listener);
  listener(playerState.isPlaying, playerState.muadhinName);
  return () => {
    legacyListeners.delete(listener);
  };
}

function notifyListeners() {
  const cloned = { ...playerState };
  playerListeners.forEach((fn) => {
    try {
      fn(cloned);
    } catch (e) {
      console.error(e);
    }
  });
  legacyListeners.forEach((fn) => {
    try {
      fn(cloned.isPlaying, cloned.muadhinName);
    } catch (e) {
      console.error(e);
    }
  });
}

// Built-in melodic chime using Web Audio API (for soft pre-reminders or sunrise)
export function playIslamicChime() {
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const notes = [293.66, 329.63, 392.0, 440.0, 523.25]; // Maqam Rast / Peaceful chime

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.22);

      gain.gain.setValueAtTime(0, ctx.currentTime + idx * 0.22);
      gain.gain.linearRampToValueAtTime(0.25, ctx.currentTime + idx * 0.22 + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.22 + 0.8);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime + idx * 0.22);
      osc.stop(ctx.currentTime + idx * 0.22 + 0.85);
    });
  } catch (err) {
    console.warn('Web Audio chime warning:', err);
  }
}

/**
 * Configure Media Session API for mobile lock screen & background controls
 */
function updateMediaSession(muadhinName: string, prayerName?: string) {
  if (typeof window === 'undefined' || !('mediaSession' in navigator)) return;

  try {
    const title = prayerName ? `أذان صلاة ${prayerName}` : 'أذان الصلاة';
    navigator.mediaSession.metadata = new MediaMetadata({
      title,
      artist: muadhinName || 'مؤذن الصلاة',
      album: 'مسبحة رفيق المسلم',
      artwork: [
        { src: '/icon.png', sizes: '96x96', type: 'image/png' },
        { src: '/icon.png', sizes: '192x192', type: 'image/png' },
        { src: '/icon.png', sizes: '512x512', type: 'image/png' }
      ]
    });

    navigator.mediaSession.setActionHandler('play', () => {
      resumeAdhanAudio();
    });
    navigator.mediaSession.setActionHandler('pause', () => {
      pauseAdhanAudio();
    });
    navigator.mediaSession.setActionHandler('stop', () => {
      stopAdhanAudio();
    });
    navigator.mediaSession.setActionHandler('seekto', (details) => {
      if (details.seekTime !== undefined) {
        seekAdhanAudio(details.seekTime);
      }
    });
  } catch (e) {
    console.debug('MediaSession error:', e);
  }
}

/**
 * Play authentic Adhan MP3 from direct URL or MuadhinOption
 */
export async function playAdhanAudio(
  urlOrMuadhin: string | MuadhinOption,
  onEnded?: () => void,
  onError?: (err?: unknown) => void,
  label?: string,
  mode: 'adhan' | 'takbeer' = 'adhan',
  prayerName?: string
): Promise<HTMLAudioElement | null> {
  stopAdhanAudio();

  let targetMuadhin: MuadhinOption | undefined;
  let targetUrl = '';

  if (typeof urlOrMuadhin === 'string') {
    targetUrl = urlOrMuadhin;
    targetMuadhin = MUADHIN_OPTIONS.find(
      (m) => m.audioUrl === urlOrMuadhin || m.backupAudioUrl === urlOrMuadhin
    );
  } else {
    targetMuadhin = urlOrMuadhin;
    targetUrl = targetMuadhin.audioUrl;
  }

  // Check offline cache first if we have a targetMuadhin
  if (targetMuadhin) {
    try {
      targetUrl = await getPlayableAudioUrl(targetMuadhin);
    } catch {
      // Fallback to direct URL
    }
  }

  const muadhinLabel = targetMuadhin?.nameAr || label || 'أذان الصلاة';
  const muadhinCity = targetMuadhin?.cityAr || '';

  try {
    const audio = new Audio();
    audio.preload = 'auto';
    audio.crossOrigin = 'anonymous';
    currentAudio = audio;
    audio.volume = isAudioMuted ? 0 : savedVolume;

    playerState = {
      isPlaying: true,
      isPaused: false,
      currentTime: 0,
      duration: targetMuadhin?.approxDurationSec || 200,
      volume: savedVolume,
      isMuted: isAudioMuted,
      muadhinName: muadhinLabel,
      muadhinCity,
      prayerName: prayerName || '',
      soundMode: mode,
      hasError: false
    };
    notifyListeners();
    updateMediaSession(muadhinLabel, prayerName);

    // Audio event bindings
    audio.ontimeupdate = () => {
      if (!currentAudio) return;
      playerState.currentTime = currentAudio.currentTime;
      if (currentAudio.duration && !isNaN(currentAudio.duration)) {
        playerState.duration = currentAudio.duration;
      }
      notifyListeners();
    };

    audio.onloadedmetadata = () => {
      if (!currentAudio) return;
      if (currentAudio.duration && !isNaN(currentAudio.duration)) {
        playerState.duration = currentAudio.duration;
        notifyListeners();
      }
    };

    audio.onended = () => {
      stopAdhanAudio();
      if (onEnded) onEnded();
    };

    // Error handling with backup URL fallback
    audio.onerror = async () => {
      console.warn('Audio playback error on URL:', targetUrl);
      if (targetMuadhin?.backupAudioUrl && targetUrl !== targetMuadhin.backupAudioUrl) {
        console.log('Retrying with backup Adhan URL:', targetMuadhin.backupAudioUrl);
        try {
          audio.src = targetMuadhin.backupAudioUrl;
          await audio.play();
          return;
        } catch (backupErr) {
          console.error('Backup Adhan playback failed:', backupErr);
        }
      }

      playerState.hasError = true;
      playerState.errorMessage = 'تعذر تشغيل ملف الأذان الصوتي، يرجى التحقق من الاتصال.';
      notifyListeners();
      stopAdhanAudio();
      if (onError) onError();
    };

    audio.src = targetUrl;
    await audio.play();

    // If Takbeer Only mode, stop after ~26 seconds (first Takbeerat "الله أكبر الله أكبر")
    if (mode === 'takbeer') {
      takbeerTimeout = setTimeout(() => {
        stopAdhanAudio();
        if (onEnded) onEnded();
      }, 26000);
    }

    return audio;
  } catch (err) {
    console.warn('Audio play() call failed (possibly autoplay policy):', err);
    playerState.hasError = true;
    playerState.errorMessage = 'يرجى النقر على الشاشة للسماح بتشغيل الصوت.';
    notifyListeners();
    stopAdhanAudio();
    if (onError) onError(err);
    return null;
  }
}

/**
 * Pause active Adhan playback
 */
export function pauseAdhanAudio() {
  if (currentAudio && !currentAudio.paused) {
    currentAudio.pause();
    playerState.isPlaying = false;
    playerState.isPaused = true;
    notifyListeners();
  }
}

/**
 * Resume paused Adhan playback
 */
export async function resumeAdhanAudio() {
  if (currentAudio && currentAudio.paused) {
    try {
      await currentAudio.play();
      playerState.isPlaying = true;
      playerState.isPaused = false;
      notifyListeners();
    } catch (e) {
      console.warn('Could not resume audio:', e);
    }
  }
}

/**
 * Start Adhan playback (or resume if paused) directly from notification controls
 */
export async function startOrResumeAdhanAudio(prayerName?: string) {
  if (currentAudio && playerState.isPaused) {
    await resumeAdhanAudio();
    return;
  }

  let selectedMuadhinId = 'abdulbaset';
  try {
    const saved = localStorage.getItem('rafiq_prayer_settings');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && parsed.selectedMuadhin) {
        selectedMuadhinId = parsed.selectedMuadhin;
      }
    }
  } catch {
    // fallback to default
  }

  const targetMuadhin =
    MUADHIN_OPTIONS.find((m) => m.id === selectedMuadhinId) || MUADHIN_OPTIONS[0];

  await playAdhanAudio(
    targetMuadhin,
    undefined,
    undefined,
    undefined,
    'adhan',
    prayerName || playerState.prayerName || ''
  );
}

/**
 * Seek to specific time in seconds
 */
export function seekAdhanAudio(timeInSeconds: number) {
  if (currentAudio) {
    currentAudio.currentTime = Math.max(0, Math.min(timeInSeconds, currentAudio.duration || 300));
    playerState.currentTime = currentAudio.currentTime;
    notifyListeners();
  }
}

/**
 * Stop Adhan playback completely
 */
export function stopAdhanAudio() {
  if (takbeerTimeout) {
    clearTimeout(takbeerTimeout);
    takbeerTimeout = null;
  }
  if (currentAudio) {
    try {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio.src = '';
    } catch (e) {
      console.warn(e);
    }
    currentAudio = null;
  }

  playerState = {
    ...playerState,
    isPlaying: false,
    isPaused: false,
    currentTime: 0,
    hasError: false,
    errorMessage: undefined
  };
  notifyListeners();
}

/**
 * Set Adhan volume (0.0 to 1.0)
 */
export function setAdhanVolume(vol: number) {
  savedVolume = Math.max(0, Math.min(1, vol));
  isAudioMuted = savedVolume === 0;
  if (currentAudio) {
    currentAudio.volume = isAudioMuted ? 0 : savedVolume;
  }
  playerState.volume = savedVolume;
  playerState.isMuted = isAudioMuted;
  notifyListeners();
}

export function getAdhanVolume(): number {
  return savedVolume;
}

/**
 * Toggle mute state
 */
export function toggleAdhanMute(): boolean {
  isAudioMuted = !isAudioMuted;
  if (currentAudio) {
    currentAudio.volume = isAudioMuted ? 0 : savedVolume;
  }
  playerState.isMuted = isAudioMuted;
  notifyListeners();
  return isAudioMuted;
}

export function isAdhanPlaying(): boolean {
  return playerState.isPlaying;
}

export function getAdhanPlayerState(): AdhanPlayerState {
  return { ...playerState };
}

/**
 * Play prayer alert by mode ('adhan' | 'takbeer' | 'chime' | 'silent' | 'off')
 */
export function playPrayerSound(
  mode: 'adhan' | 'takbeer' | 'chime' | 'silent' | 'off',
  audioUrlOrMuadhin?: string | MuadhinOption,
  label?: string,
  onEnded?: () => void,
  onError?: () => void,
  prayerName?: string
) {
  if (mode === 'off' || mode === 'silent') {
    return;
  }

  if (mode === 'chime') {
    playIslamicChime();
    if (onEnded) setTimeout(onEnded, 1200);
    return;
  }

  const muadhinTarget = audioUrlOrMuadhin || MUADHIN_OPTIONS[0];

  if (mode === 'takbeer') {
    playAdhanAudio(muadhinTarget, onEnded, onError, label, 'takbeer', prayerName);
    return;
  }

  if (mode === 'adhan') {
    playAdhanAudio(muadhinTarget, onEnded, onError, label, 'adhan', prayerName);
  }
}

// Mobile haptic vibration trigger
export function triggerHaptic(pattern: number | number[] = 50) {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignored if unsupported
    }
  }
}
