import { CityLocation, PrayerKey, PrayerSettings, PrayerAlertDetail } from '../types';
import { DEFAULT_PRAYER_SETTINGS } from '../data/citiesData';
import { MUADHIN_OPTIONS } from '../data/prayersData';
import { calculateAllPrayerData } from './prayerCalculator';
import {
  triggerPrayerAdhanNotification,
  isNotificationChannelEnabled,
  RIFQ_NOTIFICATION_CHANNELS,
  hasNotificationFired,
  markNotificationFired,
  subscribeToNotificationSettings,
  syncFullNotificationScheduleWithServiceWorker,
  ScheduledSwNotificationItem,
} from './notifications';
import { addNotification } from './storage';
import {
  checkPrayerFocusLifecycle,
  syncPrayerFocusWithNativeBridge,
  FocusPrayerKey,
} from './prayerFocusService';
import { MihrabVerificationService } from './mihrabVerificationService';
import { syncWidgetStateWithNative } from './widgetService';

let schedulerInterval: ReturnType<typeof setInterval> | null = null;
let unsubscribeSettingsListener: (() => void) | null = null;
let activePrayerCallback:
  | ((info: { prayerKey: PrayerKey; prayerNameAr: string; cityName: string; timeStr: string }) => void)
  | null = null;

const PRAYER_NAMES_AR: Record<PrayerKey, string> = {
  fajr: 'الفجر',
  sunrise: 'الشروق',
  dhuhr: 'الظهر',
  asr: 'العصر',
  maghrib: 'المغرب',
  isha: 'العشاء',
};

export function getCurrentCity(): CityLocation {
  try {
    const saved = localStorage.getItem('rafiq_current_city');
    if (saved) return JSON.parse(saved);
  } catch {
    // fallback
  }
  return {
    id: 'eg-cairo',
    nameAr: 'القاهرة',
    nameEn: 'Cairo',
    countryAr: 'مصر',
    countryEn: 'Egypt',
    governorateAr: 'محافظة القاهرة',
    latitude: 30.0444,
    longitude: 31.2357,
    timezone: 'Africa/Cairo',
    defaultMethod: 'Egyptian',
    regionCategory: 'egypt',
  };
}

export function getPrayerSettings(): PrayerSettings {
  try {
    const saved = localStorage.getItem('rafiq_prayer_settings');
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...DEFAULT_PRAYER_SETTINGS,
        ...parsed,
        notifications: {
          ...DEFAULT_PRAYER_SETTINGS.notifications,
          ...(parsed.notifications || {}),
        },
        prayerAlerts: {
          ...DEFAULT_PRAYER_SETTINGS.prayerAlerts,
          ...(parsed.prayerAlerts || {}),
        },
      };
    }
  } catch {
    // fallback
  }
  return DEFAULT_PRAYER_SETTINGS;
}

export function savePrayerSettings(settings: PrayerSettings): void {
  try {
    localStorage.setItem('rafiq_prayer_settings', JSON.stringify(settings));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('rafiq-prayer-settings-updated', { detail: settings })
      );
    }
    // Reschedule prayer notifications with updated settings
    checkAndTriggerPrayerAdhanNow().catch(() => {});
  } catch {
    // ignore
  }
}

/**
 * Syncs today's calculated prayer times with the active Service Worker
 * so the background worker can also monitor and display browser Notifications.
 */
export function syncPrayerScheduleWithServiceWorker(
  cityName: string,
  todayKey: string,
  times: Record<PrayerKey, Date>,
  settings: PrayerSettings
): void {
  const adhanChannelEnabled = isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.adhan);
  const prayersList: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const alreadyFiredKeys: string[] = [];
  const nativePrayerScheduleItems: ScheduledSwNotificationItem[] = [];

  const prayersPayload = prayersList.map((pkey) => {
    const pDate = times[pkey];
    const timeFormatted = pDate
      ? `${pDate.getHours().toString().padStart(2, '0')}:${pDate.getMinutes().toString().padStart(2, '0')}`
      : '';
    const mainSig = `${todayKey}_${pkey}`;
    const preSig = `${todayKey}_pre_${pkey}`;

    if (localStorage.getItem(`rafiq_adhan_fired_${todayKey}_${pkey}`) || hasNotificationFired(mainSig)) {
      alreadyFiredKeys.push(mainSig);
    }
    if (localStorage.getItem(`rafiq_pre_adhan_fired_${todayKey}_${pkey}`) || hasNotificationFired(preSig)) {
      alreadyFiredKeys.push(preSig);
    }

    const alertDetail: PrayerAlertDetail = settings.prayerAlerts?.[pkey] || {
      mode: pkey === 'sunrise' ? 'chime' : 'adhan',
      preReminder: pkey !== 'sunrise',
    };
    const isEnabled =
      adhanChannelEnabled &&
      settings.notifications[pkey] !== false &&
      alertDetail.mode !== 'off';

    const prayerNameAr = PRAYER_NAMES_AR[pkey];

    if (isEnabled && pDate && pDate.getTime() > 0) {
      nativePrayerScheduleItems.push({
        id: `prayer_main_${pkey}`,
        signatureKey: mainSig,
        channelId: RIFQ_NOTIFICATION_CHANNELS.prayer,
        title: `حان الآن وقت صلاة ${prayerNameAr} 🕌`,
        body: `دخل الآن وقت صلاة ${prayerNameAr} (${timeFormatted}) بتوقيت ${cityName} • حي على الصلاة، حي على الفلاح`,
        timestamp: pDate.getTime(),
        timeHHMM: timeFormatted,
        repeatDaily: true,
        enabled: true,
        tag: `prayer-${prayerNameAr}-${todayKey}-main`,
        screen: 'prayers',
        prayerKey: pkey,
        prayerNameAr,
        cityName,
        timeFormatted,
        isPrayerAdhan: true,
      });

      const preMins = settings.preAdhanReminderMinutes || 15;
      if (alertDetail.preReminder && pkey !== 'sunrise' && preMins > 0) {
        const preTimeMs = pDate.getTime() - preMins * 60 * 1000;
        const preDate = new Date(preTimeMs);
        const preHHMM = `${preDate.getHours().toString().padStart(2, '0')}:${preDate
          .getMinutes()
          .toString()
          .padStart(2, '0')}`;
        nativePrayerScheduleItems.push({
          id: `prayer_pre_${pkey}`,
          signatureKey: preSig,
          channelId: RIFQ_NOTIFICATION_CHANNELS.prayer,
          title: `اقترب موعد صلاة ${prayerNameAr} ⏳`,
          body: `تبقى دقائق يسيرة على أذان ${prayerNameAr} (${timeFormatted}) بتوقيت ${cityName}. استعد بالوضوء والصلاة.`,
          timestamp: preTimeMs,
          timeHHMM: preHHMM,
          repeatDaily: true,
          enabled: true,
          tag: `prayer-${prayerNameAr}-${todayKey}-pre`,
          screen: 'prayers',
          prayerKey: pkey,
          prayerNameAr,
          cityName,
          timeFormatted,
          isPrayerAdhan: false,
        });
      }
    }

    return {
      key: pkey,
      nameAr: prayerNameAr,
      timestamp: pDate ? pDate.getTime() : 0,
      timeFormatted,
      enabled: isEnabled,
      preReminder: Boolean(alertDetail.preReminder && pkey !== 'sunrise'),
      preReminderMinutes: settings.preAdhanReminderMinutes || 15,
    };
  });

  // Sync prayer items into Android Native AlarmManager & Service Worker schedule
  syncFullNotificationScheduleWithServiceWorker(nativePrayerScheduleItems);
  syncWidgetStateWithNative().catch(() => {});

  if (typeof navigator === 'undefined' || !('serviceWorker' in navigator)) return;

  navigator.serviceWorker.ready
    .then((reg) => {
      if (reg.active) {
        reg.active.postMessage({
          type: 'SYNC_PRAYER_SCHEDULE',
          cityName,
          adhanChannelEnabled,
          prayers: prayersPayload,
          alreadyFiredKeys,
        });
      }
    })
    .catch(() => {});
}

/**
 * Checks all prayer times against current time and triggers Adhan audio + notifications
 */
export async function checkAndTriggerPrayerAdhanNow(): Promise<void> {
  const now = new Date();
  const city = getCurrentCity();
  const settings = getPrayerSettings();
  const adhanChannelEnabled = isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.adhan);

  const prayerData = calculateAllPrayerData(city.latitude, city.longitude, now, settings);
  const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')}`;

  const prayersList: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

  // Always keep Service Worker schedule & Native Prayer Focus Mode synchronized with current prayer times & channel state
  syncPrayerScheduleWithServiceWorker(city.nameAr, todayKey, prayerData.times, settings);
  syncPrayerFocusWithNativeBridge();
  await checkPrayerFocusLifecycle(now);
  await MihrabVerificationService.evaluateLifecycle();

  // If the master Adhan notification channel is disabled, do not fire automatic prayer alerts
  if (!adhanChannelEnabled) {
    return;
  }

  for (const pkey of prayersList) {
    const isNotificationEnabled = settings.notifications[pkey] !== false;
    if (!isNotificationEnabled) continue;

    const alertDetail: PrayerAlertDetail = settings.prayerAlerts?.[pkey] || {
      mode: pkey === 'sunrise' ? 'chime' : 'adhan',
      preReminder: pkey !== 'sunrise',
    };

    if (alertDetail.mode === 'off') continue;

    const pDate = prayerData.times[pkey];
    if (!pDate) continue;

    // 1. Check main Prayer Adhan window (from exact prayer time up to 15 minutes after, so background tab throttling never misses it)
    const diffMs = now.getTime() - pDate.getTime();
    const isInAdhanWindow = diffMs >= 0 && diffMs <= 15 * 60 * 1000;

    const storageKey = `rafiq_adhan_fired_${todayKey}_${pkey}`;
    const mainSig = `${todayKey}_${pkey}`;
    const alreadyFired = Boolean(localStorage.getItem(storageKey)) || hasNotificationFired(mainSig);

    if (isInAdhanWindow && !alreadyFired) {
      localStorage.setItem(storageKey, 'true');
      markNotificationFired(mainSig);

      const targetMuadhinId =
        alertDetail.customMuadhinId || settings.selectedMuadhin || 'abdulbaset';
      const targetMuadhin =
        MUADHIN_OPTIONS.find((m) => m.id === targetMuadhinId) || MUADHIN_OPTIONS[0];

      const timeFormatted = `${pDate.getHours().toString().padStart(2, '0')}:${pDate
        .getMinutes()
        .toString()
        .padStart(2, '0')}`;
      const prayerNameAr = PRAYER_NAMES_AR[pkey];

      await triggerPrayerAdhanNotification({
        prayerNameAr,
        cityName: city.nameAr,
        timeFormatted,
        mode: alertDetail.mode,
        audioUrl: targetMuadhin?.audioUrl,
        muadhinName: targetMuadhin?.nameAr,
        isPreReminder: false,
        signatureKey: mainSig,
      });

      addNotification({
        title: `حان الآن وقت صلاة ${prayerNameAr} 🕌`,
        message: `دخل وقت صلاة ${prayerNameAr} (${timeFormatted}) بتوقيت ${city.nameAr}.`,
        time: 'الآن',
        read: false,
        type: 'reminder',
        actionScreen: 'prayers',
        signatureKey: mainSig,
      });

      if (pkey !== 'sunrise') {
        MihrabVerificationService.startSession(
          pkey as FocusPrayerKey,
          prayerNameAr,
          pDate.getTime()
        );
      }

      if (activePrayerCallback) {
        activePrayerCallback({
          prayerKey: pkey,
          prayerNameAr,
          cityName: city.nameAr,
          timeStr: timeFormatted,
        });
      }
    }

    // 2. Check Pre-Adhan ("الصلاة القادمة") reminder (e.g. 15 minutes before prayer)
    if (alertDetail.preReminder && settings.preAdhanReminderMinutes > 0 && pkey !== 'sunrise') {
      const preReminderMs = settings.preAdhanReminderMinutes * 60 * 1000;
      const preTimestamp = pDate.getTime() - preReminderMs;
      const preDiffMs = now.getTime() - preTimestamp;
      // Fire if we are past the pre-reminder mark and still at least 1 minute before actual prayer time
      const isPreWindow =
        preDiffMs >= 0 &&
        preDiffMs <= 10 * 60 * 1000 &&
        now.getTime() < pDate.getTime() - 60 * 1000;

      const preStorageKey = `rafiq_pre_adhan_fired_${todayKey}_${pkey}`;
      const preSig = `${todayKey}_pre_${pkey}`;
      const preAlreadyFired =
        Boolean(localStorage.getItem(preStorageKey)) || hasNotificationFired(preSig);

      if (isPreWindow && !preAlreadyFired) {
        localStorage.setItem(preStorageKey, 'true');
        markNotificationFired(preSig);

        const timeFormatted = `${pDate.getHours().toString().padStart(2, '0')}:${pDate
          .getMinutes()
          .toString()
          .padStart(2, '0')}`;
        const prayerNameAr = PRAYER_NAMES_AR[pkey];

        await triggerPrayerAdhanNotification({
          prayerNameAr,
          cityName: city.nameAr,
          timeFormatted,
          mode: 'chime',
          isPreReminder: true,
          signatureKey: preSig,
        });

        addNotification({
          title: `اقترب وقت صلاة ${prayerNameAr} 🕌`,
          message: `تبقى دقائق يسيرة على أذان ${prayerNameAr} (${timeFormatted}) بتوقيت ${city.nameAr}.`,
          time: 'الآن',
          read: false,
          type: 'reminder',
          actionScreen: 'prayers',
          signatureKey: preSig,
        });
      }
    }
  }
}

/**
 * Starts the global continuous background Adhan runner
 */
export function startPrayerScheduler(
  onTriggered?: (info: {
    prayerKey: PrayerKey;
    prayerNameAr: string;
    cityName: string;
    timeStr: string;
  }) => void
): void {
  if (onTriggered) {
    activePrayerCallback = onTriggered;
  }

  // Check immediately upon launch
  checkAndTriggerPrayerAdhanNow();

  if (schedulerInterval) {
    clearInterval(schedulerInterval);
  }

  // Check every 10 seconds for accurate Adhan timing
  schedulerInterval = setInterval(() => {
    checkAndTriggerPrayerAdhanNow();
  }, 10000);

  if (unsubscribeSettingsListener) {
    unsubscribeSettingsListener();
  }
  unsubscribeSettingsListener = subscribeToNotificationSettings(() => {
    checkAndTriggerPrayerAdhanNow();
  });
}

/**
 * Stops the scheduler
 */
export function stopPrayerScheduler(): void {
  if (schedulerInterval) {
    clearInterval(schedulerInterval);
    schedulerInterval = null;
  }
  if (unsubscribeSettingsListener) {
    unsubscribeSettingsListener();
    unsubscribeSettingsListener = null;
  }
}

/**
 * Immediate test trigger for Adhan audio and notifications
 */
export async function triggerTestAdhan(
  prayerKey: PrayerKey = 'maghrib'
): Promise<{ success: boolean; message: string }> {
  try {
    const city = getCurrentCity();
    const settings = getPrayerSettings();
    const prayerNameAr = PRAYER_NAMES_AR[prayerKey];
    const now = new Date();
    const timeFormatted = `${now.getHours().toString().padStart(2, '0')}:${now
      .getMinutes()
      .toString()
      .padStart(2, '0')}`;

    const targetMuadhinId = settings.selectedMuadhin || 'abdulbaset';
    const targetMuadhin =
      MUADHIN_OPTIONS.find((m) => m.id === targetMuadhinId) || MUADHIN_OPTIONS[0];

    // Trigger audio + notification (bypassChannelCheck = true for explicit test button)
    await triggerPrayerAdhanNotification({
      prayerNameAr,
      cityName: city.nameAr,
      timeFormatted,
      mode: 'adhan',
      audioUrl: targetMuadhin?.audioUrl,
      muadhinName: targetMuadhin?.nameAr,
      isPreReminder: false,
      bypassChannelCheck: true,
    });

    if (activePrayerCallback) {
      activePrayerCallback({
        prayerKey,
        prayerNameAr,
        cityName: city.nameAr,
        timeStr: timeFormatted,
      });
    }

    return {
      success: true,
      message: `تم تشغيل تجربة أذان ${prayerNameAr} بصوت ${targetMuadhin?.nameAr || 'المؤذن'}.`,
    };
  } catch {
    return {
      success: false,
      message: 'تعذر تشغيل الأذان التجريبي.',
    };
  }
}
