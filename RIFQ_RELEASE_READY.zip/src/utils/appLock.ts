// Biometric & Local Screen Lock Utility

const LOCK_SETTINGS_KEY = 'mushaba_app_lock_v1';

export interface AppLockSettings {
  isEnabled: boolean;
  type: 'biometric' | 'pin';
  pinCode?: string; // Encrypted or hashed simple PIN
  lastUnlockedAt?: number;
}

export function getAppLockSettings(): AppLockSettings {
  try {
    const raw = localStorage.getItem(LOCK_SETTINGS_KEY);
    return raw ? JSON.parse(raw) : { isEnabled: false, type: 'biometric' };
  } catch {
    return { isEnabled: false, type: 'biometric' };
  }
}

export function saveAppLockSettings(settings: AppLockSettings): void {
  try {
    localStorage.setItem(LOCK_SETTINGS_KEY, JSON.stringify(settings));
  } catch {}
}

export async function isBiometricAvailable(): Promise<boolean> {
  if (typeof window === 'undefined') return false;
  if (!window.PublicKeyCredential) return false;
  try {
    if (PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable) {
      return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    }
    return true;
  } catch {
    return false;
  }
}

/**
 * Prompt biometric authentication via WebAuthn
 */
export async function promptBiometricAuth(): Promise<boolean> {
  if (!window.PublicKeyCredential) return false;
  try {
    const challenge = new Uint8Array(32);
    window.crypto.getRandomValues(challenge);

    // Create a temporary assertion
    const credential = await navigator.credentials.get({
      publicKey: {
        challenge,
        timeout: 60000,
        userVerification: 'required',
        rpId: window.location.hostname
      }
    });

    return !!credential;
  } catch (e: unknown) {
    const err = e as Error;
    // If not registered yet or failed, allow PIN or fallback
    console.warn('Biometric prompt feedback:', err.message);
    return false;
  }
}
