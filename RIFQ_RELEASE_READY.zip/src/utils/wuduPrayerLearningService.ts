import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db } from './firebase';

export type FivePrayerId = 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';

export interface WuduLearningProgressState {
  completedStepNumbers: number[];
  isCompleted: boolean;
  lastStepNumber: number | null;
  completedAt: string | null;
}

export interface SinglePrayerLearningProgress {
  prayerId: FivePrayerId;
  completedStepIds: string[];
  totalSteps: number;
  isCompleted: boolean;
  lastStepIndex: number | null;
  completedAt: string | null;
}

export interface QuizResultRecord {
  id: string;
  quizType: 'wudu_order' | 'prayer_order' | 'next_step' | 'general_review';
  title: string;
  score: number;
  total: number;
  completedAt: string;
}

export interface PrayerWuduLearningData {
  uid?: string;
  wuduProgress: WuduLearningProgressState;
  prayerProgress: Record<FivePrayerId, SinglePrayerLearningProgress>;
  completedLessons: string[];
  completedSteps: string[];
  lastLesson: string | null;
  lastLessonId: string | null;
  lastStep: string | null;
  quizResults: QuizResultRecord[];
  lastOpenedAt: string | null;
}

const LOCAL_CACHE_PREFIX = 'rifq_prayer_wudu_learning_v2_';
const IDB_NAME = 'rifq_prayer_wudu_learning_idb_v1';
const IDB_STORE = 'progress_store';

export function createEmptyPrayerWuduLearningData(uid?: string): PrayerWuduLearningData {
  return {
    uid: uid || undefined,
    wuduProgress: {
      completedStepNumbers: [],
      isCompleted: false,
      lastStepNumber: null,
      completedAt: null,
    },
    prayerProgress: {
      fajr: {
        prayerId: 'fajr',
        completedStepIds: [],
        totalSteps: 16,
        isCompleted: false,
        lastStepIndex: null,
        completedAt: null,
      },
      dhuhr: {
        prayerId: 'dhuhr',
        completedStepIds: [],
        totalSteps: 31,
        isCompleted: false,
        lastStepIndex: null,
        completedAt: null,
      },
      asr: {
        prayerId: 'asr',
        completedStepIds: [],
        totalSteps: 31,
        isCompleted: false,
        lastStepIndex: null,
        completedAt: null,
      },
      maghrib: {
        prayerId: 'maghrib',
        completedStepIds: [],
        totalSteps: 24,
        isCompleted: false,
        lastStepIndex: null,
        completedAt: null,
      },
      isha: {
        prayerId: 'isha',
        completedStepIds: [],
        totalSteps: 31,
        isCompleted: false,
        lastStepIndex: null,
        completedAt: null,
      },
    },
    completedLessons: [],
    completedSteps: [],
    lastLesson: null,
    lastLessonId: null,
    lastStep: null,
    quizResults: [],
    lastOpenedAt: null,
  };
}

export function hasAnyLearningActivity(data: PrayerWuduLearningData): boolean {
  if (!data) return false;
  if (data.completedSteps.length > 0) return true;
  if (data.completedLessons.length > 0) return true;
  if (data.quizResults.length > 0) return true;
  if (data.wuduProgress.completedStepNumbers.length > 0) return true;
  if (data.lastLesson !== null || data.lastStep !== null) return true;
  for (const p of Object.values(data.prayerProgress || {})) {
    if (p && p.completedStepIds && p.completedStepIds.length > 0) return true;
  }
  return false;
}

function getCacheKey(uid?: string | null): string {
  return `${LOCAL_CACHE_PREFIX}${uid || 'guest'}`;
}

function normalizeProgressData(
  raw: Partial<PrayerWuduLearningData> | null | undefined,
  uid?: string
): PrayerWuduLearningData {
  const base = createEmptyPrayerWuduLearningData(uid);
  if (!raw || typeof raw !== 'object') return base;

  const wuduRaw = raw.wuduProgress || base.wuduProgress;
  const completedStepNumbers = Array.isArray(wuduRaw.completedStepNumbers)
    ? Array.from(new Set(wuduRaw.completedStepNumbers.map(Number).filter((n) => n >= 1 && n <= 9))).sort(
        (a, b) => a - b
      )
    : [];

  const prayerIds: FivePrayerId[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const prayerProgress = { ...base.prayerProgress };

  for (const pid of prayerIds) {
    const pRaw = raw.prayerProgress?.[pid];
    if (pRaw && typeof pRaw === 'object') {
      prayerProgress[pid] = {
        prayerId: pid,
        completedStepIds: Array.isArray(pRaw.completedStepIds)
          ? Array.from(new Set(pRaw.completedStepIds.map(String)))
          : [],
        totalSteps: typeof pRaw.totalSteps === 'number' && pRaw.totalSteps > 0
          ? pRaw.totalSteps
          : base.prayerProgress[pid].totalSteps,
        isCompleted: Boolean(pRaw.isCompleted),
        lastStepIndex: typeof pRaw.lastStepIndex === 'number' ? pRaw.lastStepIndex : null,
        completedAt: typeof pRaw.completedAt === 'string' ? pRaw.completedAt : null,
      };
    }
  }

  return {
    uid: uid || raw.uid,
    wuduProgress: {
      completedStepNumbers,
      isCompleted: Boolean(wuduRaw.isCompleted) || completedStepNumbers.length >= 9,
      lastStepNumber: typeof wuduRaw.lastStepNumber === 'number' ? wuduRaw.lastStepNumber : null,
      completedAt: typeof wuduRaw.completedAt === 'string' ? wuduRaw.completedAt : null,
    },
    prayerProgress,
    completedLessons: Array.isArray(raw.completedLessons)
      ? Array.from(new Set(raw.completedLessons.map(String)))
      : [],
    completedSteps: Array.isArray(raw.completedSteps)
      ? Array.from(new Set(raw.completedSteps.map(String)))
      : [],
    lastLesson: typeof raw.lastLesson === 'string' ? raw.lastLesson : null,
    lastLessonId: typeof raw.lastLessonId === 'string' ? raw.lastLessonId : null,
    lastStep: typeof raw.lastStep === 'string' ? raw.lastStep : null,
    quizResults: Array.isArray(raw.quizResults) ? raw.quizResults.slice(0, 50) : [],
    lastOpenedAt: typeof raw.lastOpenedAt === 'string' ? raw.lastOpenedAt : null,
  };
}

function saveToIndexedDb(key: string, data: PrayerWuduLearningData): void {
  if (typeof window === 'undefined' || !('indexedDB' in window)) return;
  try {
    const req = window.indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const idb = req.result;
      if (!idb.objectStoreNames.contains(IDB_STORE)) {
        idb.createObjectStore(IDB_STORE);
      }
    };
    req.onsuccess = () => {
      try {
        const idb = req.result;
        const tx = idb.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).put(data, key);
      } catch {
        // ignore
      }
    };
  } catch {
    // ignore
  }
}

export function loadLocalPrayerWuduProgress(uid?: string | null): PrayerWuduLearningData {
  const effectiveUid = uid ?? auth.currentUser?.uid ?? undefined;
  const key = getCacheKey(effectiveUid);
  try {
    const rawStr = localStorage.getItem(key);
    if (rawStr) {
      return normalizeProgressData(JSON.parse(rawStr), effectiveUid);
    }
  } catch {
    // ignore
  }
  return createEmptyPrayerWuduLearningData(effectiveUid);
}

function saveLocalPrayerWuduProgress(data: PrayerWuduLearningData, uid?: string | null): void {
  const effectiveUid = uid ?? data.uid ?? auth.currentUser?.uid ?? undefined;
  const key = getCacheKey(effectiveUid);
  const normalized = normalizeProgressData(data, effectiveUid);
  try {
    localStorage.setItem(key, JSON.stringify(normalized));
  } catch {
    // ignore
  }
  saveToIndexedDb(key, normalized);
}

function mergeLearningData(
  localData: PrayerWuduLearningData,
  remoteData: PrayerWuduLearningData,
  uid?: string
): PrayerWuduLearningData {
  const wuduSteps = Array.from(
    new Set([
      ...localData.wuduProgress.completedStepNumbers,
      ...remoteData.wuduProgress.completedStepNumbers,
    ])
  ).sort((a, b) => a - b);

  const prayerIds: FivePrayerId[] = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
  const mergedPrayers = { ...localData.prayerProgress };

  for (const pid of prayerIds) {
    const lp = localData.prayerProgress[pid];
    const rp = remoteData.prayerProgress[pid];
    const stepIds = Array.from(new Set([...(lp?.completedStepIds || []), ...(rp?.completedStepIds || [])]));
    const totalSteps = Math.max(lp?.totalSteps || 0, rp?.totalSteps || 0, 16);
    mergedPrayers[pid] = {
      prayerId: pid,
      completedStepIds: stepIds,
      totalSteps,
      isCompleted: Boolean(lp?.isCompleted || rp?.isCompleted || stepIds.length >= totalSteps),
      lastStepIndex: rp?.lastStepIndex ?? lp?.lastStepIndex ?? null,
      completedAt: rp?.completedAt || lp?.completedAt || null,
    };
  }

  // Merge quiz results by ID
  const quizMap = new Map<string, QuizResultRecord>();
  for (const q of [...remoteData.quizResults, ...localData.quizResults]) {
    if (q && q.id) {
      quizMap.set(q.id, q);
    }
  }
  const mergedQuizResults = Array.from(quizMap.values()).sort((a, b) =>
    b.completedAt.localeCompare(a.completedAt)
  );

  // Pick most recent lastLesson / lastStep based on lastOpenedAt
  const localTime = localData.lastOpenedAt ? Date.parse(localData.lastOpenedAt) : 0;
  const remoteTime = remoteData.lastOpenedAt ? Date.parse(remoteData.lastOpenedAt) : 0;
  const newer = localTime >= remoteTime ? localData : remoteData;
  const older = localTime >= remoteTime ? remoteData : localData;

  return normalizeProgressData(
    {
      uid,
      wuduProgress: {
        completedStepNumbers: wuduSteps,
        isCompleted:
          localData.wuduProgress.isCompleted ||
          remoteData.wuduProgress.isCompleted ||
          wuduSteps.length >= 9,
        lastStepNumber:
          newer.wuduProgress.lastStepNumber ?? older.wuduProgress.lastStepNumber ?? null,
        completedAt:
          newer.wuduProgress.completedAt || older.wuduProgress.completedAt || null,
      },
      prayerProgress: mergedPrayers,
      completedLessons: Array.from(
        new Set([...localData.completedLessons, ...remoteData.completedLessons])
      ),
      completedSteps: Array.from(
        new Set([...localData.completedSteps, ...remoteData.completedSteps])
      ),
      lastLesson: newer.lastLesson || older.lastLesson || null,
      lastLessonId: newer.lastLessonId || older.lastLessonId || null,
      lastStep: newer.lastStep || older.lastStep || null,
      quizResults: mergedQuizResults,
      lastOpenedAt: newer.lastOpenedAt || older.lastOpenedAt || null,
    },
    uid
  );
}

export async function syncPrayerWuduProgressWithFirestore(): Promise<PrayerWuduLearningData> {
  const user = auth.currentUser;
  const local = loadLocalPrayerWuduProgress(user?.uid);
  if (!user) {
    return local;
  }

  const docRef = doc(db, 'users', user.uid, 'prayer_wudu_learning', 'main');
  try {
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const remote = normalizeProgressData(snap.data() as Partial<PrayerWuduLearningData>, user.uid);
      const merged = mergeLearningData(local, remote, user.uid);
      saveLocalPrayerWuduProgress(merged, user.uid);
      if (hasAnyLearningActivity(merged)) {
        await setDoc(
          docRef,
          {
            ...merged,
            uid: user.uid,
            lastOpenedAt: merged.lastOpenedAt || new Date().toISOString(),
          },
          { merge: true }
        );
      }
      return merged;
    } else if (hasAnyLearningActivity(local)) {
      const toWrite: PrayerWuduLearningData = {
        ...local,
        uid: user.uid,
        lastOpenedAt: local.lastOpenedAt || new Date().toISOString(),
      };
      saveLocalPrayerWuduProgress(toWrite, user.uid);
      await setDoc(docRef, toWrite, { merge: true });
      return toWrite;
    }
  } catch {
    // Graceful offline fallback
  }
  return local;
}

export async function persistPrayerWuduProgress(
  updater: (prev: PrayerWuduLearningData) => PrayerWuduLearningData
): Promise<PrayerWuduLearningData> {
  const user = auth.currentUser;
  const prev = loadLocalPrayerWuduProgress(user?.uid);
  const nowIso = new Date().toISOString();
  const updated = normalizeProgressData(
    {
      ...updater(prev),
      uid: user?.uid,
      lastOpenedAt: nowIso,
    },
    user?.uid
  );

  saveLocalPrayerWuduProgress(updated, user?.uid);

  if (user) {
    const docRef = doc(db, 'users', user.uid, 'prayer_wudu_learning', 'main');
    try {
      await setDoc(docRef, updated, { merge: true });
    } catch {
      // Saved locally and will sync when connection resumes
    }
  }

  return updated;
}

export function subscribeToPrayerWuduProgress(
  onUpdate: (data: PrayerWuduLearningData) => void
): () => void {
  let unsubSnapshot: (() => void) | null = null;

  const unsubAuth = onAuthStateChanged(auth, (user) => {
    if (unsubSnapshot) {
      unsubSnapshot();
      unsubSnapshot = null;
    }

    if (!user) {
      onUpdate(loadLocalPrayerWuduProgress(null));
      return;
    }

    const docRef = doc(db, 'users', user.uid, 'prayer_wudu_learning', 'main');
    unsubSnapshot = onSnapshot(
      docRef,
      (snap) => {
        const local = loadLocalPrayerWuduProgress(user.uid);
        if (snap.exists()) {
          const remote = normalizeProgressData(
            snap.data() as Partial<PrayerWuduLearningData>,
            user.uid
          );
          const merged = mergeLearningData(local, remote, user.uid);
          saveLocalPrayerWuduProgress(merged, user.uid);
          onUpdate(merged);
        } else {
          onUpdate(local);
        }
      },
      () => {
        onUpdate(loadLocalPrayerWuduProgress(user.uid));
      }
    );
  });

  return () => {
    unsubAuth();
    if (unsubSnapshot) unsubSnapshot();
  };
}
