import {
  collection,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  getCountFromServer,
  increment,
  writeBatch,
  onSnapshot,
  QueryDocumentSnapshot,
  DocumentData,
} from 'firebase/firestore';
import {
  db,
  auth,
  User,
  UserCloudProfile,
  OperationType,
  handleFirestoreError,
} from './firebase';
import {
  getNotificationPermission,
  loadUnifiedNotificationSettings,
  isNativeAndroidPlatform,
} from './notifications';
import { ScreenType, WardType } from '../types';

export const PRIMARY_ADMIN_EMAIL = 'mo.abdullah262007@gmail.com';

export interface AdminRoleRecord {
  uid: string;
  email: string | null;
  displayName: string | null;
  role: 'admin';
  grantedBy: string;
  grantedAt: string;
}

export interface AdminVerificationResult {
  isAdmin: boolean;
  role: 'admin' | 'user';
  adminDoc: AdminRoleRecord | null;
  verifiedAt: number;
  error?: string;
}

export interface AdminDashboardStats {
  totalUsers: number | null;
  activeUsers24h: number | null;
  activeUsers7d: number | null;
  newUsersToday: number | null;
  newUsers7d: number | null;
  activeNotificationDevices: number | null;
  totalNotificationDevices: number | null;
  sentNotificationsCount: number | null;
  openReportsCount: number | null;
  totalReportsCount: number | null;
  activeGroupsCount: number | null;
  totalAdminsCount: number | null;
  fetchedAt: string;
}

export interface AdminUserSummary {
  uid: string;
  displayName: string;
  email: string | null;
  photoURL: string | null;
  emailVerified: boolean;
  providerId: string;
  createdAt: string | null;
  lastActiveAt: string | null;
  lastSyncedAt: number | null;
  accountStatus: 'active' | 'suspended' | 'banned';
  statusReason?: string;
  role: 'user' | 'admin';
  city?: string;
  stats?: UserCloudProfile['stats'];
}

export interface NotificationDeviceRecord {
  uid: string;
  email: string | null;
  displayName: string | null;
  platform: 'web' | 'android';
  permissionStatus: 'granted' | 'denied' | 'default' | 'unsupported';
  isActive: boolean;
  channelsEnabled?: Record<string, boolean>;
  updatedAt: string;
}

export interface AdminNotificationRecord {
  id: string;
  title: string;
  message: string;
  type: 'general' | 'reminder' | 'milestone';
  targetType: 'all' | 'user';
  targetUid?: string | null;
  actionScreen?: ScreenType | null;
  actionWard?: WardType | null;
  sentByUid: string;
  sentByName: string;
  createdAt: string;
}

export type ReportCategory = 'bug' | 'content' | 'group' | 'account' | 'suggestion' | 'other';
export type ReportStatus = 'open' | 'new' | 'in_progress' | 'resolved' | 'closed';

export interface SafeDeviceDiagnosticInfo {
  appVersion: string;
  platform: string;
  browserOrOs: string;
  screenResolution: string;
  language: string;
  onlineStatus: string;
  theme?: string;
}

export interface UserReportRecord {
  id: string;
  userId?: string | null;
  reporterUid: string;
  reporterName: string;
  reporterEmail: string | null;
  category: ReportCategory;
  issueType?: string | null;
  subject: string;
  description: string;
  targetId?: string | null;
  screenshotDataUrl?: string | null;
  deviceInfo?: SafeDeviceDiagnosticInfo | null;
  status: ReportStatus;
  adminResponse?: string | null;
  resolvedByUid?: string | null;
  createdAt: string;
  updatedAt: string;
}

export function getReportStatusLabel(status: ReportStatus): string {
  switch (status) {
    case 'open':
    case 'new':
      return 'جديد';
    case 'in_progress':
      return 'قيد المراجعة';
    case 'resolved':
      return 'تم الحل';
    case 'closed':
      return 'مغلق';
    default:
      return 'جديد';
  }
}

export function collectSafeDeviceDiagnosticInfo(themeName?: string): SafeDeviceDiagnosticInfo {
  const isAndroidApk = isNativeAndroidPlatform();
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  let osSummary = 'نظام غير محدد';
  if (/android/i.test(ua)) osSummary = 'Android';
  else if (/iPad|iPhone|iPod/i.test(ua)) osSummary = 'iOS';
  else if (/Win/i.test(ua)) osSummary = 'Windows';
  else if (/Mac/i.test(ua)) osSummary = 'macOS';
  else if (/Linux/i.test(ua)) osSummary = 'Linux';

  let browserSummary = 'متصفح الويب';
  if (isAndroidApk || /wv/i.test(ua)) browserSummary = 'Android WebView / APK';
  else if (/Edg\//i.test(ua)) browserSummary = 'Edge';
  else if (/Chrome\//i.test(ua)) browserSummary = 'Chrome';
  else if (/Safari\//i.test(ua) && !/Chrome\//i.test(ua)) browserSummary = 'Safari';
  else if (/Firefox\//i.test(ua)) browserSummary = 'Firefox';

  const screenRes =
    typeof window !== 'undefined'
      ? `${window.innerWidth}×${window.innerHeight}`
      : 'غير متاح';

  return {
    appVersion: '2.5.0',
    platform: isAndroidApk ? 'تطبيق أندرويد (APK)' : 'نسخة الويب (PWA)',
    browserOrOs: `${osSummary} • ${browserSummary}`,
    screenResolution: screenRes,
    language: typeof navigator !== 'undefined' ? navigator.language || 'ar' : 'ar',
    onlineStatus:
      typeof navigator !== 'undefined'
        ? navigator.onLine
          ? 'متصل بالإنترنت'
          : 'غير متصل'
        : 'متصل',
    ...(themeName ? { theme: themeName } : {}),
  };
}

export async function compressScreenshotFileToDataUrl(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('يرجى اختيار ملف صورة صالح فقط (PNG أو JPG أو WebP).');
  }
  if (file.size > 10 * 1024 * 1024) {
    throw new Error('حجم الصورة كبير جداً. يرجى اختيار صورة أقل من 10 ميجابايت.');
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذر قراءة ملف الصورة المرفقة.'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('ملف الصورة غير صالح.'));
      img.onload = () => {
        const maxDim = 850;
        let width = img.width;
        let height = img.height;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('تعذر معالجة الصورة المرفقة.'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const compressed = canvas.toDataURL('image/jpeg', 0.65);
        resolve(compressed);
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

const GUEST_SUBMITTED_REPORTS_KEY = 'rifq_guest_submitted_report_ids_v1';

function saveGuestSubmittedReportId(reportId: string): void {
  try {
    const raw = localStorage.getItem(GUEST_SUBMITTED_REPORTS_KEY);
    const parsed: string[] = raw ? JSON.parse(raw) : [];
    if (!parsed.includes(reportId)) {
      const updated = [reportId, ...parsed].slice(0, 30);
      localStorage.setItem(GUEST_SUBMITTED_REPORTS_KEY, JSON.stringify(updated));
    }
  } catch {
    // Ignore storage errors
  }
}

function getGuestSubmittedReportIds(): string[] {
  try {
    const raw = localStorage.getItem(GUEST_SUBMITTED_REPORTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((id) => typeof id === 'string') : [];
  } catch {
    return [];
  }
}

export interface AdminAuditLogRecord {
  id: string;
  adminUid: string;
  adminEmail: string | null;
  actionType: string;
  targetType: 'user' | 'group' | 'notification' | 'report' | 'system';
  targetId: string;
  details: string;
  createdAt: string;
}

export interface SystemConfigRecord {
  announcementEnabled: boolean;
  announcementTitle: string;
  announcementMessage: string;
  announcementType: 'info' | 'warning' | 'celebration';
  updatedByUid?: string;
  updatedAt?: string;
}

export interface AdminGroupSummary {
  id: string;
  groupName: string;
  joinCode: string;
  adminId: string;
  adminName: string;
  description: string;
  planType: string;
  totalPages: number;
  targetDays: number;
  currentDay: number;
  isPublic: boolean;
  isActive: boolean;
  createdAt: string;
}

/**
 * Formats any Firestore / Firebase error into a clear, truthful Arabic message
 * while preserving the underlying error code/details for the administrator.
 */
export function formatAdminOperationError(error: unknown): string {
  if (!error) return 'حدث خطأ غير معروف أثناء تنفيذ العملية.';
  const raw = error instanceof Error ? error.message : String(error);
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && 'error' in parsed) {
      const inner = String(parsed.error || '');
      if (inner.includes('Missing or insufficient permissions') || inner.includes('PERMISSION_DENIED')) {
        return `رفضت قواعد أمان Firebase (Security Rules) تنفيذ العملية على المسار (${parsed.path || 'غير محدد'}): صلاحيات غير كافية.`;
      }
      return `فشلت العملية في Firestore (${parsed.operationType || 'write'}): ${inner}`;
    }
  } catch {
    // Not a JSON FirestoreErrorInfo string
  }

  if (raw.includes('Missing or insufficient permissions') || raw.includes('PERMISSION_DENIED')) {
    return 'رفض الخادم تنفيذ العملية (PERMISSION_DENIED): الحساب الحالي لا يملك صلاحية مسؤول (Admin) موثقة في قاعدة البيانات.';
  }
  if (raw.includes('Quota exceeded')) {
    return 'تم تجاوز الحصة اليومية المجانية لقواعد بيانات Firestore (Quota Exceeded).';
  }
  if (raw.includes('offline') || raw.includes('network')) {
    return 'تعذر الاتصال بخادم Firebase، يرجى التحقق من اتصال الإنترنت والمحاولة مجدداً.';
  }
  return raw;
}

/**
 * Generates a clean Firestore-compatible ID matching ^[a-zA-Z0-9_\-]+$
 */
function generateCleanDocId(prefix: string): string {
  const randomPart = Math.random().toString(36).substring(2, 10);
  return `${prefix}_${Date.now()}_${randomPart}`;
}

/**
 * Writes an immutable audit log entry in /admin_audit_logs/{logId}
 */
export async function recordAdminAuditLog(params: {
  actionType: string;
  targetType: 'user' | 'group' | 'notification' | 'report' | 'system';
  targetId: string;
  details: string;
}): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) return;

  const logId = generateCleanDocId('audit');
  const nowIso = new Date().toISOString();
  const path = `admin_audit_logs/${logId}`;

  try {
    await setDoc(doc(db, 'admin_audit_logs', logId), {
      adminUid: currentUser.uid,
      adminEmail: currentUser.email || null,
      actionType: params.actionType.slice(0, 100),
      targetType: params.targetType,
      targetId: (params.targetId || 'global').slice(0, 128),
      details: params.details.slice(0, 1900),
      createdAt: nowIso,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Server-side / Firestore RBAC verification for the current user.
 * Checks /admins/{uid} directly from Firestore (and provisions /admins/{uid} if the user is
 * the verified primary owner email).
 * Never trusts localStorage, URL params, or unverified client claims.
 */
export async function verifyAdminAccess(user: User | null): Promise<AdminVerificationResult> {
  if (!user || !user.uid) {
    return {
      isAdmin: false,
      role: 'user',
      adminDoc: null,
      verifiedAt: Date.now(),
    };
  }

  const adminDocRef = doc(db, 'admins', user.uid);

  try {
    // 1. Force server read first to guarantee real-time revocation/grant accuracy
    let snap;
    try {
      snap = await getDocFromServer(adminDocRef);
    } catch {
      snap = await getDoc(adminDocRef);
    }

    if (snap.exists()) {
      const data = snap.data() as AdminRoleRecord;
      if (data && data.role === 'admin') {
        return {
          isAdmin: true,
          role: 'admin',
          adminDoc: data,
          verifiedAt: Date.now(),
        };
      }
    }

    // 2. Check if this user is the verified primary bootstrapped owner allowed by firestore.rules
    const isPrimaryVerifiedAdmin =
      Boolean(user.emailVerified) &&
      typeof user.email === 'string' &&
      user.email.toLowerCase() === PRIMARY_ADMIN_EMAIL.toLowerCase();

    if (isPrimaryVerifiedAdmin) {
      const nowIso = new Date().toISOString();
      const bootstrapRecord: AdminRoleRecord = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || 'المسؤول الرئيسي',
        role: 'admin',
        grantedBy: 'system_bootstrap',
        grantedAt: nowIso,
      };

      await setDoc(adminDocRef, bootstrapRecord, { merge: true });
      await setDoc(
        doc(db, 'users', user.uid),
        {
          uid: user.uid,
          role: 'admin',
          accountStatus: 'active',
          updatedAt: nowIso,
        },
        { merge: true }
      );

      return {
        isAdmin: true,
        role: 'admin',
        adminDoc: bootstrapRecord,
        verifiedAt: Date.now(),
      };
    }

    return {
      isAdmin: false,
      role: 'user',
      adminDoc: null,
      verifiedAt: Date.now(),
    };
  } catch (error) {
    return {
      isAdmin: false,
      role: 'user',
      adminDoc: null,
      verifiedAt: Date.now(),
      error: formatAdminOperationError(error),
    };
  }
}

/**
 * Syncs the current authenticated user's real device notification state to /notification_devices/{uid}.
 * This ensures the Admin Dashboard's "الأجهزة/التوكنات النشطة للإشعارات" count is 100% real.
 */
export async function syncCurrentDeviceNotificationStatus(user: User | null): Promise<void> {
  if (!user || !user.uid) return;
  try {
    const perm = getNotificationPermission();
    const unified = loadUnifiedNotificationSettings();
    const platform: 'web' | 'android' = isNativeAndroidPlatform() ? 'android' : 'web';
    const anyChannelEnabled =
      unified.adhanChannelEnabled ||
      unified.quranChannelEnabled ||
      unified.azkarChannelEnabled ||
      unified.remindersChannelEnabled ||
      unified.updatesChannelEnabled;
    const isActive = perm === 'granted' && anyChannelEnabled;
    const nowIso = new Date().toISOString();

    await setDoc(
      doc(db, 'notification_devices', user.uid),
      {
        uid: user.uid,
        email: user.email || null,
        displayName: user.displayName || null,
        platform,
        permissionStatus: perm,
        isActive,
        channelsEnabled: {
          adhan: unified.adhanChannelEnabled,
          quran: unified.quranChannelEnabled,
          azkar: unified.azkarChannelEnabled,
          reminders: unified.remindersChannelEnabled,
          updates: unified.updatesChannelEnabled,
        },
        updatedAt: nowIso,
      },
      { merge: true }
    );
  } catch {
    // Non-blocking background device status registration
  }
}

/**
 * Safe helper to run a server-side count aggregation query without throwing if an index/collection is unavailable.
 * Returns null if the count cannot be retrieved so the UI displays "غير متاح" instead of a fake 0.
 */
async function safeServerCount(q: ReturnType<typeof query> | ReturnType<typeof collection>): Promise<number | null> {
  try {
    const snap = await getCountFromServer(q);
    return snap.data().count;
  } catch {
    return null;
  }
}

/**
 * Fetches 100% real, server-aggregated statistics for the Admin Dashboard.
 * Never downloads all user documents just to count them; uses getCountFromServer & /system_stats/global.
 */
export async function fetchAdminDashboardStats(): Promise<AdminDashboardStats> {
  const now = Date.now();
  const oneDayAgoMs = now - 24 * 60 * 60 * 1000;
  const sevenDaysAgoMs = now - 7 * 24 * 60 * 60 * 1000;

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const todayStartIso = todayStart.toISOString();
  const sevenDaysAgoIso = new Date(sevenDaysAgoMs).toISOString();

  const [
    totalUsersCount,
    active24hCount,
    active7dCount,
    newTodayCount,
    new7dCount,
    activeDevicesCount,
    totalDevicesCount,
    sentNotifsCount,
    openReportsCount,
    totalReportsCount,
    activeGroupsCount,
    totalAdminsCount,
  ] = await Promise.all([
    safeServerCount(collection(db, 'users')),
    safeServerCount(query(collection(db, 'users'), where('lastSyncedAt', '>=', oneDayAgoMs))),
    safeServerCount(query(collection(db, 'users'), where('lastSyncedAt', '>=', sevenDaysAgoMs))),
    safeServerCount(query(collection(db, 'users'), where('createdAt', '>=', todayStartIso))),
    safeServerCount(query(collection(db, 'users'), where('createdAt', '>=', sevenDaysAgoIso))),
    safeServerCount(query(collection(db, 'notification_devices'), where('isActive', '==', true))),
    safeServerCount(collection(db, 'notification_devices')),
    safeServerCount(collection(db, 'admin_notifications')),
    safeServerCount(query(collection(db, 'reports'), where('status', '==', 'open'))),
    safeServerCount(collection(db, 'reports')),
    safeServerCount(query(collection(db, 'groups'), where('isActive', '==', true))),
    safeServerCount(collection(db, 'admins')),
  ]);

  // Reconcile /system_stats/global with real authoritative server counts
  try {
    const statsUpdate: Record<string, unknown> = {
      updatedAt: new Date().toISOString(),
    };
    if (totalUsersCount !== null) statsUpdate.totalUsersCount = totalUsersCount;
    if (sentNotifsCount !== null) statsUpdate.sentNotificationsCount = sentNotifsCount;
    if (openReportsCount !== null) statsUpdate.openReportsCount = openReportsCount;

    await setDoc(doc(db, 'system_stats', 'global'), statsUpdate, { merge: true });
  } catch {
    // Ignore if offline
  }

  return {
    totalUsers: totalUsersCount,
    activeUsers24h: active24hCount,
    activeUsers7d: active7dCount,
    newUsersToday: newTodayCount,
    newUsers7d: new7dCount,
    activeNotificationDevices: activeDevicesCount,
    totalNotificationDevices: totalDevicesCount,
    sentNotificationsCount: sentNotifsCount,
    openReportsCount: openReportsCount,
    totalReportsCount: totalReportsCount,
    activeGroupsCount: activeGroupsCount,
    totalAdminsCount: totalAdminsCount,
    fetchedAt: new Date().toISOString(),
  };
}

/**
 * Maps a raw Firestore user document + admin UID set to a clean AdminUserSummary
 * (Strictly excludes any sensitive credentials; passwords are never stored in Firestore).
 */
function mapDocToAdminUserSummary(
  uid: string,
  data: Record<string, any>,
  adminUids: Set<string>
): AdminUserSummary {
  const email = typeof data.email === 'string' && data.email.trim() ? data.email.trim() : null;
  const isPrimaryEmail =
    email !== null && email.toLowerCase() === PRIMARY_ADMIN_EMAIL.toLowerCase();
  const isAdminRole = adminUids.has(uid) || data.role === 'admin' || isPrimaryEmail;

  const statusRaw = data.accountStatus;
  const accountStatus: 'active' | 'suspended' | 'banned' =
    statusRaw === 'suspended' || statusRaw === 'banned' ? statusRaw : 'active';

  return {
    uid,
    displayName:
      (typeof data.displayName === 'string' && data.displayName.trim()) ||
      (typeof data.fullName === 'string' && data.fullName.trim()) ||
      (email ? email.split('@')[0] : 'مستخدم رِفْق'),
    email,
    photoURL: typeof data.photoURL === 'string' ? data.photoURL : null,
    emailVerified: Boolean(data.emailVerified),
    providerId: typeof data.providerId === 'string' ? data.providerId : ' غير مسجل',
    createdAt: typeof data.createdAt === 'string' ? data.createdAt : null,
    lastActiveAt:
      typeof data.lastActiveAt === 'string'
        ? data.lastActiveAt
        : typeof data.updatedAt === 'string'
        ? data.updatedAt
        : null,
    lastSyncedAt: typeof data.lastSyncedAt === 'number' ? data.lastSyncedAt : null,
    accountStatus,
    statusReason: typeof data.statusReason === 'string' ? data.statusReason : undefined,
    role: isAdminRole ? 'admin' : 'user',
    city: typeof data.city === 'string' ? data.city : undefined,
    stats: data.stats,
  };
}

/**
 * Fetches the set of all verified Admin UIDs from /admins
 */
export async function fetchAllAdminUids(): Promise<Set<string>> {
  const set = new Set<string>();
  try {
    const snap = await getDocs(collection(db, 'admins'));
    snap.forEach((d) => {
      const data = d.data();
      if (data?.role === 'admin') {
        set.add(d.id);
      }
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'admins');
  }
  return set;
}

/**
 * Fetches paginated real users from Firestore /users collection
 */
export async function fetchAdminUsersPage(options?: {
  pageSize?: number;
  lastDoc?: QueryDocumentSnapshot<DocumentData> | null;
}): Promise<{
  users: AdminUserSummary[];
  lastDoc: QueryDocumentSnapshot<DocumentData> | null;
  hasMore: boolean;
}> {
  const pageSize = options?.pageSize || 25;
  const adminUids = await fetchAllAdminUids();

  try {
    let q = query(collection(db, 'users'), limit(pageSize));
    if (options?.lastDoc) {
      q = query(collection(db, 'users'), startAfter(options.lastDoc), limit(pageSize));
    }

    const snap = await getDocs(q);
    const users: AdminUserSummary[] = [];
    snap.forEach((docSnap) => {
      users.push(mapDocToAdminUserSummary(docSnap.id, docSnap.data(), adminUids));
    });

    // Sort by newest activity or creation date
    users.sort((a, b) => {
      const tA = a.lastSyncedAt || (a.createdAt ? new Date(a.createdAt).getTime() : 0);
      const tB = b.lastSyncedAt || (b.createdAt ? new Date(b.createdAt).getTime() : 0);
      return tB - tA;
    });

    const nextLastDoc = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;
    return {
      users,
      lastDoc: nextLastDoc,
      hasMore: snap.docs.length === pageSize,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
  }
}

/**
 * Real server-backed user search by UID, Email, or DisplayName.
 */
export async function searchAdminUsersInFirestore(searchTerm: string): Promise<AdminUserSummary[]> {
  const trimmed = searchTerm.trim();
  if (!trimmed) {
    const page = await fetchAdminUsersPage({ pageSize: 25 });
    return page.users;
  }

  const adminUids = await fetchAllAdminUids();
  const resultsMap = new Map<string, AdminUserSummary>();

  try {
    // 1. Direct UID lookup in /users/{trimmed}
    if (/^[a-zA-Z0-9_\-]+$/.test(trimmed)) {
      const directSnap = await getDoc(doc(db, 'users', trimmed));
      if (directSnap.exists()) {
        resultsMap.set(
          directSnap.id,
          mapDocToAdminUserSummary(directSnap.id, directSnap.data(), adminUids)
        );
      }
    }

    // 2. Exact Email query if it contains '@'
    if (trimmed.includes('@')) {
      const emailQuery = query(collection(db, 'users'), where('email', '==', trimmed), limit(10));
      const emailSnap = await getDocs(emailQuery);
      emailSnap.forEach((d) => {
        resultsMap.set(d.id, mapDocToAdminUserSummary(d.id, d.data(), adminUids));
      });
    }

    // 3. Exact displayName match
    const nameQuery = query(
      collection(db, 'users'),
      where('displayName', '==', trimmed),
      limit(15)
    );
    const nameSnap = await getDocs(nameQuery);
    nameSnap.forEach((d) => {
      resultsMap.set(d.id, mapDocToAdminUserSummary(d.id, d.data(), adminUids));
    });

    // 4. Case-insensitive partial filter across recent users batch (up to 60 docs)
    const recentSnap = await getDocs(query(collection(db, 'users'), limit(60)));
    const lower = trimmed.toLowerCase();
    recentSnap.forEach((d) => {
      if (resultsMap.has(d.id)) return;
      const summary = mapDocToAdminUserSummary(d.id, d.data(), adminUids);
      if (
        summary.uid.toLowerCase().includes(lower) ||
        (summary.email && summary.email.toLowerCase().includes(lower)) ||
        summary.displayName.toLowerCase().includes(lower)
      ) {
        resultsMap.set(d.id, summary);
      }
    });

    return Array.from(resultsMap.values());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
  }
}

/**
 * Inspects full real details of a specific user from Firestore
 */
export async function inspectAdminUserDetails(uid: string): Promise<{
  profile: AdminUserSummary;
  rawProfile: Record<string, any>;
  deviceStatus: NotificationDeviceRecord | null;
  journeysCount: number;
  achievementsCount: number;
}> {
  const adminUids = await fetchAllAdminUids();
  const userRef = doc(db, 'users', uid);

  try {
    const [userSnap, deviceSnap, journeysCount, achievementsCount] = await Promise.all([
      getDocFromServer(userRef).catch(() => getDoc(userRef)),
      getDoc(doc(db, 'notification_devices', uid)).catch(() => null),
      safeServerCount(collection(db, 'users', uid, 'journeys')),
      safeServerCount(collection(db, 'users', uid, 'achievements')),
    ]);

    if (!userSnap.exists()) {
      throw new Error('لم يتم العثور على وثيقة المستخدم في قاعدة البيانات.');
    }

    const rawData = userSnap.data();
    const profile = mapDocToAdminUserSummary(uid, rawData, adminUids);
    const deviceStatus =
      deviceSnap && deviceSnap.exists() ? (deviceSnap.data() as NotificationDeviceRecord) : null;

    return {
      profile,
      rawProfile: rawData,
      deviceStatus,
      journeysCount: journeysCount ?? 0,
      achievementsCount: achievementsCount ?? 0,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
  }
}

/**
 * Updates a user's account status ('active' | 'suspended' | 'banned') in Firestore /users/{targetUid}
 */
export async function updateUserAccountStatusByAdmin(params: {
  targetUid: string;
  targetName: string;
  newStatus: 'active' | 'suspended' | 'banned';
  reason: string;
}): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('يجب تسجيل الدخول كمسؤول لتنفيذ هذه العملية.');
  }
  if (params.targetUid === currentUser.uid && params.newStatus !== 'active') {
    throw new Error('لا يمكنك إيقاف أو حظر حسابك الإداري الحالي.');
  }

  const nowIso = new Date().toISOString();
  const path = `users/${params.targetUid}`;

  try {
    await setDoc(
      doc(db, 'users', params.targetUid),
      {
        uid: params.targetUid,
        accountStatus: params.newStatus,
        statusReason: params.reason.trim() || null,
        statusUpdatedAt: nowIso,
        statusUpdatedBy: currentUser.uid,
        updatedAt: nowIso,
      },
      { merge: true }
    );

    const statusLabel =
      params.newStatus === 'active'
        ? 'تفعيل الحساب (نشط)'
        : params.newStatus === 'suspended'
        ? 'إيقاف الحساب مؤقتاً'
        : 'حظر الحساب نهائياً';

    await recordAdminAuditLog({
      actionType: `user_status_${params.newStatus}`,
      targetType: 'user',
      targetId: params.targetUid,
      details: `${statusLabel} للمستخدم "${params.targetName}" (${params.targetUid})${
        params.reason.trim() ? ` — السبب: ${params.reason.trim()}` : ''
      }`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Grants or revokes Admin privileges for a user by writing/deleting /admins/{targetUid}
 * and syncing role field on /users/{targetUid}.
 */
export async function setUserAdminRoleByAdmin(params: {
  targetUid: string;
  targetName: string;
  targetEmail: string | null;
  makeAdmin: boolean;
}): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('يجب تسجيل الدخول كمسؤول لتنفيذ هذه العملية.');
  }
  if (!params.makeAdmin && params.targetUid === currentUser.uid) {
    throw new Error('لا يمكنك سحب صلاحية المسؤول (Admin) من حسابك الحالي منعاً لفقدان الوصول.');
  }
  if (
    !params.makeAdmin &&
    params.targetEmail &&
    params.targetEmail.toLowerCase() === PRIMARY_ADMIN_EMAIL.toLowerCase()
  ) {
    throw new Error('لا يمكن سحب صلاحية المالك الرئيسي للنظام.');
  }

  const nowIso = new Date().toISOString();
  const adminDocPath = `admins/${params.targetUid}`;

  try {
    if (params.makeAdmin) {
      const record: AdminRoleRecord = {
        uid: params.targetUid,
        email: params.targetEmail || null,
        displayName: params.targetName,
        role: 'admin',
        grantedBy: currentUser.uid,
        grantedAt: nowIso,
      };
      await setDoc(doc(db, 'admins', params.targetUid), record);
      await setDoc(
        doc(db, 'users', params.targetUid),
        {
          uid: params.targetUid,
          role: 'admin',
          updatedAt: nowIso,
        },
        { merge: true }
      );

      await recordAdminAuditLog({
        actionType: 'grant_admin_role',
        targetType: 'user',
        targetId: params.targetUid,
        details: `منح صلاحية مسؤول (Admin) للمستخدم "${params.targetName}" (${params.targetUid})`,
      });
    } else {
      await deleteDoc(doc(db, 'admins', params.targetUid));
      await setDoc(
        doc(db, 'users', params.targetUid),
        {
          uid: params.targetUid,
          role: 'user',
          updatedAt: nowIso,
        },
        { merge: true }
      );

      await recordAdminAuditLog({
        actionType: 'revoke_admin_role',
        targetType: 'user',
        targetId: params.targetUid,
        details: `سحب صلاحية المسؤول وإرجاع الدور إلى مستخدم عادي (User) للحساب "${params.targetName}" (${params.targetUid})`,
      });
    }
  } catch (error) {
    handleFirestoreError(
      error,
      params.makeAdmin ? OperationType.CREATE : OperationType.DELETE,
      adminDocPath
    );
  }
}

/**
 * Deletes a user's Firestore documents and subcollections (/users/{targetUid}) and decrements global counter.
 */
export async function deleteUserCloudDataByAdmin(params: {
  targetUid: string;
  targetName: string;
}): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('يجب تسجيل الدخول كمسؤول لتنفيذ هذه العملية.');
  }
  if (params.targetUid === currentUser.uid) {
    throw new Error('لا يمكنك حذف حسابك الإداري الحالي من لوحة الإدارة.');
  }

  const path = `users/${params.targetUid}`;
  try {
    // Delete known user subcollections first
    const subcollections = ['journeys', 'journey_progress', 'daily_tasks', 'achievements'];
    for (const sub of subcollections) {
      const subSnap = await getDocs(collection(db, 'users', params.targetUid, sub));
      if (!subSnap.empty) {
        const batch = writeBatch(db);
        subSnap.forEach((d) => batch.delete(d.ref));
        await batch.commit();
      }
    }

    // Delete notification device doc if exists
    try {
      await deleteDoc(doc(db, 'notification_devices', params.targetUid));
    } catch {
      // Ignore if not present
    }

    // Delete primary user doc
    await deleteDoc(doc(db, 'users', params.targetUid));

    // Decrement counter in /system_stats/global
    await setDoc(
      doc(db, 'system_stats', 'global'),
      {
        totalUsersCount: increment(-1),
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );

    await recordAdminAuditLog({
      actionType: 'delete_user_cloud_data',
      targetType: 'user',
      targetId: params.targetUid,
      details: `حذف السجل السحابي والبيانات المرتبطة للمستخدم "${params.targetName}" (${params.targetUid})`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Sends a real broadcast or user-targeted notification via Firestore /admin_notifications/{notifId}.
 * Connected clients automatically receive and display it in real-time.
 */
export async function sendAdminBroadcastNotification(params: {
  title: string;
  message: string;
  type: 'general' | 'reminder' | 'milestone';
  targetType: 'all' | 'user';
  targetUid?: string;
  actionScreen?: ScreenType | '';
  actionWard?: WardType | '';
}): Promise<AdminNotificationRecord> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('يجب تسجيل الدخول كمسؤول لإرسال الإشعارات.');
  }

  const cleanTitle = params.title.trim();
  const cleanMsg = params.message.trim();
  if (!cleanTitle || !cleanMsg) {
    throw new Error('يرجى إدخال عنوان الإشعار ونص الرسالة.');
  }
  if (params.targetType === 'user' && !params.targetUid?.trim()) {
    throw new Error('يرجى إدخال معرف المستخدم (UID) المستهدف.');
  }

  const notifId = generateCleanDocId('notif');
  const nowIso = new Date().toISOString();
  const path = `admin_notifications/${notifId}`;

  const payload: Record<string, any> = {
    title: cleanTitle.slice(0, 200),
    message: cleanMsg.slice(0, 2000),
    type: params.type,
    targetType: params.targetType,
    targetUid: params.targetType === 'user' ? params.targetUid?.trim() : null,
    actionScreen: params.actionScreen || null,
    actionWard: params.actionWard || null,
    sentByUid: currentUser.uid,
    sentByName: currentUser.displayName || currentUser.email || 'إدارة رِفْق',
    createdAt: nowIso,
  };

  try {
    await setDoc(doc(db, 'admin_notifications', notifId), payload);

    await setDoc(
      doc(db, 'system_stats', 'global'),
      {
        sentNotificationsCount: increment(1),
        updatedAt: nowIso,
      },
      { merge: true }
    );

    await recordAdminAuditLog({
      actionType: 'send_notification',
      targetType: 'notification',
      targetId: notifId,
      details: `إرسال إشعار "${cleanTitle}" إلى (${
        params.targetType === 'all' ? 'جميع المستخدمين' : `المستخدم ${params.targetUid}`
      })`,
    });

    return {
      id: notifId,
      ...(payload as Omit<AdminNotificationRecord, 'id'>),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Fetches sent admin notifications from /admin_notifications
 */
export async function fetchAdminSentNotifications(
  maxItems = 30
): Promise<AdminNotificationRecord[]> {
  try {
    const q = query(
      collection(db, 'admin_notifications'),
      orderBy('createdAt', 'desc'),
      limit(maxItems)
    );
    const snap = await getDocs(q);
    const list: AdminNotificationRecord[] = [];
    snap.forEach((d) => {
      const data = d.data();
      list.push({
        id: d.id,
        title: data.title || '',
        message: data.message || '',
        type: data.type || 'general',
        targetType: data.targetType || 'all',
        targetUid: data.targetUid || null,
        actionScreen: data.actionScreen || null,
        actionWard: data.actionWard || null,
        sentByUid: data.sentByUid || '',
        sentByName: data.sentByName || 'إدارة رِفْق',
        createdAt: data.createdAt || '',
      });
    });
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'admin_notifications');
  }
}

/**
 * Deletes a sent notification from /admin_notifications/{notifId}
 */
export async function deleteAdminNotificationById(notifId: string, title: string): Promise<void> {
  const path = `admin_notifications/${notifId}`;
  try {
    await deleteDoc(doc(db, 'admin_notifications', notifId));
    await recordAdminAuditLog({
      actionType: 'delete_notification',
      targetType: 'notification',
      targetId: notifId,
      details: `حذف الإشعار الإداري "${title}" (${notifId})`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Fetches registered notification devices from /notification_devices
 */
export async function fetchRegisteredNotificationDevices(
  maxItems = 40
): Promise<NotificationDeviceRecord[]> {
  try {
    const q = query(collection(db, 'notification_devices'), limit(maxItems));
    const snap = await getDocs(q);
    const list: NotificationDeviceRecord[] = [];
    snap.forEach((d) => {
      const data = d.data();
      list.push({
        uid: data.uid || d.id,
        email: data.email || null,
        displayName: data.displayName || null,
        platform: data.platform === 'android' ? 'android' : 'web',
        permissionStatus: data.permissionStatus || 'default',
        isActive: Boolean(data.isActive),
        channelsEnabled: data.channelsEnabled || {},
        updatedAt: data.updatedAt || '',
      });
    });
    list.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'notification_devices');
  }
}

/**
 * Subscribes a signed-in client to real-time admin broadcast/targeted notifications
 */
export function subscribeToLiveAdminNotifications(
  currentUid: string,
  onNewNotification: (notif: AdminNotificationRecord) => void
): () => void {
  if (!currentUid) return () => {};

  const q = query(collection(db, 'admin_notifications'), orderBy('createdAt', 'desc'), limit(8));
  const unsub = onSnapshot(
    q,
    (snap) => {
      snap.forEach((docSnap) => {
        const data = docSnap.data();
        if (!data) return;
        const targetType = data.targetType || 'all';
        const targetUid = data.targetUid || null;
        if (targetType === 'all' || (targetType === 'user' && targetUid === currentUid)) {
          onNewNotification({
            id: docSnap.id,
            title: data.title || 'إشعار من إدارة رِفْق',
            message: data.message || '',
            type: data.type || 'general',
            targetType,
            targetUid,
            actionScreen: data.actionScreen || null,
            actionWard: data.actionWard || null,
            sentByUid: data.sentByUid || '',
            sentByName: data.sentByName || 'إدارة رِفْق',
            createdAt: data.createdAt || '',
          });
        }
      });
    },
    () => {
      // Ignore snapshot listener error if offline or signed out
    }
  );

  return unsub;
}

/**
 * Fetches all real Wird collaborative groups from Firestore /groups
 */
export async function fetchAdminWirdGroups(): Promise<AdminGroupSummary[]> {
  try {
    const snap = await getDocs(query(collection(db, 'groups'), limit(60)));
    const groups: AdminGroupSummary[] = [];
    snap.forEach((d) => {
      const data = d.data();
      groups.push({
        id: d.id,
        groupName: data.groupName || 'مجموعة بدون اسم',
        joinCode: data.joinCode || data.groupCode || '—',
        adminId: data.adminId || '',
        adminName: data.adminName || 'غير محدد',
        description: data.description || '',
        planType: data.planType || 'khatma',
        totalPages: Number(data.totalPages) || 604,
        targetDays: Number(data.targetDays) || 30,
        currentDay: Number(data.currentDay) || 1,
        isPublic: data.isPublic !== false,
        isActive: data.isActive !== false,
        createdAt: data.createdAt || '',
      });
    });
    groups.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    return groups;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'groups');
  }
}

/**
 * Inspects real members and messages of a Wird group from Firestore
 */
export async function inspectAdminGroupSubcollections(groupId: string): Promise<{
  members: Array<{ userId: string; displayName: string; role: string; dailyProgress: number; joinedAt: string }>;
  messages: Array<{ id: string; userId: string; userName: string; message: string; category: string; createdAt: string }>;
}> {
  try {
    const [membersSnap, messagesSnap] = await Promise.all([
      getDocs(collection(db, 'groups', groupId, 'members')),
      getDocs(collection(db, 'groups', groupId, 'messages')),
    ]);

    const members: Array<{ userId: string; displayName: string; role: string; dailyProgress: number; joinedAt: string }> = [];
    membersSnap.forEach((d) => {
      const data = d.data();
      members.push({
        userId: data.userId || d.id,
        displayName: data.displayName || 'عضو',
        role: data.role || 'member',
        dailyProgress: Number(data.dailyProgress) || 0,
        joinedAt: data.joinedAt || '',
      });
    });

    const messages: Array<{ id: string; userId: string; userName: string; message: string; category: string; createdAt: string }> = [];
    messagesSnap.forEach((d) => {
      const data = d.data();
      messages.push({
        id: d.id,
        userId: data.userId || '',
        userName: data.userName || 'عضو',
        message: data.message || '',
        category: data.category || 'general',
        createdAt: data.createdAt || '',
      });
    });
    messages.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));

    return { members, messages };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `groups/${groupId}`);
  }
}

/**
 * Toggles a Wird group's active status in Firestore
 */
export async function toggleWirdGroupStatusByAdmin(
  groupId: string,
  groupName: string,
  isActive: boolean
): Promise<void> {
  const path = `groups/${groupId}`;
  try {
    await updateDoc(doc(db, 'groups', groupId), {
      isActive,
    });
    await recordAdminAuditLog({
      actionType: isActive ? 'activate_group' : 'suspend_group',
      targetType: 'group',
      targetId: groupId,
      details: `${isActive ? 'إعادة تفعيل' : 'إيقاف'} مجموعة الورد "${groupName}" (${groupId})`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Deletes an offending message inside a Wird group wall
 */
export async function deleteWirdGroupMessageByAdmin(
  groupId: string,
  messageId: string,
  previewText: string
): Promise<void> {
  const path = `groups/${groupId}/messages/${messageId}`;
  try {
    await deleteDoc(doc(db, 'groups', groupId, 'messages', messageId));
    await recordAdminAuditLog({
      actionType: 'delete_group_message',
      targetType: 'group',
      targetId: groupId,
      details: `حذف رسالة من حائط المجموعة (${groupId}): "${previewText.slice(0, 80)}"`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Permanently deletes a Wird group and all its subcollections from Firestore
 */
export async function deleteWirdGroupByAdmin(groupId: string, groupName: string): Promise<void> {
  const path = `groups/${groupId}`;
  try {
    const subcollections = [
      'members',
      'distribution',
      'dailyProgress',
      'messages',
      'activityLog',
      'joinRequests',
    ];
    for (const sub of subcollections) {
      const snap = await getDocs(collection(db, 'groups', groupId, sub));
      if (!snap.empty) {
        const batch = writeBatch(db);
        snap.forEach((d) => batch.delete(d.ref));
        await batch.commit();
      }
    }

    await deleteDoc(doc(db, 'groups', groupId));

    await recordAdminAuditLog({
      actionType: 'delete_group',
      targetType: 'group',
      targetId: groupId,
      details: `حذف مجموعة الورد "${groupName}" (${groupId}) وجميع بياناتها الفرعية نهائياً`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

function mapSnapshotDocToReportRecord(docId: string, data: DocumentData): UserReportRecord {
  return {
    id: docId,
    userId: data.userId ?? (data.reporterUid && data.reporterUid !== 'guest' ? data.reporterUid : null),
    reporterUid: data.reporterUid || 'guest',
    reporterName: data.reporterName || 'مستخدم رِفْق',
    reporterEmail: data.reporterEmail || null,
    category: data.category || 'other',
    issueType: data.issueType || null,
    subject: data.subject || '',
    description: data.description || '',
    targetId: data.targetId || null,
    screenshotDataUrl: data.screenshotDataUrl || null,
    deviceInfo: data.deviceInfo || null,
    status: data.status || 'open',
    adminResponse: data.adminResponse || null,
    resolvedByUid: data.resolvedByUid || null,
    createdAt: data.createdAt || '',
    updatedAt: data.updatedAt || '',
  };
}

/**
 * Submits a real user report / feature suggestion / support ticket to /reports/{reportId}
 */
export async function submitUserReportToFirestore(params: {
  category: ReportCategory;
  issueType?: string;
  subject: string;
  description: string;
  targetId?: string;
  screenshotDataUrl?: string | null;
  deviceInfo?: SafeDeviceDiagnosticInfo | null;
  reporterNameOverride?: string;
}): Promise<UserReportRecord> {
  const currentUser = auth.currentUser;

  const cleanSubject = params.subject.trim();
  const cleanDesc = params.description.trim();
  if (cleanSubject.length < 3 || cleanDesc.length < 5) {
    throw new Error('يرجى كتابة عنوان واضح ووصف مفصل قبل الإرسال.');
  }

  const reportId = generateCleanDocId(params.category === 'suggestion' ? 'sug' : 'rep');
  const nowIso = new Date().toISOString();
  const path = `reports/${reportId}`;

  const reporterUid = currentUser ? currentUser.uid : 'guest';
  const userId = currentUser ? currentUser.uid : null;
  const reporterName = currentUser
    ? currentUser.displayName || (currentUser.email ? currentUser.email.split('@')[0] : 'مستخدم رِفْق')
    : params.reporterNameOverride?.trim() || 'زائر تطبيق رِفْق';

  const payload = {
    userId,
    reporterUid,
    reporterName,
    reporterEmail: currentUser?.email || null,
    category: params.category,
    issueType: params.issueType?.trim() || null,
    subject: cleanSubject.slice(0, 200),
    description: cleanDesc.slice(0, 4000),
    targetId: params.targetId?.trim() || null,
    screenshotDataUrl: params.screenshotDataUrl || null,
    deviceInfo: params.deviceInfo || null,
    status: 'open' as const,
    adminResponse: null,
    resolvedByUid: null,
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  try {
    await setDoc(doc(db, 'reports', reportId), payload);
    if (!currentUser) {
      saveGuestSubmittedReportId(reportId);
    }
    if (currentUser) {
      try {
        await setDoc(
          doc(db, 'system_stats', 'global'),
          {
            openReportsCount: increment(1),
            updatedAt: nowIso,
          },
          { merge: true }
        );
      } catch {
        // Ignore counter error if non-admin
      }
    }

    return {
      id: reportId,
      ...payload,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Fetches reports submitted by the currently signed-in user (and any guest reports submitted on this device)
 */
export async function fetchUserOwnReports(uid?: string | null): Promise<UserReportRecord[]> {
  try {
    const recordsMap = new Map<string, UserReportRecord>();

    if (uid) {
      const q = query(collection(db, 'reports'), where('reporterUid', '==', uid), limit(35));
      const snap = await getDocs(q);
      snap.forEach((d) => {
        recordsMap.set(d.id, mapSnapshotDocToReportRecord(d.id, d.data()));
      });
    }

    const guestIds = getGuestSubmittedReportIds();
    for (const gId of guestIds) {
      if (!recordsMap.has(gId)) {
        try {
          const docSnap = await getDoc(doc(db, 'reports', gId));
          if (docSnap.exists()) {
            recordsMap.set(docSnap.id, mapSnapshotDocToReportRecord(docSnap.id, docSnap.data()));
          }
        } catch {
          // Ignore individual permission error if any
        }
      }
    }

    const list = Array.from(recordsMap.values());
    list.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'reports');
  }
}

/**
 * Subscribes in real-time to a signed-in user's own reports so status updates & admin replies appear immediately
 */
export function subscribeToUserOwnReports(
  uid: string | null | undefined,
  onUpdate: (reports: UserReportRecord[]) => void
): () => void {
  if (!uid) {
    fetchUserOwnReports(null)
      .then(onUpdate)
      .catch(() => onUpdate([]));
    return () => {};
  }

  const q = query(collection(db, 'reports'), where('reporterUid', '==', uid), limit(35));
  const unsub = onSnapshot(
    q,
    async (snap) => {
      const recordsMap = new Map<string, UserReportRecord>();
      snap.forEach((d) => {
        recordsMap.set(d.id, mapSnapshotDocToReportRecord(d.id, d.data()));
      });

      const guestIds = getGuestSubmittedReportIds();
      for (const gId of guestIds) {
        if (!recordsMap.has(gId)) {
          try {
            const docSnap = await getDoc(doc(db, 'reports', gId));
            if (docSnap.exists()) {
              recordsMap.set(docSnap.id, mapSnapshotDocToReportRecord(docSnap.id, docSnap.data()));
            }
          } catch {
            // Ignore
          }
        }
      }

      const list = Array.from(recordsMap.values());
      list.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      onUpdate(list);
    },
    () => {
      // Ignore snapshot listener error if offline or signed out
    }
  );

  return unsub;
}

/**
 * Fetches all user reports for the Admin Dashboard
 */
export async function fetchAdminReports(): Promise<UserReportRecord[]> {
  try {
    const q = query(collection(db, 'reports'), limit(80));
    const snap = await getDocs(q);
    const list: UserReportRecord[] = [];
    snap.forEach((d) => {
      list.push(mapSnapshotDocToReportRecord(d.id, d.data()));
    });
    list.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'reports');
  }
}

/**
 * Updates a report's status and official admin response in Firestore, and notifies the user if registered
 */
export async function updateReportStatusByAdmin(params: {
  reportId: string;
  subject: string;
  newStatus: ReportStatus;
  adminResponse: string;
  reporterUid?: string | null;
  category?: ReportCategory;
}): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('يجب تسجيل الدخول كمسؤول لتحديث حالة البلاغ.');
  }

  const nowIso = new Date().toISOString();
  const path = `reports/${params.reportId}`;
  const statusLabel = getReportStatusLabel(params.newStatus);

  try {
    await updateDoc(doc(db, 'reports', params.reportId), {
      status: params.newStatus,
      adminResponse: params.adminResponse.trim() || null,
      resolvedByUid: currentUser.uid,
      updatedAt: nowIso,
    });

    await recordAdminAuditLog({
      actionType: `report_status_${params.newStatus}`,
      targetType: 'report',
      targetId: params.reportId,
      details: `تحديث حالة "${params.subject}" إلى (${statusLabel})${
        params.adminResponse.trim() ? ` مع رد إداري` : ''
      }`,
    });

    // Send real-time targeted notification to the reporter if they have a registered user UID
    if (params.reporterUid && params.reporterUid !== 'guest') {
      try {
        const isSuggestion = params.category === 'suggestion';
        const notifTitle = isSuggestion
          ? `تحديث بخصوص اقتراحك: ${params.subject}`.slice(0, 190)
          : `تحديث حالة بلاغك: ${params.subject}`.slice(0, 190);
        const replySnippet = params.adminResponse.trim()
          ? `\nرد فريق رِفْق: ${params.adminResponse.trim()}`
          : '';
        const notifMessage = `تم تحديث الحالة إلى «${statusLabel}».${replySnippet}`.slice(0, 1900);

        await sendAdminBroadcastNotification({
          title: notifTitle,
          message: notifMessage,
          type: params.newStatus === 'resolved' ? 'milestone' : 'general',
          targetType: 'user',
          targetUid: params.reporterUid,
          actionScreen: 'credits',
        });
      } catch {
        // Non-blocking if notification creation fails
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

/**
 * Deletes a report from /reports/{reportId}
 */
export async function deleteReportByAdmin(reportId: string, subject: string): Promise<void> {
  const path = `reports/${reportId}`;
  try {
    await deleteDoc(doc(db, 'reports', reportId));
    await recordAdminAuditLog({
      actionType: 'delete_report',
      targetType: 'report',
      targetId: reportId,
      details: `حذف البلاغ "${subject}" (${reportId})`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Fetches immutable admin audit logs from /admin_audit_logs
 */
export async function fetchAdminAuditLogs(maxItems = 50): Promise<AdminAuditLogRecord[]> {
  try {
    const q = query(
      collection(db, 'admin_audit_logs'),
      orderBy('createdAt', 'desc'),
      limit(maxItems)
    );
    const snap = await getDocs(q);
    const logs: AdminAuditLogRecord[] = [];
    snap.forEach((d) => {
      const data = d.data();
      logs.push({
        id: d.id,
        adminUid: data.adminUid || '',
        adminEmail: data.adminEmail || null,
        actionType: data.actionType || '',
        targetType: data.targetType || 'system',
        targetId: data.targetId || '',
        details: data.details || '',
        createdAt: data.createdAt || '',
      });
    });
    return logs;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'admin_audit_logs');
  }
}

/**
 * Fetches global system configuration (/system_config/app_settings)
 */
export async function fetchGlobalSystemConfig(): Promise<SystemConfigRecord | null> {
  try {
    const snap = await getDoc(doc(db, 'system_config', 'app_settings'));
    if (!snap.exists()) {
      return {
        announcementEnabled: false,
        announcementTitle: '',
        announcementMessage: '',
        announcementType: 'info',
      };
    }
    const data = snap.data();
    return {
      announcementEnabled: Boolean(data.announcementEnabled),
      announcementTitle: data.announcementTitle || '',
      announcementMessage: data.announcementMessage || '',
      announcementType:
        data.announcementType === 'warning' || data.announcementType === 'celebration'
          ? data.announcementType
          : 'info',
      updatedByUid: data.updatedByUid,
      updatedAt: data.updatedAt,
    };
  } catch {
    return null;
  }
}

/**
 * Updates global system configuration (/system_config/app_settings)
 */
export async function updateGlobalSystemConfigByAdmin(
  config: SystemConfigRecord
): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('يجب تسجيل الدخول كمسؤول لحفظ إعدادات النظام.');
  }

  const nowIso = new Date().toISOString();
  const path = 'system_config/app_settings';

  try {
    await setDoc(
      doc(db, 'system_config', 'app_settings'),
      {
        announcementEnabled: Boolean(config.announcementEnabled),
        announcementTitle: config.announcementTitle.trim().slice(0, 150),
        announcementMessage: config.announcementMessage.trim().slice(0, 1000),
        announcementType: config.announcementType,
        updatedByUid: currentUser.uid,
        updatedAt: nowIso,
      },
      { merge: true }
    );

    await recordAdminAuditLog({
      actionType: 'update_system_config',
      targetType: 'system',
      targetId: 'app_settings',
      details: `${
        config.announcementEnabled ? 'تفعيل' : 'إيقاف'
      } التنبيه العام للتطبيق: "${config.announcementTitle.trim() || 'بدون عنوان'}"`,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
