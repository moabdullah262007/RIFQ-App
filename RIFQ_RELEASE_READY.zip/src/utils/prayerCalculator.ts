import {
  Coordinates,
  CalculationMethod,
  CalculationParameters,
  PrayerTimes,
  SunnahTimes,
  Madhab,
  Qibla
} from 'adhan';
import { CalculationMethodKey, MadhabKey, PrayerKey, PrayerSettings } from '../types';

export interface CalculatedPrayerData {
  times: Record<PrayerKey, Date>;
  currentPrayer: PrayerKey | null;
  nextPrayer: PrayerKey;
  nextPrayerTime: Date;
  timeRemainingMs: number;
  timeRemainingText: string;
  sunnahTimes: {
    middleOfTheNight: Date;
    lastThirdOfTheNight: Date; // الثلث الأخير من الليل
  };
  suhurTime: Date; // 20 minutes before Fajr
  iftarTime: Date; // Maghrib time
  duhaStart: Date; // 15 mins after sunrise
  duhaEnd: Date; // 12 mins before dhuhr
  isDuhaTime: boolean;
  isProhibitedPrayerTime: boolean;
  prohibitedReason?: string;
  daylightProgressPercent: number; // 0..100% during day, or night index
  isDaytime: boolean;
  qiblaBearing: number; // 0..360 degrees
  distanceToKaabaKm: number;
  hijriDate: {
    day: number;
    month: number;
    year: number;
    dayName: string;
    monthName: string;
    formatted: string;
  };
}

export function getCalculationParameters(
  method: CalculationMethodKey,
  madhab: MadhabKey,
  offsets?: Record<PrayerKey, number>
): CalculationParameters {
  let params: CalculationParameters;

  switch (method) {
    case 'Egyptian':
      params = CalculationMethod.Egyptian();
      break;
    case 'UmmAlQura':
      params = CalculationMethod.UmmAlQura();
      break;
    case 'MuslimWorldLeague':
      params = CalculationMethod.MuslimWorldLeague();
      break;
    case 'Karachi':
      params = CalculationMethod.Karachi();
      break;
    case 'NorthAmerica':
      params = CalculationMethod.NorthAmerica();
      break;
    case 'Dubai':
      params = CalculationMethod.Dubai();
      break;
    case 'Qatar':
      params = CalculationMethod.Qatar();
      break;
    case 'Kuwait':
      params = CalculationMethod.Kuwait();
      break;
    case 'Turkey':
      params = CalculationMethod.Turkey();
      break;
    case 'Singapore':
      params = CalculationMethod.Singapore();
      break;
    case 'Custom':
    default:
      params = CalculationMethod.Other();
      break;
  }

  // Set Asr juristic calculation method (Hanafi vs Majority)
  params.madhab = madhab === 'hanafi' ? Madhab.Hanafi : Madhab.Shafi;

  // Apply minute adjustments if specified
  if (offsets) {
    params.adjustments.fajr = offsets.fajr || 0;
    params.adjustments.sunrise = offsets.sunrise || 0;
    params.adjustments.dhuhr = offsets.dhuhr || 0;
    params.adjustments.asr = offsets.asr || 0;
    params.adjustments.maghrib = offsets.maghrib || 0;
    params.adjustments.isha = offsets.isha || 0;
  }

  return params;
}

export const KAABA_COORDINATES = {
  latitude: 21.4225,
  longitude: 39.8262
};

// Haversine formula to compute great circle distance in kilometers
export function calculateDistanceToKaaba(lat: number, lon: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((KAABA_COORDINATES.latitude - lat) * Math.PI) / 180;
  const dLon = ((KAABA_COORDINATES.longitude - lon) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat * Math.PI) / 180) *
      Math.cos((KAABA_COORDINATES.latitude * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Format milliseconds remaining into Arabic text
export function formatRemainingTime(ms: number): {
  hours: number;
  minutes: number;
  seconds: number;
  text: string;
} {
  if (ms <= 0) {
    return { hours: 0, minutes: 0, seconds: 0, text: 'حان الآن' };
  }

  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  let text = 'باقي ';
  if (hours > 0) {
    text += `${hours} ${hours === 1 ? 'ساعة' : hours === 2 ? 'ساعتان' : hours <= 10 ? 'ساعات' : 'ساعة'} و `;
  }
  text += `${minutes} ${minutes === 1 ? 'دقيقة' : minutes === 2 ? 'دقيقتان' : minutes <= 10 ? 'دقائق' : 'دقيقة'}`;
  text += ` و ${seconds} ثانية`;

  return { hours, minutes, seconds, text };
}

// Convert Date to 12h or 24h formatted string
export function formatPrayerTime(date: Date, format: '12h' | '24h' = '12h'): string {
  if (!date || isNaN(date.getTime())) return '--:--';

  let hours = date.getHours();
  const minutes = date.getMinutes().toString().padStart(2, '0');

  if (format === '24h') {
    return `${hours.toString().padStart(2, '0')}:${minutes}`;
  }

  const isPM = hours >= 12;
  hours = hours % 12;
  if (hours === 0) hours = 12;

  const period = isPM ? 'م' : 'ص';
  return `${hours}:${minutes} ${period}`;
}

// Get accurate Hijri date with optional manual day adjustment
export function getHijriDate(date: Date, adjustmentDays: number = 0) {
  const adjustedDate = new Date(date.getTime() + adjustmentDays * 86400000);

  try {
    const formatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      weekday: 'long'
    });

    const parts = formatter.formatToParts(adjustedDate);
    let day = 1;
    let monthName = '';
    let year = 1447;
    let dayName = '';

    parts.forEach((p) => {
      if (p.type === 'day') {
        const parsed = parseInt(p.value.replace(/[^\d]/g, ''), 10);
        if (!isNaN(parsed)) day = parsed;
      }
      if (p.type === 'month') monthName = p.value;
      if (p.type === 'year') {
        const parsed = parseInt(p.value.replace(/[^\d]/g, ''), 10);
        if (!isNaN(parsed)) year = parsed;
      }
      if (p.type === 'weekday') dayName = p.value;
    });

    // Approximate hijri month index 1..12
    const hijriMonths = [
      'محرم',
      'صفر',
      'ربيع الأول',
      'ربيع الآخر',
      'جمادى الأولى',
      'جمادى الآخرة',
      'رجب',
      'شعبان',
      'رمضان',
      'شوال',
      'ذو القعدة',
      'ذو الحجة'
    ];
    let month = 1;
    const foundIdx = hijriMonths.findIndex((m) => monthName.includes(m));
    if (foundIdx !== -1) {
      month = foundIdx + 1;
    }

    const formatted = `${dayName}، ${day} ${monthName} ${year} هـ`;

    return {
      day,
      month,
      year,
      dayName,
      monthName,
      formatted
    };
  } catch {
    // Fallback if Intl is unavailable
    return {
      day: 15,
      month: 9,
      year: 1447,
      dayName: 'اليوم المبارك',
      monthName: 'رمضان',
      formatted: '١٥ رمضان ١٤٤٧ هـ'
    };
  }
}

// Master calculation function
export function calculateAllPrayerData(
  latitude: number,
  longitude: number,
  currentDate: Date = new Date(),
  settings: PrayerSettings
): CalculatedPrayerData {
  const coords = new Coordinates(latitude, longitude);
  const params = getCalculationParameters(settings.method, settings.madhab, settings.manualOffsets);

  const prayerTimes = new PrayerTimes(coords, currentDate, params);
  const sunnahTimes = new SunnahTimes(prayerTimes);

  const times: Record<PrayerKey, Date> = {
    fajr: prayerTimes.fajr,
    sunrise: prayerTimes.sunrise,
    dhuhr: prayerTimes.dhuhr,
    asr: prayerTimes.asr,
    maghrib: prayerTimes.maghrib,
    isha: prayerTimes.isha
  };

  // Suhur time: 20 minutes before Fajr
  const suhurTime = new Date(times.fajr.getTime() - 20 * 60 * 1000);
  const iftarTime = times.maghrib;

  // Determine current and next prayer
  const nowMs = currentDate.getTime();
  let currentPrayer: PrayerKey | null = null;
  let nextPrayer: PrayerKey = 'fajr';
  let nextPrayerTime: Date = times.fajr;

  const sequence: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

  if (nowMs < times.fajr.getTime()) {
    currentPrayer = null; // Still in night/Qiyam
    nextPrayer = 'fajr';
    nextPrayerTime = times.fajr;
  } else if (nowMs < times.sunrise.getTime()) {
    currentPrayer = 'fajr';
    nextPrayer = 'sunrise';
    nextPrayerTime = times.sunrise;
  } else if (nowMs < times.dhuhr.getTime()) {
    currentPrayer = 'sunrise';
    nextPrayer = 'dhuhr';
    nextPrayerTime = times.dhuhr;
  } else if (nowMs < times.asr.getTime()) {
    currentPrayer = 'dhuhr';
    nextPrayer = 'asr';
    nextPrayerTime = times.asr;
  } else if (nowMs < times.maghrib.getTime()) {
    currentPrayer = 'asr';
    nextPrayer = 'maghrib';
    nextPrayerTime = times.maghrib;
  } else if (nowMs < times.isha.getTime()) {
    currentPrayer = 'maghrib';
    nextPrayer = 'isha';
    nextPrayerTime = times.isha;
  } else {
    // After Isha: Next prayer is tomorrow's Fajr
    currentPrayer = 'isha';
    nextPrayer = 'fajr';
    const tomorrow = new Date(currentDate.getTime() + 24 * 60 * 60 * 1000);
    const tomorrowPrayerTimes = new PrayerTimes(coords, tomorrow, params);
    nextPrayerTime = tomorrowPrayerTimes.fajr;
  }

  // Duha times & Prohibited prayer times
  const duhaStart = new Date(times.sunrise.getTime() + 15 * 60 * 1000);
  const duhaEnd = new Date(times.dhuhr.getTime() - 12 * 60 * 1000);
  const isDuhaTime = nowMs >= duhaStart.getTime() && nowMs <= duhaEnd.getTime();

  let isProhibitedPrayerTime = false;
  let prohibitedReason: string | undefined;

  if (nowMs >= times.fajr.getTime() && nowMs < duhaStart.getTime()) {
    isProhibitedPrayerTime = true;
    prohibitedReason = 'من بعد صلاة الفجر حتى طلوع الشمس وارتفاعها قيد رمح (نحو ١٥ دقيقة بعد الشروق)';
  } else if (nowMs > duhaEnd.getTime() && nowMs < times.dhuhr.getTime()) {
    isProhibitedPrayerTime = true;
    prohibitedReason = 'عند استواء الشمس في كبد السماء قبيل أذان الظهر بنحو ١٢ دقيقة';
  } else if (nowMs >= times.asr.getTime() && nowMs < times.maghrib.getTime()) {
    isProhibitedPrayerTime = true;
    prohibitedReason = 'من بعد صلاة العصر حتى مغيب كامل قرص الشمس';
  }

  // Daylight & Sun progress percentage
  const isDaytime = nowMs >= times.sunrise.getTime() && nowMs <= times.maghrib.getTime();
  let daylightProgressPercent = 0;
  if (isDaytime) {
    const daySpan = times.maghrib.getTime() - times.sunrise.getTime();
    const elapsed = nowMs - times.sunrise.getTime();
    daylightProgressPercent = Math.min(100, Math.max(0, Math.round((elapsed / daySpan) * 100)));
  } else {
    // Night progress (from Maghrib to next Sunrise)
    const nightSpan = 12 * 3600 * 1000;
    const elapsed = nowMs > times.maghrib.getTime() ? nowMs - times.maghrib.getTime() : nowMs + (24 * 3600 * 1000 - times.maghrib.getTime());
    daylightProgressPercent = Math.min(100, Math.max(0, Math.round((elapsed / nightSpan) * 100)));
  }

  const timeRemainingMs = Math.max(0, nextPrayerTime.getTime() - nowMs);
  const remainingFormatted = formatRemainingTime(timeRemainingMs);

  const qiblaBearing = Math.round(Qibla(coords));
  const distanceToKaabaKm = calculateDistanceToKaaba(latitude, longitude);
  const hijriDate = getHijriDate(currentDate, settings.hijriAdjustment);

  return {
    times,
    currentPrayer,
    nextPrayer,
    nextPrayerTime,
    timeRemainingMs,
    timeRemainingText: remainingFormatted.text,
    sunnahTimes: {
      middleOfTheNight: sunnahTimes.middleOfTheNight,
      lastThirdOfTheNight: sunnahTimes.lastThirdOfTheNight
    },
    suhurTime,
    iftarTime,
    duhaStart,
    duhaEnd,
    isDuhaTime,
    isProhibitedPrayerTime,
    prohibitedReason,
    daylightProgressPercent,
    isDaytime,
    qiblaBearing,
    distanceToKaabaKm,
    hijriDate
  };
}

export interface DailyPrayerRow {
  date: Date;
  dayNum: number;
  dayName: string;
  gregorianFormatted: string;
  hijriFormatted: string;
  fajr: Date;
  sunrise: Date;
  dhuhr: Date;
  asr: Date;
  maghrib: Date;
  isha: Date;
  suhur: Date;
  isToday: boolean;
}

export function calculateMonthPrayerTimes(
  latitude: number,
  longitude: number,
  year: number,
  monthIndex: number,
  settings: PrayerSettings
): DailyPrayerRow[] {
  const coords = new Coordinates(latitude, longitude);
  const params = getCalculationParameters(settings.method, settings.madhab, settings.manualOffsets);
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
  const today = new Date();
  const isCurrentMonthYear = today.getFullYear() === year && today.getMonth() === monthIndex;

  const rows: DailyPrayerRow[] = [];

  for (let d = 1; d <= daysInMonth; d++) {
    const dayDate = new Date(year, monthIndex, d, 12, 0, 0);
    const pTimes = new PrayerTimes(coords, dayDate, params);
    const hijri = getHijriDate(dayDate, settings.hijriAdjustment);
    const isToday = isCurrentMonthYear && today.getDate() === d;

    rows.push({
      date: dayDate,
      dayNum: d,
      dayName: hijri.dayName,
      gregorianFormatted: `${d} / ${monthIndex + 1} / ${year}`,
      hijriFormatted: `${hijri.day} ${hijri.monthName}`,
      fajr: pTimes.fajr,
      sunrise: pTimes.sunrise,
      dhuhr: pTimes.dhuhr,
      asr: pTimes.asr,
      maghrib: pTimes.maghrib,
      isha: pTimes.isha,
      suhur: new Date(pTimes.fajr.getTime() - 20 * 60 * 1000),
      isToday
    });
  }

  return rows;
}
