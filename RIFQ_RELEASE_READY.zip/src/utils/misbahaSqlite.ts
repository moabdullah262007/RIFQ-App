// ═══════════════════════════════════════════════════════════════════════════
// إدارة قاعدة البيانات المحلية (SQLite / IndexedDB + LocalStorage) لقسم «المسبحة المركزية»
// الجداول الخمسة المعتمدة:
// 1. misbaha_sessions (id | dhikr | count | target | duration | created_at)
// 2. custom_adhkar    (id | text | target | list_name | usage_count | created_at)
// 3. daily_stats      (id | date | total_count | sessions_count | cycles_count | dhikr_counts_json)
// 4. settings         (id | daily_target | weekly_target | monthly_target | sound | sound_volume | vibration | theme | dark_mode | current_dhikr | current_count | current_target | total_cycles)
// 5. streak           (id | current_streak | longest_streak | last_date)
// ═══════════════════════════════════════════════════════════════════════════

import { RosaryThemeId } from '../types';
import { getTodayDateString, loadHistory, saveHistory, getTodayRecord } from './storage';

export const MISBAHA_SQLITE_DDL_SCHEMA = `-- 1. جدول جلسات التسبيح (misbaha_sessions)
CREATE TABLE IF NOT EXISTS misbaha_sessions (
  id TEXT PRIMARY KEY,
  dhikr TEXT NOT NULL,
  count INTEGER NOT NULL,
  target INTEGER NOT NULL,
  duration INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_misbaha_sessions_created_at ON misbaha_sessions(created_at DESC);

-- 2. جدول الأذكار المخصصة (custom_adhkar)
CREATE TABLE IF NOT EXISTS custom_adhkar (
  id TEXT PRIMARY KEY,
  text TEXT NOT NULL,
  target INTEGER NOT NULL DEFAULT 100,
  list_name TEXT NOT NULL DEFAULT 'أذكار عامة',
  usage_count INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_custom_adhkar_list ON custom_adhkar(list_name);

-- 3. جدول الإحصائيات اليومية (daily_stats)
CREATE TABLE IF NOT EXISTS daily_stats (
  id TEXT PRIMARY KEY,
  date TEXT NOT NULL UNIQUE,
  total_count INTEGER NOT NULL DEFAULT 0,
  sessions_count INTEGER NOT NULL DEFAULT 0,
  cycles_count INTEGER NOT NULL DEFAULT 0,
  dhikr_counts_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_daily_stats_date ON daily_stats(date DESC);

-- 4. جدول إعدادات المسبحة والأهداف (settings)
CREATE TABLE IF NOT EXISTS settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  daily_target INTEGER NOT NULL DEFAULT 100,
  weekly_target INTEGER NOT NULL DEFAULT 3000,
  monthly_target INTEGER NOT NULL DEFAULT 15000,
  sound TEXT NOT NULL DEFAULT 'wood',
  sound_volume INTEGER NOT NULL DEFAULT 75,
  vibration TEXT NOT NULL DEFAULT 'medium',
  theme TEXT NOT NULL DEFAULT 'gold',
  dark_mode INTEGER NOT NULL DEFAULT 0,
  current_dhikr TEXT NOT NULL DEFAULT 'سُبْحَانَ اللَّهِ',
  current_count INTEGER NOT NULL DEFAULT 0,
  current_target INTEGER NOT NULL DEFAULT 100,
  total_cycles INTEGER NOT NULL DEFAULT 0
);

-- 5. جدول السلسلة المتتالية (streak)
CREATE TABLE IF NOT EXISTS streak (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  current_streak INTEGER NOT NULL DEFAULT 0,
  longest_streak INTEGER NOT NULL DEFAULT 0,
  last_date TEXT NOT NULL DEFAULT ''
);`;

export interface MisbahaSessionSqliteRow {
  id: string;
  dhikr: string;
  count: number;
  target: number;
  duration: number; // in seconds
  created_at: string; // ISO string
}

export type WirdCategoryType = 'daily' | 'special_occasion' | 'custom';

export interface CustomAdhkarSqliteRow {
  id: string;
  text: string;
  target: number;
  list_name: string;
  usage_count: number;
  created_at: string;
  wird_type?: WirdCategoryType;
  notes?: string;
}

export interface DailyStatsSqliteRow {
  id: string;
  date: string; // YYYY-MM-DD
  total_count: number;
  sessions_count: number;
  cycles_count: number;
  dhikr_counts_json: string;
}

export type MisbahaSoundOption = 'wood' | 'water' | 'golden_bell' | 'silent';
export type MisbahaVibrationOption = 'light' | 'medium' | 'strong' | 'none';

export interface MisbahaSettingsSqliteRow {
  id: number;
  daily_target: number; // 100 | 500 | 1000 | 0 (0 = مفتوح)
  weekly_target: number;
  monthly_target: number;
  sound: MisbahaSoundOption;
  sound_volume: number; // 0..100
  vibration: MisbahaVibrationOption;
  theme: RosaryThemeId;
  dark_mode: number; // 0 | 1
  current_dhikr: string;
  current_count: number;
  current_target: number; // 100 | 33 | 99 | 500 | 1000 | 0
  total_cycles: number;
}

export interface MisbahaStreakSqliteRow {
  id: number;
  current_streak: number;
  longest_streak: number;
  last_date: string;
}

export interface MisbahaTextAchievement {
  id: string;
  title: string;
  description: string;
  current: number;
  target: number;
  completed: boolean;
  progressPercent: number;
}

export interface WeeklyChartDayPoint {
  date: string;
  dayNameAr: string;
  shortDate: string;
  count: number;
  sessionsCount: number;
  isToday: boolean;
}

export interface MostUsedDhikrStat {
  dhikr: string;
  shortDhikr: string;
  count: number;
  percentage: number;
}

export interface DailyHourlyChartPoint {
  hour: number;
  label: string;
  periodAr: string;
  count: number;
}

export interface FourWeeksChartPoint {
  weekLabel: string;
  rangeLabel: string;
  count: number;
  sessionsCount: number;
  activeDays: number;
}

export const ADHKAR_LIST_CATEGORIES: string[] = [
  'أذكار عامة',
  'التسبيح والتحميد',
  'الاستغفار والتوبة',
  'الصلاة على النبي ﷺ',
  'أذكار الصباح والمساء',
  'أدعية قرآنية ونبوية',
];

export interface WirdCategoryMeta {
  id: string;
  name: string;
  type: WirdCategoryType;
  icon: string;
  description: string;
}

export const PREDEFINED_WIRD_CATEGORIES: WirdCategoryMeta[] = [
  // أوراد يومية (Daily Wirds)
  {
    id: 'daily_general',
    name: 'ورد التسبيح اليومي العام',
    type: 'daily',
    icon: '☀️',
    description: 'الأذكار والتحميدات اليومية الراتبة'
  },
  {
    id: 'daily_morning_evening',
    name: 'ورد الصباح والمساء',
    type: 'daily',
    icon: '🌅',
    description: 'أذكار وأوراد البكور والأصيل'
  },
  {
    id: 'daily_post_prayer',
    name: 'ورد ما بعد الصلوات المكتوبة',
    type: 'daily',
    icon: '🕌',
    description: 'التسبيحات والتعقيبات دبر الصلوات الخمس'
  },
  {
    id: 'daily_night_istighfar',
    name: 'ورد قيام الليل والاستغفار بالأسحار',
    type: 'daily',
    icon: '🌙',
    description: 'أوراد الثلث الأخير من الليل والمستغفرين بالأسحار'
  },
  {
    id: 'daily_sleep',
    name: 'ورد ما قبل النوم وحصن الفراش',
    type: 'daily',
    icon: '🛏️',
    description: 'أذكار النوم والسكينة والتحصين'
  },

  // أوراد مناسبات خاصة (Special Occasion Wirds)
  {
    id: 'occasion_friday',
    name: 'ورد يوم الجمعة المباركة',
    type: 'special_occasion',
    icon: '✨',
    description: 'الصلاة على النبي ﷺ والتهليل في يوم الجمعة'
  },
  {
    id: 'occasion_ramadan',
    name: 'ورد شهر رمضان وليالي القدر',
    type: 'special_occasion',
    icon: '🏮',
    description: 'الأوراد الرمضانية المباركة ودعاء العفو'
  },
  {
    id: 'occasion_distress',
    name: 'ورد تفريج الكرب والهم والشدائد',
    type: 'special_occasion',
    icon: '🤲',
    description: 'أدعية تفريج الكرب والحوقلة ودعوة ذي النون'
  },
  {
    id: 'occasion_arafah_ashura',
    name: 'ورد يوم عرفة وعاشوراء والمواسم',
    type: 'special_occasion',
    icon: '🕋',
    description: 'خير الدعاء في خير أيام العام والأشهر الحرم'
  },
  {
    id: 'occasion_travel',
    name: 'ورد السفر والحفظ والاستخارة',
    type: 'special_occasion',
    icon: '🧭',
    description: 'أذكار الركوب، السفر، وحفظ الأهل والنفس'
  },
];

export const LS_CUSTOM_WIRD_CATEGORIES_KEY = 'rifq_custom_wird_categories_v1';

export function loadUserCustomWirdCategories(): string[] {
  try {
    const raw = localStorage.getItem(LS_CUSTOM_WIRD_CATEGORIES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addUserCustomWirdCategory(name: string): string[] {
  const clean = name.trim();
  if (!clean) return loadUserCustomWirdCategories();
  const current = loadUserCustomWirdCategories();
  if (!current.includes(clean)) {
    const next = [...current, clean];
    try {
      localStorage.setItem(LS_CUSTOM_WIRD_CATEGORIES_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
    return next;
  }
  return current;
}

export function deleteUserCustomWirdCategory(name: string): string[] {
  const current = loadUserCustomWirdCategories();
  const next = current.filter((c) => c !== name);
  try {
    localStorage.setItem(LS_CUSTOM_WIRD_CATEGORIES_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }
  return next;
}

export const AUTHENTIC_BUILTIN_ADHKAR: {
  id: string;
  text: string;
  target: number;
  list_name: string;
  virtue: string;
}[] = [
  {
    id: 'builtin_subhanallah',
    text: 'سُبْحَانَ اللَّهِ',
    target: 100,
    list_name: 'التسبيح والتحميد',
    virtue: 'من قال سبحان الله مائة مرة كُتبت له ألف حسنة أو حُطّت عنه ألف خطيئة (صحيح مسلم)',
  },
  {
    id: 'builtin_alhamdulillah',
    text: 'الْحَمْدُ لِلَّهِ',
    target: 100,
    list_name: 'التسبيح والتحميد',
    virtue: 'والحمدُ للهِ تملأُ الميزان (صحيح مسلم)',
  },
  {
    id: 'builtin_allahuakbar',
    text: 'اللَّهُ أَكْبَرُ',
    target: 100,
    list_name: 'التسبيح والتحميد',
    virtue: 'سبحان الله والحمد لله والله أكبر تملآن ما بين السماوات والأرض (صحيح مسلم)',
  },
  {
    id: 'builtin_subhanallahi_wabihamdihi',
    text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
    target: 100,
    list_name: 'التسبيح والتحميد',
    virtue: 'كلمتان خفيفتان على اللسان، ثقيلتان في الميزان، حبيبتان إلى الرحمن (متفق عليه)',
  },
  {
    id: 'builtin_lailahaillallah',
    text: 'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
    target: 100,
    list_name: 'أذكار الصباح والمساء',
    virtue: 'كانت له عدل عشر رقاب، وكُتبت له مائة حسنة، ومُحيت عنه مائة سيئة (متفق عليه)',
  },
  {
    id: 'builtin_istighfar',
    text: 'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
    target: 100,
    list_name: 'الاستغفار والتوبة',
    virtue: 'إني لأستغفر الله في اليوم مائة مرة (صحيح مسلم)',
  },
  {
    id: 'builtin_salawat',
    text: 'اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
    target: 100,
    list_name: 'الصلاة على النبي ﷺ',
    virtue: 'من صلى عليّ صلاةً واحدةً صلى الله عليه بها عشراً (صحيح مسلم)',
  },
  {
    id: 'builtin_hawqala',
    text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
    target: 100,
    list_name: 'أذكار عامة',
    virtue: 'كنزٌ من كنوز الجنة (متفق عليه)',
  },
  {
    id: 'builtin_yunus',
    text: 'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
    target: 100,
    list_name: 'أدعية قرآنية ونبوية',
    virtue: 'لم يدعُ بها رجل مسلم في شيء قط إلا استجاب الله له (جامع الترمذي)',
  },
];

const MISBAHA_IDB_NAME = 'rifq_misbaha_sqlite_db_v1';
const MISBAHA_IDB_VERSION = 1;

const LS_SESSIONS_KEY = 'rifq_sqlite_misbaha_sessions_v1';
const LS_CUSTOM_ADHKAR_KEY = 'rifq_sqlite_custom_adhkar_v1';
const LS_DAILY_STATS_KEY = 'rifq_sqlite_daily_stats_v1';
const LS_SETTINGS_KEY = 'rifq_sqlite_misbaha_settings_v1';
const LS_STREAK_KEY = 'rifq_sqlite_misbaha_streak_v1';

let memSessions: MisbahaSessionSqliteRow[] | null = null;
let memCustomAdhkar: CustomAdhkarSqliteRow[] | null = null;
let memDailyStats: DailyStatsSqliteRow[] | null = null;
let memSettings: MisbahaSettingsSqliteRow | null = null;
let memStreak: MisbahaStreakSqliteRow | null = null;
let isHydratingMisbahaFromCloud = false;

export interface MisbahaCloudPayload {
  sessions: MisbahaSessionSqliteRow[];
  customAdhkar: CustomAdhkarSqliteRow[];
  dailyStats: DailyStatsSqliteRow[];
  settings: MisbahaSettingsSqliteRow;
  streak: MisbahaStreakSqliteRow;
}

export function setMisbahaCloudHydrationLock(locked: boolean): void {
  isHydratingMisbahaFromCloud = locked;
}

export function invalidateMisbahaMemoryCache(): void {
  memSessions = null;
  memCustomAdhkar = null;
  memDailyStats = null;
  memSettings = null;
  memStreak = null;
}

// Track active session start time in milliseconds to calculate real session duration
let activeSessionStartMs: number | null = null;

function openMisbahaIndexedDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  return new Promise((resolve) => {
    try {
      const req = window.indexedDB.open(MISBAHA_IDB_NAME, MISBAHA_IDB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('misbaha_sessions')) {
          db.createObjectStore('misbaha_sessions', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('custom_adhkar')) {
          db.createObjectStore('custom_adhkar', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('daily_stats')) {
          db.createObjectStore('daily_stats', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('streak')) {
          db.createObjectStore('streak', { keyPath: 'id' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function syncMisbahaTablesToIndexedDb(): void {
  openMisbahaIndexedDb().then((db) => {
    if (!db) return;
    try {
      const tx = db.transaction(
        ['misbaha_sessions', 'custom_adhkar', 'daily_stats', 'settings', 'streak'],
        'readwrite'
      );
      const sStore = tx.objectStore('misbaha_sessions');
      const cStore = tx.objectStore('custom_adhkar');
      const dStore = tx.objectStore('daily_stats');
      const setStore = tx.objectStore('settings');
      const strStore = tx.objectStore('streak');

      sStore.clear();
      for (const s of memSessions || []) sStore.put(s);

      cStore.clear();
      for (const c of memCustomAdhkar || []) cStore.put(c);

      dStore.clear();
      for (const d of memDailyStats || []) dStore.put(d);

      if (memSettings) setStore.put(memSettings);
      if (memStreak) strStore.put(memStreak);
    } catch {
      // ignore IndexedDB errors
    }
  });
}

function getDefaultMisbahaSettings(): MisbahaSettingsSqliteRow {
  return {
    id: 1,
    daily_target: 100,
    weekly_target: 3000,
    monthly_target: 15000,
    sound: 'wood',
    sound_volume: 75,
    vibration: 'medium',
    theme: 'gold',
    dark_mode: 0,
    current_dhikr: 'سُبْحَانَ اللَّهِ',
    current_count: 0,
    current_target: 100,
    total_cycles: 0,
  };
}

function getDefaultMisbahaStreak(): MisbahaStreakSqliteRow {
  return {
    id: 1,
    current_streak: 0,
    longest_streak: 0,
    last_date: '',
  };
}

function persistAllMisbahaTables(emitMutationEvent = true): void {
  try {
    if (memSessions) localStorage.setItem(LS_SESSIONS_KEY, JSON.stringify(memSessions));
    if (memCustomAdhkar) localStorage.setItem(LS_CUSTOM_ADHKAR_KEY, JSON.stringify(memCustomAdhkar));
    if (memDailyStats) localStorage.setItem(LS_DAILY_STATS_KEY, JSON.stringify(memDailyStats));
    if (memSettings) localStorage.setItem(LS_SETTINGS_KEY, JSON.stringify(memSettings));
    if (memStreak) localStorage.setItem(LS_STREAK_KEY, JSON.stringify(memStreak));
  } catch {
    // ignore storage quota errors
  }
  syncMisbahaTablesToIndexedDb();

  if (emitMutationEvent && !isHydratingMisbahaFromCloud && typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('rifq-local-data-mutated', { detail: { domain: 'misbaha' } })
    );
  }
}

export function exportMisbahaUserPayload(): MisbahaCloudPayload {
  const tables = initMisbahaSqliteTables();
  return {
    sessions: [...tables.sessions],
    customAdhkar: [...tables.customAdhkar],
    dailyStats: [...tables.dailyStats],
    settings: { ...tables.settings },
    streak: { ...tables.streak },
  };
}

export function hydrateMisbahaUserPayload(payload?: Partial<MisbahaCloudPayload> | null): void {
  isHydratingMisbahaFromCloud = true;
  try {
    const today = getTodayDateString();
    memSessions = Array.isArray(payload?.sessions) ? [...payload.sessions] : [];
    memCustomAdhkar = Array.isArray(payload?.customAdhkar) ? [...payload.customAdhkar] : [];
    memDailyStats = Array.isArray(payload?.dailyStats) ? [...payload.dailyStats] : [];
    if (!memDailyStats.some((d) => d.date === today)) {
      memDailyStats.push({
        id: `stat_${today}`,
        date: today,
        total_count: 0,
        sessions_count: 0,
        cycles_count: 0,
        dhikr_counts_json: '{}',
      });
    }
    memSettings = {
      ...getDefaultMisbahaSettings(),
      ...(payload?.settings || {}),
      id: 1,
    };
    memStreak = {
      ...getDefaultMisbahaStreak(),
      ...(payload?.streak || {}),
      id: 1,
    };
    recomputeStreakTable();
    persistAllMisbahaTables(false);
  } finally {
    isHydratingMisbahaFromCloud = false;
  }
}

/**
 * تهيئة جداول SQLite الخمسة للمسبحة المركزية ومزامنتها مع سجل الاستخدام الفعلي
 * بدون أي بيانات وهمية (Pure Zero-Start)
 */
export function initMisbahaSqliteTables(): {
  sessions: MisbahaSessionSqliteRow[];
  customAdhkar: CustomAdhkarSqliteRow[];
  dailyStats: DailyStatsSqliteRow[];
  settings: MisbahaSettingsSqliteRow;
  streak: MisbahaStreakSqliteRow;
} {
  if (memSessions && memCustomAdhkar && memDailyStats && memSettings && memStreak) {
    return {
      sessions: memSessions,
      customAdhkar: memCustomAdhkar,
      dailyStats: memDailyStats,
      settings: memSettings,
      streak: memStreak,
    };
  }

  try {
    const rawSessions = localStorage.getItem(LS_SESSIONS_KEY);
    memSessions = rawSessions ? JSON.parse(rawSessions) : [];
  } catch {
    memSessions = [];
  }

  try {
    const rawCustom = localStorage.getItem(LS_CUSTOM_ADHKAR_KEY);
    memCustomAdhkar = rawCustom ? JSON.parse(rawCustom) : [];
  } catch {
    memCustomAdhkar = [];
  }

  try {
    const rawStats = localStorage.getItem(LS_DAILY_STATS_KEY);
    memDailyStats = rawStats ? JSON.parse(rawStats) : [];
  } catch {
    memDailyStats = [];
  }

  try {
    const rawSettings = localStorage.getItem(LS_SETTINGS_KEY);
    memSettings = rawSettings
      ? { ...getDefaultMisbahaSettings(), ...JSON.parse(rawSettings) }
      : getDefaultMisbahaSettings();
  } catch {
    memSettings = getDefaultMisbahaSettings();
  }

  try {
    const rawStreak = localStorage.getItem(LS_STREAK_KEY);
    memStreak = rawStreak
      ? { ...getDefaultMisbahaStreak(), ...JSON.parse(rawStreak) }
      : getDefaultMisbahaStreak();
  } catch {
    memStreak = getDefaultMisbahaStreak();
  }

  // Sync any real existing daily records from mushaba_history_v1 into daily_stats
  const appHistory = loadHistory();
  for (const [dateStr, rec] of Object.entries(appHistory)) {
    const existingRow = memDailyStats.find((d) => d.date === dateStr);
    if (!existingRow && rec.totalCount >= 0) {
      memDailyStats.push({
        id: `stat_${dateStr}`,
        date: dateStr,
        total_count: rec.totalCount || 0,
        sessions_count: rec.sessionsCount || 0,
        cycles_count: Math.floor((rec.totalCount || 0) / 100),
        dhikr_counts_json: JSON.stringify(rec.dhikrCounts || {}),
      });
    } else if (existingRow && (rec.totalCount || 0) > existingRow.total_count) {
      existingRow.total_count = rec.totalCount;
      existingRow.dhikr_counts_json = JSON.stringify(rec.dhikrCounts || {});
    }
  }

  // Ensure today's row exists in daily_stats
  const today = getTodayDateString();
  if (!memDailyStats.some((d) => d.date === today)) {
    memDailyStats.push({
      id: `stat_${today}`,
      date: today,
      total_count: 0,
      sessions_count: 0,
      cycles_count: 0,
      dhikr_counts_json: '{}',
    });
  }

  recomputeStreakTable();
  persistAllMisbahaTables(false);

  return {
    sessions: memSessions,
    customAdhkar: memCustomAdhkar,
    dailyStats: memDailyStats,
    settings: memSettings,
    streak: memStreak,
  };
}

/**
 * إعادة حساب جدول السلسلة (streak) بدقة من أيام النشاط الفعلية في daily_stats
 */
function recomputeStreakTable(): void {
  if (!memDailyStats || !memStreak) return;

  const activeDates = memDailyStats
    .filter((d) => d.total_count > 0)
    .map((d) => d.date)
    .sort();

  if (activeDates.length === 0) {
    memStreak = {
      id: 1,
      current_streak: 0,
      longest_streak: 0,
      last_date: '',
    };
    return;
  }

  let longest = 0;
  let temp = 0;

  for (let i = 0; i < activeDates.length; i++) {
    if (i === 0) {
      temp = 1;
    } else {
      const prev = new Date(activeDates[i - 1]);
      const curr = new Date(activeDates[i]);
      const diffDays = Math.round((curr.getTime() - prev.getTime()) / (1000 * 60 * 60 * 24));
      if (diffDays === 1) {
        temp += 1;
      } else if (diffDays > 1) {
        temp = 1;
      }
    }
    if (temp > longest) longest = temp;
  }

  const todayStr = getTodayDateString();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;

  const activeSet = new Set(activeDates);
  let current = 0;
  let cursor = new Date();

  if (activeSet.has(todayStr) || activeSet.has(yesterdayStr)) {
    if (!activeSet.has(todayStr)) {
      cursor = yesterday;
    }
    while (true) {
      const dStr = `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, '0')}-${String(cursor.getDate()).padStart(2, '0')}`;
      if (activeSet.has(dStr)) {
        current += 1;
        cursor.setDate(cursor.getDate() - 1);
      } else {
        break;
      }
    }
  }

  memStreak = {
    id: 1,
    current_streak: current,
    longest_streak: Math.max(longest, current, memStreak.longest_streak || 0),
    last_date: activeDates[activeDates.length - 1] || '',
  };
}

/**
 * استرجاع النص التحفيزي للسلسلة بناءً على الأداء الفعلي
 */
export function getStreakMotivationalText(currentStreak: number, todayCount: number): string {
  if (currentStreak >= 7) {
    return 'ما شاء الله! واصل ثباتك المبارك على ذكر الله';
  }
  if (currentStreak >= 1 && todayCount >= 100) {
    return 'ما شاء الله! واصل، أتممت ورداً طيباً اليوم';
  }
  if (currentStreak >= 1 || todayCount > 0) {
    return 'أنت في الطريق الصحيح، داوم على الذكر ولو بالقليل';
  }
  return 'ابدأ تسبيحتك الأولى اليوم لتفتتح سلسلتك المباركة';
}

/**
 * تسجيل تسبيحة جديدة (+1 أو أكثر) في قاعدة البيانات المحلية (SQLite)
 */
export function recordMisbahaTasbeeh(amount = 1): {
  settings: MisbahaSettingsSqliteRow;
  todayStats: DailyStatsSqliteRow;
  streak: MisbahaStreakSqliteRow;
  completedCycle: boolean;
  newSessionLogged: MisbahaSessionSqliteRow | null;
} {
  const tables = initMisbahaSqliteTables();
  const now = Date.now();

  if (!activeSessionStartMs || tables.settings.current_count === 0) {
    activeSessionStartMs = now;
  }

  const dhikr = tables.settings.current_dhikr || 'سُبْحَانَ اللَّهِ';
  const target = tables.settings.current_target; // 0 means open (∞)
  const nextCount = tables.settings.current_count + amount;

  let completedCycle = false;
  let newSessionLogged: MisbahaSessionSqliteRow | null = null;

  // Update custom_adhkar usage_count if it matches
  const customMatch = tables.customAdhkar.find((c) => c.text === dhikr);
  if (customMatch) {
    customMatch.usage_count += amount;
  }

  // Update daily_stats for today
  const todayStr = getTodayDateString();
  let todayRow = tables.dailyStats.find((d) => d.date === todayStr);
  if (!todayRow) {
    todayRow = {
      id: `stat_${todayStr}`,
      date: todayStr,
      total_count: 0,
      sessions_count: 0,
      cycles_count: 0,
      dhikr_counts_json: '{}',
    };
    tables.dailyStats.push(todayRow);
  }

  todayRow.total_count += amount;
  let dhikrMap: Record<string, number> = {};
  try {
    dhikrMap = JSON.parse(todayRow.dhikr_counts_json || '{}');
  } catch {
    dhikrMap = {};
  }
  dhikrMap[dhikr] = (dhikrMap[dhikr] || 0) + amount;
  todayRow.dhikr_counts_json = JSON.stringify(dhikrMap);

  // Check if cycle target reached (when target > 0)
  if (target > 0 && nextCount >= target) {
    completedCycle = true;
    tables.settings.total_cycles += 1;
    tables.settings.current_count = 0;
    todayRow.cycles_count += 1;
    todayRow.sessions_count += 1;

    const elapsedSec = activeSessionStartMs
      ? Math.max(1, Math.round((now - activeSessionStartMs) / 1000))
      : Math.max(5, Math.round(target * 0.8));

    newSessionLogged = {
      id: `sess_${now}_${Math.random().toString(36).slice(2, 7)}`,
      dhikr,
      count: target,
      target,
      duration: elapsedSec,
      created_at: new Date(now).toISOString(),
    };

    tables.sessions.unshift(newSessionLogged);
    activeSessionStartMs = null;
  } else {
    tables.settings.current_count = nextCount;
    if (todayRow.sessions_count === 0) {
      todayRow.sessions_count = 1;
    }
  }

  // Sync with global app history so all screens stay 100% consistent
  const history = loadHistory();
  const appToday = getTodayRecord(history);
  const hour = new Date().getHours();
  appToday.totalCount = todayRow.total_count;
  appToday.freeCount += amount;
  appToday.sessionsCount = todayRow.sessions_count;
  appToday.hourlyCounts[hour] = (appToday.hourlyCounts[hour] || 0) + amount;
  appToday.dhikrCounts[dhikr] = dhikrMap[dhikr];
  history[todayStr] = appToday;
  saveHistory(history);

  recomputeStreakTable();
  persistAllMisbahaTables();

  return {
    settings: { ...tables.settings },
    todayStats: { ...todayRow },
    streak: { ...tables.streak },
    completedCycle,
    newSessionLogged,
  };
}

/**
 * إنقاص العداد بواحد (-1) من العداد الحالي وإحصائيات اليوم
 */
export function decrementMisbahaTasbeeh(): {
  settings: MisbahaSettingsSqliteRow;
  todayStats: DailyStatsSqliteRow;
} {
  const tables = initMisbahaSqliteTables();
  const todayStr = getTodayDateString();
  let todayRow = tables.dailyStats.find((d) => d.date === todayStr);
  if (!todayRow) {
    todayRow = {
      id: `stat_${todayStr}`,
      date: todayStr,
      total_count: 0,
      sessions_count: 0,
      cycles_count: 0,
      dhikr_counts_json: '{}',
    };
    tables.dailyStats.push(todayRow);
  }

  if (tables.settings.current_count > 0) {
    tables.settings.current_count = Math.max(0, tables.settings.current_count - 1);
  }

  if (todayRow.total_count > 0) {
    todayRow.total_count = Math.max(0, todayRow.total_count - 1);
    const dhikr = tables.settings.current_dhikr;
    try {
      const dhikrMap: Record<string, number> = JSON.parse(todayRow.dhikr_counts_json || '{}');
      if (dhikrMap[dhikr] && dhikrMap[dhikr] > 0) {
        dhikrMap[dhikr] = Math.max(0, dhikrMap[dhikr] - 1);
        todayRow.dhikr_counts_json = JSON.stringify(dhikrMap);
      }
    } catch {
      // ignore
    }
  }

  recomputeStreakTable();
  persistAllMisbahaTables();

  return {
    settings: { ...tables.settings },
    todayStats: { ...todayRow },
  };
}

/**
 * حفظ الجلسة الجزئية الحالية في جدول misbaha_sessions وتصفير العداد الحالي
 */
export function resetMisbahaCurrentCounter(logPartialSession = true): {
  settings: MisbahaSettingsSqliteRow;
  sessions: MisbahaSessionSqliteRow[];
} {
  const tables = initMisbahaSqliteTables();
  const now = Date.now();

  if (logPartialSession && tables.settings.current_count > 0) {
    const elapsedSec = activeSessionStartMs
      ? Math.max(1, Math.round((now - activeSessionStartMs) / 1000))
      : Math.max(1, tables.settings.current_count);

    const partialSession: MisbahaSessionSqliteRow = {
      id: `sess_${now}_${Math.random().toString(36).slice(2, 7)}`,
      dhikr: tables.settings.current_dhikr,
      count: tables.settings.current_count,
      target: tables.settings.current_target,
      duration: elapsedSec,
      created_at: new Date(now).toISOString(),
    };
    tables.sessions.unshift(partialSession);
  }

  tables.settings.current_count = 0;
  activeSessionStartMs = null;
  persistAllMisbahaTables();

  return {
    settings: { ...tables.settings },
    sessions: [...tables.sessions],
  };
}

/**
 * تصفير كافة الإحصائيات والسجل والسلسلة والعداد بالكامل بعد تأكيد المستخدم
 */
export function resetAllMisbahaStatistics(): {
  settings: MisbahaSettingsSqliteRow;
  sessions: MisbahaSessionSqliteRow[];
  dailyStats: DailyStatsSqliteRow[];
  streak: MisbahaStreakSqliteRow;
} {
  const tables = initMisbahaSqliteTables();
  const todayStr = getTodayDateString();

  tables.sessions.length = 0;
  tables.dailyStats.length = 0;
  tables.dailyStats.push({
    id: `stat_${todayStr}`,
    date: todayStr,
    total_count: 0,
    sessions_count: 0,
    cycles_count: 0,
    dhikr_counts_json: '{}',
  });

  tables.settings.current_count = 0;
  tables.settings.total_cycles = 0;

  for (const c of tables.customAdhkar) {
    c.usage_count = 0;
  }

  tables.streak.current_streak = 0;
  tables.streak.longest_streak = 0;
  tables.streak.last_date = '';
  activeSessionStartMs = null;

  // Also reset today's record in global app history
  const history = loadHistory();
  for (const k of Object.keys(history)) {
    delete history[k];
  }
  history[todayStr] = {
    date: todayStr,
    totalCount: 0,
    sessionsCount: 0,
    completedAthkarCount: 0,
    freeCount: 0,
    hourlyCounts: new Array(24).fill(0),
    dhikrCounts: {},
  };
  saveHistory(history);

  persistAllMisbahaTables();

  return {
    settings: { ...tables.settings },
    sessions: [],
    dailyStats: [...tables.dailyStats],
    streak: { ...tables.streak },
  };
}

/**
 * تحديث إعدادات المسبحة والأهداف في جدول settings
 */
export function updateMisbahaSettingsInSqlite(
  partial: Partial<MisbahaSettingsSqliteRow>
): MisbahaSettingsSqliteRow {
  const tables = initMisbahaSqliteTables();

  // If changing dhikr while current_count > 0, save partial session automatically
  if (
    partial.current_dhikr &&
    partial.current_dhikr !== tables.settings.current_dhikr &&
    tables.settings.current_count > 0
  ) {
    const now = Date.now();
    const elapsedSec = activeSessionStartMs
      ? Math.max(1, Math.round((now - activeSessionStartMs) / 1000))
      : Math.max(1, tables.settings.current_count);

    tables.sessions.unshift({
      id: `sess_${now}_${Math.random().toString(36).slice(2, 7)}`,
      dhikr: tables.settings.current_dhikr,
      count: tables.settings.current_count,
      target: tables.settings.current_target,
      duration: elapsedSec,
      created_at: new Date(now).toISOString(),
    });
    partial.current_count = 0;
    activeSessionStartMs = null;
  }

  tables.settings = {
    ...tables.settings,
    ...partial,
    id: 1,
  };

  persistAllMisbahaTables();
  return { ...tables.settings };
}

/**
 * إضافة ذكر مخصص جديد في جدول custom_adhkar
 */
export function addCustomDhikrToSqlite(
  text: string,
  target: number,
  listName = 'أذكار عامة',
  wirdType: WirdCategoryType = 'daily',
  notes = ''
): CustomAdhkarSqliteRow[] {
  const tables = initMisbahaSqliteTables();
  const cleanText = text.trim();
  if (!cleanText) return [...tables.customAdhkar];

  const newRow: CustomAdhkarSqliteRow = {
    id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    text: cleanText,
    target: Math.max(0, target),
    list_name: listName || 'أذكار عامة',
    usage_count: 0,
    created_at: new Date().toISOString(),
    wird_type: wirdType,
    notes: notes.trim(),
  };

  tables.customAdhkar.unshift(newRow);
  persistAllMisbahaTables();
  return [...tables.customAdhkar];
}

/**
 * تعديل ذكر مخصص في جدول custom_adhkar
 */
export function updateCustomDhikrInSqlite(
  id: string,
  updates: {
    text?: string;
    target?: number;
    list_name?: string;
    wird_type?: WirdCategoryType;
    notes?: string;
  }
): CustomAdhkarSqliteRow[] {
  const tables = initMisbahaSqliteTables();
  const row = tables.customAdhkar.find((c) => c.id === id);
  if (row) {
    if (updates.text !== undefined && updates.text.trim()) {
      row.text = updates.text.trim();
    }
    if (updates.target !== undefined) {
      row.target = Math.max(0, updates.target);
    }
    if (updates.list_name !== undefined && updates.list_name.trim()) {
      row.list_name = updates.list_name.trim();
    }
    if (updates.wird_type !== undefined) {
      row.wird_type = updates.wird_type;
    }
    if (updates.notes !== undefined) {
      row.notes = updates.notes.trim();
    }
    persistAllMisbahaTables();
  }
  return [...tables.customAdhkar];
}

/**
 * حذف ذكر مخصص من جدول custom_adhkar
 */
export function deleteCustomDhikrFromSqlite(id: string): CustomAdhkarSqliteRow[] {
  const tables = initMisbahaSqliteTables();
  tables.customAdhkar = tables.customAdhkar.filter((c) => c.id !== id);
  memCustomAdhkar = tables.customAdhkar;
  persistAllMisbahaTables();
  return [...tables.customAdhkar];
}

/**
 * حذف جلسة من جدول misbaha_sessions
 */
export function deleteMisbahaSessionFromSqlite(sessionId: string): MisbahaSessionSqliteRow[] {
  const tables = initMisbahaSqliteTables();
  tables.sessions = tables.sessions.filter((s) => s.id !== sessionId);
  memSessions = tables.sessions;
  persistAllMisbahaTables();
  return [...tables.sessions];
}

/**
 * تنسيق مدة الجلسة بالثواني والدقائق
 */
export function formatSessionDuration(seconds: number): string {
  if (!seconds || seconds <= 0) return '1 ثانية';
  if (seconds < 60) return `${seconds} ثانية`;
  const mins = Math.floor(seconds / 60);
  const remSec = seconds % 60;
  if (remSec === 0) {
    return mins === 1 ? 'دقيقة واحدة' : mins === 2 ? 'دقيقتان' : `${mins} دقائق`;
  }
  return `${mins} د و ${remSec} ث`;
}

/**
 * استرجاع الإحصائيات المتقدمة الشاملة (اليوم، الأسبوع، الشهر، السنة، الرسم البياني الأسبوعي، أكثر الأذكار استخداماً، والإنجازات النصية بدون شارات)
 */
export function getMisbahaAdvancedStats(): {
  todayCount: number;
  weekCount: number;
  monthCount: number;
  yearCount: number;
  totalLifetimeCount: number;
  totalCycles: number;
  totalSessions: number;
  currentStreak: number;
  longestStreak: number;
  motivationalText: string;
  weeklyChart: WeeklyChartDayPoint[];
  todayHourlyChart: DailyHourlyChartPoint[];
  fourWeeksChart: FourWeeksChartPoint[];
  mostUsedAdhkar: MostUsedDhikrStat[];
  achievements: MisbahaTextAchievement[];
} {
  const tables = initMisbahaSqliteTables();
  const todayStr = getTodayDateString();
  const now = new Date();

  const statsMap = new Map<string, DailyStatsSqliteRow>();
  for (const row of tables.dailyStats) {
    statsMap.set(row.date, row);
  }

  const todayRow = statsMap.get(todayStr);
  const todayCount = todayRow ? todayRow.total_count : 0;

  let weekCount = 0;
  let monthCount = 0;
  let yearCount = 0;
  let totalLifetimeCount = 0;
  const dhikrTotals: Record<string, number> = {};

  const dayNamesAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const weeklyChart: WeeklyChartDayPoint[] = [];

  for (let i = 6; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i);
    const dStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const row = statsMap.get(dStr);
    const count = row ? row.total_count : 0;
    const sessionsCount = row ? row.sessions_count : 0;

    weeklyChart.push({
      date: dStr,
      dayNameAr: dayNamesAr[d.getDay()],
      shortDate: `${d.getDate()}/${d.getMonth() + 1}`,
      count,
      sessionsCount,
      isToday: dStr === todayStr,
    });
  }

  // Build 4-Weeks Weekly Comparison Chart
  const weekNames = ['قبل 3 أسابيع', 'قبل أسبوعين', 'الأسبوع الماضي', 'هذا الأسبوع'];
  const fourWeeksChart: FourWeeksChartPoint[] = [];
  for (let w = 3; w >= 0; w--) {
    let wCount = 0;
    let wSessions = 0;
    let wActiveDays = 0;
    const startOffset = w * 7 + 6;
    const endOffset = w * 7;

    const startD = new Date(now);
    startD.setDate(now.getDate() - startOffset);
    const endD = new Date(now);
    endD.setDate(now.getDate() - endOffset);

    for (let dayIdx = startOffset; dayIdx >= endOffset; dayIdx--) {
      const curD = new Date(now);
      curD.setDate(now.getDate() - dayIdx);
      const dStr = `${curD.getFullYear()}-${String(curD.getMonth() + 1).padStart(2, '0')}-${String(curD.getDate()).padStart(2, '0')}`;
      const r = statsMap.get(dStr);
      if (r && r.total_count > 0) {
        wCount += r.total_count;
        wSessions += r.sessions_count || 1;
        wActiveDays += 1;
      }
    }

    fourWeeksChart.push({
      weekLabel: weekNames[3 - w],
      rangeLabel: `${startD.getDate()}/${startD.getMonth() + 1} - ${endD.getDate()}/${endD.getMonth() + 1}`,
      count: wCount,
      sessionsCount: wSessions,
      activeDays: wActiveDays,
    });
  }

  // Build Today's 24-Hour Daily Chart from app history + sessions
  const appHistory = loadHistory();
  const todayAppRec = appHistory[todayStr];
  const hourlyArr =
    todayAppRec && Array.isArray(todayAppRec.hourlyCounts) && todayAppRec.hourlyCounts.length === 24
      ? [...todayAppRec.hourlyCounts]
      : new Array(24).fill(0);

  // Ensure if todayCount > sum(hourlyArr), attribute difference to current hour
  const hourlySum = hourlyArr.reduce((acc, v) => acc + (v || 0), 0);
  if (todayCount > hourlySum) {
    hourlyArr[now.getHours()] = (hourlyArr[now.getHours()] || 0) + (todayCount - hourlySum);
  }

  const todayHourlyChart: DailyHourlyChartPoint[] = hourlyArr.map((cnt, h) => {
    const h12 = h % 12 || 12;
    const ampm = h >= 12 ? 'م' : 'ص';
    let periodAr = 'الليل والقيام';
    if (h >= 4 && h < 11) periodAr = 'الفجر والصباح';
    else if (h >= 11 && h < 16) periodAr = 'الظهيرة والعصر';
    else if (h >= 16 && h < 21) periodAr = 'المساء والمغرب';

    return {
      hour: h,
      label: `${h12} ${ampm}`,
      periodAr,
      count: cnt || 0,
    };
  });

  for (const row of tables.dailyStats) {
    const c = row.total_count || 0;
    totalLifetimeCount += c;

    const rowDate = new Date(row.date);
    const diffDays = Math.floor((now.getTime() - rowDate.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays >= 0 && diffDays < 7) {
      weekCount += c;
    }
    if (diffDays >= 0 && diffDays < 30) {
      monthCount += c;
    }
    if (diffDays >= 0 && diffDays < 365) {
      yearCount += c;
    }

    try {
      const parsed: Record<string, number> = JSON.parse(row.dhikr_counts_json || '{}');
      for (const [k, v] of Object.entries(parsed)) {
        if (v > 0) {
          dhikrTotals[k] = (dhikrTotals[k] || 0) + v;
        }
      }
    } catch {
      // ignore
    }
  }

  // Also include counts from custom_adhkar usage_count if not already in dhikrTotals
  for (const custom of tables.customAdhkar) {
    if (custom.usage_count > 0 && !dhikrTotals[custom.text]) {
      dhikrTotals[custom.text] = custom.usage_count;
    }
  }

  const totalDhikrSum = Object.values(dhikrTotals).reduce((a, b) => a + b, 0);
  const mostUsedAdhkar: MostUsedDhikrStat[] = Object.entries(dhikrTotals)
    .filter(([, count]) => count > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([dhikr, count]) => ({
      dhikr,
      shortDhikr: dhikr.length > 24 ? `${dhikr.slice(0, 22)}...` : dhikr,
      count,
      percentage: totalDhikrSum > 0 ? Math.round((count / totalDhikrSum) * 100) : 0,
    }));

  const totalCycles = tables.settings.total_cycles;
  const totalSessions = tables.sessions.length;
  const currentStreak = tables.streak.current_streak;
  const longestStreak = tables.streak.longest_streak;

  // Text-only achievements (بدون شارات)
  const rawAchievements: { id: string; title: string; description: string; current: number; target: number }[] = [
    {
      id: 'ach_100_tasbeeh',
      title: 'أكملت 100 تسبيحة',
      description: 'إتمام مائة تسبيحة خالصة في المسبحة المركزية',
      current: totalLifetimeCount,
      target: 100,
    },
    {
      id: 'ach_1000_tasbeeh',
      title: 'أكملت 1000 تسبيحة',
      description: 'الوصول إلى ألف تسبيحة في سجل الذكر العام',
      current: totalLifetimeCount,
      target: 1000,
    },
    {
      id: 'ach_10000_tasbeeh',
      title: 'أكملت 10000 تسبيحة',
      description: 'الوصول إلى عشرة آلاف تسبيحة مباركة',
      current: totalLifetimeCount,
      target: 10000,
    },
    {
      id: 'ach_7_days_streak',
      title: 'استمريت 7 أيام',
      description: 'المواظبة على التسبيح سبعة أيام متتالية دون انقطاع',
      current: longestStreak,
      target: 7,
    },
    {
      id: 'ach_30_days_streak',
      title: 'استمريت 30 يوم',
      description: 'المواظبة على ذكر الله ثلاثين يوماً متتالياً',
      current: longestStreak,
      target: 30,
    },
    {
      id: 'ach_10_cycles',
      title: 'أكملت 10 دورات',
      description: 'إتمام عشر دورات كاملة في المسبحة المركزية',
      current: totalCycles,
      target: 10,
    },
    {
      id: 'ach_100_cycles',
      title: 'أكملت 100 دورة',
      description: 'إتمام مائة دورة تسبيح كاملة',
      current: totalCycles,
      target: 100,
    },
  ];

  const achievements: MisbahaTextAchievement[] = rawAchievements.map((a) => ({
    ...a,
    completed: a.current >= a.target,
    progressPercent: Math.min(100, Math.round((a.current / a.target) * 100)),
  }));

  return {
    todayCount,
    weekCount,
    monthCount,
    yearCount,
    totalLifetimeCount,
    totalCycles,
    totalSessions,
    currentStreak,
    longestStreak,
    motivationalText: getStreakMotivationalText(currentStreak, todayCount),
    weeklyChart,
    todayHourlyChart,
    fourWeeksChart,
    mostUsedAdhkar,
    achievements,
  };
}
