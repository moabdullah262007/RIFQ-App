import { Capacitor, registerPlugin, PluginListenerHandle } from '@capacitor/core';
import {
  QURAN_AUDIO_RECITERS,
  QuranAudioReciter,
  SURAH_LIST,
  buildPrimarySurahAudioUrl,
  getResilientSurahAudioUrls,
  formatSurahThreeDigits,
} from '../data/quranAudioData';

const FAVORITE_RECITERS_KEY = 'rifq_quran_audio_fav_reciters_v1';
const FAVORITE_TRACKS_KEY = 'rifq_quran_audio_fav_tracks_v1';
const DOWNLOADED_TRACKS_KEY = 'rifq_quran_audio_downloads_v1';
const RECENT_PLAYS_KEY = 'rifq_quran_audio_recent_v1';
const SELECTED_RECITER_KEY = 'rifq_quran_audio_selected_reciter_v1';
const API_RECITER_SERVERS_CACHE_KEY = 'rifq_mp3quran_api_servers_v1';

const AUDIO_CACHE_NAME = 'rifq-quran-audio-offline-v2';
const LEGACY_AUDIO_CACHE_NAME = 'rifq-quran-audio-offline-v1';

const IDB_NAME = 'rifq_quran_audio_offline_db_v2';
const IDB_VERSION = 1;
const IDB_FILES_STORE = 'audio_files';
const IDB_META_STORE = 'audio_metadata';

const MIN_VALID_AUDIO_BYTES = 10240; // 10 KB minimum for a valid Surah MP3

export type SurahDownloadStatus = 'not_downloaded' | 'downloading' | 'downloaded' | 'failed';

export interface FavoriteTrackRecord {
  id: string; // `${reciterId}_${surahNumber}`
  reciterId: string;
  reciterName: string;
  surahNumber: number;
  surahName: string;
  addedAt: string;
}

export interface DownloadedTrackRecord {
  id: string; // `${reciterId}_${surahNumber}`
  surahId: string; // `surah_${surahNumber}`
  reciterId: string;
  reciterName: string;
  surahNumber: number;
  surahName: string;
  sourceUrl: string; // رابط المصدر الأصلي
  audioUrl: string; // للتوافق مع الواجهة الحالية
  localFilePath: string; // مسار الملف المحلي الحقيقي على الجهاز
  fileSizeBytes: number; // حجم الملف الفعلي بالبايت
  downloadedAt: string; // تاريخ التحميل ISO
  downloadStatus: SurahDownloadStatus; // حالة التحميل
}

export interface RecentPlayRecord {
  id: string; // `${reciterId}_${surahNumber}`
  reciterId: string;
  reciterName: string;
  rewaya: string;
  surahNumber: number;
  surahName: string;
  positionSeconds: number;
  durationSeconds: number;
  playedAt: string;
}

interface StoredIdbAudioFile {
  id: string;
  surahId: string;
  reciterId: string;
  surahNumber: number;
  buffer: ArrayBuffer;
  mimeType: string;
  fileSizeBytes: number;
  sourceUrl: string;
  localFilePath: string;
  downloadedAt: string;
}

interface RifqQuranAudioNativePlugin {
  downloadSurah(options: {
    id: string;
    surahId: string;
    reciterId: string;
    reciterName: string;
    surahNumber: number;
    surahName: string;
    candidateUrls: string[];
  }): Promise<DownloadedTrackRecord>;
  verifyAndListDownloads(options?: {
    clientRecords?: DownloadedTrackRecord[];
  }): Promise<{ downloads: DownloadedTrackRecord[] }>;
  verifySurahFile(options: { id: string }): Promise<{
    exists: boolean;
    localFilePath?: string;
    fileSizeBytes?: number;
    record?: DownloadedTrackRecord;
  }>;
  deleteSurah(options: { id: string }): Promise<{
    deleted: boolean;
    downloads: DownloadedTrackRecord[];
  }>;
  addListener(
    eventName: 'quranAudioDownloadProgress',
    listenerFunc: (data: {
      id: string;
      surahNumber: number;
      reciterId: string;
      percent: number;
    }) => void
  ): Promise<PluginListenerHandle>;
}

const RifqQuranAudioNative = registerPlugin<RifqQuranAudioNativePlugin>('RifqQuranAudio');

// Active in-memory Object URLs cache so we don't recreate Blob URLs repeatedly in the same session
const activeBlobUrls = new Map<string, string>();

// Listeners for reactive updates when verification or downloads finish
type DownloadsChangeListener = (tracks: DownloadedTrackRecord[]) => void;
const downloadsListeners = new Set<DownloadsChangeListener>();

export function subscribeToOfflineDownloads(listener: DownloadsChangeListener): () => void {
  downloadsListeners.add(listener);
  return () => {
    downloadsListeners.delete(listener);
  };
}

function notifyDownloadsListeners(tracks: DownloadedTrackRecord[]): void {
  downloadsListeners.forEach((fn) => {
    try {
      fn(tracks);
    } catch (e) {
      console.error(e);
    }
  });
}

function isNativeAndroid(): boolean {
  try {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  } catch {
    return false;
  }
}

function buildCanonicalCacheUrl(trackId: string): string {
  return `https://offline.rifq.local/quran_audio/${encodeURIComponent(trackId)}.mp3`;
}

// ==================== IndexedDB Persistent Binary & Metadata Engine ====================

let idbPromise: Promise<IDBDatabase> | null = null;

function openOfflineAudioDb(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') {
    return Promise.reject(new Error('IndexedDB is not supported in this environment'));
  }
  if (idbPromise) return idbPromise;

  idbPromise = new Promise((resolve, reject) => {
    try {
      const request = indexedDB.open(IDB_NAME, IDB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(IDB_FILES_STORE)) {
          db.createObjectStore(IDB_FILES_STORE, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(IDB_META_STORE)) {
          db.createObjectStore(IDB_META_STORE, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => {
        idbPromise = null;
        reject(request.error);
      };
    } catch (err) {
      idbPromise = null;
      reject(err);
    }
  });

  return idbPromise;
}

async function saveAudioFileAndMetaToIdb(
  record: DownloadedTrackRecord,
  buffer: ArrayBuffer,
  mimeType: string = 'audio/mpeg'
): Promise<void> {
  const db = await openOfflineAudioDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction([IDB_FILES_STORE, IDB_META_STORE], 'readwrite');
    const filesStore = tx.objectStore(IDB_FILES_STORE);
    const metaStore = tx.objectStore(IDB_META_STORE);

    const fileRow: StoredIdbAudioFile = {
      id: record.id,
      surahId: record.surahId,
      reciterId: record.reciterId,
      surahNumber: record.surahNumber,
      buffer,
      mimeType,
      fileSizeBytes: buffer.byteLength,
      sourceUrl: record.sourceUrl,
      localFilePath: record.localFilePath,
      downloadedAt: record.downloadedAt,
    };

    filesStore.put(fileRow);
    metaStore.put(record);

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

async function saveMetaOnlyToIdb(record: DownloadedTrackRecord): Promise<void> {
  try {
    const db = await openOfflineAudioDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(IDB_META_STORE, 'readwrite');
      tx.objectStore(IDB_META_STORE).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // ignore
  }
}

async function getAudioFileFromIdb(trackId: string): Promise<StoredIdbAudioFile | null> {
  try {
    const db = await openOfflineAudioDb();
    return await new Promise<StoredIdbAudioFile | null>((resolve) => {
      const tx = db.transaction(IDB_FILES_STORE, 'readonly');
      const req = tx.objectStore(IDB_FILES_STORE).get(trackId);
      req.onsuccess = () => resolve((req.result as StoredIdbAudioFile) || null);
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

async function getAllMetaFromIdb(): Promise<DownloadedTrackRecord[]> {
  try {
    const db = await openOfflineAudioDb();
    return await new Promise<DownloadedTrackRecord[]>((resolve) => {
      const tx = db.transaction(IDB_META_STORE, 'readonly');
      const req = tx.objectStore(IDB_META_STORE).getAll();
      req.onsuccess = () => resolve(Array.isArray(req.result) ? req.result : []);
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

async function getAllFileMetaKeysFromIdb(): Promise<
  Array<{
    id: string;
    surahId: string;
    reciterId: string;
    surahNumber: number;
    fileSizeBytes: number;
    sourceUrl: string;
    localFilePath: string;
    downloadedAt: string;
  }>
> {
  try {
    const db = await openOfflineAudioDb();
    return await new Promise((resolve) => {
      const tx = db.transaction(IDB_FILES_STORE, 'readonly');
      const store = tx.objectStore(IDB_FILES_STORE);
      const results: Array<{
        id: string;
        surahId: string;
        reciterId: string;
        surahNumber: number;
        fileSizeBytes: number;
        sourceUrl: string;
        localFilePath: string;
        downloadedAt: string;
      }> = [];
      const cursorReq = store.openCursor();
      cursorReq.onsuccess = () => {
        const cursor = cursorReq.result;
        if (cursor) {
          const val = cursor.value as StoredIdbAudioFile;
          if (val && val.buffer && val.buffer.byteLength >= MIN_VALID_AUDIO_BYTES) {
            results.push({
              id: val.id,
              surahId: val.surahId || `surah_${val.surahNumber}`,
              reciterId: val.reciterId,
              surahNumber: val.surahNumber,
              fileSizeBytes: val.buffer.byteLength,
              sourceUrl: val.sourceUrl || '',
              localFilePath: val.localFilePath || `idb://${IDB_NAME}/${IDB_FILES_STORE}/${val.id}`,
              downloadedAt: val.downloadedAt || new Date().toISOString(),
            });
          }
          cursor.continue();
        } else {
          resolve(results);
        }
      };
      cursorReq.onerror = () => resolve(results);
    });
  } catch {
    return [];
  }
}

async function deleteAudioFileAndMetaFromIdb(trackId: string): Promise<void> {
  try {
    const db = await openOfflineAudioDb();
    await new Promise<void>((resolve) => {
      const tx = db.transaction([IDB_FILES_STORE, IDB_META_STORE], 'readwrite');
      tx.objectStore(IDB_FILES_STORE).delete(trackId);
      tx.objectStore(IDB_META_STORE).delete(trackId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // ignore
  }
}

/**
 * Validates that an ArrayBuffer contains real audio data (>= 10 KB and not an HTML/JSON error page)
 */
function isValidAudioArrayBuffer(buffer: ArrayBuffer | null | undefined): boolean {
  if (!buffer || buffer.byteLength < MIN_VALID_AUDIO_BYTES) {
    return false;
  }
  try {
    const headerBytes = new Uint8Array(buffer, 0, Math.min(24, buffer.byteLength));
    let ascii = '';
    for (let i = 0; i < headerBytes.length; i++) {
      ascii += String.fromCharCode(headerBytes[i]);
    }
    const trimmed = ascii.trim().toLowerCase();
    if (
      trimmed.startsWith('<!doc') ||
      trimmed.startsWith('<html') ||
      trimmed.startsWith('<?xml') ||
      trimmed.startsWith('{"error')
    ) {
      return false;
    }
    return true;
  } catch {
    return true;
  }
}

function normalizeDownloadedRecord(raw: Partial<DownloadedTrackRecord>): DownloadedTrackRecord | null {
  if (!raw || !raw.reciterId || !raw.surahNumber) return null;
  const surahNum = Number(raw.surahNumber);
  if (!Number.isFinite(surahNum) || surahNum < 1 || surahNum > 114) return null;

  const surahMeta = SURAH_LIST.find((s) => s.number === surahNum) || SURAH_LIST[0];
  const reciterMeta = QURAN_AUDIO_RECITERS.find((r) => r.id === raw.reciterId);
  const id = raw.id || `${raw.reciterId}_${surahNum}`;
  const sourceUrl =
    raw.sourceUrl ||
    raw.audioUrl ||
    (reciterMeta ? buildPrimarySurahAudioUrl(reciterMeta, surahNum) : '');

  return {
    id,
    surahId: raw.surahId || `surah_${surahNum}`,
    reciterId: raw.reciterId,
    reciterName: raw.reciterName || reciterMeta?.name || '',
    surahNumber: surahNum,
    surahName: raw.surahName || surahMeta.name,
    sourceUrl,
    audioUrl: raw.audioUrl || sourceUrl,
    localFilePath: raw.localFilePath || `idb://${IDB_NAME}/${IDB_FILES_STORE}/${id}`,
    fileSizeBytes: Number(raw.fileSizeBytes) || 0,
    downloadedAt: raw.downloadedAt || new Date().toISOString(),
    downloadStatus: raw.downloadStatus || 'downloaded',
  };
}

function saveDownloadedTracksToLocalStorage(records: DownloadedTrackRecord[]): void {
  try {
    const onlyDownloaded = records.filter((r) => r.downloadStatus === 'downloaded');
    localStorage.setItem(DOWNLOADED_TRACKS_KEY, JSON.stringify(onlyDownloaded));
  } catch (e) {
    console.warn('Failed to persist downloaded tracks metadata to localStorage', e);
  }
}

// ==================== Initialization & Selected Reciter Persistence ====================

/**
 * تهيئة جداول التخزين المحلي والتحقق من الملفات الصوتية المحملة فعلياً على الجهاز
 */
export function initQuranAudioSqliteTables(): void {
  try {
    if (!localStorage.getItem(FAVORITE_RECITERS_KEY)) {
      localStorage.setItem(FAVORITE_RECITERS_KEY, JSON.stringify([]));
    }
    if (!localStorage.getItem(FAVORITE_TRACKS_KEY)) {
      localStorage.setItem(FAVORITE_TRACKS_KEY, JSON.stringify([]));
    }
    if (!localStorage.getItem(DOWNLOADED_TRACKS_KEY)) {
      localStorage.setItem(DOWNLOADED_TRACKS_KEY, JSON.stringify([]));
    }
    if (!localStorage.getItem(RECENT_PLAYS_KEY)) {
      localStorage.setItem(RECENT_PLAYS_KEY, JSON.stringify([]));
    }
  } catch (e) {
    console.warn('Failed to initialize Quran Audio storage tables', e);
  }

  // Trigger background verification of physical files on device
  verifyAndSyncOfflineDownloads().catch(() => {});
}

export function getSavedSelectedReciterId(): string {
  try {
    const saved = localStorage.getItem(SELECTED_RECITER_KEY);
    if (saved && QURAN_AUDIO_RECITERS.some((r) => r.id === saved)) {
      return saved;
    }
    const recents = getRecentPlays();
    if (recents.length > 0 && QURAN_AUDIO_RECITERS.some((r) => r.id === recents[0].reciterId)) {
      return recents[0].reciterId;
    }
    const downloads = getDownloadedTracks();
    if (downloads.length > 0 && QURAN_AUDIO_RECITERS.some((r) => r.id === downloads[0].reciterId)) {
      return downloads[0].reciterId;
    }
  } catch {
    // ignore
  }
  return QURAN_AUDIO_RECITERS[0].id;
}

export function saveSelectedReciterId(reciterId: string): void {
  try {
    if (reciterId && QURAN_AUDIO_RECITERS.some((r) => r.id === reciterId)) {
      localStorage.setItem(SELECTED_RECITER_KEY, reciterId);
    }
  } catch {
    // ignore
  }
}

/**
 * جلب وتحديث روابط خوادم القراء مباشرة من API الرسمي:
 * https://mp3quran.net/api/v3/reciters?language=ar
 */
export async function syncRecitersFromMp3QuranApi(): Promise<Record<number, string>> {
  let cachedServers: Record<number, string> = {};
  try {
    const cached = localStorage.getItem(API_RECITER_SERVERS_CACHE_KEY);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed && parsed.servers) {
        cachedServers = parsed.servers;
        if (parsed.timestamp && Date.now() - parsed.timestamp < 1000 * 60 * 60 * 12) {
          return cachedServers;
        }
      }
    }
  } catch {
    // ignore
  }

  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return cachedServers;
  }

  try {
    const response = await fetch('https://mp3quran.net/api/v3/reciters?language=ar');
    if (!response.ok) return cachedServers;
    const data = await response.json();
    const serverMap: Record<number, string> = {};

    if (data && Array.isArray(data.reciters)) {
      for (const r of data.reciters) {
        if (r.id && Array.isArray(r.moshaf) && r.moshaf.length > 0 && r.moshaf[0].server) {
          serverMap[Number(r.id)] = String(r.moshaf[0].server);
        }
      }
      localStorage.setItem(
        API_RECITER_SERVERS_CACHE_KEY,
        JSON.stringify({ timestamp: Date.now(), servers: serverMap })
      );
      return serverMap;
    }
    return cachedServers;
  } catch {
    return cachedServers;
  }
}

/**
 * جلب رابط التلاوة من Quran.com API v4 كرافد إضافي موثوق يدعم CORS والتحميل المباشر:
 * https://api.quran.com/api/v4/chapter_recitations/{id}/{surah}
 */
export async function fetchQuranComChapterAudioUrl(
  recitationId: number,
  surahNumber: number
): Promise<string | null> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return null;
  }
  try {
    const res = await fetch(
      `https://api.quran.com/api/v4/chapter_recitations/${recitationId}/${surahNumber}`
    );
    if (!res.ok) return null;
    const json = await res.json();
    if (json?.audio_file?.audio_url) {
      return String(json.audio_file.audio_url);
    }
    return null;
  } catch {
    return null;
  }
}

// ==================== Favorite Reciters ====================

export function getFavoriteReciterIds(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITE_RECITERS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleFavoriteReciterId(reciterId: string): { ids: string[]; isFavorite: boolean } {
  const current = getFavoriteReciterIds();
  const exists = current.includes(reciterId);
  const updated = exists ? current.filter((id) => id !== reciterId) : [reciterId, ...current];
  try {
    localStorage.setItem(FAVORITE_RECITERS_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn(e);
  }
  return { ids: updated, isFavorite: !exists };
}

// ==================== Favorite Tracks ====================

export function getFavoriteTracks(): FavoriteTrackRecord[] {
  try {
    const raw = localStorage.getItem(FAVORITE_TRACKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function toggleFavoriteTrack(
  reciter: QuranAudioReciter,
  surahNumber: number
): { tracks: FavoriteTrackRecord[]; isFavorite: boolean } {
  const current = getFavoriteTracks();
  const trackId = `${reciter.id}_${surahNumber}`;
  const exists = current.some((t) => t.id === trackId);
  const surah = SURAH_LIST.find((s) => s.number === surahNumber) || SURAH_LIST[0];

  const updated = exists
    ? current.filter((t) => t.id !== trackId)
    : [
        {
          id: trackId,
          reciterId: reciter.id,
          reciterName: reciter.name,
          surahNumber,
          surahName: surah.name,
          addedAt: new Date().toISOString(),
        },
        ...current,
      ];

  try {
    localStorage.setItem(FAVORITE_TRACKS_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn(e);
  }
  return { tracks: updated, isFavorite: !exists };
}

// ==================== Recent Plays ====================

export function getRecentPlays(): RecentPlayRecord[] {
  try {
    const raw = localStorage.getItem(RECENT_PLAYS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveRecentPlay(
  reciter: QuranAudioReciter,
  surahNumber: number,
  positionSeconds: number = 0,
  durationSeconds: number = 0
): RecentPlayRecord[] {
  const current = getRecentPlays();
  const surah = SURAH_LIST.find((s) => s.number === surahNumber) || SURAH_LIST[0];
  const trackId = `${reciter.id}_${surahNumber}`;

  saveSelectedReciterId(reciter.id);

  const record: RecentPlayRecord = {
    id: trackId,
    reciterId: reciter.id,
    reciterName: reciter.name,
    rewaya: reciter.rewaya,
    surahNumber,
    surahName: surah.name,
    positionSeconds: Math.floor(positionSeconds),
    durationSeconds: Math.floor(durationSeconds),
    playedAt: new Date().toISOString(),
  };

  const filtered = current.filter((item) => item.id !== trackId);
  const updated = [record, ...filtered].slice(0, 40);
  try {
    localStorage.setItem(RECENT_PLAYS_KEY, JSON.stringify(updated));
  } catch (e) {
    console.warn(e);
  }
  return updated;
}

// ==================== Offline Downloads (Real Persistent Device Storage) ====================

export function getDownloadedTracks(): DownloadedTrackRecord[] {
  try {
    const raw = localStorage.getItem(DOWNLOADED_TRACKS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const normalized: DownloadedTrackRecord[] = [];
    for (const item of parsed) {
      const norm = normalizeDownloadedRecord(item);
      if (norm && norm.downloadStatus === 'downloaded') {
        normalized.push(norm);
      }
    }
    return normalized;
  } catch {
    return [];
  }
}

export function isTrackDownloaded(
  reciterId: string,
  surahNumber: number,
  tracksList?: DownloadedTrackRecord[]
): boolean {
  const list = tracksList || getDownloadedTracks();
  return list.some(
    (d) => d.id === `${reciterId}_${surahNumber}` && d.downloadStatus === 'downloaded'
  );
}

/**
 * البحث عن ملف محمل للسورة (سواء للقارئ المحدد أولاً أو لأي قارئ آخر إذا كانت محملة مسبقاً على الجهاز)
 */
export function getDownloadedTrackForSurah(
  surahNumber: number,
  preferredReciterId?: string,
  tracksList?: DownloadedTrackRecord[]
): DownloadedTrackRecord | null {
  const list = tracksList || getDownloadedTracks();
  if (preferredReciterId) {
    const exact = list.find(
      (d) => d.id === `${preferredReciterId}_${surahNumber}` && d.downloadStatus === 'downloaded'
    );
    if (exact) return exact;
  }
  const anyMatch = list.find(
    (d) => d.surahNumber === surahNumber && d.downloadStatus === 'downloaded'
  );
  return anyMatch || null;
}

/**
 * التحقق الفعلي من وجود وسلامة ملف السورة على الجهاز (Android Native Filesystem / IndexedDB / CacheStorage)
 */
export async function verifySurahOfflineFile(
  reciterId: string,
  surahNumber: number
): Promise<{ exists: boolean; record: DownloadedTrackRecord | null }> {
  const trackId = `${reciterId}_${surahNumber}`;
  const currentList = getDownloadedTracks();
  const existingMeta = currentList.find((d) => d.id === trackId) || null;

  // 1. Check Native Android Internal Storage first if on Android APK
  if (isNativeAndroid()) {
    try {
      const nativeCheck = await RifqQuranAudioNative.verifySurahFile({ id: trackId });
      if (nativeCheck && nativeCheck.exists && (nativeCheck.fileSizeBytes || 0) >= MIN_VALID_AUDIO_BYTES) {
        const norm = normalizeDownloadedRecord({
          ...(existingMeta || {}),
          ...(nativeCheck.record || {}),
          id: trackId,
          surahId: `surah_${surahNumber}`,
          reciterId,
          surahNumber,
          localFilePath: nativeCheck.localFilePath || existingMeta?.localFilePath || '',
          fileSizeBytes: nativeCheck.fileSizeBytes || existingMeta?.fileSizeBytes || 0,
          downloadStatus: 'downloaded',
        });
        return { exists: true, record: norm };
      }
    } catch {
      // Fall through to IndexedDB check
    }
  }

  // 2. Check Persistent IndexedDB Binary Store
  const idbFile = await getAudioFileFromIdb(trackId);
  if (idbFile && isValidAudioArrayBuffer(idbFile.buffer)) {
    const norm = normalizeDownloadedRecord({
      ...(existingMeta || {}),
      id: trackId,
      surahId: idbFile.surahId || `surah_${surahNumber}`,
      reciterId,
      surahNumber,
      sourceUrl: existingMeta?.sourceUrl || idbFile.sourceUrl,
      audioUrl: existingMeta?.audioUrl || idbFile.sourceUrl,
      localFilePath: idbFile.localFilePath || `idb://${IDB_NAME}/${IDB_FILES_STORE}/${trackId}`,
      fileSizeBytes: idbFile.buffer.byteLength,
      downloadedAt: existingMeta?.downloadedAt || idbFile.downloadedAt,
      downloadStatus: 'downloaded',
    });
    return { exists: true, record: norm };
  }

  // 3. Check CacheStorage (canonical URL & sourceUrl) and migrate to IndexedDB if valid
  if (typeof window !== 'undefined' && 'caches' in window) {
    try {
      const canonicalUrl = buildCanonicalCacheUrl(trackId);
      const urlsToCheck = [
        canonicalUrl,
        existingMeta?.sourceUrl,
        existingMeta?.audioUrl,
      ].filter(Boolean) as string[];

      for (const cacheName of [AUDIO_CACHE_NAME, LEGACY_AUDIO_CACHE_NAME]) {
        const cache = await caches.open(cacheName);
        for (const u of urlsToCheck) {
          const match = await cache.match(u);
          if (match) {
            const blob = await match.blob();
            if (blob.size >= MIN_VALID_AUDIO_BYTES) {
              const buffer = await blob.arrayBuffer();
              if (isValidAudioArrayBuffer(buffer)) {
                const norm = normalizeDownloadedRecord({
                  ...(existingMeta || {}),
                  id: trackId,
                  surahId: `surah_${surahNumber}`,
                  reciterId,
                  surahNumber,
                  sourceUrl: existingMeta?.sourceUrl || u,
                  audioUrl: existingMeta?.audioUrl || u,
                  localFilePath: `idb://${IDB_NAME}/${IDB_FILES_STORE}/${trackId}`,
                  fileSizeBytes: buffer.byteLength,
                  downloadStatus: 'downloaded',
                });
                if (norm) {
                  await saveAudioFileAndMetaToIdb(norm, buffer, 'audio/mpeg').catch(() => {});
                }
                return { exists: true, record: norm };
              }
            }
          }
        }
      }
    } catch {
      // ignore
    }
  }

  return { exists: false, record: null };
}

/**
 * فحص ومزامنة جميع ملفات السور المحملة فعلياً على الجهاز عند فتح التطبيق أو قسم «القرآن — استماع».
 * - يستعيد أي سورة موجودة فعلياً في مساحة تخزين الجهاز (Android Filesystem أو IndexedDB) حتى لو فُقدت من الذاكرة المؤقتة.
 * - يحذف أي سجل وهمي أو ملف تالف/ناقص حتى تظهر الحالة الحقيقية فقط.
 */
export async function verifyAndSyncOfflineDownloads(): Promise<DownloadedTrackRecord[]> {
  const localRecords = getDownloadedTracks();
  const idbMetaRecords = await getAllMetaFromIdb();
  const idbFileKeys = await getAllFileMetaKeysFromIdb();

  const mergedCandidatesMap = new Map<string, DownloadedTrackRecord>();

  for (const r of [...localRecords, ...idbMetaRecords]) {
    const norm = normalizeDownloadedRecord(r);
    if (norm) {
      mergedCandidatesMap.set(norm.id, norm);
    }
  }

  // Also reconstruct metadata for any valid binary file found in IndexedDB audio_files store
  for (const fileInfo of idbFileKeys) {
    if (!mergedCandidatesMap.has(fileInfo.id)) {
      const norm = normalizeDownloadedRecord({
        id: fileInfo.id,
        surahId: fileInfo.surahId,
        reciterId: fileInfo.reciterId,
        surahNumber: fileInfo.surahNumber,
        sourceUrl: fileInfo.sourceUrl,
        audioUrl: fileInfo.sourceUrl,
        localFilePath: fileInfo.localFilePath,
        fileSizeBytes: fileInfo.fileSizeBytes,
        downloadedAt: fileInfo.downloadedAt,
        downloadStatus: 'downloaded',
      });
      if (norm) {
        mergedCandidatesMap.set(norm.id, norm);
      }
    }
  }

  const verifiedMap = new Map<string, DownloadedTrackRecord>();

  // 1. Verify native Android filesystem downloads if running inside Android APK
  if (isNativeAndroid()) {
    try {
      const nativeRes = await RifqQuranAudioNative.verifyAndListDownloads({
        clientRecords: Array.from(mergedCandidatesMap.values()),
      });
      if (nativeRes && Array.isArray(nativeRes.downloads)) {
        for (const item of nativeRes.downloads) {
          const norm = normalizeDownloadedRecord({
            ...item,
            downloadStatus: 'downloaded',
          });
          if (norm && norm.fileSizeBytes >= MIN_VALID_AUDIO_BYTES) {
            verifiedMap.set(norm.id, norm);
            await saveMetaOnlyToIdb(norm);
          }
        }
      }
    } catch (e) {
      console.warn('Native Android download verification fallback to WebView storage:', e);
    }
  }

  // 2. Verify IndexedDB & CacheStorage files for all remaining candidates
  for (const [trackId, candidate] of mergedCandidatesMap.entries()) {
    if (verifiedMap.has(trackId)) continue;

    const check = await verifySurahOfflineFile(candidate.reciterId, candidate.surahNumber);
    if (check.exists && check.record) {
      verifiedMap.set(trackId, check.record);
      await saveMetaOnlyToIdb(check.record);
    } else {
      // File does not exist or is corrupted: clean up any leftover metadata or partial cache
      await deleteAudioFileAndMetaFromIdb(trackId);
    }
  }

  const verifiedList = Array.from(verifiedMap.values()).sort((a, b) =>
    String(b.downloadedAt || '').localeCompare(String(a.downloadedAt || ''))
  );

  saveDownloadedTracksToLocalStorage(verifiedList);
  notifyDownloadsListeners(verifiedList);
  return verifiedList;
}

/**
 * بناء قائمة شاملة من الروابط الموثوقة لتحميل السورة (مع دعم CORS وخوادم MP3Quran و Quran.com و Islamic Network)
 */
async function buildDownloadCandidateUrls(
  reciter: QuranAudioReciter,
  surahNumber: number,
  extraServerUrl?: string
): Promise<string[]> {
  const baseUrls = getResilientSurahAudioUrls(reciter, surahNumber);
  const candidates: string[] = [];

  if (extraServerUrl) {
    const cleanServer = extraServerUrl.endsWith('/') ? extraServerUrl : `${extraServerUrl}/`;
    candidates.push(`${cleanServer}${formatSurahThreeDigits(surahNumber)}.mp3`);
  }

  // Include primary URLs
  for (const u of baseUrls) {
    candidates.push(u);
  }

  // Query Quran.com API v4 for direct CORS-enabled download URL (download.quranicaudio.com)
  const quranComUrl = await fetchQuranComChapterAudioUrl(
    reciter.quranComRecitationId || 7,
    surahNumber
  );
  if (quranComUrl) {
    // Insert right after primary URL or at the front for Web fetch reliability
    candidates.splice(1, 0, quranComUrl);
  }

  return Array.from(new Set(candidates.filter(Boolean)));
}

/**
 * تحميل ملف صوتي حقيقي عبر Fetch مع تتبع دقيق لنسبة التحميل والتحقق من سلامة الملف
 */
async function fetchAudioBufferWithProgress(
  url: string,
  onProgress?: (percent: number) => void
): Promise<{ buffer: ArrayBuffer; contentType: string }> {
  const response = await fetch(url, {
    mode: 'cors',
    credentials: 'omit',
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status} from ${url}`);
  }

  const contentType = response.headers.get('content-type') || 'audio/mpeg';
  if (contentType.includes('text/html') || contentType.includes('application/json')) {
    throw new Error(`Invalid audio content-type (${contentType}) from ${url}`);
  }

  const contentLengthHeader = response.headers.get('content-length');
  const totalBytes = contentLengthHeader ? parseInt(contentLengthHeader, 10) : 0;

  if (response.body && typeof response.body.getReader === 'function') {
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let receivedBytes = 0;
    let lastEmitTime = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value && value.byteLength > 0) {
        chunks.push(value);
        receivedBytes += value.byteLength;

        const now = Date.now();
        if (now - lastEmitTime >= 120) {
          lastEmitTime = now;
          if (totalBytes > 0) {
            const pct = Math.min(95, Math.max(8, Math.round((receivedBytes / totalBytes) * 95)));
            onProgress?.(pct);
          } else {
            const pct = Math.min(90, 10 + Math.floor(receivedBytes / (64 * 1024)));
            onProgress?.(pct);
          }
        }
      }
    }

    if (totalBytes > 0 && receivedBytes !== totalBytes) {
      throw new Error(`Incomplete download: received ${receivedBytes} of ${totalBytes} bytes`);
    }

    const combined = new Uint8Array(receivedBytes);
    let offset = 0;
    for (const chunk of chunks) {
      combined.set(chunk, offset);
      offset += chunk.byteLength;
    }

    const buffer = combined.buffer;
    if (!isValidAudioArrayBuffer(buffer)) {
      throw new Error('Downloaded file is too small or not a valid MP3 file');
    }

    return { buffer, contentType: 'audio/mpeg' };
  } else {
    const blob = await response.blob();
    const buffer = await blob.arrayBuffer();
    if (totalBytes > 0 && buffer.byteLength !== totalBytes) {
      throw new Error(`Incomplete blob download: ${buffer.byteLength} of ${totalBytes} bytes`);
    }
    if (!isValidAudioArrayBuffer(buffer)) {
      throw new Error('Downloaded blob is not a valid MP3 file');
    }
    onProgress?.(92);
    return { buffer, contentType: 'audio/mpeg' };
  }
}

/**
 * تحميل السورة للاستماع Offline بشكل حقيقي ودائم:
 * 1. على Android APK: ينزل الملف الفعلي إلى `filesDir/quran_audio/` عبر الإضافة الأصلية `RifqQuranAudio` ويحفظ Metadata في SharedPreferences + IndexedDB.
 * 2. على الويب / WebView: ينزل الملف الصوتي الحقيقي ويتحقق من حجمه وسلامته ويحفظه في IndexedDB (`audio_files` + `audio_metadata`) و CacheStorage.
 * 3. إذا فشل التحميل أو انقطع الاتصال: يحذف أي بيانات جزئية ولا يسجل السورة كمحملة ويرمي خطأ واضحاً لإظهار زر «إعادة المحاولة».
 */
export async function downloadSurahForOffline(
  reciter: QuranAudioReciter,
  surahNumber: number,
  onProgress?: (percent: number) => void,
  extraServerUrl?: string
): Promise<DownloadedTrackRecord> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    // Before failing offline, check if the file is already physically present on the device!
    const existingCheck = await verifySurahOfflineFile(reciter.id, surahNumber);
    if (existingCheck.exists && existingCheck.record) {
      onProgress?.(100);
      return existingCheck.record;
    }
    throw new Error('لا يوجد اتصال بالإنترنت لتحميل السورة حالياً');
  }

  const surah = SURAH_LIST.find((s) => s.number === surahNumber) || SURAH_LIST[0];
  const trackId = `${reciter.id}_${surahNumber}`;
  const surahId = `surah_${surahNumber}`;

  saveSelectedReciterId(reciter.id);
  onProgress?.(5);

  const candidateUrls = await buildDownloadCandidateUrls(reciter, surahNumber, extraServerUrl);

  // Path A: Native Android Persistent Filesystem Download (`filesDir/quran_audio/${trackId}.mp3`)
  if (isNativeAndroid()) {
    let progressListener: PluginListenerHandle | null = null;
    try {
      progressListener = await RifqQuranAudioNative.addListener(
        'quranAudioDownloadProgress',
        (data) => {
          if (data && data.id === trackId && typeof data.percent === 'number') {
            onProgress?.(data.percent);
          }
        }
      );

      const nativeRecord = await RifqQuranAudioNative.downloadSurah({
        id: trackId,
        surahId,
        reciterId: reciter.id,
        reciterName: reciter.name,
        surahNumber,
        surahName: surah.name,
        candidateUrls,
      });

      const normalized = normalizeDownloadedRecord({
        ...nativeRecord,
        id: trackId,
        surahId,
        reciterId: reciter.id,
        reciterName: reciter.name,
        surahNumber,
        surahName: surah.name,
        downloadStatus: 'downloaded',
      });

      if (!normalized || normalized.fileSizeBytes < MIN_VALID_AUDIO_BYTES) {
        throw new Error('الملف المحمل غير مكتمل');
      }

      await saveMetaOnlyToIdb(normalized);
      const updatedList = [
        normalized,
        ...getDownloadedTracks().filter((d) => d.id !== trackId),
      ];
      saveDownloadedTracksToLocalStorage(updatedList);
      notifyDownloadsListeners(updatedList);
      onProgress?.(100);
      return normalized;
    } catch (nativeErr) {
      console.warn('Native downloadSurah fallback to JS IndexedDB download:', nativeErr);
    } finally {
      if (progressListener) {
        try {
          await progressListener.remove();
        } catch {
          // ignore
        }
      }
    }
  }

  // Path B: Web / WebView Fetch Stream -> Persistent IndexedDB (`audio_files` + `audio_metadata`) & CacheStorage
  // Order candidates so CORS-verified mirrors (download.quranicaudio.com / cdn.islamic.network) and primary URLs are tried cleanly
  const webOrderedCandidates = [
    ...candidateUrls.filter(
      (u) => u.includes('quranicaudio.com') || u.includes('cdn.islamic.network')
    ),
    ...candidateUrls.filter(
      (u) => !u.includes('quranicaudio.com') && !u.includes('cdn.islamic.network')
    ),
  ];

  let downloadedBuffer: ArrayBuffer | null = null;
  let successfulSourceUrl = '';
  let lastError: Error | null = null;

  for (const url of webOrderedCandidates) {
    try {
      const res = await fetchAudioBufferWithProgress(url, onProgress);
      if (res && isValidAudioArrayBuffer(res.buffer)) {
        downloadedBuffer = res.buffer;
        successfulSourceUrl = url;
        break;
      }
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
    }
  }

  // If download failed on all candidate URLs: clean up any partial data and throw!
  if (!downloadedBuffer || !isValidAudioArrayBuffer(downloadedBuffer)) {
    await deleteAudioFileAndMetaFromIdb(trackId);
    if (typeof window !== 'undefined' && 'caches' in window) {
      try {
        const cache = await caches.open(AUDIO_CACHE_NAME);
        await cache.delete(buildCanonicalCacheUrl(trackId));
      } catch {
        // ignore
      }
    }
    throw lastError || new Error('فشل تحميل ملف السورة الصوتي. يرجى التحقق من الاتصال والمحاولة مجدداً.');
  }

  const localFilePath = `idb://${IDB_NAME}/${IDB_FILES_STORE}/${trackId}`;
  const downloadedAt = new Date().toISOString();

  const record: DownloadedTrackRecord = {
    id: trackId,
    surahId,
    reciterId: reciter.id,
    reciterName: reciter.name,
    surahNumber,
    surahName: surah.name,
    sourceUrl: successfulSourceUrl,
    audioUrl: successfulSourceUrl,
    localFilePath,
    fileSizeBytes: downloadedBuffer.byteLength,
    downloadedAt,
    downloadStatus: 'downloaded',
  };

  // 1. Persist binary MP3 ArrayBuffer + Metadata in IndexedDB (mandatory)
  await saveAudioFileAndMetaToIdb(record, downloadedBuffer, 'audio/mpeg');

  // 2. Also persist in CacheStorage under canonical key & sourceUrl for fast streaming
  if (typeof window !== 'undefined' && 'caches' in window) {
    try {
      const blob = new Blob([downloadedBuffer], { type: 'audio/mpeg' });
      const cache = await caches.open(AUDIO_CACHE_NAME);
      const headers = {
        'Content-Type': 'audio/mpeg',
        'Content-Length': String(downloadedBuffer.byteLength),
      };
      await cache.put(buildCanonicalCacheUrl(trackId), new Response(blob, { headers }));
      if (successfulSourceUrl) {
        await cache.put(successfulSourceUrl, new Response(blob, { headers }));
      }
    } catch {
      // IndexedDB already holds the authoritative binary copy
    }
  }

  // 3. Verify that the file is readable back from storage before marking 100% complete
  const verifyBack = await getAudioFileFromIdb(trackId);
  if (!verifyBack || !isValidAudioArrayBuffer(verifyBack.buffer)) {
    await deleteAudioFileAndMetaFromIdb(trackId);
    throw new Error('تعذر حفظ ملف السورة في مساحة تخزين الجهاز');
  }

  const updatedList = [record, ...getDownloadedTracks().filter((d) => d.id !== trackId)];
  saveDownloadedTracksToLocalStorage(updatedList);
  notifyDownloadsListeners(updatedList);
  onProgress?.(100);

  return record;
}

/**
 * استرجاع رابط تشغيل محلي مباشر (من ملف الجهاز الأصلي على Android أو من IndexedDB / CacheStorage)
 * يعمل بدون إنترنت نهائياً (100% Offline)
 */
export async function getPlayableOfflineSurahUrl(
  reciterId: string,
  surahNumber: number
): Promise<{ url: string; record: DownloadedTrackRecord } | null> {
  const trackId = `${reciterId}_${surahNumber}`;
  const currentList = getDownloadedTracks();
  const existingRecord = currentList.find((d) => d.id === trackId) || null;

  // 1. On Native Android: check physical file in `filesDir/quran_audio/` first
  if (isNativeAndroid()) {
    try {
      const nativeCheck = await RifqQuranAudioNative.verifySurahFile({ id: trackId });
      if (
        nativeCheck &&
        nativeCheck.exists &&
        nativeCheck.localFilePath &&
        (nativeCheck.fileSizeBytes || 0) >= MIN_VALID_AUDIO_BYTES
      ) {
        const playableUri = Capacitor.convertFileSrc(nativeCheck.localFilePath);
        const norm =
          normalizeDownloadedRecord({
            ...(existingRecord || {}),
            ...(nativeCheck.record || {}),
            id: trackId,
            reciterId,
            surahNumber,
            localFilePath: nativeCheck.localFilePath,
            fileSizeBytes: nativeCheck.fileSizeBytes || existingRecord?.fileSizeBytes || 0,
            downloadStatus: 'downloaded',
          }) || existingRecord!;
        return { url: playableUri, record: norm };
      }
    } catch {
      // Fall through to IndexedDB
    }
  }

  // 2. Check active session Blob URL if already created and verified
  if (activeBlobUrls.has(trackId) && existingRecord) {
    return { url: activeBlobUrls.get(trackId)!, record: existingRecord };
  }

  // 3. Read binary MP3 from Persistent IndexedDB `audio_files`
  const idbFile = await getAudioFileFromIdb(trackId);
  if (idbFile && isValidAudioArrayBuffer(idbFile.buffer)) {
    const blob = new Blob([idbFile.buffer], { type: idbFile.mimeType || 'audio/mpeg' });
    const blobUrl = URL.createObjectURL(blob);
    activeBlobUrls.set(trackId, blobUrl);

    const norm =
      normalizeDownloadedRecord({
        ...(existingRecord || {}),
        id: trackId,
        surahId: idbFile.surahId || `surah_${surahNumber}`,
        reciterId,
        surahNumber,
        sourceUrl: existingRecord?.sourceUrl || idbFile.sourceUrl,
        audioUrl: existingRecord?.audioUrl || idbFile.sourceUrl,
        localFilePath: idbFile.localFilePath || `idb://${IDB_NAME}/${IDB_FILES_STORE}/${trackId}`,
        fileSizeBytes: idbFile.buffer.byteLength,
        downloadedAt: existingRecord?.downloadedAt || idbFile.downloadedAt,
        downloadStatus: 'downloaded',
      }) || existingRecord!;

    return { url: blobUrl, record: norm };
  }

  // 4. Check CacheStorage (canonical URL & sourceUrl)
  if (typeof window !== 'undefined' && 'caches' in window) {
    try {
      const canonicalUrl = buildCanonicalCacheUrl(trackId);
      const urlsToTry = [
        canonicalUrl,
        existingRecord?.sourceUrl,
        existingRecord?.audioUrl,
      ].filter(Boolean) as string[];

      for (const cacheName of [AUDIO_CACHE_NAME, LEGACY_AUDIO_CACHE_NAME]) {
        const cache = await caches.open(cacheName);
        for (const u of urlsToTry) {
          const match = await cache.match(u);
          if (match) {
            const blob = await match.blob();
            if (blob.size >= MIN_VALID_AUDIO_BYTES) {
              const buffer = await blob.arrayBuffer();
              if (isValidAudioArrayBuffer(buffer)) {
                const blobUrl = URL.createObjectURL(blob);
                activeBlobUrls.set(trackId, blobUrl);
                const norm = normalizeDownloadedRecord({
                  ...(existingRecord || {}),
                  id: trackId,
                  reciterId,
                  surahNumber,
                  sourceUrl: existingRecord?.sourceUrl || u,
                  audioUrl: existingRecord?.audioUrl || u,
                  fileSizeBytes: buffer.byteLength,
                  downloadStatus: 'downloaded',
                })!;
                await saveAudioFileAndMetaToIdb(norm, buffer, 'audio/mpeg').catch(() => {});
                return { url: blobUrl, record: norm };
              }
            }
          }
        }
      }
    } catch {
      // ignore
    }
  }

  return null;
}

/**
 * استرجاع رابط صوتي محلي (للتوافق مع الدوال السابقة)
 */
export async function getOfflineCachedAudioUrl(audioUrl: string): Promise<string | null> {
  try {
    if (!('caches' in window)) return null;
    for (const cacheName of [AUDIO_CACHE_NAME, LEGACY_AUDIO_CACHE_NAME]) {
      const cache = await caches.open(cacheName);
      const match = await cache.match(audioUrl);
      if (match) {
        const blob = await match.blob();
        if (blob.size >= MIN_VALID_AUDIO_BYTES) {
          return URL.createObjectURL(blob);
        }
      }
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * حذف سورة محملة:
 * - يحذف الملف المحلي فعلياً من Android Filesystem و IndexedDB و CacheStorage.
 * - يحذف الـ Metadata الخاصة به.
 * - يُرجع القائمة المحدثة فوراً.
 */
export async function removeOfflineDownload(
  reciterId: string,
  surahNumber: number
): Promise<DownloadedTrackRecord[]> {
  const trackId = `${reciterId}_${surahNumber}`;
  const current = getDownloadedTracks();
  const target = current.find((d) => d.id === trackId);

  // Revoke in-memory object URL if active
  if (activeBlobUrls.has(trackId)) {
    try {
      URL.revokeObjectURL(activeBlobUrls.get(trackId)!);
    } catch {
      // ignore
    }
    activeBlobUrls.delete(trackId);
  }

  // 1. Delete physical file & metadata from Native Android storage
  if (isNativeAndroid()) {
    try {
      await RifqQuranAudioNative.deleteSurah({ id: trackId });
    } catch {
      // ignore
    }
  }

  // 2. Delete binary & metadata from IndexedDB
  await deleteAudioFileAndMetaFromIdb(trackId);

  // 3. Delete from CacheStorage
  if (typeof window !== 'undefined' && 'caches' in window) {
    try {
      for (const cacheName of [AUDIO_CACHE_NAME, LEGACY_AUDIO_CACHE_NAME]) {
        const cache = await caches.open(cacheName);
        await cache.delete(buildCanonicalCacheUrl(trackId));
        if (target?.sourceUrl) await cache.delete(target.sourceUrl);
        if (target?.audioUrl) await cache.delete(target.audioUrl);
      }
    } catch {
      // ignore
    }
  }

  const updated = current.filter((d) => d.id !== trackId);
  saveDownloadedTracksToLocalStorage(updated);
  notifyDownloadsListeners(updated);
  return updated;
}

export function formatBytesArabic(bytes: number): string {
  if (!bytes || bytes <= 0) return '—';
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) return `${mb.toFixed(1)} م.ب`;
  const kb = bytes / 1024;
  return `${Math.round(kb)} ك.ب`;
}
