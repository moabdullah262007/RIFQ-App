import firebaseAppletConfig from '../../firebase-applet-config.json';

/**
 * الإعداد المركزي الموحد لدومين وروابط تطبيق رِفْق | RIFQ
 * ---------------------------------------------------------------------------
 * ملاحظة مهمة:
 * - يُمنع استخدام localhost أو 127.0.0.1 في روابط الدعوات في بيئة الإنتاج.
 * - لتغيير الدومين الرسمي للتطبيق في المستقبل، يكفي تعديل `DEFAULT_RIFQ_PUBLIC_ORIGIN`
 *   أو ضبط متغير البيئة `VITE_RIFQ_PUBLIC_DOMAIN`.
 */

export const DEFAULT_RIFQ_PUBLIC_ORIGIN = `https://${
  firebaseAppletConfig.authDomain || 'aesthetic-infusion-ncbh2.firebaseapp.com'
}`;

export const RIFQ_SUPPORTED_APP_LINK_HOSTS: readonly string[] = [
  firebaseAppletConfig.authDomain || 'aesthetic-infusion-ncbh2.firebaseapp.com',
  `${firebaseAppletConfig.projectId || 'aesthetic-infusion-ncbh2'}.web.app`,
  'ais-pre-w24ueafjqjx4xkohc75ff6-637381413504.europe-west1.run.app',
];

export const RIFQ_CUSTOM_DEEP_LINK_SCHEME = 'rifq';
export const RIFQ_ANDROID_PACKAGE_NAME = 'com.rifq.app';

/**
 * التحقق مما إذا كان اسم النطاق (Hostname) محليًا أو غير صالح للمشاركة الخارجية
 */
export function isLocalOrInternalHost(hostname: string): boolean {
  const h = (hostname || '').trim().toLowerCase();
  if (!h) return true;
  if (
    h === 'localhost' ||
    h === '127.0.0.1' ||
    h === '0.0.0.0' ||
    h === '[::1]' ||
    h.endsWith('.local') ||
    h.endsWith('.localhost') ||
    h.startsWith('192.168.') ||
    h.startsWith('10.') ||
    /^172\.(1[6-9]|2\d|3[0-1])\./.test(h)
  ) {
    return true;
  }
  return false;
}

/**
 * إرجاع الدومين الرسمي الحقيقي لتطبيق رِفْق (بدون شرطة مائلة في النهاية)
 * يضمن عدم إرجاع localhost نهائيًا تحت أي ظرف (سواء على Web أو داخل Android Capacitor WebView).
 */
export function getRifqPublicOrigin(): string {
  // 1. فحص متغير البيئة المخصص إن وُجد
  try {
    const meta = import.meta as unknown as {
      env?: Record<string, string | undefined>;
    };
    const envDomain = meta?.env?.VITE_RIFQ_PUBLIC_DOMAIN;

    if (envDomain && envDomain.trim()) {
      const normalized = envDomain.trim().replace(/\/+$/, '');
      const withProtocol = /^https?:\/\//i.test(normalized)
        ? normalized
        : `https://${normalized}`;
      const parsed = new URL(withProtocol);
      if (!isLocalOrInternalHost(parsed.hostname)) {
        return `${parsed.protocol}//${parsed.host}`;
      }
    }
  } catch {
    // fallback to default public origin
  }

  // 2. استخدام الدومين المركزي الرسمي لتطبيق رِفْق
  return DEFAULT_RIFQ_PUBLIC_ORIGIN.replace(/\/+$/, '');
}
