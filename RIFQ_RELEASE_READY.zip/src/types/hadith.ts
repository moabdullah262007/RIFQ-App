export type HadithGrade = 'صحيح' | 'حسن';

export type HadithCategoryKey = 
  | 'ethics'       // الأخلاق
  | 'worship'      // العبادات
  | 'dhikr'        // الذكر والدعاء
  | 'raqaiq'       // الرقائق
  | 'muamalat'     // المعاملات
  | 'family'       // الأسرة
  | 'health'       // الصحة النبوية
  | 'afterlife'    // الجنة والنار
  | 'seerah'       // السيرة
  | 'tawbah';      // التوبة

export interface HadithCategoryInfo {
  id: HadithCategoryKey;
  name: string;
  icon: string;
  description: string;
}

export interface HadithItem {
  id: string;
  text: string;
  narrator: string;          // الصحابي راوي الحديث (مثال: عمر بن الخطاب رضي الله عنه)
  source: string;            // اسم الكتاب الأصلي (صحيح البخاري، صحيح مسلم، سنن الترمذي...)
  bookName: string;          // اسم الباب أو الكتاب الداخلي (كتاب الإيمان، كتاب البر والصلة...)
  hadithNumber: string;      // رقم الحديث في الكتاب الأصلي
  grade: HadithGrade;        // 'صحيح' أو 'حسن'
  gradeDetail: string;       // تفصيل الحكم والتخريج (متفق عليه، أخرجه مسلم، صححه الترمذي...)
  category: HadithCategoryKey; // تصنيف الموضوع
  explanation: string;       // الشرح الميسّر لمعاني الحديث
  benefits: string[];        // الفوائد المستنبطة من الحديث
  rulings: string[];         // الأحكام الفقهية والتربوية والعملية
  isHadithOfDay?: boolean;   // مناسب لأن يكون من أحاديث اليوم (من الصحيحين حصراً)
}

export interface HadithFilterOptions {
  searchQuery: string;
  category: HadithCategoryKey | 'all';
  gradeOnly: 'all' | 'sahih_only';
  sourceFilter: string; // 'all' | 'bukhari' | 'muslim' | 'sunan' ...
  narratorQuery: string;
}
