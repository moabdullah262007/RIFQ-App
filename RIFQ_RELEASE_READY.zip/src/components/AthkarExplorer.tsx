import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Star, 
  Share2, 
  Copy, 
  Check, 
  Plus, 
  Minus, 
  ArrowRight, 
  BookOpen, 
  Sparkles, 
  Maximize2, 
  X
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { DhikrItem, ScreenType, UserSettings } from '../types';
import { soundManager } from '../utils/audio';
import { DhikrShareModal } from './DhikrShareModal';
import { AthkarSectionSvg, QuranSectionSvg } from './Home/RifqSectionIcons';

interface AthkarExplorerProps {
  athkarList: DhikrItem[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onNavigate: (screen: ScreenType) => void;
  settings: UserSettings;
  onRecordIncrement: (dhikrText: string, amount?: number) => void;
}

export const AthkarExplorer: React.FC<AthkarExplorerProps> = ({
  athkarList,
  favorites,
  onToggleFavorite,
  onNavigate,
  settings,
  onRecordIncrement,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'quran' | 'sunnah' | 'favorites'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sourceFilter, setSourceFilter] = useState<'all' | 'quran' | 'sunnah'>('all');
  const [sortBy, setSortBy] = useState<'default' | 'alphabetical' | 'repeats'>('default');
  
  // Local card counts
  const [cardCounts, setCardCounts] = useState<Record<string, number>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [zoomedDhikr, setZoomedDhikr] = useState<DhikrItem | null>(null);
  const [selectedDhikrForShare, setSelectedDhikrForShare] = useState<DhikrItem | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2000);
  };

  const handleIncrementCard = (item: DhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const current = cardCounts[item.id] || 0;
    const next = current + 1;
    setCardCounts(prev => ({ ...prev, [item.id]: next }));
    
    if (settings.soundEnabled) {
      soundManager.playBeadClick(settings.soundVolume, settings.soundType);
    }
    if (settings.vibrationEnabled) {
      soundManager.triggerHaptic(20);
    }

    onRecordIncrement(item.text, 1);

    if (next === item.countTarget) {
      if (settings.soundEnabled) {
        soundManager.playCompletionChime(settings.soundVolume);
      }
      try {
        confetti({
          particleCount: 30,
          spread: 50,
          origin: { y: 0.7 },
          colors: ['#5B5FEF', '#E8B84A', '#72B7E8', '#E99AC7'],
        });
      } catch {
        // ignore
      }
    }
  };

  const handleDecrementCard = (item: DhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const current = cardCounts[item.id] || 0;
    if (current > 0) {
      setCardCounts(prev => ({ ...prev, [item.id]: current - 1 }));
    }
  };

  const handleCopy = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const copyText = `« ${text} »\n\n— منقول من تطبيق «رِفْق | RIFQ» ✨`;
    navigator.clipboard.writeText(copyText);
    showToast('تم نسخ الذكر مع بصمة التطبيق بنجاح 📋');
  };

  const handleShare = (item: DhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedDhikrForShare(item);
  };

  // Filter and Sort Athkar
  const filteredAthkar = useMemo(() => {
    return athkarList
      .filter((item) => {
        // Tab Filter
        if (activeTab === 'favorites') {
          if (!favorites.includes(item.id)) return false;
        } else if (activeTab === 'quran') {
          if (item.category !== 'quran') return false;
        } else if (activeTab === 'sunnah') {
          if (item.category !== 'sunnah') return false;
        }

        // Source Filter
        if (sourceFilter === 'quran' && item.category !== 'quran') return false;
        if (sourceFilter === 'sunnah' && item.category !== 'sunnah') return false;

        // Search Query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchText = item.text.toLowerCase().includes(q);
          const matchSource = item.source.toLowerCase().includes(q);
          const matchVirtue = item.virtue?.toLowerCase().includes(q);
          if (!matchText && !matchSource && !matchVirtue) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'alphabetical') {
          return a.text.localeCompare(b.text, 'ar');
        }
        if (sortBy === 'repeats') {
          return b.countTarget - a.countTarget;
        }
        return 0;
      });
  }, [athkarList, activeTab, favorites, sourceFilter, searchQuery, sortBy]);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 pb-12 select-none" dir="rtl">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-full shadow-xl text-sm font-bold flex items-center gap-2 animate-fade-in border border-[#5B5FEF]">
          <Check className="w-4 h-4 text-[#5B5FEF]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Bar: "فصل الذكر" in Gold + Back + Search */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E6E6F0] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('tasbeeh')}
            className="p-2 rounded-xl text-[#25263A] hover:bg-[#F7F7FC] transition-colors"
            title="الرجوع للمسبحة"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0">
            <AthkarSectionSvg size={32} />
          </div>
          <div>
            <h2 className="text-xl font-extrabold text-[#5B5FEF] font-tajawal">
              فصل الذكر
            </h2>
            <p className="text-xs text-[#77798C]">موسوعة الأذكار القرآنية والنبوية المأثورة</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs bg-[#4CAF82]/12 text-[#4145C7] font-bold px-3 py-1.5 rounded-full">
            {filteredAthkar.length} ذكر
          </span>
        </div>
      </div>

      {/* Tabs Row: الكل | القرآن الكريم | السنة النبوية | المفضلة */}
      <div className="bg-white rounded-2xl p-1 shadow-sm border border-[#E6E6F0] flex items-center justify-between">
        {[
          { id: 'all', label: 'الكل', count: athkarList.length },
          { id: 'quran', label: 'القرآن الكريم', iconNode: <QuranSectionSvg size={18} /> },
          { id: 'sunnah', label: 'السنة النبوية', iconNode: <AthkarSectionSvg size={18} /> },
          { id: 'favorites', label: 'المفضلة', count: favorites.length },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex-1 py-3 text-center text-sm font-bold transition-all relative rounded-xl ${
                isActive
                  ? 'text-[#4145C7] bg-[#EEEEFF]/70 shadow-xs'
                  : 'text-[#77798C] hover:text-[#25263A]'
              }`}
            >
              <div className="flex items-center justify-center gap-1.5">
                {tab.iconNode}
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className={`text-[11px] px-1.5 py-0.2 rounded-full ${
                    isActive ? 'bg-[#5B5FEF] text-white' : 'bg-gray-100 text-[#77798C]'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </div>
              {isActive && (
                <div className="absolute bottom-0 left-4 right-4 h-[3px] bg-[#5B5FEF] rounded-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* Search Bar & Filters Controls */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E6E6F0] space-y-3">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث في الأذكار والآيات والمصادر..."
            className="w-full bg-[#F7F7FC]/60 border border-[#E6E6F0] rounded-xl py-3 pr-10 pl-4 text-sm text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF] transition-colors"
          />
          <Search className="w-5 h-5 text-gray-400 absolute right-3 top-3.5" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-3 top-3.5 text-xs text-gray-400 hover:text-[#77798C] bg-gray-200 rounded-full w-5 h-5 flex items-center justify-center"
            >
              ✕
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Source Filter */}
          <div className="flex items-center gap-2">
            <span className="text-[#77798C] font-medium">المصدر:</span>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value as typeof sourceFilter)}
              className="bg-[#F7F7FC] border border-[#E6E6F0] rounded-lg px-2.5 py-1.5 text-[#25263A] font-semibold focus:outline-hidden"
            >
              <option value="all">الكل</option>
              <option value="quran">القرآن الكريم</option>
              <option value="sunnah">السنة والأحاديث</option>
            </select>
          </div>

          {/* Sort By */}
          <div className="flex items-center gap-2">
            <span className="text-[#77798C] font-medium">الترتيب:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
              className="bg-[#F7F7FC] border border-[#E6E6F0] rounded-lg px-2.5 py-1.5 text-[#25263A] font-semibold focus:outline-hidden"
            >
              <option value="default">الافتراضي</option>
              <option value="alphabetical">أبجدياً</option>
              <option value="repeats">عدد التكرارات</option>
            </select>
          </div>
        </div>
      </div>

      {/* Athkar Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAthkar.map((item) => {
          const isFav = favorites.includes(item.id);
          const currentProgress = cardCounts[item.id] || 0;
          const isCompleted = currentProgress >= item.countTarget;
          const progressRatio = Math.min(100, Math.round((currentProgress / item.countTarget) * 100));

          return (
            <div
              key={item.id}
              onClick={() => setZoomedDhikr(item)}
              className={`rounded-2xl p-5 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border transition-all duration-300 relative flex flex-col justify-between cursor-pointer group ${
                isCompleted
                  ? 'bg-[#4CAF82]/12/80 border-[#4CAF82]/40 shadow-md'
                  : 'bg-white border-[#E6E6F0] hover:-translate-y-1 hover:shadow-lg hover:border-[#E6E6F0]'
              }`}
            >
              {/* Card Header: Type Badge (Left/Right) & Favorite Star */}
              <div className="flex items-center justify-between mb-3">
                {/* Type Badge in Left/Right corner */}
                <span className={`text-xs px-2.5 py-1 rounded-full font-bold flex items-center gap-1 ${
                  item.category === 'quran'
                    ? 'bg-[#EEEEFF] text-[#5B5FEF]'
                    : 'bg-[#4CAF82]/12 text-[#4145C7]'
                }`}>
                  {item.category === 'quran' ? '📖 آية قرآنية' : '✨ حديث نبوي'}
                </span>

                <div className="flex items-center gap-2">
                  {/* Zoom hint */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setZoomedDhikr(item);
                    }}
                    title="تكبير النص"
                    className="p-1 text-gray-400 hover:text-[#77798C] rounded-lg transition-colors opacity-60 group-hover:opacity-100"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>

                  {/* Favorite Toggle */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite(item.id);
                      showToast(isFav ? 'تمت الإزالة من المفضلة' : 'تمت الإضافة للمفضلة ⭐');
                    }}
                    title={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                    className="p-1 rounded-lg transition-transform active:scale-125"
                  >
                    <Star
                      className={`w-5 h-5 transition-colors ${
                        isFav
                          ? 'text-[#5B5FEF] fill-[#72B7E8]'
                          : 'text-gray-300 hover:text-[#5B5FEF]'
                      }`}
                    />
                  </button>
                </div>
              </div>

              {/* Dhikr Arabic Text in Center (18-20px Brown #25263A) */}
              <div className="my-2">
                <p className="text-lg sm:text-xl font-bold text-[#25263A] leading-relaxed font-tajawal text-center sm:text-right">
                  {item.text}
                </p>
                {item.virtue && (
                  <p className="text-xs text-[#4CAF82] bg-[#4CAF82]/12/70 p-2 rounded-xl mt-3 font-medium border border-emerald-100">
                    💡 <span className="font-bold">الفضل:</span> {item.virtue}
                  </p>
                )}
              </div>

              {/* Source & Target Repeats info */}
              <div className="flex items-center justify-between text-xs pt-3 mt-2 border-t border-[#E6E6F0]">
                <span className="text-[#77798C] font-medium">
                  {item.source}
                </span>
                <span className="text-[#5B5FEF] font-extrabold bg-[#EEEEFF] px-2 py-0.5 rounded-md">
                  التكرار: {item.countTarget} مرات
                </span>
              </div>

              {/* Interactive Mini Counter & Controls */}
              <div className="mt-4 pt-3 border-t border-[#E6E6F0] flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  {/* Left: Copy & Share Buttons */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => handleShare(item, e)}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 text-[#4145C7] border border-[#4CAF82]/40/80 text-xs font-black transition-all cursor-pointer shadow-2xs active:scale-95"
                      title="مشاركة الذكر كبطاقة مصممة أو نص منسق مع بصمة التطبيق"
                    >
                      <Share2 className="w-3.5 h-3.5 text-[#4145C7]" />
                      <span>مشاركة</span>
                    </button>

                    <button
                      onClick={(e) => handleCopy(item.text, e)}
                      className="p-1.5 rounded-xl text-[#77798C] hover:text-[#4145C7] hover:bg-gray-100 border border-[#E6E6F0] transition-colors cursor-pointer"
                      title="نسخ نص الذكر مع بصمة التطبيق"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Center Mini Tasbeeh Counter (+ / -) */}
                  <div className="flex items-center gap-2 bg-[#F7F7FC] p-1 rounded-xl">
                    <button
                      onClick={(e) => handleDecrementCard(item, e)}
                      disabled={currentProgress === 0}
                      className="w-7 h-7 rounded-lg bg-white text-[#77798C] flex items-center justify-center shadow-xs hover:bg-gray-100 disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>

                    <span className="text-xs font-black text-[#4145C7] px-2 min-w-8 text-center">
                      {currentProgress} / {item.countTarget}
                    </span>

                    <button
                      onClick={(e) => handleIncrementCard(item, e)}
                      className="w-7 h-7 rounded-lg bg-[#5B5FEF] text-white flex items-center justify-center shadow-xs hover:bg-[#4145C7] active:scale-95 transition-all"
                    >
                      {isCompleted ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Mini Horizontal Progress Bar */}
                <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      isCompleted ? 'bg-[#5B5FEF]' : 'bg-gradient-to-r from-amber-300 to-[#72B7E8]'
                    }`}
                    style={{ width: `${progressRatio}%` }}
                  />
                </div>
              </div>

              {/* Completed Green Checkmark Overlay Tag */}
              {isCompleted && (
                <div className="absolute top-3 left-3 bg-[#5B5FEF] text-white text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                  <Check className="w-3 h-3" />
                  <span>مكتمل</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {filteredAthkar.length === 0 && (
        <div className="bg-white rounded-2xl p-8 text-center border border-[#E6E6F0] space-y-3">
          <BookOpen className="w-12 h-12 text-gray-300 mx-auto" />
          <h4 className="text-lg font-bold text-[#25263A]">لا توجد أذكار مطابقة</h4>
          <p className="text-xs text-[#77798C]">جرب البحث بكلمات أخرى أو تغيير الفلتر المحدد.</p>
        </div>
      )}

      {/* Zoom Text Modal */}
      {zoomedDhikr && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in"
          onClick={() => setZoomedDhikr(null)}
        >
          <div 
            className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border-2 border-[#E6E6F0] space-y-4 text-center relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setZoomedDhikr(null)}
              className="absolute top-4 left-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-[#77798C] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-xs font-bold text-[#5B5FEF] bg-[#EEEEFF] px-3 py-1 rounded-full inline-block">
              {zoomedDhikr.source}
            </span>

            <p className="text-2xl sm:text-3xl font-black text-[#4145C7] leading-relaxed font-tajawal py-4">
              « {zoomedDhikr.text} »
            </p>

            {zoomedDhikr.virtue && (
              <p className="text-sm text-[#77798C] bg-[#EEEEFF]/70 p-3 rounded-xl border border-[#E6E6F0]">
                {zoomedDhikr.virtue}
              </p>
            )}

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={(e) => handleCopy(zoomedDhikr.text, e)}
                className="px-4 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-[#25263A] text-xs font-bold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
              >
                <Copy className="w-4 h-4 text-[#5B5FEF]" />
                <span>نسخ بالبصمة</span>
              </button>

              <button
                onClick={(e) => {
                  const target = zoomedDhikr;
                  setZoomedDhikr(null);
                  handleShare(target, e);
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:from-[#164e1a] hover:to-[#4CAF82] text-white text-xs font-black shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-amber-200" />
                <span>مشاركة كصورة مصممة أو نص 🎨</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ─── Share Dhikr Modal (Designed Image & Formatted Text) ─── */}
      <DhikrShareModal
        dhikr={selectedDhikrForShare}
        isOpen={!!selectedDhikrForShare}
        onClose={() => setSelectedDhikrForShare(null)}
      />
    </div>
  );
};
