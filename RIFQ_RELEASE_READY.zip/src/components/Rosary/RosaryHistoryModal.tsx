import React, { useState } from 'react';
import { X, History, Trash2, Calendar, Award, AlertCircle } from 'lucide-react';
import { RosarySessionLog, clearAllRosaryData } from '../../utils/rosaryStorage';
import { TasbeehSectionSvg } from '../Home/RifqSectionIcons';

interface RosaryHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  historyLogs: RosarySessionLog[];
  onDataCleared: () => void;
}

export const RosaryHistoryModal: React.FC<RosaryHistoryModalProps> = ({
  isOpen,
  onClose,
  historyLogs,
  onDataCleared,
}) => {
  const [showConfirmClear, setShowConfirmClear] = useState(false);

  if (!isOpen) return null;

  const handleConfirmClear = () => {
    clearAllRosaryData();
    onDataCleared();
    setShowConfirmClear(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" dir="rtl">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/60 backdrop-blur-xs animate-fade-in" onClick={onClose} />

      {/* Modal Card */}
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-[#E6E6F0] overflow-hidden z-10 flex flex-col max-h-[85vh] animate-scale-up">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-amber-300">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-200">سجل التسبيح المبارك</h3>
              <p className="text-[11px] text-emerald-100">الجلسات والدورات المكتملة فعلياً</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {historyLogs.length > 0 && (
              <button
                onClick={() => setShowConfirmClear(true)}
                className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-100 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                title="مسح السجل بالكامل"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">مسح السجل</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3">
          {historyLogs.length === 0 ? (
            <div className="py-12 px-4 text-center">
              <div className="w-16 h-16 rounded-full bg-[#EEEEFF] border border-[#E6E6F0] text-[#4145C7] mx-auto flex items-center justify-center text-2xl mb-3 shadow-inner">
                <TasbeehSectionSvg size={42} />
              </div>
              <h4 className="font-bold text-[#25263A] text-base mb-1">السجل فارغ حالياً</h4>
              <p className="text-xs text-[#77798C] max-w-xs mx-auto leading-relaxed">
                لا توجد دورات مسجلة بعد. عند إتمام دورات التسبيح الحقيقية، ستظهر جلساتك هنا تلقائياً بتوقيتها وتفاصيلها.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {historyLogs.map((log) => (
                <div
                  key={log.id}
                  className="bg-[#F7F7FC]/70 border border-[#E6E6F0] rounded-2xl p-3 flex items-center justify-between shadow-2xs hover:bg-[#F7F7FC] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-white border border-[#E6E6F0] text-[#4145C7] flex items-center justify-center text-sm font-bold shadow-2xs">
                      <Award className="w-4 h-4 text-[#5B5FEF]" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-[#4145C7] font-amiri">
                        {log.dhikrText}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-[#77798C] mt-0.5">
                        <Calendar className="w-3 h-3 text-gray-400" />
                        <span>{log.timestamp}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-left bg-white px-3 py-1.5 rounded-xl border border-[#E6E6F0] shadow-2xs">
                    <span className="text-xs font-black text-[#4145C7] font-mono block">
                      {log.count} تسبيحة
                    </span>
                    <span className="text-[10px] text-[#5B5FEF] font-bold block">
                      دورة مكتملة ({log.target})
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Confirmation Modal for Clearing History */}
        {showConfirmClear && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 z-20 animate-fade-in">
            <div className="bg-white rounded-3xl p-5 max-w-xs w-full text-center space-y-4 shadow-xl border border-red-200">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 mx-auto flex items-center justify-center">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-[#25263A] text-base mb-1">تأكيد مسح السجل</h4>
                <p className="text-xs text-[#77798C] leading-relaxed">
                  هل أنت متأكد من رغبتك في حذف جميع جلسات ودورات التسبيح السابقة؟ لا يمكن التراجع عن هذا الإجراء.
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleConfirmClear}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  نعم، احذف السجل
                </button>
                <button
                  onClick={() => setShowConfirmClear(false)}
                  className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
