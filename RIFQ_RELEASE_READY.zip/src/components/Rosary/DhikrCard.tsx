import React from 'react';
import { ChevronDown, Plus, Sparkles } from 'lucide-react';
import { TasbeehSectionSvg } from '../Home/RifqSectionIcons';

interface DhikrCardProps {
  currentDhikr: string;
  todayCount: number;
  totalCycles: number;
  totalSessions: number;
  onOpenDhikrSelector: () => void;
}

export const DhikrCard: React.FC<DhikrCardProps> = ({
  currentDhikr,
  todayCount,
  totalCycles,
  totalSessions,
  onOpenDhikrSelector,
}) => {
  return (
    <div
      className="w-full bg-white rounded-3xl p-4 shadow-sm border border-[#E6E6F0] relative overflow-hidden"
      dir="rtl"
    >
      {/* Decorative top gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#5B5FEF] via-[#E99AC7] to-[#4CAF82]" />

      {/* Main Dhikr Header Bar */}
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-[#E6E6F0]">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center text-sm font-bold border border-[#E6E6F0]">
            <TasbeehSectionSvg size={26} />
          </div>
          <div>
            <span className="text-[11px] text-gray-400 font-bold block">الذكر الحالي</span>
            <h2 className="text-lg md:text-xl font-black text-[#4145C7] font-amiri leading-tight">
              {currentDhikr}
            </h2>
          </div>
        </div>

        {/* Change Dhikr Selector Button */}
        <button
          onClick={onOpenDhikrSelector}
          className="px-3 py-1.5 bg-[#EEEEFF] hover:bg-[#EEEEFF] text-[#4145C7] text-xs font-bold rounded-xl border border-[#E6E6F0] flex items-center gap-1 transition-colors cursor-pointer"
          title="تغيير الذكر أو إضافة ذكر مخصص"
        >
          <span>تغيير الذكر</span>
          <ChevronDown className="w-3.5 h-3.5 text-[#5B5FEF]" />
        </button>
      </div>

      {/* Real Statistics 3-Pill Strip (Calculated Strictly From Real Data) */}
      <div className="grid grid-cols-3 gap-2 pt-3 text-center">
        {/* Today's Count */}
        <div className="bg-[#F7F7FC]/70 rounded-2xl p-2 border border-[#E6E6F0]">
          <span className="text-[11px] text-[#77798C] font-medium block">تسبيحات اليوم</span>
          <span className="text-lg font-black text-[#4145C7] font-mono mt-0.5 block">
            {todayCount}
          </span>
        </div>

        {/* Real Completed Cycles */}
        <div className="bg-[#F7F7FC]/70 rounded-2xl p-2 border border-[#E6E6F0]">
          <span className="text-[11px] text-[#77798C] font-medium block">الدورات</span>
          <span className="text-lg font-black text-[#5B5FEF] font-mono mt-0.5 block">
            {totalCycles}
          </span>
        </div>

        {/* Real Sessions */}
        <div className="bg-[#F7F7FC]/70 rounded-2xl p-2 border border-[#E6E6F0]">
          <span className="text-[11px] text-[#77798C] font-medium block">الجلسات</span>
          <span className="text-lg font-black text-[#4CAF82] font-mono mt-0.5 block">
            {totalSessions}
          </span>
        </div>
      </div>
    </div>
  );
};
