import React, { useState, useEffect } from 'react';
import {
  X,
  Check,
  Plus,
  Trash2,
  Sparkles,
  Edit3,
  BookOpen,
  Calendar,
  Layers,
  Search,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Tag
} from 'lucide-react';
import { DEFAULT_DHIKR_LIST } from '../../utils/rosaryStorage';
import {
  initMisbahaSqliteTables,
  addCustomDhikrToSqlite,
  updateCustomDhikrInSqlite,
  deleteCustomDhikrFromSqlite,
  CustomAdhkarSqliteRow,
  WirdCategoryType,
  PREDEFINED_WIRD_CATEGORIES,
  loadUserCustomWirdCategories,
  addUserCustomWirdCategory
} from '../../utils/misbahaSqlite';
import {
  loadCustomAthkar,
  addCustomDhikr,
  updateCustomDhikr,
  deleteCustomDhikr
} from '../../utils/storage';
import { TasbeehSectionSvg } from '../Home/RifqSectionIcons';
import { soundManager } from '../../utils/audio';

interface DhikrSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDhikr: string;
  onSelectDhikr: (text: string, defaultTarget?: number) => void;
}

const PROPHETIC_CUSTOM_TEMPLATES = [
  {
    label: 'لا حول ولا قوة إلا بالله',
    text: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ',
    target: 100,
    wirdType: 'daily' as WirdCategoryType,
    listName: 'ورد التسبيح اليومي العام',
    notes: 'كنز من كنوز الجنة ودواء للهم والغم وقضاء الحوائج',
  },
  {
    label: 'حسبنا الله ونعم الوكيل',
    text: 'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ',
    target: 100,
    wirdType: 'special_occasion' as WirdCategoryType,
    listName: 'ورد تفريج الكرب والهم والشدائد',
    notes: 'أمان لكل خائف ومكروب ووقاية من كل سوء',
  },
  {
    label: 'دعاء ليلة القدر والعفو',
    text: 'اللَّهُمَّ إِنَّكَ عَفُوٌّ كَرِيمٌ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي',
    target: 100,
    wirdType: 'special_occasion' as WirdCategoryType,
    listName: 'ورد شهر رمضان وليالي القدر',
    notes: 'وصية رسول الله ﷺ لأم المؤمنين عائشة رضي الله عنها',
  },
  {
    label: 'دعوة ذي النون (يونس عليه السلام)',
    text: 'لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
    target: 100,
    wirdType: 'special_occasion' as WirdCategoryType,
    listName: 'ورد تفريج الكرب والهم والشدائد',
    notes: 'لم يدعُ بها مسلم في شيء قط إلا استجاب الله له',
  },
  {
    label: 'سيد الاستغفار',
    text: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ خَلَقْتَنِي وَأَنَا عَبْدُكَ',
    target: 33,
    wirdType: 'daily' as WirdCategoryType,
    listName: 'ورد الصباح والمساء',
    notes: 'من قالها موقناً بها فمات من يومه أو ليلته دخل الجنة',
  },
  {
    label: 'الصلاة الإبراهيمية المباركة',
    text: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ',
    target: 100,
    wirdType: 'special_occasion' as WirdCategoryType,
    listName: 'ورد يوم الجمعة المباركة',
    notes: 'صلاة الله بها عشراً وحط عشر خطيئات ورفع عشر درجات',
  },
  {
    label: 'استغفار الأسحار وقيام الليل',
    text: 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ',
    target: 100,
    wirdType: 'daily' as WirdCategoryType,
    listName: 'ورد قيام الليل والاستغفار بالأسحار',
    notes: 'غُفرت ذنوبه وإن كان فر من الزحف',
  },
];

export const DhikrSelectorModal: React.FC<DhikrSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedDhikr,
  onSelectDhikr,
}) => {
  const [activeTab, setActiveTab] = useState<'builtin' | 'custom'>('builtin');
  const [customList, setCustomList] = useState<CustomAdhkarSqliteRow[]>([]);
  const [wirdFilter, setWirdFilter] = useState<'all' | WirdCategoryType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Add new state
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newDhikrText, setNewDhikrText] = useState('');
  const [newDhikrTarget, setNewDhikrTarget] = useState<number>(100);
  const [newWirdType, setNewWirdType] = useState<WirdCategoryType>('daily');
  const [newListName, setNewListName] = useState<string>('ورد التسبيح اليومي العام');
  const [customListNameInput, setCustomListNameInput] = useState<string>('');
  const [newDhikrNotes, setNewDhikrNotes] = useState<string>('');

  // Edit state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [editTarget, setEditTarget] = useState(100);
  const [editWirdType, setEditWirdType] = useState<WirdCategoryType>('daily');
  const [editListName, setEditListName] = useState('');
  const [editNotes, setEditNotes] = useState('');

  // Delete confirmation
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Load custom adhkar from sqlite & storage
  const reloadCustomAdhkar = () => {
    const tables = initMisbahaSqliteTables();
    setCustomList([...tables.customAdhkar]);
  };

  useEffect(() => {
    if (isOpen) {
      reloadCustomAdhkar();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Available categories list
  const userCustomWirds = loadUserCustomWirdCategories();
  const availableCategories = [
    ...PREDEFINED_WIRD_CATEGORIES.map((c) => ({
      name: c.name,
      type: c.type,
      icon: c.icon,
    })),
    ...userCustomWirds.map((w) => ({
      name: w,
      type: 'custom' as WirdCategoryType,
      icon: '✨',
    })),
  ];

  const handleSaveNewDhikr = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDhikrText.trim()) return;

    const finalListName =
      newWirdType === 'custom' && customListNameInput.trim()
        ? customListNameInput.trim()
        : newListName;

    if (newWirdType === 'custom' && customListNameInput.trim()) {
      addUserCustomWirdCategory(customListNameInput.trim());
    }

    // Save to SQLite
    const updatedSqlite = addCustomDhikrToSqlite(
      newDhikrText.trim(),
      newDhikrTarget,
      finalListName,
      newWirdType,
      newDhikrNotes.trim()
    );

    // Sync to storage
    addCustomDhikr({
      text: newDhikrText.trim(),
      countTarget: newDhikrTarget,
      category: 'custom',
      source: finalListName,
      virtue: newDhikrNotes.trim() || undefined,
    });

    setCustomList([...updatedSqlite]);
    soundManager.playBeadClick(0.8, 'wood');
    soundManager.triggerHaptic(40);

    onSelectDhikr(newDhikrText.trim(), newDhikrTarget);
    setNewDhikrText('');
    setCustomListNameInput('');
    setNewDhikrNotes('');
    setIsAddingNew(false);
  };

  const handleStartEdit = (item: CustomAdhkarSqliteRow) => {
    setEditingId(item.id);
    setEditText(item.text);
    setEditTarget(item.target);
    setEditWirdType(item.wird_type || 'daily');
    setEditListName(item.list_name || 'أذكار عامة');
    setEditNotes(item.notes || '');
  };

  const handleSaveEdit = (id: string) => {
    if (!editText.trim()) return;

    if (editWirdType === 'custom' && editListName.trim()) {
      addUserCustomWirdCategory(editListName.trim());
    }

    const updated = updateCustomDhikrInSqlite(id, {
      text: editText.trim(),
      target: editTarget,
      wird_type: editWirdType,
      list_name: editListName.trim(),
      notes: editNotes.trim(),
    });

    updateCustomDhikr(id, {
      text: editText.trim(),
      countTarget: editTarget,
      source: editListName.trim(),
      virtue: editNotes.trim() || undefined,
    });

    setCustomList([...updated]);
    setEditingId(null);
    soundManager.playBeadClick(0.7, 'wood');
    soundManager.triggerHaptic(25);
  };

  const handleDeleteDhikr = (id: string) => {
    const updated = deleteCustomDhikrFromSqlite(id);
    deleteCustomDhikr(id);
    setCustomList([...updated]);
    setDeleteConfirmId(null);
    soundManager.triggerHaptic(35);
  };

  // Filtered built-in adhkar
  const filteredBuiltin = DEFAULT_DHIKR_LIST.filter((item) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return item.text.toLowerCase().includes(q) || item.title.toLowerCase().includes(q);
  });

  // Filtered custom adhkar
  const filteredCustom = customList.filter((item) => {
    const matchesFilter = wirdFilter === 'all' || item.wird_type === wirdFilter;
    if (!matchesFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      item.text.toLowerCase().includes(q) ||
      item.list_name.toLowerCase().includes(q) ||
      (item.notes && item.notes.toLowerCase().includes(q))
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4" dir="rtl">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/65 backdrop-blur-xs animate-fade-in"
        onClick={onClose}
      />

      {/* Modal Card */}
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-[#E6E6F0] overflow-hidden z-10 flex flex-col max-h-[90vh] animate-scale-up">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#5B5FEF] via-[#4145C7] to-[#4145C7] p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/15 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-amber-200 font-cairo">
                أذكار وأوراد المسبحة المباركة
              </h3>
              <p className="text-[11px] text-emerald-100">
                اختر ذكراً مأثوراً أو أنشئ وردك اليومي والمناسبات الخاصة
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="p-3 bg-[#F7F7FC] border-b border-[#E6E6F0] flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setActiveTab('builtin');
              setSearchQuery('');
            }}
            className={`flex-1 py-2 px-3 rounded-xl font-cairo font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'builtin'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'bg-white text-[#25263A] hover:bg-[#EEEEFF] border border-[#E6E6F0]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>الأذكار المأثورة الراتبة</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('custom');
              setSearchQuery('');
            }}
            className={`flex-1 py-2 px-3 rounded-xl font-cairo font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'custom'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'bg-white text-[#25263A] hover:bg-[#EEEEFF] border border-[#E6E6F0]'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>أذكاري وأورادي المخصصة ({customList.length})</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="px-4 pt-2.5 pb-1 bg-white border-b border-[#E6E6F0]/60">
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                activeTab === 'builtin'
                  ? 'ابحث في الأذكار النبوية المأثورة...'
                  : 'ابحث في أذكارك المخصصة بنص الذكر أو اسم الورد...'
              }
              className="w-full bg-[#F7F7FC] hover:bg-[#EEEEFF]/40 focus:bg-white border border-[#E6E6F0] focus:border-[#5B5FEF] rounded-xl py-2 pr-9 pl-8 text-xs font-cairo text-[#25263A] focus:outline-hidden transition-all placeholder:text-[#77798C]"
            />
            <Search className="w-4 h-4 text-[#77798C] absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 p-0.5 text-gray-400 hover:text-gray-600 rounded-full cursor-pointer"
                title="مسح البحث"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 overflow-y-auto space-y-3.5 flex-1">
          {/* TAB 1: BUILT-IN ADHKAR */}
          {activeTab === 'builtin' && (
            <div className="space-y-2">
              <span className="text-xs font-bold text-[#77798C] block px-1">
                اختر من الأذكار النبوية المعتمدة ({filteredBuiltin.length}):
              </span>
              <div className="space-y-2">
                {filteredBuiltin.map((item) => {
                  const isSelected = selectedDhikr === item.text;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectDhikr(item.text, item.defaultTarget);
                        onClose();
                      }}
                      className={`w-full p-3.5 rounded-2xl flex items-center justify-between transition-all text-right cursor-pointer ${
                        isSelected
                          ? 'bg-[#4CAF82]/12 border-2 border-[#5B5FEF] text-[#4145C7] shadow-xs'
                          : 'bg-white hover:bg-[#F7F7FC] border border-[#E6E6F0] text-[#25263A]'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center shrink-0">
                          <TasbeehSectionSvg size={24} />
                        </span>
                        <div>
                          <h4 className="font-bold text-sm font-amiri text-[#4145C7] leading-relaxed">
                            {item.text}
                          </h4>
                          <span className="text-[11px] text-[#77798C] block mt-0.5 font-cairo">
                            {item.title} • الهدف الافتراضي {item.defaultTarget} مرة
                          </span>
                        </div>
                      </div>

                      {isSelected && (
                        <div className="w-6 h-6 rounded-full bg-[#5B5FEF] text-white flex items-center justify-center shrink-0">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {filteredBuiltin.length === 0 && (
                <div className="py-8 text-center text-xs text-gray-500 bg-gray-50 rounded-2xl p-4">
                  لا توجد نتائج مطابقة لبحثك في الأذكار الراتبة
                </div>
              )}

              {/* Quick switch to add custom wird */}
              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('custom');
                    setIsAddingNew(true);
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-[#5B5FEF] hover:underline cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>تريد إضافة ذكر أو ورد مخصص خاص بك؟ اضغط هنا</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: CUSTOM ADHKAR & WIRDS */}
          {activeTab === 'custom' && (
            <div className="space-y-3.5">
              {/* Category Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
                <button
                  type="button"
                  onClick={() => setWirdFilter('all')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors ${
                    wirdFilter === 'all'
                      ? 'bg-[#5B5FEF] text-white shadow-2xs'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  الكل ({customList.length})
                </button>

                <button
                  type="button"
                  onClick={() => setWirdFilter('daily')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1 ${
                    wirdFilter === 'daily'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-amber-50 text-amber-900 border border-amber-200'
                  }`}
                >
                  <span>🌅</span>
                  <span>أوراد يومية</span>
                </button>

                <button
                  type="button"
                  onClick={() => setWirdFilter('special_occasion')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1 ${
                    wirdFilter === 'special_occasion'
                      ? 'bg-purple-600 text-white shadow-2xs'
                      : 'bg-purple-50 text-purple-900 border border-purple-200'
                  }`}
                >
                  <span>🌙</span>
                  <span>مناسبات خاصة</span>
                </button>

                <button
                  type="button"
                  onClick={() => setWirdFilter('custom')}
                  className={`px-3 py-1.5 rounded-xl font-cairo font-bold whitespace-nowrap cursor-pointer transition-colors flex items-center gap-1 ${
                    wirdFilter === 'custom'
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                  }`}
                >
                  <span>✨</span>
                  <span>أوراد خاصة بي</span>
                </button>
              </div>

              {/* Add New Button Toggle & Quick Templates */}
              {!isAddingNew ? (
                <div className="space-y-2.5">
                  <button
                    type="button"
                    onClick={() => setIsAddingNew(true)}
                    className="w-full py-3 px-4 bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-[#5B5FEF]/10 border border-dashed border-[#5B5FEF] hover:bg-[#EEEEFF] text-[#4145C7] font-bold text-xs rounded-2xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs"
                  >
                    <Plus className="w-4 h-4 text-[#5B5FEF]" />
                    <span>إضافة وتخصيص ذكر أو ورد جديد</span>
                  </button>

                  {/* نماذج مقترحة سريعة للاقتباس والتخصيص */}
                  <div className="p-3 bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0] space-y-1.5">
                    <span className="text-[11px] font-bold text-[#77798C] flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-amber-500" />
                      <span>اقتبس من هذه النماذج بلمسة واحدة:</span>
                    </span>
                    <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
                      {PROPHETIC_CUSTOM_TEMPLATES.slice(0, 5).map((tpl, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setIsAddingNew(true);
                            setNewDhikrText(tpl.text);
                            setNewDhikrTarget(tpl.target);
                            setNewWirdType(tpl.wirdType);
                            setNewListName(tpl.listName);
                            setNewDhikrNotes(tpl.notes);
                            soundManager.triggerHaptic(20);
                          }}
                          className="px-2.5 py-1 bg-white hover:bg-[#EEEEFF] border border-[#E6E6F0] hover:border-[#5B5FEF] rounded-lg text-[#25263A] whitespace-nowrap font-bold transition-all cursor-pointer"
                        >
                          {tpl.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* Add Custom Dhikr Form */
                <form
                  onSubmit={handleSaveNewDhikr}
                  className="p-4 bg-amber-50/70 border border-amber-300/80 rounded-2xl space-y-3 animate-fade-in"
                >
                  <div className="flex items-center justify-between border-b border-amber-200 pb-2">
                    <span className="font-bold text-xs text-[#25263A] flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-[#5B5FEF]" />
                      <span>إنشاء ذكر مخصص وتحديد الورد والهدف</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsAddingNew(false)}
                      className="text-gray-400 hover:text-gray-600 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Dhikr Text Input */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-gray-700 block">
                      نص الذكر أو الدعاء المبارك:
                    </label>
                    <textarea
                      rows={2}
                      required
                      value={newDhikrText}
                      onChange={(e) => setNewDhikrText(e.target.value)}
                      placeholder="اكتب صيغة الذكر (مثلاً: رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ...)"
                      className="w-full bg-white border border-gray-300 focus:border-[#5B5FEF] rounded-xl p-2.5 font-amiri text-base focus:outline-hidden leading-relaxed"
                    />
                  </div>

                  {/* Target Repetitions */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-gray-700 block">
                      عدد التكرارات المستهدف:
                    </label>
                    <div className="flex items-center gap-2 flex-wrap">
                      <input
                        type="number"
                        min="0"
                        max="10000"
                        value={newDhikrTarget}
                        onChange={(e) => setNewDhikrTarget(parseInt(e.target.value, 10) || 0)}
                        className="w-24 bg-white border border-gray-300 rounded-xl p-2 text-xs font-mono font-bold text-center"
                      />
                      <div className="flex gap-1 flex-wrap">
                        {[33, 100, 300, 500, 1000, 0].map((t) => (
                          <button
                            key={t}
                            type="button"
                            onClick={() => setNewDhikrTarget(t)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition-colors ${
                              newDhikrTarget === t
                                ? 'bg-[#5B5FEF] text-white'
                                : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                            }`}
                          >
                            {t === 0 ? 'مفتوح ∞' : t}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Wird Type & Category */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-gray-700 block">
                      تصنيف الورد أو المناسبة:
                    </label>
                    <div className="grid grid-cols-3 gap-1.5 text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          setNewWirdType('daily');
                          setNewListName('ورد التسبيح اليومي العام');
                        }}
                        className={`p-2 rounded-xl text-center font-bold border transition-colors cursor-pointer ${
                          newWirdType === 'daily'
                            ? 'bg-amber-500 text-white border-amber-600'
                            : 'bg-white text-gray-700 border-gray-200'
                        }`}
                      >
                        <span className="block text-sm">🌅</span>
                        <span className="text-[10px] block mt-0.5">ورد يومي</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setNewWirdType('special_occasion');
                          setNewListName('ورد يوم الجمعة المباركة');
                        }}
                        className={`p-2 rounded-xl text-center font-bold border transition-colors cursor-pointer ${
                          newWirdType === 'special_occasion'
                            ? 'bg-purple-600 text-white border-purple-700'
                            : 'bg-white text-gray-700 border-gray-200'
                        }`}
                      >
                        <span className="block text-sm">🌙</span>
                        <span className="text-[10px] block mt-0.5">مناسبة خاصة</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setNewWirdType('custom');
                          setCustomListNameInput('');
                        }}
                        className={`p-2 rounded-xl text-center font-bold border transition-colors cursor-pointer ${
                          newWirdType === 'custom'
                            ? 'bg-emerald-600 text-white border-emerald-700'
                            : 'bg-white text-gray-700 border-gray-200'
                        }`}
                      >
                        <span className="block text-sm">✨</span>
                        <span className="text-[10px] block mt-0.5">ورد مخصص</span>
                      </button>
                    </div>

                    {/* Predefined or Custom name selector */}
                    {newWirdType !== 'custom' ? (
                      <select
                        value={newListName}
                        onChange={(e) => setNewListName(e.target.value)}
                        className="w-full bg-white border border-gray-300 rounded-xl p-2 text-xs font-bold mt-1 text-gray-700 focus:outline-hidden"
                      >
                        {availableCategories
                          .filter((c) => c.type === newWirdType)
                          .map((c) => (
                            <option key={c.name} value={c.name}>
                              {c.icon} {c.name}
                            </option>
                          ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        placeholder="اكتب اسم الورد المخصص (مثلاً: ورد قيام الليل، ورد الشفاء، ورد الاختبارات)"
                        value={customListNameInput}
                        onChange={(e) => setCustomListNameInput(e.target.value)}
                        className="w-full bg-white border border-gray-300 rounded-xl p-2 text-xs font-bold mt-1 text-gray-700 focus:outline-hidden"
                        required
                      />
                    )}
                  </div>

                  {/* Optional Notes / Virtue */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-gray-700 block">
                      فضله أو النية والمناسبة (اختياري):
                    </label>
                    <input
                      type="text"
                      placeholder="مثال: يقال عند ضيق الصدر، أو بعد صلاة العصر"
                      value={newDhikrNotes}
                      onChange={(e) => setNewDhikrNotes(e.target.value)}
                      className="w-full bg-white border border-gray-300 rounded-xl p-2 text-xs focus:outline-hidden"
                    />
                  </div>

                  {/* Buttons */}
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="submit"
                      className="flex-1 py-2 bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>حفظ الذكر والبدء به فوراً</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsAddingNew(false)}
                      className="px-3.5 py-2 bg-gray-200 text-gray-700 font-bold rounded-xl text-xs cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                </form>
              )}

              {/* Custom Adhkar List */}
              {filteredCustom.length === 0 ? (
                <div className="py-8 text-center bg-gray-50 rounded-2xl border border-gray-200 p-4">
                  <span className="text-3xl block mb-2">🤲</span>
                  <p className="font-bold text-xs text-gray-700">
                    لا توجد أذكار محفوظة في هذا التصنيف
                  </p>
                  <p className="text-[11px] text-gray-400 mt-1">
                    أضف ذكرك الخاص بسهولة وسجل وردك اليومي أو لمناسباتك
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {filteredCustom.map((item) => {
                    const isSelected = selectedDhikr === item.text;
                    const isEditing = editingId === item.id;
                    const isConfirmingDelete = deleteConfirmId === item.id;

                    if (isEditing) {
                      return (
                        <div
                          key={item.id}
                          className="p-3.5 bg-blue-50/70 border border-blue-200 rounded-2xl space-y-2.5 animate-fade-in"
                        >
                          <span className="font-bold text-xs text-blue-900 block">تعديل الذكر المخصص</span>
                          <textarea
                            rows={2}
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            className="w-full bg-white border border-blue-300 rounded-xl p-2 text-xs font-amiri text-base focus:outline-hidden"
                          />
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <label className="text-[10px] text-gray-500 block">الهدف (التكرارات):</label>
                              <input
                                type="number"
                                min="0"
                                max="10000"
                                value={editTarget}
                                onChange={(e) =>
                                  setEditTarget(parseInt(e.target.value, 10) || 0)
                                }
                                className="w-full bg-white border border-gray-300 rounded-lg p-1.5 text-center font-bold"
                              />
                            </div>
                            <div>
                              <label className="text-[10px] text-gray-500 block">نوع الورد:</label>
                              <select
                                value={editWirdType}
                                onChange={(e) =>
                                  setEditWirdType(e.target.value as WirdCategoryType)
                                }
                                className="w-full bg-white border border-gray-300 rounded-lg p-1.5 text-xs font-bold"
                              >
                                <option value="daily">ورد يومي 🌅</option>
                                <option value="special_occasion">مناسبة خاصة 🌙</option>
                                <option value="custom">ورد مخصص ✨</option>
                              </select>
                            </div>
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-500 block">اسم الورد:</label>
                            <input
                              type="text"
                              value={editListName}
                              onChange={(e) => setEditListName(e.target.value)}
                              className="w-full bg-white border border-gray-300 rounded-lg p-1.5 text-xs font-bold"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-gray-500 block">فضل الذكر أو النية:</label>
                            <input
                              type="text"
                              value={editNotes}
                              onChange={(e) => setEditNotes(e.target.value)}
                              className="w-full bg-white border border-gray-300 rounded-lg p-1.5 text-xs"
                            />
                          </div>
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => handleSaveEdit(item.id)}
                              className="flex-1 py-1.5 bg-[#5B5FEF] text-white text-xs font-bold rounded-xl cursor-pointer"
                            >
                              حفظ التعديل
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingId(null)}
                              className="px-3 py-1.5 bg-gray-200 text-gray-700 text-xs font-bold rounded-xl cursor-pointer"
                            >
                              إلغاء
                            </button>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={item.id}
                        className={`p-3.5 rounded-2xl border transition-all ${
                          isSelected
                            ? 'bg-[#4CAF82]/12 border-2 border-[#5B5FEF] shadow-2xs'
                            : 'bg-white hover:bg-gray-50 border-[#E6E6F0]'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                  item.wird_type === 'special_occasion'
                                    ? 'bg-purple-100 text-purple-900 border-purple-200'
                                    : item.wird_type === 'custom'
                                    ? 'bg-emerald-100 text-emerald-900 border-emerald-200'
                                    : 'bg-amber-100 text-amber-900 border-amber-200'
                                }`}
                              >
                                {item.wird_type === 'special_occasion'
                                  ? '🌙 مناسبة خاصة'
                                  : item.wird_type === 'custom'
                                  ? '✨ ورد مخصص'
                                  : '🌅 ورد يومي'}
                              </span>

                              <span className="text-[10px] text-gray-500 font-medium">
                                {item.list_name}
                              </span>
                            </div>

                            <p className="font-amiri text-base font-bold text-[#25263A] leading-relaxed">
                              {item.text}
                            </p>

                            {item.notes && (
                              <p className="text-[11px] text-[#77798C] mt-1 font-serif">
                                {item.notes}
                              </p>
                            )}

                            <div className="flex items-center gap-2 mt-2 text-[11px] text-[#77798C]">
                              <span className="font-bold text-[#5B5FEF]">
                                الهدف: {item.target === 0 ? 'مفتوح ∞' : `${item.target} مرة`}
                              </span>
                              <span>•</span>
                              <span>الاستخدام: {item.usage_count || 0}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                onSelectDhikr(item.text, item.target);
                                onClose();
                              }}
                              className="px-3 py-1.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-bold cursor-pointer transition-colors shadow-2xs"
                            >
                              تسبيح الآن
                            </button>

                            <button
                              type="button"
                              onClick={() => handleStartEdit(item)}
                              className="p-1.5 text-gray-400 hover:text-[#5B5FEF] hover:bg-gray-100 rounded-lg cursor-pointer transition-colors"
                              title="تعديل الذكر"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => setDeleteConfirmId(item.id)}
                              className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                              title="حذف الذكر"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Delete confirmation dialog */}
                        {isConfirmingDelete && (
                          <div className="mt-2.5 p-2.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-900 animate-fade-in">
                            <span className="font-bold">هل أنت متأكد من حذف هذا الذكر؟</span>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleDeleteDhikr(item.id)}
                                className="px-2.5 py-1 bg-rose-600 text-white rounded-lg font-bold text-xs cursor-pointer"
                              >
                                نعم، احذف
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteConfirmId(null)}
                                className="px-2 py-1 bg-gray-200 text-gray-700 rounded-lg font-bold text-xs cursor-pointer"
                              >
                                تراجع
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
