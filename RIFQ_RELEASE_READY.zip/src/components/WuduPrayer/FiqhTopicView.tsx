import React from 'react';
import { ArrowRight, BookOpen, AlertCircle, Sparkles, CheckCircle2 } from 'lucide-react';
import { WuduPrayerIllustration } from './WuduPrayerIllustration';

interface FiqhTopicProps {
  id: string;
  onBack: () => void;
  onGoToSection: (sectionId: string) => void;
}

export const FiqhTopicView: React.FC<FiqhTopicProps> = ({ id, onBack, onGoToSection }) => {
  // Return tailored authentic fiqh content depending on the topic
  let title = '';
  let icon = '📖';
  let badge = 'أحكام فقهية موثقة';
  let contentNode: React.ReactNode = null;

  switch (id) {
    case 'rukoo_sujood':
      title = 'أحكام الركوع والسجود والطمأنينة';
      icon = '🧎';
      contentNode = (
        <div className="space-y-4">
          <div className="flex justify-center py-2">
            <WuduPrayerIllustration type="rukoo" size={170} />
          </div>
          <div className="p-4 rounded-[16px] bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] space-y-2">
            <h4 className="font-bold text-sm text-[#4145C7] dark:text-amber-300">صفة الركوع الصحيحة:</h4>
            <p className="text-xs md:text-sm text-[#25263A] dark:text-stone-300 leading-relaxed font-tajawal">
              ينحني المصلي حتى يستوي ظهره مع رأسه فلا يرفعه ولا ينكسه، ويضع كفيه على ركبتيه كالقابض عليهما مفرجاً أصابعه، ويجافي مرفقيه عن جنبيه.
            </p>
          </div>
          <div className="flex justify-center py-2">
            <WuduPrayerIllustration type="sujood" size={170} />
          </div>
          <div className="p-4 rounded-[16px] bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] space-y-2">
            <h4 className="font-bold text-sm text-[#4145C7] dark:text-amber-300">صفة السجود والأعضاء السبعة:</h4>
            <p className="text-xs md:text-sm text-[#25263A] dark:text-stone-300 leading-relaxed font-tajawal">
              السجود ركن عظيم وأقرب ما يكون العبد من ربه وهو ساجد. يجب السجود على: الجبهة والأنف، والكفين، والركبتين، وأطراف أصابع القدمين متجهة للقبلة.
            </p>
          </div>
        </div>
      );
      break;

    case 'nawaqid_wudu':
      title = 'نواقض الوضوء (مبطلات الطهارة)';
      icon = '⚠️';
      contentNode = (
        <div className="space-y-3">
          <div className="p-4 rounded-[16px] bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-xs md:text-sm text-red-900 dark:text-red-200 space-y-2">
            <div className="font-bold text-sm flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <span>الأمور المتفق عليها التي تنقض الوضوء وتوجب إعادته:</span>
            </div>
            <ul className="list-disc list-inside space-y-1.5 leading-relaxed">
              <li><strong>الخارج من السبيلين:</strong> بول، غائط، ريح، أو مذي (بالإجماع).</li>
              <li><strong>النوم المستغرق:</strong> الذي يزول معه الإدراك والشعور، أما النعاس الخفيف فلا ينقض.</li>
              <li><strong>زوال العقل:</strong> بالإغماء، أو السُّكر، أو البنج أو الجنون.</li>
              <li><strong>مس الفرج باليد مباشرة:</strong> بشهوة وبدون حائل عند جمهور الفقهاء.</li>
              <li><strong>أكل لحم الإبل:</strong> لحديث البراء بن عازب: «توضؤوا من لحوم الإبل» (صحيح مسلم).</li>
            </ul>
          </div>
          <div className="p-3 bg-stone-50 dark:bg-stone-900 rounded-xl text-xs text-[#77798C] dark:text-stone-400">
            * تنبيه: خروج الدم القليل من الجرح أو لمس الأشياء الطاهرة لا ينقض الوضوء.
          </div>
        </div>
      );
      break;

    case 'mubtilat_salah':
      title = 'مبطلات الصلاة ومفسداتها';
      icon = '⚠️';
      contentNode = (
        <div className="space-y-3">
          <div className="p-4 rounded-[16px] bg-[#EEEEFF] dark:bg-amber-950/40 border border-[#E6E6F0] dark:border-amber-800 text-xs md:text-sm text-amber-950 dark:text-amber-200 space-y-2">
            <div className="font-bold text-sm flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-[#4145C7]" />
              <span>مبطلات الصلاة التي توجب قطعها وإعادتها:</span>
            </div>
            <ul className="list-disc list-inside space-y-1.5 leading-relaxed">
              <li><strong>الكلام العمد:</strong> لغير مصلحة الصلاة (لقوله تعالى: ﴿وَقُومُوا لِلَّهِ قَانِتِينَ﴾).</li>
              <li><strong>الضحك والقهقهة:</strong> تبطل الصلاة بإجماع العلماء.</li>
              <li><strong>الأكل والشرب عمداً:</strong> مهما كان قليلاً.</li>
              <li><strong>انكشاف العورة عمداً:</strong> أو بغير عمد إذا طال الوقت.</li>
              <li><strong>الحدث:</strong> خروج ريح أو بول أثناء الصلاة ينقض الطهارة فوراً.</li>
              <li><strong>الحركة الكثيرة المتوالية:</strong> لغير ضرورة الصلاة.</li>
              <li><strong>ترك ركن أو شرط عمداً:</strong> مثل ترك الركوع أو السجود أو استقبال القبلة.</li>
            </ul>
          </div>
        </div>
      );
      break;

    case 'ghusl':
      title = 'صفة الغسل الشرعي الكامل';
      icon = '🚿';
      contentNode = (
        <div className="space-y-4">
          <div className="flex justify-center py-2">
            <WuduPrayerIllustration type="ghusl" size={170} />
          </div>
          <div className="p-4 rounded-[16px] bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] space-y-2">
            <h4 className="font-bold text-sm text-[#4145C7] dark:text-amber-300">خطوات الغسل النبوي الشريف:</h4>
            <ol className="list-decimal list-inside space-y-2 text-xs md:text-sm text-[#25263A] dark:text-stone-300 leading-relaxed font-tajawal">
              <li>استحضار النية بقلبه والتسمية.</li>
              <li>غسل الكفين ثلاث مرات وغسل الفرج وإزالة الأذى.</li>
              <li>الوضوء كاملاً كوضوء الصلاة (وقد يؤخر غسل القدمين).</li>
              <li>حثي الماء على الرأس ثلاث مرات حتى يروي أصول الشعر.</li>
              <li>إفاضة الماء على سائر الجسد، مبدوءاً بالشق الأيمن ثم الأيسر، مع تدليك ما يستطاع وتخليل الأصابع.</li>
            </ol>
          </div>
        </div>
      );
      break;

    case 'jamaah':
      title = 'صلاة الجماعة وآداب المسجد';
      icon = '🕌';
      contentNode = (
        <div className="space-y-4">
          <div className="flex justify-center py-2">
            <WuduPrayerIllustration type="jamaah" size={170} />
          </div>
          <div className="p-4 rounded-[16px] bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] space-y-2">
            <h4 className="font-bold text-sm text-[#4145C7] dark:text-amber-300">فضل صلاة الجماعة وقواعدها:</h4>
            <p className="text-xs md:text-sm text-[#25263A] dark:text-stone-300 leading-relaxed font-tajawal">
              «صلاة الجماعة تفضل صلاة الفذ بسبع وعشرين درجة» (صحيح البخاري).
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-xs md:text-sm text-[#25263A] dark:text-stone-300 leading-relaxed">
              <li><strong>متابعة الإمام:</strong> يكبر المأموم بعد تكبير الإمام، ولا يسابقه ولا يوافقه، بل يعقبه فوراً.</li>
              <li><strong>تسوية الصفوف:</strong> قال ﷺ: «سَوُّوا صُفُوفَكُمْ، فَإِنَّ تَسْوِيَةَ الصُّفُوفِ مِنْ إِقَامَةِ الصَّلاَةِ».</li>
              <li><strong>إدراك الركعة:</strong> يُدرك المأموم الركعة إذا أدرك الإمام في الركوع واطمأن معه قبل الرفع.</li>
            </ul>
          </div>
        </div>
      );
      break;

    case 'witr':
      title = 'صلاة الوتر وقيام الليل';
      icon = '🌙';
      contentNode = (
        <div className="space-y-4">
          <div className="flex justify-center py-2">
            <WuduPrayerIllustration type="witr" size={170} />
          </div>
          <div className="p-4 rounded-[16px] bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] space-y-2">
            <h4 className="font-bold text-sm text-[#4145C7] dark:text-amber-300">فضل الوتر وكيفيته:</h4>
            <p className="text-xs md:text-sm text-[#25263A] dark:text-stone-300 leading-relaxed font-tajawal">
              الوتر سنة مؤكدة حث عليها النبي ﷺ وقال: «إِنَّ اللَّهَ وِتْرٌ يُحِبُّ الْوِتْرَ فَأَوْتِرُوا يَا أَهْلَ الْقُرْآنِ».
            </p>
            <ul className="list-disc list-inside space-y-1.5 text-xs md:text-sm text-[#25263A] dark:text-stone-300 leading-relaxed">
              <li><strong>وقته:</strong> من بعد صلاة العشاء إلى طلوع الفجر، وأفضله ثلث الليل الآخر.</li>
              <li><strong>أقله:</strong> ركعة واحدة، وأدنى الكمال ثلاث ركعات بسلامين أو سلام واحد.</li>
              <li><strong>دعاء القنوت:</strong> «اللَّهُمَّ اهْدِنِي فِيمَنْ هَدَيْتَ، وَعَافِنِي فِيمَنْ عَافَيْتَ...» بعد الركوع أو قبله في الركعة الأخيرة.</li>
            </ul>
          </div>
        </div>
      );
      break;

    case 'athkar_prayer':
    case 'sunan':
    default:
      title = 'سنن وأذكار الصلاة المشروعة';
      icon = '📿';
      contentNode = (
        <div className="space-y-4">
          <div className="p-4 rounded-[16px] bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] space-y-2">
            <h4 className="font-bold text-sm text-[#4145C7] dark:text-amber-300">دعاء الاستفتاح:</h4>
            <p className="text-xs md:text-sm text-[#25263A] dark:text-stone-300 font-amiri leading-loose">
              «سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ، وَتَبَارَكَ اسْمُكَ، وَتَعَالَى جَدُّكَ، وَلاَ إِلَهَ غَيْرُكَ»
            </p>
          </div>
          <div className="p-4 rounded-[16px] bg-[#F7F7FC] dark:bg-stone-900 border border-[#E6E6F0] space-y-2">
            <h4 className="font-bold text-sm text-[#4145C7] dark:text-amber-300">الاستعاذة بالتشهد الأخير:</h4>
            <p className="text-xs md:text-sm text-[#25263A] dark:text-stone-300 font-amiri leading-loose">
              «اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ عَذَابِ جَهَنَّمَ، وَمِنْ عَذَابِ الْقَبْرِ، وَمِنْ فِتْنَةِ الْمَحْيَا وَالْمَمَاتِ، وَمِنْ شَرِّ فِتْنَةِ الْمَسِيحِ الدَّجَّالِ»
            </p>
          </div>
        </div>
      );
      break;
  }

  return (
    <div className="space-y-6 pb-12 animate-fade-in" dir="rtl">
      {/* Top Header */}
      <div className="flex items-center justify-between bg-white dark:bg-[#1E1E1E] p-4 rounded-[20px] border border-[#E6E6F0] shadow-[0_4px_16px_rgba(0,0,0,0.04)]">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#F7F7FC] dark:bg-stone-800 text-[#25263A] dark:text-amber-200 font-bold hover:bg-[#EEEEFF] transition-all active:scale-95 cursor-pointer"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span>رجوع للأقسام</span>
        </button>

        <div className="text-center">
          <h2 className="text-base md:text-lg font-bold font-tajawal text-[#25263A] dark:text-stone-100 flex items-center gap-1.5 justify-center">
            <span>{title}</span>
            <span>{icon}</span>
          </h2>
          <span className="text-xs text-[#77798C] dark:text-stone-400">
            {badge}
          </span>
        </div>

        <div className="w-16" />
      </div>

      {/* Main Container */}
      <div className="bg-white dark:bg-[#1E1E1E] rounded-[20px] border border-[#E6E6F0] p-5 md:p-6 shadow-md space-y-4">
        {contentNode}
      </div>
    </div>
  );
};
