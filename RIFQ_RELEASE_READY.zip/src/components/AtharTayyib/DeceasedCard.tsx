import React, { useState } from 'react';
import { Heart, ChevronLeft, Sparkles, Clock, Bell } from 'lucide-react';
import { DeceasedRecord } from '../../utils/atharTayyibStorage';
import { MemorialPhotoFrame } from './MemorialPhotoFrame';

export interface DeceasedCardProps {
  record: DeceasedRecord;
  onOpenDetails: (record: DeceasedRecord) => void;
  onQuickPray: (recordId: string) => void;
}

export const DeceasedCard: React.FC<DeceasedCardProps> = ({
  record,
  onOpenDetails,
  onQuickPray,
}) => {
  const [prayedRecently, setPrayedRecently] = useState(false);

  const handlePrayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickPray(record.id);
    setPrayedRecently(true);
    setTimeout(() => setPrayedRecently(false), 2200);
  };

  const isFemale = record.gender === 'female';
  const prayButtonLabel = isFemale ? 'الدعاء لها 🤍' : 'الدعاء له 🤍';
  const praySuccessMessage = isFemale ? 'تقبل الله دعاءك لها 🤍' : 'تقبل الله دعاءك له 🤍';

  // Format death date cleanly if provided
  const formattedDeathDate = record.deathDate ? record.deathDate : null;

  return (
    <div
      onClick={() => onOpenDetails(record)}
      className="group relative bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-4 sm:p-5 border border-[#E6E6F0] dark:border-[#2D2E4A] hover:border-[#E8B84A]/60 dark:hover:border-[#E8B84A]/50 shadow-[0_4px_20px_rgba(37,38,58,0.03)] hover:shadow-[0_8px_30px_rgba(91,95,239,0.08)] transition-all duration-300 cursor-pointer flex flex-col justify-between overflow-hidden"
      dir="rtl"
    >
      {/* Subtle background ambient glow on hover */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#E8B84A]/10 via-[#B98CC8]/5 to-transparent rounded-bl-full pointer-events-none transition-opacity duration-300 group-hover:opacity-100 opacity-60" />

      {/* Card Content Top */}
      <div>
        <div className="flex items-center gap-4">
          {/* Glowing Memorial Photo Frame */}
          <MemorialPhotoFrame
            photoUrl={record.photoDataUrl}
            name={record.name}
            size="md"
            showGlow={true}
          />

          {/* Name & Metadata (Only what user entered!) */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h3 className="font-cairo font-black text-base sm:text-lg text-[#25263A] dark:text-[#F3F4F6] truncate leading-tight group-hover:text-[#5B5FEF] dark:group-hover:text-[#9FA4FF] transition-colors">
                {record.name}
              </h3>
              {record.relationship && (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#EEEEFF] dark:bg-[#282946] text-[#5B5FEF] dark:text-[#9FA4FF] border border-[#5B5FEF]/20">
                  {record.relationship}
                </span>
              )}
            </div>

            {/* Optional Death Date */}
            {formattedDeathDate && (
              <p className="flex items-center gap-1.5 text-xs text-[#77798C] dark:text-[#9E9FB5] mt-1 font-medium">
                <Clock className="w-3.5 h-3.5 text-[#E8B84A] shrink-0" />
                <span>تاريخ الوفاة: {formattedDeathDate}</span>
              </p>
            )}

            {/* Reminder Badge if Active */}
            {record.reminder?.enabled && record.reminder?.time && (
              <p className="inline-flex items-center gap-1 text-[11px] text-[#72B7E8] dark:text-[#88C6F7] mt-1 font-bold">
                <Bell className="w-3 h-3 shrink-0" />
                <span>تذكير يومي: {record.reminder.time}</span>
              </p>
            )}

            {/* Prayer Count (Real user clicks) */}
            {record.prayerCount > 0 && (
              <p className="flex items-center gap-1 text-xs text-[#5B5FEF] dark:text-[#9FA4FF] font-bold mt-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
                <span>دَعَوْتَ {isFemale ? 'لها' : 'له'} {record.prayerCount} {record.prayerCount === 1 ? 'مرة' : record.prayerCount === 2 ? 'مرتين' : 'مرات'}</span>
              </p>
            )}
          </div>
        </div>

        {/* Short Bio (Only if entered!) */}
        {record.shortBio && (
          <p className="text-xs text-[#56586E] dark:text-[#C2C3D6] line-clamp-2 mt-3 leading-relaxed bg-[#F7F7FC] dark:bg-[#25263A]/50 p-2.5 rounded-2xl border border-[#E6E6F0]/60 dark:border-[#2D2E4A]/60">
            {record.shortBio}
          </p>
        )}
      </div>

      {/* Card Actions Bottom */}
      <div className="flex items-center justify-between gap-2 pt-4 mt-3 border-t border-[#E6E6F0]/80 dark:border-[#2D2E4A]/80">
        {/* Quick Prayer Button */}
        <button
          type="button"
          onClick={handlePrayClick}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-2xl text-xs font-black transition-all active:scale-95 cursor-pointer shadow-xs ${
            prayedRecently
              ? 'bg-[#EBF7EE] text-[#2E7D32] dark:bg-[#1E3825] dark:text-[#81C784] border border-[#A5D6A7]'
              : 'bg-gradient-to-r from-[#FFF9E6] to-[#FFF3D6] hover:from-[#FFF3C4] hover:to-[#FFEAA8] dark:from-[#332A15] dark:to-[#453616] text-[#8C6D1F] dark:text-[#FDD835] border border-[#E8B84A]/40'
          }`}
          title="تسجيل دعاء حقيقي في ميزان حسناته"
        >
          <Heart className={`w-3.5 h-3.5 ${prayedRecently ? 'fill-current text-[#2E7D32] animate-bounce' : 'text-[#E8B84A]'}`} />
          <span>{prayedRecently ? praySuccessMessage : prayButtonLabel}</span>
        </button>

        {/* View Details Link */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onOpenDetails(record);
          }}
          className="p-2 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] dark:bg-[#25263A] dark:hover:bg-[#2F304B] text-[#5B5FEF] dark:text-[#9FA4FF] border border-[#E6E6F0] dark:border-[#2D2E4A] transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
          title="عرض التفاصيل والأدعية المأثورة"
          aria-label="عرض التفاصيل"
        >
          <span>التفاصيل</span>
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
