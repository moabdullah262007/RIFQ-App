import React from 'react';

export interface MemorialPhotoFrameProps {
  photoUrl?: string | null;
  name: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  shape?: 'circle' | 'arch';
  className?: string;
  showGlow?: boolean;
}

export const MemorialPhotoFrame: React.FC<MemorialPhotoFrameProps> = ({
  photoUrl,
  name,
  size = 'md',
  shape = 'circle',
  className = '',
  showGlow = true,
}) => {
  // Dimensions per size
  const sizeConfig = {
    sm: {
      container: 'w-16 h-16',
      borderWidth: 'border-[1.5px]',
      glowSpread: 'shadow-[0_0_12px_rgba(232,184,74,0.35),0_0_20px_rgba(185,140,200,0.25)]',
      dotsSize: 'w-1 h-1',
      avatarIconSize: 'w-8 h-8',
    },
    md: {
      container: 'w-24 h-24',
      borderWidth: 'border-2',
      glowSpread: 'shadow-[0_0_16px_rgba(232,184,74,0.4),0_0_28px_rgba(185,140,200,0.3)]',
      dotsSize: 'w-1.5 h-1.5',
      avatarIconSize: 'w-12 h-12',
    },
    lg: {
      container: 'w-36 h-36',
      borderWidth: 'border-2',
      glowSpread: 'shadow-[0_0_24px_rgba(232,184,74,0.45),0_0_40px_rgba(185,140,200,0.35)]',
      dotsSize: 'w-2 h-2',
      avatarIconSize: 'w-18 h-18',
    },
    xl: {
      container: 'w-44 h-44 sm:w-48 sm:h-48',
      borderWidth: 'border-[2.5px]',
      glowSpread: 'shadow-[0_0_30px_rgba(232,184,74,0.5),0_0_55px_rgba(185,140,200,0.4)]',
      dotsSize: 'w-2.5 h-2.5',
      avatarIconSize: 'w-24 h-24',
    },
  }[size];

  const shapeClass =
    shape === 'arch'
      ? 'rounded-t-[44px] rounded-b-[20px]'
      : 'rounded-full';

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 ${sizeConfig.container} ${className}`}
      dir="ltr"
    >
      {/* Outer Ethereal Lavender Halo */}
      {showGlow && (
        <div
          aria-hidden="true"
          className={`absolute -inset-1.5 ${shapeClass} bg-gradient-to-tr from-[#B98CC8]/25 via-[#E8B84A]/20 to-[#9FA4FF]/25 blur-md pointer-events-none transition-opacity duration-300`}
        />
      )}

      {/* Subtle Micro Celestial Light Dots around the perimeter */}
      {showGlow && size !== 'sm' && (
        <>
          <span
            aria-hidden="true"
            className={`absolute top-0 right-1 ${sizeConfig.dotsSize} rounded-full bg-[#FFEBB3] shadow-[0_0_6px_#FFEBB3] animate-pulse pointer-events-none`}
            style={{ animationDuration: '3s' }}
          />
          <span
            aria-hidden="true"
            className={`absolute bottom-1 left-2 ${sizeConfig.dotsSize} rounded-full bg-[#FFEBB3] shadow-[0_0_6px_#FFEBB3] animate-pulse pointer-events-none`}
            style={{ animationDuration: '4s' }}
          />
          <span
            aria-hidden="true"
            className="absolute top-1/2 -left-1 w-1 h-1 rounded-full bg-[#EAEBFF] shadow-[0_0_4px_#EAEBFF] pointer-events-none"
          />
        </>
      )}

      {/* Golden Dual Decorative Border Shell */}
      <div
        className={`relative w-full h-full p-[3px] ${shapeClass} bg-gradient-to-b from-[#F5D77F] via-[#E8B84A] to-[#D4A836] ${
          showGlow ? sizeConfig.glowSpread : 'shadow-md'
        } transition-transform duration-300`}
      >
        {/* Inner Border Ring / Cream Matting */}
        <div
          className={`relative w-full h-full p-[2px] ${shapeClass} bg-[#FFFEFC] dark:bg-[#202138] overflow-hidden`}
        >
          {/* Inner Golden Rim Line */}
          <div
            className={`relative w-full h-full ${shapeClass} overflow-hidden bg-gradient-to-b from-[#F7F7FC] to-[#EEEEFF] dark:from-[#25263A] dark:to-[#1A1B2E] border border-[#E8B84A]/40`}
          >
            {photoUrl ? (
              <img
                src={photoUrl}
                alt={name}
                loading="lazy"
                className="w-full h-full object-cover object-center transition-transform duration-500 hover:scale-105"
                onError={(e) => {
                  // Fallback to silhouette if load fails
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              /* Dignified Memorial Silhouette Avatar with Soft Golden Halo */
              <div
                className="w-full h-full flex flex-col items-center justify-center relative select-none"
                title={name}
              >
                {/* Background gentle light radiance */}
                <div className="absolute inset-0 bg-radial from-[#FFFFFF]/70 dark:from-[#353655]/60 to-transparent pointer-events-none" />

                <svg
                  viewBox="0 0 64 64"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className={`relative ${sizeConfig.avatarIconSize} drop-shadow-sm`}
                >
                  {/* Subtle golden halo behind head */}
                  <circle
                    cx="32"
                    cy="20"
                    r="14"
                    fill="url(#avatar_halo)"
                    stroke="#E8B84A"
                    strokeWidth="1.2"
                    strokeDasharray="2 2"
                    opacity="0.85"
                  />

                  {/* Serene Head Silhouette */}
                  <circle cx="32" cy="22" r="8.5" fill="url(#avatar_grad)" />

                  {/* Shoulders Silhouette */}
                  <path
                    d="M17 50C17 40.5 23.5 37 32 37C40.5 37 47 40.5 47 50C47 52.5 45 54 42.5 54H21.5C19 54 17 52.5 17 50Z"
                    fill="url(#avatar_grad)"
                  />

                  {/* Small white lily emblem at base of silhouette */}
                  <path
                    d="M32 46C30.5 44 29 42.5 32 40C35 42.5 33.5 44 32 46Z"
                    fill="#FFFEFC"
                  />
                  <circle cx="32" cy="42" r="1" fill="#E8B84A" />

                  <defs>
                    <radialGradient
                      id="avatar_halo"
                      cx="0"
                      cy="0"
                      r="1"
                      gradientUnits="userSpaceOnUse"
                      gradientTransform="translate(32 20) rotate(90) scale(14)"
                    >
                      <stop stopColor="#FFF4D0" stopOpacity="0.8" />
                      <stop offset="0.7" stopColor="#E8B84A" stopOpacity="0.25" />
                      <stop offset="1" stopColor="#E8B84A" stopOpacity="0" />
                    </radialGradient>
                    <linearGradient
                      id="avatar_grad"
                      x1="32"
                      y1="13.5"
                      x2="32"
                      y2="54"
                      gradientUnits="userSpaceOnUse"
                    >
                      <stop stopColor="#9FA4FF" />
                      <stop offset="0.6" stopColor="#7E84F7" />
                      <stop offset="1" stopColor="#5B5FEF" />
                    </linearGradient>
                  </defs>
                </svg>

                {/* Subtle initial letter badge in tiny bottom corner if sm/md */}
                {name && size === 'sm' && (
                  <span className="sr-only">{name}</span>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
