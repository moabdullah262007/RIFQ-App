import React, { useState, useRef } from 'react';
import { X, Upload, Trash2, Calendar, Clock, Bell, Sparkles, User, Heart, BookOpen, AlertCircle } from 'lucide-react';
import { DeceasedRecord, compressMemorialPhoto } from '../../utils/atharTayyibStorage';
import { MemorialPhotoFrame } from './MemorialPhotoFrame';

export interface AddEditDeceasedModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: DeceasedRecord) => void;
  initialRecord?: DeceasedRecord | null;
}

const RELATION_SUGGESTIONS = [
  'الوالد',
  'الوالدة',
  'الجد',
  'الجدة',
  'الأخ',
  'الأخت',
  'الابن',
  'الابنة',
  'الزوج',
  'الزوجة',
  'عم / عمة',
  'خال / خالة',
  'صديق',
  'معلم',
];

const DAYS_OF_WEEK = [
  { id: 5, label: 'الجمعة' },
  { id: 1, label: 'الاثنين' },
  { id: 4, label: 'الخميس' },
  { id: 0, label: 'الأحد' },
  { id: 2, label: 'الثلاثاء' },
  { id: 3, label: 'الأربعاء' },
  { id: 6, label: 'السبت' },
];

export const AddEditDeceasedModal: React.FC<AddEditDeceasedModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialRecord,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState(initialRecord?.name || '');
  const [gender, setGender] = useState<'male' | 'female'>(initialRecord?.gender || 'male');
  const [relationship, setRelationship] = useState(initialRecord?.relationship || '');
  const [deathDate, setDeathDate] = useState(initialRecord?.deathDate || '');
  const [photoDataUrl, setPhotoDataUrl] = useState<string | null>(initialRecord?.photoDataUrl || null);
  const [shortBio, setShortBio] = useState(initialRecord?.shortBio || '');
  const [memories, setMemories] = useState(initialRecord?.memories || '');
  const [notes, setNotes] = useState(initialRecord?.notes || '');

  // Reminder settings
  const [reminderEnabled, setReminderEnabled] = useState(initialRecord?.reminder?.enabled || false);
  const [reminderTime, setReminderTime] = useState(initialRecord?.reminder?.time || '17:00');
  const [reminderDays, setReminderDays] = useState<number[]>(initialRecord?.reminder?.days || []);

  const [isProcessingPhoto, setIsProcessingPhoto] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate size (max 8MB before compression)
    if (file.size > 8 * 1024 * 1024) {
      setErrorMsg('حجم الصورة كبير جداً، يرجى اختيار صورة أصغر من 8 ميجابايت.');
      return;
    }

    try {
      setIsProcessingPhoto(true);
      setErrorMsg('');
      const compressed = await compressMemorialPhoto(file);
      setPhotoDataUrl(compressed);
    } catch {
      setErrorMsg('حدث خطأ أثناء معالجة الصورة، يرجى المحاولة بصورة أخرى.');
    } finally {
      setIsProcessingPhoto(false);
    }
  };

  const handleToggleDay = (dayId: number) => {
    setReminderDays((prev) =>
      prev.includes(dayId) ? prev.filter((d) => d !== dayId) : [...prev, dayId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('يرجى إدخال اسم المتوفى رحمه الله.');
      return;
    }

    const now = Date.now();
    const finalRecord: DeceasedRecord = {
      id: initialRecord?.id || `deceased_${now}_${Math.random().toString(36).slice(2, 8)}`,
      name: name.trim(),
      gender,
      relationship: relationship.trim() || undefined,
      deathDate: deathDate.trim() || undefined,
      photoDataUrl: photoDataUrl || null,
      shortBio: shortBio.trim() || undefined,
      memories: memories.trim() || undefined,
      notes: notes.trim() || undefined,
      prayerCount: initialRecord?.prayerCount || 0,
      lastPrayedAt: initialRecord?.lastPrayedAt || null,
      prayerLogs: initialRecord?.prayerLogs || [],
      reminder: {
        enabled: reminderEnabled,
        time: reminderTime || '17:00',
        days: reminderDays,
      },
      createdAt: initialRecord?.createdAt || now,
      updatedAt: now,
    };

    onSave(finalRecord);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#25263A]/70 backdrop-blur-sm animate-fade-in overflow-y-auto"
      dir="rtl"
    >
      <div className="relative w-full max-w-lg bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl shadow-2xl border border-[#E6E6F0] dark:border-[#2D2E4A] max-h-[92vh] flex flex-col overflow-hidden my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-[#E6E6F0] dark:border-[#2D2E4A] bg-gradient-to-r from-[#FFFEFC] to-[#F7F7FC] dark:from-[#202138] dark:to-[#1A1B2E]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#FFF9E6] to-[#FFEBB3] dark:from-[#352D16] dark:to-[#453616] border border-[#E8B84A]/40 flex items-center justify-center text-[#E8B84A] shadow-xs">
              <Sparkles className="w-5 h-5 text-[#D4A836]" />
            </div>
            <div>
              <h2 className="font-cairo font-black text-base sm:text-lg text-[#25263A] dark:text-[#F3F4F6]">
                {initialRecord ? 'تعديل بيانات المتوفى' : 'إضافة متوفى 🕊️'}
              </h2>
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5]">
                نحفظ أثرهم بالدعاء والذكر الطيب في قلوبنا
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-2xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] hover:text-[#25263A] dark:hover:text-[#F3F4F6] transition-colors cursor-pointer"
            aria-label="إغلاق النافذة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {errorMsg && (
            <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-2xl text-xs font-bold border border-red-200 dark:border-red-900/50">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Photo Section with Memorial Glowing Frame Preview */}
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 p-4 rounded-3xl bg-[#F7F7FC] dark:bg-[#25263A]/50 border border-[#E6E6F0] dark:border-[#2D2E4A]">
            <MemorialPhotoFrame
              photoUrl={photoDataUrl}
              name={name || 'المتوفى'}
              size="lg"
              showGlow={true}
            />

            <div className="flex-1 text-center sm:text-right space-y-2">
              <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6]">
                الصورة الشخصية (اختيارية)
              </label>
              <p className="text-[11px] text-[#77798C] dark:text-[#9E9FB5] leading-relaxed">
                ستُحفظ الصورة داخل إطار تذكاري متوهج بأمان وخصوصية كاملة على جهازك فقط.
              </p>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessingPhoto}
                  className="px-3.5 py-2 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-bold hover:brightness-105 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{photoDataUrl ? 'تغيير الصورة' : 'اختيار صورة'}</span>
                </button>

                {photoDataUrl && (
                  <button
                    type="button"
                    onClick={() => setPhotoDataUrl(null)}
                    className="px-3 py-2 rounded-2xl bg-[#FFF0F0] dark:bg-red-950/40 text-red-600 dark:text-red-400 text-xs font-bold hover:bg-red-100 transition-colors flex items-center gap-1 cursor-pointer border border-red-200 dark:border-red-900/40"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Name & Gender (Gender controls prayer pronouns accurately) */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-black text-[#25263A] dark:text-[#F3F4F6] mb-1.5">
                الاسم الكريم للمتوفى <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="مثال: الوالد الحبيب عبد الله رحمه الله"
                  required
                  className="w-full px-4 py-3 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-sm font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#77798C] dark:text-[#9E9FB5] mb-1.5">
                صيغة الدعاء المناسبة
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setGender('male')}
                  className={`py-2 px-3 rounded-2xl text-xs font-black border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    gender === 'male'
                      ? 'bg-[#EEEEFF] dark:bg-[#2B2D54] text-[#5B5FEF] dark:text-[#9FA4FF] border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] dark:bg-[#202138] text-[#77798C] dark:text-[#9E9FB5] border-[#E6E6F0] dark:border-[#2D2E4A]'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  <span>مذكر (اللهم ارحمه)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setGender('female')}
                  className={`py-2 px-3 rounded-2xl text-xs font-black border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    gender === 'female'
                      ? 'bg-[#FFF0F6] dark:bg-[#3D2534] text-[#E99AC7] dark:text-[#FFB6DF] border-[#E99AC7]'
                      : 'bg-[#F7F7FC] dark:bg-[#202138] text-[#77798C] dark:text-[#9E9FB5] border-[#E6E6F0] dark:border-[#2D2E4A]'
                  }`}
                >
                  <Heart className="w-3.5 h-3.5" />
                  <span>مؤنث (اللهم ارحمها)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Relationship (صلة القرابة) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6]">
              صلة القرابة (اختيارية)
            </label>
            <input
              type="text"
              value={relationship}
              onChange={(e) => setRelationship(e.target.value)}
              placeholder="مثال: الوالد، الجد، صديق عزيز..."
              className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
            />
            {/* Quick Pills */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {RELATION_SUGGESTIONS.map((rel) => (
                <button
                  key={rel}
                  type="button"
                  onClick={() => setRelationship(rel)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer ${
                    relationship === rel
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] dark:text-[#9E9FB5] border-[#E6E6F0] dark:border-[#2D2E4A] hover:bg-[#EEEEFF]'
                  }`}
                >
                  {rel}
                </button>
              ))}
            </div>
          </div>

          {/* Date of Death (تاريخ الوفاة) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6]">
              تاريخ الوفاة (اختياري)
            </label>
            <div className="relative">
              <input
                type="text"
                value={deathDate}
                onChange={(e) => setDeathDate(e.target.value)}
                placeholder="مثال: 15 رمضان 1445 هـ أو 2024-03-25"
                className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
              />
              <Calendar className="w-4 h-4 text-[#77798C] absolute left-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Short Bio (نبذة عنه) */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6]">
              نبذة قصيرة عنه (اختيارية)
            </label>
            <textarea
              rows={2}
              value={shortBio}
              onChange={(e) => setShortBio(e.target.value)}
              placeholder="سطر أو سطرين يصفان خصاله الكريمة..."
              className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors resize-none leading-relaxed"
            />
          </div>

          {/* Memories & Impact (أثر طيّب) */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-xs font-bold text-[#25263A] dark:text-[#F3F4F6]">
              <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
              <span>أثر طيّب • مواقف جميلة أو ذكريات ووصايا (اختيارية)</span>
            </label>
            <textarea
              rows={3}
              value={memories}
              onChange={(e) => setMemories(e.target.value)}
              placeholder="اكتب ما تحب أن تحفظه له: كلمة كان يرددها، موقف جميل، وصية، أو صدقة جارية ترغب في تذكرها..."
              className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors resize-none leading-relaxed"
            />
          </div>

          {/* Additional Notes */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-[#77798C] dark:text-[#9E9FB5]">
              ملاحظات إضافية خاصة (اختيارية)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="ملاحظة شخصية خاصة بك..."
              className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
            />
          </div>

          {/* Prayer Reminder Settings (تذكير بالدعاء له) */}
          <div className="p-4 rounded-3xl bg-gradient-to-br from-[#FFFDF5] to-[#F9F7FC] dark:from-[#242136] dark:to-[#1E1F35] border border-[#E8B84A]/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#E8B84A]" />
                <span className="text-xs font-black text-[#25263A] dark:text-[#F3F4F6]">
                  تذكير محلي بالدعاء له
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={reminderEnabled}
                  onChange={(e) => setReminderEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-[#E6E6F0] dark:bg-[#353655] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
              </label>
            </div>

            {reminderEnabled && (
              <div className="space-y-3 pt-2 border-t border-[#E8B84A]/20">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs text-[#77798C] dark:text-[#9E9FB5] font-bold">
                    وقت التذكير:
                  </span>
                  <div className="relative">
                    <input
                      type="time"
                      value={reminderTime}
                      onChange={(e) => setReminderTime(e.target.value)}
                      className="px-3 py-1.5 rounded-xl bg-white dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-black text-[#25263A] dark:text-[#F3F4F6] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <span className="block text-[11px] text-[#77798C] dark:text-[#9E9FB5] font-bold mb-1.5">
                    تكرار التذكير (اتركه بدون تحديد ليكون يومياً):
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {DAYS_OF_WEEK.map((d) => {
                      const isSelected = reminderDays.includes(d.id);
                      return (
                        <button
                          key={d.id}
                          type="button"
                          onClick={() => handleToggleDay(d.id)}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-[#E8B84A] text-[#25263A] border-[#E8B84A]'
                              : 'bg-white dark:bg-[#25263A] text-[#77798C] dark:text-[#9E9FB5] border-[#E6E6F0] dark:border-[#2D2E4A]'
                          }`}
                        >
                          {d.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] dark:text-[#9E9FB5] text-xs font-bold hover:bg-[#E6E6F0] transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <span>{initialRecord ? 'حفظ التعديلات' : 'إضافة المتوفى'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
