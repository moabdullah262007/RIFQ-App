import React, { useState, useMemo, useEffect } from 'react';
import {
  CompanionCategoryId,
  CompanionProfile,
  CompanionStory,
} from '../../types';
import {
  initCompanionsSqliteTables,
  loadCompanionCategoriesFromStorage,
  loadCompanionsFromStorage,
  loadCompanionFavorites,
  toggleCompanionFavorite,
  searchCompanionsInStorage,
} from '../../utils/storage';

interface CompanionsStoriesViewProps {
  onBack: () => void;
  initialCompanionId?: string | null;
  initialCategory?: CompanionCategoryId | 'all' | 'favorites';
}

/**
 * أيقونة قسم قصص الصحابة بصيغة PNG الحقيقية (128×128 بخلفية شفافة)
 * بعد استبدال الأيقونات القديمة بالصور الجديدة
 */
export const IslamicCompanionGoldSvg: React.FC<{
  size?: number;
  gender?: 'male' | 'female';
  className?: string;
}> = ({ size = 36, gender = 'male', className = '' }) => (
  <img
    src={gender === 'female' ? 'assets/icons/menu/ic_woman_flower.png' : 'assets/icons/menu/ic_companions.png'}
    alt={gender === 'female' ? 'صحابية جليلة' : 'صحابي جليل'}
    width={size}
    height={size}
    draggable={false}
    loading="eager"
    decoding="async"
    style={{ width: size, height: size }}
    className={`object-contain select-none shrink-0 drop-shadow-[0_2px_5px_rgba(201,168,76,0.28)] ${className}`}
  />
);

const CategoryIconSvg: React.FC<{ icon: string; active?: boolean }> = ({ icon, active = false }) => {
  const stroke = active ? '#FFFFFF' : '#E8B84A';
  const accent = active ? '#F7F7FC' : '#4CAF82';

  switch (icon) {
    case 'khulafa':
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M4 19H20M6 16V9L12 5L18 9V16" stroke={stroke} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 9V16" stroke={accent} strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'ashara':
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 3C7.5 3 4 6.5 4 11V20H20V11C20 6.5 16.5 3 12 3Z" stroke={stroke} strokeWidth="2" strokeLinejoin="round" />
          <path d="M9 14L11 16L15.5 11.5" stroke={accent} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'sabiqun':
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 3V7M5.6 5.6L8.4 8.4M18.4 5.6L15.6 8.4M4 15H20" stroke={stroke} strokeWidth="2" strokeLinecap="round" />
          <path d="M7 15C7 12.2 9.2 10 12 10C14.8 10 17 12.2 17 15" stroke={accent} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'commanders':
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 3L19 6V12C19 16.5 16 19.8 12 21C8 19.8 5 16.5 5 12V6L12 3Z" stroke={stroke} strokeWidth="2" strokeLinejoin="round" />
          <path d="M12 8V15M9 11.5H15" stroke={accent} strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'scholars':
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M3 6.5C3 5.7 3.7 5 4.5 5H10.5C11.3 5 12 5.7 12 6.5V19C12 18.2 11.3 17.5 10.5 17.5H4.5C3.7 17.5 3 16.8 3 16V6.5Z" stroke={stroke} strokeWidth="1.9" />
          <path d="M21 6.5C21 5.7 20.3 5 19.5 5H13.5C12.7 5 12 5.7 12 6.5V19C12 18.2 12.7 17.5 13.5 17.5H19.5C20.3 17.5 21 16.8 21 16V6.5Z" stroke={accent} strokeWidth="1.9" />
        </svg>
      );
    case 'sahabiyat':
    case 'ummahat':
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="9" r="4" stroke={stroke} strokeWidth="2" />
          <path d="M6 20C6.8 16 9 14 12 14C15 14 17.2 16 18 20" stroke={accent} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'narrators':
    default:
      return (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M7 4H17C18.1 4 19 4.9 19 6V18C19 19.1 18.1 20 17 20H7C5.9 20 5 19.1 5 18V6C5 4.9 5.9 4 7 4Z" stroke={stroke} strokeWidth="2" />
          <path d="M9 9H15M9 13H15M9 17H13" stroke={accent} strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
  }
};

export const CompanionsStoriesView: React.FC<CompanionsStoriesViewProps> = ({
  onBack,
  initialCompanionId = null,
  initialCategory = 'all',
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CompanionCategoryId | 'all' | 'favorites'>(initialCategory);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompanionId, setSelectedCompanionId] = useState<string | null>(initialCompanionId);
  const [activeDetailTab, setActiveDetailTab] = useState<'bio' | 'stories' | 'hadiths' | 'lessons'>('stories');
  const [fontScale, setFontScale] = useState<number>(1);
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => loadCompanionFavorites());
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // تهيئة جداول SQLite واسترجاع التصنيفات والصحابة من قاعدة البيانات المحلية
  useEffect(() => {
    initCompanionsSqliteTables();
    setFavoriteIds(loadCompanionFavorites());
  }, []);

  useEffect(() => {
    if (initialCompanionId !== undefined) {
      setSelectedCompanionId(initialCompanionId);
    }
  }, [initialCompanionId]);

  useEffect(() => {
    if (initialCategory !== undefined) {
      setSelectedCategory(initialCategory);
    }
  }, [initialCategory]);

  const categories = useMemo(() => loadCompanionCategoriesFromStorage(), []);
  const allCompanions = useMemo(() => loadCompanionsFromStorage(), [favoriteIds]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2600);
  };

  const toggleFavorite = (companionId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const { favoriteIds: updatedIds, isFavorite } = toggleCompanionFavorite(companionId);
    setFavoriteIds(updatedIds);
    showToast(isFavorite ? 'تمت الإضافة إلى المفضلة' : 'تمت الإزالة من المفضلة');
  };

  const filteredCompanions = useMemo(() => {
    return searchCompanionsInStorage(searchQuery, selectedCategory);
  }, [selectedCategory, searchQuery, favoriteIds]);

  const selectedCompanion = useMemo(
    () => allCompanions.find((c) => c.id === selectedCompanionId) || null,
    [allCompanions, selectedCompanionId]
  );

  const handleCopyText = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      showToast('تم نسخ النص مع المصدر بنجاح');
      setTimeout(() => setCopiedId((prev) => (prev === id ? null : prev)), 2000);
    } catch {
      showToast('تم تجهيز النص للنسخ');
    }
  };

  const handleShareText = async (title: string, text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({ title, text });
        return;
      } catch {
        // fallback to clipboard
      }
    }
    await handleCopyText(title, text);
  };

  const formatStoryForShare = (companion: CompanionProfile, story: CompanionStory) => {
    return [
      `من سيرة: ${companion.name}`,
      `${story.title}`,
      '',
      story.content,
      '',
      `المصدر: ${story.reference}`,
      '— تطبيق رِفْق | RIFQ (قسم قصص الصحابة)',
    ].join('\n');
  };

  const formatCompanionForShare = (companion: CompanionProfile) => {
    return [
      `${companion.name}`,
      `الاسم الكامل: ${companion.full_name}`,
      `اللقب: ${companion.title}`,
      `الميلاد: ${companion.birth_date} (${companion.birth_place}) • الوفاة: ${companion.death_date}`,
      '',
      `نبذة:`,
      companion.bio,
      '',
      `من فضائله ومناقبه:`,
      ...companion.virtues.map((v) => `• ${v}`),
      '',
      `المصادر: ${companion.sources.join(' ، ')}`,
      '— تطبيق رِفْق | RIFQ (قسم قصص الصحابة)',
    ].join('\n');
  };

  // ── شاشة تفاصيل الصحابي وقراءة القصص ──
  if (selectedCompanion) {
    const isFav = favoriteIds.includes(selectedCompanion.id);
    return (
      <div dir="rtl" className="min-h-screen bg-[#F7F7FC] pb-24">
        {/* الشريط العلوي */}
        <div className="sticky top-0 z-30 bg-[#FFFFFF] border-b border-[#E6E6F0] shadow-[0_2px_10px_rgba(0,0,0,0.04)] px-4 py-3">
          <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setSelectedCompanionId(null)}
              className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-[#25263A] font-cairo font-bold text-sm hover:border-[#5B5FEF] transition-colors cursor-pointer"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M9 18L15 12L9 6" stroke="#5B5FEF" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span>عودة للقائمة</span>
            </button>

            {/* أزرار التحكم بحجم الخط والمفضلة والمشاركة */}
            <div className="flex items-center gap-2">
              <div className="flex items-center bg-[#F7F7FC] rounded-xl border border-[#E6E6F0] p-1">
                <button
                  type="button"
                  onClick={() => setFontScale((s) => Math.max(0.85, +(s - 0.1).toFixed(2)))}
                  aria-label="تصغير الخط"
                  className="px-2.5 py-1 rounded-lg font-cairo font-bold text-xs text-[#25263A] hover:bg-[#FFFFFF] transition-colors cursor-pointer"
                >
                  أ-
                </button>
                <span className="px-2 text-xs font-cairo text-[#77798C]">الخط</span>
                <button
                  type="button"
                  onClick={() => setFontScale((s) => Math.min(1.35, +(s + 0.1).toFixed(2)))}
                  aria-label="تكبير الخط"
                  className="px-2.5 py-1 rounded-lg font-cairo font-bold text-xs text-[#25263A] hover:bg-[#FFFFFF] transition-colors cursor-pointer"
                >
                  أ+
                </button>
              </div>

              <button
                type="button"
                onClick={() => toggleFavorite(selectedCompanion.id)}
                aria-label={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-colors cursor-pointer ${
                  isFav
                    ? 'bg-[#EEEEFF] border-[#5B5FEF]'
                    : 'bg-[#F7F7FC] border-[#E6E6F0] hover:border-[#5B5FEF]'
                }`}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill={isFav ? '#E8B84A' : 'none'}>
                  <path
                    d="M12 20.5C12 20.5 4 15.2 4 8.8C4 6.1 6.1 4 8.8 4C10.4 4 11.8 4.8 12 6C12.2 4.8 13.6 4 15.2 4C17.9 4 20 6.1 20 8.8C20 15.2 12 20.5 12 20.5Z"
                    stroke="#5B5FEF"
                    strokeWidth="2"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleShareText(selectedCompanion.name, formatCompanionForShare(selectedCompanion))
                }
                aria-label="مشاركة ترجمة الصحابي"
                className="w-10 h-10 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] hover:border-[#5B5FEF] flex items-center justify-center transition-colors cursor-pointer"
              >
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
                  <circle cx="18" cy="5" r="3" stroke="#5B5FEF" strokeWidth="2" />
                  <circle cx="6" cy="12" r="3" stroke="#5B5FEF" strokeWidth="2" />
                  <circle cx="18" cy="19" r="3" stroke="#5B5FEF" strokeWidth="2" />
                  <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke="#4CAF82" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 pt-5 space-y-5">
          {/* بطاقة تعريف الصحابي الرئيسية */}
          <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 shadow-[0_4px_14px_rgba(0,0,0,0.05)]">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0">
                <IslamicCompanionGoldSvg size={50} gender={selectedCompanion.gender} />
              </div>
              <div className="flex-1 space-y-1.5">
                <h1 className="font-cairo font-bold text-xl sm:text-2xl text-[#25263A]">
                  {selectedCompanion.name}
                </h1>
                <p className="font-cairo font-bold text-sm text-[#4CAF82]">
                  {selectedCompanion.title}
                </p>
                <p className="font-cairo text-xs sm:text-sm text-[#77798C]">
                  <span className="font-bold text-[#25263A]">النسب الكامل: </span>
                  {selectedCompanion.full_name}
                </p>
              </div>
            </div>

            {/* جدول بيانات الميلاد والوفاة ومكان الميلاد والمرويات */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-4 border-t border-[#F7F7FC]">
              <div className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0]">
                <span className="block font-cairo text-xs text-[#77798C]">الميلاد</span>
                <span className="font-cairo font-bold text-sm text-[#25263A] mt-0.5 block">
                  {selectedCompanion.birth_date}
                </span>
              </div>
              <div className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0]">
                <span className="block font-cairo text-xs text-[#77798C]">الوفاة</span>
                <span className="font-cairo font-bold text-sm text-[#25263A] mt-0.5 block">
                  {selectedCompanion.death_date}
                </span>
              </div>
              <div className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0]">
                <span className="block font-cairo text-xs text-[#77798C]">مكان الميلاد</span>
                <span className="font-cairo font-bold text-sm text-[#25263A] mt-0.5 block">
                  {selectedCompanion.birth_place}
                </span>
              </div>
              <div className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0]">
                <span className="block font-cairo text-xs text-[#77798C]">المرويات والآثار</span>
                <span className="font-cairo font-bold text-sm text-[#72B7E8] mt-0.5 block">
                  {selectedCompanion.hadiths_count}
                </span>
              </div>
            </div>
          </div>

          {/* تبويبات المحتوى */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-[#FFFFFF] p-2 rounded-2xl border border-[#E6E6F0]">
            {[
              { id: 'stories', label: `القصص والمواقف (${selectedCompanion.stories.length})` },
              { id: 'bio', label: 'السيرة والفضائل' },
              { id: 'hadiths', label: 'من مروياته وأقواله' },
              { id: 'lessons', label: 'الوفاة والمصادر' },
            ].map((tab) => {
              const active = activeDetailTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveDetailTab(tab.id as typeof activeDetailTab)}
                  className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                    active
                      ? 'bg-[#5B5FEF] text-[#FFFFFF] shadow-sm'
                      : 'bg-transparent text-[#25263A] hover:bg-[#F7F7FC]'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* 1. تبويب القصص والمواقف الموثقة */}
          {activeDetailTab === 'stories' && (
            <div className="space-y-4">
              {selectedCompanion.stories.map((story, idx) => {
                const isCopied = copiedId === story.id;
                return (
                  <article
                    key={story.id}
                    className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 shadow-[0_4px_12px_rgba(0,0,0,0.04)] space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center font-cairo font-bold text-sm text-[#25263A] shrink-0">
                          {idx + 1}
                        </div>
                        <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                          {story.title}
                        </h3>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            handleCopyText(story.id, formatStoryForShare(selectedCompanion, story))
                          }
                          aria-label="نسخ القصة"
                          className="px-2.5 py-1.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] hover:border-[#5B5FEF] font-cairo font-bold text-xs text-[#25263A] flex items-center gap-1.5 cursor-pointer"
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                            {isCopied ? (
                              <path d="M5 13L9 17L19 7" stroke="#4CAF82" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
                            ) : (
                              <>
                                <rect x="9" y="9" width="11" height="11" rx="2" stroke="#5B5FEF" strokeWidth="2" />
                                <path d="M5 15H4C2.9 15 2 14.1 2 13V4C2 2.9 2.9 2 4 2H13C14.1 2 15 2.9 15 4V5" stroke="#4CAF82" strokeWidth="2" />
                              </>
                            )}
                          </svg>
                          <span>{isCopied ? 'تم النسخ' : 'نسخ'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            handleShareText(story.title, formatStoryForShare(selectedCompanion, story))
                          }
                          aria-label="مشاركة القصة"
                          className="px-2.5 py-1.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] hover:border-[#5B5FEF] font-cairo font-bold text-xs text-[#25263A] flex items-center gap-1.5 cursor-pointer"
                        >
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                            <circle cx="18" cy="5" r="3" stroke="#5B5FEF" strokeWidth="2" />
                            <circle cx="6" cy="12" r="3" stroke="#5B5FEF" strokeWidth="2" />
                            <circle cx="18" cy="19" r="3" stroke="#5B5FEF" strokeWidth="2" />
                            <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke="#4CAF82" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                          <span>مشاركة</span>
                        </button>
                      </div>
                    </div>

                    <p
                      style={{ fontSize: `${15.5 * fontScale}px` }}
                      className="font-cairo text-[#25263A] leading-[1.95] text-justify bg-[#F7F7FC]/65 p-4 rounded-xl border border-[#E6E6F0]"
                    >
                      {story.content}
                    </p>

                    <div className="flex items-center gap-2 pt-1 text-xs sm:text-sm font-cairo text-[#4CAF82]">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" stroke="#5B5FEF" strokeWidth="2" strokeLinecap="round" />
                        <path d="M6.5 2H20V22H6.5A2.5 2.5 0 0 1 4 19.5V4.5A2.5 2.5 0 0 1 6.5 2Z" stroke="#4CAF82" strokeWidth="2" strokeLinejoin="round" />
                      </svg>
                      <span className="font-bold">المصدر المعتمد:</span>
                      <span className="text-[#25263A]">{story.reference}</span>
                    </div>
                  </article>
                );
              })}
            </div>
          )}

          {/* 2. تبويب السيرة والفضائل */}
          {activeDetailTab === 'bio' && (
            <div className="space-y-4">
              <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 space-y-3">
                <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A] flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#5B5FEF] inline-block" />
                  <span>السيرة النبوية والتعريف</span>
                </h3>
                <p
                  style={{ fontSize: `${15.5 * fontScale}px` }}
                  className="font-cairo text-[#25263A] leading-[1.95] text-justify"
                >
                  {selectedCompanion.bio}
                </p>
              </div>

              <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 space-y-3">
                <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A] flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#4CAF82] inline-block" />
                  <span>الفضائل والمناقب في القرآن والسنة</span>
                </h3>
                <div className="space-y-3">
                  {selectedCompanion.virtues.map((virtue, i) => (
                    <div
                      key={i}
                      style={{ fontSize: `${17 * fontScale}px` }}
                      className="font-amiri text-[#25263A] leading-[2.0] bg-[#F7F7FC] p-4 rounded-xl border border-[#E6E6F0]"
                    >
                      {virtue}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 3. تبويب من مروياته وأقواله */}
          {activeDetailTab === 'hadiths' && (
            <div className="space-y-4">
              <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
                  <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                    من الأحاديث والآثار المروية
                  </h3>
                  <span className="font-cairo font-bold text-sm text-[#72B7E8]">
                    مجموع المرويات: {selectedCompanion.hadiths_count}
                  </span>
                </div>

                {selectedCompanion.hadiths.map((h, i) => (
                  <div
                    key={i}
                    className="bg-[#F7F7FC] rounded-xl p-4 border border-[#E6E6F0] space-y-3"
                  >
                    <p
                      style={{ fontSize: `${18 * fontScale}px` }}
                      className="font-amiri text-[#25263A] leading-[2.1] text-justify"
                    >
                      {h.text}
                    </p>
                    <div className="flex items-center justify-between pt-2 border-t border-[#E6E6F0]">
                      <span className="font-cairo font-bold text-xs sm:text-sm text-[#4CAF82]">
                        التخريج والمصدر: {h.source}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopyText(`hadith_${i}`, `${h.text}\nالمصدر: ${h.source}`)}
                        className="px-3 py-1 rounded-lg bg-[#FFFFFF] border border-[#E6E6F0] font-cairo font-bold text-xs text-[#25263A] hover:border-[#5B5FEF] cursor-pointer"
                      >
                        نسخ الحديث
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. تبويب الوفاة والدروس المستفادة والمصادر */}
          {activeDetailTab === 'lessons' && (
            <div className="space-y-4">
              <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 space-y-2.5">
                <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                  الوفاة والخاتمة
                </h3>
                <p
                  style={{ fontSize: `${15.5 * fontScale}px` }}
                  className="font-cairo text-[#25263A] leading-[1.9]"
                >
                  {selectedCompanion.death_details}
                </p>
              </div>

              <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 space-y-3">
                <h3 className="font-cairo font-bold text-base sm:text-lg text-[#4CAF82]">
                  الدروس والعبر التربوية
                </h3>
                <ul className="space-y-2">
                  {selectedCompanion.lessons.map((lesson, i) => (
                    <li
                      key={i}
                      style={{ fontSize: `${15 * fontScale}px` }}
                      className="flex items-start gap-2.5 font-cairo text-[#25263A] bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]"
                    >
                      <span className="w-6 h-6 rounded-full bg-[#5B5FEF] text-[#FFFFFF] font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {i + 1}
                      </span>
                      <span>{lesson}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 space-y-3">
                <h3 className="font-cairo font-bold text-base sm:text-lg text-[#72B7E8]">
                  المصادر والمراجع التاريخية المعتمدة
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedCompanion.sources.map((src, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-2.5 p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] font-cairo text-xs sm:text-sm text-[#25263A]"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="shrink-0">
                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" stroke="#5B5FEF" strokeWidth="2" strokeLinecap="round" />
                        <path d="M6.5 2H20V22H6.5A2.5 2.5 0 0 1 4 19.5V4.5A2.5 2.5 0 0 1 6.5 2Z" stroke="#72B7E8" strokeWidth="2" />
                      </svg>
                      <span>{src}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {toastMessage && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#4CAF82] text-[#FFFFFF] font-cairo font-bold text-sm px-5 py-2.5 rounded-xl shadow-lg">
            {toastMessage}
          </div>
        )}
      </div>
    );
  }

  // ── الشاشة الرئيسية لقسم قصص الصحابة ──
  return (
    <div dir="rtl" className="min-h-screen bg-[#F7F7FC] pb-24">
      {/* ترويسة القسم */}
      <div className="bg-[#FFFFFF] border-b border-[#E6E6F0] px-4 py-4 shadow-[0_2px_10px_rgba(0,0,0,0.04)]">
        <div className="max-w-5xl mx-auto space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onBack}
                aria-label="العودة للرئيسية"
                className="w-10 h-10 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] transition-colors cursor-pointer"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M9 18L15 12L9 6" stroke="#5B5FEF" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>

              <div className="w-12 h-12 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0">
                <IslamicCompanionGoldSvg size={38} gender="male" />
              </div>

              <div>
                <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A]">
                  قصص الصحابة
                </h1>
                <p className="font-cairo text-xs sm:text-sm text-[#77798C]">
                  تراجم ومواقف الصحابة الكرام من أصح كتب السنة والسير والتراجم
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() =>
                setSelectedCategory((prev) => (prev === 'favorites' ? 'all' : 'favorites'))
              }
              className={`px-3.5 py-2 rounded-xl border font-cairo font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer ${
                selectedCategory === 'favorites'
                  ? 'bg-[#5B5FEF] text-[#FFFFFF] border-[#5B5FEF]'
                  : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
              }`}
            >
              <svg
                width="17"
                height="17"
                viewBox="0 0 24 24"
                fill={selectedCategory === 'favorites' ? '#FFFFFF' : 'none'}
              >
                <path
                  d="M12 20.5C12 20.5 4 15.2 4 8.8C4 6.1 6.1 4 8.8 4C10.4 4 11.8 4.8 12 6C12.2 4.8 13.6 4 15.2 4C17.9 4 20 6.1 20 8.8C20 15.2 12 20.5 12 20.5Z"
                  stroke={selectedCategory === 'favorites' ? '#FFFFFF' : '#E8B84A'}
                  strokeWidth="2"
                />
              </svg>
              <span>المفضلة ({favoriteIds.length})</span>
            </button>
          </div>

          {/* شريط البحث السريع */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث باسم الصحابي، اللقب، القصة، أو الحديث..."
              className="w-full bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] rounded-xl py-3 pr-11 pl-10 font-cairo text-sm text-[#25263A] placeholder-[#77798C] focus:outline-none transition-colors"
            />
            <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <circle cx="11" cy="11" r="7" stroke="#5B5FEF" strokeWidth="2.2" />
                <path d="M20 20L16.2 16.2" stroke="#4CAF82" strokeWidth="2.2" strokeLinecap="round" />
              </svg>
            </div>
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="مسح البحث"
                className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-cairo font-bold text-[#77798C] hover:text-[#25263A] cursor-pointer"
              >
                مسح
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 pt-5 space-y-5">
        {/* شبكة التصنيفات الفرعية الـ 8 */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h2 className="font-cairo font-bold text-sm sm:text-base text-[#25263A]">
              التصنيفات الفرعية (8 تصنيفات)
            </h2>
            {selectedCategory !== 'all' && (
              <button
                type="button"
                onClick={() => setSelectedCategory('all')}
                className="font-cairo font-bold text-xs text-[#72B7E8] hover:underline cursor-pointer"
              >
                عرض جميع الصحابة ({allCompanions.length})
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {categories.map((cat) => {
              const active = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedCategory(active ? 'all' : cat.id)}
                  className={`p-3 rounded-2xl border text-right transition-all flex items-center gap-3 cursor-pointer ${
                    active
                      ? 'bg-[#5B5FEF] text-[#FFFFFF] border-[#5B5FEF] shadow-sm'
                      : 'bg-[#FFFFFF] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                  }`}
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                      active ? 'bg-[#FFFFFF]/20' : 'bg-[#F7F7FC] border border-[#E6E6F0]'
                    }`}
                  >
                    <CategoryIconSvg icon={cat.icon} active={active} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div
                      className={`font-cairo font-bold text-xs sm:text-sm truncate ${
                        active ? 'text-[#FFFFFF]' : 'text-[#25263A]'
                      }`}
                    >
                      {cat.name}
                    </div>
                    <div
                      className={`font-cairo text-[11px] ${
                        active ? 'text-[#FFFFFF]/90' : 'text-[#77798C]'
                      }`}
                    >
                      {cat.countLabel}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* قائمة الصحابة */}
        {filteredCompanions.length === 0 ? (
          <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-8 text-center space-y-2">
            <div className="w-14 h-14 mx-auto rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
              <IslamicCompanionGoldSvg size={38} />
            </div>
            <p className="font-cairo font-bold text-base text-[#25263A]">
              {selectedCategory === 'favorites'
                ? 'لم تقم بإضافة تراجم إلى المفضلة بعد'
                : 'لا توجد نتائج مطابقة لعبارة البحث'}
            </p>
            <p className="font-cairo text-xs text-[#77798C]">
              يمكنك البحث باسم الصحابي أو لقبه أو تصفح التصنيفات الثمانية أعلاه
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {filteredCompanions.map((companion) => {
              const isFav = favoriteIds.includes(companion.id);
              return (
                <div
                  key={companion.id}
                  onClick={() => {
                    setSelectedCompanionId(companion.id);
                    setActiveDetailTab('stories');
                  }}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      setSelectedCompanionId(companion.id);
                      setActiveDetailTab('stories');
                    }
                  }}
                  className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] hover:border-[#5B5FEF] p-4 shadow-[0_4px_10px_rgba(0,0,0,0.04)] transition-all cursor-pointer flex flex-col justify-between gap-3"
                >
                  <div className="flex items-start gap-3.5">
                    <div className="w-14 h-14 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0">
                      <IslamicCompanionGoldSvg size={42} gender={companion.gender} />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-cairo font-bold text-base text-[#25263A] leading-snug">
                          {companion.name}
                        </h3>
                        <button
                          type="button"
                          onClick={(e) => toggleFavorite(companion.id, e)}
                          aria-label={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                          className="w-8 h-8 rounded-lg bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 hover:border-[#5B5FEF] cursor-pointer"
                        >
                          <svg width="16" height="16" viewBox="0 0 24 24" fill={isFav ? '#E8B84A' : 'none'}>
                            <path
                              d="M12 20.5C12 20.5 4 15.2 4 8.8C4 6.1 6.1 4 8.8 4C10.4 4 11.8 4.8 12 6C12.2 4.8 13.6 4 15.2 4C17.9 4 20 6.1 20 8.8C20 15.2 12 20.5 12 20.5Z"
                              stroke="#5B5FEF"
                              strokeWidth="2"
                            />
                          </svg>
                        </button>
                      </div>

                      <p className="font-cairo font-bold text-xs text-[#4CAF82] mt-0.5">
                        {companion.title}
                      </p>

                      <p className="font-cairo text-xs text-[#77798C] line-clamp-2 mt-1.5 leading-relaxed">
                        {companion.bio}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2.5 border-t border-[#F7F7FC] text-xs font-cairo">
                    <div className="text-[#77798C]">
                      <span>الوفاة: {companion.death_date}</span>
                      <span className="mx-1.5">•</span>
                      <span className="text-[#72B7E8] font-bold">
                        {companion.stories.length} {companion.stories.length === 1 ? 'قصة موثقة' : 'قصص موثقة'}
                      </span>
                    </div>

                    <span className="font-bold text-[#25263A] flex items-center gap-1">
                      <span>قراءة السيرة</span>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                        <path d="M15 18L9 12L15 6" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#4CAF82] text-[#FFFFFF] font-cairo font-bold text-sm px-5 py-2.5 rounded-xl shadow-lg">
          {toastMessage}
        </div>
      )}
    </div>
  );
};
