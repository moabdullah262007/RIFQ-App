import React, { useState, useEffect, useRef } from 'react';
import {
  BookOpen,
  Sparkles,
  Copy,
  Check,
  Share2,
  X,
  Volume2,
  Bookmark
} from 'lucide-react';
import { DailyToastItem, loadDailyAyahHadithToastConfig } from '../utils/dailyAyahHadithToastService';
import { soundManager } from '../utils/audio';

export const DailyToastNotification: React.FC = () => {
  const [activeItem, setActiveItem] = useState<DailyToastItem | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [progressPercent, setProgressPercent] = useState(100);
  const timerRef = useRef<number | null>(null);
  const progressIntervalRef = useRef<number | null>(null);
  const isHoveredRef = useRef(false);

  useEffect(() => {
    const handleShowToast = (e: Event) => {
      const customEvent = e as CustomEvent<{ item: DailyToastItem }>;
      if (customEvent.detail?.item) {
        const item = customEvent.detail.item;
        setActiveItem(item);
        setIsCopied(false);
        setProgressPercent(100);

        const cfg = loadDailyAyahHadithToastConfig();
        if (cfg.soundEnabled) {
          try {
            soundManager.playBeadClick(0.6, 'soft_chime');
          } catch {
            // ignore
          }
        }

        // Start auto-dismiss countdown
        startDismissTimer(cfg.autoDismissSeconds || 10);
      }
    };

    window.addEventListener('rifq-daily-toast-show', handleShowToast);
    return () => {
      window.removeEventListener('rifq-daily-toast-show', handleShowToast);
      clearTimers();
    };
  }, []);

  const clearTimers = () => {
    if (timerRef.current) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (progressIntervalRef.current) {
      window.clearInterval(progressIntervalRef.current);
      progressIntervalRef.current = null;
    }
  };

  const startDismissTimer = (seconds: number) => {
    clearTimers();
    const durationMs = seconds * 1000;
    const intervalStepMs = 50;
    let elapsedMs = 0;

    progressIntervalRef.current = window.setInterval(() => {
      if (isHoveredRef.current) return; // Pause on hover
      elapsedMs += intervalStepMs;
      const remaining = Math.max(0, 100 - (elapsedMs / durationMs) * 100);
      setProgressPercent(remaining);

      if (elapsedMs >= durationMs) {
        clearTimers();
        setActiveItem(null);
      }
    }, intervalStepMs);
  };

  const handleCopy = async () => {
    if (!activeItem) return;
    const shareText = `${activeItem.text}\n— ${activeItem.source}`;
    try {
      await navigator.clipboard.writeText(shareText);
      setIsCopied(true);
      soundManager.triggerHaptic(25);
      setTimeout(() => setIsCopied(false), 2200);
    } catch {
      // ignore
    }
  };

  const handleShare = async () => {
    if (!activeItem) return;
    const shareText = `${activeItem.text}\n— ${activeItem.source}\n(تطبيق رِفْق | الرفيق الإسلامي)`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: activeItem.type === 'ayah' ? 'آية اليوم المباركة' : 'حديث اليوم الشريف',
          text: shareText,
        });
        return;
      } catch {
        // fallback to copy
      }
    }
    handleCopy();
  };

  const handleDismiss = () => {
    clearTimers();
    setActiveItem(null);
  };

  if (!activeItem) return null;

  const isAyah = activeItem.type === 'ayah';

  return (
    <div
      className="fixed top-18 right-3 left-3 sm:right-6 sm:left-auto sm:max-w-md z-50 animate-bounce-subtle select-none"
      dir="rtl"
      onMouseEnter={() => {
        isHoveredRef.current = true;
      }}
      onMouseLeave={() => {
        isHoveredRef.current = false;
      }}
    >
      <div
        className="rounded-3xl p-4 sm:p-5 shadow-2xl border relative overflow-hidden backdrop-blur-md transition-all duration-300"
        style={{
          backgroundColor: 'var(--theme-surface)',
          borderColor: 'var(--theme-border)',
          color: 'var(--theme-text)',
          boxShadow: 'var(--theme-shadow-strong)',
        }}
      >
        {/* Top header accent glow */}
        <div
          className="absolute top-0 right-0 left-0 h-1.5"
          style={{ background: 'var(--theme-header-gradient)' }}
        />

        {/* Header row */}
        <div className="flex items-center justify-between gap-2 pb-2.5 border-b" style={{ borderColor: 'var(--theme-divider)' }}>
          <div className="flex items-center gap-2">
            <div
              className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0 border"
              style={{
                backgroundColor: 'var(--theme-primary-light)',
                borderColor: 'var(--theme-border)',
                color: 'var(--theme-primary)',
              }}
            >
              {isAyah ? <BookOpen className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span
                  className="px-2 py-0.5 rounded-full text-[10px] font-black font-cairo"
                  style={{
                    backgroundColor: 'var(--theme-primary-light)',
                    color: 'var(--theme-primary)',
                    border: '1px solid var(--theme-border)',
                  }}
                >
                  {isAyah ? '﴿ آية اليوم المباركة ﴾' : '📜 حديث نبوي شريف'}
                </span>
                <span className="text-[10px]" style={{ color: 'var(--theme-text-muted)' }}>
                  تنبيه يومي
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleDismiss}
            className="p-1.5 rounded-xl hover:opacity-80 transition-colors cursor-pointer"
            style={{ color: 'var(--theme-text-muted)' }}
            title="إغلاق التنبيه"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-3 text-center space-y-2">
          <p
            className="font-amiri text-lg sm:text-xl font-bold leading-loose select-text px-1"
            style={{ color: 'var(--theme-text)' }}
          >
            {activeItem.text}
          </p>

          <div className="inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-xl text-xs font-cairo font-bold"
            style={{
              backgroundColor: 'var(--theme-background-secondary)',
              color: 'var(--theme-primary-dark)',
              border: '1px solid var(--theme-border)',
            }}
          >
            <span>{activeItem.source}</span>
          </div>

          {activeItem.benefit && (
            <p
              className="text-xs leading-relaxed font-cairo pt-1 px-2"
              style={{ color: 'var(--theme-text-secondary)' }}
            >
              💡 {activeItem.benefit}
            </p>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t" style={{ borderColor: 'var(--theme-divider)' }}>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleCopy}
              className="px-3 py-1.5 rounded-xl text-xs font-cairo font-bold flex items-center gap-1.5 transition-all cursor-pointer border"
              style={{
                backgroundColor: isCopied ? 'var(--theme-primary)' : 'var(--theme-surface-elevated)',
                color: isCopied ? 'var(--theme-button-text)' : 'var(--theme-text)',
                borderColor: 'var(--theme-border)',
              }}
              title="نسخ الآية أو الحديث"
            >
              {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? 'تم النسخ' : 'نسخ'}</span>
            </button>

            <button
              type="button"
              onClick={handleShare}
              className="px-3 py-1.5 rounded-xl text-xs font-cairo font-bold flex items-center gap-1.5 transition-all cursor-pointer border"
              style={{
                backgroundColor: 'var(--theme-surface-elevated)',
                color: 'var(--theme-text)',
                borderColor: 'var(--theme-border)',
              }}
              title="مشاركة"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشاركة</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleDismiss}
            className="px-3 py-1.5 rounded-xl text-xs font-cairo font-bold transition-all cursor-pointer"
            style={{
              backgroundColor: 'var(--theme-primary-light)',
              color: 'var(--theme-primary)',
            }}
          >
            جزاكم الله خيراً
          </button>
        </div>

        {/* Auto dismiss progress line at bottom */}
        <div
          className="absolute bottom-0 right-0 left-0 h-1 bg-gray-200/40 overflow-hidden"
          style={{ backgroundColor: 'var(--theme-divider)' }}
        >
          <div
            className="h-full transition-all duration-75"
            style={{
              width: `${progressPercent}%`,
              backgroundColor: 'var(--theme-primary)',
            }}
          />
        </div>
      </div>
    </div>
  );
};
