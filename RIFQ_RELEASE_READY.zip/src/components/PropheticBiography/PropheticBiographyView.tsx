import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowRight,
  Search,
  BookOpen,
  Heart,
  Clock,
  Sparkles,
  MapPin,
  Users,
  Calendar,
  Library,
  CheckCircle2,
  ChevronLeft,
  Bookmark,
  Plus,
  Database,
  ShieldCheck,
  X,
  Play,
  Award,
  Filter,
  Compass,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import {
  SeerahChapter,
  SeerahPeriodId,
  SeerahFigure,
  SeerahPlace,
  SeerahFavoriteItem,
  SeerahFavoriteType,
  SeerahReadingProgress,
  SEERAH_PERIODS,
  SEERAH_FIGURES,
  SEERAH_PLACES,
  SEERAH_CANONICAL_SOURCES,
} from '../../data/seerah';
import {
  isSeerahAdmin,
  fetchSeerahChaptersList,
  searchSeerahContent,
  loadSeerahFavorites,
  toggleSeerahFavorite,
  loadSeerahReadingProgress,
  saveSeerahReadingProgress,
  adminSaveSeerahChapter,
  adminDeleteSeerahChapter,
  adminSyncAllCanonicalChaptersToFirestore,
} from '../../utils/seerahService';
import { SeerahChapterReader } from './SeerahChapterReader';
import {
  FigureDetailModal,
  PlaceDetailModal,
  AdminChapterModal,
} from './SeerahModals';

interface PropheticBiographyViewProps {
  onBack: () => void;
}

type MainTab =
  | 'chapters'
  | 'timeline'
  | 'figures'
  | 'places'
  | 'sources'
  | 'favorites';

const QUICK_SEARCH_CHIPS = [
  'بدر',
  'الهجرة',
  'الإسراء والمعراج',
  'عائشة',
  'أبو بكر',
  'فتح مكة',
  'حجة الوداع',
  'أحد',
  'الخندق',
  'الطائف',
];

export const PropheticBiographyView: React.FC<PropheticBiographyViewProps> = ({
  onBack,
}) => {
  const { currentUser } = useAuth();
  const uid = currentUser?.uid;
  const isAdmin = isSeerahAdmin(currentUser?.email);

  const [chapters, setChapters] = useState<SeerahChapter[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<MainTab>('chapters');
  const [selectedPeriod, setSelectedPeriod] = useState<SeerahPeriodId | 'all'>('all');
  const [figureCategoryFilter, setFigureCategoryFilter] = useState<string>('all');
  const [placeRegionFilter, setPlaceRegionFilter] = useState<string>('all');

  // Reader state
  const [activeChapterId, setActiveChapterId] = useState<string | null>(null);
  const [initialSectionId, setInitialSectionId] = useState<string | undefined>(undefined);

  // Modals state
  const [selectedFigure, setSelectedFigure] = useState<SeerahFigure | null>(null);
  const [selectedPlace, setSelectedPlace] = useState<SeerahPlace | null>(null);
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [editingChapter, setEditingChapter] = useState<SeerahChapter | null>(null);
  const [seedingCloud, setSeedingCloud] = useState<boolean>(false);
  const [seedMessage, setSeedMessage] = useState<string | null>(null);

  // Search state
  const [searchQuery, setSearchQuery] = useState<string>('');

  // User data state
  const [favorites, setFavorites] = useState<SeerahFavoriteItem[]>([]);
  const [progress, setProgress] = useState<SeerahReadingProgress>({
    userId: uid || 'guest',
    lastChapterId: 'ch_01_lineage_makkah',
    lastChapterTitle: 'الفصل الأول: نسب النبي ﷺ وأحوال مكة والعرب قبل البعثة',
    lastSectionId: '',
    lastSectionTitle: '',
    scrollPercent: 0,
    completedChapterIds: [],
    updatedAt: new Date().toISOString(),
  });

  useEffect(() => {
    let mounted = true;
    const initData = async () => {
      setLoading(true);
      try {
        const [loadedChapters, loadedFavs, loadedProg] = await Promise.all([
          fetchSeerahChaptersList(isAdmin),
          loadSeerahFavorites(uid),
          loadSeerahReadingProgress(uid),
        ]);
        if (!mounted) return;
        setChapters(loadedChapters);
        setFavorites(loadedFavs);
        if (loadedProg) {
          setProgress(loadedProg);
        }
      } catch (err) {
        console.error('Error loading Seerah data:', err);
      } finally {
        if (mounted) setLoading(false);
      }
    };
    initData();
    return () => {
      mounted = false;
    };
  }, [uid, isAdmin]);

  // Filtered chapters by period
  const filteredChapters = useMemo(() => {
    if (selectedPeriod === 'all') return chapters;
    return chapters.filter((ch) => ch.period === selectedPeriod);
  }, [chapters, selectedPeriod]);

  // Search results
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    return searchSeerahContent(searchQuery, chapters);
  }, [searchQuery, chapters]);

  // Active chapter object
  const activeChapter = useMemo(() => {
    if (!activeChapterId) return null;
    return chapters.find((c) => c.id === activeChapterId) || null;
  }, [activeChapterId, chapters]);

  const activeChapterIndex = useMemo(() => {
    if (!activeChapterId) return -1;
    return chapters.findIndex((c) => c.id === activeChapterId);
  }, [activeChapterId, chapters]);

  const prevChapter =
    activeChapterIndex > 0 ? chapters[activeChapterIndex - 1] : null;
  const nextChapter =
    activeChapterIndex >= 0 && activeChapterIndex < chapters.length - 1
      ? chapters[activeChapterIndex + 1]
      : null;

  // Last read chapter object for "Continue Reading" banner
  const lastReadChapter = useMemo(() => {
    return (
      chapters.find((c) => c.id === progress.lastChapterId) || chapters[0] || null
    );
  }, [chapters, progress.lastChapterId]);

  const completionPercentage = useMemo(() => {
    if (chapters.length === 0) return 0;
    return Math.round(
      (progress.completedChapterIds.length / chapters.length) * 100
    );
  }, [chapters.length, progress.completedChapterIds.length]);

  // Handlers
  const handleOpenChapter = async (chapterId: string, sectionId?: string) => {
    const ch = chapters.find((c) => c.id === chapterId);
    setActiveChapterId(chapterId);
    setInitialSectionId(sectionId);
    if (ch) {
      const sec = sectionId ? ch.sections.find((s) => s.id === sectionId) : ch.sections[0];
      const updated = await saveSeerahReadingProgress(uid, {
        lastChapterId: ch.id,
        lastChapterTitle: ch.title,
        lastSectionId: sec?.id || '',
        lastSectionTitle: sec?.title || '',
      });
      setProgress(updated);
    }
  };

  const handleToggleFavorite = async (item: {
    type: SeerahFavoriteType;
    targetId: string;
    chapterId?: string;
    title: string;
    subtitle: string;
    periodTitle?: string;
  }) => {
    const result = await toggleSeerahFavorite(uid, item);
    setFavorites(result.favorites);
  };

  const handleSaveProgress = async (
    sectionId: string,
    sectionTitle: string,
    markCompleted?: boolean
  ) => {
    if (!activeChapter) return;
    const updated = await saveSeerahReadingProgress(uid, {
      lastChapterId: activeChapter.id,
      lastChapterTitle: activeChapter.title,
      lastSectionId: sectionId,
      lastSectionTitle: sectionTitle,
      markChapterCompleted: markCompleted,
    });
    setProgress(updated);
  };

  const handleSeedCloud = async () => {
    setSeedingCloud(true);
    setSeedMessage(null);
    const res = await adminSyncAllCanonicalChaptersToFirestore();
    setSeedingCloud(false);
    setSeedMessage(res.message);
    setTimeout(() => setSeedMessage(null), 4000);
  };

  const handleAdminSaveChapter = async (chapter: SeerahChapter) => {
    await adminSaveSeerahChapter(chapter);
    const refreshed = await fetchSeerahChaptersList(isAdmin);
    setChapters(refreshed);
  };

  const handleAdminDeleteChapter = async (chapterId: string) => {
    await adminDeleteSeerahChapter(chapterId);
    const refreshed = await fetchSeerahChaptersList(isAdmin);
    setChapters(refreshed);
    setActiveChapterId(null);
  };

  const isFavorited = (type: SeerahFavoriteType, targetId: string) =>
    favorites.some((f) => f.id === `${type}_${targetId}` || f.targetId === targetId);

  // If currently inside a chapter reader, render the full E-Book Reader
  if (activeChapter) {
    return (
      <>
        <SeerahChapterReader
          chapter={activeChapter}
          prevChapter={prevChapter}
          nextChapter={nextChapter}
          figures={SEERAH_FIGURES}
          places={SEERAH_PLACES}
          initialSectionId={initialSectionId}
          isChapterFavorite={isFavorited('chapter', activeChapter.id)}
          isSectionFavorite={(secId) => isFavorited('section', secId)}
          isCompleted={progress.completedChapterIds.includes(activeChapter.id)}
          isAdmin={isAdmin}
          onBackToIndex={() => {
            setActiveChapterId(null);
            setInitialSectionId(undefined);
          }}
          onSelectChapter={(chId, secId) => handleOpenChapter(chId, secId)}
          onToggleFavorite={handleToggleFavorite}
          onSaveProgress={handleSaveProgress}
          onOpenFigure={(fig) => setSelectedFigure(fig)}
          onOpenPlace={(pl) => setSelectedPlace(pl)}
          onAdminEdit={(ch) => {
            setEditingChapter(ch);
            setShowAdminModal(true);
          }}
          onAdminDelete={handleAdminDeleteChapter}
        />

        <FigureDetailModal
          figure={selectedFigure}
          chapters={chapters}
          isFavorite={selectedFigure ? isFavorited('figure', selectedFigure.id) : false}
          onClose={() => setSelectedFigure(null)}
          onToggleFavorite={() => {
            if (!selectedFigure) return;
            handleToggleFavorite({
              type: 'figure',
              targetId: selectedFigure.id,
              title: selectedFigure.name,
              subtitle: selectedFigure.titleOrKunya,
              periodTitle: selectedFigure.categoryLabel,
            });
          }}
          onOpenChapter={(chId) => {
            setSelectedFigure(null);
            handleOpenChapter(chId);
          }}
        />

        <PlaceDetailModal
          place={selectedPlace}
          chapters={chapters}
          isFavorite={selectedPlace ? isFavorited('place', selectedPlace.id) : false}
          onClose={() => setSelectedPlace(null)}
          onToggleFavorite={() => {
            if (!selectedPlace) return;
            handleToggleFavorite({
              type: 'place',
              targetId: selectedPlace.id,
              title: selectedPlace.name,
              subtitle: selectedPlace.regionLabel,
              periodTitle: selectedPlace.modernLocation,
            });
          }}
          onOpenChapter={(chId) => {
            setSelectedPlace(null);
            handleOpenChapter(chId);
          }}
        />

        <AdminChapterModal
          isOpen={showAdminModal}
          initialChapter={editingChapter}
          totalChaptersCount={chapters.length}
          onClose={() => {
            setShowAdminModal(false);
            setEditingChapter(null);
          }}
          onSaveChapter={handleAdminSaveChapter}
          onSyncAllToCloud={handleSeedCloud}
        />
      </>
    );
  }

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#FBF9FE] via-[#F5F2FA] to-[#EFEBF7] pb-28 font-tajawal"
      dir="rtl"
    >
      {/* Hero Encyclopedia Header */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#1A2138] via-[#261E47] to-[#3A2866] text-white pt-6 pb-7 px-4 rounded-b-[2.5rem] shadow-xl border-b border-[#D4AF37]/30">
        {/* Subtle starry pattern overlay */}
        <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#E8C15A_1px,transparent_1px)] [background-size:20px_20px]" />

        <div className="max-w-4xl mx-auto relative z-10">
          {/* Top Bar */}
          <div className="flex items-center justify-between mb-5">
            <button
              type="button"
              onClick={onBack}
              className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-white font-bold text-xs transition-all cursor-pointer border border-white/15"
            >
              <ArrowRight className="w-4 h-4" />
              <span>الرئيسية</span>
            </button>

            <div className="flex items-center gap-2">
              {currentUser && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingChapter(null);
                    setShowAdminModal(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#D4AF37]/20 hover:bg-[#D4AF37]/30 text-[#F8E296] border border-[#D4AF37]/40 text-[11px] font-bold transition-all cursor-pointer"
                  title="إضافة أو إدارة فصول السيرة النبوية"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إدارة المحتوى</span>
                </button>
              )}

              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-200 text-[11px] font-black">
                <Award className="w-3.5 h-3.5 text-emerald-300" />
                <span>إنجاز القراءة: {completionPercentage}%</span>
              </div>
            </div>
          </div>

          {/* Title & Custom Emblem */}
          <div className="flex items-center gap-4 mb-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full p-1 bg-gradient-to-tr from-[#B38728] via-[#FBF5B7] to-[#AA771C] shadow-lg shrink-0">
              <div className="w-full h-full rounded-full bg-[#19233C] flex items-center justify-center overflow-hidden relative">
                <img
                  src="/assets/icons/menu/ic_seerah.svg"
                  alt="السيرة النبوية"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).style.display = 'none';
                  }}
                />
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 text-[#F8E296] text-[10px] font-black mb-1.5">
                <Sparkles className="w-3 h-3" />
                <span>الموسوعة الشاملة المحققة • من المولد إلى الرفيق الأعلى ﷺ</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black font-cairo text-white tracking-tight">
                السيرة النبوية الشريفة
              </h1>
              <p className="text-xs sm:text-sm text-purple-100/85 font-medium mt-1 leading-relaxed">
                كتاب إلكتروني موسوعي مفصّل يستعرض حياة خاتم الأنبياء محمد ﷺ فصلًا بعد فصل بالروايات الصحيحة والمصادر المعتمدة
              </p>
            </div>
          </div>

          {/* Global Encyclopedia Stats Bar */}
          <div className="grid grid-cols-4 gap-2 sm:gap-3 mb-5">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 text-center border border-white/10">
              <p className="text-base sm:text-lg font-black text-[#F8E296]">
                {chapters.length}
              </p>
              <p className="text-[10px] text-purple-100/80 font-bold">
                فصلًا موسوعيًا
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 text-center border border-white/10">
              <p className="text-base sm:text-lg font-black text-[#F8E296]">
                {SEERAH_PERIODS.length}
              </p>
              <p className="text-[10px] text-purple-100/80 font-bold">
                مرحلة تاريخية
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 text-center border border-white/10">
              <p className="text-base sm:text-lg font-black text-[#F8E296]">
                {SEERAH_FIGURES.length}+
              </p>
              <p className="text-[10px] text-purple-100/80 font-bold">
                شخصية وصحابي
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-2.5 text-center border border-white/10">
              <p className="text-base sm:text-lg font-black text-[#F8E296]">
                {SEERAH_PLACES.length}+
              </p>
              <p className="text-[10px] text-purple-100/80 font-bold">
                معلم وموقع نبوي
              </p>
            </div>
          </div>

          {/* Search Input inside Hero */}
          <div className="relative">
            <Search className="w-4 h-4 text-purple-200 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في السيرة: (بدر، الهجرة، الإسراء والمعراج، عائشة، أبو بكر، فتح مكة، حجة الوداع...)"
              className="w-full pr-11 pl-10 py-3.5 rounded-2xl bg-white/15 hover:bg-white/20 focus:bg-white text-white focus:text-slate-900 placeholder-purple-200/75 focus:placeholder-slate-400 text-xs sm:text-sm font-bold border border-white/20 focus:border-[#D4AF37] outline-none transition-all shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-slate-200/30 hover:bg-slate-300/50 text-current flex items-center justify-center cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Search Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-2.5 pb-1">
            <span className="text-[10px] font-bold text-[#F8E296] shrink-0 ml-1">
              بحث سريع:
            </span>
            {QUICK_SEARCH_CHIPS.map((chip) => (
              <button
                key={chip}
                type="button"
                onClick={() =>
                  setSearchQuery((prev) => (prev === chip ? '' : chip))
                }
                className={`px-2.5 py-1 rounded-full text-[10px] font-bold shrink-0 transition-all cursor-pointer ${
                  searchQuery === chip
                    ? 'bg-[#D4AF37] text-slate-950 shadow-sm'
                    : 'bg-white/10 hover:bg-white/20 text-purple-100 border border-white/10'
                }`}
              >
                {chip}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 mt-5 space-y-5">
        {/* Search Results Panel (when active) */}
        {searchQuery.trim() !== '' && (
          <div className="bg-white rounded-3xl p-5 shadow-md border border-purple-100 animate-fade-in">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-[#5D4E8C]" />
                <h2 className="text-sm font-black text-slate-800">
                  نتائج البحث في الموسوعة عن «{searchQuery}»
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-black bg-purple-100 text-[#5D4E8C]">
                  {searchResults.length} نتيجة
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-xs font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                إغلاق البحث
              </button>
            </div>

            {searchResults.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-sm font-bold text-slate-500">
                  لم يتم العثور على نتائج مطابقة لـ "{searchQuery}"
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  جرّب البحث بكلمات مثل: غزوة بدر، الهجرة، خديجة، الوحي، الطائف، حجة الوداع
                </p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
                {searchResults.map((res, idx) => (
                  <button
                    key={`${res.id}-${idx}`}
                    type="button"
                    onClick={() => {
                      if (res.type === 'figure' && res.figureId) {
                        const fig = SEERAH_FIGURES.find((f) => f.id === res.figureId);
                        if (fig) setSelectedFigure(fig);
                      } else if (res.type === 'place' && res.placeId) {
                        const pl = SEERAH_PLACES.find((p) => p.id === res.placeId);
                        if (pl) setSelectedPlace(pl);
                      } else if (res.chapterId) {
                        handleOpenChapter(res.chapterId, res.sectionId);
                      }
                    }}
                    className="w-full text-right p-3.5 rounded-2xl bg-slate-50/80 hover:bg-purple-50/70 border border-slate-200/70 hover:border-purple-300 transition-all flex items-start justify-between gap-3 cursor-pointer"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-[#5D4E8C]/10 text-[#5D4E8C]">
                          {res.typeLabel}
                        </span>
                      </div>
                      <h4 className="text-sm font-black text-slate-800">
                        {res.title}
                      </h4>
                      <p className="text-[11px] font-bold text-[#5D4E8C]">
                        {res.subtitle}
                      </p>
                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {res.snippet}
                      </p>
                    </div>
                    <ChevronLeft className="w-4 h-4 text-slate-400 shrink-0 mt-2" />
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* "📖 تابع القراءة" (Continue Reading Card) */}
        {lastReadChapter && !searchQuery.trim() && (
          <div className="bg-gradient-to-r from-[#2D2250] via-[#3B2D66] to-[#4A387B] rounded-3xl p-4 sm:p-5 text-white shadow-lg border border-[#D4AF37]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center shrink-0 text-[#F8E296]">
                <BookOpen className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#D4AF37] text-slate-950">
                    📖 تابع القراءة من حيث توقفت
                  </span>
                  <span className="text-[11px] text-purple-200 font-bold">
                    الفصل {lastReadChapter.order} من {chapters.length}
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black font-cairo text-white mt-1">
                  {lastReadChapter.title}
                </h3>
                <p className="text-xs text-purple-200/90 mt-0.5 line-clamp-1">
                  {progress.lastSectionTitle
                    ? `${progress.lastSectionTitle} • ${lastReadChapter.hijriYear}`
                    : `${lastReadChapter.subtitle} • ${lastReadChapter.hijriYear}`}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() =>
                handleOpenChapter(
                  lastReadChapter.id,
                  progress.lastSectionId || undefined
                )
              }
              className="flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#D4AF37] to-[#E6C55A] hover:opacity-95 text-slate-950 font-black text-xs shadow-md shrink-0 transition-all cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>متابعة القراءة الآن</span>
            </button>
          </div>
        )}

        {/* Main Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {[
            {
              id: 'chapters' as MainTab,
              label: 'فصول الكتاب',
              icon: BookOpen,
              count: chapters.length,
            },
            {
              id: 'timeline' as MainTab,
              label: 'التسلسل الزمني',
              icon: Calendar,
              count: SEERAH_PERIODS.length,
            },
            {
              id: 'figures' as MainTab,
              label: 'شخصيات السيرة',
              icon: Users,
              count: SEERAH_FIGURES.length,
            },
            {
              id: 'places' as MainTab,
              label: 'أماكن السيرة',
              icon: MapPin,
              count: SEERAH_PLACES.length,
            },
            {
              id: 'sources' as MainTab,
              label: 'المصادر والتحقيق',
              icon: Library,
              count: SEERAH_CANONICAL_SOURCES.length,
            },
            {
              id: 'favorites' as MainTab,
              label: 'المفضلة',
              icon: Heart,
              count: favorites.length,
            },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black shrink-0 transition-all cursor-pointer border ${
                  active
                    ? 'bg-[#5D4E8C] text-white border-[#5D4E8C] shadow-md'
                    : 'bg-white text-slate-700 border-purple-100 hover:bg-purple-50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                    active
                      ? 'bg-white/20 text-white'
                      : 'bg-purple-50 text-[#5D4E8C]'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: CHAPTERS (فصول الكتاب) */}
        {activeTab === 'chapters' && (
          <div className="space-y-4">
            {/* Period Filter Pills */}
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-purple-100">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-xs font-black text-slate-700 flex items-center gap-1.5">
                  <Filter className="w-3.5 h-3.5 text-[#5D4E8C]" />
                  تصفية الفصول حسب المرحلة التاريخية:
                </span>
                {selectedPeriod !== 'all' && (
                  <button
                    type="button"
                    onClick={() => setSelectedPeriod('all')}
                    className="text-[11px] font-bold text-[#5D4E8C] hover:underline cursor-pointer"
                  >
                    عرض كل المراحل ({chapters.length})
                  </button>
                )}
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                <button
                  type="button"
                  onClick={() => setSelectedPeriod('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                    selectedPeriod === 'all'
                      ? 'bg-amber-500 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  كل الفصول ({chapters.length})
                </button>
                {SEERAH_PERIODS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setSelectedPeriod(p.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                      selectedPeriod === p.id
                        ? 'bg-[#5D4E8C] text-white shadow-sm'
                        : 'bg-slate-100 text-slate-600 hover:bg-purple-50 hover:text-[#5D4E8C]'
                    }`}
                  >
                    {p.order}. {p.title}
                  </button>
                ))}
              </div>
            </div>

            {/* Chapters List */}
            {loading ? (
              <div className="bg-white rounded-3xl p-12 text-center border border-purple-100">
                <div className="w-10 h-10 border-4 border-[#5D4E8C] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <p className="text-sm font-bold text-slate-600">
                  جاري تحميل فصول السيرة النبوية الشريفة...
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {filteredChapters.map((chapter) => {
                  const isCompleted = progress.completedChapterIds.includes(
                    chapter.id
                  );
                  const isFav = isFavorited('chapter', chapter.id);
                  const totalSubsections = chapter.sections.reduce(
                    (acc, s) => acc + (s.subsections ? s.subsections.length : 0),
                    0
                  );

                  return (
                    <div
                      key={chapter.id}
                      className="bg-white rounded-3xl p-5 shadow-sm hover:shadow-md border border-purple-100/90 transition-all group"
                    >
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#5D4E8C] to-[#3B2D66] text-white font-black text-xs flex items-center justify-center shadow-sm">
                            {chapter.order}
                          </span>
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-black bg-purple-50 text-[#5D4E8C] border border-purple-200/60">
                            {chapter.periodTitle}
                          </span>
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200/60">
                            {chapter.hijriYear} • {chapter.gregorianYear}
                          </span>
                          {isCompleted && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3" />
                              تمت القراءة
                            </span>
                          )}
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleFavorite({
                              type: 'chapter',
                              targetId: chapter.id,
                              chapterId: chapter.id,
                              title: chapter.title,
                              subtitle: chapter.subtitle,
                              periodTitle: chapter.periodTitle,
                            });
                          }}
                          className={`p-2 rounded-xl border transition-all cursor-pointer ${
                            isFav
                              ? 'bg-rose-50 border-rose-200 text-rose-600'
                              : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-rose-500'
                          }`}
                          title="حفظ الفصل في المفضلة"
                        >
                          <Heart
                            className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`}
                          />
                        </button>
                      </div>

                      <div
                        onClick={() => handleOpenChapter(chapter.id)}
                        className="cursor-pointer"
                      >
                        <h3 className="text-lg sm:text-xl font-black font-cairo text-slate-900 group-hover:text-[#5D4E8C] transition-colors">
                          {chapter.title}
                        </h3>
                        <p className="text-xs sm:text-sm font-bold text-[#5D4E8C] mt-1">
                          {chapter.subtitle}
                        </p>
                        <p className="text-xs sm:text-sm text-slate-600 mt-2.5 leading-relaxed line-clamp-3">
                          {chapter.summary}
                        </p>

                        {/* Section Preview Pills */}
                        <div className="mt-4 pt-3 border-t border-slate-100">
                          <p className="text-[11px] font-black text-slate-500 mb-2">
                            مباحث وأقسام هذا الفصل ({chapter.sections.length}{' '}
                            مباحث
                            {totalSubsections > 0
                              ? ` • ${totalSubsections} عنوانًا فرعيًا`
                              : ''}
                            ):
                          </p>
                          <div className="flex flex-wrap gap-1.5">
                            {chapter.sections.map((sec) => (
                              <button
                                key={sec.id}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleOpenChapter(chapter.id, sec.id);
                                }}
                                className="px-2.5 py-1 rounded-xl text-[11px] font-bold bg-slate-50 hover:bg-purple-50 text-slate-700 hover:text-[#5D4E8C] border border-slate-200/80 transition-all cursor-pointer"
                              >
                                • {sec.title}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Bottom Metadata & Read CTA */}
                        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-3 text-[11px] font-bold text-slate-500">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-amber-600" />
                              {chapter.readingTimeMinutes} دقيقة قراءة
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                              {chapter.locationName}
                            </span>
                            <span className="flex items-center gap-1">
                              <Library className="w-3.5 h-3.5 text-purple-600" />
                              {chapter.sources.length} مصادر معتمدة
                            </span>
                          </div>

                          <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#5D4E8C] group-hover:bg-[#4A3D73] text-white text-xs font-black transition-all shadow-sm">
                            <BookOpen className="w-3.5 h-3.5" />
                            <span>قراءة الفصل كاملًا</span>
                            <ChevronLeft className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: CHRONOLOGICAL TIMELINE (التسلسل الزمني) */}
        {activeTab === 'timeline' && (
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-5 shadow-sm border border-purple-100">
              <h2 className="text-base sm:text-lg font-black font-cairo text-slate-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-[#5D4E8C]" />
                <span>التسلسل الزمني الكامل للسيرة النبوية (11 مرحلة تاريخية)</span>
              </h2>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                رحلة زمنية متسلسلة من أحوال مكة ونسب النبي ﷺ قبل البعثة، مرورًا بنزول الوحي والهجرة والغزوات الكبرى، وصولًا إلى حجة الوداع والالتحاق بالرفيق الأعلى ﷺ. اضغط على أي حدث لفتح فصله الكامل.
              </p>
            </div>

            <div className="relative pr-4 sm:pr-8 border-r-2 border-[#D4AF37]/60 space-y-8 mr-2">
              {SEERAH_PERIODS.map((period) => {
                const periodChapters = chapters.filter(
                  (c) => c.period === period.id
                );
                return (
                  <div key={period.id} className="relative">
                    {/* Timeline Node Badge */}
                    <div className="-right-[27px] sm:-right-[43px] top-1 w-6 h-6 rounded-full bg-gradient-to-br from-[#D4AF37] to-[#9A7418] text-white font-black text-[11px] flex items-center justify-center shadow-md border-2 border-white absolute">
                      {period.order}
                    </div>

                    <div className="bg-white rounded-3xl p-5 shadow-sm border border-purple-100">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-50 text-amber-800 border border-amber-200">
                          {period.dateRange}
                        </span>
                        <span className="text-xs font-bold text-[#5D4E8C]">
                          {periodChapters.length} فصول تفصيلية
                        </span>
                      </div>

                      <h3 className="text-lg font-black font-cairo text-slate-900">
                        {period.title}
                      </h3>
                      <p className="text-xs font-bold text-[#5D4E8C] mt-0.5">
                        {period.subtitle}
                      </p>
                      <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                        {period.description}
                      </p>

                      {/* Chapters inside this Period */}
                      <div className="mt-4 space-y-2.5">
                        {periodChapters.map((ch) => (
                          <button
                            key={ch.id}
                            type="button"
                            onClick={() => handleOpenChapter(ch.id)}
                            className="w-full text-right p-3.5 rounded-2xl bg-slate-50 hover:bg-purple-50/70 border border-slate-200/80 hover:border-purple-300 transition-all flex items-center justify-between gap-3 cursor-pointer"
                          >
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 rounded-md bg-[#5D4E8C] text-white text-[10px] font-black">
                                  الفصل {ch.order}
                                </span>
                                <span className="text-[11px] font-bold text-amber-700">
                                  {ch.hijriYear}
                                </span>
                              </div>
                              <p className="text-sm font-black text-slate-800 mt-1">
                                {ch.title}
                              </p>
                              <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                                {ch.subtitle}
                              </p>
                            </div>
                            <ChevronLeft className="w-4 h-4 text-[#5D4E8C] shrink-0" />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: FIGURES (شخصيات السيرة) */}
        {activeTab === 'figures' && (
          <div className="space-y-4">
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-purple-100">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                {[
                  { id: 'all', label: 'كل الشخصيات' },
                  { id: 'household', label: 'آل البيت وأمهات المؤمنين' },
                  { id: 'rightly_guided', label: 'الخلفاء الراشدون' },
                  { id: 'muhajirun', label: 'المهاجرون السابقون' },
                  { id: 'ansar', label: 'أعلام الأنصار' },
                  { id: 'other_historical', label: 'شخصيات وملوك معاصرون' },
                ].map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setFigureCategoryFilter(cat.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                      figureCategoryFilter === cat.id
                        ? 'bg-[#5D4E8C] text-white shadow-sm'
                        : 'bg-slate-100 text-slate-600 hover:bg-purple-50'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {SEERAH_FIGURES.filter(
                (f) =>
                  figureCategoryFilter === 'all' ||
                  f.category === figureCategoryFilter
              ).map((figure) => {
                const isFav = isFavorited('figure', figure.id);
                return (
                  <div
                    key={figure.id}
                    onClick={() => setSelectedFigure(figure)}
                    className="bg-white rounded-3xl p-5 shadow-sm hover:shadow-md border border-purple-100 transition-all cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-black bg-purple-50 text-[#5D4E8C] border border-purple-200/60">
                          {figure.categoryLabel}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleFavorite({
                              type: 'figure',
                              targetId: figure.id,
                              title: figure.name,
                              subtitle: figure.titleOrKunya,
                              periodTitle: figure.categoryLabel,
                            });
                          }}
                          className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                            isFav
                              ? 'bg-rose-50 border-rose-200 text-rose-600'
                              : 'bg-slate-50 border-slate-200 text-slate-400'
                          }`}
                        >
                          <Heart
                            className={`w-3.5 h-3.5 ${
                              isFav ? 'fill-current' : ''
                            }`}
                          />
                        </button>
                      </div>

                      <h3 className="text-base font-black font-cairo text-slate-900">
                        {figure.name}{' '}
                        <span className="text-xs font-bold text-amber-700">
                          ({figure.honorific})
                        </span>
                      </h3>
                      <p className="text-xs font-bold text-[#5D4E8C] mt-0.5">
                        {figure.titleOrKunya}
                      </p>
                      <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                        {figure.summary}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-[#5D4E8C]">
                      <span>{figure.relatedChapterIds.length} فصول مرتبطة</span>
                      <span className="flex items-center gap-1">
                        عرض السيرة والمواقف
                        <ChevronLeft className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 4: PLACES (أماكن السيرة) */}
        {activeTab === 'places' && (
          <div className="space-y-4">
            <div className="bg-white rounded-3xl p-4 shadow-sm border border-purple-100">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                {[
                  { id: 'all', label: 'كل المعالم والأماكن' },
                  { id: 'makkah', label: 'مكة المكرمة والمشاعر' },
                  { id: 'madinah', label: 'المدينة المنورة وما حولها' },
                  { id: 'hijaz_north', label: 'مواقع الغزوات والحجاز' },
                  { id: 'sham_ethiopia', label: 'القدس والشام والحبشة' },
                ].map((reg) => (
                  <button
                    key={reg.id}
                    type="button"
                    onClick={() => setPlaceRegionFilter(reg.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                      placeRegionFilter === reg.id
                        ? 'bg-[#5D4E8C] text-white shadow-sm'
                        : 'bg-slate-100 text-slate-600 hover:bg-purple-50'
                    }`}
                  >
                    {reg.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {SEERAH_PLACES.filter(
                (p) =>
                  placeRegionFilter === 'all' || p.region === placeRegionFilter
              ).map((place) => {
                const isFav = isFavorited('place', place.id);
                return (
                  <div
                    key={place.id}
                    onClick={() => setSelectedPlace(place)}
                    className="bg-white rounded-3xl p-5 shadow-sm hover:shadow-md border border-purple-100 transition-all cursor-pointer flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <Compass className="w-3 h-3" />
                          {place.regionLabel}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleToggleFavorite({
                              type: 'place',
                              targetId: place.id,
                              title: place.name,
                              subtitle: place.regionLabel,
                              periodTitle: place.modernLocation,
                            });
                          }}
                          className={`p-1.5 rounded-xl border transition-all cursor-pointer ${
                            isFav
                              ? 'bg-rose-50 border-rose-200 text-rose-600'
                              : 'bg-slate-50 border-slate-200 text-slate-400'
                          }`}
                        >
                          <Heart
                            className={`w-3.5 h-3.5 ${
                              isFav ? 'fill-current' : ''
                            }`}
                          />
                        </button>
                      </div>

                      <h3 className="text-base font-black font-cairo text-slate-900">
                        {place.name}
                      </h3>
                      <p className="text-[11px] font-bold text-slate-500 mt-0.5">
                        {place.modernLocation}
                      </p>
                      <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                        {place.summary}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-[#5D4E8C]">
                      <span>{place.historicalSignificance.length} أحداث ومعالم</span>
                      <span className="flex items-center gap-1">
                        تفاصيل المكان والأحداث
                        <ChevronLeft className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 5: AUTHENTICATED SOURCES (المصادر والتحقيق العلمي) */}
        {activeTab === 'sources' && (
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 rounded-3xl p-5 text-white shadow-md">
              <div className="flex items-start gap-3">
                <ShieldCheck className="w-7 h-7 text-emerald-300 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-base sm:text-lg font-black font-cairo">
                    منهجية التحقيق العلمي والتوثيق في قسم السيرة النبوية
                  </h3>
                  <p className="text-xs text-emerald-100/90 mt-1.5 leading-relaxed">
                    اعتمدنا في بناء هذه الموسوعة على أصح ما ثبت في القرآن الكريم، والصحيحين (البخاري ومسلم)، وأمهات كتب السيرة النبوية المحققة. وعند إيراد خبر مشهور في كتب المغازي لا يثبت إسناده، يتم التنبيه عليه صراحةً في صندوق «تحقيق الروايات» ليكون القارئ على بصيرة تامة.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {SEERAH_CANONICAL_SOURCES.map((src, i) => (
                <div
                  key={src.id}
                  className="bg-white rounded-3xl p-5 shadow-sm border border-purple-100"
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-purple-50 text-[#5D4E8C]">
                      مرجع معتمد #{i + 1}
                    </span>
                    {src.volumeOrSection && (
                      <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
                        {src.volumeOrSection}
                      </span>
                    )}
                  </div>
                  <h4 className="text-base font-black font-cairo text-slate-900">
                    {src.bookTitle}
                  </h4>
                  <p className="text-xs font-bold text-amber-700 mt-0.5">
                    المؤلف: {src.author}
                  </p>
                  {src.note && (
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                      {src.note}
                    </p>
                  )}
                </div>
              ))}
            </div>

            {currentUser && (
              <div className="bg-white rounded-3xl p-5 shadow-sm border border-purple-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <Database className="w-6 h-6 text-[#5D4E8C] shrink-0" />
                  <div>
                    <h4 className="text-sm font-black text-slate-800">
                      مزامنة بيانات السيرة النبوية مع السحابة (Firestore)
                    </h4>
                    <p className="text-xs text-slate-500">
                      يمكنك رفع وتحديث الفصول والشخصيات والأماكن في مجموعات Firestore لتكون متاحة للتوسع المستمر.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleSeedCloud}
                  disabled={seedingCloud}
                  className="px-4 py-2.5 rounded-2xl bg-[#5D4E8C] hover:bg-[#4A3D73] text-white text-xs font-black shrink-0 cursor-pointer disabled:opacity-50"
                >
                  {seedingCloud
                    ? 'جاري المزامنة...'
                    : 'مزامنة قاعدة البيانات السحابية'}
                </button>
              </div>
            )}
            {seedMessage && (
              <p className="text-center text-xs font-bold text-emerald-700 bg-emerald-50 p-3 rounded-2xl border border-emerald-200">
                {seedMessage}
              </p>
            )}
          </div>
        )}

        {/* TAB 6: FAVORITES (المفضلة) */}
        {activeTab === 'favorites' && (
          <div className="space-y-4">
            {favorites.length === 0 ? (
              <div className="bg-white rounded-3xl p-10 text-center border border-purple-100">
                <Bookmark className="w-10 h-10 text-purple-300 mx-auto mb-3" />
                <h3 className="text-base font-black text-slate-800">
                  قائمة المفضلة فارغة حاليًا
                </h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto leading-relaxed">
                  يمكنك حفظ أي فصل أو مبحث أو شخصية أو مكان أثناء قراءتك للسيرة النبوية للرجوع إليه في أي وقت.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3">
                {favorites.map((fav) => (
                  <div
                    key={fav.id}
                    onClick={() => {
                      if (fav.type === 'figure') {
                        const fig = SEERAH_FIGURES.find(
                          (f) => f.id === fav.targetId
                        );
                        if (fig) setSelectedFigure(fig);
                      } else if (fav.type === 'place') {
                        const pl = SEERAH_PLACES.find(
                          (p) => p.id === fav.targetId
                        );
                        if (pl) setSelectedPlace(pl);
                      } else if (fav.chapterId) {
                        handleOpenChapter(
                          fav.chapterId,
                          fav.type === 'section' ? fav.targetId : undefined
                        );
                      }
                    }}
                    className="bg-white rounded-2xl p-4 shadow-sm hover:shadow-md border border-purple-100 flex items-center justify-between gap-3 cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md bg-purple-50 text-[#5D4E8C] text-[10px] font-black">
                          {fav.type === 'chapter'
                            ? 'فصل كامل'
                            : fav.type === 'section'
                            ? 'مبحث'
                            : fav.type === 'figure'
                            ? 'شخصية نبوية'
                            : 'معلم تاريخي'}
                        </span>
                        {fav.periodTitle && (
                          <span className="text-[10px] font-bold text-amber-700">
                            {fav.periodTitle}
                          </span>
                        )}
                      </div>
                      <h4 className="text-sm font-black text-slate-900 mt-1">
                        {fav.title}
                      </h4>
                      <p className="text-xs text-slate-500">{fav.subtitle}</p>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleFavorite({
                          type: fav.type,
                          targetId: fav.targetId,
                          chapterId: fav.chapterId,
                          title: fav.title,
                          subtitle: fav.subtitle,
                          periodTitle: fav.periodTitle,
                        });
                      }}
                      className="p-2 rounded-xl bg-rose-50 text-rose-600 hover:bg-rose-100 cursor-pointer"
                      title="إزالة من المفضلة"
                    >
                      <Heart className="w-4 h-4 fill-current" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modals */}
      <FigureDetailModal
        figure={selectedFigure}
        chapters={chapters}
        isFavorite={selectedFigure ? isFavorited('figure', selectedFigure.id) : false}
        onClose={() => setSelectedFigure(null)}
        onToggleFavorite={() => {
          if (!selectedFigure) return;
          handleToggleFavorite({
            type: 'figure',
            targetId: selectedFigure.id,
            title: selectedFigure.name,
            subtitle: selectedFigure.titleOrKunya,
            periodTitle: selectedFigure.categoryLabel,
          });
        }}
        onOpenChapter={(chId) => {
          setSelectedFigure(null);
          handleOpenChapter(chId);
        }}
      />

      <PlaceDetailModal
        place={selectedPlace}
        chapters={chapters}
        isFavorite={selectedPlace ? isFavorited('place', selectedPlace.id) : false}
        onClose={() => setSelectedPlace(null)}
        onToggleFavorite={() => {
          if (!selectedPlace) return;
          handleToggleFavorite({
            type: 'place',
            targetId: selectedPlace.id,
            title: selectedPlace.name,
            subtitle: selectedPlace.regionLabel,
            periodTitle: selectedPlace.modernLocation,
          });
        }}
        onOpenChapter={(chId) => {
          setSelectedPlace(null);
          handleOpenChapter(chId);
        }}
      />

      <AdminChapterModal
        isOpen={showAdminModal}
        initialChapter={editingChapter}
        totalChaptersCount={chapters.length}
        onClose={() => {
          setShowAdminModal(false);
          setEditingChapter(null);
        }}
        onSaveChapter={handleAdminSaveChapter}
        onSyncAllToCloud={handleSeedCloud}
      />
    </div>
  );
};
