import React, { useState } from 'react';
import { Search, BookOpen, Copy, Check, ZoomIn, ZoomOut, Share2, Info } from 'lucide-react';
import { AUTHENTIC_FIQH_TOPICS, FiqhTopic } from './fiqhData';

export const FiqhView: React.FC = () => {
  const [selectedTopicId, setSelectedTopicId] = useState<string>(AUTHENTIC_FIQH_TOPICS[0].id);
  const [searchQuery, setSearchQuery] = useState('');
  const [fontSizeOffset, setFontSizeOffset] = useState(0); // -2 to +4
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredTopics = AUTHENTIC_FIQH_TOPICS.filter(t =>
    t.title.includes(searchQuery) ||
    t.summary.includes(searchQuery) ||
    t.details.some(d => d.includes(searchQuery))
  );

  const activeTopic = AUTHENTIC_FIQH_TOPICS.find(t => t.id === selectedTopicId) || AUTHENTIC_FIQH_TOPICS[0];

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = (t: FiqhTopic) => {
    if (navigator.share) {
      navigator.share({
        title: t.title,
        text: `${t.title}\n\n${t.dalil}\n\nالمصدر: ${t.source}\n(تطبيق رِفْق | RIFQ)`
      }).catch(() => {});
    } else {
      handleCopy(`${t.title}\n\n${t.dalil}\n\nالمصدر: ${t.source}`, t.id);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-2xl shadow-xs">
            🌙
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">فقه المرأة المسلمة</h3>
            <p className="text-xs text-[#77798C]">أحكام شرعية موثقة من صحيح البخاري ومسلم وفتاوى كبار العلماء</p>
          </div>
        </div>

        {/* أزرار التحكم بحجم الخط */}
        <div className="flex items-center gap-1 bg-stone-50 border border-[#E6E6F0] rounded-xl p-1">
          <button
            type="button"
            onClick={() => setFontSizeOffset(prev => Math.min(prev + 1, 4))}
            className="p-1.5 hover:bg-stone-200 rounded-lg text-[#77798C] transition-colors cursor-pointer"
            title="تكبير الخط"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setFontSizeOffset(prev => Math.max(prev - 1, -2))}
            className="p-1.5 hover:bg-stone-200 rounded-lg text-[#77798C] transition-colors cursor-pointer"
            title="تصغير الخط"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* حقل البحث */}
      <div className="relative">
        <Search className="w-4 h-4 text-stone-400 absolute right-3.5 top-3" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="ابحثي في أحكام الطهارة، الصلاة، الصيام، الزينة، الحجاب..."
          className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#E6E6F0] rounded-xl text-xs focus:border-[#5B5FEF] outline-hidden shadow-2xs"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* قائمة المواضيع الشرعية المعتمدة */}
        <div className="space-y-2 lg:col-span-1">
          {filteredTopics.map(topic => {
            const isSelected = topic.id === activeTopic.id;
            return (
              <button
                key={topic.id}
                type="button"
                onClick={() => setSelectedTopicId(topic.id)}
                className={`w-full text-right p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 ${
                  isSelected
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                    : 'bg-white text-[#25263A] border-[#E6E6F0] hover:border-[#E6E6F0]'
                }`}
              >
                <span className="text-xl shrink-0">{topic.icon}</span>
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold truncate font-tajawal">{topic.title}</h4>
                  <p className={`text-[11px] truncate mt-0.5 ${isSelected ? 'text-amber-100' : 'text-[#77798C]'}`}>
                    {topic.summary}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* عرض تفاصيل الموضوع المحدد */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border border-[#E6E6F0] shadow-xs space-y-5">
          <div className="flex items-start justify-between gap-3 pb-4 border-b border-[#E6E6F0]">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{activeTopic.icon}</span>
              <div>
                <h3 className="text-base sm:text-lg font-black text-[#25263A] font-tajawal">
                  {activeTopic.title}
                </h3>
                <span className="text-[11px] text-[#5B5FEF] font-bold">
                  المصدر: {activeTopic.source}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => handleCopy(`${activeTopic.title}\n\n${activeTopic.details.join('\n')}`, activeTopic.id)}
                className="p-2 rounded-xl border border-[#E6E6F0] hover:bg-stone-50 text-[#77798C] transition-colors cursor-pointer"
                title="نسخ الفتوى"
              >
                {copiedId === activeTopic.id ? <Check className="w-4 h-4 text-[#4CAF82]" /> : <Copy className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={() => handleShare(activeTopic)}
                className="p-2 rounded-xl border border-[#E6E6F0] hover:bg-stone-50 text-[#77798C] transition-colors cursor-pointer"
                title="مشاركة"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* الدليل الشرعي */}
          <div className="p-4 bg-[#F7F7FC]/70 rounded-2xl border border-[#E6E6F0] text-center space-y-1">
            <span className="text-[11px] font-bold text-[#5B5FEF]">الدليل من الكتاب والسنة</span>
            <p
              className="font-amiri font-bold text-[#25263A] leading-relaxed"
              style={{ fontSize: `${16 + fontSizeOffset}px` }}
            >
              {activeTopic.dalil}
            </p>
          </div>

          {/* تفاصيل الأحكام */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-[#25263A]">بيان الأحكام والضوابط:</h4>
            <div className="space-y-2.5">
              {activeTopic.details.map((detail, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-stone-50/70 border border-[#E6E6F0] flex items-start gap-3"
                >
                  <span className="w-5 h-5 rounded-full bg-[#5B5FEF] text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p
                    className="text-[#25263A] leading-relaxed"
                    style={{ fontSize: `${13 + fontSizeOffset}px` }}
                  >
                    {detail}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
