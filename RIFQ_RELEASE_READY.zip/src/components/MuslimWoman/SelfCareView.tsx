import React, { useState } from 'react';
import { Plus, Check, Droplet, Moon, Activity, Sparkles, Trash2 } from 'lucide-react';
import { DailyHabitRecord } from './womanTypes';

interface SelfCareViewProps {
  selfCare: Record<string, DailyHabitRecord>;
  customHabits: string[];
  onUpdateTodayRecord: (record: DailyHabitRecord) => void;
  onAddCustomHabit: (name: string) => void;
  onDeleteCustomHabit: (name: string) => void;
}

export const SelfCareView: React.FC<SelfCareViewProps> = ({
  selfCare,
  customHabits,
  onUpdateTodayRecord,
  onAddCustomHabit,
  onDeleteCustomHabit,
}) => {
  const [newHabitName, setNewHabitName] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayRecord: DailyHabitRecord = selfCare[todayStr] || {
    waterCups: 0,
    sleepHours: 0,
    activityMinutes: 0,
    completedHabits: []
  };

  const handleUpdateWater = (delta: number) => {
    const nextCups = Math.max(0, Math.min(20, todayRecord.waterCups + delta));
    onUpdateTodayRecord({ ...todayRecord, waterCups: nextCups });
  };

  const handleUpdateSleep = (hours: number) => {
    onUpdateTodayRecord({ ...todayRecord, sleepHours: hours });
  };

  const handleUpdateActivity = (mins: number) => {
    onUpdateTodayRecord({ ...todayRecord, activityMinutes: mins });
  };

  const handleToggleHabit = (hName: string) => {
    const isCompleted = todayRecord.completedHabits.includes(hName);
    const updated = isCompleted
      ? todayRecord.completedHabits.filter(h => h !== hName)
      : [...todayRecord.completedHabits, hName];
    onUpdateTodayRecord({ ...todayRecord, completedHabits: updated });
  };

  const handleAddNewHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;
    onAddCustomHabit(newHabitName.trim());
    setNewHabitName('');
    setShowAddModal(false);
  };

  // بيانات الأيام السابقة الحقيقية للرسم البياني (آخر 7 أيام مسجلة فعلاً)
  const recordedDays = Object.keys(selfCare).sort().slice(-7);
  const hasAnyRecord = recordedDays.length > 0;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#4CAF82]/12 border border-[#4CAF82]/40 flex items-center justify-center text-2xl shadow-xs">
            🌿
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">العناية والروتين اليومي</h3>
            <p className="text-xs text-[#77798C]">متابعة شرب الماء، النوم، الحركة، وأورادكِ اليومية</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 text-xs bg-[#5B5FEF] text-white px-3.5 py-2 rounded-xl font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>إضافة عادة خاصة</span>
        </button>
      </div>

      {/* لوحات المتابعة اليومية */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        {/* 💧 شرب الماء */}
        <div className="bg-white rounded-2xl p-5 border border-sky-200/60 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
              <Droplet className="w-4 h-4 text-sky-500" />
              <span>💧 شرب الماء اليوم</span>
            </span>
            <span className="text-xs font-bold text-sky-600 bg-sky-50 px-2 py-0.5 rounded-full">
              {todayRecord.waterCups * 250} مل
            </span>
          </div>

          <div className="text-center py-2">
            <div className="text-3xl font-black text-sky-700 font-tajawal">
              {todayRecord.waterCups} <span className="text-sm font-normal text-[#77798C]">أكواب</span>
            </div>
            <p className="text-[11px] text-stone-400 mt-1">الهدف المقترح: 8 أكواب (2 لتر)</p>
          </div>

          <div className="flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => handleUpdateWater(-1)}
              className="w-10 h-10 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-lg font-bold flex items-center justify-center cursor-pointer transition-colors"
            >
              -
            </button>
            <button
              type="button"
              onClick={() => handleUpdateWater(1)}
              className="flex-1 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              + شربت كوباً (250 مل)
            </button>
          </div>
        </div>

        {/* 😴 ساعات النوم */}
        <div className="bg-white rounded-2xl p-5 border border-purple-200/60 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
              <Moon className="w-4 h-4 text-purple-500" />
              <span>😴 نوم الليلة الماضية</span>
            </span>
            <span className="text-xs font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
              {todayRecord.sleepHours} ساعات
            </span>
          </div>

          <div className="text-center py-2">
            <div className="text-3xl font-black text-purple-700 font-tajawal">
              {todayRecord.sleepHours} <span className="text-sm font-normal text-[#77798C]">ساعة</span>
            </div>
            <p className="text-[11px] text-stone-400 mt-1">المعدل الصحي: 7-8 ساعات</p>
          </div>

          <input
            type="range"
            min="0"
            max="14"
            step="0.5"
            value={todayRecord.sleepHours}
            onChange={e => handleUpdateSleep(parseFloat(e.target.value))}
            className="w-full accent-purple-600"
          />
        </div>

        {/* 🚶 النشاط والحركة */}
        <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0]/60 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-amber-500" />
              <span>🚶 النشاط والحركة</span>
            </span>
            <span className="text-xs font-bold text-[#4145C7] bg-[#EEEEFF] px-2 py-0.5 rounded-full">
              {todayRecord.activityMinutes} دقيقة
            </span>
          </div>

          <div className="text-center py-2">
            <div className="text-3xl font-black text-[#4145C7] font-tajawal">
              {todayRecord.activityMinutes} <span className="text-sm font-normal text-[#77798C]">د</span>
            </div>
            <p className="text-[11px] text-stone-400 mt-1">مشي أو تمارين تمدد خفيفة</p>
          </div>

          <div className="flex gap-1.5 justify-center">
            {[15, 30, 45, 60].map(mins => (
              <button
                key={mins}
                type="button"
                onClick={() => handleUpdateActivity(mins)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                  todayRecord.activityMinutes === mins
                    ? 'bg-amber-500 text-white border-amber-500'
                    : 'bg-stone-50 text-[#77798C] border-[#E6E6F0] hover:bg-stone-100'
                }`}
              >
                {mins}د
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* قائمة العادات والأوراد اليومية */}
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-bold text-[#25263A] flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
            <span>عادات وأوراد اليوم ({todayRecord.completedHabits.length} من {customHabits.length})</span>
          </h4>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {customHabits.map(habit => {
            const isDone = todayRecord.completedHabits.includes(habit);
            return (
              <div
                key={habit}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                  isDone
                    ? 'border-[#4CAF82]/40 bg-[#4CAF82]/12/50'
                    : 'border-[#E6E6F0] bg-stone-50/30'
                }`}
              >
                <div
                  onClick={() => handleToggleHabit(habit)}
                  className="flex items-center gap-2.5 flex-1 cursor-pointer select-none"
                >
                  <div className={`w-5 h-5 rounded-md flex items-center justify-center transition-colors ${
                    isDone ? 'bg-emerald-500 text-white' : 'border border-stone-300 bg-white'
                  }`}>
                    {isDone && <Check className="w-3.5 h-3.5" />}
                  </div>
                  <span className={`text-xs font-bold ${isDone ? 'text-[#4CAF82] line-through' : 'text-[#25263A]'}`}>
                    {habit}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => onDeleteCustomHabit(habit)}
                  className="text-stone-300 hover:text-rose-500 p-1 cursor-pointer transition-colors"
                  title="حذف هذه العادة"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* رسم بياني حقيقي للأيام السابقة المسجلة فعلياً */}
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-3">
        <h4 className="text-sm font-bold text-[#25263A]">سجل نشاطكِ المسجل للأيام السابقة</h4>
        {!hasAnyRecord ? (
          <p className="text-xs text-[#77798C] text-center py-4">
            لا توجد بيانات مسجلة بعد. عند إدخال أكواب الماء أو العادات اليومية سيظهر سجلكِ الحقيقي هنا.
          </p>
        ) : (
          <div className="space-y-2">
            {recordedDays.map(dateKey => {
              const rec = selfCare[dateKey];
              const habitsCount = rec.completedHabits?.length || 0;
              return (
                <div key={dateKey} className="p-2.5 rounded-xl bg-stone-50 border border-[#E6E6F0] flex items-center justify-between text-xs">
                  <span className="font-bold text-[#25263A]">{dateKey}</span>
                  <div className="flex items-center gap-4 text-[11px] text-[#77798C]">
                    <span>💧 {rec.waterCups || 0} أكواب</span>
                    <span>😴 {rec.sleepHours || 0} ساعات</span>
                    <span>🌸 {habitsCount} عادات</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* نافذة إضافة عادة */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-[#E6E6F0] shadow-xl space-y-4">
            <h4 className="text-base font-bold text-[#25263A]">إضافة عادة أو وِرد يومي</h4>
            <form onSubmit={handleAddNewHabit} className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-700 font-bold mb-1">اسم العادة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: الاستغفار 100 مرة، قراءة 10 صفحات..."
                  value={newHabitName}
                  onChange={e => setNewHabitName(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#5B5FEF] text-white py-2 rounded-xl font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
                >
                  إضافة
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-2 border border-stone-300 rounded-xl text-[#77798C] font-bold hover:bg-stone-50 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
