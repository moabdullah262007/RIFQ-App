import React, { useState } from 'react';
import { ChevronRight, ChevronLeft, Calendar as CalendarIcon, Info } from 'lucide-react';
import { WomanProfileState } from './womanTypes';

interface WomanCalendarViewProps {
  state: WomanProfileState;
}

export const WomanCalendarView: React.FC<WomanCalendarViewProps> = ({ state }) => {
  const [currentDate, setCurrentDate] = useState(() => new Date());
  const [selectedDayStr, setSelectedDayStr] = useState<string>(() => new Date().toISOString().slice(0, 10));

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // حساب الأيام في الشهر
  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const totalDays = lastDayOfMonth.getDate();
  const startDayOfWeek = firstDayOfMonth.getDay(); // 0 = Sunday, 6 = Saturday

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  // فحص الفعاليات المسجلة لكل يوم
  const getDayEvents = (dateStr: string) => {
    const events: { type: 'cycle' | 'cycle_expected' | 'reminder' | 'diary' | 'pregnancy'; label: string; color: string }[] = [];

    // 1. فحص الحيض المسجل
    for (const c of state.cycles) {
      if (dateStr >= c.startDate && dateStr <= c.endDate) {
        events.push({ type: 'cycle', label: 'حيض مسجل', color: '#D95C6A' });
        break;
      }
    }

    // 2. فحص الحمل ومواعيده
    if (state.pregnancy.hasActivePregnancy && state.pregnancy.lmpDate) {
      const appts = state.pregnancy.appointments.filter(a => a.date === dateStr);
      for (const a of appts) {
        events.push({ type: 'pregnancy', label: `موعد حمل: ${a.title}`, color: '#E99AC7' });
      }
    }

    // 3. فحص التذكيرات
    const dayReminders = state.reminders.filter(r => r.date === dateStr || r.frequency === 'daily');
    for (const r of dayReminders) {
      events.push({ type: 'reminder', label: `تذكير: ${r.title}`, color: '#72B7E8' });
    }

    // 4. فحص المذكرات
    const dayDiary = state.diary.filter(d => d.createdAt.startsWith(dateStr));
    for (const d of dayDiary) {
      events.push({ type: 'diary', label: `خاطرة: ${d.title}`, color: '#E99AC7' });
    }

    return events;
  };

  const selectedDayEvents = getDayEvents(selectedDayStr);

  const monthNames = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  const weekDayNames = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-2xl shadow-xs">
            📅
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">تقويم المرأة الموحد</h3>
            <p className="text-xs text-[#77798C]">تقويم خاص يعرض فقط ما قمتِ بتسجيله فعلياً</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={prevMonth}
            className="p-2 rounded-xl border border-[#E6E6F0] hover:border-[#5B5FEF] text-[#77798C] cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <span className="text-sm font-bold text-[#25263A] min-w-28 text-center font-tajawal">
            {monthNames[month]} {year}
          </span>
          <button
            type="button"
            onClick={nextMonth}
            className="p-2 rounded-xl border border-[#E6E6F0] hover:border-[#5B5FEF] text-[#77798C] cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* دليل ألوان التقويم */}
      <div className="bg-white rounded-2xl p-4 border border-[#E6E6F0] shadow-xs flex flex-wrap items-center gap-4 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-[#D95C6A]" />
          <span>حيض مسجل</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-[#5B5FEF]" />
          <span>موعد فحص حمل</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-[#72B7E8]" />
          <span>تذكير شخصي</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-full bg-[#E99AC7]" />
          <span>خاطرة في المذكرات</span>
        </div>
      </div>

      {/* شبكة التقويم */}
      <div className="bg-white rounded-3xl p-5 border border-[#E6E6F0] shadow-xs space-y-3">
        {/* أسماء أيام الأسبوع */}
        <div className="grid grid-cols-7 gap-1 text-center font-bold text-xs text-[#25263A] pb-2 border-b border-[#E6E6F0]">
          {weekDayNames.map(day => (
            <div key={day} className="py-1">
              {day}
            </div>
          ))}
        </div>

        {/* خانات الأيام */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {/* فراغات الأيام الأولى للشهر */}
          {Array.from({ length: startDayOfWeek }).map((_, idx) => (
            <div key={`empty-${idx}`} className="h-14 rounded-xl bg-stone-50/30" />
          ))}

          {/* أيام الشهر الحقيقي */}
          {Array.from({ length: totalDays }).map((_, idx) => {
            const dayNum = idx + 1;
            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
            const events = getDayEvents(dateStr);
            const isSelected = selectedDayStr === dateStr;
            const isToday = new Date().toISOString().slice(0, 10) === dateStr;

            return (
              <div
                key={dateStr}
                onClick={() => setSelectedDayStr(dateStr)}
                className={`h-14 sm:h-16 p-1 rounded-xl border flex flex-col justify-between transition-all cursor-pointer ${
                  isSelected
                    ? 'border-[#5B5FEF] bg-[#EEEEFF]/50 shadow-xs'
                    : isToday
                    ? 'border-stone-400 bg-stone-50 font-bold'
                    : 'border-[#E6E6F0] bg-white hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className={`${isToday ? 'text-[#5B5FEF] font-black' : 'text-stone-700'}`}>
                    {dayNum}
                  </span>
                  {isToday && (
                    <span className="text-[9px] bg-[#5B5FEF] text-white px-1 rounded">اليوم</span>
                  )}
                </div>

                {/* نقاط الأحداث المسجلة فعلاً */}
                <div className="flex flex-wrap gap-1 justify-center">
                  {events.map((ev, eIdx) => (
                    <span
                      key={eIdx}
                      className="w-2 h-2 rounded-full shadow-2xs"
                      style={{ backgroundColor: ev.color }}
                      title={ev.label}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* تفاصيل اليوم المحدد */}
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-3">
        <h4 className="text-sm font-bold text-[#25263A] flex items-center justify-between">
          <span>سجلات يوم {selectedDayStr}:</span>
          <span className="text-xs text-[#77798C]">{selectedDayEvents.length} سجلات مسجلة</span>
        </h4>

        {selectedDayEvents.length === 0 ? (
          <p className="text-xs text-[#77798C] text-center py-4 border border-dashed border-[#E6E6F0] rounded-xl">
            لا توجد أي بيانات مسجلة في هذا اليوم. التقويم يظهر بياناتكِ الحقيقية فقط بدون أي عناصر وهمية.
          </p>
        ) : (
          <div className="space-y-2">
            {selectedDayEvents.map((ev, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl border border-[#E6E6F0] bg-stone-50/50 flex items-center gap-3 text-xs"
              >
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: ev.color }} />
                <span className="font-bold text-[#25263A]">{ev.label}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
