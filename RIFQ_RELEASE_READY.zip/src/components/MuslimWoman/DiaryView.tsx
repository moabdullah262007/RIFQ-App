import React, { useState } from 'react';
import { Plus, Trash2, Search, Lock, Unlock, KeyRound, Heart, Sparkles } from 'lucide-react';
import { DiaryEntry } from './womanTypes';

interface DiaryViewProps {
  entries: DiaryEntry[];
  pinCode: string | null;
  isPinEnabled: boolean;
  onAddEntry: (entry: Omit<DiaryEntry, 'id' | 'createdAt'>) => void;
  onDeleteEntry: (id: string) => void;
  onUpdateSecurity: (pin: string | null, enabled: boolean) => void;
}

const MOODS = [
  { id: 'peaceful', label: 'سكينة وطمأنينة', icon: '🕊️' },
  { id: 'happy', label: 'فرح وامتنان', icon: '🌸' },
  { id: 'grateful', label: 'شكر لله', icon: '🤲' },
  { id: 'pensive', label: 'تأمل وتفكير', icon: '💭' },
  { id: 'tired', label: 'إرهاق وحاجة للراحة', icon: '☕' }
] as const;

export const DiaryView: React.FC<DiaryViewProps> = ({
  entries,
  pinCode,
  isPinEnabled,
  onAddEntry,
  onDeleteEntry,
  onUpdateSecurity,
}) => {
  const [isUnlocked, setIsUnlocked] = useState(!isPinEnabled || !pinCode);
  const [enteredPin, setEnteredPin] = useState('');
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedMood, setSelectedMood] = useState<DiaryEntry['mood']>('peaceful');
  const [searchQuery, setSearchQuery] = useState('');

  // فحص فتح القفل
  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredPin === pinCode) {
      setIsUnlocked(true);
      setEnteredPin('');
    } else {
      alert('رمز المرور غير صحيح');
    }
  };

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.trim().length === 4) {
      onUpdateSecurity(newPin.trim(), true);
      setShowSecurityModal(false);
      setIsUnlocked(true);
      alert('تم تفعيل رمز القفل بنجاح (4 أرقام)');
    } else if (newPin.trim().length === 0) {
      onUpdateSecurity(null, false);
      setShowSecurityModal(false);
      setIsUnlocked(true);
      alert('تم إلغاء قفل المذكرات');
    } else {
      alert('يرجى إدخال 4 أرقام أو ترك الحقل فارغاً لإلغاء القفل');
    }
  };

  const handleSaveEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    onAddEntry({
      title: title.trim(),
      content: content.trim(),
      mood: selectedMood
    });

    setTitle('');
    setContent('');
    setSelectedMood('peaceful');
    setShowAddModal(false);
  };

  // شاشة القفل إن كان مفعّلاً ولم تفتحه
  if (isPinEnabled && pinCode && !isUnlocked) {
    return (
      <div className="bg-white rounded-3xl p-8 border border-[#E6E6F0] shadow-xs max-w-sm mx-auto text-center space-y-4 animate-fade-in my-8">
        <div className="w-16 h-16 mx-auto rounded-full bg-pink-50 flex items-center justify-center text-3xl">
          🔒
        </div>
        <div>
          <h4 className="text-base font-bold text-[#25263A]">مذكراتكِ محمية برمز سري</h4>
          <p className="text-xs text-[#77798C] mt-1">أدخلي رمز المرور المكون من 4 أرقام للوصول إلى خواطرك</p>
        </div>

        <form onSubmit={handleUnlock} className="space-y-3">
          <input
            type="password"
            maxLength={4}
            autoFocus
            required
            value={enteredPin}
            onChange={e => setEnteredPin(e.target.value)}
            placeholder="••••"
            className="w-32 mx-auto text-center tracking-widest text-2xl p-2 border-2 border-[#E6E6F0] rounded-xl focus:border-[#5B5FEF] outline-hidden"
          />
          <button
            type="submit"
            className="w-full bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold text-sm hover:bg-[#4145C7] transition-colors cursor-pointer"
          >
            فتح المذكرات 🔓
          </button>
        </form>
      </div>
    );
  }

  const filteredEntries = entries.filter(e =>
    e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-pink-50 border border-pink-200 flex items-center justify-center text-2xl shadow-xs">
            💗
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">مذكراتي الخاصة</h3>
            <p className="text-xs text-[#77798C]">مساحة خاصة وآمنة لكتابة مشاعرك، خواطرك، ووقفاتك اليومية</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowSecurityModal(true)}
            className="p-2.5 rounded-xl border border-[#E6E6F0] hover:border-[#5B5FEF] text-[#77798C] hover:text-[#5B5FEF] transition-colors cursor-pointer"
            title="إعدادات القفل السري"
          >
            {isPinEnabled ? <Lock className="w-4 h-4 text-[#5B5FEF]" /> : <Unlock className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-4 py-2.5 rounded-xl font-bold text-sm shadow-xs transition-transform active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>خاطرة جديدة</span>
          </button>
        </div>
      </div>

      {entries.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 border border-dashed border-[#E6E6F0] text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 mx-auto rounded-full bg-pink-50 flex items-center justify-center text-3xl">
            💗
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h4 className="text-base font-bold text-[#25263A]">لا توجد مذكرات أو خواطر مسجلة</h4>
            <p className="text-xs text-[#77798C] leading-relaxed">
              هنا مساحتكِ الآمنة الخالصة، لا تخرج من هاتفكِ أبداً. دوّني مشاعركِ، أفكاركِ، دعوات استجابها الله لكِ، أو وقفات شكر يومية.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-[#4145C7] transition-all cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>+ كتابة أول خاطرة</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {/* حقل البحث */}
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute right-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="ابحثي في مذكراتكِ..."
              className="w-full pr-10 pl-4 py-2.5 bg-white border border-[#E6E6F0] rounded-xl text-xs focus:border-[#5B5FEF] outline-hidden shadow-2xs"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredEntries.map(entry => {
              const moodObj = MOODS.find(m => m.id === entry.mood);
              const dateStr = new Date(entry.createdAt).toLocaleDateString('ar-EG', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              });

              return (
                <div
                  key={entry.id}
                  className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-3 relative group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{moodObj?.icon || '🌸'}</span>
                      <h4 className="text-sm font-bold text-[#25263A]">{entry.title}</h4>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteEntry(entry.id)}
                      className="p-1.5 text-stone-400 hover:text-rose-500 rounded-lg transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-stone-700 leading-relaxed whitespace-pre-wrap">
                    {entry.content}
                  </p>

                  <div className="pt-2 border-t border-[#E6E6F0] flex items-center justify-between text-[11px] text-[#77798C]">
                    <span>{dateStr}</span>
                    <span className="text-[#4145C7] font-bold">{moodObj?.label}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* نافذة إضافة خاطرة */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-[#E6E6F0] shadow-xl space-y-4">
            <h4 className="text-base font-bold text-[#25263A]">خاطرة جديدة في مذكراتي</h4>
            <form onSubmit={handleSaveEntry} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-stone-700 font-bold mb-1">عنوان الخاطرة</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: وقفة شكر، راحة بعد تعب..."
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden text-xs"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1.5">الحالة والشعور</label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                  {MOODS.map(m => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setSelectedMood(m.id)}
                      className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                        selectedMood === m.id
                          ? 'bg-pink-100 text-pink-900 border-pink-300 font-bold'
                          : 'bg-stone-50 border-[#E6E6F0] text-[#77798C]'
                      }`}
                    >
                      <div className="text-lg mb-0.5">{m.icon}</div>
                      <div className="text-[10px] leading-tight truncate">{m.label.slice(0, 10)}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">المحتوى</label>
                <textarea
                  required
                  rows={4}
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  placeholder="اكتبي ما يجول في خاطركِ بكل حرية..."
                  className="w-full p-3 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden text-xs"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
                >
                  حفظ الخاطرة
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 border border-stone-300 rounded-xl text-[#77798C] font-bold hover:bg-stone-50 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* نافذة ضبط القفل السري */}
      {showSecurityModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-xs w-full border border-[#E6E6F0] shadow-xl space-y-4 text-center">
            <KeyRound className="w-8 h-8 text-[#5B5FEF] mx-auto" />
            <h4 className="text-base font-bold text-[#25263A]">حماية المذكرات برمز سري</h4>
            <p className="text-xs text-[#77798C]">
              أدخلي 4 أرقام لتعيين رمز جديد، أو اتركي الحقل فارغاً لإلغاء القفل الحالي.
            </p>

            <form onSubmit={handleSaveSecurity} className="space-y-3">
              <input
                type="password"
                maxLength={4}
                value={newPin}
                onChange={e => setNewPin(e.target.value)}
                placeholder="4 أرقام"
                className="w-32 mx-auto text-center tracking-widest text-xl p-2 border-2 border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
              />

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#5B5FEF] text-white py-2 rounded-xl text-xs font-bold hover:bg-[#4145C7] cursor-pointer"
                >
                  حفظ الإعداد
                </button>
                <button
                  type="button"
                  onClick={() => setShowSecurityModal(false)}
                  className="px-3 py-2 border border-stone-300 rounded-xl text-xs text-[#77798C] font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
