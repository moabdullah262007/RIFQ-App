// أنواع ونماذج قسم «رِفْق للمرأة» - بدون أي بيانات وهمية
export interface CycleRecord {
  id: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  symptoms: string[];
  notes?: string;
  flowIntensity?: 'light' | 'medium' | 'heavy';
}

export interface PregnancyData {
  hasActivePregnancy: boolean;
  lmpDate: string; // YYYY-MM-DD
  notes: string;
  appointments: PregnancyAppointment[];
}

export interface PregnancyAppointment {
  id: string;
  title: string;
  date: string;
  doctorName?: string;
  notes?: string;
  completed: boolean;
}

export interface FeedingRecord {
  id: string;
  timestamp: string; // ISO
  side: 'left' | 'right' | 'both' | 'bottle';
  durationMinutes: number;
  notes?: string;
}

export interface ChildRecord {
  id: string;
  name: string;
  birthDate: string; // YYYY-MM-DD
  gender: 'male' | 'female';
  notes?: string;
}

export interface WomanReminder {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  frequency: 'once' | 'daily' | 'weekly' | 'monthly';
  category: 'health' | 'worship' | 'baby' | 'personal';
  isActive: boolean;
  notes?: string;
}

export interface DiaryEntry {
  id: string;
  title: string;
  content: string;
  createdAt: string; // ISO
  mood: 'peaceful' | 'happy' | 'tired' | 'grateful' | 'pensive';
}

export interface DailyHabitRecord {
  waterCups: number; // 250ml per cup
  sleepHours: number;
  activityMinutes: number;
  completedHabits: string[]; // names of habits done
}

export interface WomanProfileState {
  cycles: CycleRecord[];
  pregnancy: PregnancyData;
  feedings: FeedingRecord[];
  children: ChildRecord[];
  reminders: WomanReminder[];
  diary: DiaryEntry[];
  selfCare: Record<string, DailyHabitRecord>; // date -> record
  customHabits: string[];
  pinCode: string | null;
  isPinEnabled: boolean;
}

export const DEFAULT_HABITS = [
  'ورد القرآن الكريم',
  'أذكار الصباح',
  'أذكار المساء',
  'قيام الليل / الوتر',
  'قراءة نافعة',
  'رياضة خفيفة'
];

export const INITIAL_WOMAN_STATE: WomanProfileState = {
  cycles: [],
  pregnancy: {
    hasActivePregnancy: false,
    lmpDate: '',
    notes: '',
    appointments: []
  },
  feedings: [],
  children: [],
  reminders: [],
  diary: [],
  selfCare: {},
  customHabits: DEFAULT_HABITS,
  pinCode: null,
  isPinEnabled: false
};

const STORAGE_KEY = 'rifq_woman_space_data_v1';

export function loadWomanState(): WomanProfileState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return INITIAL_WOMAN_STATE;
    const parsed = JSON.parse(raw);
    return {
      ...INITIAL_WOMAN_STATE,
      ...parsed,
      pregnancy: {
        ...INITIAL_WOMAN_STATE.pregnancy,
        ...(parsed.pregnancy || {})
      },
      cycles: Array.isArray(parsed.cycles) ? parsed.cycles : [],
      feedings: Array.isArray(parsed.feedings) ? parsed.feedings : [],
      children: Array.isArray(parsed.children) ? parsed.children : [],
      reminders: Array.isArray(parsed.reminders) ? parsed.reminders : [],
      diary: Array.isArray(parsed.diary) ? parsed.diary : [],
      selfCare: parsed.selfCare || {},
      customHabits: Array.isArray(parsed.customHabits) && parsed.customHabits.length > 0 
        ? parsed.customHabits 
        : DEFAULT_HABITS
    };
  } catch {
    return INITIAL_WOMAN_STATE;
  }
}

export function saveWomanState(state: WomanProfileState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Error saving woman state', err);
  }
}

export function wipeAllWomanData(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.error('Error wiping woman data', err);
  }
}
