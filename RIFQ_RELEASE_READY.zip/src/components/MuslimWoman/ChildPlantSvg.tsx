import React from 'react';

/**
 * أيقونات SVG حقيقية 100% لميزة «نبتة طفلي» (بدون أي إيموجي)
 * تتضمن النبتة التفاعلية التي تتدرج من: بذرة -> برعم -> نبتة صغيرة -> نبتة مورقة -> شجرة صغيرة
 */

export const SproutHeaderSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 24,
  className = '',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    className={className}
    aria-hidden="true"
  >
    <path
      d="M12 22V11"
      stroke="#4CAF82"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M12 13C8.5 13 5 10.5 5 6.5C9 6.5 12 9 12 13Z"
      fill="#4CAF82"
      fillOpacity="0.2"
      stroke="#4CAF82"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    <path
      d="M12 11C15.5 11 19 8.5 19 4.5C15 4.5 12 7 12 11Z"
      fill="#E99AC7"
      fillOpacity="0.25"
      stroke="#4CAF82"
      strokeWidth="2"
      strokeLinejoin="round"
    />
    <path d="M8 22H16" stroke="#5B5FEF" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const RulerSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect
      x="3"
      y="6"
      width="18"
      height="12"
      rx="2.5"
      stroke="#5B5FEF"
      strokeWidth="2"
      fill="#FDF2F8"
      fillOpacity="0.4"
    />
    <path
      d="M7 6V10M11 6V12M15 6V10M19 6V12"
      stroke="#25263A"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
  </svg>
);

export const WeightScaleSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect
      x="3"
      y="3"
      width="18"
      height="18"
      rx="4"
      stroke="#4CAF82"
      strokeWidth="2"
      fill="#F7F7FC"
    />
    <path
      d="M8 10C9.5 7.5 14.5 7.5 16 10"
      stroke="#5B5FEF"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path d="M12 11L14 8" stroke="#25263A" strokeWidth="2" strokeLinecap="round" />
    <circle cx="12" cy="11" r="1.5" fill="#E99AC7" />
  </svg>
);

export const HeadCircumferenceSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <circle
      cx="12"
      cy="12"
      r="7.5"
      stroke="#E99AC7"
      strokeWidth="2"
      fill="#FDF2F8"
      fillOpacity="0.45"
    />
    <ellipse
      cx="12"
      cy="10.5"
      rx="8.5"
      ry="3"
      stroke="#5B5FEF"
      strokeWidth="1.8"
      strokeDasharray="3 2"
    />
    <circle cx="9.5" cy="12.5" r="1" fill="#25263A" />
    <circle cx="14.5" cy="12.5" r="1" fill="#25263A" />
  </svg>
);

export const CalendarApptSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect
      x="3"
      y="5"
      width="18"
      height="16"
      rx="3"
      stroke="#5B5FEF"
      strokeWidth="2"
      fill="#FFFFFF"
    />
    <path d="M3 10H21" stroke="#E99AC7" strokeWidth="2" />
    <path d="M8 3V7M16 3V7" stroke="#4CAF82" strokeWidth="2" strokeLinecap="round" />
    <circle cx="12" cy="15" r="2" fill="#4CAF82" />
  </svg>
);

export const NoteBookSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect
      x="5"
      y="3"
      width="14"
      height="18"
      rx="2.5"
      stroke="#5B5FEF"
      strokeWidth="2"
      fill="#FDF2F8"
      fillOpacity="0.35"
    />
    <path
      d="M9 8H15M9 12H15M9 16H13"
      stroke="#25263A"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
  </svg>
);

export const ActivityLogSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <path
      d="M4 19V5M4 19H20"
      stroke="#5B5FEF"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M7 14L11 10L15 13L19 7"
      stroke="#4CAF82"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="19" cy="7" r="2" fill="#E99AC7" />
  </svg>
);

export const BirthdayGiftSvg: React.FC<{ size?: number; className?: string }> = ({
  size = 20,
  className = '',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className}>
    <rect
      x="4"
      y="10"
      width="16"
      height="10"
      rx="2"
      stroke="#5B5FEF"
      strokeWidth="2"
      fill="#FDF2F8"
    />
    <path d="M12 10V20M4 14H20" stroke="#5B5FEF" strokeWidth="1.8" />
    <path
      d="M12 10C12 10 9 6.5 7.5 8C6 9.5 8.5 10 12 10ZM12 10C12 10 15 6.5 16.5 8C18 9.5 15.5 10 12 10Z"
      stroke="#4CAF82"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
  </svg>
);

/**
 * النبتة التفاعلية SVG (تتغير حسب المرحلة 0..4 والحجم التدريجي المستمر visualScale)
 */
export const InteractiveChildPlantSvg: React.FC<{
  stageIndex: 0 | 1 | 2 | 3 | 4;
  visualScale: number;
  animateOnMount?: boolean;
}> = ({ stageIndex, visualScale, animateOnMount = true }) => {
  const clampedScale = Math.max(0.75, Math.min(1.45, visualScale));

  return (
    <div
      className={`relative flex items-center justify-center transition-transform duration-700 ease-out ${
        animateOnMount ? 'animate-fade-in' : ''
      }`}
      style={{ transform: `scale(${clampedScale})` }}
    >
      <svg
        width="190"
        height="190"
        viewBox="0 0 200 200"
        fill="none"
        role="img"
        aria-label="النبتة التفاعلية لعمر الطفل"
      >
        <defs>
          <radialGradient id="plantAura" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#E99AC7" stopOpacity="0.22" />
            <stop offset="70%" stopColor="#E99AC7" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="potGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E99AC7" />
            <stop offset="100%" stopColor="#E99AC7" />
          </linearGradient>
          <linearGradient id="leafGreenGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#4CAF82" />
            <stop offset="100%" stopColor="#4CAF82" />
          </linearGradient>
          <linearGradient id="goldLeafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E8B84A" />
            <stop offset="100%" stopColor="#E99AC7" />
          </linearGradient>
        </defs>

        {/* هالة خلفية ناعمة */}
        <circle cx="100" cy="105" r="82" fill="url(#plantAura)" />

        {/* تربة وأصيص ذهبي وردي أنيق */}
        <path
          d="M66 150H134L126 182C125 185 122 187 119 187H81C78 187 75 185 74 182L66 150Z"
          fill="url(#potGrad)"
          stroke="#5B5FEF"
          strokeWidth="2"
        />
        <rect
          x="60"
          y="142"
          width="80"
          height="10"
          rx="5"
          fill="#FFFFFF"
          stroke="#5B5FEF"
          strokeWidth="2"
        />
        <ellipse cx="100" cy="143" rx="34" ry="5" fill="#25263A" fillOpacity="0.75" />

        {/* المرحلة 0: بذرة وبرعم أولي (0 - 6 أشهر) */}
        {stageIndex === 0 && (
          <g>
            <ellipse
              cx="100"
              cy="138"
              rx="10"
              ry="7"
              fill="url(#goldLeafGrad)"
              stroke="#4CAF82"
              strokeWidth="2"
            />
            <path
              d="M100 138V110"
              stroke="#4CAF82"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <path
              d="M100 118C86 118 76 108 76 96C88 96 100 106 100 118Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 112C114 112 124 102 124 90C112 90 100 100 100 112Z"
              fill="url(#leafGreenGrad)"
            />
            <circle cx="100" cy="84" r="4" fill="#E99AC7" />
          </g>
        )}

        {/* المرحلة 1: نبتة صغيرة (6 - 12 شهر) */}
        {stageIndex === 1 && (
          <g>
            <path
              d="M100 142V86"
              stroke="#4CAF82"
              strokeWidth="4.5"
              strokeLinecap="round"
            />
            <path
              d="M100 124C80 124 68 110 68 94C84 94 100 108 100 124Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 116C120 116 132 102 132 86C116 86 100 100 100 116Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 94C86 94 76 82 76 68C90 68 100 80 100 94Z"
              fill="url(#leafGreenGrad)"
            />
            <circle cx="100" cy="74" r="5.5" fill="url(#goldLeafGrad)" />
          </g>
        )}

        {/* المرحلة 2: نبتة أكثر نمواً (1 - 2 سنة) */}
        {stageIndex === 2 && (
          <g>
            <path
              d="M100 142V68"
              stroke="#4CAF82"
              strokeWidth="5"
              strokeLinecap="round"
            />
            <path
              d="M100 126C76 126 62 110 62 92C80 92 100 108 100 126Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 118C124 118 138 102 138 84C120 84 100 100 100 118Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 98C78 98 66 82 66 64C84 64 100 80 100 98Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 90C122 90 134 74 134 56C116 56 100 72 100 90Z"
              fill="url(#leafGreenGrad)"
            />
            <circle cx="100" cy="58" r="7" fill="url(#goldLeafGrad)" />
          </g>
        )}

        {/* المرحلة 3: نبتة كبيرة مورقة ومزهرة (2 - 4 سنوات) */}
        {stageIndex === 3 && (
          <g>
            <path
              d="M100 142V52"
              stroke="#4CAF82"
              strokeWidth="6"
              strokeLinecap="round"
            />
            <path
              d="M100 112L76 92M100 94L126 74"
              stroke="#4CAF82"
              strokeWidth="4"
              strokeLinecap="round"
            />
            <path
              d="M100 128C72 128 56 110 56 90C76 90 100 108 100 128Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 120C128 120 144 102 144 82C124 82 100 100 100 120Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 96C74 96 58 78 58 58C78 58 100 76 100 96Z"
              fill="url(#leafGreenGrad)"
            />
            <path
              d="M100 88C126 88 142 70 142 50C122 50 100 68 100 88Z"
              fill="url(#leafGreenGrad)"
            />
            <circle cx="100" cy="44" r="10" fill="#E99AC7" stroke="#5B5FEF" strokeWidth="2" />
            <circle cx="100" cy="44" r="4.5" fill="url(#goldLeafGrad)" />
          </g>
        )}

        {/* المرحلة 4: شجرة صغيرة راسخة ومثمرة (بعد 4 سنوات) */}
        {stageIndex === 4 && (
          <g>
            <path
              d="M95 142L97 78H103L105 142H95Z"
              fill="#25263A"
            />
            <path
              d="M100 96L76 76M100 88L124 68"
              stroke="#25263A"
              strokeWidth="4.5"
              strokeLinecap="round"
            />
            <circle cx="100" cy="58" r="34" fill="url(#leafGreenGrad)" />
            <circle cx="74" cy="72" r="24" fill="#4CAF82" />
            <circle cx="126" cy="72" r="24" fill="#4CAF82" />
            <circle cx="100" cy="42" r="22" fill="#4CAF82" />
            {/* ثمار ذهبية ووردية رمزية */}
            <circle cx="82" cy="64" r="5" fill="url(#goldLeafGrad)" />
            <circle cx="118" cy="62" r="5" fill="url(#goldLeafGrad)" />
            <circle cx="100" cy="44" r="5.5" fill="#E99AC7" stroke="#5B5FEF" strokeWidth="1.5" />
          </g>
        )}
      </svg>
    </div>
  );
};
