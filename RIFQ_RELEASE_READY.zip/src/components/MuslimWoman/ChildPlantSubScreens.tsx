import React, { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  ChildRow,
  MeasurementRow,
  AppointmentRow,
  NoteRow,
  ActivityRow,
  CalculatedChildAge,
  calculateChildAge,
  formatDateDMY,
} from '../../utils/childPlantSqlite';
import {
  SproutHeaderSvg,
  RulerSvg,
  WeightScaleSvg,
  HeadCircumferenceSvg,
  CalendarApptSvg,
  NoteBookSvg,
  ActivityLogSvg,
  BirthdayGiftSvg,
} from './ChildPlantSvg';

const GROWTH_TIMELINE_STAGES = [
  {
    index: 0,
    range: 'من الولادة - 6 أشهر',
    title: 'البداية: بذرة وبرعم أولي',
    desc: 'مرحلة التواصل البصري والسمعي مع الأم، الابتسامة الاجتماعية، والانتباه للأصوات والألوان المحيطة (مرجع تعليمي عام: WHO / CDC).',
  },
  {
    index: 1,
    range: 'من 6 - 12 شهراً',
    title: 'مرحلة لاحقة: نبتة صغيرة',
    desc: 'مرحلة الجلوس المتوازن، الإمساك بالأشياء ونقلها بين اليدين، بدء الحبو، والمناغاة بمقاطع صوتية متكررة (WHO / CDC).',
  },
  {
    index: 2,
    range: 'من 1 - 2 سنة',
    title: 'نمو متزايد: نبتة أكثر نمواً',
    desc: 'مرحلة الخطوات المستقلة، نطق الكلمات الأولى المفهومة، الإشارة للأشياء المالوفة، والتفاعل مع أفراد الأسرة (WHO / CDC).',
  },
  {
    index: 3,
    range: 'من 2 - 4 سنوات',
    title: 'مرحلة أكبر: نبتة كبيرة مورقة',
    desc: 'مرحلة تكوين الجمل القصيرة، اللعب التخيلي والحركي النشط، وتنمية المهارات الاجتماعية وحب الاستكشاف (WHO / CDC).',
  },
  {
    index: 4,
    range: 'بعد 4 سنوات',
    title: 'مرحلة متقدمة: شجرة صغيرة',
    desc: 'مرحلة الاعتماد التدريجي في المهارات اليومية، سرد القصص، طرح الأسئلة، وبناء الصداقات والتعلم التعاوني (WHO / CDC).',
  },
];

/* ══════════════════════════════════════════════════════════════════════════
   الشاشة 3: قياسات النمو + الشاشة 4: الرسوم البيانية (3 Line Charts)
   ══════════════════════════════════════════════════════════════════════════ */
export const ChildMeasurementsAndChartsScreen: React.FC<{
  mode: 'measurements' | 'charts';
  onSwitchMode: (m: 'measurements' | 'charts') => void;
  measurements: MeasurementRow[];
  isDark: boolean;
  onSaveMeasurement: (
    data: {
      id?: string;
      date: string;
      height: number | null;
      weight: number | null;
      head_circumference: number | null;
      notes: string;
    }
  ) => void;
  onDeleteMeasurement: (id: string) => void;
}> = ({ mode, onSwitchMode, measurements, isDark, onSaveMeasurement, onDeleteMeasurement }) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [dateVal, setDateVal] = useState(() => new Date().toISOString().slice(0, 10));
  const [heightVal, setHeightVal] = useState('');
  const [weightVal, setWeightVal] = useState('');
  const [headVal, setHeadVal] = useState('');
  const [notesVal, setNotesVal] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const cardClass = isDark
    ? 'bg-[#1E1E1E] border border-[#E99AC7]/40 text-white rounded-[20px] shadow-sm'
    : 'bg-[#FFFFFF] border border-[#E99AC7] text-[#25263A] rounded-[20px] shadow-xs';

  const openAddDialog = () => {
    setEditId(null);
    setDateVal(new Date().toISOString().slice(0, 10));
    setHeightVal('');
    setWeightVal('');
    setHeadVal('');
    setNotesVal('');
    setFormError(null);
    setDialogOpen(true);
  };

  const openEditDialog = (m: MeasurementRow) => {
    setEditId(m.id);
    setDateVal(m.date);
    setHeightVal(m.height !== null ? String(m.height) : '');
    setWeightVal(m.weight !== null ? String(m.weight) : '');
    setHeadVal(m.head_circumference !== null ? String(m.head_circumference) : '');
    setNotesVal(m.notes || '');
    setFormError(null);
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const todayStr = new Date().toISOString().slice(0, 10);
    if (!dateVal || dateVal > todayStr) {
      setFormError('تاريخ القياس لا يمكن أن يكون في المستقبل.');
      return;
    }

    const h = heightVal.trim() ? Number(heightVal) : null;
    const w = weightVal.trim() ? Number(weightVal) : null;
    const hc = headVal.trim() ? Number(headVal) : null;

    if (h === null && w === null && hc === null) {
      setFormError('يرجى إدخال قيمة واحدة على الأقل (الطول أو الوزن أو محيط الرأس).');
      return;
    }
    if ((h !== null && h <= 0) || (w !== null && w <= 0) || (hc !== null && hc <= 0)) {
      setFormError('جميع الأرقام المدخلة يجب أن تكون موجبة وأكبر من الصفر.');
      return;
    }

    onSaveMeasurement({
      id: editId || undefined,
      date: dateVal,
      height: h,
      weight: w,
      head_circumference: hc,
      notes: notesVal.trim(),
    });
    setDialogOpen(false);
  };

  // ترتيب القياسات زمنياً للرسوم البيانية
  const sortedChronological = [...measurements].sort((a, b) => a.date.localeCompare(b.date));
  const heightChartData = sortedChronological
    .filter((m) => m.height !== null && m.height > 0)
    .map((m) => ({ date: formatDateDMY(m.date), value: m.height }));
  const weightChartData = sortedChronological
    .filter((m) => m.weight !== null && m.weight > 0)
    .map((m) => ({ date: formatDateDMY(m.date), value: m.weight }));
  const headChartData = sortedChronological
    .filter((m) => m.head_circumference !== null && m.head_circumference > 0)
    .map((m) => ({ date: formatDateDMY(m.date), value: m.head_circumference }));

  return (
    <div className="space-y-4">
      {/* التبديل السريع بين قائمة القياسات والرسوم البيانية + زر إضافة */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onSwitchMode('measurements')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              mode === 'measurements'
                ? 'bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white shadow-xs'
                : 'bg-[#FDF2F8] text-[#25263A] border border-[#E6E6F0]'
            }`}
          >
            قائمة قياسات النمو
          </button>
          <button
            type="button"
            onClick={() => onSwitchMode('charts')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              mode === 'charts'
                ? 'bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white shadow-xs'
                : 'bg-[#FDF2F8] text-[#25263A] border border-[#E6E6F0]'
            }`}
          >
            الرسوم البيانية (3 مخططات)
          </button>
        </div>

        <button
          type="button"
          onClick={openAddDialog}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold shadow-xs cursor-pointer"
        >
          + إضافة قياس
        </button>
      </div>

      {/* حالة فارغة عند عدم وجود أي قياسات */}
      {measurements.length === 0 ? (
        <div className={`${cardClass} p-8 text-center space-y-4`}>
          <div className="w-16 h-16 mx-auto rounded-full bg-[#FDF2F8] border border-[#E99AC7] flex items-center justify-center">
            <SproutHeaderSvg size={32} />
          </div>
          <p className="font-bold text-sm">لم تتم إضافة أي قياسات بعد</p>
          <button
            type="button"
            onClick={openAddDialog}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold shadow-xs cursor-pointer"
          >
            إضافة أول قياس
          </button>
        </div>
      ) : mode === 'measurements' ? (
        /* قائمة القياسات */
        <div className="space-y-3">
          {measurements.map((m) => (
            <div key={m.id} className={`${cardClass} p-4 space-y-3`}>
              <div className="flex items-center justify-between border-b border-[#E99AC7]/30 pb-2">
                <span className="text-xs font-bold text-[#5B5FEF]">
                  التاريخ: {formatDateDMY(m.date)}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => openEditDialog(m)}
                    className="px-3 py-1 rounded-lg bg-[#FDF2F8] text-[#25263A] border border-[#E6E6F0] text-xs font-bold cursor-pointer"
                  >
                    تعديل
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteMeasurement(m.id)}
                    className="px-3 py-1 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                  >
                    حذف
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2.5 text-xs">
                <div className="p-2.5 rounded-xl bg-[#F7F7FC] text-[#25263A] flex items-center gap-2">
                  <RulerSvg size={18} />
                  <div>
                    <div className="text-[11px] text-[#77798C]">الطول</div>
                    <div className="font-bold">{m.height !== null ? `${m.height} سم` : '—'}</div>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F7F7FC] text-[#25263A] flex items-center gap-2">
                  <WeightScaleSvg size={18} />
                  <div>
                    <div className="text-[11px] text-[#77798C]">الوزن</div>
                    <div className="font-bold">{m.weight !== null ? `${m.weight} كجم` : '—'}</div>
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-[#F7F7FC] text-[#25263A] flex items-center gap-2">
                  <HeadCircumferenceSvg size={18} />
                  <div>
                    <div className="text-[11px] text-[#77798C]">محيط الرأس</div>
                    <div className="font-bold">
                      {m.head_circumference !== null ? `${m.head_circumference} سم` : '—'}
                    </div>
                  </div>
                </div>
              </div>

              {m.notes && (
                <p className="text-xs text-[#77798C] bg-[#FDF2F8]/30 p-2.5 rounded-xl">
                  ملاحظة: {m.notes}
                </p>
              )}
            </div>
          ))}
        </div>
      ) : (
        /* الشاشة 4: 3 رسوم بيانية حقيقية (الطول، الوزن، محيط الرأس) */
        <div className="space-y-4">
          {[
            {
              title: '1. الطول مع مرور الوقت (سم)',
              icon: <RulerSvg size={20} />,
              data: heightChartData,
              color: '#4CAF82',
              unit: 'سم',
            },
            {
              title: '2. الوزن مع مرور الوقت (كجم)',
              icon: <WeightScaleSvg size={20} />,
              data: weightChartData,
              color: '#E99AC7',
              unit: 'كجم',
            },
            {
              title: '3. محيط الرأس مع مرور الوقت (سم)',
              icon: <HeadCircumferenceSvg size={20} />,
              data: headChartData,
              color: '#E99AC7',
              unit: 'سم',
            },
          ].map((chart, idx) => (
            <div key={idx} className={`${cardClass} p-4 space-y-3`}>
              <div className="flex items-center gap-2 border-b border-[#E99AC7]/30 pb-2">
                {chart.icon}
                <h4 className="font-bold text-sm">{chart.title}</h4>
              </div>
              {chart.data.length === 0 ? (
                <div className="py-6 text-center space-y-2">
                  <p className="text-xs text-[#77798C]">لم تتم إضافة قياسات لهذا المؤشر بعد</p>
                  <button
                    type="button"
                    onClick={openAddDialog}
                    className="px-4 py-1.5 rounded-xl bg-[#FDF2F8] text-[#25263A] border border-[#E6E6F0] text-xs font-bold cursor-pointer"
                  >
                    إضافة قياس
                  </button>
                </div>
              ) : (
                <div className="h-52 w-full" dir="ltr">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chart.data}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(201,168,76,0.2)" />
                      <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#77798C' }} />
                      <YAxis tick={{ fontSize: 11, fill: '#77798C' }} />
                      <Tooltip
                        formatter={(val: number) => [`${val} ${chart.unit}`, chart.title]}
                      />
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke={chart.color}
                        strokeWidth={3}
                        dot={{ r: 5, fill: chart.color }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* نافذة حوار إضافة / تعديل قياس */}
      {dialogOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmit}
            className={`${cardClass} max-w-md w-full p-5 space-y-3.5 animate-fade-in`}
          >
            <h4 className="font-bold text-base border-b border-[#E99AC7]/40 pb-2">
              {editId ? 'تعديل قياس النمو' : 'إضافة قياس نمو جديد'}
            </h4>

            {formError && (
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold">
                {formError}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold mb-1">التاريخ</label>
              <input
                type="date"
                max={new Date().toISOString().slice(0, 10)}
                value={dateVal}
                onChange={(e) => setDateVal(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-xs font-bold mb-1">الطول (سم)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={heightVal}
                  onChange={(e) => setHeightVal(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold mb-1">الوزن (كجم)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.1"
                  value={weightVal}
                  onChange={(e) => setWeightVal(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold mb-1">محيط الرأس (سم)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={headVal}
                  onChange={(e) => setHeadVal(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">ملاحظة (اختياري)</label>
              <input
                type="text"
                value={notesVal}
                onChange={(e) => setNotesVal(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDialogOpen(false)}
                className="px-4 py-2 rounded-xl bg-[#FDF2F8] text-[#25263A] border border-[#E6E6F0] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
              >
                حفظ القياس
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

/* ══════════════════════════════════════════════════════════════════════════
   الشاشة 5: مراحل النمو (Timeline) — مرجع تعليمي WHO / CDC بدون تشخيص طبي
   ══════════════════════════════════════════════════════════════════════════ */
export const ChildStagesTimelineScreen: React.FC<{
  ageInfo: CalculatedChildAge;
  isDark: boolean;
}> = ({ ageInfo, isDark }) => {
  const cardClass = isDark
    ? 'bg-[#1E1E1E] border border-[#E99AC7]/40 text-white rounded-[20px] shadow-sm'
    : 'bg-[#FFFFFF] border border-[#E99AC7] text-[#25263A] rounded-[20px] shadow-xs';

  return (
    <div className="space-y-4">
      <div className={`${cardClass} p-4 space-y-2`}>
        <div className="text-xs font-bold text-[#4CAF82]">
          العمر الحالي: {ageInfo.formattedArabic} • المرحلة الحالية: {ageInfo.stageTitle}
        </div>
        <p className="text-xs text-[#77798C] leading-relaxed">{ageInfo.stageDescription}</p>
        <div className="p-2.5 rounded-xl bg-[#FDF2F8]/50 border border-[#E99AC7] text-[11px] font-bold text-[#25263A]">
          تنبيه: النبتة والمراحل العمرية تمثيل بصري وتعليمي عام (استناداً إلى منظمة الصحة العالمية WHO و CDC) وليست مقياساً أو تشخيصاً طبياً.
        </div>
      </div>

      <div className="space-y-3">
        {GROWTH_TIMELINE_STAGES.map((st) => {
          const isCurrent = st.index === ageInfo.stageIndex;
          const isReached = st.index <= ageInfo.stageIndex;
          return (
            <div
              key={st.index}
              className={`${cardClass} p-4 border-r-4 ${
                isCurrent
                  ? 'border-r-[#4CAF82] ring-1 ring-[#5B5FEF]'
                  : isReached
                  ? 'border-r-[#E99AC7]'
                  : 'opacity-75'
              }`}
            >
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm">{st.title}</h4>
                <span className="text-xs font-bold text-[#5B5FEF]">{st.range}</span>
              </div>
              <p className="text-xs text-[#77798C] mt-1.5 leading-relaxed">{st.desc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ══════════════════════════════════════════════════════════════════════════
   الشاشة 6: المواعيد (مع جدولة إشعار حقيقي)
   ══════════════════════════════════════════════════════════════════════════ */
export const ChildAppointmentsScreen: React.FC<{
  appointments: AppointmentRow[];
  isDark: boolean;
  onSaveAppointment: (data: {
    id?: string;
    title: string;
    date: string;
    time: string;
    doctor_name: string;
    notes: string;
    reminder_enabled: boolean;
  }) => void;
  onDeleteAppointment: (id: string) => void;
  onToggleReminder: (id: string) => void;
}> = ({
  appointments,
  isDark,
  onSaveAppointment,
  onDeleteAppointment,
  onToggleReminder,
}) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [time, setTime] = useState('10:00');
  const [doctor, setDoctor] = useState('');
  const [notes, setNotes] = useState('');
  const [reminderEnabled, setReminderEnabled] = useState(true);

  const cardClass = isDark
    ? 'bg-[#1E1E1E] border border-[#E99AC7]/40 text-white rounded-[20px] shadow-sm'
    : 'bg-[#FFFFFF] border border-[#E99AC7] text-[#25263A] rounded-[20px] shadow-xs';

  const openNew = () => {
    setEditId(null);
    setTitle('');
    setDate(new Date().toISOString().slice(0, 10));
    setTime('10:00');
    setDoctor('');
    setNotes('');
    setReminderEnabled(true);
    setDialogOpen(true);
  };

  const openEdit = (a: AppointmentRow) => {
    setEditId(a.id);
    setTitle(a.title);
    setDate(a.date);
    setTime(a.time);
    setDoctor(a.doctor_name);
    setNotes(a.notes);
    setReminderEnabled(a.reminder_enabled === 1);
    setDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !date || !time) return;
    onSaveAppointment({
      id: editId || undefined,
      title: title.trim(),
      date,
      time,
      doctor_name: doctor.trim(),
      notes: notes.trim(),
      reminder_enabled: reminderEnabled,
    });
    setDialogOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-sm">مواعيدي القادمة والمسجلة</h3>
        <button
          type="button"
          onClick={openNew}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
        >
          + إضافة موعد
        </button>
      </div>

      {appointments.length === 0 ? (
        <div className={`${cardClass} p-8 text-center space-y-4`}>
          <div className="w-16 h-16 mx-auto rounded-full bg-[#FDF2F8] border border-[#E99AC7] flex items-center justify-center">
            <CalendarApptSvg size={28} />
          </div>
          <p className="font-bold text-sm">لا توجد مواعيد قادمة</p>
          <button
            type="button"
            onClick={openNew}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
          >
            إضافة موعد
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {appointments.map((a) => (
            <div key={a.id} className={`${cardClass} p-4 space-y-2.5`}>
              <div className="flex items-center justify-between">
                <div className="font-bold text-sm">{a.title}</div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onToggleReminder(a.id)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold cursor-pointer ${
                      a.reminder_enabled
                        ? 'bg-[#5B5FEF] text-white'
                        : 'bg-[#F7F7FC] text-[#77798C]'
                    }`}
                  >
                    {a.reminder_enabled ? 'تنبيه مفعّل' : 'تنبيه معطل'}
                  </button>
                  <button
                    type="button"
                    onClick={() => openEdit(a)}
                    className="px-2.5 py-1 rounded-lg bg-[#FDF2F8] text-[#25263A] text-xs font-bold cursor-pointer"
                  >
                    تعديل
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteAppointment(a.id)}
                    className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 text-xs font-bold cursor-pointer"
                  >
                    حذف
                  </button>
                </div>
              </div>
              <div className="text-xs text-[#5B5FEF] font-bold">
                التاريخ: {formatDateDMY(a.date)} • الوقت: {a.time}
                {a.doctor_name ? ` • الطبيب: ${a.doctor_name}` : ''}
              </div>
              {a.notes && <p className="text-xs text-[#77798C]">{a.notes}</p>}
            </div>
          ))}
        </div>
      )}

      {dialogOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <form onSubmit={handleSubmit} className={`${cardClass} max-w-md w-full p-5 space-y-3`}>
            <h4 className="font-bold text-base border-b border-[#E99AC7]/40 pb-2">
              {editId ? 'تعديل الموعد' : 'إضافة موعد جديد'}
            </h4>
            <div>
              <label className="block text-xs font-bold mb-1">اسم الموعد</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold mb-1">التاريخ</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-bold mb-1">الوقت</label>
                <input
                  type="time"
                  required
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">اسم الطبيب (اختياري)</label>
              <input
                type="text"
                value={doctor}
                onChange={(e) => setDoctor(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold mb-1">ملاحظة (اختياري)</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs"
              />
            </div>
            <label className="flex items-center justify-between p-2.5 rounded-xl bg-[#FDF2F8]/40 border border-[#E99AC7] cursor-pointer">
              <span className="text-xs font-bold text-[#25263A]">
                تفعيل إشعار حقيقي في الموعد (يحترم الخصوصية)
              </span>
              <input
                type="checkbox"
                checked={reminderEnabled}
                onChange={(e) => setReminderEnabled(e.target.checked)}
                className="accent-[#4CAF82] w-4 h-4"
              />
            </label>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDialogOpen(false)}
                className="px-4 py-2 rounded-xl bg-[#FDF2F8] text-[#25263A] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
              >
                حفظ الموعد
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

/* ══════════════════════════════════════════════════════════════════════════
   الشاشة 7: سجل الطفل + الشاشة 8: ملاحظاتي + الشاشة 9: أطفالي (متعدد)
   ══════════════════════════════════════════════════════════════════════════ */
export const ChildActivitiesNotesAndChildrenScreen: React.FC<{
  subView: 'activities' | 'notes' | 'children';
  activities: ActivityRow[];
  notes: NoteRow[];
  childrenList: ChildRow[];
  selectedChildId: string | null;
  isDark: boolean;
  onSaveNote: (data: { id?: string; title: string; content: string; date: string }) => void;
  onDeleteNote: (id: string) => void;
  onSelectChild: (id: string) => void;
  onOpenAddChild: () => void;
  onDeleteAllChildData: (id: string) => void;
}> = ({
  subView,
  activities,
  notes,
  childrenList,
  selectedChildId,
  isDark,
  onSaveNote,
  onDeleteNote,
  onSelectChild,
  onOpenAddChild,
  onDeleteAllChildData,
}) => {
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteDate, setNoteDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [confirmDeleteChildId, setConfirmDeleteChildId] = useState<string | null>(null);

  const cardClass = isDark
    ? 'bg-[#1E1E1E] border border-[#E99AC7]/40 text-white rounded-[20px] shadow-sm'
    : 'bg-[#FFFFFF] border border-[#E99AC7] text-[#25263A] rounded-[20px] shadow-xs';

  if (subView === 'activities') {
    return (
      <div className="space-y-3">
        {activities.length === 0 ? (
          <div className={`${cardClass} p-8 text-center space-y-3`}>
            <div className="w-14 h-14 mx-auto rounded-full bg-[#FDF2F8] flex items-center justify-center">
              <ActivityLogSvg size={26} />
            </div>
            <p className="font-bold text-sm">لا توجد أحداث بعد</p>
          </div>
        ) : (
          activities.map((act) => (
            <div key={act.id} className={`${cardClass} p-4 flex items-center justify-between gap-3`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FDF2F8] flex items-center justify-center shrink-0">
                  {act.type === 'measurement' && <RulerSvg size={20} />}
                  {act.type === 'appointment' && <CalendarApptSvg size={20} />}
                  {act.type === 'note' && <NoteBookSvg size={20} />}
                  {act.type === 'birthday' && <BirthdayGiftSvg size={20} />}
                </div>
                <div>
                  <h4 className="font-bold text-sm">{act.title}</h4>
                  <p className="text-xs text-[#77798C]">{act.subtitle}</p>
                </div>
              </div>
              <span className="text-xs font-bold text-[#5B5FEF] shrink-0">
                {formatDateDMY(act.date)}
              </span>
            </div>
          ))
        )}
      </div>
    );
  }

  if (subView === 'notes') {
    return (
      <div className="space-y-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!noteTitle.trim() || !noteContent.trim()) return;
            onSaveNote({
              id: editingNoteId || undefined,
              title: noteTitle.trim(),
              content: noteContent.trim(),
              date: noteDate,
            });
            setNoteTitle('');
            setNoteContent('');
            setEditingNoteId(null);
          }}
          className={`${cardClass} p-4 space-y-3`}
        >
          <h4 className="font-bold text-sm">
            {editingNoteId ? 'تعديل الملاحظة' : 'إضافة ملاحظة جديدة'}
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input
              type="text"
              placeholder="عنوان الملاحظة"
              value={noteTitle}
              onChange={(e) => setNoteTitle(e.target.value)}
              className="px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
            />
            <input
              type="date"
              value={noteDate}
              onChange={(e) => setNoteDate(e.target.value)}
              className="px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs font-bold"
            />
          </div>
          <textarea
            rows={2}
            placeholder="نص الملاحظة..."
            value={noteContent}
            onChange={(e) => setNoteContent(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] text-xs"
          />
          <div className="flex justify-end gap-2">
            {editingNoteId && (
              <button
                type="button"
                onClick={() => {
                  setEditingNoteId(null);
                  setNoteTitle('');
                  setNoteContent('');
                }}
                className="px-3 py-1.5 rounded-xl bg-[#FDF2F8] text-[#25263A] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            )}
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
            >
              حفظ
            </button>
          </div>
        </form>

        {notes.length === 0 ? (
          <div className={`${cardClass} p-8 text-center space-y-2`}>
            <p className="font-bold text-sm">ابدئي بإضافة أول ملاحظة</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notes.map((n) => (
              <div key={n.id} className={`${cardClass} p-4 space-y-2`}>
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm">{n.title}</h4>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#5B5FEF] font-bold">
                      {formatDateDMY(n.created_at.slice(0, 10))}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setEditingNoteId(n.id);
                        setNoteTitle(n.title);
                        setNoteContent(n.content);
                        setNoteDate(n.created_at.slice(0, 10));
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#FDF2F8] text-[#25263A] text-xs font-bold cursor-pointer"
                    >
                      تعديل
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteNote(n.id)}
                      className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 text-xs font-bold cursor-pointer"
                    >
                      حذف
                    </button>
                  </div>
                </div>
                <p className="text-xs text-[#77798C] leading-relaxed">{n.content}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // الشاشة 9: أطفالي (متعدد) + حذف كل بيانات طفل مع تأكيد
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold text-sm">قائمة أطفالي المسجلين</h3>
        <button
          type="button"
          onClick={onOpenAddChild}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
        >
          + إضافة طفل
        </button>
      </div>

      <div className="space-y-3">
        {childrenList.map((child) => {
          const age = calculateChildAge(child.birth_date);
          const isSelected = child.id === selectedChildId;
          return (
            <div
              key={child.id}
              className={`${cardClass} p-4 flex items-center justify-between gap-3 ${
                isSelected ? 'ring-2 ring-[#5B5FEF]' : ''
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#FDF2F8] border border-[#5B5FEF] overflow-hidden flex items-center justify-center shrink-0">
                  {child.photo_path ? (
                    <img
                      src={child.photo_path}
                      alt={child.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <SproutHeaderSvg size={24} />
                  )}
                </div>
                <div>
                  <h4 className="font-bold text-sm">{child.name || 'طفلي'}</h4>
                  <p className="text-xs text-[#77798C]">العمر: {age.formattedArabic}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onSelectChild(child.id)}
                  className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#E99AC7] to-[#E8B84A] text-white text-xs font-bold cursor-pointer"
                >
                  فتح
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeleteChildId(child.id)}
                  className="px-3 py-1.5 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 text-xs font-bold cursor-pointer"
                >
                  حذف كل بيانات الطفل
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {confirmDeleteChildId && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className={`${cardClass} max-w-sm w-full p-5 text-center space-y-4`}>
            <h4 className="font-bold text-base text-rose-700">تأكيد حذف بيانات الطفل</h4>
            <p className="text-xs text-[#77798C] leading-relaxed">
              هل أنتِ متأكدة من حذف كل بيانات هذا الطفل (القياسات، المواعيد، الملاحظات، والسجل) نهائياً من قاعدة البيانات المحلية؟
            </p>
            <div className="flex justify-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onDeleteAllChildData(confirmDeleteChildId);
                  setConfirmDeleteChildId(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold cursor-pointer"
              >
                نعم، حذف نهائي
              </button>
              <button
                type="button"
                onClick={() => setConfirmDeleteChildId(null)}
                className="px-4 py-2 rounded-xl bg-[#FDF2F8] text-[#25263A] text-xs font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
