import React, { useState } from 'react';
import { Plus, Trash2, Clock, Milk, Baby } from 'lucide-react';
import { FeedingRecord } from './womanTypes';

interface BreastfeedingViewProps {
  feedings: FeedingRecord[];
  onAddFeeding: (feeding: Omit<FeedingRecord, 'id'>) => void;
  onDeleteFeeding: (id: string) => void;
}

export const BreastfeedingView: React.FC<BreastfeedingViewProps> = ({
  feedings,
  onAddFeeding,
  onDeleteFeeding,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [side, setSide] = useState<'left' | 'right' | 'both' | 'bottle'>('right');
  const [duration, setDuration] = useState<number>(15);
  const [time, setTime] = useState<string>(() => {
    const d = new Date();
    return d.toTimeString().slice(0, 5);
  });
  const [notes, setNotes] = useState('');

  // إحصائيات اليوم من السجلات الحقيقية فقط
  const todayDateStr = new Date().toISOString().slice(0, 10);
  const todayFeedings = feedings.filter(f => f.timestamp.startsWith(todayDateStr));
  const todayTotalMinutes = todayFeedings.reduce((sum, f) => sum + f.durationMinutes, 0);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const d = new Date();
    const [hours, minutes] = time.split(':');
    d.setHours(parseInt(hours, 10), parseInt(minutes, 10), 0, 0);

    onAddFeeding({
      timestamp: d.toISOString(),
      side,
      durationMinutes: duration,
      notes: notes.trim() || undefined
    });

    setNotes('');
    setShowAddModal(false);
  };

  const getSideLabel = (s: FeedingRecord['side']) => {
    switch (s) {
      case 'left': return 'الثدي الأيسر ◀️';
      case 'right': return 'الثدي الأيمن ▶️';
      case 'both': return 'كلا الجانبين 🔄';
      case 'bottle': return 'زجاجة رضاعة 🍼';
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-orange-50 border border-orange-200 flex items-center justify-center text-2xl shadow-xs">
            🍼
          </div>
          <div>
            <h3 className="text-lg font-bold text-[#25263A] font-tajawal">متابعة الرضاعة الطبيعية</h3>
            <p className="text-xs text-[#77798C]">تسجيل جهة الرضاعة، التوقيت، والمدة بالدقائق</p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-4 py-2.5 rounded-xl font-bold text-sm shadow-xs transition-transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>سجلي رضعة جديدة</span>
        </button>
      </div>

      {feedings.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 border border-dashed border-[#E6E6F0] text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 mx-auto rounded-full bg-orange-50 flex items-center justify-center text-3xl">
            🍼
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h4 className="text-base font-bold text-[#25263A]">لم تسجلي أي رضعة بعد</h4>
            <p className="text-xs text-[#77798C] leading-relaxed">
              سجلي أوقات رضاعة طفلك، والجهة (الأيمن، الأيسر، أو الرضّاعة) لتنظيم جدول الرضاعة والتأكد من توازن التغذية.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-[#4145C7] transition-all cursor-pointer shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>🍼 سجلي أول رضعة</span>
          </button>
        </div>
      ) : (
        <>
          {/* بطاقات إحصائيات حقيقية لليوم */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            <div className="bg-gradient-to-br from-white to-orange-50/40 rounded-2xl p-4 border border-orange-200/50 shadow-xs">
              <span className="text-xs text-[#77798C]">رضعات اليوم</span>
              <div className="text-2xl font-black text-[#25263A] font-tajawal mt-1">
                {todayFeedings.length} <span className="text-xs font-normal text-[#77798C]">مرات</span>
              </div>
            </div>

            <div className="bg-gradient-to-br from-white to-amber-50/40 rounded-2xl p-4 border border-[#E6E6F0] shadow-xs">
              <span className="text-xs text-[#77798C]">إجمالي مدة اليوم</span>
              <div className="text-2xl font-black text-[#25263A] font-tajawal mt-1">
                {todayTotalMinutes} <span className="text-xs font-normal text-[#77798C]">دقيقة</span>
              </div>
            </div>

            <div className="col-span-2 sm:col-span-1 bg-gradient-to-br from-white to-stone-50 rounded-2xl p-4 border border-[#E6E6F0] shadow-xs">
              <span className="text-xs text-[#77798C]">آخر رضعة سُجلت</span>
              <div className="text-sm font-bold text-[#25263A] font-tajawal mt-1 truncate">
                {feedings[0] ? getSideLabel(feedings[0].side) : '—'}
              </div>
              <div className="text-[11px] text-[#77798C] mt-0.5">
                {feedings[0] ? new Date(feedings[0].timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : ''}
              </div>
            </div>
          </div>

          {/* سجل الرضعات */}
          <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-4">
            <h4 className="text-sm font-bold text-[#25263A]">سجل الرضعات ({feedings.length})</h4>
            <div className="space-y-2.5">
              {feedings.map(f => {
                const dateObj = new Date(f.timestamp);
                const isToday = f.timestamp.startsWith(todayDateStr);
                return (
                  <div
                    key={f.id}
                    className="p-3.5 rounded-xl border border-[#E6E6F0] bg-stone-50/40 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-orange-100 text-orange-800">
                          {getSideLabel(f.side)}
                        </span>
                        <span className="text-xs font-bold text-[#25263A]">
                          {f.durationMinutes} دقيقة
                        </span>
                        <span className="text-[11px] text-[#77798C]">
                          {isToday ? 'اليوم' : dateObj.toLocaleDateString('ar-EG')} - {dateObj.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      {f.notes && (
                        <p className="text-xs text-[#77798C] italic">ملاحظة: {f.notes}</p>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteFeeding(f.id)}
                      className="p-1.5 text-stone-400 hover:text-rose-500 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}

      {/* نافذة تسجيل رضعة */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-[#E6E6F0] shadow-xl space-y-4">
            <h4 className="text-base font-bold text-[#25263A]">تسجيل رضعة جديدة</h4>
            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-stone-700 font-bold mb-1.5">جهة الرضاعة</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'right', label: 'الأيمن ▶️' },
                    { id: 'left', label: 'الأيسر ◀️' },
                    { id: 'both', label: 'كلاهما 🔄' },
                    { id: 'bottle', label: 'زجاجة 🍼' },
                  ].map(item => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setSide(item.id as any)}
                      className={`p-2 rounded-xl text-center font-bold border transition-all cursor-pointer ${
                        side === item.id
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-stone-50 border-[#E6E6F0] text-stone-700'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">
                  المدة بالدقائق: <span className="text-[#5B5FEF] font-black text-sm">{duration} د</span>
                </label>
                <input
                  type="range"
                  min="3"
                  max="60"
                  step="1"
                  value={duration}
                  onChange={e => setDuration(parseInt(e.target.value, 10))}
                  className="w-full accent-[#E99AC7]"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">وقت البدء</label>
                <input
                  type="time"
                  required
                  value={time}
                  onChange={e => setTime(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div>
                <label className="block text-stone-700 font-bold mb-1">ملاحظات (اختياري)</label>
                <input
                  type="text"
                  placeholder="مثال: تجشأ سريعاً، هادئ..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full p-2.5 border border-stone-300 rounded-xl focus:border-[#5B5FEF] outline-hidden"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#5B5FEF] text-white py-2.5 rounded-xl font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
                >
                  حفظ الرضعة
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 border border-stone-300 rounded-xl text-[#77798C] font-bold hover:bg-stone-50 cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
