import React, { useState, useEffect } from 'react';
import { Clock, MapPin, Sparkles, Moon, Sun, Sunrise, Sunset, Bell } from 'lucide-react';
import { WidgetSize, WidgetTheme, PrayerKey, PrayerSettings } from '../../types';
import { WIDGET_THEMES } from '../../utils/widgetThemes';
import { 
  calculateAllPrayerData, 
  CalculatedPrayerData, 
  formatPrayerTime, 
  formatRemainingTime,
  getHijriDate 
} from '../../utils/prayerCalculator';
import { getCurrentCity, getPrayerSettings } from '../../utils/prayerScheduler';
import { WidgetTargetPrayer } from '../../utils/widgetService';

interface PrayerWidgetProps {
  size?: WidgetSize;
  theme?: WidgetTheme;
  targetPrayer?: WidgetTargetPrayer;
  onOpenApp?: () => void;
  className?: string;
}

const DEFAULT_SETTINGS: PrayerSettings = {
  method: 'Egyptian',
  madhab: 'shafi',
  timeFormat: '12h',
  hijriAdjustment: 0,
  notifications: { fajr: true, sunrise: false, dhuhr: true, asr: true, maghrib: true, isha: true },
  preAdhanReminderMinutes: 15,
  iqamaMinutes: { fajr: 20, sunrise: 0, dhuhr: 15, asr: 15, maghrib: 10, isha: 15 },
  selectedMuadhin: 'makkah',
  soundEnabled: true,
  manualOffsets: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  showSunnah: true,
  silentModeReminder: true,
};

const PRAYER_DETAILS: Record<PrayerKey, { nameAr: string; icon: React.ReactNode }> = {
  fajr: { nameAr: 'الفجر', icon: <Moon className="w-4 h-4 text-indigo-300" /> },
  sunrise: { nameAr: 'الشروق', icon: <Sunrise className="w-4 h-4 text-amber-400" /> },
  dhuhr: { nameAr: 'الظهر', icon: <Sun className="w-4 h-4 text-amber-300" /> },
  asr: { nameAr: 'العصر', icon: <Sun className="w-4 h-4 text-orange-400" /> },
  maghrib: { nameAr: 'المغرب', icon: <Sunset className="w-4 h-4 text-rose-400" /> },
  isha: { nameAr: 'العشاء', icon: <Moon className="w-4 h-4 text-purple-300" /> },
};

export const PrayerWidget: React.FC<PrayerWidgetProps> = ({
  size = 'medium',
  theme = 'navy',
  targetPrayer = 'next',
  onOpenApp,
  className = '',
}) => {
  const [prayerData, setPrayerData] = useState<CalculatedPrayerData | null>(null);
  const [cityName, setCityName] = useState<string>('مكة المكرمة');
  const [hijriDateText, setHijriDateText] = useState<string>('');
  const [remainingCountdown, setRemainingCountdown] = useState<string>('--:--:--');
  const [displayedPrayerKey, setDisplayedPrayerKey] = useState<PrayerKey>('fajr');
  const [displayedPrayerTime, setDisplayedPrayerTime] = useState<Date>(new Date());

  const styles = WIDGET_THEMES[theme];

  // Refresh prayer times & live countdown using real RIFQ city & prayer settings
  useEffect(() => {
    const updateTimes = () => {
      const city = getCurrentCity();
      const prayerSettings = getPrayerSettings() || DEFAULT_SETTINGS;
      setCityName(city.nameAr || 'القاهرة');

      const now = new Date();
      const calculated = calculateAllPrayerData(city.latitude, city.longitude, now, prayerSettings);
      setPrayerData(calculated);

      const hijri = getHijriDate(now, prayerSettings.hijriAdjustment);
      setHijriDateText(`${hijri.day} ${hijri.monthName}`);

      let activeKey: PrayerKey = calculated.nextPrayer;
      let activeTime: Date = calculated.nextPrayerTime;

      if (targetPrayer && targetPrayer !== 'next') {
        activeKey = targetPrayer as PrayerKey;
        const todayTarget = calculated.times[activeKey];
        if (todayTarget && todayTarget.getTime() > now.getTime()) {
          activeTime = todayTarget;
        } else {
          const tomorrow = new Date(now);
          tomorrow.setDate(tomorrow.getDate() + 1);
          const tomorrowCalc = calculateAllPrayerData(city.latitude, city.longitude, tomorrow, prayerSettings);
          activeTime = tomorrowCalc.times[activeKey] || todayTarget;
        }
      }

      setDisplayedPrayerKey(activeKey);
      setDisplayedPrayerTime(activeTime);

      const diff = activeTime.getTime() - now.getTime();
      const formatted = formatRemainingTime(diff);
      const padZero = (n: number) => n.toString().padStart(2, '0');
      setRemainingCountdown(`${padZero(formatted.hours)}:${padZero(formatted.minutes)}:${padZero(formatted.seconds)}`);
    };

    updateTimes();
    const interval = setInterval(updateTimes, 1000);
    window.addEventListener('storage', updateTimes);
    window.addEventListener('rifq-user-data-synced', updateTimes);
    window.addEventListener('rifq-local-data-mutated', updateTimes);
    return () => {
      clearInterval(interval);
      window.removeEventListener('storage', updateTimes);
      window.removeEventListener('rifq-user-data-synced', updateTimes);
      window.removeEventListener('rifq-local-data-mutated', updateTimes);
    };
  }, [targetPrayer]);

  if (!prayerData) {
    return (
      <div
        style={styles.containerStyle}
        className={`w-full aspect-square rounded-3xl p-5 flex items-center justify-center ${styles.container} ${styles.border} ${className}`}
      >
        <span className={`text-xs animate-pulse ${styles.primaryText}`}>جارِ حساب مواقيت الصلاة...</span>
      </div>
    );
  }

  const nextPrayerKey = displayedPrayerKey;
  const nextDetail = PRAYER_DETAILS[nextPrayerKey] || PRAYER_DETAILS.fajr;
  const nextTimeFormatted = formatPrayerTime(displayedPrayerTime, '12h');

  const mainPrayerKeys: PrayerKey[] = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

  // ════════════════ SMALL SIZE (2x2) ════════════════
  if (size === 'small') {
    return (
      <div
        onClick={onOpenApp}
        dir="rtl"
        style={styles.containerStyle}
        className={`relative aspect-square w-full rounded-3xl p-4 flex flex-col justify-between select-none overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.01] ${styles.container} ${styles.border} ${className}`}
      >
        {/* Subtle Background Crescent/Arch */}
        <div className="absolute -left-6 -bottom-6 w-28 h-28 rounded-full bg-white/5 pointer-events-none" />

        {/* Top bar: Next Prayer Badge & City */}
        <div className="flex items-center justify-between z-10">
          <div className={`px-2 py-0.5 rounded-full text-[10px] font-black flex items-center gap-1 ${styles.badge} ${styles.badgeText}`}>
            {nextDetail.icon}
            <span>الصلاة القادمة</span>
          </div>

          <div className={`flex items-center gap-1 text-[10px] font-black ${styles.accentText}`}>
            <MapPin className="w-2.5 h-2.5" />
            <span className="truncate max-w-[65px]">{cityName}</span>
          </div>
        </div>

        {/* Center: Big Prayer Name & Time */}
        <div className="flex flex-col items-center justify-center my-auto z-10 text-center space-y-1">
          <span className={`text-xs font-bold flex items-center gap-1 ${styles.accentText}`}>
            <span>صلاة</span>
            <span className="text-sm font-black">{nextDetail.nameAr}</span>
          </span>

          <div className={`text-2xl sm:text-3xl font-black font-tajawal tracking-tight ${styles.primaryText}`}>
            {nextTimeFormatted}
          </div>

          {/* Hijri Date badge */}
          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${styles.highlightBadge}`}>
            {hijriDateText} هـ
          </span>
        </div>

        {/* Bottom Ticking Countdown Bar */}
        <div className={`z-10 px-2.5 py-1.5 rounded-xl flex items-center justify-between ${styles.subCard}`}>
          <span className={`text-[9px] font-bold ${styles.secondaryText}`}>
            باقي للأذان:
          </span>
          <span className={`font-mono font-black text-xs tracking-wider ${styles.accentText}`}>
            {remainingCountdown}
          </span>
        </div>
      </div>
    );
  }

  // ════════════════ MEDIUM SIZE (4x2) ════════════════
  return (
    <div
      onClick={onOpenApp}
      dir="rtl"
      style={styles.containerStyle}
      className={`relative w-full rounded-3xl p-4 sm:p-5 flex flex-col justify-between select-none overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.01] ${styles.container} ${styles.border} ${className}`}
    >
      {/* Background Aura */}
      <div className="absolute -left-10 -bottom-10 w-44 h-44 rounded-full bg-white/5 pointer-events-none" />
      <div className="absolute right-10 -top-10 w-32 h-32 rounded-full bg-amber-400/5 pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between z-10 mb-2">
        <div className="flex items-center gap-2">
          <div className={`px-2.5 py-0.5 rounded-full text-[11px] font-black flex items-center gap-1.5 ${styles.badge} ${styles.badgeText}`}>
            <Clock className="w-3 h-3" />
            <span>مواقيت الصلاة والأذان</span>
          </div>

          <div className={`flex items-center gap-1 text-xs font-black ${styles.accentText}`}>
            <MapPin className="w-3 h-3" />
            <span>{cityName}</span>
          </div>
        </div>

        <div className={`flex items-center gap-1.5 text-xs font-black px-2.5 py-0.5 rounded-full ${styles.highlightBadge}`}>
          <Sparkles className="w-3.5 h-3.5" />
          <span>{hijriDateText} هـ</span>
        </div>
      </div>

      {/* Main Center Grid: Next Prayer Spotlight + Countdown */}
      <div className="grid grid-cols-12 gap-3 items-center z-10 my-auto">
        {/* Left Column: Next Prayer Highlight */}
        <div className="col-span-7 flex items-center gap-3">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-inner ${styles.highlightBadge}`}>
            {nextDetail.icon}
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className={`text-[10px] font-bold ${styles.secondaryText}`}>
                الصلاة القادمة:
              </span>
              <span className={`text-xs font-black ${styles.accentText}`}>
                صلاة {nextDetail.nameAr}
              </span>
            </div>

            <div className={`text-2xl sm:text-3xl font-black font-tajawal tracking-tight ${styles.primaryText}`}>
              {nextTimeFormatted}
            </div>
          </div>
        </div>

        {/* Right Column: Live Ticking Countdown */}
        <div className="col-span-5 flex flex-col items-end justify-center">
          <div className={`px-3 py-1.5 rounded-2xl text-right space-y-0.5 ${styles.subCard}`}>
            <span className={`text-[9px] font-bold block ${styles.secondaryText}`}>
              الوقت المتبقي للأذان:
            </span>
            <div className={`font-mono text-sm sm:text-base font-black tracking-wider ${styles.accentText}`}>
              {remainingCountdown}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom: 6 Prayers Timeline Ribbon */}
      <div className={`z-10 mt-2.5 pt-2 border-t ${styles.divider} grid grid-cols-6 gap-1 text-center`}>
        {mainPrayerKeys.map((k) => {
          const isNext = k === nextPrayerKey;
          const time = prayerData.times[k];
          const name = PRAYER_DETAILS[k].nameAr;
          const timeStr = formatPrayerTime(time, '12h');

          return (
            <div
              key={k}
              className={`p-1 sm:p-1.5 rounded-xl transition-all ${
                isNext
                  ? `${styles.activeChip} scale-105`
                  : styles.subCard
              }`}
            >
              <span className={`block text-[10px] ${isNext ? 'font-black' : styles.secondaryText}`}>
                {name}
              </span>
              <span className={`block text-[10px] font-mono ${isNext ? 'font-black' : styles.primaryText}`}>
                {timeStr.replace(/ [صم]/, '')}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
