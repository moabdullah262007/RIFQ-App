import React, { useState, useEffect } from 'react';
import { Sparkles, Dices, Copy, Check, Heart, Play } from 'lucide-react';
import { WidgetSize, WidgetTheme, DhikrItem } from '../../types';
import { WIDGET_THEMES } from '../../utils/widgetThemes';
import { EXPLORER_ATHKAR } from '../../data/athkarData';
import { saveSettings, loadSettings } from '../../utils/storage';
import { soundManager } from '../../utils/audio';

interface DhikrWidgetProps {
  size?: WidgetSize;
  theme?: WidgetTheme;
  customDhikr?: string;
  interactive?: boolean;
  onOpenApp?: () => void;
  onStartTasbeehWithDhikr?: (dhikrText: string) => void;
  className?: string;
}

export const DhikrWidget: React.FC<DhikrWidgetProps> = ({
  size = 'medium',
  theme = 'navy',
  customDhikr,
  interactive = true,
  onOpenApp,
  onStartTasbeehWithDhikr,
  className = '',
}) => {
  const [currentDhikrIndex, setCurrentDhikrIndex] = useState(0);
  const [manualOverride, setManualOverride] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);

  const styles = WIDGET_THEMES[theme];

  // Pick a daily stable dhikr or match customDhikr when changed
  useEffect(() => {
    setManualOverride(false);
    if (customDhikr && customDhikr.trim().length > 0) {
      const foundIdx = EXPLORER_ATHKAR.findIndex((item) => item.text.trim() === customDhikr.trim());
      if (foundIdx >= 0) {
        setCurrentDhikrIndex(foundIdx);
        return;
      }
    }
    const today = new Date().toDateString();
    let hash = 0;
    for (let i = 0; i < today.length; i++) {
      hash = (hash << 5) - hash + today.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % EXPLORER_ATHKAR.length;
    setCurrentDhikrIndex(idx);
  }, [customDhikr]);

  const matchedCustom: DhikrItem | null =
    !manualOverride && customDhikr && customDhikr.trim().length > 0
      ? EXPLORER_ATHKAR.find((item) => item.text.trim() === customDhikr.trim()) || {
          id: 'custom-widget-dhikr',
          text: customDhikr.trim(),
          category: 'sunnah' as const,
          countTarget: 100,
          countDone: 0,
          virtue: 'ذكر مبارك مختار في إعدادات الويدجت',
          source: 'الأذكار المختارة في رِفْق',
        }
      : null;

  const dhikr: DhikrItem = matchedCustom || EXPLORER_ATHKAR[currentDhikrIndex] || EXPLORER_ATHKAR[0];

  const handleNextDhikr = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!interactive) return;

    setManualOverride(true);
    soundManager.triggerHaptic(15);
    setIsSpinning(true);
    setTimeout(() => setIsSpinning(false), 300);

    let nextIdx;
    do {
      nextIdx = Math.floor(Math.random() * EXPLORER_ATHKAR.length);
    } while (nextIdx === currentDhikrIndex && EXPLORER_ATHKAR.length > 1);

    setCurrentDhikrIndex(nextIdx);
  };

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard?.writeText(`${dhikr.text}\n(${dhikr.source})\nمن تطبيق رِفْق | RIFQ`);
    soundManager.triggerHaptic(10);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTasbeehThis = (e: React.MouseEvent) => {
    e.stopPropagation();
    const settings = loadSettings();
    saveSettings({ ...settings, rosaryDhikr: dhikr.text, rosaryTarget: dhikr.countTarget || 100 });

    if (onStartTasbeehWithDhikr) {
      onStartTasbeehWithDhikr(dhikr.text);
    } else if (onOpenApp) {
      onOpenApp();
    }
  };

  // ════════════════ SMALL SIZE (2x2) ════════════════
  if (size === 'small') {
    return (
      <div
        onClick={onOpenApp}
        dir="rtl"
        style={styles.containerStyle}
        className={`relative aspect-square w-full rounded-3xl p-4 flex flex-col justify-between select-none overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.01] ${styles.container} ${styles.border} ${className}`}
      >
        {/* Subtle Watermark */}
        <div className="absolute -left-6 -bottom-6 w-28 h-28 rounded-full bg-white/5 pointer-events-none" />

        {/* Top bar: Category Badge & Dice Button */}
        <div className="flex items-center justify-between z-10">
          <div className={`px-2 py-0.5 rounded-full text-[10px] font-black flex items-center gap-1 ${styles.badge} ${styles.badgeText}`}>
            <Sparkles className="w-2.5 h-2.5" />
            <span>ذكر اليوم</span>
          </div>

          <button
            type="button"
            onClick={handleNextDhikr}
            title="ذكر عشوائي آخر"
            className={`p-1 rounded-lg transition-transform active:scale-90 cursor-pointer ${styles.subtleButton}`}
          >
            <Dices className={`w-3.5 h-3.5 transition-transform duration-300 ${isSpinning ? 'rotate-180 scale-125' : ''}`} />
          </button>
        </div>

        {/* Center: Dhikr text in Amiri Calligraphy font */}
        <div className="my-auto z-10 text-center py-1">
          <p className={`font-amiri text-base sm:text-lg font-bold leading-relaxed line-clamp-3 text-balance ${styles.primaryText}`}>
            «{dhikr.text}»
          </p>
        </div>

        {/* Bottom bar: Source, Listen & Copy Button */}
        <div className={`z-10 flex items-center justify-between gap-1 pt-1 border-t ${styles.divider}`}>
          <span className={`text-[9px] font-bold truncate max-w-[75px] ${styles.secondaryText}`}>
            {dhikr.source}
          </span>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={handleCopy}
              title="نسخ الذكر"
              className={`p-1 rounded-md transition-colors cursor-pointer ${styles.subtleButton}`}
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ════════════════ MEDIUM SIZE (4x2) ════════════════
  return (
    <div
      onClick={onOpenApp}
      dir="rtl"
      style={styles.containerStyle}
      className={`relative w-full rounded-3xl p-4 sm:p-5 flex flex-col justify-between select-none overflow-hidden cursor-pointer transition-all duration-300 hover:scale-[1.01] ${styles.container} ${styles.border} ${className}`}
    >
      {/* Background aura */}
      <div className="absolute -left-10 -bottom-10 w-44 h-44 rounded-full bg-white/5 pointer-events-none" />
      <div className="absolute right-10 -top-10 w-32 h-32 rounded-full bg-amber-400/5 pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between z-10 mb-1">
        <div className="flex items-center gap-2">
          <div className={`px-2.5 py-0.5 rounded-full text-[11px] font-black flex items-center gap-1.5 ${styles.badge} ${styles.badgeText}`}>
            <Sparkles className="w-3 h-3" />
            <span>ذكر مبارك من السنة</span>
          </div>

          <span className={`text-xs font-bold ${styles.secondaryText}`}>
            «رِفْق | RIFQ»
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handleNextDhikr}
            title="تغيير الذكر (عشوائي)"
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer ${styles.subtleButton}`}
          >
            <Dices className={`w-3.5 h-3.5 ${isSpinning ? 'rotate-180 scale-125' : ''}`} />
            <span>ذكر آخر</span>
          </button>
        </div>
      </div>

      {/* Center: Dhikr Calligraphy & Virtue */}
      <div className="my-auto z-10 py-1 space-y-1.5">
        <p className={`font-amiri text-lg sm:text-xl font-bold leading-relaxed text-balance ${styles.primaryText}`}>
          «{dhikr.text}»
        </p>

        {dhikr.virtue && (
          <p className={`text-xs font-medium line-clamp-1 ${styles.secondaryText}`}>
            ✨ <span className={`font-black ${styles.accentText}`}>فضله:</span> {dhikr.virtue}
          </p>
        )}
      </div>

      {/* Bottom Bar: Source + Action Buttons */}
      <div className={`z-10 mt-1 pt-2 border-t ${styles.divider} flex items-center justify-between flex-wrap gap-1.5`}>
        <span className={`text-[11px] font-bold ${styles.secondaryText}`}>
          المصدر: {dhikr.source}
        </span>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleCopy}
            className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer ${styles.subtleButton}`}
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
          </button>

          <button
            type="button"
            onClick={handleTasbeehThis}
            className={`px-3 py-1 rounded-xl text-xs font-black flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer ${styles.button}`}
          >
            <Play className="w-3 h-3 fill-current" />
            <span>سبّح بهذا الذكر</span>
          </button>
        </div>
      </div>
    </div>
  );
};
