import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Sparkles,
  Smartphone,
  Check,
  Layers,
  Palette,
  HelpCircle,
  Plus,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Sliders,
  MapPin,
  Flame,
  Clock,
  BookOpen,
  LayoutGrid,
  Settings2,
  Trophy,
  Save,
} from 'lucide-react';
import { WidgetType, WidgetSize, WidgetTheme, ScreenType } from '../../types';
import { TasbeehWidget } from './TasbeehWidget';
import { PrayerWidget } from './PrayerWidget';
import { DhikrWidget } from './DhikrWidget';
import { MultiWidget } from './MultiWidget';
import {
  loadSettings,
  saveSettings,
  loadCustomAthkar,
  loadHistory,
  getTodayRecord,
  calculateStreaks,
} from '../../utils/storage';
import { getCurrentCity } from '../../utils/prayerScheduler';
import {
  getInstalledNativeWidgetsStatus,
  requestPinNativeWidget,
  syncWidgetStateWithNative,
  updateNativeWidgetInstanceConfig,
  loadSavedWidgetStudioConfig,
  saveWidgetStudioConfigToPreferences,
  openNativeWidgetConfigActivity,
  NativeWidgetsStatus,
  InstalledNativeWidgetInstance,
  WidgetTargetPrayer,
  WidgetStatsMode,
  WidgetStudioConfig,
} from '../../utils/widgetService';
import { useTheme } from '../../context/ThemeContext';

interface WidgetsMainViewProps {
  onNavigate?: (screen: ScreenType) => void;
}

const BUILTIN_WIDGET_ATHKAR: string[] = [
  'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
  'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ',
  'لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ',
  'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
  'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
  'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
  'سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَلَا إِلَٰهَ إِلَّا اللَّهُ، وَاللَّهُ أَكْبَرُ',
];

const WIDGET_TYPE_LABELS: Record<WidgetType, string> = {
  tasbeeh: 'عداد التسبيح والإحصائيات',
  prayer: 'مواقيت الصلاة والأذان',
  dhikr: 'ذكر اليوم المبارك',
  multi: 'الويدجت الشامل',
};

const WIDGET_SIZE_LABELS: Record<WidgetSize, string> = {
  small: 'صغير (2×2)',
  medium: 'متوسط (4×2)',
  large: 'كبير (4×4)',
};

const WIDGET_THEME_LABELS: Record<WidgetTheme, string> = {
  navy: 'الأزرق الملكي',
  gold: 'الذهب الخالص',
  midnight: 'السواد الليلي',
  cream: 'البيج الهادئ',
};

const TARGET_PRAYER_OPTIONS: Array<{
  id: WidgetTargetPrayer;
  label: string;
  desc: string;
}> = [
  { id: 'next', label: 'الصلاة القادمة تلقائياً', desc: 'ينتقل تلقائياً للصلاة التالية طوال اليوم' },
  { id: 'fajr', label: 'صلاة الفجر', desc: 'عرض موعد الفجر والعد التنازلي له' },
  { id: 'sunrise', label: 'الشروق والضحى', desc: 'عرض موعد شروق الشمس' },
  { id: 'dhuhr', label: 'صلاة الظهر', desc: 'عرض موعد الظهر والعد التنازلي له' },
  { id: 'asr', label: 'صلاة العصر', desc: 'عرض موعد العصر والعد التنازلي له' },
  { id: 'maghrib', label: 'صلاة المغرب', desc: 'عرض موعد المغرب والعد التنازلي له' },
  { id: 'isha', label: 'صلاة العشاء', desc: 'عرض موعد العشاء والعد التنازلي له' },
];

const STATS_MODE_OPTIONS: Array<{
  id: WidgetStatsMode;
  label: string;
  desc: string;
  badge: string;
}> = [
  {
    id: 'today_count',
    label: 'عداد تسبيحات اليوم والهدف',
    desc: 'يعرض عدد تسبيحاتك اليوم مع نسبة إنجاز الهدف اليومي',
    badge: 'الافتراضي',
  },
  {
    id: 'streak',
    label: 'سلسلة المواظبة اليومية 🔥',
    desc: 'يُبرز عدد أيام مواظبتك المتتالية كإحصائية رئيسية',
    badge: 'تحفيزي',
  },
  {
    id: 'lifetime',
    label: 'الحصاد الكلي للتسبيحات 🏆',
    desc: 'يعرض إجمالي تسبيحاتك الكلي في رِفْق منذ البداية',
    badge: 'شامل',
  },
  {
    id: 'completed_athkar',
    label: 'الأذكار والأوراد المكتملة اليوم ✨',
    desc: 'يعرض عدد الأذكار والأوراد المكتملة خلال اليوم',
    badge: 'إنجاز الأوراد',
  },
];

export const WidgetsMainView: React.FC<WidgetsMainViewProps> = ({ onNavigate }) => {
  const { theme, isDark } = useTheme();
  const colors = theme.colors;
  const initialConfig = loadSavedWidgetStudioConfig();

  const [activeType, setActiveType] = useState<WidgetType>(initialConfig.type);
  const [activeSize, setActiveSize] = useState<WidgetSize>(initialConfig.size);
  const [activeTheme, setActiveTheme] = useState<WidgetTheme>(initialConfig.theme);
  const [selectedDhikr, setSelectedDhikr] = useState<string>(initialConfig.customDhikr);
  const [targetPrayer, setTargetPrayer] = useState<WidgetTargetPrayer>(initialConfig.targetPrayer);
  const [statsMode, setStatsMode] = useState<WidgetStatsMode>(initialConfig.statsMode);

  const [availableAthkar, setAvailableAthkar] = useState<string[]>(BUILTIN_WIDGET_ATHKAR);

  const [nativeStatus, setNativeStatus] = useState<NativeWidgetsStatus>({
    isNativeAndroid: false,
    supported: false,
    installedCount: 0,
    instances: [],
  });
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [isPinning, setIsPinning] = useState<boolean>(false);
  const [isSavingPrefs, setIsSavingPrefs] = useState<boolean>(false);
  const [updatingInstanceId, setUpdatingInstanceId] = useState<number | null>(null);

  const [pinFeedback, setPinFeedback] = useState<{
    status: 'idle' | 'requested' | 'pinned' | 'unsupported' | 'error';
    message: string;
  }>({ status: 'idle', message: '' });

  const [liveSummary, setLiveSummary] = useState(() => {
    const hist = loadHistory();
    const rec = getTodayRecord(hist);
    const st = calculateStreaks(hist);
    const city = getCurrentCity();
    return {
      todayCount: rec.totalCount || 0,
      streak: st.currentStreak || 0,
      cityName: city.nameAr || 'القاهرة',
    };
  });

  const officialGuideRef = useRef<HTMLDivElement | null>(null);

  const buildCurrentConfig = useCallback(
    (overrides?: Partial<WidgetStudioConfig>): WidgetStudioConfig => ({
      type: overrides?.type ?? activeType,
      size: overrides?.size ?? activeSize,
      theme: overrides?.theme ?? activeTheme,
      customDhikr: overrides?.customDhikr ?? selectedDhikr,
      targetPrayer: overrides?.targetPrayer ?? targetPrayer,
      statsMode: overrides?.statsMode ?? statsMode,
    }),
    [activeType, activeSize, activeTheme, selectedDhikr, targetPrayer, statsMode]
  );

  const persistConfigToSharedPrefs = useCallback(
    async (nextCfg: WidgetStudioConfig, applyToInstalled: boolean = true) => {
      const currentSettings = loadSettings();
      if (nextCfg.customDhikr && currentSettings.rosaryDhikr !== nextCfg.customDhikr) {
        saveSettings({
          ...currentSettings,
          rosaryDhikr: nextCfg.customDhikr,
        });
      }
      const status = await saveWidgetStudioConfigToPreferences(nextCfg, applyToInstalled);
      setNativeStatus(status);
      return status;
    },
    []
  );

  const refreshAllState = useCallback(async () => {
    const hist = loadHistory();
    const rec = getTodayRecord(hist);
    const st = calculateStreaks(hist);
    const city = getCurrentCity();
    setLiveSummary({
      todayCount: rec.totalCount || 0,
      streak: st.currentStreak || 0,
      cityName: city.nameAr || 'القاهرة',
    });

    const customList = loadCustomAthkar()
      .map((item) => item.text?.trim())
      .filter(Boolean);
    const merged = Array.from(new Set([...BUILTIN_WIDGET_ATHKAR, ...customList]));
    setAvailableAthkar(merged);

    const status = await syncWidgetStateWithNative();
    setNativeStatus(status);

    // If native SharedPreferences has a saved globalConfig, keep UI synchronized
    if (status.globalConfig) {
      const g = status.globalConfig;
      if (g.type && ['tasbeeh', 'prayer', 'dhikr', 'multi'].includes(g.type)) {
        setActiveType(g.type);
      }
      if (g.size && ['small', 'medium', 'large'].includes(g.size)) {
        setActiveSize(g.size as WidgetSize);
      }
      if (g.theme && ['navy', 'gold', 'midnight', 'cream'].includes(g.theme)) {
        setActiveTheme(g.theme);
      }
      if (g.customDhikr) {
        setSelectedDhikr(g.customDhikr);
      }
      if (g.targetPrayer) {
        setTargetPrayer(g.targetPrayer);
      }
      if (g.statsMode) {
        setStatsMode(g.statsMode);
      }
    }
  }, []);

  useEffect(() => {
    refreshAllState();

    const handleDataOrPinUpdate = (e?: Event) => {
      if (e && e.type === 'rifq-native-widget-pinned') {
        const detail = (e as CustomEvent)?.detail;
        const widgetId = detail?.appWidgetId;
        setPinFeedback({
          status: 'pinned',
          message:
            widgetId && widgetId > 0
              ? `تم تثبيت ويدجت رِفْق (#${widgetId}) فعليًا على الشاشة الرئيسية لهاتفك وحفظ إعداداتها في SharedPreferences.`
              : 'تم تثبيت ويدجت رِفْق فعليًا على الشاشة الرئيسية لهاتفك.',
        });
      } else if (e && e.type === 'rifq-native-widget-config-saved') {
        const savedCfg = loadSavedWidgetStudioConfig();
        setActiveType(savedCfg.type);
        setActiveSize(savedCfg.size);
        setActiveTheme(savedCfg.theme);
        setSelectedDhikr(savedCfg.customDhikr);
        setTargetPrayer(savedCfg.targetPrayer);
        setStatsMode(savedCfg.statsMode);
        setPinFeedback({
          status: 'pinned',
          message:
            'تم حفظ إعدادات الويدجت في SharedPreferences وتحديث جميع الويدجت المثبتة على الشاشة الرئيسية.',
        });
      }
      refreshAllState();
    };

    window.addEventListener('storage', handleDataOrPinUpdate);
    window.addEventListener('rifq-user-data-synced', handleDataOrPinUpdate);
    window.addEventListener('rifq-local-data-mutated', handleDataOrPinUpdate);
    window.addEventListener('rifq-widget-increments-merged', handleDataOrPinUpdate);
    window.addEventListener('rifq-native-widget-pinned', handleDataOrPinUpdate);
    window.addEventListener('rifq-native-widget-config-saved', handleDataOrPinUpdate);
    window.addEventListener('focus', handleDataOrPinUpdate);

    return () => {
      window.removeEventListener('storage', handleDataOrPinUpdate);
      window.removeEventListener('rifq-user-data-synced', handleDataOrPinUpdate);
      window.removeEventListener('rifq-local-data-mutated', handleDataOrPinUpdate);
      window.removeEventListener('rifq-widget-increments-merged', handleDataOrPinUpdate);
      window.removeEventListener('rifq-native-widget-pinned', handleDataOrPinUpdate);
      window.removeEventListener('rifq-native-widget-config-saved', handleDataOrPinUpdate);
      window.removeEventListener('focus', handleDataOrPinUpdate);
    };
  }, [refreshAllState]);

  const handleSelectType = async (type: WidgetType) => {
    setActiveType(type);
    await persistConfigToSharedPrefs(buildCurrentConfig({ type }), false);
  };

  const handleSelectSize = async (size: WidgetSize) => {
    setActiveSize(size);
    await persistConfigToSharedPrefs(buildCurrentConfig({ size }), true);
  };

  const handleSelectTheme = async (theme: WidgetTheme) => {
    setActiveTheme(theme);
    await persistConfigToSharedPrefs(buildCurrentConfig({ theme }), true);
  };

  const handleSelectDhikr = async (dhikr: string) => {
    setSelectedDhikr(dhikr);
    await persistConfigToSharedPrefs(buildCurrentConfig({ customDhikr: dhikr }), true);
  };

  const handleSelectTargetPrayer = async (prayer: WidgetTargetPrayer) => {
    setTargetPrayer(prayer);
    await persistConfigToSharedPrefs(buildCurrentConfig({ targetPrayer: prayer }), true);
  };

  const handleSelectStatsMode = async (mode: WidgetStatsMode) => {
    setStatsMode(mode);
    await persistConfigToSharedPrefs(buildCurrentConfig({ statsMode: mode }), true);
  };

  const handleSaveAllPreferencesNow = async () => {
    setIsSavingPrefs(true);
    try {
      const cfg = buildCurrentConfig();
      const status = await persistConfigToSharedPrefs(cfg, true);
      setPinFeedback({
        status: 'pinned',
        message: status.isNativeAndroid
          ? `تم حفظ الإعدادات في SharedPreferences وتحديث ${status.installedCount} ويدجت على الشاشة الرئيسية فوراً.`
          : 'تم حفظ تفضيلات الويدجت (الصلاة، الذكر، الإحصائية، الحجم، والنمط اللوني) بنجاح.',
      });
    } finally {
      setIsSavingPrefs(false);
    }
  };

  const handleOpenNativeConfigActivity = async (appWidgetId?: number) => {
    const cfg = buildCurrentConfig();
    await persistConfigToSharedPrefs(cfg, false);
    const res = await openNativeWidgetConfigActivity({ appWidgetId, config: cfg });
    if (!res.opened) {
      setPinFeedback({
        status: 'unsupported',
        message:
          'شاشة إعداد الويدجت الأصلية (RifqWidgetConfigActivity) تفتح تلقائياً على أجهزة Android عند تثبيت التطبيق أو إضافة الويدجت من الشاشة الرئيسية. يمكنك أيضاً تخصيص كافة الخيارات مباشرة من هذه الصفحة.',
      });
    }
  };

  const handleManualSyncNow = async () => {
    setIsSyncing(true);
    try {
      const cfg = buildCurrentConfig();
      const status = await persistConfigToSharedPrefs(cfg, true);
      setNativeStatus(status);
    } finally {
      setIsSyncing(false);
    }
  };

  /**
   * Real Android Home Screen Widget Pinning (`AppWidgetManager.requestPinAppWidget`).
   * Persists all selections (`type`, `size`, `theme`, `dhikrText`, `targetPrayer`, `statsMode`)
   * to `SharedPreferences` first so `AppWidgetProvider` reads them immediately.
   */
  const handlePinWidgetToHomeScreen = async () => {
    setIsPinning(true);
    setPinFeedback({ status: 'idle', message: '' });

    try {
      const currentCfg = buildCurrentConfig();
      await persistConfigToSharedPrefs(currentCfg, false);

      const checkStatus = await getInstalledNativeWidgetsStatus();
      setNativeStatus(checkStatus);

      if (!checkStatus.isNativeAndroid) {
        setPinFeedback({
          status: 'unsupported',
          message:
            'تم حفظ إعداداتك المختارة! التثبيت المباشر (requestPinAppWidget) يعمل داخل تطبيق الأندرويد المثبت على الهاتف. يمكنك اتباع خطوات أندرويد الرسمية بالأسفل لإضافة الويدجت من قائمة Widgets.',
        });
        officialGuideRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }

      if (!checkStatus.supported) {
        setPinFeedback({
          status: 'unsupported',
          message:
            'واجهة الشاشة الرئيسية (Launcher) الحالية في هاتفك لا تدعم التثبيت التلقائي المباشر (isRequestPinAppWidgetSupported = false). تم حفظ إعداداتك في SharedPreferences؛ يرجى إضافة الويدجت بالطريقة الرسمية: ضغط مطول على الشاشة الرئيسية ← Widgets ← رِفْق | RIFQ.',
        });
        officialGuideRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }

      const result = await requestPinNativeWidget({
        type: activeType,
        size: activeSize,
        theme: activeTheme,
        dhikrText: selectedDhikr,
        targetPrayer,
        statsMode,
      });

      const updatedStatus = await getInstalledNativeWidgetsStatus();
      setNativeStatus(updatedStatus);

      if (result.supported && result.requested) {
        setPinFeedback({
          status: 'requested',
          message: `تم حفظ إعداداتك في SharedPreferences وإرسال طلب تثبيت «${WIDGET_TYPE_LABELS[activeType]}» إلى نظام Android. اضغط «إضافة / Add» في نافذة النظام المنبثقة لوضع الويدجت على شاشتك الرئيسية.`,
        });
      } else {
        setPinFeedback({
          status: 'unsupported',
          message:
            'تم حفظ الإعدادات في SharedPreferences، ولكن تعذر فتح نافذة التثبيت المباشر من الـ Launcher الحالي. يمكنك إضافة الويدجت فوراً عبر الضغط المطول على الشاشة الرئيسية للهاتف ← Widgets ← رِفْق | RIFQ.',
        });
        officialGuideRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } catch (err: any) {
      setPinFeedback({
        status: 'error',
        message: err?.message || 'حدث خطأ أثناء طلب تثبيت الويدجت من نظام أندرويد.',
      });
    } finally {
      setIsPinning(false);
    }
  };

  const handleUpdateInstalledInstance = async (instance: InstalledNativeWidgetInstance) => {
    setUpdatingInstanceId(instance.appWidgetId);
    try {
      const updated = await updateNativeWidgetInstanceConfig({
        appWidgetId: instance.appWidgetId,
        type: activeType,
        size: activeSize,
        theme: activeTheme,
        dhikrText: selectedDhikr,
        targetPrayer,
        statsMode,
      });
      setNativeStatus(updated);
      setPinFeedback({
        status: 'pinned',
        message: `تم حفظ الإعدادات في SharedPreferences وتحديث الويدجت المثبتة (#${instance.appWidgetId}) إلى «${WIDGET_TYPE_LABELS[activeType]} • ${WIDGET_SIZE_LABELS[activeSize]} • ${WIDGET_THEME_LABELS[activeTheme]}» فوراً.`,
      });
    } finally {
      setUpdatingInstanceId(null);
    }
  };

  // Dynamic high-contrast tokens that adapt to all light and dark themes
  const primaryHeadingColor = colors.text;
  const accentHeadingColor = isDark ? colors.primary : colors.primaryDark;
  const descTextColor = colors.textSecondary;
  const mutedTextColor = colors.textMuted;

  const goldBadgeStyle: React.CSSProperties = isDark
    ? {
        backgroundColor: 'rgba(245, 158, 11, 0.18)',
        color: '#FDE68A',
        borderColor: 'rgba(245, 158, 11, 0.38)',
      }
    : {
        backgroundColor: '#FEF3C7',
        color: '#78350F',
        borderColor: '#F59E0B',
      };

  const primaryBadgeStyle: React.CSSProperties = isDark
    ? {
        backgroundColor: colors.primaryLight,
        color: colors.text,
        borderColor: colors.border,
      }
    : {
        backgroundColor: colors.primaryLight,
        color: colors.primaryDark,
        borderColor: colors.border,
      };

  const emeraldBadgeStyle: React.CSSProperties = isDark
    ? {
        backgroundColor: 'rgba(16, 185, 129, 0.16)',
        color: '#6EE7B7',
        borderColor: 'rgba(16, 185, 129, 0.35)',
      }
    : {
        backgroundColor: '#ECFDF5',
        color: '#065F46',
        borderColor: '#A7F3D0',
      };

  const darkHeroBtnStyle: React.CSSProperties = {
    background: colors.heroGradient,
    backgroundColor: '#3730A3',
    color: '#FFFFFF',
    borderColor: colors.primaryDark,
  };

  return (
    <div
      className="max-w-5xl mx-auto px-4 py-6 space-y-8 animate-fade-in"
      dir="rtl"
      style={{ color: colors.text }}
    >
      {/* Header Banner — High Contrast Adaptive Surface */}
      <div
        className="relative rounded-3xl p-6 sm:p-8 border shadow-md overflow-hidden transition-colors"
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.border,
          boxShadow: colors.shadow,
        }}
      >
        {/* Top Brand Gradient Accent Bar */}
        <div
          className="absolute top-0 right-0 left-0 h-2"
          style={{ background: colors.headerGradient }}
        />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6 pt-1">
          <div className="space-y-3.5 max-w-2xl">
            {/* Top Kicker Badge */}
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-black"
              style={primaryBadgeStyle}
            >
              <Smartphone className="w-3.5 h-3.5 shrink-0" style={{ color: colors.primary }} />
              <span>Android Home Screen Widgets • إعدادات ويدجت الشاشة الرئيسية</span>
            </div>

            {/* Main Heading */}
            <h2
              className="text-2xl sm:text-3xl font-black font-tajawal tracking-tight"
              style={{ color: primaryHeadingColor }}
            >
              تخصيص وإدارة ويدجت «رِفْق | RIFQ» على هاتفك
            </h2>

            {/* Description Paragraph */}
            <p
              className="text-sm sm:text-base leading-relaxed font-medium"
              style={{ color: descTextColor }}
            >
              اختر نوع الويدجت (الصلاة، الذكر، الإحصائيات والتسبيح، أو الشامل)، وحدد الصلاة أو الإحصائية أو الذكر المفضل لعرضه على شاشتك الرئيسية. يتم حفظ جميع اختياراتك في{' '}
              <code
                className="font-mono text-xs px-1.5 py-0.5 rounded border font-bold"
                style={primaryBadgeStyle}
              >
                SharedPreferences
              </code>{' '}
              ليقرأها{' '}
              <code
                className="font-mono text-xs px-1.5 py-0.5 rounded border font-bold"
                style={primaryBadgeStyle}
              >
                AppWidgetProvider
              </code>{' '}
              فوراً حتى والتطبيق مغلق.
            </p>

            {/* High-Contrast Feature Badges */}
            <div className="flex flex-wrap gap-2 pt-1">
              <span
                className="px-3 py-1 rounded-xl text-xs font-black border"
                style={primaryBadgeStyle}
              >
                📱 الشاشة الرئيسية الحقيقية (RemoteViews)
              </span>
              <span
                className="px-3 py-1 rounded-xl text-xs font-black border"
                style={goldBadgeStyle}
              >
                ⚡ Offline • تعمل والتطبيق مغلق
              </span>
              <span
                className="px-3 py-1 rounded-xl text-xs font-black border"
                style={emeraldBadgeStyle}
              >
                ☁️ Firebase &amp; SharedPreferences
              </span>
              <span
                className="px-3 py-1 rounded-xl text-xs font-black border"
                style={primaryBadgeStyle}
              >
                📐 أحجام الويدجت (2×2 • 4×2 • 4×4)
              </span>
            </div>
          </div>

          {/* Live Status Summary Card */}
          <div
            className="rounded-2xl p-4 border shrink-0 min-w-[250px] space-y-3"
            style={{
              backgroundColor: colors.background,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-black" style={{ color: descTextColor }}>
                الويدجت المثبتة حاليًا:
              </span>
              <span
                className="px-2.5 py-0.5 rounded-lg font-black border"
                style={goldBadgeStyle}
              >
                {nativeStatus.installedCount} ويدجت
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-black" style={{ color: descTextColor }}>
                تسبيحات اليوم:
              </span>
              <span className="font-black" style={{ color: primaryHeadingColor }}>
                {liveSummary.todayCount} تسبيحة
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-black" style={{ color: descTextColor }}>
                المدينة المعتمدة:
              </span>
              <span
                className="font-black flex items-center gap-1"
                style={{ color: accentHeadingColor }}
              >
                <MapPin className="w-3.5 h-3.5" style={{ color: colors.primary }} />
                {liveSummary.cityName}
              </span>
            </div>
            <div className="pt-1 flex flex-col gap-2">
              <button
                type="button"
                onClick={handleManualSyncNow}
                disabled={isSyncing}
                style={{
                  backgroundColor: colors.surface,
                  color: accentHeadingColor,
                  borderColor: colors.border,
                }}
                className="w-full py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border hover:opacity-90"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'جاري المزامنة...' : 'حفظ ومزامنة مع الويدجت الآن'}</span>
              </button>
              <button
                type="button"
                onClick={() => handleOpenNativeConfigActivity()}
                style={goldBadgeStyle}
                className="w-full py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border hover:opacity-90"
              >
                <Settings2 className="w-3.5 h-3.5" />
                <span>فتح شاشة إعداد الويدجت الأصلية</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Action Card: Add Widget to Home Screen & Save to SharedPreferences */}
      <div
        className="rounded-3xl p-5 sm:p-6 shadow-md border-2 space-y-4 transition-colors"
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.primary,
          boxShadow: colors.shadow,
        }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div
              className="inline-flex items-center gap-1.5 text-xs font-black"
              style={{ color: accentHeadingColor }}
            >
              <Sparkles className="w-4 h-4" style={{ color: colors.primary }} />
              <span>التثبيت والحفظ المباشر في نظام Android (SharedPreferences)</span>
            </div>
            <h3
              className="text-base sm:text-lg font-black"
              style={{ color: primaryHeadingColor }}
            >
              «{WIDGET_TYPE_LABELS[activeType]}» • {WIDGET_SIZE_LABELS[activeSize]} • {WIDGET_THEME_LABELS[activeTheme]}
            </h3>
            <p className="text-xs leading-relaxed font-medium" style={{ color: descTextColor }}>
              تُحفظ إعداداتك المختارة (الصلاة، الذكر، الإحصائية، الحجم، والنمط اللوني) في{' '}
              <code
                className="font-mono text-[11px] px-1.5 py-0.5 rounded border font-bold"
                style={primaryBadgeStyle}
              >
                SharedPreferences
              </code>{' '}
              ليقرأها{' '}
              <code
                className="font-mono text-[11px] px-1.5 py-0.5 rounded border font-bold"
                style={primaryBadgeStyle}
              >
                AppWidgetProvider
              </code>{' '}
              مباشرة على الشاشة الرئيسية.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={handleSaveAllPreferencesNow}
              disabled={isSavingPrefs}
              style={{
                backgroundColor: colors.primaryLight,
                color: accentHeadingColor,
                borderColor: colors.border,
              }}
              className="px-4 py-3.5 rounded-2xl border text-xs sm:text-sm font-black flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer disabled:opacity-60 hover:opacity-90"
            >
              <Save className="w-4 h-4" style={{ color: colors.primary }} />
              <span>{isSavingPrefs ? 'جاري الحفظ...' : 'حفظ الإعدادات للويدجت'}</span>
            </button>

            <button
              type="button"
              onClick={handlePinWidgetToHomeScreen}
              disabled={isPinning}
              style={darkHeroBtnStyle}
              className="px-5 py-3.5 rounded-2xl border text-xs sm:text-sm font-black flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer disabled:opacity-60 hover:opacity-95"
            >
              <Plus className="w-5 h-5 text-[#FDE047] stroke-[2.8]" />
              <span className="text-white">➕ إضافة الويدجت إلى الشاشة الرئيسية</span>
            </button>
          </div>
        </div>

        {/* Real Feedback Banner */}
        {pinFeedback.status !== 'idle' && (
          <div
            style={
              pinFeedback.status === 'pinned' || pinFeedback.status === 'requested'
                ? emeraldBadgeStyle
                : pinFeedback.status === 'unsupported'
                ? goldBadgeStyle
                : {
                    backgroundColor: isDark ? 'rgba(239, 68, 68, 0.18)' : '#FEF2F2',
                    color: isDark ? '#FCA5A5' : '#7F1D1D',
                    borderColor: isDark ? 'rgba(239, 68, 68, 0.4)' : '#FECACA',
                  }
            }
            className="p-4 rounded-2xl border flex items-start gap-3 text-xs font-bold leading-relaxed"
          >
            {pinFeedback.status === 'pinned' || pinFeedback.status === 'requested' ? (
              <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <p>{pinFeedback.message}</p>
            </div>
          </div>
        )}
      </div>

      {/* Main Studio Grid: Configuration Controls on one side, Live Interactive Preview on the other */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left/Main Column: Configuration Controls (lg:col-span-7) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Section 1: Choose Widget Type */}
          <div
            className="rounded-3xl p-5 sm:p-6 shadow-sm border space-y-4 transition-colors"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3
                className="text-base font-black flex items-center gap-2"
                style={{ color: primaryHeadingColor }}
              >
                <Layers className="w-4 h-4" style={{ color: colors.primary }} />
                <span>1. اختر نوع الويدجت (صلاة • ذكر • إحصائيات وتسبيح)</span>
              </h3>
              <span
                className="text-xs font-bold px-2.5 py-0.5 rounded-lg border"
                style={primaryBadgeStyle}
              >
                4 مزودات AppWidgetProvider
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                {
                  id: 'tasbeeh' as WidgetType,
                  title: 'عداد التسبيح والإحصائيات',
                  desc: 'عداد تفاعلي مع زر (+) مباشر وإحصائيات اليوم أو السلسلة أو الحصاد الكلي',
                  badge: 'إحصائيات وتسبيح',
                  icon: <Flame className="w-4 h-4 text-amber-600" />,
                },
                {
                  id: 'prayer' as WidgetType,
                  title: 'مواقيت الصلاة والأذان',
                  desc: 'عرض الصلاة القادمة أو صلاة محددة من اختيارك مع العد التنازلي والتاريخ الهجري',
                  badge: 'مواقيت الصلاة',
                  icon: <Clock className="w-4 h-4" style={{ color: colors.primary }} />,
                },
                {
                  id: 'dhikr' as WidgetType,
                  title: 'ذكر اليوم المبارك',
                  desc: 'عرض ذكر مختار أو متجدد من القرآن والسنة مع فضله ومصدره وزر التبديل والنسخ',
                  badge: 'الأذكار',
                  icon: <BookOpen className="w-4 h-4 text-emerald-600" />,
                },
                {
                  id: 'multi' as WidgetType,
                  title: 'الويدجت الشامل (3 في 1)',
                  desc: 'يجمع الإحصائيات والتسبيح، الصلاة المختارة، وذكر اليوم في بطاقة شاملة واحدة',
                  badge: 'شامل',
                  icon: <LayoutGrid className="w-4 h-4" style={{ color: colors.primary }} />,
                },
              ].map((item) => {
                const isSelected = activeType === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectType(item.id)}
                    style={{
                      backgroundColor: isSelected ? colors.primaryLight : colors.background,
                      borderColor: isSelected ? colors.primary : colors.border,
                    }}
                    className={`p-4 rounded-2xl text-right transition-all cursor-pointer border-2 ${
                      isSelected ? 'shadow-sm' : 'hover:opacity-95'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5 gap-2">
                      <span
                        className="text-xs font-black flex items-center gap-1.5"
                        style={{ color: isSelected ? accentHeadingColor : primaryHeadingColor }}
                      >
                        {item.icon}
                        <span>{item.title}</span>
                      </span>
                      <span
                        style={
                          isSelected
                            ? darkHeroBtnStyle
                            : {
                                backgroundColor: colors.surface,
                                color: descTextColor,
                                borderColor: colors.border,
                              }
                        }
                        className="text-[10px] px-2 py-0.5 rounded-md font-bold border shrink-0"
                      >
                        {item.badge}
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed font-medium" style={{ color: descTextColor }}>
                      {item.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Select Which Prayer to Display (Prayer & Multi Widgets) */}
          <div
            className="rounded-3xl p-5 sm:p-6 shadow-sm border space-y-4 transition-colors"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3
                className="text-base font-black flex items-center gap-2"
                style={{ color: primaryHeadingColor }}
              >
                <Clock className="w-4 h-4" style={{ color: colors.primary }} />
                <span>2. اختر الصلاة المعروضة في الويدجت</span>
              </h3>
              <span
                className="text-[11px] font-bold px-2.5 py-0.5 rounded-lg border"
                style={emeraldBadgeStyle}
              >
                تُحفظ في SharedPreferences
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {TARGET_PRAYER_OPTIONS.map((p) => {
                const isSelected = targetPrayer === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleSelectTargetPrayer(p.id)}
                    style={
                      isSelected
                        ? darkHeroBtnStyle
                        : {
                            backgroundColor: colors.background,
                            color: primaryHeadingColor,
                            borderColor: colors.border,
                          }
                    }
                    className={`p-3 rounded-2xl text-right transition-all cursor-pointer border-2 ${
                      p.id === 'next' ? 'col-span-2' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className="text-xs font-black"
                        style={{ color: isSelected ? '#FFFFFF' : primaryHeadingColor }}
                      >
                        {p.label}
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#FDE047] shrink-0" />}
                    </div>
                    <div
                      className="text-[10px] mt-0.5 line-clamp-1 font-medium"
                      style={{
                        color: isSelected ? 'rgba(255, 255, 255, 0.9)' : descTextColor,
                      }}
                    >
                      {p.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 3: Select Which Stats Metric to Display (Tasbeeh & Multi Widgets) */}
          <div
            className="rounded-3xl p-5 sm:p-6 shadow-sm border space-y-4 transition-colors"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3
                className="text-base font-black flex items-center gap-2"
                style={{ color: primaryHeadingColor }}
              >
                <Trophy className="w-4 h-4" style={{ color: colors.primary }} />
                <span>3. اختر الإحصائية المعروضة في ويدجت الإحصائيات والتسبيح</span>
              </h3>
              <span
                className="text-[11px] font-bold px-2.5 py-0.5 rounded-lg border"
                style={emeraldBadgeStyle}
              >
                تُحفظ في SharedPreferences
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {STATS_MODE_OPTIONS.map((st) => {
                const isSelected = statsMode === st.id;
                return (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => handleSelectStatsMode(st.id)}
                    style={{
                      backgroundColor: isSelected ? colors.primaryLight : colors.background,
                      borderColor: isSelected ? colors.primary : colors.border,
                    }}
                    className={`p-3.5 rounded-2xl text-right transition-all cursor-pointer border-2 ${
                      isSelected ? 'shadow-sm' : 'hover:opacity-95'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1 gap-2">
                      <span
                        className="text-xs font-black"
                        style={{ color: isSelected ? accentHeadingColor : primaryHeadingColor }}
                      >
                        {st.label}
                      </span>
                      <span
                        style={
                          isSelected
                            ? darkHeroBtnStyle
                            : {
                                backgroundColor: colors.surface,
                                color: descTextColor,
                                borderColor: colors.border,
                              }
                        }
                        className="text-[10px] px-2 py-0.5 rounded-md font-bold border shrink-0"
                      >
                        {st.badge}
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed font-medium" style={{ color: descTextColor }}>
                      {st.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 4: Select Active Dhikr for Tasbeeh, Dhikr & Multi Widgets */}
          <div
            className="rounded-3xl p-5 sm:p-6 shadow-sm border space-y-4 transition-colors"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3
                className="text-base font-black flex items-center gap-2"
                style={{ color: primaryHeadingColor }}
              >
                <Sliders className="w-4 h-4" style={{ color: colors.primary }} />
                <span>4. اختر الذكر المعروض في الويدجت</span>
              </h3>
              <span
                className="text-[11px] font-bold px-2.5 py-0.5 rounded-lg border"
                style={emeraldBadgeStyle}
              >
                يُحفظ ويُزامن تلقائياً مع الويدجت
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {availableAthkar.map((dhikr) => {
                const isSelected = selectedDhikr === dhikr;
                return (
                  <button
                    key={dhikr}
                    type="button"
                    onClick={() => handleSelectDhikr(dhikr)}
                    style={
                      isSelected
                        ? goldBadgeStyle
                        : {
                            backgroundColor: colors.background,
                            color: primaryHeadingColor,
                            borderColor: colors.border,
                          }
                    }
                    className="p-3 rounded-2xl text-right text-xs font-bold transition-all cursor-pointer border-2 flex items-center justify-between gap-2"
                  >
                    <span className="truncate">{dhikr}</span>
                    {isSelected && <Check className="w-4 h-4 shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 5: Choose Size & Layout */}
          <div
            className="rounded-3xl p-5 sm:p-6 shadow-sm border space-y-4 transition-colors"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h3
                className="text-base font-black flex items-center gap-2"
                style={{ color: primaryHeadingColor }}
              >
                <Smartphone className="w-4 h-4" style={{ color: colors.primary }} />
                <span>5. أحجام الويدجت والتخطيط</span>
              </h3>
              <span
                className="text-[11px] font-bold px-2.5 py-0.5 rounded-lg border"
                style={primaryBadgeStyle}
              >
                يدعم تغيير الحجم الحر على الشاشة الرئيسية
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 sm:gap-3">
              {[
                { id: 'small' as WidgetSize, label: 'صغير (2×2)', sub: 'بطاقة مربعة مدمجة' },
                { id: 'medium' as WidgetSize, label: 'متوسط (4×2)', sub: 'شريط أفقي عريض (شائع)' },
                { id: 'large' as WidgetSize, label: 'كبير (4×4)', sub: 'بطاقة شاملة موسعة' },
              ].map((s) => {
                const isSelected = activeSize === s.id;
                return (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => handleSelectSize(s.id)}
                    style={
                      isSelected
                        ? darkHeroBtnStyle
                        : {
                            backgroundColor: colors.background,
                            color: primaryHeadingColor,
                            borderColor: colors.border,
                          }
                    }
                    className="p-3.5 rounded-2xl text-center transition-all cursor-pointer border-2"
                  >
                    <div
                      className="text-xs font-black"
                      style={{ color: isSelected ? '#FFFFFF' : primaryHeadingColor }}
                    >
                      {s.label}
                    </div>
                    <div
                      className="text-[10px] mt-0.5 font-medium"
                      style={{
                        color: isSelected ? 'rgba(255, 255, 255, 0.9)' : descTextColor,
                      }}
                    >
                      {s.sub}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 6: Color Theme */}
          <div
            className="rounded-3xl p-5 sm:p-6 shadow-sm border space-y-4 transition-colors"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
          >
            <h3
              className="text-base font-black flex items-center gap-2"
              style={{ color: primaryHeadingColor }}
            >
              <Palette className="w-4 h-4" style={{ color: colors.primary }} />
              <span>6. النمط اللوني للهوية</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                {
                  id: 'navy' as WidgetTheme,
                  name: 'الأزرق الملكي',
                  desc: 'الهوية الرسمية للتطبيق',
                  swatchStyle: {
                    background: 'linear-gradient(135deg, #4338CA 0%, #312E81 100%)',
                    color: '#FFFFFF',
                    borderColor: '#312E81',
                  },
                },
                {
                  id: 'gold' as WidgetTheme,
                  name: 'الذهب الخالص',
                  desc: 'أناقة فاخرة مذهبة',
                  swatchStyle: {
                    background: 'linear-gradient(135deg, #FFFDF7 0%, #FDE68A 100%)',
                    color: '#78350F',
                    borderColor: '#D97706',
                  },
                },
                {
                  id: 'midnight' as WidgetTheme,
                  name: 'السواد الليلي',
                  desc: 'مريح للعين وخلفيات داكنة',
                  swatchStyle: {
                    background: 'linear-gradient(135deg, #0F172A 0%, #1E293B 100%)',
                    color: '#FFFFFF',
                    borderColor: '#334155',
                  },
                },
                {
                  id: 'cream' as WidgetTheme,
                  name: 'البيج الهادئ',
                  desc: 'خفيف وناعم وشفاف',
                  swatchStyle: {
                    background: 'linear-gradient(135deg, #FFFFFF 0%, #E0E7FF 100%)',
                    color: '#1E2035',
                    borderColor: '#94A3B8',
                  },
                },
              ].map((t) => {
                const isSelected = activeTheme === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => handleSelectTheme(t.id)}
                    style={{
                      backgroundColor: isSelected ? colors.primaryLight : colors.background,
                      borderColor: isSelected ? colors.primary : colors.border,
                    }}
                    className={`p-3 rounded-2xl text-right transition-all cursor-pointer border-2 ${
                      isSelected ? 'shadow-sm' : 'hover:opacity-95'
                    }`}
                  >
                    <div
                      style={t.swatchStyle}
                      className="h-8 rounded-xl border mb-2 flex items-center justify-center shadow-2xs"
                    >
                      <span className="text-[11px] font-black">رِفْق</span>
                    </div>
                    <div
                      className="text-xs font-black"
                      style={{ color: isSelected ? accentHeadingColor : primaryHeadingColor }}
                    >
                      {t.name}
                    </div>
                    <div
                      className="text-[10px] mt-0.5 font-medium"
                      style={{ color: descTextColor }}
                    >
                      {t.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 7: Installed Android Home Screen Widgets Manager */}
          <div
            className="rounded-3xl p-5 sm:p-6 shadow-sm border space-y-4 transition-colors"
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
          >
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h3
                  className="text-base font-black flex items-center gap-2"
                  style={{ color: primaryHeadingColor }}
                >
                  <LayoutGrid className="w-4 h-4" style={{ color: colors.primary }} />
                  <span>الويدجت المثبتة حاليًا على الشاشة الرئيسية ({nativeStatus.installedCount})</span>
                </h3>
                <p className="text-xs mt-0.5 font-medium" style={{ color: descTextColor }}>
                  يدعم رِفْق تخصيص كل ويدجت مثبتة على الشاشة الرئيسية بشكل مستقل في SharedPreferences
                </p>
              </div>
              <button
                type="button"
                onClick={handleManualSyncNow}
                style={primaryBadgeStyle}
                className="px-3 py-1.5 rounded-xl border text-xs font-black flex items-center gap-1 cursor-pointer hover:opacity-90"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>فحص وتحديث</span>
              </button>
            </div>

            {nativeStatus.instances.length > 0 ? (
              <div className="space-y-2.5">
                {nativeStatus.instances.map((inst) => (
                  <div
                    key={inst.appWidgetId}
                    style={{
                      backgroundColor: colors.background,
                      borderColor: colors.border,
                    }}
                    className="p-3.5 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span
                          style={darkHeroBtnStyle}
                          className="px-2 py-0.5 rounded-md text-[10px] font-black"
                        >
                          #{inst.appWidgetId}
                        </span>
                        <span
                          className="text-xs font-black"
                          style={{ color: primaryHeadingColor }}
                        >
                          {WIDGET_TYPE_LABELS[inst.type] || inst.type}
                        </span>
                        <span className="text-[11px] font-bold" style={{ color: descTextColor }}>
                          • {WIDGET_SIZE_LABELS[inst.effectiveSize] || inst.effectiveSize} •{' '}
                          {WIDGET_THEME_LABELS[inst.theme] || inst.theme}
                        </span>
                      </div>
                      {inst.customDhikr && (
                        <p
                          className="text-[11px] truncate max-w-md font-medium"
                          style={{ color: descTextColor }}
                        >
                          الذكر: {inst.customDhikr}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleOpenNativeConfigActivity(inst.appWidgetId)}
                        style={{
                          backgroundColor: colors.surface,
                          color: accentHeadingColor,
                          borderColor: colors.border,
                        }}
                        className="px-3 py-2 rounded-xl border text-xs font-black flex items-center gap-1 cursor-pointer hover:opacity-90"
                      >
                        <Settings2 className="w-3.5 h-3.5" />
                        <span>إعداد أصلي</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleUpdateInstalledInstance(inst)}
                        disabled={updatingInstanceId === inst.appWidgetId}
                        style={darkHeroBtnStyle}
                        className="px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer shrink-0 disabled:opacity-60 hover:opacity-95"
                      >
                        {updatingInstanceId === inst.appWidgetId
                          ? 'جاري الحفظ...'
                          : 'تطبيق الإعدادات الحالية'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div
                style={{
                  backgroundColor: colors.background,
                  borderColor: colors.border,
                }}
                className="p-4 rounded-2xl border border-dashed text-center space-y-2"
              >
                <p className="text-xs font-black" style={{ color: primaryHeadingColor }}>
                  تُحفظ جميع اختياراتك أعلاه كإعدادات افتراضية في SharedPreferences لأي ويدجت تضيفها على شاشتك الرئيسية.
                </p>
                <p className="text-[11px] font-medium" style={{ color: descTextColor }}>
                  اضغط على زر «➕ إضافة الويدجت إلى الشاشة الرئيسية» بالأعلى أو أضفها من قائمة Widgets في هاتفك لتظهر هنا وتتحكم بكل ويدجت بشكل مستقل.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Live Interactive Preview on Home Screen (lg:col-span-5) */}
        <div className="lg:col-span-5 space-y-4 lg:sticky lg:top-6">
          <div
            style={{
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}
            className="flex items-center justify-between px-4 py-3 rounded-2xl border shadow-2xs"
          >
            <span
              className="text-xs font-black flex items-center gap-1.5"
              style={{ color: primaryHeadingColor }}
            >
              <Smartphone className="w-4 h-4" style={{ color: colors.primary }} />
              <span>معاينة حية مطابقة لويدجت الشاشة الرئيسية</span>
            </span>
            <span
              style={emeraldBadgeStyle}
              className="px-2.5 py-0.5 rounded-lg border text-[10px] font-black"
            >
              مرتبطة بـ SharedPreferences
            </span>
          </div>

          {/* Android Home Screen Chassis */}
          <div className="relative mx-auto w-full max-w-[340px] rounded-[48px] p-3 bg-stone-900 shadow-2xl ring-1 ring-white/20 border-4 border-stone-800 select-none">
            <div
              className="relative w-full aspect-[9/18.5] rounded-[38px] overflow-hidden flex flex-col justify-between p-4"
              style={{
                background: 'linear-gradient(145deg, #1E293B 0%, #0F172A 50%, #312E81 100%)',
              }}
              dir="rtl"
            >
              {/* Front Camera Punch Hole */}
              <div className="absolute top-2.5 left-1/2 -translate-x-1/2 z-30">
                <div className="w-3.5 h-3.5 bg-black rounded-full border border-stone-800" />
              </div>

              {/* Status Bar */}
              <div
                className="flex items-center justify-between text-white text-[11px] font-bold pt-1 z-20"
                dir="ltr"
              >
                <span>09:41</span>
                <div className="flex items-center gap-1.5 text-[10px]">
                  <span>5G</span>
                  <span>100%</span>
                </div>
              </div>

              {/* Home Screen Active Widget Area */}
              <div className="space-y-4 my-auto z-20">
                <div className="w-full transition-all duration-300">
                  {activeType === 'tasbeeh' && (
                    <TasbeehWidget
                      size={activeSize}
                      theme={activeTheme}
                      customDhikr={selectedDhikr}
                      statsMode={statsMode}
                      onOpenApp={() => onNavigate?.('rosary')}
                    />
                  )}
                  {activeType === 'prayer' && (
                    <PrayerWidget
                      size={activeSize}
                      theme={activeTheme}
                      targetPrayer={targetPrayer}
                      onOpenApp={() => onNavigate?.('prayers')}
                    />
                  )}
                  {activeType === 'dhikr' && (
                    <DhikrWidget
                      size={activeSize}
                      theme={activeTheme}
                      customDhikr={selectedDhikr}
                      onOpenApp={() => onNavigate?.('athkar')}
                    />
                  )}
                  {activeType === 'multi' && (
                    <MultiWidget
                      size={activeSize}
                      theme={activeTheme}
                      targetPrayer={targetPrayer}
                      statsMode={statsMode}
                      customDhikr={selectedDhikr}
                      onOpenApp={() => onNavigate?.('home')}
                      onNavigateScreen={onNavigate}
                    />
                  )}
                </div>

                {/* Home Screen App Icons */}
                <div className="grid grid-cols-4 gap-3 text-center pt-2">
                  <button
                    type="button"
                    onClick={() => onNavigate?.('home')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div
                      style={{
                        background: 'linear-gradient(135deg, #5B5FEF 0%, #4145C7 100%)',
                      }}
                      className="w-12 h-12 rounded-2xl p-2 flex items-center justify-center border border-white/25 shadow-sm group-hover:scale-105 transition-transform"
                    >
                      <Sparkles className="w-6 h-6 text-[#FDE047]" />
                    </div>
                    <span className="text-[10px] text-white font-bold truncate max-w-full">
                      رِفْق | RIFQ
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onNavigate?.('rosary')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div
                      style={{ backgroundColor: '#F8FAFC', color: '#1E2035' }}
                      className="w-12 h-12 rounded-2xl p-2 flex items-center justify-center shadow-sm font-bold text-xs group-hover:scale-105 transition-transform"
                    >
                      📿
                    </div>
                    <span className="text-[10px] text-white font-bold">المسبحة</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onNavigate?.('prayers')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 p-2 flex items-center justify-center text-white text-xs border border-white/15 shadow-sm group-hover:scale-105 transition-transform">
                      🕌
                    </div>
                    <span className="text-[10px] text-white font-bold">الصلاة</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onNavigate?.('harvest')}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div
                      style={{ backgroundColor: '#4338CA', color: '#FFFFFF' }}
                      className="w-12 h-12 rounded-2xl p-2 flex items-center justify-center text-xs border border-white/20 shadow-sm group-hover:scale-105 transition-transform"
                    >
                      🌾
                    </div>
                    <span className="text-[10px] text-white font-bold">حصادي</span>
                  </button>
                </div>
              </div>

              {/* Bottom Dock */}
              <div className="z-20 bg-white/15 backdrop-blur-md p-2 rounded-3xl grid grid-cols-4 gap-2 mb-2">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600 flex items-center justify-center text-white text-xs shadow-xs mx-auto">
                  📞
                </div>
                <div className="w-10 h-10 rounded-2xl bg-blue-600 flex items-center justify-center text-white text-xs shadow-xs mx-auto">
                  💬
                </div>
                <div className="w-10 h-10 rounded-2xl bg-amber-600 flex items-center justify-center text-white text-xs shadow-xs mx-auto">
                  🧭
                </div>
                <div className="w-10 h-10 rounded-2xl bg-purple-700 flex items-center justify-center text-white text-xs shadow-xs mx-auto">
                  📖
                </div>
              </div>

              {/* Home indicator bar */}
              <div className="w-28 h-1 bg-white/60 rounded-full mx-auto z-20" />
            </div>
          </div>

          <p className="text-center text-xs font-bold" style={{ color: descTextColor }}>
            💡 جميع الخيارات المختارة على اليمين تُحفظ تلقائياً في SharedPreferences وتنعكس فوراً على الويدجت!
          </p>
        </div>
      </div>

      {/* Official Android Home Screen Widget Guide */}
      <div
        ref={officialGuideRef}
        style={{
          backgroundColor: colors.surface,
          borderColor: colors.border,
        }}
        className="rounded-3xl p-6 sm:p-8 shadow-sm border space-y-6 transition-colors"
      >
        <div
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b"
          style={{ borderColor: colors.divider }}
        >
          <div>
            <h3
              className="text-lg font-black flex items-center gap-2"
              style={{ color: primaryHeadingColor }}
            >
              <HelpCircle className="w-5 h-5" style={{ color: colors.primary }} />
              <span>الطريقة الرسمية لإضافة وتخصيص ويدجت «رِفْق | RIFQ» على الشاشة الرئيسية</span>
            </h3>
            <p className="text-xs mt-1 font-medium" style={{ color: descTextColor }}>
              يمكنك تثبيت الويدجت وتخصيصها مباشرة من هذه الصفحة، أو عبر شاشة الإعداد الأصلية (RifqWidgetConfigActivity) عند إضافتها من قائمة Widgets
            </p>
          </div>
          <span
            style={primaryBadgeStyle}
            className="px-3 py-1.5 rounded-xl border text-xs font-black shrink-0"
          >
            APPWIDGET_CONFIGURE + SharedPreferences
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div
            style={{
              backgroundColor: colors.background,
              borderColor: colors.border,
            }}
            className="p-4 rounded-2xl border space-y-2"
          >
            <div
              style={darkHeroBtnStyle}
              className="w-7 h-7 rounded-xl font-black text-xs flex items-center justify-center"
            >
              1
            </div>
            <h4 className="text-sm font-black" style={{ color: primaryHeadingColor }}>
              ضغطة مطولة على الشاشة الرئيسية
            </h4>
            <p className="text-xs leading-relaxed font-medium" style={{ color: descTextColor }}>
              اخرج إلى الشاشة الرئيسية لهاتفك (Home Screen) واضغط ضغطة مطولة على أي مساحة فارغة.
            </p>
          </div>

          <div
            style={{
              backgroundColor: colors.background,
              borderColor: colors.border,
            }}
            className="p-4 rounded-2xl border space-y-2"
          >
            <div
              style={darkHeroBtnStyle}
              className="w-7 h-7 rounded-xl font-black text-xs flex items-center justify-center"
            >
              2
            </div>
            <h4 className="text-sm font-black" style={{ color: primaryHeadingColor }}>
              اختر قائمة Widgets (الويدجت)
            </h4>
            <p className="text-xs leading-relaxed font-medium" style={{ color: descTextColor }}>
              من القائمة التي تظهر أسفل الشاشة، اضغط على خيار{' '}
              <span className="font-black" style={{ color: accentHeadingColor }}>
                «Widgets»
              </span>{' '}
              أو{' '}
              <span className="font-black" style={{ color: accentHeadingColor }}>
                «التطبيقات المصغرة»
              </span>
              .
            </p>
          </div>

          <div
            style={{
              backgroundColor: colors.background,
              borderColor: colors.border,
            }}
            className="p-4 rounded-2xl border space-y-2"
          >
            <div
              style={darkHeroBtnStyle}
              className="w-7 h-7 rounded-xl font-black text-xs flex items-center justify-center"
            >
              3
            </div>
            <h4 className="text-sm font-black" style={{ color: primaryHeadingColor }}>
              اختر تطبيق «رِفْق | RIFQ»
            </h4>
            <p className="text-xs leading-relaxed font-medium" style={{ color: descTextColor }}>
              ابحث عن قسم{' '}
              <span className="font-black" style={{ color: accentHeadingColor }}>
                «رِفْق | RIFQ»
              </span>
              ، وستجد 4 ويدجت رسمية (التسبيح والإحصائيات، مواقيت الصلاة، ذكر اليوم، والويدجت الشامل).
            </p>
          </div>

          <div
            style={{
              backgroundColor: colors.background,
              borderColor: colors.border,
            }}
            className="p-4 rounded-2xl border space-y-2"
          >
            <div
              style={darkHeroBtnStyle}
              className="w-7 h-7 rounded-xl font-black text-xs flex items-center justify-center"
            >
              4
            </div>
            <h4 className="text-sm font-black" style={{ color: primaryHeadingColor }}>
              اختر الصلاة أو الذكر أو الإحصائية
            </h4>
            <p className="text-xs leading-relaxed font-medium" style={{ color: descTextColor }}>
              تفتح لك شاشة الإعداد الأصلية لاختيار الصلاة أو الذكر أو الإحصائية والنمط اللوني وحفظها في SharedPreferences ليقرأها AppWidgetProvider فوراً.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
