import React, { useState } from 'react';
import {
  ArrowRight,
  Compass,
  RotateCcw,
  CheckCircle2,
  Plus,
  BookOpen,
  MapPin,
  ShieldAlert,
} from 'lucide-react';
import { soundManager } from '../../utils/audio';
import { ScreenType } from '../../types';
import { HajjUmrahSectionSvg } from '../Home/RifqSectionIcons';

interface HajjUmrahViewProps {
  onBack: () => void;
  onNavigate?: (screen: ScreenType) => void;
}

interface ManasikStep {
  id: string;
  category: 'umrah' | 'hajj';
  dayBadge: string;
  title: string;
  ruling: 'ركن' | 'واجب' | 'سنة مؤكدة';
  description: string;
  authenticDuaa: string;
  duaaSource: string;
}

const MANASIK_STEPS: ManasikStep[] = [
  {
    id: 'ihram',
    category: 'umrah',
    dayBadge: 'الخطوة ١ — الميقات',
    title: 'الإحرام من الميقات والتلبية',
    ruling: 'ركن',
    description:
      'الاغتسال والتطيب في البدن قبل عقد نية الإحرام، ولبس إزار ورداء أبيضين للرجل، ثم عقد نية الدخول في النسك قائلاً: «لَبَّيْكَ عُمْرَةً» أو «لَبَّيْكَ حَجًّا»، ورفع الصوت بالتلبية.',
    authenticDuaa:
      '«لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لَا شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لَا شَرِيكَ لَكَ»',
    duaaSource: 'متفق عليه',
  },
  {
    id: 'tawaf_umrah',
    category: 'umrah',
    dayBadge: 'الخطوة ٢ — المسجد الحرام',
    title: 'الطواف بالبيت العتيق (٧ أشواط)',
    ruling: 'ركن',
    description:
      'يبدأ كل شوط من الحجر الأسود باستلامه أو الإشارة إليه باليد اليمنى قائلاً: «بِسْمِ اللَّهِ وَاللَّهُ أَكْبَرُ»، ويجعل الكعبة عن يساره، مع الاضطباع والرَّمَل للرجال في الأشواط الثلاثة الأولى، ثم يصلي ركعتين خلف مقام إبراهيم.',
    authenticDuaa:
      'بين الركن اليماني والحجر الأسود: «رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ»',
    duaaSource: 'سنن أبي داود (حسنه الألباني)',
  },
  {
    id: 'saee_umrah',
    category: 'umrah',
    dayBadge: 'الخطوة ٣ — المسعى',
    title: 'السعي بين الصفا والمروة (٧ أشواط)',
    ruling: 'ركن',
    description:
      'يبدأ بالصفا فيستقبل القبلة ويكبر ويدعو، ثم يسعى إلى المروة (هذا شوط أول)، ثم من المروة إلى الصفا (شوط ثانٍ)، حتى يتم سبعة أشواط تنتهي بالمروة.',
    authenticDuaa:
      '«إِنَّ الصَّفَا وَالْمَرْوَةَ مِن شَعَائِرِ اللَّهِ... لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ، أَنْجَزَ وَعْدَهُ، وَنَصَرَ عَبْدَهُ، وَهَزَمَ الْأَحْزَابَ وَحْدَهُ»',
    duaaSource: 'صحيح مسلم',
  },
  {
    id: 'halq_taqseer',
    category: 'umrah',
    dayBadge: 'الخطوة ٤ — التحلل',
    title: 'الحلق أو التقصير',
    ruling: 'واجب',
    description:
      'حلق شعر الرأس كله أو تقصيره من جميع جوانبه للرجال (والحلق أفضل لدعاء النبي ﷺ للمحلقين ثلاثاً)، وتقصّر المرأة من أطراف شعرها قدر أنملة.',
    authenticDuaa: '«اللَّهُمَّ اغْفِرْ لِلْمُحَلِّقِينَ» قَالُوا: وَالْمُقَصِّرِينَ؟ قَالَ فِي الرَّابِعَةِ: «وَالْمُقَصِّرِينَ»',
    duaaSource: 'متفق عليه',
  },
  {
    id: 'tarwiyah',
    category: 'hajj',
    dayBadge: '٨ ذو الحجة — يوم التروية',
    title: 'الإحرام بالحج والتوجه إلى منى',
    ruling: 'سنة مؤكدة',
    description:
      'يحرم المتمتع بالحج ضحى يوم الثامن من مكانه، ويتوجه الحجاج إلى منى فيصلون بها الظهر والعصر والمغرب والعشاء والفجر قصراً للصلاة الرباعية دون جمع.',
    authenticDuaa: 'الإكثار من التلبية والذكر والدعاء.',
    duaaSource: 'صحيح مسلم',
  },
  {
    id: 'arafah',
    category: 'hajj',
    dayBadge: '٩ ذو الحجة — الركن الأعظم',
    title: 'الوقوف بعرفة إلى غروب الشمس',
    ruling: 'ركن',
    description:
      'الحج عرفة؛ يصلي الحاج الظهر والعصر جمع تقديم وقصراً بأذان واحد وإقامتين، ويتفرغ للذكر والدعاء والتضرع مستقبلاً القبلة حتى تغرب الشمس.',
    authenticDuaa:
      '«خَيْرُ الدُّعَاءِ دُعَاءُ يَوْمِ عَرَفَةَ، وَخَيْرُ مَا قُلْتُ أَنَا وَالنَّبِيُّونَ مِنْ قَبْلِي: لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ»',
    duaaSource: 'جامع الترمذي (حسنه الألباني)',
  },
  {
    id: 'muzdalifah',
    category: 'hajj',
    dayBadge: 'ليلة ١٠ ذو الحجة',
    title: 'المبيت بمزدلفة والوقوف بالمشعر الحرام',
    ruling: 'واجب',
    description:
      'يدفع الحاج بعد غروب شمس عرفة بسكينة إلى مزدلفة، فيصلي بها المغرب والعشاء جمعاً وقصراً، ويبيت بها حتى يصلي الفجر ويدعو عند المشعر الحرام حتى يسفر جداً.',
    authenticDuaa: '﴿ فَإِذَا أَفَضْتُم مِّنْ عَرَفَاتٍ فَاذْكُرُوا اللَّهَ عِندَ الْمَشْعَرِ الْحَرَامِ ﴾',
    duaaSource: 'سورة البقرة: ١٩٨',
  },
  {
    id: 'nahr_ifadah',
    category: 'hajj',
    dayBadge: '١٠ ذو الحجة — يوم النحر',
    title: 'رمي جمرة العقبة، النحر، الحلق، وطواف الإفاضة',
    ruling: 'ركن',
    description:
      'أعمال يوم العيد أربعة مرتبة: رمي جمرة العقبة بسبع حصيات، ثم نحر الهدي، ثم الحلق أو التقصير (وبهذا يتحلل التحلل الأصغر)، ثم طواف الإفاضة وسعي الحج (ويتحلل التحلل الأكبر).',
    authenticDuaa: 'التكبير مع كل حصاة: «اللَّهُ أَكْبَرُ»',
    duaaSource: 'متفق عليه',
  },
  {
    id: 'tashreeq_wadaa',
    category: 'hajj',
    dayBadge: '١١ — ١٣ ذو الحجة',
    title: 'المبيت بمنى ورمي الجمرات الثلاث وطواف الوداع',
    ruling: 'واجب',
    description:
      'المبيت بمنى ليالي التشريق، ورمي الجمرات الثلاث بعد الزوال (الصغرى ثم الوسطى ويدعو بعدهما طويلاً، ثم الكبرى ولا يقف بعدها)، ثم طواف الوداع عند إرادة السفر.',
    authenticDuaa: '«لَا يَنْفِرَنَّ أَحَدٌ حَتَّى يَكُونَ آخِرُ عَهْدِهِ بِالْبَيْتِ»',
    duaaSource: 'صحيح مسلم',
  },
];

const MIQATS_LIST = [
  { name: 'ذو الحليفة (أبيار علي)', forPeople: 'ميقات أهل المدينة المنورة ومن مرّ طريقهم', distance: '٤٥٠ كم عن مكة' },
  { name: 'الجحفة (رابغ)', forPeople: 'ميقات أهل الشام ومصر والمغرب ومن حاذاهم', distance: '١٨٣ كم عن مكة' },
  { name: 'قرن المنازل (السيل الكبير / وادي محرم)', forPeople: 'ميقات أهل نجد والطائف والخليج', distance: '٧٥ كم عن مكة' },
  { name: 'يلملم (السعدية)', forPeople: 'ميقات أهل اليمن وتهامة', distance: '٩٢ كم عن مكة' },
  { name: 'ذات عرق (الضريبة)', forPeople: 'ميقات أهل العراق والمشرق', distance: '٩٤ كم عن مكة' },
];

export const HajjUmrahView: React.FC<HajjUmrahViewProps> = ({ onBack, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'counter' | 'manasik' | 'miqats'>('counter');

  // Interactive Tawaf & Sa'ee Counter State
  const [counterMode, setCounterMode] = useState<'tawaf' | 'saee'>('tawaf');
  const [tawafRound, setTawafRound] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_mutawwif_tawaf');
    return saved ? parseInt(saved, 10) : 1;
  });
  const [saeeRound, setSaeeRound] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_mutawwif_saee');
    return saved ? parseInt(saved, 10) : 1;
  });
  const [completedSteps, setCompletedSteps] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem('rifq_mutawwif_steps');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const currentRound = counterMode === 'tawaf' ? tawafRound : saeeRound;
  const isCompletedAllRounds = currentRound > 7;

  const advanceRound = () => {
    soundManager.triggerHaptic(45);
    if (counterMode === 'tawaf') {
      const next = Math.min(8, tawafRound + 1);
      setTawafRound(next);
      localStorage.setItem('rifq_mutawwif_tawaf', String(next));
    } else {
      const next = Math.min(8, saeeRound + 1);
      setSaeeRound(next);
      localStorage.setItem('rifq_mutawwif_saee', String(next));
    }
  };

  const resetCounter = () => {
    if (counterMode === 'tawaf') {
      setTawafRound(1);
      localStorage.setItem('rifq_mutawwif_tawaf', '1');
    } else {
      setSaeeRound(1);
      localStorage.setItem('rifq_mutawwif_saee', '1');
    }
  };

  const toggleStepDone = (id: string) => {
    const next = completedSteps.includes(id)
      ? completedSteps.filter((x) => x !== id)
      : [...completedSteps, id];
    setCompletedSteps(next);
    localStorage.setItem('rifq_mutawwif_steps', JSON.stringify(next));
  };

  // Sa'ee direction helper: odd rounds (1,3,5,7) Safa -> Marwah, even rounds (2,4,6) Marwah -> Safa
  const saeeDirectionText =
    saeeRound <= 7
      ? saeeRound % 2 === 1
        ? `الشوط ${saeeRound}: من جبل الصَّفَا ← إلى جبل المَرْوَة`
        : `الشوط ${saeeRound}: من جبل المَرْوَة ← إلى جبل الصَّفَا`
      : 'أتممت السعي سبعة أشواط كاملة بحمد الله (عند المروة)';

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-24 select-none" dir="rtl">
      {/* الشريط العلوي */}
      <div className="bg-[#FFFFFF] border-b border-[#E6E6F0] px-4 py-3.5 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
              aria-label="رجوع"
            >
              <ArrowRight className="w-5 h-5 text-[#5B5FEF]" />
            </button>
            <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 shadow-2xs">
              <HajjUmrahSectionSvg size={28} />
            </div>
            <div>
              <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A]">
                دليل الحج والعمرة (المطوّف الذكي)
              </h1>
              <p className="text-xs text-[#77798C]">
                عداد أشواط الطواف والسعي التفاعلي ودليل المناسك والأدعية المأثورة
              </p>
            </div>
          </div>

          {onNavigate && (
            <div className="hidden md:flex items-center gap-1.5 text-xs font-cairo font-bold">
              <button
                type="button"
                onClick={() => onNavigate('zakat_mawarith')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                الزكاة والمواريث
              </button>
              <button
                type="button"
                onClick={() => onNavigate('ruqyah_medicine')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                الرقية والطب النبوي
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-5 space-y-6">
        {/* التبويبات الثلاثة */}
        <div className="grid grid-cols-3 gap-2.5 bg-[#FFFFFF] p-2 rounded-2xl border border-[#E6E6F0] shadow-2xs">
          <button
            type="button"
            onClick={() => setActiveTab('counter')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'counter'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            عداد الطواف والسعي (٧ أشواط)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('manasik')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'manasik'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            مناسك العمرة والحج خطوة بخطوة
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('miqats')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeTab === 'miqats'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            المواقيت ومحظورات الإحرام
          </button>
        </div>

        {/* ═════════════════════════════════════════════════════════════════
            ١. عداد أشواط الطواف والسعي التفاعلي (٧ أشواط)
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'counter' && (
          <div className="space-y-5">
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 sm:p-6 shadow-xs space-y-5">
              {/* التبديل بين الطواف والسعي */}
              <div className="flex items-center justify-between flex-wrap gap-3 border-b border-[#F7F7FC] pb-4">
                <div className="flex items-center gap-2 bg-[#F7F7FC] p-1 rounded-2xl border border-[#E6E6F0]">
                  <button
                    type="button"
                    onClick={() => setCounterMode('tawaf')}
                    className={`px-4 py-2 rounded-xl font-cairo font-bold text-xs cursor-pointer ${
                      counterMode === 'tawaf'
                        ? 'bg-[#5B5FEF] text-white'
                        : 'text-[#25263A]'
                    }`}
                  >
                    عداد الطواف بالكعبة (٧ أشواط)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCounterMode('saee')}
                    className={`px-4 py-2 rounded-xl font-cairo font-bold text-xs cursor-pointer ${
                      counterMode === 'saee'
                        ? 'bg-[#5B5FEF] text-white'
                        : 'text-[#25263A]'
                    }`}
                  >
                    عداد السعي بين الصفا والمروة (٧ أشواط)
                  </button>
                </div>

                <button
                  type="button"
                  onClick={resetCounter}
                  className="px-3.5 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4 text-[#5B5FEF]" />
                  <span>تصفير الأشواط</span>
                </button>
              </div>

              {/* شريط الأشواط السبعة */}
              <div className="grid grid-cols-7 gap-2">
                {[1, 2, 3, 4, 5, 6, 7].map((r) => {
                  const isDone = r < currentRound;
                  const isCurrent = r === currentRound;
                  return (
                    <div
                      key={r}
                      className={`py-3 rounded-2xl border text-center font-cairo font-bold transition-all ${
                        isDone
                          ? 'bg-[#5B5FEF] text-white border-[#4CAF82]'
                          : isCurrent
                          ? 'bg-[#25263A] text-[#E8B84A] border-[#5B5FEF] ring-2 ring-[#5B5FEF]/40'
                          : 'bg-[#F7F7FC] text-[#77798C] border-[#E6E6F0]'
                      }`}
                    >
                      <div className="text-xs">شوط</div>
                      <div className="font-mono text-lg">{r}</div>
                    </div>
                  );
                })}
              </div>

              {/* تفاصيل الشوط الحالي والأدعية النبوية */}
              {!isCompletedAllRounds ? (
                <div className="bg-[#F7F7FC] rounded-3xl p-5 border-2 border-[#E6E6F0] text-center space-y-4">
                  <div className="space-y-1">
                    <span className="text-xs font-cairo font-bold text-[#4145C7]">
                      {counterMode === 'tawaf'
                        ? `الشوط ${tawafRound} من ٧ — يبدأ وينتهي عند الحجر الأسود`
                        : saeeDirectionText}
                    </span>
                    <h2 className="font-cairo font-bold text-2xl text-[#25263A]">
                      {counterMode === 'tawaf'
                        ? `أنت الآن في الشوط رقم (${tawafRound}) من الطواف`
                        : `أنت الآن في الشوط رقم (${saeeRound}) من السعي`}
                    </h2>
                    {counterMode === 'tawaf' && tawafRound <= 3 && (
                      <p className="text-xs font-bold text-[#4CAF82]">
                        سنة للرجال في هذا الشوط (١-٣): الرَّمَل (إسراع المشي مع مقاربة الخطى) والاضطباع في طواف القدوم/العمرة.
                      </p>
                    )}
                  </div>

                  {/* الذكر المأثور في هذا الموضع */}
                  <div className="bg-[#FFFFFF] rounded-2xl p-4 border border-[#E6E6F0] space-y-2">
                    <span className="text-xs font-cairo font-bold text-[#4145C7] block">
                      {counterMode === 'tawaf'
                        ? 'الذكر المأثور عند محاذاة الحجر الأسود وبين الركن اليماني والحجر الأسود:'
                        : 'الذكر المأثور عند الصعود على الصفا والمروة:'}
                    </span>
                    <p className="font-amiri text-xl text-[#25263A] leading-loose">
                      {counterMode === 'tawaf'
                        ? '«بِسْمِ اللَّهِ وَاللَّهُ أَكْبَرُ» ... ﴿ رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ ﴾'
                        : '﴿ إِنَّ الصَّفَا وَالْمَرْوَةَ مِن شَعَائِرِ اللَّهِ ﴾ ... «لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ»'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={advanceRound}
                    className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-[#25263A] font-cairo font-bold text-sm shadow-sm hover:brightness-105 cursor-pointer"
                  >
                    أتممت الشوط {currentRound} — الانتقال للشوط التالي ←
                  </button>
                </div>
              ) : (
                <div className="bg-[#4CAF82]/12 rounded-3xl p-6 border-2 border-[#4CAF82]/40 text-center space-y-3">
                  <CheckCircle2 className="w-12 h-12 text-[#4CAF82] mx-auto" />
                  <h3 className="font-cairo font-bold text-xl text-[#4145C7]">
                    تقبّل الله طاعتك! أتممت الأشواط السبعة كاملة
                  </h3>
                  <p className="text-xs sm:text-sm text-[#25263A]">
                    {counterMode === 'tawaf'
                      ? 'يُسنّ لك الآن صلاة ركعتين خلف مقام إبراهيم عليه السلام قارئاً سورة الكافرون وسورة الإخلاص، ثم الشرب من ماء زمزم.'
                      : 'انتهى سعيك عند جبل المروة، وبذلك يشرع لك الحلق أو التقصير للتحلل من الإحرام.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            ٢. مناسك العمرة والحج خطوة بخطوة مع قائمة الإنجاز
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'manasik' && (
          <div className="space-y-4">
            {MANASIK_STEPS.map((step) => {
              const isDone = completedSteps.includes(step.id);
              return (
                <div
                  key={step.id}
                  className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-xs font-cairo font-bold text-[#4145C7]">
                        {step.dayBadge} · الحكم الشرعي: {step.ruling}
                      </span>
                      <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A] mt-0.5">
                        {step.title}
                      </h3>
                    </div>

                    <button
                      type="button"
                      onClick={() => toggleStepDone(step.id)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-cairo font-bold border cursor-pointer shrink-0 ${
                        isDone
                          ? 'bg-[#5B5FEF] text-white border-[#4CAF82]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                      }`}
                    >
                      {isDone ? 'تم الأداء ✓' : 'تحديد كمكتمل'}
                    </button>
                  </div>

                  <p className="text-xs sm:text-sm text-[#25263A] leading-relaxed">
                    {step.description}
                  </p>

                  <div className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#E6E6F0]">
                    <span className="text-xs font-bold text-[#4145C7] block mb-1">
                      الذكر والدعاء الثابت ({step.duaaSource}):
                    </span>
                    <p className="font-amiri text-lg text-[#25263A] leading-relaxed">
                      {step.authenticDuaa}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            ٣. المواقيت المكانية ومحظورات الإحرام
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'miqats' && (
          <div className="space-y-5">
            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-4">
              <h2 className="font-cairo font-bold text-base text-[#25263A] flex items-center gap-2 border-b border-[#F7F7FC] pb-3">
                <MapPin className="w-5 h-5 text-[#5B5FEF]" />
                <span>المواقيت المكانية الخمسة التي وقّتها رسول الله ﷺ</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {MIQATS_LIST.map((m) => (
                  <div
                    key={m.name}
                    className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="font-cairo font-bold text-sm text-[#25263A]">
                        {m.name}
                      </h3>
                      <span className="text-xs font-bold text-[#4145C7]">{m.distance}</span>
                    </div>
                    <p className="text-xs text-[#77798C]">{m.forPeople}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-3">
              <h2 className="font-cairo font-bold text-base text-[#D95C6A] flex items-center gap-2 border-b border-[#F7F7FC] pb-3">
                <ShieldAlert className="w-5 h-5 text-[#D95C6A]" />
                <span>محظورات الإحرام التسعة الواجب اجتنابها</span>
              </h2>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-[#25263A]">
                <li className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
                  ١. إزالة الشعر من الرأس أو البدن بحلق أو غيره.
                </li>
                <li className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
                  ٢. تقليم الأظافر من اليدين أو القدمين.
                </li>
                <li className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
                  ٣. استعمال الطيب والعطور في البدن أو ثياب الإحرام بعد عقد النية.
                </li>
                <li className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
                  ٤. لبس المخيط المفصل على قدر الأعضاء وتغطية الرأس للرجال.
                </li>
                <li className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
                  ٥. انتقاب المرأة ولبسها القفازين (وتستر وجهها عن الأجانب بغير النقاب).
                </li>
                <li className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
                  ٦. عقد النكاح أو الخطبة أو الجماع ومقدماته، وقتل صيد البر.
                </li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
