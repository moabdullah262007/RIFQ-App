import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowRight,
  Volume2,
  VolumeX,
  RotateCcw,
  CheckCircle2,
  Search,
  Copy,
  Check,
  HeartPulse,
  ShieldCheck,
} from 'lucide-react';
import { soundManager } from '../../utils/audio';
import { ScreenType } from '../../types';
import { RuqyahMedicineSectionSvg } from '../Home/RifqSectionIcons';

interface RuqyahMedicineViewProps {
  onBack: () => void;
  onNavigate?: (screen: ScreenType) => void;
}

interface RuqyahItem {
  id: string;
  category: 'quran' | 'sunnah';
  title: string;
  text: string;
  targetCount: number;
  source: string;
  virtue: string;
  surahNum?: number;
  ayahNum?: number;
}

const RUQYAH_ITEMS: RuqyahItem[] = [
  {
    id: 'ruq_fatihah',
    category: 'quran',
    title: 'سورة الفاتحة (الكافية الشافية)',
    text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ * الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ * الرَّحْمَٰنِ الرَّحِيمِ * مَالِكِ يَوْمِ الدِّينِ * إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ * اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ * صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ',
    targetCount: 7,
    source: 'سورة الفاتحة: ١-٧ (صحيح البخاري)',
    virtue: 'قال النبي ﷺ لمن رقى بها اللديغ فبرأ: «وَمَا يُدْرِيكَ أَنَّهَا رُقْيَةٌ؟»',
    surahNum: 1,
    ayahNum: 1,
  },
  {
    id: 'ruq_kursi',
    category: 'quran',
    title: 'آية الكرسي (أعظم آية في كتاب الله)',
    text: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِندَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
    targetCount: 1,
    source: 'سورة البقرة: ٢٥٥ (صحيح البخاري)',
    virtue: 'من قرأها لم يزل عليه من الله حافظ ولا يقربه شيطان حتى يصبح.',
    surahNum: 2,
    ayahNum: 255,
  },
  {
    id: 'ruq_baqarah_end',
    category: 'quran',
    title: 'خواتيم سورة البقرة',
    text: 'آمَنَ الرَّسُولُ بِمَا أُنزِلَ إِلَيْهِ مِن رَّبِّهِ وَالْمُؤْمِنُونَ ۚ كُلٌّ آمَنَ بِاللَّهِ وَمَلَائِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ لَا نُفَرِّقُ بَيْنَ أَحَدٍ مِّن رُّسُلِهِ ۚ وَقَالُوا سَمِعْنَا وَأَطَعْنَا ۖ غُفْرَانَكَ رَبَّنَا وَإِلَيْكَ الْمَصِيرُ * لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا...',
    targetCount: 1,
    source: 'سورة البقرة: ٢٨٥-٢٨٦ (متفق عليه)',
    virtue: '«الآيَتَانِ مِنْ آخِرِ سُورَةِ الْبَقَرَةِ، مَنْ قَرَأَهُمَا فِي لَيْلَةٍ كَفَتَاهُ»',
    surahNum: 2,
    ayahNum: 285,
  },
  {
    id: 'ruq_muawwidhat',
    category: 'quran',
    title: 'سورة الإخلاص والمعوذتين (ثلاث مرات)',
    text: 'قُلْ هُوَ اللَّهُ أَحَدٌ ... * قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ... * قُلْ أَعُوذُ بِرَبِّ النَّاسِ ...',
    targetCount: 3,
    source: 'سور الإخلاص والفلق والناس (صحيح البخاري)',
    virtue: 'كان رسول الله ﷺ إذا اشتكى يقرأ على نفسه بالمعوذات وينفث، وما تعوّذ متعوذ بمثلهما.',
    surahNum: 113,
    ayahNum: 1,
  },
  {
    id: 'ruq_sunnah_1',
    category: 'sunnah',
    title: 'رقية النبي ﷺ للمريض',
    text: '«أَذْهِبِ الْبَاسَ رَبَّ النَّاسِ، اشْفِ وَأَنْتَ الشَّافِي، لَا شِفَاءَ إِلَّا شِفَاؤُكَ، شِفَاءً لَا يُغَادِرُ سَقَمًا»',
    targetCount: 3,
    source: 'متفق عليه (البخاري ومسلم)',
    virtue: 'كان رسول الله ﷺ يعوّذ بعض أهله يمسح بيده اليمنى ويقولها.',
  },
  {
    id: 'ruq_sunnah_2',
    category: 'sunnah',
    title: 'رقية جبريل عليه السلام للنبي ﷺ',
    text: '«بِاسْمِ اللَّهِ أَرْقِيكَ، مِنْ كُلِّ شَيْءٍ يُؤْذِيكَ، مِنْ شَرِّ كُلِّ نَفْسٍ أَوْ عَيْنِ حَاسِدٍ، اللَّهُ يَشْفِيكَ، بِاسْمِ اللَّهِ أَرْقِيكَ»',
    targetCount: 3,
    source: 'صحيح مسلم',
    virtue: 'رقية جامعة من العين والحسد وسائر الأوجاع.',
  },
  {
    id: 'ruq_sunnah_3',
    category: 'sunnah',
    title: 'رقية موضع الألم في الجسد (سبع مرات)',
    text: 'ضع يدك على الذي تألّم من جسدك وقل: «بِاسْمِ اللَّهِ» (ثلاثاً)، وقل سبع مرات: «أَعُوذُ بِاللَّهِ وَقُدْرَتِهِ مِنْ شَرِّ مَا أَجِدُ وَأُحَاذِرُ»',
    targetCount: 7,
    source: 'صحيح مسلم (عن عثمان بن أبي العاص رضي الله عنه)',
    virtue: 'قال عثمان رضي الله عنه: ففعلتُ ذلك فأذهب الله ما كان بي.',
  },
  {
    id: 'ruq_sunnah_4',
    category: 'sunnah',
    title: 'تعويذة الحسن والحسين رضي الله عنهما',
    text: '«أُعِيذُكُمَا بِكَلِمَاتِ اللَّهِ التَّامَّةِ، مِنْ كُلِّ شَيْطَانٍ وَهَامَّةٍ، وَمِنْ كُلِّ عَيْنٍ لَامَّةٍ»',
    targetCount: 3,
    source: 'صحيح البخاري',
    virtue: 'كان إبراهيم عليه السلام يعوّذ بها إسماعيل وإسحاق، والنبي ﷺ يعوّذ بها الحسن والحسين.',
  },
];

interface PropheticMedicineItem {
  id: string;
  name: string;
  subtitle: string;
  hadith: string;
  source: string;
  benefitsAndUsage: string;
}

const PROPHETIC_MEDICINE_LIST: PropheticMedicineItem[] = [
  {
    id: 'honey',
    name: 'العسل الطبيعي',
    subtitle: '﴿ فِيهِ شِفَاءٌ لِّلنَّاسِ ﴾',
    hadith:
      'قال النبي ﷺ: «الشِّفَاءُ فِي ثَلَاثَةٍ: فِي شَرْطَةِ مِحْجَمٍ، أَوْ شَرْبَةِ عَسَلٍ، أَوْ كَيَّةٍ بِنَارٍ، وَأَنْهَى أُمَّتِي عَنِ الْكَيِّ»',
    source: 'صحيح البخاري',
    benefitsAndUsage:
      'جعله الله شفاءً للناس في القرآن والسنة؛ يُشرب ممزوجاً بالماء الفاتر على الريق لتقوية المناعة وجلاء المعدة واستشفاء الجوف.',
  },
  {
    id: 'black_seed',
    name: 'الحبّة السوداء (حبّة البركة)',
    subtitle: 'شفاء من كل داء إلا السام',
    hadith:
      'قال رسول الله ﷺ: «إِنَّ هَذِهِ الْحَبَّةَ السَّوْدَاءَ شِفَاءٌ مِنْ كُلِّ دَاءٍ، إِلَّا مِنَ السَّامِ» قلت: وما السام؟ قال: «الْمَوْتُ»',
    source: 'متفق عليه (البخاري ومسلم)',
    benefitsAndUsage:
      'تُؤخذ سبع حباتٍ منها مضغاً أو مطحونةً في حينها مع ملعقة عسل، أو يُنتفع بزيتها شرباً ودهناً.',
  },
  {
    id: 'zamzam',
    name: 'ماء زمزم المبارك',
    subtitle: 'طعامُ طُعمٍ وشفاءُ سُقمٍ',
    hadith:
      'قال رسول الله ﷺ: «مَاءُ زَمْزَمَ لِمَا شُرِبَ لَهُ» وقال ﷺ: «إِنَّهَا مُبَارَكَةٌ، إِنَّهَا طَعَامُ طُعْمٍ»',
    source: 'صحيح مسلم وسنن ابن ماجه (صحيح)',
    benefitsAndUsage:
      'يُشرب بنية الشفاء والعلم النافع والفرج مع التضلع منه واستقبال القبلة والدعاء عند شربه.',
  },
  {
    id: 'ajwa',
    name: 'تمر عجوة العالية (المدينة المنورة)',
    subtitle: 'وقاية من السمّ والسحر',
    hadith:
      'قال رسول الله ﷺ: «مَنْ تَصَبَّحَ كُلَّ يَوْمٍ سَبْعَ تَمَرَاتٍ عَجْوَةً، لَمْ يَضُرَّهُ فِي ذَلِكَ الْيَوْمِ سُمٌّ وَلَا سِحْرٌ»',
    source: 'متفق عليه',
    benefitsAndUsage:
      'التصبّح بسبع تمرات على الريق صباحاً، وفيها غذاء كامل للبدن وتحصين بإذن الله.',
  },
  {
    id: 'talbinah',
    name: 'التَّلْبِينَة النبوية (حساء الشعير بالعسل واللبن)',
    subtitle: 'مَجَمَّةٌ لفؤاد المريض وتذهب ببعض الحزن',
    hadith:
      'قال رسول الله ﷺ: «التَّلْبِينَةُ مَجَمَّةٌ لِفُؤَادِ الْمَرِيضِ، تَذْهَبُ بِبَعْضِ الْحُزْنِ»',
    source: 'متفق عليه',
    benefitsAndUsage:
      'تُصنع من دقيق الشعير بنخالته يُطبخ مع الماء واللبن ويُحلى بالعسل؛ تريح القلب وتقوي المعدة وتخفف الحزن والهم.',
  },
  {
    id: 'hijamah',
    name: 'الحِجَامَة النبوية',
    subtitle: 'إن أمثل ما تداويتم به الحجامة',
    hadith:
      'قال رسول الله ﷺ: «إِنَّ أَمْثَلَ مَا تَدَاوَيْتُمْ بِهِ الْحِجَامَةُ وَالْقُسْطُ الْبَحْرِيُّ»',
    source: 'صحيح البخاري ومسلم',
    benefitsAndUsage:
      'استفراغ الدم الفاسد وتنشيط الدورة الدموية، ويُستحب تحري أيام ١٧ و١٩ و٢١ من الشهر القمري عند الحاجة.',
  },
  {
    id: 'olive_oil',
    name: 'زيت الزيتون (الشجرة المباركة)',
    subtitle: 'كلوا الزيت وادهنوا به',
    hadith:
      'قال رسول الله ﷺ: «كُلُوا الزَّيْتَ وَادَّهِنُوا بِهِ، فَإِنَّهُ مِنْ شَجَرَةٍ مُبَارَكَةٍ»',
    source: 'جامع الترمذي وسنن ابن ماجه (صححه الألباني)',
    benefitsAndUsage:
      'الانتفاع به غذاءً ودهناً للبشرة والمفاصل، ويمكن القراءة فيه بالرقية الشرعية والادهان به.',
  },
];

export const RuqyahMedicineView: React.FC<RuqyahMedicineViewProps> = ({
  onBack,
  onNavigate,
}) => {
  const [activeTab, setActiveTab] = useState<'ruqyah' | 'medicine'>('ruqyah');
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const incrementCount = (item: RuqyahItem) => {
    const curr = counts[item.id] || 0;
    if (curr < item.targetCount) {
      soundManager.triggerHaptic(30);
      setCounts({ ...counts, [item.id]: curr + 1 });
    }
  };

  const resetCount = (id: string) => {
    setCounts({ ...counts, [id]: 0 });
  };

  const playRuqyahAudio = (item: RuqyahItem) => {
    if (!item.surahNum || !item.ayahNum) return;
    if (playingId === item.id && audioRef.current) {
      audioRef.current.pause();
      setPlayingId(null);
      return;
    }
    if (audioRef.current) {
      audioRef.current.pause();
    }

    const sStr = String(item.surahNum).padStart(3, '0');
    const aStr = String(item.ayahNum).padStart(3, '0');
    const url = `https://everyayah.com/data/Alafasy_128kbps/${sStr}${aStr}.mp3`;
    const audio = new Audio(url);
    audioRef.current = audio;
    setPlayingId(item.id);
    audio.onended = () => setPlayingId(null);
    audio.onerror = () => setPlayingId(null);
    audio.play().catch(() => setPlayingId(null));
  };

  const filteredMedicine = PROPHETIC_MEDICINE_LIST.filter((m) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.trim();
    return (
      m.name.includes(q) ||
      m.hadith.includes(q) ||
      m.benefitsAndUsage.includes(q)
    );
  });

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-24 select-none" dir="rtl">
      {/* الشريط العلوي */}
      <div className="bg-[#FFFFFF] border-b border-[#E6E6F0] px-4 py-3.5 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="p-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] border border-[#E6E6F0] transition-colors cursor-pointer"
              aria-label="رجوع"
            >
              <ArrowRight className="w-5 h-5 text-[#5B5FEF]" />
            </button>
            <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 shadow-2xs">
              <RuqyahMedicineSectionSvg size={28} />
            </div>
            <div>
              <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A]">
                الرقية الشرعية والطب النبوي
              </h1>
              <p className="text-xs text-[#77798C]">
                آيات وأدعية الرقية الثابتة من القرآن والسنة وموسوعة الاستشفاء النبوي
              </p>
            </div>
          </div>

          {onNavigate && (
            <div className="hidden md:flex items-center gap-1.5 text-xs font-cairo font-bold">
              <button
                type="button"
                onClick={() => onNavigate('zakat_mawarith')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                الزكاة والمواريث
              </button>
              <button
                type="button"
                onClick={() => onNavigate('hajj_umrah')}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] cursor-pointer"
              >
                المطوّف الذكي
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 pt-5 space-y-6">
        {/* التبويبات */}
        <div className="grid grid-cols-2 gap-2.5 bg-[#FFFFFF] p-2 rounded-2xl border border-[#E6E6F0] shadow-2xs">
          <button
            type="button"
            onClick={() => setActiveTab('ruqyah')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'ruqyah'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>الرقية الشرعية الكاملة (قراءة واستماع)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('medicine')}
            className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs sm:text-sm transition-all cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'medicine'
                ? 'bg-[#25263A] text-[#E8B84A]'
                : 'text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            <HeartPulse className="w-4 h-4" />
            <span>موسوعة الطب النبوي والاستشفاء</span>
          </button>
        </div>

        {/* ═════════════════════════════════════════════════════════════════
            ١. الرقية الشرعية من القرآن والسنة الصحيحة
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'ruqyah' && (
          <div className="space-y-4">
            {RUQYAH_ITEMS.map((item) => {
              const done = counts[item.id] || 0;
              const isFinished = done >= item.targetCount;
              const isPlaying = playingId === item.id;

              return (
                <div
                  key={item.id}
                  className={`bg-[#FFFFFF] rounded-3xl border p-5 shadow-xs space-y-4 transition-all ${
                    isFinished ? 'border-[#4CAF82]' : 'border-[#E6E6F0]'
                  }`}
                >
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <span className="text-xs font-cairo font-bold text-[#4145C7]">
                        {item.category === 'quran' ? 'الرقية بالقرآن الكريم' : 'الرقية بالسنة النبوية الصحيحة'} ·{' '}
                        {item.source}
                      </span>
                      <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A] mt-0.5">
                        {item.title}
                      </h3>
                    </div>

                    <div className="flex items-center gap-2">
                      {item.surahNum && (
                        <button
                          type="button"
                          onClick={() => playRuqyahAudio(item)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-cairo font-bold flex items-center gap-1.5 cursor-pointer ${
                            isPlaying
                              ? 'bg-[#5B5FEF] text-white'
                              : 'bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0]'
                          }`}
                        >
                          {isPlaying ? (
                            <>
                              <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                              <span>إيقاف</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
                              <span>استماع</span>
                            </>
                          )}
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(`${item.title}\n${item.text}\n[${item.source}]`);
                          setCopiedId(item.id);
                          setTimeout(() => setCopiedId(null), 2000);
                        }}
                        className="p-2 rounded-xl bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] cursor-pointer"
                        title="نسخ"
                      >
                        {copiedId === item.id ? (
                          <Check className="w-4 h-4 text-[#4CAF82]" />
                        ) : (
                          <Copy className="w-4 h-4 text-[#5B5FEF]" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* نص الرقية */}
                  <div
                    onClick={() => incrementCount(item)}
                    className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] cursor-pointer hover:border-[#5B5FEF] transition-colors"
                  >
                    <p className="font-amiri text-xl sm:text-2xl text-[#25263A] leading-loose text-center">
                      {item.text}
                    </p>
                  </div>

                  {/* الفضل وعداد التكرار */}
                  <div className="flex items-center justify-between flex-wrap gap-3 pt-1">
                    <p className="text-xs text-[#77798C] flex-1">{item.virtue}</p>

                    <div className="flex items-center gap-2">
                      {done > 0 && (
                        <button
                          type="button"
                          onClick={() => resetCount(item.id)}
                          className="p-2 rounded-xl bg-[#F7F7FC] text-[#77798C] hover:text-[#25263A] cursor-pointer"
                          title="إعادة العداد"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => incrementCount(item)}
                        className={`px-5 py-2 rounded-xl font-cairo font-bold text-xs flex items-center gap-2 cursor-pointer transition-all ${
                          isFinished
                            ? 'bg-[#5B5FEF] text-white'
                            : 'bg-[#5B5FEF] text-white hover:bg-[#4145C7]'
                        }`}
                      >
                        {isFinished ? (
                          <>
                            <CheckCircle2 className="w-4 h-4" />
                            <span>أتممت ({done}/{item.targetCount})</span>
                          </>
                        ) : (
                          <span>
                            تكرار القراءة: {done} / {item.targetCount}
                          </span>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* ═════════════════════════════════════════════════════════════════
            ٢. موسوعة الطب النبوي والاستشفاء بالدليل الصحيح
        ═════════════════════════════════════════════════════════════════ */}
        {activeTab === 'medicine' && (
          <div className="space-y-4">
            <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-3.5">
              <div className="relative">
                <Search className="w-4 h-4 text-[#5B5FEF] absolute right-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث في الطب النبوي (العسل، الحبة السوداء، زمزم، الحجامة، التلبينة...)"
                  className="w-full bg-[#F7F7FC] pr-10 pl-4 py-2.5 rounded-xl border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-none"
                />
              </div>
            </div>

            {filteredMedicine.map((med) => (
              <div
                key={med.id}
                className="bg-[#FFFFFF] rounded-3xl border border-[#E6E6F0] p-5 shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h3 className="font-cairo font-bold text-base sm:text-lg text-[#25263A]">
                    {med.name}
                  </h3>
                  <span className="text-xs font-cairo font-bold text-[#4145C7]">
                    {med.subtitle} · المصدر: {med.source}
                  </span>
                </div>

                <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0]">
                  <p className="font-amiri text-lg sm:text-xl text-[#25263A] leading-relaxed">
                    {med.hadith}
                  </p>
                </div>

                <div className="bg-[#5B5FEF]/8 rounded-2xl p-3.5 border border-[#5B5FEF]/25 text-xs">
                  <span className="font-cairo font-bold text-[#4145C7] block mb-1">
                    هدي الاستعمال والانتفاع:
                  </span>
                  <p className="text-[#25263A] leading-relaxed">{med.benefitsAndUsage}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
