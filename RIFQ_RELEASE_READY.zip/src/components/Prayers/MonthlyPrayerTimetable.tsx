import React, { useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronRight,
  ChevronLeft,
  Copy,
  Check,
  Printer,
  Share2,
  Clock,
  Sparkles,
  MapPin,
  Search
} from 'lucide-react';
import { CityLocation, PrayerSettings } from '../../types';
import { calculateMonthPrayerTimes, formatPrayerTime } from '../../utils/prayerCalculator';
import { triggerHaptic } from '../../utils/prayerAudio';

interface MonthlyPrayerTimetableProps {
  currentCity: CityLocation;
  settings: PrayerSettings;
}

const MONTH_NAMES_AR = [
  'يناير (كانون الثاني)',
  'فبراير (شباط)',
  'مارس (آذار)',
  'أبريل (نيسان)',
  'مايو (أيار)',
  'يونيو (حزيران)',
  'يوليو (تموز)',
  'أغسطس (آب)',
  'سبتمبر (أيلول)',
  'أكتوبر (تشرين الأول)',
  'نوفمبر (تشرين الثاني)',
  'ديسمبر (كانون الأول)'
];

export const MonthlyPrayerTimetable: React.FC<MonthlyPrayerTimetableProps> = ({
  currentCity,
  settings
}) => {
  const today = new Date();
  const [selectedYear, setSelectedYear] = useState<number>(today.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(today.getMonth());
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedDay, setCopiedDay] = useState<number | null>(null);

  // Month navigation
  const handlePrevMonth = () => {
    triggerHaptic(20);
    if (selectedMonth === 0) {
      setSelectedMonth(11);
      setSelectedYear((y) => y - 1);
    } else {
      setSelectedMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    triggerHaptic(20);
    if (selectedMonth === 11) {
      setSelectedMonth(0);
      setSelectedYear((y) => y + 1);
    } else {
      setSelectedMonth((m) => m + 1);
    }
  };

  const handleResetToCurrentMonth = () => {
    triggerHaptic(25);
    setSelectedYear(today.getFullYear());
    setSelectedMonth(today.getMonth());
  };

  // Generate prayer rows for selected month
  const monthData = useMemo(() => {
    return calculateMonthPrayerTimes(
      currentCity.latitude,
      currentCity.longitude,
      selectedYear,
      selectedMonth,
      settings
    );
  }, [currentCity, selectedYear, selectedMonth, settings]);

  // Filtered rows
  const filteredRows = useMemo(() => {
    if (!searchQuery.trim()) return monthData;
    const q = searchQuery.trim().toLowerCase();
    return monthData.filter(
      (r) =>
        r.dayNum.toString().includes(q) ||
        r.dayName.toLowerCase().includes(q) ||
        r.hijriFormatted.toLowerCase().includes(q)
    );
  }, [monthData, searchQuery]);

  // Copy today's or any day's times
  const handleCopyDayTimes = (row: (typeof monthData)[0]) => {
    triggerHaptic(30);
    const text = `🕋 مواقيت الصلاة في ${currentCity.nameAr} - ${row.dayName} (${row.hijriFormatted} هـ / ${row.gregorianFormatted} م):
• الإمساك / السحور: ${formatPrayerTime(row.suhur, settings.timeFormat)}
• الفجر: ${formatPrayerTime(row.fajr, settings.timeFormat)}
• الشروق: ${formatPrayerTime(row.sunrise, settings.timeFormat)}
• الظهر: ${formatPrayerTime(row.dhuhr, settings.timeFormat)}
• العصر: ${formatPrayerTime(row.asr, settings.timeFormat)}
• المغرب: ${formatPrayerTime(row.maghrib, settings.timeFormat)}
• العشاء: ${formatPrayerTime(row.isha, settings.timeFormat)}

تطبيق رِفْق | RIFQ للقرآن والعبادات`;

    navigator.clipboard?.writeText(text);
    setCopiedDay(row.dayNum);
    setTimeout(() => setCopiedDay(null), 2500);
  };

  const handlePrint = () => {
    triggerHaptic(25);
    window.print();
  };

  return (
    <div className="bg-white rounded-3xl p-4 sm:p-6 border border-[#E6E6F0] shadow-sm space-y-4">
      {/* Top Bar: Title, City, Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E6E6F0] pb-4">
        <div>
          <h2 className="text-base sm:text-lg font-black text-[#25263A] flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-[#5B5FEF]" />
            <span>جدول مواقيت الصلاة الشهري والإمساكية</span>
          </h2>
          <p className="text-xs text-[#77798C] mt-0.5">
            {currentCity.nameAr}، {currentCity.countryAr} • طريقة الحساب:{' '}
            {settings.method === 'Egyptian' ? 'الهيئة المصرية العامة للمساحة' : settings.method}
          </p>
        </div>

        {/* Month Selector Controls */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handlePrevMonth}
            className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors cursor-pointer"
            title="الشهر السابق"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <span className="font-bold text-xs sm:text-sm text-[#25263A] px-2 min-w-[130px] text-center">
            {MONTH_NAMES_AR[selectedMonth]} {selectedYear}
          </span>

          <button
            onClick={handleNextMonth}
            className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors cursor-pointer"
            title="الشهر القادم"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {(selectedMonth !== today.getMonth() || selectedYear !== today.getFullYear()) && (
            <button
              onClick={handleResetToCurrentMonth}
              className="text-[11px] px-2.5 py-1.5 rounded-xl bg-[#5B5FEF] text-white font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
            >
              الشهر الحالي
            </button>
          )}

          <button
            onClick={handlePrint}
            className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors cursor-pointer hidden sm:flex items-center gap-1 text-xs"
            title="طباعة الجدول"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="flex items-center justify-between gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث باليوم أو التاريخ الهجري..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-9 pl-3 py-1.5 text-xs bg-gray-50 border border-gray-200 rounded-xl focus:outline-hidden focus:border-[#5B5FEF] focus:ring-1 focus:ring-[#5B5FEF]"
          />
        </div>

        <div className="text-[11px] text-[#77798C] font-medium">
          إجمالي الأيام: {filteredRows.length} يوم
        </div>
      </div>

      {/* Responsive Table */}
      <div className="overflow-x-auto rounded-2xl border border-gray-200 shadow-2xs">
        <table className="w-full text-right text-xs">
          <thead>
            <tr className="bg-[#EEEEFF] text-[#25263A] font-black border-b border-gray-200">
              <th className="p-3 text-center">اليوم</th>
              <th className="p-3">التاريخ الميلادي</th>
              <th className="p-3">التاريخ الهجري</th>
              <th className="p-3 text-amber-700 bg-amber-50/70 text-center">الإمساك</th>
              <th className="p-3 text-center">الفجر</th>
              <th className="p-3 text-center text-gray-500">الشروق</th>
              <th className="p-3 text-center">الظهر</th>
              <th className="p-3 text-center">العصر</th>
              <th className="p-3 text-center text-rose-700 bg-rose-50/70">المغرب</th>
              <th className="p-3 text-center">العشاء</th>
              <th className="p-3 text-center">مشاركة</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredRows.map((row) => {
              const isToday = row.isToday;
              const isFriday = row.dayName.includes('الجمعة');

              return (
                <tr
                  key={row.dayNum}
                  className={`transition-colors ${
                    isToday
                      ? 'bg-amber-100/60 font-bold border-l-4 border-amber-500'
                      : isFriday
                      ? 'bg-emerald-50/40 hover:bg-emerald-50/70'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <td className="p-2.5 text-center">
                    <span
                      className={`inline-flex items-center justify-center w-7 h-7 rounded-xl font-bold text-xs ${
                        isToday
                          ? 'bg-amber-500 text-white shadow-2xs'
                          : isFriday
                          ? 'bg-[#5B5FEF] text-white'
                          : 'text-[#25263A]'
                      }`}
                    >
                      {row.dayNum}
                    </span>
                  </td>
                  <td className="p-2.5 whitespace-nowrap">
                    <span className="font-bold text-[#25263A] block">{row.dayName}</span>
                    <span className="text-[10px] text-gray-400">{row.gregorianFormatted}</span>
                  </td>
                  <td className="p-2.5 whitespace-nowrap text-[#4145C7] font-medium">
                    {row.hijriFormatted}
                  </td>
                  <td className="p-2.5 text-center font-mono text-amber-800 bg-amber-50/40 font-semibold">
                    {formatPrayerTime(row.suhur, settings.timeFormat)}
                  </td>
                  <td className="p-2.5 text-center font-mono font-bold text-[#25263A]">
                    {formatPrayerTime(row.fajr, settings.timeFormat)}
                  </td>
                  <td className="p-2.5 text-center font-mono text-gray-500">
                    {formatPrayerTime(row.sunrise, settings.timeFormat)}
                  </td>
                  <td className="p-2.5 text-center font-mono font-bold text-[#25263A]">
                    {formatPrayerTime(row.dhuhr, settings.timeFormat)}
                  </td>
                  <td className="p-2.5 text-center font-mono font-bold text-[#25263A]">
                    {formatPrayerTime(row.asr, settings.timeFormat)}
                  </td>
                  <td className="p-2.5 text-center font-mono font-black text-rose-800 bg-rose-50/40">
                    {formatPrayerTime(row.maghrib, settings.timeFormat)}
                  </td>
                  <td className="p-2.5 text-center font-mono font-bold text-[#25263A]">
                    {formatPrayerTime(row.isha, settings.timeFormat)}
                  </td>
                  <td className="p-2.5 text-center">
                    <button
                      onClick={() => handleCopyDayTimes(row)}
                      className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                        copiedDay === row.dayNum
                          ? 'bg-emerald-500 text-white'
                          : 'text-gray-400 hover:text-[#5B5FEF] hover:bg-gray-100'
                      }`}
                      title="نسخ مواقيت هذا اليوم"
                    >
                      {copiedDay === row.dayNum ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Footer Notes */}
      <div className="bg-[#EEEEFF]/60 rounded-2xl p-3 border border-[#E6E6F0] text-xs text-[#77798C] flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-[#4145C7]" />
          <span>
            وقت الإمساك مبني على الاحتياط الشرعي (قبل أذان الفجر بـ ٢٠ دقيقة للسحور والاستعداد).
          </span>
        </div>
        <div className="text-[11px] text-gray-500">
          دقة فلكية معتمدة وفق خوارزميات الجمعية الفلكية الإسلامية
        </div>
      </div>
    </div>
  );
};
