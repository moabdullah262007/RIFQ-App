import React, { useState } from 'react';
import { BookOpen, ChevronDown, ChevronUp, Sparkles, CheckCircle2, ShieldAlert, Award } from 'lucide-react';
import { triggerHaptic } from '../../utils/prayerAudio';

interface FiqhTopic {
  id: string;
  category: string;
  title: string;
  summary: string;
  points: string[];
  evidenceText?: string;
  sourceText?: string;
}

const FIQH_TOPICS: FiqhTopic[] = [
  {
    id: 'prohibited-times',
    category: 'أوقات الصلاة',
    title: 'أوقات النهي عن الصلاة (أوقات الكراهة)',
    summary: 'الأوقات التي نهى النبي ﷺ عن ابتداء صلاة التطوع فيها، وتُقسم إلى أوقات مضيقة وأوقات موسعة.',
    points: [
      'الوقت الأول: من بعد صلاة الفجر حتى تطلع الشمس وترتفع قيد رمح (نحو ١٥ إلى ٢٠ دقيقة بعد الشروق).',
      'الوقت الثاني: عند استواء الشمس في كبد السماء قبيل الزوال حتى تؤذن صلاة الظهر (نحو ١٠ إلى ١٥ دقيقة).',
      'الوقت الثالث: من بعد صلاة العصر حتى تغرب الشمس تماماً.',
      'ما يجوز في أوقات النهي: قضاء الفرائض الفائتة، والصلوات ذوات الأسباب عند جمهور المحققين (مثل: تحية المسجد، ركعتي الطواف، صلاة الجنازة، سنة الوضوء، وركعتي كسوف الشمس).'
    ],
    evidenceText: '«ثلاث ساعات كان رسول الله ﷺ ينهانا أن نصلي فيهن أو أن نقبر فيهن موتانا: حين تطلع الشمس بازغة حتى ترتفع، وحين يقوم قائم الظهيرة حتى تميل الشمس، وحين تضيّف الشمس للغروب حتى تغرب».',
    sourceText: 'صحيح مسلم (832)'
  },
  {
    id: 'sunan-rawatib',
    category: 'السنن والنوافل',
    title: 'سنن الرواتب المؤكدة (١٢ ركعة يومياً)',
    summary: 'الصلوات المسنونة التابعة للفرائض التي واظب عليها النبي ﷺ ورتّب عليها أعظم الثواب ببناء بيت في الجنة.',
    points: [
      'ركعتان قبل صلاة الفجر: وهي آكد السنن الرواتب («ركعتا الفجر خير من الدنيا وما فيها»).',
      'أربع ركعات قبل صلاة الظهر: تُصلى ركعتين ثم ركعتين بتسليمتين.',
      'ركعتان بعد صلاة الظهر: سنة مؤكدة، ويستحب زيادة ركعتين لتصير أربعاً («من حافظ على أربع قبل الظهر وأربع بعدها حرمه الله على النار»).',
      'ركعتان بعد صلاة المغرب: بعد الفريضة مباشرة.',
      'ركعتان بعد صلاة العشاء: قبل صلاة الوتر.',
      'ملاحظة: صلاة العصر ليس لها سنة راتبة مؤكدة، لكن يُستحب صلاة أربع ركعات قبلها لقوله ﷺ: «رحم الله امرأ صلى قبل العصر أربعاً».'
    ],
    evidenceText: '«ما من عبد مسلم يصلي لله كل يوم ثنتي عشرة ركعة تطوعاً غير فريضة، إلا بنى الله له بيتاً في الجنة».',
    sourceText: 'صحيح مسلم (728)'
  },
  {
    id: 'duha-prayer',
    category: 'السنن والنوافل',
    title: 'صلاة الضحى (صلاة الأوابين)',
    summary: 'سنة نبوية مؤكدة تجزئ عن صدقة كل مفصل من مفاصل الإنسان البالغة ٣٦٠ مفصلاً.',
    points: [
      'وقتها: يبدأ بعد شروق الشمس بـ ١٥ إلى ٢٠ دقيقة، ويمتد حتى قبل أذان الظهر بنحو ١٠ دقائق.',
      'أفضل وقتها: عند اشتداد حر الشمس في منتصف الضحى لقوله ﷺ: «صلاة الأوابين حين ترمض الفصال».',
      'عدد ركعاتها: أقلها ركعتان، وأوسطها أربع أو ست، وأكثرها ثماني ركعات أو ما تيسر للمسلم مثنى مثنى.',
      'فضلها: وصية الحبيب المصطفى ﷺ لأبي هريرة وأبي الدرداء رضي الله عنهما ألا يدعوا ركعتي الضحى حتى الممات.'
    ],
    evidenceText: '«يصبح على كل سلامى من أحدكم صدقة... ويجزئ من ذلك ركعتان يركعهما من الضحى».',
    sourceText: 'صحيح مسلم (720)'
  },
  {
    id: 'witr-qiyam',
    category: 'قيام الليل',
    title: 'صلاة الوتر وقيام الليل',
    summary: 'خاتمة صلاة الليل التي حث عليها الشارع الحكيم وجعلها خيراً من حمر النعم.',
    points: [
      'وقتها: من بعد صلاة العشاء إلى طلوع الفجر الصادق، وأفضله في الثلث الأخير من الليل لمن وثق بالاستيقاظ.',
      'عدد ركعاتها: أقل الوتر ركعة واحدة، وأدنى الكمال ثلاث ركعات (ركعتان شفع ثم ركعة وتر)، ويجوز ٥ و ٧ و ٩ و ١١ ركعة.',
      'القراءة المستحبة: في الركعة الأولى بسورة الأعلى، والثانية بالكافرون، والثالثة بالإخلاص والمعوذتين.',
      'دعاء القنوت: مستحب في الركعة الأخيرة بعد الركوع أو قبله.'
    ],
    evidenceText: '«اجعلوا آخر صلاتكم بالليل وتراً»، و«إن الله وتر يحب الوتر، فأوتروا يا أهل القرآن».',
    sourceText: 'صحيح البخاري ومسلم وأصحاب السنن'
  },
  {
    id: 'sujood-sahw',
    category: 'أحكام الصلاة',
    title: 'سجود السهو (متى يكون قبل السلام ومتى بعده؟)',
    summary: 'سجدتان يسجدهما المصلي جبراً للخلل الحاصل في صلاته من زيادة أو نقصان أو شك.',
    points: [
      'سجود السهو قبل السلام (موضعان):',
      '١. إذا كان السهو عن نقص (كنسيان التشهد الأول أو التسبيح في الركوع/السجود).',
      '٢. إذا شك في عدد الركعات ولم يترجح لديه شيء، فإنه يبني على اليقين (وهو الأقل) ثم يسجد قبل السلام.',
      'سجود السهو بعد السلام (موضعان):',
      '١. إذا كان السهو عن زيادة (كركوع زائد أو سجدة زائدة أو ركعة خامسة سهواً).',
      '٢. إذا شك وتحرى وترجح عنده أحد الأمرين، فإنه يتم صلاته ويسلم ثم يسجد للسهو ويسلم ثانية.'
    ],
    evidenceText: 'أحاديث ذي اليدين وابن مسعود وأبي سعيد الخدري في الصحيحين.',
    sourceText: 'صحيح البخاري ومسلم'
  },
  {
    id: 'traveler-prayer',
    category: 'الرخص الشرعية',
    title: 'صلاة المسافر (الجمع والقصر)',
    summary: 'تيسير وتخفيف شرعي للمسافر برخصة القصر والجمع في الصلوات الرباعية.',
    points: [
      'القصر: صلاة الرباعية (الظهر، العصر، العشاء) ركعتين فقط بدلاً من أربع ركعات. أما الفجر والمغرب فلا قصر فيهما.',
      'الجمع: يجوز للمسافر الجمع بين الظهر والعصر (تقديماً في وقت الظهر أو تأخيراً في وقت العصر)، والجمع بين المغرب والعشاء (تقديماً أو تأخيراً).',
      'شروط القصر: مجاوزة عمران بلد الإقامة، ومسافة السفر المعتبرة (نحو ٨٠ كم فأكثر عند جمهور الفقهاء).',
      'إذا صلى المسافر خلف إمام مقيم: لزمه الإتمام أربع ركعات متابعة لإمامه.'
    ],
    evidenceText: '﴿وَإِذَا ضَرَبْتُمْ فِي الْأَرْضِ فَلَيْسَ عَلَيْكُمْ جُنَاحٌ أَن تَقْصُرُوا مِنَ الصَّلَاةِ﴾، و«صدقة تصدق الله بها عليكم فاقبلوا صدقته».',
    sourceText: 'سورة النساء وصحيح مسلم'
  },
  {
    id: 'janazah-prayer',
    category: 'صلاة الجنازة',
    title: 'صفة صلاة الجنازة وأدعيتها',
    summary: 'فرض كفاية يُؤدى قياماً بلا ركوع ولا سجود، فيها أربع تكبيرات.',
    points: [
      'التكبيرة الأولى: الاستعاذة والبسملة وقراءة سورة الفاتحة سراً.',
      'التكبيرة الثانية: الصلاة الإبراهيمية على النبي ﷺ.',
      'التكبيرة الثالثة: الدعاء الخالص للميت: «اللهم اغفر له وارحمه، وعافه واعف عنه، وأكرم نزله، ووسع مدخله، واغسله بالماء والثلج والبرد...».',
      'التكبيرة الرابعة: السكوت قليلاً أو الدعاء لجميع المسلمين، ثم تسليمة واحدة عن اليمين أو تسليمتين.'
    ],
    evidenceText: '«من شهد الجنازة حتى يصلى عليها فله قيراط، ومن شهدها حتى تدفن فله قيراطان»، قيل: وما القيراطان؟ قال: «مثل الجبلين العظيمين».',
    sourceText: 'صحيح البخاري (1325) ومسلم (945)'
  }
];

export const PrayerFiqhGuide: React.FC = () => {
  const [expandedId, setExpandedId] = useState<string | null>('prohibited-times');

  const toggleTopic = (id: string) => {
    triggerHaptic(20);
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white rounded-3xl p-4 sm:p-5 border border-amber-400/30 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-xl">
            📖
          </div>
          <div>
            <h2 className="font-tajawal font-black text-base sm:text-lg text-amber-200">
              دليل فقه وسنن وأحكام الصلاة
            </h2>
            <p className="text-xs text-emerald-200">
              أحكام معتمدة موثقة بالأدلة الصحيحة: أوقات النهي، الرواتب، سجود السهو، والمسافر
            </p>
          </div>
        </div>
      </div>

      {/* Accordion List */}
      <div className="space-y-2.5">
        {FIQH_TOPICS.map((topic) => {
          const isExpanded = expandedId === topic.id;

          return (
            <div
              key={topic.id}
              className={`rounded-2xl border transition-all overflow-hidden ${
                isExpanded
                  ? 'bg-white border-amber-400 shadow-md ring-1 ring-amber-300/40'
                  : 'bg-white border-[#E6E6F0] hover:border-gray-300 hover:shadow-xs'
              }`}
            >
              <button
                type="button"
                onClick={() => toggleTopic(topic.id)}
                className="w-full p-4 flex items-center justify-between text-right cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold shrink-0 transition-colors ${
                      isExpanded
                        ? 'bg-[#5B5FEF] text-amber-300'
                        : 'bg-gray-100 text-gray-700'
                    }`}
                  >
                    <BookOpen className="w-4 h-4" />
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900">
                        {topic.category}
                      </span>
                      <h3 className="font-black text-sm text-[#25263A]">{topic.title}</h3>
                    </div>
                    <p className="text-xs text-[#77798C] mt-0.5 line-clamp-1">{topic.summary}</p>
                  </div>
                </div>

                <div className="text-gray-400 shrink-0 mr-2">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </button>

              {isExpanded && (
                <div className="p-4 pt-0 border-t border-gray-100 space-y-3 text-xs animate-fade-in">
                  <p className="text-[#25263A] font-medium leading-relaxed bg-[#EEEEFF]/60 p-3 rounded-xl">
                    {topic.summary}
                  </p>

                  <div className="space-y-1.5 pt-1">
                    <span className="font-bold text-[#4CAF82] block text-xs">الأحكام والضوابط الشرعية:</span>
                    <ul className="space-y-1.5">
                      {topic.points.map((pt, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-gray-700 leading-relaxed">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#5B5FEF] shrink-0 mt-0.5" />
                          <span>{pt}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {topic.evidenceText && (
                    <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-3 text-gray-800">
                      <span className="font-bold text-amber-900 block text-[11px] mb-1">
                        الدليل من السنة النبوية المطهرة:
                      </span>
                      <p className="font-serif text-[13px] leading-relaxed text-amber-950">
                        {topic.evidenceText}
                      </p>
                      {topic.sourceText && (
                        <span className="text-[10px] text-amber-700 block mt-1 font-medium">
                          المصدر: {topic.sourceText}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
