import React, { useState } from 'react';
import { X, Check, RotateCcw, Volume2, Sparkles, BookOpen, Compass, CheckCircle2 } from 'lucide-react';
import { POST_PRAYER_ATHKAR } from '../../data/prayersData';
import { triggerHaptic, playIslamicChime } from '../../utils/prayerAudio';

// Vector Rosary Bead Ring Icon
const RosaryVectorIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <circle cx="12" cy="7" r="1.5" fill="currentColor" />
    <circle cx="16" cy="9" r="1.5" fill="currentColor" />
    <circle cx="18" cy="13" r="1.5" fill="currentColor" />
    <circle cx="16" cy="17" r="1.5" fill="currentColor" />
    <circle cx="12" cy="19" r="1.5" fill="currentColor" />
    <circle cx="8" cy="17" r="1.5" fill="currentColor" />
    <circle cx="6" cy="13" r="1.5" fill="currentColor" />
    <circle cx="8" cy="9" r="1.5" fill="currentColor" />
    <path d="M12 19v3m-1.5 0h3" />
  </svg>
);

interface PostPrayerAthkarModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PostPrayerAthkarModal: React.FC<PostPrayerAthkarModalProps> = ({
  isOpen,
  onClose
}) => {
  const [completedCounts, setCompletedCounts] = useState<Record<string, number>>({});

  if (!isOpen) return null;

  const handleIncrement = (id: string, maxRepeat: number) => {
    setCompletedCounts((prev) => {
      const current = prev[id] || 0;
      if (current < maxRepeat) {
        const next = current + 1;
        triggerHaptic(next === maxRepeat ? [50, 50, 100] : 30);
        if (next === maxRepeat) {
          playIslamicChime();
        }
        return { ...prev, [id]: next };
      }
      return prev;
    });
  };

  const handleReset = () => {
    setCompletedCounts({});
  };

  const totalDhikrs = POST_PRAYER_ATHKAR.length;
  const completedDhikrs = POST_PRAYER_ATHKAR.filter(
    (item) => (completedCounts[item.id] || 0) >= item.repeat
  ).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E6F0] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-200">
              <RosaryVectorIcon className="w-6 h-6 text-amber-200" />
            </div>
            <div>
              <h3 className="font-black text-lg text-amber-200">أذكار ما بعد الصلاة المكتوبة</h3>
              <p className="text-xs text-emerald-200">الأدعية والأذكار المأثورة عن رسول الله ﷺ بعد السلام</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleReset}
              title="إعادة التعيين"
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="bg-[#EEEEFF] px-4 py-2.5 border-b border-[#E6E6F0]/60 flex items-center justify-between text-xs">
          <span className="font-bold text-[#4145C7]">
            الإنجاز: {completedDhikrs} من {totalDhikrs} أذكار
          </span>
          <div className="w-36 h-2.5 bg-amber-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#5B5FEF] transition-all duration-300 rounded-full"
              style={{ width: `${(completedDhikrs / totalDhikrs) * 100}%` }}
            />
          </div>
        </div>

        {/* Athkar List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {POST_PRAYER_ATHKAR.map((item, idx) => {
            const count = completedCounts[item.id] || 0;
            const isDone = count >= item.repeat;

            return (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition-all ${
                  isDone
                    ? 'bg-[#4CAF82]/12/70 border-[#4CAF82]/40 shadow-xs'
                    : 'bg-white border-[#E6E6F0]/80 hover:border-amber-300 hover:shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#EEEEFF] text-[#4145C7] text-xs font-bold flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h4 className="font-bold text-sm text-[#25263A]">{item.title}</h4>
                  </div>
                  <span className="text-xs text-[#77798C] font-medium">{item.source}</span>
                </div>

                <p className="text-base text-[#25263A] font-serif leading-relaxed mb-3 pr-2 border-r-2 border-amber-300">
                  {item.text}
                </p>

                {item.virtue && (
                  <div className="bg-[#EEEEFF]/60 rounded-xl p-2.5 mb-3 text-xs text-[#4145C7] flex items-start gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-[#4145C7] shrink-0 mt-0.5" />
                    <span>{item.virtue}</span>
                  </div>
                )}

                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs text-[#77798C]">
                    التكرار: {count} / {item.repeat}
                  </span>

                  <button
                    onClick={() => handleIncrement(item.id, item.repeat)}
                    disabled={isDone}
                    className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                      isDone
                        ? 'bg-[#5B5FEF] text-white'
                        : 'bg-gradient-to-r from-[#5B5FEF] to-emerald-700 text-amber-200 hover:brightness-110 active:scale-95 shadow-xs'
                    }`}
                  >
                    {isDone ? (
                      <>
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>تم الذكر بنجاح</span>
                      </>
                    ) : (
                      <>
                        <span>ذكرتُ</span>
                        <span>({count + 1})</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-50 border-t border-[#E6E6F0] text-center text-xs text-[#77798C]">
          «من قال حين يسلم من الصلاة كُفّر عنه ما تقدم من ذنبه»
        </div>
      </div>
    </div>
  );
};
