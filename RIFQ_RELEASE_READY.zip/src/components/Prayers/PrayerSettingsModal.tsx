import React, { useState, useEffect } from 'react';
import {
  X,
  Settings,
  Volume2,
  VolumeX,
  Square,
  Play,
  Sliders,
  Bell,
  Check,
  Clock,
  Globe,
  BellRing,
  Copy,
  Smartphone,
  Sparkles,
  AlertCircle,
  Download,
  Trash2,
  Loader2,
  CheckCircle2,
  Radio,
  Vibrate
} from 'lucide-react';
import {
  CalculationMethodKey,
  MadhabKey,
  PrayerKey,
  PrayerSettings,
  PrayerSoundMode,
  PrayerAlertDetail
} from '../../types';
import { MUADHIN_OPTIONS, MuadhinOption, PRAYERS_METADATA } from '../../data/prayersData';
import {
  playAdhanAudio,
  playPrayerSound,
  stopAdhanAudio,
  isAdhanPlaying,
  triggerHaptic,
  setAdhanVolume,
  getAdhanVolume,
  toggleAdhanMute,
  subscribeToAdhanPlayer
} from '../../utils/prayerAudio';
import {
  isMuadhinCached,
  downloadMuadhinAudio,
  deleteMuadhinAudio,
  getCachedMuadhinIds,
  subscribeToCacheChanges
} from '../../utils/adhanCacheManager';
import {
  getNotificationPermission,
  requestNotificationPermission,
  triggerPrayerAdhanNotification
} from '../../utils/notifications';
import {
  FLUTTER_PUBSPEC_SNIPPET,
  FLUTTER_NOTIFICATION_SERVICE_CODE,
  FLUTTER_ANDROID_SETUP_GUIDE
} from '../../data/flutterNotificationCode';

interface PrayerSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: PrayerSettings;
  onUpdateSettings: (newSettings: PrayerSettings) => void;
}

const CALCULATION_METHODS: { id: CalculationMethodKey; nameAr: string; desc: string }[] = [
  {
    id: 'Egyptian',
    nameAr: 'هيئة المساحة المصرية (المعتمدة في مصر)',
    desc: 'زاوية الفجر 19.5° وزاوية العشاء 17.5° - الأنسب لمصر وأفريقيا وبلاد الشام'
  },
  {
    id: 'UmmAlQura',
    nameAr: 'تقويم أم القرى (مكة المكرمة)',
    desc: 'زاوية الفجر 18.5° والعشاء 90 دقيقة بعد المغرب (120 دقيقة في رمضان) - السعودية والخليج'
  },
  {
    id: 'MuslimWorldLeague',
    nameAr: 'رابطة العالم الإسلامي (MWL)',
    desc: 'زاوية الفجر 18° وزاوية العشاء 17° - منتشرة عالمياً في أوروبا والدول العربية'
  },
  {
    id: 'Karachi',
    nameAr: 'جامعة العلوم الإسلامية بكراتشي',
    desc: 'زاوية الفجر 18° وزاوية العشاء 18° - باكستان والهند وأفغانستان'
  },
  {
    id: 'NorthAmerica',
    nameAr: 'الجمعية الإسلامية لأمريكا الشمالية (ISNA)',
    desc: 'زاوية الفجر 15° وزاوية العشاء 15° - الولايات المتحدة وكندا'
  },
  {
    id: 'Dubai',
    nameAr: 'دائرة الشؤون الإسلامية بدبي (الإمارات)',
    desc: 'معتمدة في دولة الإمارات العربية المتحدة'
  },
  {
    id: 'Qatar',
    nameAr: 'وزارة الأوقاف والشؤون الإسلامية بقطر',
    desc: 'معتمدة في دولة قطر'
  },
  {
    id: 'Kuwait',
    nameAr: 'وزارة الأوقاف والشؤون الإسلامية بالكويت',
    desc: 'معتمدة في دولة الكويت'
  },
  {
    id: 'Turkey',
    nameAr: 'رئاسة الشؤون الدينية التركية (ديانت)',
    desc: 'معتمدة في تركيا والمجتمعات الإسلامية الأوروبية'
  }
];

export const PrayerSettingsModal: React.FC<PrayerSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings
}) => {
  const [activeTab, setActiveTab] = useState<'calc' | 'notifications' | 'audio' | 'flutter' | 'adjust'>('notifications');
  const [playingMuadhinId, setPlayingMuadhinId] = useState<string | null>(null);
  const [permissionState, setPermissionState] = useState<string>('default');
  const [testingPrayerKey, setTestingPrayerKey] = useState<PrayerKey | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Offline caching & Audio states
  const [cachedIds, setCachedIds] = useState<string[]>([]);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [downloadProgress, setDownloadProgress] = useState<number>(0);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [audioVolume, setAudioVolume] = useState<number>(() => getAdhanVolume());
  const [isAudioMutedState, setIsAudioMutedState] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setPermissionState(getNotificationPermission());
      getCachedMuadhinIds().then(setCachedIds);
    }
  }, [isOpen]);

  useEffect(() => {
    const unsubCache = subscribeToCacheChanges(() => {
      getCachedMuadhinIds().then(setCachedIds);
    });
    const unsubPlayer = subscribeToAdhanPlayer((state) => {
      if (!state.isPlaying && !state.isPaused) {
        setPlayingMuadhinId(null);
        setTestingPrayerKey(null);
      }
      setIsAudioMutedState(state.isMuted);
      setAudioVolume(state.volume);
    });
    return () => {
      unsubCache();
      unsubPlayer();
    };
  }, []);

  if (!isOpen) return null;

  const handleRequestPermission = async () => {
    const res = await requestNotificationPermission();
    setPermissionState(res);
  };

  const handleCopyCode = (text: string, key: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2500);
    } catch {
      // Ignored
    }
  };

  const handleTestAudio = (muadhin: MuadhinOption) => {
    if (playingMuadhinId === muadhin.id) {
      stopAdhanAudio();
      setPlayingMuadhinId(null);
    } else {
      triggerHaptic(30);
      setPlayingMuadhinId(muadhin.id);
      playAdhanAudio(
        muadhin,
        () => setPlayingMuadhinId(null),
        () => setPlayingMuadhinId(null),
        muadhin.nameAr,
        'adhan'
      );
    }
  };

  const handleDownloadMuadhin = async (muadhin: MuadhinOption, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(25);
    setDownloadingId(muadhin.id);
    setDownloadProgress(5);
    setDownloadError(null);

    try {
      await downloadMuadhinAudio(muadhin, (percent) => {
        setDownloadProgress(percent);
      });
      const updated = await getCachedMuadhinIds();
      setCachedIds(updated);
      setDownloadingId(null);
      setDownloadProgress(0);
      triggerHaptic([30, 50, 80]);
    } catch (err: unknown) {
      setDownloadingId(null);
      setDownloadProgress(0);
      setDownloadError(err instanceof Error ? err.message : 'تعذر تحميل الملف الصوتي.');
    }
  };

  const handleDeleteCached = async (muadhinId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerHaptic(20);
    await deleteMuadhinAudio(muadhinId);
    const updated = await getCachedMuadhinIds();
    setCachedIds(updated);
  };

  const handleVolumeChange = (newVal: number) => {
    setAudioVolume(newVal);
    setAdhanVolume(newVal);
  };

  const handleToggleMute = () => {
    triggerHaptic(15);
    const muted = toggleAdhanMute();
    setIsAudioMutedState(muted);
  };

  const handleTestPrayerAlert = (pkey: PrayerKey) => {
    const alertDetail = settings.prayerAlerts?.[pkey] || { mode: 'adhan' };
    const muadhinId = alertDetail.customMuadhinId || settings.selectedMuadhin;
    const muadhin = MUADHIN_OPTIONS.find((m) => m.id === muadhinId) || MUADHIN_OPTIONS[0];

    if (testingPrayerKey === pkey) {
      stopAdhanAudio();
      setTestingPrayerKey(null);
    } else {
      triggerHaptic(40);
      setTestingPrayerKey(pkey);
      triggerPrayerAdhanNotification({
        prayerNameAr: PRAYERS_METADATA[pkey].nameAr,
        cityName: 'القاهرة',
        timeFormatted: 'الآن',
        mode: alertDetail.mode,
        audioUrl: muadhin.audioUrl,
        muadhinName: muadhin.nameAr,
        isPreReminder: false
      });
    }
  };

  const handleClose = () => {
    stopAdhanAudio();
    setPlayingMuadhinId(null);
    setTestingPrayerKey(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl border border-[#E6E6F0] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-l from-[#5B5FEF] via-[#4145C7] to-[#4145C7] text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-xl">
              ⚙️
            </div>
            <div>
              <h3 className="font-black text-lg text-amber-200">إعدادات مواقيت الصلاة</h3>
              <p className="text-xs text-emerald-200">طرق الحساب الفلكية، المذهب الفقهي، أصوات الأذان والتنبيهات</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Setting Tabs */}
        <div className="flex items-center gap-1.5 p-3 bg-gray-50 border-b border-[#E6E6F0] text-xs overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('notifications')}
            className={`px-3 py-2 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'notifications'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-[#E6E6F0]'
            }`}
          >
            <BellRing className="w-3.5 h-3.5" />
            <span>تنبيهات وأصوات الأذان لكل صلاة</span>
          </button>
          <button
            onClick={() => setActiveTab('audio')}
            className={`px-3 py-2 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'audio'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-[#E6E6F0]'
            }`}
          >
            المؤذن الموحد
          </button>
          <button
            onClick={() => setActiveTab('calc')}
            className={`px-3 py-2 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'calc'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-[#E6E6F0]'
            }`}
          >
            طريقة الحساب والمذهب
          </button>
          <button
            onClick={() => setActiveTab('flutter')}
            className={`px-3 py-2 rounded-xl font-bold transition-all whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'flutter'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'bg-white text-[#4CAF82] hover:bg-[#4CAF82]/12 border border-[#4CAF82]/40'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-amber-500" />
            <span>كود Flutter (مكتبة الإشعارات)</span>
          </button>
          <button
            onClick={() => setActiveTab('adjust')}
            className={`px-3 py-2 rounded-xl font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'adjust'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'bg-white text-gray-700 hover:bg-gray-100 border border-[#E6E6F0]'
            }`}
          >
            ضبط يدوي (دقائق)
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* TAB 1: CALCULATION & JURISTIC */}
          {activeTab === 'calc' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-2">
                  طريقة الحساب الفلكية:
                </label>
                <div className="space-y-2">
                  {CALCULATION_METHODS.map((m) => {
                    const isSelected = settings.method === m.id;
                    return (
                      <div
                        key={m.id}
                        onClick={() => {
                          triggerHaptic(20);
                          onUpdateSettings({ ...settings, method: m.id });
                        }}
                        className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                          isSelected
                            ? 'bg-[#EEEEFF]/90 border-amber-400 shadow-xs'
                            : 'bg-white border-[#E6E6F0] hover:border-amber-300'
                        }`}
                      >
                        <div>
                          <span className="font-bold text-sm text-[#25263A] block">{m.nameAr}</span>
                          <span className="text-xs text-[#77798C] mt-0.5 block">{m.desc}</span>
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-[#5B5FEF] text-white flex items-center justify-center shrink-0 mt-0.5">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Madhab for Asr */}
              <div className="pt-3 border-t border-[#E6E6F0]">
                <label className="block text-xs font-bold text-gray-700 mb-2">
                  مذهب حساب وقت صلاة العصر:
                </label>
                <div className="grid grid-cols-2 gap-2 text-xs font-bold">
                  <button
                    onClick={() => {
                      triggerHaptic(20);
                      onUpdateSettings({ ...settings, madhab: 'shafi' });
                    }}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                      settings.madhab === 'shafi'
                        ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-emerald-950 font-black shadow-xs'
                        : 'bg-white border-[#E6E6F0] text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <span className="block font-bold text-sm">جمهور الفقهاء ⭐</span>
                    <span className="text-[11px] text-[#77798C] font-normal mt-0.5 block">
                      الشافعي، المالكي، الحنبلي (عندما يصير ظل الشيء مثله)
                    </span>
                  </button>

                  <button
                    onClick={() => {
                      triggerHaptic(20);
                      onUpdateSettings({ ...settings, madhab: 'hanafi' });
                    }}
                    className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                      settings.madhab === 'hanafi'
                        ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-emerald-950 font-black shadow-xs'
                        : 'bg-white border-[#E6E6F0] text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <span className="block font-bold text-sm">المذهب الحنفي</span>
                    <span className="text-[11px] text-[#77798C] font-normal mt-0.5 block">
                      الإمام أبو حنيفة (عندما يصير ظل الشيء مثليه)
                    </span>
                  </button>
                </div>
              </div>

              {/* Time Format (12h vs 24h) */}
              <div className="pt-3 border-t border-[#E6E6F0] flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-[#25263A] block">صيغة عرض الوقت:</span>
                  <span className="text-xs text-[#77798C]">اختر بين نظام 12 ساعة (ص/م) أو نظام 24 ساعة</span>
                </div>
                <div className="flex bg-gray-100 p-1 rounded-xl text-xs font-bold">
                  <button
                    onClick={() => onUpdateSettings({ ...settings, timeFormat: '12h' })}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      settings.timeFormat === '12h' ? 'bg-white text-[#4CAF82] shadow-xs' : 'text-[#77798C]'
                    }`}
                  >
                    12 ساعة (ص/م)
                  </button>
                  <button
                    onClick={() => onUpdateSettings({ ...settings, timeFormat: '24h' })}
                    className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                      settings.timeFormat === '24h' ? 'bg-white text-[#4CAF82] shadow-xs' : 'text-[#77798C]'
                    }`}
                  >
                    24 ساعة
                  </button>
                </div>
              </div>

              {/* Show Sunnah Option */}
              <div className="pt-3 border-t border-[#E6E6F0] flex items-center justify-between">
                <div>
                  <span className="text-sm font-bold text-[#25263A] block">عرض السنن والرواتب:</span>
                  <span className="text-xs text-[#77798C]">إظهار تفاصيل الركعات المسنونة قبل وبعد كل صلاة</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showSunnah}
                  onChange={(e) => onUpdateSettings({ ...settings, showSunnah: e.target.checked })}
                  className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* TAB 2: AUDIO & MUADHINS */}
          {activeTab === 'audio' && (
            <div className="space-y-4">
              {/* Master Sound & Volume Control */}
              <div className="p-3.5 bg-gradient-to-r from-emerald-50 via-teal-50 to-amber-50 rounded-2xl border border-[#4CAF82]/40/80 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-5 h-5 text-[#4CAF82]" />
                    <div>
                      <span className="text-sm font-black text-emerald-950 block">تشغيل صوت الأذان الحقيقي</span>
                      <span className="text-[11px] text-emerald-850">ملفات MP3 مسجلة بأعلى جودة لأشهر مؤذني العالم الإسلامي</span>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.soundEnabled}
                    onChange={(e) => onUpdateSettings({ ...settings, soundEnabled: e.target.checked })}
                    className="w-5 h-5 accent-emerald-700 rounded cursor-pointer"
                  />
                </div>

                {/* Volume Slider & Mute */}
                {settings.soundEnabled && (
                  <div className="pt-2 border-t border-[#4CAF82]/40/60 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleToggleMute}
                        className="w-8 h-8 rounded-xl bg-white text-[#4CAF82] border border-[#4CAF82]/40 flex items-center justify-center hover:bg-[#4CAF82]/12 transition-colors cursor-pointer"
                        title={isAudioMutedState ? 'إلغاء كتم الصوت' : 'كتم الصوت'}
                      >
                        {isAudioMutedState || audioVolume === 0 ? (
                          <VolumeX className="w-4 h-4 text-rose-600" />
                        ) : (
                          <Volume2 className="w-4 h-4 text-[#4CAF82]" />
                        )}
                      </button>
                      <span className="text-xs font-bold text-gray-700">مستوى الصوت:</span>
                    </div>

                    <div className="flex items-center gap-2 flex-1 max-w-xs">
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={isAudioMutedState ? 0 : audioVolume}
                        onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                        className="w-full h-2 bg-emerald-200 rounded-lg appearance-none cursor-pointer accent-emerald-700"
                      />
                      <span className="text-xs font-mono font-bold text-[#4CAF82] w-10 text-left">
                        {Math.round((isAudioMutedState ? 0 : audioVolume) * 100)}%
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Warning if muted */}
              {(isAudioMutedState || audioVolume === 0) && (
                <div className="p-3 bg-[#EEEEFF] border border-amber-300 rounded-2xl flex items-center justify-between text-xs text-[#4145C7]">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-[#4145C7] shrink-0" />
                    <span>الصوت مكتوم حالياً. لن تسمع صوت الأذان حتى ترفع الصوت.</span>
                  </div>
                  <button
                    onClick={() => {
                      if (isAudioMutedState) toggleAdhanMute();
                      handleVolumeChange(0.9);
                    }}
                    className="font-bold underline text-[#4145C7] hover:text-amber-950 cursor-pointer"
                  >
                    إلغاء الكتم (90%)
                  </button>
                </div>
              )}

              {/* Offline Cache Info Banner */}
              <div className="p-3 bg-emerald-950 text-white rounded-2xl flex items-center justify-between text-xs shadow-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold text-amber-300 block">دعم التشغيل بدون إنترنت (Offline Caching)</span>
                    <span className="text-[11px] text-emerald-200">
                      حمّل صوت مؤذنك المفضل ليعمل الأذان في أي وقت حتى عند انقطاع الشبكة
                    </span>
                  </div>
                </div>
                <span className="text-[11px] bg-[#5B5FEF] px-2.5 py-1 rounded-full text-emerald-100 font-bold shrink-0">
                  {cachedIds.length} مؤذن محمّل
                </span>
              </div>

              {downloadError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{downloadError}</span>
                </div>
              )}

              {/* Muadhins List */}
              <div>
                <label className="block text-xs font-black text-[#25263A] mb-2.5">
                  اختر صوت المؤذن الافتراضي للصلوات ({MUADHIN_OPTIONS.length} أصوات مسجلة):
                </label>

                <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                  {MUADHIN_OPTIONS.map((muadhin) => {
                    const isSelected = settings.selectedMuadhin === muadhin.id;
                    const isPlaying = playingMuadhinId === muadhin.id;
                    const isCached = cachedIds.includes(muadhin.id);
                    const isDownloading = downloadingId === muadhin.id;

                    return (
                      <div
                        key={muadhin.id}
                        onClick={() => {
                          triggerHaptic(20);
                          onUpdateSettings({ ...settings, selectedMuadhin: muadhin.id });
                        }}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-[#4CAF82]/12/90 border-[#4CAF82]/40 ring-2 ring-emerald-500/20 shadow-xs'
                            : 'bg-white border-[#E6E6F0] hover:border-[#4CAF82]/40 hover:bg-[#4CAF82]/12/30'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2.5 mb-2">
                          <div className="flex items-start gap-3">
                            {/* Play / Stop Preview Button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTestAudio(muadhin);
                              }}
                              className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white transition-all shadow-sm shrink-0 cursor-pointer ${
                                isPlaying ? 'bg-rose-600 animate-pulse' : 'bg-[#5B5FEF] hover:bg-[#5B5FEF]'
                              }`}
                              title={isPlaying ? 'إيقاف الاستماع' : 'استماع لصوت الأذان الحقيقي'}
                            >
                              {isPlaying ? <Square className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white ml-0.5" />}
                            </button>

                            <div>
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-black text-sm text-[#25263A]">{muadhin.nameAr}</span>
                                {muadhin.badgeText && (
                                  <span className="text-[10px] bg-[#EEEEFF] text-[#4145C7] border border-amber-300 px-1.5 py-0.2 rounded-md font-bold">
                                    {muadhin.badgeText}
                                  </span>
                                )}
                              </div>
                              <span className="text-[11px] text-[#77798C] block">
                                {muadhin.cityAr} • المدة: {muadhin.durationText}
                              </span>
                              <p className="text-[11px] text-[#77798C] mt-1 line-clamp-1 leading-normal">
                                {muadhin.descriptionAr}
                              </p>
                            </div>
                          </div>

                          {/* Selected Tag */}
                          {isSelected && (
                            <span className="text-[11px] bg-[#5B5FEF] text-white font-black px-2.5 py-0.5 rounded-full shrink-0 shadow-xs">
                              المؤذن المعتمد ✓
                            </span>
                          )}
                        </div>

                        {/* Card bottom: Offline download status & Action buttons */}
                        <div className="pt-2 border-t border-[#E6E6F0] flex items-center justify-between text-xs">
                          <div className="flex items-center gap-1.5">
                            {isCached ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#4CAF82] bg-[#4CAF82]/12 px-2 py-0.5 rounded-lg">
                                <CheckCircle2 className="w-3 h-3 text-[#4CAF82]" />
                                <span>محمّل بدون إنترنت (جاهز للأوفلاين)</span>
                              </span>
                            ) : (
                              <span className="text-[11px] text-gray-400">
                                غير محمّل (يعمل بالإنترنت)
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5">
                            {/* Download / Progress Button */}
                            {isDownloading ? (
                              <div className="flex items-center gap-1.5 px-3 py-1 bg-[#EEEEFF] text-[#4145C7] rounded-xl text-xs font-bold">
                                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#4145C7]" />
                                <span>جاري التحميل ({downloadProgress}%)</span>
                              </div>
                            ) : isCached ? (
                              <button
                                type="button"
                                onClick={(e) => handleDeleteCached(muadhin.id, e)}
                                className="px-2.5 py-1 text-[11px] text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-1 transition-colors cursor-pointer"
                                title="حذف الملف لتوفير المساحة"
                              >
                                <Trash2 className="w-3 h-3" />
                                <span>حذف من الجهاز</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={(e) => handleDownloadMuadhin(muadhin, e)}
                                className="px-2.5 py-1 text-[11px] font-bold text-[#4CAF82] bg-[#4CAF82]/12 hover:bg-emerald-200 border border-[#4CAF82]/40 rounded-xl flex items-center gap-1 transition-colors cursor-pointer shadow-xs"
                                title="تحميل ملف الأذان بصيغة MP3 للتشغيل بدون إنترنت"
                              >
                                <Download className="w-3 h-3 text-[#4CAF82]" />
                                <span>تحميل أوفلاين (MP3)</span>
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB: NOTIFICATIONS & PER-PRAYER ADHAN AUDIO */}
          {activeTab === 'notifications' && (
            <div className="space-y-4">
              {/* Permission Banner */}
              <div className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                permissionState === 'granted'
                  ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-[#4CAF82]'
                  : 'bg-[#EEEEFF] border-[#E6E6F0] text-[#4145C7]'
              }`}>
                <div className="flex items-center gap-2.5">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    permissionState === 'granted' ? 'bg-emerald-200 text-[#4CAF82]' : 'bg-amber-200 text-[#4145C7]'
                  }`}>
                    {permissionState === 'granted' ? <Check className="w-4 h-4" /> : <BellRing className="w-4 h-4 animate-bounce" />}
                  </div>
                  <div>
                    <span className="font-black text-xs block">
                      {permissionState === 'granted' ? 'إشعارات المتصفح مفعلة بنجاح ✅' : 'إذن الإشعارات مطلوب لتنبيه الأذان'}
                    </span>
                    <span className="text-[11px] opacity-80 block">
                      {permissionState === 'granted'
                        ? 'ستصلك تنبيهات الأذان بصوت المؤذن المخصص لكل صلاة في موعدها الدقيق'
                        : 'انقر لتفعيل الصلاحية ليعمل الأذان والتنبيه بدقة في الخلفية'}
                    </span>
                  </div>
                </div>

                {permissionState !== 'granted' && (
                  <button
                    onClick={handleRequestPermission}
                    className="px-3 py-1.5 bg-[#5B5FEF] text-white text-xs font-bold rounded-xl hover:bg-[#5B5FEF] transition-colors shrink-0 shadow-xs cursor-pointer"
                  >
                    تفعيل الإذن 🔔
                  </button>
                )}
              </div>

              {/* Master Sound & Pre-Reminder Controls */}
              <div className="p-3.5 bg-gray-50 border border-[#E6E6F0] rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-[#4145C7]" />
                    <span className="text-xs font-bold text-[#25263A]">تشغيل الصوت والتنبيهات المسموعة:</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.soundEnabled}
                    onChange={(e) => onUpdateSettings({ ...settings, soundEnabled: e.target.checked })}
                    className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
                  />
                </div>

                {/* Pre-Adhan Reminder */}
                <div className="pt-2.5 border-t border-[#E6E6F0]">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-gray-700">
                      تنبيه ما قبل الأذان (للاستعداد والوضوء):
                    </label>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5 text-xs font-bold">
                    {[0, 10, 15, 30].map((mins) => (
                      <button
                        key={mins}
                        onClick={() => onUpdateSettings({ ...settings, preAdhanReminderMinutes: mins })}
                        className={`py-1.5 px-2 rounded-xl border transition-all cursor-pointer ${
                          settings.preAdhanReminderMinutes === mins
                            ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                            : 'bg-white text-gray-700 border-[#E6E6F0] hover:bg-gray-100'
                        }`}
                      >
                        {mins === 0 ? 'بدون تنبيه' : `${mins} دقيقة`}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* PER-PRAYER ALERT CONFIGURATION LIST */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-black text-[#25263A] flex items-center gap-1.5">
                    <span>ضبط تنبيه وصوت الأذان لكل صلاة على حدة:</span>
                  </label>
                  <span className="text-[11px] text-[#77798C]">اختر صوت المؤذن ونوع التنبيه لكل فريضة</span>
                </div>

                <div className="space-y-3">
                  {(['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as PrayerKey[]).map((pkey) => {
                    const isEnabled = settings.notifications[pkey] !== false;
                    const alertDetail: PrayerAlertDetail = settings.prayerAlerts?.[pkey] || {
                      mode: isEnabled ? (pkey === 'sunrise' ? 'chime' : 'adhan') : 'off',
                      customMuadhinId: undefined,
                      preReminder: true
                    };
                    const meta = PRAYERS_METADATA[pkey];
                    const isPlayingTest = testingPrayerKey === pkey;

                    // Current chosen muadhin name
                    const customMuadhin = MUADHIN_OPTIONS.find((m) => m.id === alertDetail.customMuadhinId);
                    const defaultMuadhin = MUADHIN_OPTIONS.find((m) => m.id === settings.selectedMuadhin) || MUADHIN_OPTIONS[0];

                    return (
                      <div
                        key={pkey}
                        className={`p-3.5 bg-white border rounded-2xl transition-all shadow-xs ${
                          isEnabled ? 'border-[#4CAF82]/40 ring-1 ring-emerald-500/10' : 'border-[#E6E6F0] opacity-70 bg-gray-50/50'
                        }`}
                      >
                        {/* Prayer Card Header */}
                        <div className="flex items-center justify-between pb-2 border-b border-[#E6E6F0]">
                          <div className="flex items-center gap-2.5">
                            <span className="text-lg">{meta.icon}</span>
                            <div>
                              <span className="font-black text-sm text-[#25263A] block">{meta.nameAr}</span>
                              <span className="text-[10px] text-[#77798C]">{meta.rakats ? `${meta.rakats} ركعات` : 'وقت الشروق'}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={isEnabled}
                              onChange={(e) => {
                                const checked = e.target.checked;
                                const nextAlerts = {
                                  ...(settings.prayerAlerts || {}),
                                  [pkey]: {
                                    ...alertDetail,
                                    mode: checked ? (alertDetail.mode === 'off' ? 'adhan' : alertDetail.mode) : 'off'
                                  }
                                };
                                onUpdateSettings({
                                  ...settings,
                                  notifications: {
                                    ...settings.notifications,
                                    [pkey]: checked
                                  },
                                  prayerAlerts: nextAlerts
                                });
                              }}
                              className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
                              title="تفعيل أو تعطيل التنبيه"
                            />
                          </div>
                        </div>

                        {isEnabled && (
                          <div className="pt-3 space-y-3">
                            {/* Mode Pills */}
                            <div>
                              <span className="text-[11px] font-bold text-[#77798C] block mb-1.5">نوع التنبيه الصوتي:</span>
                              <div className="grid grid-cols-4 gap-1 text-[11px] font-bold">
                                {[
                                  { mode: 'adhan' as PrayerSoundMode, label: 'أذان كامل 📢' },
                                  { mode: 'takbeer' as PrayerSoundMode, label: 'تكبيرات 🕋' },
                                  { mode: 'chime' as PrayerSoundMode, label: 'نغمة وقار 🔔' },
                                  { mode: 'silent' as PrayerSoundMode, label: 'صامت 🔕' },
                                ].map((item) => {
                                  const isSelected = alertDetail.mode === item.mode;
                                  return (
                                    <button
                                      key={item.mode}
                                      onClick={() => {
                                        onUpdateSettings({
                                          ...settings,
                                          prayerAlerts: {
                                            ...(settings.prayerAlerts || {}),
                                            [pkey]: {
                                              ...alertDetail,
                                              mode: item.mode
                                            }
                                          }
                                        });
                                      }}
                                      className={`py-1.5 px-1 rounded-xl border text-center transition-all cursor-pointer ${
                                        isSelected
                                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                                          : 'bg-gray-50 text-gray-700 border-[#E6E6F0] hover:bg-gray-100'
                                      }`}
                                    >
                                      {item.label}
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                            {/* Custom Muadhin Selector (if adhan or takbeer) */}
                            {(alertDetail.mode === 'adhan' || alertDetail.mode === 'takbeer') && (
                              <div className="bg-[#EEEEFF]/60 p-2.5 rounded-xl border border-[#E6E6F0]/70">
                                <label className="text-[11px] font-bold text-[#4145C7] block mb-1">
                                  صوت المؤذن المخصص لـ {meta.nameAr}:
                                </label>
                                <select
                                  value={alertDetail.customMuadhinId || ''}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    onUpdateSettings({
                                      ...settings,
                                      prayerAlerts: {
                                        ...(settings.prayerAlerts || {}),
                                        [pkey]: {
                                          ...alertDetail,
                                          customMuadhinId: val ? val : undefined
                                        }
                                      }
                                    });
                                  }}
                                  className="w-full text-xs font-bold p-2 bg-white border border-amber-300 rounded-lg text-[#25263A] focus:outline-hidden focus:ring-1 focus:ring-amber-500 cursor-pointer"
                                >
                                  <option value="">استخدام المؤذن العام الافتراضي ({defaultMuadhin.nameAr})</option>
                                  {MUADHIN_OPTIONS.map((m) => (
                                    <option key={m.id} value={m.id}>
                                      {m.nameAr} - {m.cityAr} ({m.durationText})
                                    </option>
                                  ))}
                                </select>
                              </div>
                            )}

                            {/* Test & Pre-Reminder Actions */}
                            <div className="flex items-center justify-between pt-1 text-xs">
                              <label className="flex items-center gap-1.5 text-[#77798C] cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={alertDetail.preReminder !== false}
                                  onChange={(e) => {
                                    onUpdateSettings({
                                      ...settings,
                                      prayerAlerts: {
                                        ...(settings.prayerAlerts || {}),
                                        [pkey]: {
                                          ...alertDetail,
                                          preReminder: e.target.checked
                                        }
                                      }
                                    });
                                  }}
                                  className="w-3.5 h-3.5 accent-emerald-600 rounded"
                                />
                                <span className="text-[11px]">تنبيه مسبق قبل الأذان</span>
                              </label>

                              <button
                                onClick={() => handleTestPrayerAlert(pkey)}
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                                  isPlayingTest
                                    ? 'bg-rose-600 text-white animate-pulse shadow-xs'
                                    : 'bg-[#4CAF82]/12 hover:bg-emerald-200 text-[#4CAF82] border border-[#4CAF82]/40'
                                }`}
                              >
                                {isPlayingTest ? (
                                  <>
                                    <Square className="w-3 h-3 fill-white" />
                                    <span>إيقاف التجربة</span>
                                  </>
                                ) : (
                                  <>
                                    <Play className="w-3 h-3 fill-emerald-800" />
                                    <span>تجربة الأذان والإشعار</span>
                                  </>
                                )}
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB: FLUTTER CODE (flutter_local_notifications) */}
          {activeTab === 'flutter' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-[#4CAF82]/40 rounded-2xl text-emerald-950">
                <div className="flex items-center gap-2 mb-1">
                  <Smartphone className="w-5 h-5 text-[#4CAF82]" />
                  <span className="font-black text-sm">نظام إشعارات الأذان لتطبيق Flutter (Android & iOS)</span>
                </div>
                <p className="text-xs text-[#4CAF82] leading-relaxed">
                  هذا الكود الجاهز مبني بمكتبة <code className="font-mono font-bold bg-white/70 px-1 py-0.5 rounded">flutter_local_notifications</code> مع دعم التنبيهات الدقيقة في موعد الأذان، وتشغيل أصوات الأذان المخصصة من <code className="font-mono text-[#4CAF82]">res/raw</code> لكل صلاة على حدة.
                </p>
              </div>

              {/* 1. pubspec.yaml */}
              <div className="bg-gray-900 text-gray-100 rounded-2xl overflow-hidden border border-gray-700">
                <div className="px-3.5 py-2 bg-gray-800 flex items-center justify-between text-xs">
                  <span className="font-mono text-amber-300 font-bold">1. pubspec.yaml</span>
                  <button
                    onClick={() => handleCopyCode(FLUTTER_PUBSPEC_SNIPPET, 'pubspec')}
                    className="flex items-center gap-1 text-[11px] bg-white/10 hover:bg-white/20 px-2 py-0.5 rounded text-white cursor-pointer"
                  >
                    {copiedKey === 'pubspec' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'pubspec' ? 'تم النسخ' : 'نسخ'}</span>
                  </button>
                </div>
                <pre className="p-3 text-[11px] font-mono overflow-x-auto text-emerald-400 dir-ltr text-left">
                  {FLUTTER_PUBSPEC_SNIPPET}
                </pre>
              </div>

              {/* 2. Dart Service Code */}
              <div className="bg-gray-900 text-gray-100 rounded-2xl overflow-hidden border border-gray-700">
                <div className="px-3.5 py-2 bg-gray-800 flex items-center justify-between text-xs">
                  <span className="font-mono text-amber-300 font-bold">2. prayer_notification_service.dart</span>
                  <button
                    onClick={() => handleCopyCode(FLUTTER_NOTIFICATION_SERVICE_CODE, 'service')}
                    className="flex items-center gap-1 text-[11px] bg-white/10 hover:bg-white/20 px-2 py-0.5 rounded text-white cursor-pointer"
                  >
                    {copiedKey === 'service' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'service' ? 'تم النسخ' : 'نسخ الكود كاملاً'}</span>
                  </button>
                </div>
                <pre className="p-3 text-[10px] font-mono overflow-x-auto max-h-60 text-blue-200 dir-ltr text-left">
                  {FLUTTER_NOTIFICATION_SERVICE_CODE}
                </pre>
              </div>

              {/* 3. AndroidManifest.xml setup */}
              <div className="bg-gray-900 text-gray-100 rounded-2xl overflow-hidden border border-gray-700">
                <div className="px-3.5 py-2 bg-gray-800 flex items-center justify-between text-xs">
                  <span className="font-mono text-amber-300 font-bold">3. AndroidManifest.xml وإعداد أصوات الأذان</span>
                  <button
                    onClick={() => handleCopyCode(FLUTTER_ANDROID_SETUP_GUIDE, 'manifest')}
                    className="flex items-center gap-1 text-[11px] bg-white/10 hover:bg-white/20 px-2 py-0.5 rounded text-white cursor-pointer"
                  >
                    {copiedKey === 'manifest' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === 'manifest' ? 'تم النسخ' : 'نسخ الإعدادات'}</span>
                  </button>
                </div>
                <pre className="p-3 text-[10px] font-mono overflow-x-auto max-h-48 text-amber-200 dir-ltr text-left">
                  {FLUTTER_ANDROID_SETUP_GUIDE}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 4: MANUAL FINE-TUNING */}
          {activeTab === 'adjust' && (
            <div className="space-y-3">
              <p className="text-xs text-[#77798C] leading-relaxed">
                يمكنك إضافة أو خصم دقائق محددة لكل صلاة للتطابق التام مع ساعة المسجد المحلي في حيك:
              </p>

              {(['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'] as PrayerKey[]).map((pkey) => {
                const offset = settings.manualOffsets?.[pkey] || 0;
                const labels: Record<PrayerKey, string> = {
                  fajr: 'الفجر',
                  sunrise: 'الشروق',
                  dhuhr: 'الظهر',
                  asr: 'العصر',
                  maghrib: 'المغرب',
                  isha: 'العشاء'
                };

                return (
                  <div
                    key={pkey}
                    className="p-3 bg-white border border-[#E6E6F0] rounded-2xl flex items-center justify-between"
                  >
                    <span className="font-bold text-sm text-[#25263A]">صلاة {labels[pkey]}</span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          const nextOffset = offset - 1;
                          onUpdateSettings({
                            ...settings,
                            manualOffsets: { ...settings.manualOffsets, [pkey]: nextOffset }
                          });
                        }}
                        className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 text-[#25263A] font-bold flex items-center justify-center cursor-pointer"
                      >
                        -
                      </button>

                      <span className="font-mono text-sm font-bold w-12 text-center text-[#4145C7]">
                        {offset > 0 ? `+${offset}` : offset} د
                      </span>

                      <button
                        onClick={() => {
                          const nextOffset = offset + 1;
                          onUpdateSettings({
                            ...settings,
                            manualOffsets: { ...settings.manualOffsets, [pkey]: nextOffset }
                          });
                        }}
                        className="w-7 h-7 rounded-lg bg-gray-100 hover:bg-gray-200 text-[#25263A] font-bold flex items-center justify-center cursor-pointer"
                      >
                        +
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-50 border-t border-[#E6E6F0] flex justify-end">
          <button
            onClick={handleClose}
            className="px-6 py-2 bg-gradient-to-r from-[#5B5FEF] to-emerald-700 text-white font-black text-xs rounded-xl shadow-xs hover:brightness-110 cursor-pointer"
          >
            حفظ وإغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
