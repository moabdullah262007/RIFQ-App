import React from 'react';
import { Sun, Moon, Clock, AlertTriangle, Sparkles, CheckCircle2 } from 'lucide-react';
import { CalculatedPrayerData } from '../../utils/prayerCalculator';
import { formatPrayerTime } from '../../utils/prayerCalculator';
import { PrayerSettings } from '../../types';

interface CelestialSunArcProps {
  prayerData: CalculatedPrayerData;
  settings: PrayerSettings;
  currentTime: Date;
}

export const CelestialSunArc: React.FC<CelestialSunArcProps> = ({
  prayerData,
  settings,
  currentTime
}) => {
  const {
    times,
    isDaytime,
    daylightProgressPercent,
    duhaStart,
    duhaEnd,
    isDuhaTime,
    isProhibitedPrayerTime,
    prohibitedReason,
    currentPrayer
  } = prayerData;

  // Arc geometry for SVG (half circle / arc from x=30,y=130 through peak x=150,y=25 to x=270,y=130)
  // Progress 0..100 maps angle from 180 deg to 0 deg
  const angleRad = (Math.PI * (100 - daylightProgressPercent)) / 100;
  // Center is (150, 130), Radius is 115
  const cx = 150;
  const cy = 125;
  const r = 110;
  const currentX = cx + r * Math.cos(angleRad);
  const currentY = cy - r * Math.sin(angleRad);

  return (
    <div className="bg-gradient-to-b from-[#1E1B4B]/95 via-[#232055] to-[#161439] text-white rounded-3xl p-4 sm:p-5 border border-amber-400/30 shadow-lg relative overflow-hidden">
      {/* Background stars / ambient glow */}
      <div className="absolute top-2 left-4 text-amber-200/20 text-xs select-none pointer-events-none">✨</div>
      <div className="absolute top-8 right-6 text-amber-200/20 text-xs select-none pointer-events-none">✦</div>
      <div className="absolute -right-12 -bottom-12 w-40 h-40 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header with Title and Current Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center text-amber-300">
            {isDaytime ? <Sun className="w-4 h-4 animate-spin-slow" /> : <Moon className="w-4 h-4" />}
          </div>
          <div>
            <h3 className="font-tajawal font-black text-sm text-amber-200 flex items-center gap-1.5">
              <span>المسار الفلكي للشمس ومراحل النهار</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white font-normal font-sans">
                {isDaytime ? `${daylightProgressPercent}% من النهار` : 'فترة الليل وسكونه'}
              </span>
            </h3>
            <p className="text-[11px] text-indigo-200">
              متابعة دقيقة للشروق، الضحى، الزوال، العصر، والغروب
            </p>
          </div>
        </div>

        {/* Live Status Pill */}
        {isDuhaTime ? (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/50 text-amber-200 text-xs font-bold shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span>وقت صلاة الضحى مستحب الآن ☀️</span>
          </div>
        ) : isProhibitedPrayerTime ? (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-400/50 text-rose-200 text-xs font-bold shadow-xs">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span>وقت نهي عن صلاة النفل ⚠️</span>
          </div>
        ) : (
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
            <span>وقت مباح للصلاة والتنفل</span>
          </div>
        )}
      </div>

      {/* Visual Solar Arc Display */}
      <div className="relative py-2 flex flex-col items-center">
        <svg viewBox="0 0 300 145" className="w-full max-w-md h-36 overflow-visible">
          <defs>
            <linearGradient id="arcGlow" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.4" />
              <stop offset="50%" stopColor="#fbbf24" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#ea580c" stopOpacity="0.4" />
            </linearGradient>
            <linearGradient id="sunGlow" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fde047" />
              <stop offset="100%" stopColor="#f59e0b" />
            </linearGradient>
            <filter id="shadow">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#f59e0b" floodOpacity="0.6" />
            </filter>
          </defs>

          {/* Horizon Line */}
          <line
            x1="20"
            y1={cy}
            x2="280"
            y2={cy}
            stroke="rgba(255,255,255,0.15)"
            strokeWidth="1.5"
            strokeDasharray="4 4"
          />

          {/* Dotted Arch Trail */}
          <path
            d={`M 40 ${cy} A ${r} ${r} 0 0 1 260 ${cy}`}
            fill="none"
            stroke="rgba(255, 255, 255, 0.2)"
            strokeWidth="2.5"
            strokeDasharray="3 3"
          />

          {/* Active Arc Trail up to Sun */}
          {isDaytime && (
            <path
              d={`M 260 ${cy} A ${r} ${r} 0 0 0 ${currentX} ${currentY}`}
              fill="none"
              stroke="url(#arcGlow)"
              strokeWidth="4"
              strokeLinecap="round"
            />
          )}

          {/* Key Milestones on Horizon / Arc */}
          {/* 1. Sunrise (Right side in RTL coordinates view) */}
          <circle cx="260" cy={cy} r="4" fill="#f59e0b" />
          <text x="260" y={cy + 15} fill="#fcd34d" fontSize="8" fontWeight="bold" textAnchor="middle">
            الشروق
          </text>

          {/* 2. Duha Milestone */}
          <circle cx="225" cy={cy - 65} r="3" fill="#fbbf24" />
          <text x="225" y={cy - 72} fill="#fef08a" fontSize="7.5" fontWeight="bold" textAnchor="middle">
            الضحى
          </text>

          {/* 3. Dhuhr Peak / Zenith */}
          <circle cx="150" cy={cy - r} r="4" fill="#38bdf8" />
          <text x="150" y={cy - r - 6} fill="#bae6fd" fontSize="8" fontWeight="bold" textAnchor="middle">
            الزوال (الظهر)
          </text>

          {/* 4. Asr Milestone */}
          <circle cx="75" cy={cy - 65} r="3" fill="#f97316" />
          <text x="75" y={cy - 72} fill="#fed7aa" fontSize="7.5" fontWeight="bold" textAnchor="middle">
            العصر
          </text>

          {/* 5. Maghrib / Sunset */}
          <circle cx="40" cy={cy} r="4" fill="#ef4444" />
          <text x="40" y={cy + 15} fill="#fca5a5" fontSize="8" fontWeight="bold" textAnchor="middle">
            الغروب
          </text>

          {/* Current Sun / Moon Position Marker */}
          {isDaytime ? (
            <g transform={`translate(${currentX}, ${currentY})`} filter="url(#shadow)">
              <circle cx="0" cy="0" r="9" fill="url(#sunGlow)" />
              <circle cx="0" cy="0" r="13" fill="none" stroke="#fef08a" strokeWidth="1.5" opacity="0.7">
                <animate attributeName="r" values="9;14;9" dur="2.5s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.8;0.2;0.8" dur="2.5s" repeatCount="indefinite" />
              </circle>
            </g>
          ) : (
            <g transform={`translate(150, 132)`}>
              <circle cx="0" cy="0" r="7" fill="#c7d2fe" />
              <text x="0" y="10" fill="#a5b4fc" fontSize="7" textAnchor="middle">
                سكون الليل
              </text>
            </g>
          )}
        </svg>

        {/* Prohibited Alert banner if active */}
        {isProhibitedPrayerTime && prohibitedReason && (
          <div className="w-full mt-1 p-2.5 rounded-2xl bg-rose-950/70 border border-rose-500/40 text-rose-200 text-xs flex items-start gap-2 animate-fade-in">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block text-rose-100">تنبيه: وقت كراهة ونهي عن صلاة النفل المطلق</span>
              <p className="text-[11px] text-rose-200/90 mt-0.5 leading-relaxed">
                {prohibitedReason} (يُستثنى قضاء الفرائض الفائتة وذوات الأسباب كتحية المسجد عند جمهور الفقهاء).
              </p>
            </div>
          </div>
        )}

        {/* Duha Banner Details */}
        <div className="w-full grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 text-xs">
          <div className="p-2.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-amber-300 text-base">☀️</span>
              <div>
                <span className="font-bold text-amber-200 block text-xs">صلاة الضحى (صلاة الأوابين)</span>
                <span className="text-[10px] text-gray-300">
                  يبدأ بعد الشروق بـ 15 دقيقة وينتهي قبل الظهر
                </span>
              </div>
            </div>
            <div className="text-left font-mono font-bold text-amber-300 text-xs">
              {formatPrayerTime(duhaStart, settings.timeFormat)} - {formatPrayerTime(duhaEnd, settings.timeFormat)}
            </div>
          </div>

          <div className="p-2.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-indigo-300 text-base">🌙</span>
              <div>
                <span className="font-bold text-indigo-200 block text-xs">الثلث الأخير من الليل</span>
                <span className="text-[10px] text-gray-300">
                  وقت النزول الإلهي واستجابة الدعاء
                </span>
              </div>
            </div>
            <div className="text-left font-mono font-bold text-indigo-300 text-xs">
              {formatPrayerTime(prayerData.sunnahTimes.lastThirdOfTheNight, settings.timeFormat)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
