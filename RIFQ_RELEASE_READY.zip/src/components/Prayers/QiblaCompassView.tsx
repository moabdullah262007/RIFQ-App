import React, { useState, useEffect, useRef } from 'react';
import { Compass, Sparkles, Navigation, X, ShieldAlert, CheckCircle2, RotateCw } from 'lucide-react';
import { CityLocation } from '../../types';
import { triggerHaptic } from '../../utils/prayerAudio';

interface QiblaCompassViewProps {
  isOpen: boolean;
  onClose: () => void;
  qiblaBearing: number;
  distanceToKaabaKm: number;
  currentCity: CityLocation;
}

export const QiblaCompassView: React.FC<QiblaCompassViewProps> = ({
  isOpen,
  onClose,
  qiblaBearing,
  distanceToKaabaKm,
  currentCity
}) => {
  const [deviceHeading, setDeviceHeading] = useState<number | null>(null);
  const [manualAngle, setManualAngle] = useState<number>(0);
  const [permissionState, setPermissionState] = useState<'prompt' | 'granted' | 'denied' | 'unsupported'>('prompt');
  const [isCalibrating, setIsCalibrating] = useState(false);
  const hasVibratedRef = useRef(false);

  // Check if device orientation is supported
  useEffect(() => {
    if (!isOpen) return;

    if (typeof window === 'undefined' || !window.DeviceOrientationEvent) {
      setPermissionState('unsupported');
      return;
    }

    const handleOrientation = (e: DeviceOrientationEvent) => {
      let heading: number | null = null;

      // Webkit / iOS compass heading
      if ('webkitCompassHeading' in e && typeof (e as { webkitCompassHeading?: number }).webkitCompassHeading === 'number') {
        heading = (e as { webkitCompassHeading: number }).webkitCompassHeading;
      } else if (e.alpha !== null) {
        // Standard Android/Chrome deviceorientation
        heading = 360 - e.alpha;
      }

      if (heading !== null) {
        setDeviceHeading(Math.round(heading));
        setPermissionState('granted');
      }
    };

    window.addEventListener('deviceorientation', handleOrientation, true);

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, [isOpen]);

  // Request iOS permission if needed
  const requestCompassPermission = async () => {
    const DeviceOrientation = window.DeviceOrientationEvent as unknown as {
      requestPermission?: () => Promise<'granted' | 'denied'>;
    };

    if (typeof DeviceOrientation.requestPermission === 'function') {
      try {
        const response = await DeviceOrientation.requestPermission();
        setPermissionState(response === 'granted' ? 'granted' : 'denied');
      } catch {
        setPermissionState('denied');
      }
    } else {
      setIsCalibrating(true);
      setTimeout(() => setIsCalibrating(false), 1000);
    }
  };

  // Current heading: from sensor or manual dial
  const currentHeading = deviceHeading !== null ? deviceHeading : manualAngle;
  // Relative angle to Kaaba (where 0 means pointing directly at Kaaba)
  const relativeQiblaAngle = (qiblaBearing - currentHeading + 360) % 360;
  // Is aligned within 4 degrees?
  const isAligned = Math.abs(relativeQiblaAngle < 180 ? relativeQiblaAngle : 360 - relativeQiblaAngle) <= 4;

  useEffect(() => {
    if (isAligned && !hasVibratedRef.current) {
      hasVibratedRef.current = true;
      triggerHaptic([60, 40, 60]);
    } else if (!isAligned) {
      hasVibratedRef.current = false;
    }
  }, [isAligned]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/75 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-gradient-to-b from-[#0B2313] via-[#0F321C] to-[#08180E] text-white rounded-3xl w-full max-w-lg shadow-2xl border border-amber-500/40 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 flex items-center justify-between border-b border-amber-500/20 bg-black/20">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-xl shadow-xs">
              🧭
            </div>
            <div>
              <h3 className="font-bold text-lg text-amber-300 font-tajawal">بوصلة اتجاه القبلة</h3>
              <p className="text-xs text-emerald-300">
                {currentCity.nameAr} • زاوية القبلة: {qiblaBearing}°
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 flex flex-col items-center justify-center">
          {/* Alignment status banner */}
          <div
            className={`w-full py-2.5 px-4 rounded-2xl mb-4 text-center font-bold text-sm transition-all duration-300 flex items-center justify-center gap-2 border ${
              isAligned
                ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-[0_0_20px_rgba(201,168,76,0.3)] animate-pulse'
                : 'bg-white/5 border-white/10 text-emerald-200'
            }`}
          >
            {isAligned ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-amber-300" />
                <span>أنت الآن في اتجاه الكعبة المشرفة تماماً! 🕋</span>
              </>
            ) : (
              <>
                <Navigation className="w-4 h-4 text-amber-400 rotate-45" />
                <span>
                  أدر جهازك حتى يتطابق سهم الكعبة مع القمة ({Math.round(relativeQiblaAngle)}° متبقية)
                </span>
              </>
            )}
          </div>

          {/* Compass Visual Instrument */}
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 my-2 flex items-center justify-center">
            {/* Outer Golden Glow Ring */}
            <div
              className={`absolute inset-0 rounded-full border-2 transition-all duration-500 ${
                isAligned
                  ? 'border-amber-400 shadow-[0_0_35px_rgba(201,168,76,0.6)]'
                  : 'border-amber-500/30'
              }`}
            />

            {/* Dial background with markings */}
            <div
              className="absolute inset-2 rounded-full bg-radial from-[#12361E] to-[#07190D] border border-amber-400/20 shadow-inner flex items-center justify-center transition-transform duration-200"
              style={{ transform: `rotate(${-currentHeading}deg)` }}
            >
              {/* Cardinal directions */}
              <span className="absolute top-3 font-black text-xs text-rose-400">شمال N</span>
              <span className="absolute bottom-3 font-bold text-xs text-amber-200/70">جنوب S</span>
              <span className="absolute right-3 font-bold text-xs text-amber-200/70">شرق E</span>
              <span className="absolute left-3 font-bold text-xs text-amber-200/70">غرب W</span>

              {/* Degrees tick marks */}
              <div className="absolute inset-0 rounded-full border border-dashed border-amber-400/20" />

              {/* Kaaba Direction Marker on the dial */}
              <div
                className="absolute inset-0 flex items-start justify-center transition-transform"
                style={{ transform: `rotate(${qiblaBearing}deg)` }}
              >
                <div className="flex flex-col items-center -translate-y-1">
                  <div className="w-8 h-8 rounded-xl bg-black border-2 border-amber-400 flex items-center justify-center text-sm shadow-md">
                    🕋
                  </div>
                  <div className="w-1 h-5 bg-gradient-to-b from-amber-400 to-transparent" />
                </div>
              </div>
            </div>

            {/* Static Forward Pointer (indicates phone's forward direction) */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 flex flex-col items-center z-10 pointer-events-none">
              <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[14px] border-t-amber-400 drop-shadow-[0_2px_6px_rgba(201,168,76,0.8)]" />
            </div>

            {/* Center Compass Core */}
            <div className="relative z-10 w-20 h-20 rounded-full bg-gradient-to-br from-amber-300 via-[#72B7E8] to-amber-700 p-0.5 shadow-lg flex items-center justify-center">
              <div className="w-full h-full rounded-full bg-[#0E2716] flex flex-col items-center justify-center text-center">
                <span className="text-[11px] font-bold text-amber-300">{qiblaBearing}°</span>
                <span className="text-[9px] text-emerald-300">القبلة</span>
              </div>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="w-full grid grid-cols-2 gap-3 mt-4">
            <div className="p-3 bg-white/5 border border-amber-500/20 rounded-2xl text-center">
              <span className="text-xs text-emerald-300/80 block">المسافة إلى مكة المكرمة</span>
              <span className="text-base font-black text-amber-300 font-mono mt-0.5 block">
                {distanceToKaabaKm.toLocaleString('ar-EG')} كم
              </span>
            </div>
            <div className="p-3 bg-white/5 border border-amber-500/20 rounded-2xl text-center">
              <span className="text-xs text-emerald-300/80 block">انحراف القبلة الفلكي</span>
              <span className="text-base font-black text-amber-300 font-mono mt-0.5 block">
                {qiblaBearing}° من الشمال
              </span>
            </div>
          </div>

          {/* Device Sensor / Manual fallback controls */}
          <div className="w-full mt-4 p-3 bg-black/30 border border-white/10 rounded-2xl text-xs space-y-2">
            <div className="flex items-center justify-between text-emerald-200">
              <span>حساس الاتجاه (Magnetometer):</span>
              <span className={`font-bold ${deviceHeading !== null ? 'text-emerald-400' : 'text-amber-400'}`}>
                {deviceHeading !== null ? `نشط (${deviceHeading}°)` : 'يدوي / وضع تجريبي'}
              </span>
            </div>

            {deviceHeading === null && (
              <div className="pt-2 border-t border-white/10 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 text-[11px]">محاكاة تدوير البوصلة يدوياً:</span>
                  <span className="font-mono text-amber-300 font-bold">{manualAngle}°</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="359"
                  value={manualAngle}
                  onChange={(e) => setManualAngle(parseInt(e.target.value, 10))}
                  className="w-full accent-amber-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-gray-400">
                  <button
                    onClick={() => setManualAngle(qiblaBearing)}
                    className="text-amber-400 hover:underline cursor-pointer"
                  >
                    محاذاة الكعبة مباشرة ({qiblaBearing}°)
                  </button>
                  <button
                    onClick={requestCompassPermission}
                    className="text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCw className="w-3 h-3" />
                    <span>تنشيط حساس الجوال</span>
                  </button>
                </div>
              </div>
            )}

            <p className="text-[11px] text-gray-400 leading-relaxed text-center pt-1">
              💡 للحصول على أعلى دقة، احرص على وضع الهاتف أفقياً بعيداً عن المعادن والأجهزة الكهربائية.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
