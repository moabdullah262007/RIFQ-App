import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  ArrowRight,
  Download,
  Award,
  Clock,
  TrendingUp,
  Flame,
  CalendarDays,
  Layers,
  RefreshCw,
  Target,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ReferenceLine,
  Cell,
} from 'recharts';
import { DailyRecord, ScreenType } from '../types';
import { StatsSectionSvg, TasbeehSectionSvg, WirdSectionSvg } from './Home/RifqSectionIcons';
import {
  getMisbahaAdvancedStats,
  initMisbahaSqliteTables,
} from '../utils/misbahaSqlite';

interface StatsViewProps {
  history: Record<string, DailyRecord>;
  onNavigate: (screen: ScreenType) => void;
}

export const StatsView: React.FC<StatsViewProps> = ({
  history,
  onNavigate,
}) => {
  const [timeFilter, setTimeFilter] = useState<'7days' | '30days' | 'all' | 'custom'>('7days');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [dailyWeeklyChartMode, setDailyWeeklyChartMode] = useState<'bar' | 'area' | 'composed'>('bar');
  const [hourlyChartMode, setHourlyChartMode] = useState<'area' | 'bar'>('area');
  const [monthlyChartType, setMonthlyChartType] = useState<'area' | 'bar'>('area');

  // Load synchronized SQLite data + advanced stats
  const sqliteTables = useMemo(() => initMisbahaSqliteTables(), [history]);
  const misbahaAdvanced = useMemo(() => getMisbahaAdvancedStats(), [history]);
  const dailyGoal = sqliteTables.settings.daily_target || 100;
  const weeklyGoal = sqliteTables.settings.weekly_target || 3000;

  // Merge app history and SQLite daily_stats so no record is ever missed
  const mergedHistoryMap = useMemo(() => {
    const map: Record<string, DailyRecord> = {};
    for (const [dateKey, rawRec] of Object.entries(history)) {
      const rec = rawRec as DailyRecord;
      map[dateKey] = {
        ...rec,
        hourlyCounts:
          Array.isArray(rec.hourlyCounts) && rec.hourlyCounts.length === 24
            ? [...rec.hourlyCounts]
            : new Array(24).fill(0),
        dhikrCounts: { ...(rec.dhikrCounts || {}) },
      };
    }

    for (const row of sqliteTables.dailyStats) {
      let rowDhikr: Record<string, number> = {};
      try {
        rowDhikr = JSON.parse(row.dhikr_counts_json || '{}');
      } catch {
        rowDhikr = {};
      }

      if (!map[row.date]) {
        map[row.date] = {
          date: row.date,
          totalCount: row.total_count || 0,
          sessionsCount: row.sessions_count || 0,
          completedAthkarCount: 0,
          freeCount: row.total_count || 0,
          hourlyCounts: new Array(24).fill(0),
          dhikrCounts: rowDhikr,
        };
      } else if ((row.total_count || 0) > (map[row.date].totalCount || 0)) {
        map[row.date].totalCount = row.total_count;
        map[row.date].sessionsCount = Math.max(
          map[row.date].sessionsCount || 0,
          row.sessions_count || 0
        );
        map[row.date].dhikrCounts = {
          ...map[row.date].dhikrCounts,
          ...rowDhikr,
        };
      }
    }
    return map;
  }, [history, sqliteTables.dailyStats]);

  const allRecords = useMemo(() => Object.values(mergedHistoryMap), [mergedHistoryMap]);

  // 7-Day Weekly & Daily Chart Data (always shows all 7 days of the week for clear Recharts visualization)
  const sevenDaysChartData = useMemo(() => {
    const now = new Date();
    const dayNamesAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const result = [];

    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const rec = mergedHistoryMap[dateKey];
      const count = rec ? rec.totalCount || 0 : 0;
      const sessions = rec ? rec.sessionsCount || (count > 0 ? 1 : 0) : 0;
      const dayName = dayNamesAr[d.getDay()];
      const shortDate = `${d.getDate()}/${d.getMonth() + 1}`;

      result.push({
        date: dateKey,
        dayName,
        shortDate,
        axisLabel: `${dayName} (${shortDate})`,
        count,
        sessions,
        goal: dailyGoal > 0 ? dailyGoal : 100,
        isToday: i === 0,
      });
    }
    return result;
  }, [mergedHistoryMap, dailyGoal]);

  // 30 Days Monthly Progress Data for Recharts
  const monthlyProgressData = useMemo(() => {
    const list = [];
    const now = new Date();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const dateKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const rec = mergedHistoryMap[dateKey];
      const count = rec ? rec.totalCount || 0 : 0;

      const dayNum = d.getDate();
      const monthNum = d.getMonth() + 1;
      const dayName = d.toLocaleDateString('ar-EG', { weekday: 'short' });
      const fullDate = d.toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' });

      list.push({
        date: dateKey,
        label: `${dayNum}/${monthNum}`,
        fullDate,
        dayName,
        count,
        sessions: rec?.sessionsCount || (count > 0 ? 1 : 0),
        completedAthkar: rec?.completedAthkarCount || 0,
      });
    }
    return list;
  }, [mergedHistoryMap]);

  const monthlyStats = useMemo(() => {
    const total = monthlyProgressData.reduce((acc, d) => acc + d.count, 0);
    const activeDays = monthlyProgressData.filter((d) => d.count > 0).length;
    const avgDaily = Math.round(total / 30);
    let maxDay = monthlyProgressData[0] || { count: 0, fullDate: '', dayName: '' };
    monthlyProgressData.forEach((d) => {
      if (d.count > maxDay.count) {
        maxDay = d;
      }
    });
    const consistencyRate = Math.round((activeDays / 30) * 100);
    return { total, activeDays, avgDaily, maxDay, consistencyRate };
  }, [monthlyProgressData]);

  const lifetimeStats = useMemo(() => {
    let totalCount = 0;
    let totalSessions = 0;
    let totalFree = 0;
    let totalWardsCompleted = 0;

    allRecords.forEach((r) => {
      totalCount += r.totalCount || 0;
      totalSessions += r.sessionsCount || (r.totalCount > 0 ? 1 : 0);
      totalFree += r.freeCount || 0;
      totalWardsCompleted += r.completedAthkarCount || 0;
    });

    return {
      totalCount: Math.max(totalCount, misbahaAdvanced.totalLifetimeCount),
      totalSessions: Math.max(totalSessions, misbahaAdvanced.totalSessions),
      totalFree,
      totalWardsCompleted,
    };
  }, [allRecords, misbahaAdvanced.totalLifetimeCount, misbahaAdvanced.totalSessions]);

  // Filter records by time period
  const filteredRecords = useMemo(() => {
    const now = new Date();
    const sorted = [...allRecords].sort((a, b) => a.date.localeCompare(b.date));

    if (timeFilter === '7days') {
      const past7 = new Date(now);
      past7.setDate(now.getDate() - 6);
      const minDate = `${past7.getFullYear()}-${String(past7.getMonth() + 1).padStart(2, '0')}-${String(past7.getDate()).padStart(2, '0')}`;
      return sorted.filter((r) => r.date >= minDate);
    }

    if (timeFilter === '30days') {
      const past30 = new Date(now);
      past30.setDate(now.getDate() - 29);
      const minDate = `${past30.getFullYear()}-${String(past30.getMonth() + 1).padStart(2, '0')}-${String(past30.getDate()).padStart(2, '0')}`;
      return sorted.filter((r) => r.date >= minDate);
    }

    if (timeFilter === 'custom' && startDate && endDate) {
      return sorted.filter((r) => r.date >= startDate && r.date <= endDate);
    }

    return sorted;
  }, [allRecords, timeFilter, startDate, endDate]);

  // Period Chart Data for Recharts (7days uses full 7-day calendar, 30days uses 30-day calendar, custom/all uses filtered records)
  const activePeriodChartData = useMemo(() => {
    if (timeFilter === '7days') {
      return sevenDaysChartData;
    }
    if (timeFilter === '30days') {
      return monthlyProgressData.map((d) => ({
        date: d.date,
        dayName: d.dayName,
        shortDate: d.label,
        axisLabel: d.label,
        count: d.count,
        sessions: d.sessions,
        goal: dailyGoal > 0 ? dailyGoal : 100,
        isToday: d.date === sevenDaysChartData[sevenDaysChartData.length - 1]?.date,
      }));
    }
    return filteredRecords.map((r) => {
      const d = new Date(r.date);
      const dayName = d.toLocaleDateString('ar-EG', { weekday: 'short' });
      const shortDate = r.date.split('-').slice(1).join('/');
      return {
        date: r.date,
        dayName,
        shortDate,
        axisLabel: shortDate,
        count: r.totalCount || 0,
        sessions: r.sessionsCount || (r.totalCount > 0 ? 1 : 0),
        goal: dailyGoal > 0 ? dailyGoal : 100,
        isToday: false,
      };
    });
  }, [timeFilter, sevenDaysChartData, monthlyProgressData, filteredRecords, dailyGoal]);

  const selectedPeriodTotal = useMemo(() => {
    return activePeriodChartData.reduce((sum, r) => sum + (r.count || 0), 0);
  }, [activePeriodChartData]);

  // Aggregate Dhikr breakdown for Recharts horizontal bar chart
  const dhikrChartData = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredRecords.forEach((r) => {
      if (r.dhikrCounts) {
        Object.entries(r.dhikrCounts).forEach(([text, cnt]) => {
          const val = Number(cnt) || 0;
          if (val > 0) {
            counts[text] = (counts[text] || 0) + val;
          }
        });
      }
    });

    // Also include custom_adhkar usage counts if empty
    if (Object.keys(counts).length === 0 && misbahaAdvanced.mostUsedAdhkar.length > 0) {
      for (const item of misbahaAdvanced.mostUsedAdhkar) {
        counts[item.dhikr] = item.count;
      }
    }

    const totalSum = Object.values(counts).reduce((a, b) => a + b, 0);
    return Object.entries(counts)
      .filter(([, count]) => count > 0)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 7)
      .map(([dhikr, count]) => ({
        dhikr,
        shortName: dhikr.length > 22 ? `${dhikr.slice(0, 20)}...` : dhikr,
        count,
        percentage: totalSum > 0 ? Math.round((count / totalSum) * 100) : 0,
      }));
  }, [filteredRecords, misbahaAdvanced.mostUsedAdhkar]);

  // Aggregate 24-Hour distribution for Recharts Hourly Chart
  const hourlyChartData = useMemo(() => {
    const hours = new Array(24).fill(0);
    filteredRecords.forEach((r) => {
      if (Array.isArray(r.hourlyCounts)) {
        r.hourlyCounts.forEach((c, h) => {
          if (h >= 0 && h < 24) {
            hours[h] += Number(c) || 0;
          }
        });
      }
    });

    // If total in period > sum of hourlyCounts (e.g. from SQLite sessions), distribute based on session timestamps
    const sumHours = hours.reduce((a, b) => a + b, 0);
    if (selectedPeriodTotal > sumHours) {
      for (const sess of sqliteTables.sessions) {
        const sessHour = new Date(sess.created_at).getHours();
        if (!isNaN(sessHour) && sessHour >= 0 && sessHour < 24) {
          hours[sessHour] += sess.count || 0;
        }
      }
    }

    return hours.map((c, h) => {
      const h12 = h % 12 || 12;
      const ampm = h >= 12 ? 'م' : 'ص';
      let periodName = 'الليل والقيام';
      if (h >= 4 && h < 11) periodName = 'الفجر والصباح';
      else if (h >= 11 && h < 16) periodName = 'الظهيرة والعصر';
      else if (h >= 16 && h < 21) periodName = 'المساء والمغرب';

      return {
        hour: h,
        label: `${h12} ${ampm}`,
        periodName,
        count: c,
      };
    });
  }, [filteredRecords, selectedPeriodTotal, sqliteTables.sessions]);

  const handleExportReport = () => {
    const reportText = [
      '=== تقرير إحصائيات تطبيق «رِفْق | RIFQ» ===',
      `التاريخ: ${new Date().toLocaleDateString('ar-EG')}`,
      `إجمالي التسبيحات الكلي: ${lifetimeStats.totalCount}`,
      `عدد الجلسات: ${lifetimeStats.totalSessions}`,
      `التسبيح الحر: ${lifetimeStats.totalFree}`,
      `الأوراد المكتملة: ${lifetimeStats.totalWardsCompleted}`,
      '',
      `إجمالي الفترة المحددة (${timeFilter}): ${selectedPeriodTotal} تسبيحة`,
      '',
      'أكثر الأذكار تكراراً:',
      ...dhikrChartData.map((item, idx) => `${idx + 1}. ${item.dhikr}: ${item.count} مرة (${item.percentage}%)`),
      '',
      '«أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ»',
    ].join('\n');

    const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `تقرير_تطبيق_رفق_${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6 pb-16 select-none font-cairo" dir="rtl">
      {/* Top Bar: "سجل الإحصائيات" in Gold + Export Button */}
      <div className="bg-white rounded-[20px] p-4 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onNavigate('tasbeeh')}
            className="min-w-[44px] min-h-[44px] rounded-xl text-[#25263A] hover:bg-[#F7F7FC] flex items-center justify-center transition-colors cursor-pointer"
            title="الرجوع للمسبحة المركزية"
          >
            <ArrowRight className="w-5 h-5 text-[#5B5FEF]" />
          </button>
          <div className="flex items-center gap-2.5">
            <StatsSectionSvg size={32} />
            <div>
              <h2 className="text-xl font-bold text-[#5B5FEF] font-cairo">
                سجل الإحصائيات البيانية
              </h2>
              <p className="text-xs text-[#77798C]">
                تمثيل بياني تفاعلي للتسبيحات اليومية والأسبوعية والشهرية
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleExportReport}
          className="bg-[#F7F7FC] text-[#25263A] border border-[#5B5FEF] px-3.5 py-2 rounded-xl text-xs font-bold hover:bg-[#EEEEFF] transition-colors flex items-center gap-1.5 cursor-pointer min-h-[40px]"
        >
          <Download className="w-4 h-4 text-[#5B5FEF]" />
          <span>تصدير التقرير</span>
        </button>
      </div>

      {/* 4 Overview Cards (Clean SVG icons, no emojis, tabular-nums) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Card 1: إجمالي التسبيحات */}
        <div className="bg-white rounded-[20px] p-4 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] text-center flex flex-col items-center justify-center">
          <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mb-1.5">
            <TasbeehSectionSvg size={24} />
          </div>
          <span className="text-xs text-[#77798C] font-bold">إجمالي التسبيحات</span>
          <span className="text-2xl font-bold text-[#5B5FEF] mt-1 font-cairo tabular-nums">
            {lifetimeStats.totalCount.toLocaleString('ar-EG')}
          </span>
        </div>

        {/* Card 2: عدد الجلسات */}
        <div className="bg-white rounded-[20px] p-4 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] text-center flex flex-col items-center justify-center">
          <div className="w-10 h-10 rounded-xl bg-[#25263A]/10 text-[#25263A] flex items-center justify-center mb-1.5">
            <Layers className="w-5 h-5 text-[#25263A]" />
          </div>
          <span className="text-xs text-[#77798C] font-bold">عدد الجلسات</span>
          <span className="text-2xl font-bold text-[#25263A] mt-1 font-cairo tabular-nums">
            {lifetimeStats.totalSessions.toLocaleString('ar-EG')}
          </span>
        </div>

        {/* Card 3: الدورات المكتملة */}
        <div className="bg-white rounded-[20px] p-4 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] text-center flex flex-col items-center justify-center">
          <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center mb-1.5">
            <RefreshCw className="w-5 h-5 text-[#4145C7]" />
          </div>
          <span className="text-xs text-[#77798C] font-bold">الدورات المكتملة</span>
          <span className="text-2xl font-bold text-[#4145C7] mt-1 font-cairo tabular-nums">
            {misbahaAdvanced.totalCycles.toLocaleString('ar-EG')}
          </span>
        </div>

        {/* Card 4: الأوراد المكتملة */}
        <div className="bg-white rounded-[20px] p-4 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] text-center flex flex-col items-center justify-center">
          <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mb-1.5">
            <WirdSectionSvg size={24} />
          </div>
          <span className="text-xs text-[#77798C] font-bold">الأوراد المكتملة</span>
          <span className="text-2xl font-bold text-[#4145C7] mt-1 font-cairo tabular-nums">
            {lifetimeStats.totalWardsCompleted.toLocaleString('ar-EG')}
          </span>
        </div>
      </div>

      {/* Time Filters: 7 أيام | 30 يوم | مخصص | الكل */}
      <div className="bg-white rounded-[20px] p-3 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] space-y-3">
        <div className="flex items-center justify-between gap-2">
          {[
            { id: '7days', label: 'أسبوعي (7 أيام)' },
            { id: '30days', label: 'شهري (30 يوماً)' },
            { id: 'custom', label: 'فترة مخصصة' },
            { id: 'all', label: 'كل السجل' },
          ].map((f) => {
            const isActive = timeFilter === f.id;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setTimeFilter(f.id as typeof timeFilter)}
                className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#5B5FEF] text-white shadow-xs'
                    : 'bg-[#F7F7FC] text-[#25263A] hover:bg-[#EEEEFF]'
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>

        {/* Custom date picker row */}
        {timeFilter === 'custom' && (
          <div className="flex items-center gap-3 p-2.5 bg-[#F7F7FC] rounded-xl text-xs animate-fade-in">
            <div className="flex-1">
              <label className="block text-[#77798C] font-bold mb-1">من تاريخ:</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-white border border-[#E6E6F0] rounded-lg p-2 text-[#25263A]"
              />
            </div>
            <div className="flex-1">
              <label className="block text-[#77798C] font-bold mb-1">إلى تاريخ:</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-white border border-[#E6E6F0] rounded-lg p-2 text-[#25263A]"
              />
            </div>
          </div>
        )}
      </div>

      {/* Selected Period Total Banner */}
      <div className="bg-gradient-to-br from-[#5B5FEF] to-[#4145C7] text-white rounded-[20px] p-6 shadow-md text-center relative overflow-hidden border border-[#5B5FEF]">
        <span className="text-xs sm:text-sm font-bold text-[#E8B84A] block">
          إجمالي التسبيحات في الفترة المحددة
        </span>
        <span className="text-[44px] sm:text-[52px] font-bold text-white leading-none my-2 block font-cairo tabular-nums">
          {selectedPeriodTotal.toLocaleString('ar-EG')}
        </span>
        <span className="text-xs text-white/85">
          اليوم: {misbahaAdvanced.todayCount.toLocaleString('ar-EG')} · الأسبوع:{' '}
          {misbahaAdvanced.weekCount.toLocaleString('ar-EG')} · الشهر:{' '}
          {misbahaAdvanced.monthCount.toLocaleString('ar-EG')}
        </span>
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          【1】التمثيل البياني للتسبيحات اليومية والأسبوعية (Recharts Bar / Area / Composed)
         ══════════════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-[20px] p-5 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E6E6F0] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#25263A]">
                الرسم البياني للتسبيحات اليومية والأسبوعية
              </h3>
              <p className="text-xs text-[#77798C]">
                مقارنة عدد التسبيحات اليومية بالهدف المحدد ({dailyGoal > 0 ? dailyGoal : 'مفتوح'})
              </p>
            </div>
          </div>

          {/* Chart Type Switcher */}
          <div className="flex items-center gap-1 bg-[#F7F7FC] p-1 rounded-xl self-start sm:self-auto text-xs font-bold">
            <button
              type="button"
              onClick={() => setDailyWeeklyChartMode('bar')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                dailyWeeklyChartMode === 'bar'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:bg-[#EEEEFF]'
              }`}
            >
              أعمدة
            </button>
            <button
              type="button"
              onClick={() => setDailyWeeklyChartMode('area')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                dailyWeeklyChartMode === 'area'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:bg-[#EEEEFF]'
              }`}
            >
              منحنى
            </button>
            <button
              type="button"
              onClick={() => setDailyWeeklyChartMode('composed')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                dailyWeeklyChartMode === 'composed'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:bg-[#EEEEFF]'
              }`}
            >
              مزدوج
            </button>
          </div>
        </div>

        {/* Recharts Daily / Weekly Visualization */}
        <div className="w-full h-72 pt-2" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            {dailyWeeklyChartMode === 'bar' ? (
              <BarChart
                data={activePeriodChartData}
                margin={{ top: 12, right: 16, left: -16, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                <XAxis
                  dataKey="dayName"
                  tick={{ fontSize: 11, fill: '#25263A', fontWeight: 700 }}
                  tickLine={false}
                  axisLine={{ stroke: '#72B7E8' }}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                {dailyGoal > 0 && (
                  <ReferenceLine
                    y={dailyGoal}
                    stroke="#5B5FEF"
                    strokeDasharray="4 4"
                    strokeWidth={1.5}
                  />
                )}
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload as (typeof activePeriodChartData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[150px]"
                          dir="rtl"
                        >
                          <p className="font-bold text-[#25263A] border-b border-[#E6E6F0] pb-1 mb-1.5 flex items-center justify-between gap-3">
                            <span>{d.dayName}</span>
                            <span className="text-[#77798C] tabular-nums">{d.shortDate}</span>
                          </p>
                          <div className="flex items-center justify-between gap-3 font-bold">
                            <span className="text-[#77798C]">التسبيحات:</span>
                            <span className="text-sm text-[#4145C7] tabular-nums">
                              {d.count.toLocaleString('ar-EG')}
                            </span>
                          </div>
                          <div className="flex items-center justify-between gap-3 text-[11px] text-[#77798C] mt-1">
                            <span>الجلسات:</span>
                            <span className="tabular-nums">{d.sessions}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" name="التسبيحات" radius={[8, 8, 0, 0]} maxBarSize={44}>
                  {activePeriodChartData.map((entry, idx) => (
                    <Cell
                      key={`cell-${idx}`}
                      fill={entry.isToday ? '#5B5FEF' : '#72B7E8'}
                    />
                  ))}
                </Bar>
              </BarChart>
            ) : dailyWeeklyChartMode === 'area' ? (
              <AreaChart
                data={activePeriodChartData}
                margin={{ top: 12, right: 16, left: -16, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="weeklyGoldArea" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#72B7E8" stopOpacity={0.55} />
                    <stop offset="95%" stopColor="#72B7E8" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                <XAxis
                  dataKey="dayName"
                  tick={{ fontSize: 11, fill: '#25263A', fontWeight: 700 }}
                  tickLine={false}
                  axisLine={{ stroke: '#72B7E8' }}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                {dailyGoal > 0 && (
                  <ReferenceLine
                    y={dailyGoal}
                    stroke="#5B5FEF"
                    strokeDasharray="4 4"
                    strokeWidth={1.5}
                  />
                )}
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload as (typeof activePeriodChartData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[150px]"
                          dir="rtl"
                        >
                          <p className="font-bold text-[#25263A] border-b border-[#E6E6F0] pb-1 mb-1.5 flex items-center justify-between gap-3">
                            <span>{d.dayName}</span>
                            <span className="text-[#77798C] tabular-nums">{d.shortDate}</span>
                          </p>
                          <div className="flex items-center justify-between gap-3 font-bold">
                            <span className="text-[#77798C]">التسبيحات:</span>
                            <span className="text-sm text-[#5B5FEF] tabular-nums">
                              {d.count.toLocaleString('ar-EG')}
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="count"
                  stroke="#5B5FEF"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#weeklyGoldArea)"
                  activeDot={{ r: 6, fill: '#5B5FEF', stroke: '#FFFFFF', strokeWidth: 2 }}
                />
              </AreaChart>
            ) : (
              <ComposedChart
                data={activePeriodChartData}
                margin={{ top: 12, right: 16, left: -16, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                <XAxis
                  dataKey="dayName"
                  tick={{ fontSize: 11, fill: '#25263A', fontWeight: 700 }}
                  tickLine={false}
                  axisLine={{ stroke: '#72B7E8' }}
                />
                <YAxis
                  tick={{ fontSize: 11, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload as (typeof activePeriodChartData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[155px]"
                          dir="rtl"
                        >
                          <p className="font-bold text-[#25263A] border-b border-[#E6E6F0] pb-1 mb-1.5 flex items-center justify-between gap-3">
                            <span>{d.dayName}</span>
                            <span className="text-[#77798C] tabular-nums">{d.shortDate}</span>
                          </p>
                          <div className="flex items-center justify-between gap-3 font-bold">
                            <span className="text-[#77798C]">التسبيحات:</span>
                            <span className="text-sm text-[#5B5FEF] tabular-nums">
                              {d.count.toLocaleString('ar-EG')}
                            </span>
                          </div>
                          <div className="flex items-center justify-between gap-3 font-bold text-[#4145C7] mt-1">
                            <span>الهدف اليومي:</span>
                            <span className="tabular-nums">{d.goal}</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" fill="#72B7E8" radius={[6, 6, 0, 0]} maxBarSize={38} />
                <Line
                  type="monotone"
                  dataKey="goal"
                  stroke="#5B5FEF"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#5B5FEF' }}
                />
              </ComposedChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Legend & Target Note */}
        <div className="flex items-center justify-between text-xs text-[#77798C] bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-bold text-[#25263A]">
              <span className="w-3 h-3 rounded-xs bg-[#5B5FEF] inline-block" />
              <span>اليوم الحالي</span>
            </span>
            <span className="flex items-center gap-1.5 font-bold text-[#25263A]">
              <span className="w-3 h-3 rounded-xs bg-[#5B5FEF] inline-block" />
              <span>أيام الأسبوع</span>
            </span>
          </div>
          <span className="tabular-nums font-bold text-[#4145C7]">
            الهدف اليومي: {dailyGoal > 0 ? `${dailyGoal} تسبيحة` : 'مفتوح'}
          </span>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          【2】المقارنة البيانية الأسبوعية (آخر 4 أسابيع — Recharts BarChart)
         ══════════════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-[20px] p-5 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#25263A]">
                مؤشر الأداء الأسبوعي (مقارنة آخر 4 أسابيع)
              </h3>
              <p className="text-xs text-[#77798C]">
                تمثيل بياني لمجموع التسبيحات الأسبوعية مقارنة بالهدف الأسبوعي ({weeklyGoal})
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-[#5B5FEF] tabular-nums">
            هذا الأسبوع: {misbahaAdvanced.weekCount.toLocaleString('ar-EG')}
          </span>
        </div>

        <div className="w-full h-60 pt-2" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={misbahaAdvanced.fourWeeksChart}
              margin={{ top: 10, right: 16, left: -16, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
              <XAxis
                dataKey="weekLabel"
                tick={{ fontSize: 11, fill: '#25263A', fontWeight: 700 }}
                tickLine={false}
                axisLine={{ stroke: '#72B7E8' }}
              />
              <YAxis
                tick={{ fontSize: 11, fill: '#77798C' }}
                tickLine={false}
                axisLine={false}
                allowDecimals={false}
              />
              {weeklyGoal > 0 && (
                <ReferenceLine
                  y={weeklyGoal}
                  stroke="#5B5FEF"
                  strokeDasharray="4 4"
                  strokeWidth={1.5}
                />
              )}
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const w = payload[0].payload as (typeof misbahaAdvanced.fourWeeksChart)[0];
                    return (
                      <div
                        className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[160px]"
                        dir="rtl"
                      >
                        <p className="font-bold text-[#25263A] border-b border-[#E6E6F0] pb-1 mb-1.5 flex items-center justify-between gap-2">
                          <span>{w.weekLabel}</span>
                          <span className="text-[#77798C] tabular-nums">{w.rangeLabel}</span>
                        </p>
                        <div className="flex items-center justify-between gap-3 font-bold">
                          <span className="text-[#77798C]">مجموع الأسبوع:</span>
                          <span className="text-sm text-[#4145C7] tabular-nums">
                            {w.count.toLocaleString('ar-EG')}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-3 text-[11px] text-[#77798C] mt-1">
                          <span>أيام النشاط:</span>
                          <span className="tabular-nums">{w.activeDays} / 7 أيام</span>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar dataKey="count" name="مجموع الأسبوع" radius={[8, 8, 0, 0]} maxBarSize={52}>
                {misbahaAdvanced.fourWeeksChart.map((_, index) => (
                  <Cell
                    key={`week-cell-${index}`}
                    fill={index === 3 ? '#5B5FEF' : '#72B7E8'}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          【3】التوزيع البياني للتسبيحات حسب ساعات اليوم (Recharts 24-Hour Chart)
          بدلاً من الجداول النصية
         ══════════════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-[20px] p-5 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E6F0] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#25263A]">
                التوزيع البياني للتسبيح على مدار ساعات اليوم (24 ساعة)
              </h3>
              <p className="text-xs text-[#77798C]">
                تمثيل بياني لأوقات الذروة والنشاط اليومي بدلاً من الجداول النصية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-[#F7F7FC] p-1 rounded-xl self-start sm:self-auto text-xs font-bold">
            <button
              type="button"
              onClick={() => setHourlyChartMode('area')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                hourlyChartMode === 'area'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:bg-[#EEEEFF]'
              }`}
            >
              منحنى الساعات
            </button>
            <button
              type="button"
              onClick={() => setHourlyChartMode('bar')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                hourlyChartMode === 'bar'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:bg-[#EEEEFF]'
              }`}
            >
              أعمدة الساعات
            </button>
          </div>
        </div>

        <div className="w-full h-64 pt-2" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            {hourlyChartMode === 'area' ? (
              <AreaChart
                data={hourlyChartData}
                margin={{ top: 10, right: 15, left: -20, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="hourlyGoldGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#5B5FEF" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#72B7E8" stopOpacity={0.04} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  interval={2}
                  axisLine={{ stroke: '#72B7E8' }}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const h = payload[0].payload as (typeof hourlyChartData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[145px]"
                          dir="rtl"
                        >
                          <p className="font-bold text-[#25263A] border-b border-[#E6E6F0] pb-1 mb-1 flex items-center justify-between gap-2">
                            <span>الساعة {h.label}</span>
                            <span className="text-[#77798C]">{h.periodName}</span>
                          </p>
                          <div className="flex items-center justify-between gap-3 font-bold">
                            <span className="text-[#77798C]">عدد التسبيحات:</span>
                            <span className="text-sm text-[#4145C7] tabular-nums">
                              {h.count.toLocaleString('ar-EG')}
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="count"
                  stroke="#5B5FEF"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#hourlyGoldGrad)"
                  activeDot={{ r: 5, fill: '#72B7E8', stroke: '#5B5FEF', strokeWidth: 2 }}
                />
              </AreaChart>
            ) : (
              <BarChart
                data={hourlyChartData}
                margin={{ top: 10, right: 15, left: -20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E6F0" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  interval={2}
                  axisLine={{ stroke: '#72B7E8' }}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const h = payload[0].payload as (typeof hourlyChartData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[145px]"
                          dir="rtl"
                        >
                          <p className="font-bold text-[#25263A] border-b border-[#E6E6F0] pb-1 mb-1 flex items-center justify-between gap-2">
                            <span>الساعة {h.label}</span>
                            <span className="text-[#77798C]">{h.periodName}</span>
                          </p>
                          <div className="flex items-center justify-between gap-3 font-bold">
                            <span className="text-[#77798C]">عدد التسبيحات:</span>
                            <span className="text-sm text-[#5B5FEF] tabular-nums">
                              {h.count.toLocaleString('ar-EG')}
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" fill="#72B7E8" radius={[4, 4, 0, 0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          【4】التقدم الشهري (آخر 30 يوماً — Recharts Area / Bar)
         ══════════════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-[20px] p-5 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#E6E6F0] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center">
              <CalendarDays className="w-5 h-5 text-[#4145C7]" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#25263A]">
                التقدم الشهري (آخر 30 يوماً)
              </h3>
              <p className="text-xs text-[#77798C]">
                متابعة وتيرة التسبيح اليومي والاستمرارية لبناء عادة راسخة
              </p>
            </div>
          </div>

          {/* Toggle between Area Chart & Bar Chart */}
          <div className="flex items-center gap-1 bg-[#F7F7FC] p-1 rounded-xl self-start sm:self-auto text-xs font-bold">
            <button
              type="button"
              onClick={() => setMonthlyChartType('area')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                monthlyChartType === 'area'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:bg-[#EEEEFF]'
              }`}
            >
              انسيابي
            </button>
            <button
              type="button"
              onClick={() => setMonthlyChartType('bar')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                monthlyChartType === 'bar'
                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                  : 'text-[#25263A] hover:bg-[#EEEEFF]'
              }`}
            >
              أعمدة
            </button>
          </div>
        </div>

        {/* 4 Quick Monthly Habit Indicators */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
          <div className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
            <span className="text-[11px] text-[#77798C] font-bold block mb-0.5">مجموع 30 يوماً</span>
            <span className="text-lg font-bold text-[#5B5FEF] tabular-nums">
              {monthlyStats.total.toLocaleString('ar-EG')}
            </span>
            <span className="text-[10px] text-[#77798C] block mt-0.5">تسبيحة</span>
          </div>

          <div className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
            <span className="text-[11px] text-[#77798C] font-bold block mb-0.5">المعدل اليومي</span>
            <span className="text-lg font-bold text-[#4145C7] tabular-nums">
              {monthlyStats.avgDaily.toLocaleString('ar-EG')}
            </span>
            <span className="text-[10px] text-[#77798C] block mt-0.5">تسبيحة / يوم</span>
          </div>

          <div className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
            <span className="text-[11px] text-[#77798C] font-bold block mb-0.5">أيام المواظبة</span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold text-[#25263A] tabular-nums">
                {monthlyStats.activeDays.toLocaleString('ar-EG')}
              </span>
              <span className="text-xs text-[#77798C]">/ 30 يوماً</span>
            </div>
            <span className="text-[10px] text-[#4145C7] font-bold block mt-0.5 tabular-nums">
              نسبة الالتزام: {monthlyStats.consistencyRate}%
            </span>
          </div>

          <div className="bg-[#F7F7FC] p-3 rounded-xl border border-[#E6E6F0]">
            <span className="text-[11px] text-[#77798C] font-bold block mb-0.5">أعلى إنجاز يومي</span>
            <span className="text-lg font-bold text-[#5B5FEF] tabular-nums">
              {monthlyStats.maxDay.count.toLocaleString('ar-EG')}
            </span>
            <span className="text-[10px] text-[#77798C] block mt-0.5 truncate">
              {monthlyStats.maxDay.count > 0 ? monthlyStats.maxDay.fullDate : '—'}
            </span>
          </div>
        </div>

        {/* Recharts 30-Day Container */}
        <div className="w-full h-64 pt-2" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            {monthlyChartType === 'area' ? (
              <AreaChart
                data={monthlyProgressData}
                margin={{ top: 10, right: 15, left: -20, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="monthlyAreaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#5B5FEF" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="#72B7E8" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F7F7FC" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  interval={3}
                  axisLine={{ stroke: '#72B7E8' }}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const item = payload[0].payload as (typeof monthlyProgressData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[140px]"
                          dir="rtl"
                        >
                          <p className="font-bold text-[#25263A] mb-1.5 flex items-center justify-between border-b border-[#E6E6F0] pb-1">
                            <span>{item.dayName}</span>
                            <span className="text-[#77798C] font-normal">{item.fullDate}</span>
                          </p>
                          <div className="flex items-center justify-between gap-3 font-bold">
                            <span className="text-[#77798C]">التسبيحات:</span>
                            <span className="text-sm font-bold text-[#4145C7] tabular-nums">
                              {item.count.toLocaleString('ar-EG')}
                            </span>
                          </div>
                          {item.sessions > 0 && (
                            <div className="flex items-center justify-between text-[#77798C] text-[11px] mt-1">
                              <span>الجلسات:</span>
                              <span className="tabular-nums">
                                {item.sessions.toLocaleString('ar-EG')}
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="count"
                  name="التسبيحات"
                  stroke="#5B5FEF"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#monthlyAreaGrad)"
                  activeDot={{ r: 5, fill: '#72B7E8', stroke: '#5B5FEF', strokeWidth: 2 }}
                />
              </AreaChart>
            ) : (
              <BarChart
                data={monthlyProgressData}
                margin={{ top: 10, right: 15, left: -20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F7F7FC" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  interval={3}
                  axisLine={{ stroke: '#72B7E8' }}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const item = payload[0].payload as (typeof monthlyProgressData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs min-w-[140px]"
                          dir="rtl"
                        >
                          <p className="font-bold text-[#25263A] mb-1.5 flex items-center justify-between border-b border-[#E6E6F0] pb-1">
                            <span>{item.dayName}</span>
                            <span className="text-[#77798C] font-normal">{item.fullDate}</span>
                          </p>
                          <div className="flex items-center justify-between gap-3 font-bold">
                            <span className="text-[#77798C]">التسبيحات:</span>
                            <span className="text-sm font-bold text-[#4145C7] tabular-nums">
                              {item.count.toLocaleString('ar-EG')}
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar
                  dataKey="count"
                  name="التسبيحات"
                  fill="#5B5FEF"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>

        <div className="bg-[#F7F7FC] rounded-xl p-3 flex items-center justify-between text-xs text-[#25263A]">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-[#5B5FEF] shrink-0" />
            <span>
              <strong className="text-[#4145C7]">بناء عادة الذكر:</strong> «أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ»
            </span>
          </div>
          <span className="text-[11px] text-[#77798C] hidden sm:inline">30 يوماً متتالية</span>
        </div>
      </div>

      {/* ══════════════════════════════════════════════════════════════════
          【5】التمثيل البياني لأكثر الأذكار تكراراً (Recharts Horizontal BarChart)
         ══════════════════════════════════════════════════════════════════ */}
      <div className="bg-white rounded-[20px] p-5 shadow-[0_4px_12px_rgba(0,0,0,0.06)] border border-[#E6E6F0] space-y-4">
        <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#25263A]">
                التمثيل البياني لأكثر الأذكار استخداماً
              </h3>
              <p className="text-xs text-[#77798C]">
                توزيع الأذكار المسبّح بها خلال الفترة المحددة
              </p>
            </div>
          </div>
          <Target className="w-4 h-4 text-[#5B5FEF]" />
        </div>

        {dhikrChartData.length === 0 ? (
          <div className="py-10 text-center space-y-1">
            <p className="font-bold text-sm text-[#77798C]">
              لا توجد بيانات أذكار مسجلة في هذه الفترة بعد
            </p>
            <p className="text-xs text-[#77798C]">
              ابدأ التسبيح في المسبحة المركزية ليظهر التوزيع البياني للأذكار هنا تلقائياً
            </p>
          </div>
        ) : (
          <div className="w-full h-64 pt-2" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={dhikrChartData}
                layout="vertical"
                margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#E6E6F0" />
                <XAxis
                  type="number"
                  tick={{ fontSize: 11, fill: '#77798C' }}
                  tickLine={false}
                  axisLine={{ stroke: '#72B7E8' }}
                  allowDecimals={false}
                />
                <YAxis
                  type="category"
                  dataKey="shortName"
                  width={135}
                  tick={{ fontSize: 11, fill: '#25263A', fontWeight: 700 }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const d = payload[0].payload as (typeof dhikrChartData)[0];
                      return (
                        <div
                          className="bg-white p-3 rounded-xl shadow-lg border border-[#E6E6F0] text-right font-cairo text-xs max-w-xs"
                          dir="rtl"
                        >
                          <p className="font-amiri font-bold text-sm text-[#25263A] mb-1.5 border-b border-[#E6E6F0] pb-1">
                            {d.dhikr}
                          </p>
                          <div className="flex items-center justify-between gap-4 font-bold">
                            <span className="text-[#77798C]">العدد:</span>
                            <span className="text-[#4145C7] tabular-nums">
                              {d.count.toLocaleString('ar-EG')} تسبيحة ({d.percentage}%)
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" name="عدد التسبيحات" radius={[0, 8, 8, 0]} maxBarSize={28}>
                  {dhikrChartData.map((_, idx) => (
                    <Cell
                      key={`dhikr-bar-${idx}`}
                      fill={idx === 0 ? '#5B5FEF' : '#72B7E8'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};
