import React, { useState, useMemo, useRef } from 'react';
import { 
  User as UserIcon, 
  Mail, 
  Calendar, 
  MapPin, 
  Flame, 
  Trophy, 
  Sparkles, 
  BookOpen, 
  BookMarked, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  LogOut, 
  Trash2, 
  Shield, 
  Key, 
  Camera, 
  Edit3, 
  Save, 
  X, 
  Cloud, 
  Fingerprint, 
  Clock,
  ArrowRight,
  Award,
  Lock,
  Check
} from 'lucide-react';
import { evaluateAchievementBadges, AchievementBadgeStatus } from '../../utils/achievementBadges';
import { useAuth } from '../../context/AuthContext';
import { increment } from 'firebase/firestore';
import { 
  updateProfile, 
  updatePassword, 
  updateEmail, 
  deleteUser, 
  sendEmailVerification, 
  doc, 
  db, 
  setDoc,
  updateDoc, 
  deleteDoc, 
  getAuthErrorMessage,
  compressAvatarFileToDataUrl,
  updateUserAvatarEverywhere,
  getSavedUserAvatar,
  setSavedUserDisplayName
} from '../../utils/firebase';
import { 
  calculateTotalLifetimeTasbeeh, 
  calculateStreaks, 
  calculateRank, 
  loadHistory, 
  loadCustomAthkar 
} from '../../utils/storage';
import { loadHadithFavorites } from '../../utils/hadithStorage';
import { loadKhatmah } from '../../utils/quranService';
import { getAppLockSettings, saveAppLockSettings, isBiometricAvailable, promptBiometricAuth } from '../../utils/appLock';
import { ScreenType } from '../../types';

interface ProfileViewProps {
  onNavigate: (screen: ScreenType) => void;
  onOpenAuth: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  onNavigate,
  onOpenAuth,
}) => {
  const { 
    currentUser, 
    userProfile, 
    isAdmin,
    syncStatus, 
    lastSyncedAt, 
    triggerCloudSync, 
    logout, 
    refreshUserProfile 
  } = useAuth();

  // Local State
  const [activeTab, setActiveTab] = useState<'overview' | 'settings' | 'security'>('overview');
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Edit fields
  const [name, setName] = useState(userProfile?.displayName || currentUser?.displayName || 'مستخدم رِفْق');
  const [bio, setBio] = useState(userProfile?.bio || 'اللهم اجعل لساني عامراً بذكرك، وقلبي بخشيتك.');
  const [city, setCity] = useState(userProfile?.city || '');
  const [localPhotoUrl, setLocalPhotoUrl] = useState<string | null>(
    userProfile?.photoURL || getSavedUserAvatar(currentUser?.uid) || currentUser?.photoURL || null
  );
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  // Password & Email Change fields
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [newEmail, setNewEmail] = useState('');

  // Delete Account Confirmation
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  // Biometric / App Lock State
  const [lockSettings, setLockSettings] = useState(getAppLockSettings());
  const [biometricSupported, setBiometricSupported] = useState(false);
  const [selectedBadgeModal, setSelectedBadgeModal] = useState<AchievementBadgeStatus | null>(null);

  // Avatar file upload ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check biometric support on mount
  React.useEffect(() => {
    isBiometricAvailable().then(setBiometricSupported);
  }, []);

  // Update edit form when userProfile changes
  React.useEffect(() => {
    if (userProfile) {
      setName(userProfile.displayName || currentUser?.displayName || 'مستخدم رِفْق');
      setBio(userProfile.bio || 'اللهم اجعل لساني عامراً بذكرك، وقلبي بخشيتك.');
      setCity(userProfile.city || '');
      const resolvedPhoto =
        userProfile.photoURL ||
        getSavedUserAvatar(currentUser?.uid) ||
        currentUser?.photoURL ||
        null;
      if (resolvedPhoto) {
        setLocalPhotoUrl(resolvedPhoto);
      }
    } else if (currentUser) {
      const resolvedPhoto = getSavedUserAvatar(currentUser.uid) || currentUser.photoURL || null;
      if (resolvedPhoto) {
        setLocalPhotoUrl(resolvedPhoto);
      }
    }
  }, [userProfile, currentUser]);

  // Compute Live Calculated Statistics
  const realStats = useMemo(() => {
    const history = loadHistory();
    const totalTasbeeh = calculateTotalLifetimeTasbeeh(history);
    const { currentStreak, longestStreak } = calculateStreaks(history);
    const rank = calculateRank(totalTasbeeh);
    const customAthkar = loadCustomAthkar();
    const hadithFavs = loadHadithFavorites();
    const khatmah = loadKhatmah();

    // Total completed Athkar in history
    const completedAthkar = Object.values(history).reduce(
      (acc, r) => acc + (r.completedAthkarCount || 0), 
      0
    );

    return {
      totalTasbeeh,
      currentStreak,
      longestStreak,
      rank,
      completedAthkar,
      customAthkarCount: customAthkar.length,
      hadithFavoritesCount: hadithFavs.length,
      khatmahCount: khatmah.readSurahs?.length || 0,
      khatmahPages: khatmah.completedAyahsCount || 0,
      achievements: evaluateAchievementBadges(history)
    };
  }, [lastSyncedAt, currentUser]);

  // Formatted join date
  const joinDate = useMemo(() => {
    if (currentUser?.metadata?.creationTime) {
      try {
        const d = new Date(currentUser.metadata.creationTime);
        return d.toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' });
      } catch {
        return 'حديث الانضمام';
      }
    }
    return 'حديث الانضمام';
  }, [currentUser]);

  // Format Sync Time
  const formattedSyncTime = useMemo(() => {
    if (!lastSyncedAt) return 'لم تتم المزامنة بعد';
    const d = new Date(lastSyncedAt);
    return d.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
  }, [lastSyncedAt]);

  // Save Profile Changes
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const trimmedName = name.trim() || 'ذاكر لله';
      setSavedUserDisplayName(currentUser.uid, trimmedName);

      // 1. Update Firebase Auth displayName
      try {
        await updateProfile(currentUser, { displayName: trimmedName });
      } catch {
        // Ignore if Auth update fails
      }

      // 2. Update Firestore Doc safely with setDoc merge
      const userRef = doc(db, 'users', currentUser.uid);
      await setDoc(
        userRef,
        {
          uid: currentUser.uid,
          displayName: trimmedName,
          bio: bio.trim(),
          city: city.trim(),
          ...(localPhotoUrl ? { photoURL: localPhotoUrl } : {}),
          updatedAt: new Date().toISOString()
        },
        { merge: true }
      );

      await refreshUserProfile();
      setIsEditing(false);
      setSuccessMsg('تم حفظ بيانات الملف الشخصي بنجاح ✅');
    } catch (error: unknown) {
      const err = error as { code?: string; message?: string };
      setErrorMsg(getAuthErrorMessage(err.code || ''));
    } finally {
      setLoading(false);
    }
  };

  // Avatar Image Upload
  const handleAvatarFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    // Reset input value so picking the same image again still triggers onChange
    e.target.value = '';

    setIsUploadingAvatar(true);
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      const compressedDataUrl = await compressAvatarFileToDataUrl(file, 256, 0.84);
      // Update UI immediately
      setLocalPhotoUrl(compressedDataUrl);

      // Save in LocalStorage, Firestore (and Firebase Auth if short enough)
      await updateUserAvatarEverywhere(currentUser, compressedDataUrl);
      await refreshUserProfile();
      setSuccessMsg('تم تحديث صورة الملف الشخصي بنجاح 🌟');
    } catch (err) {
      console.warn('Avatar update issue:', err);
      setErrorMsg(
        err instanceof Error && err.message
          ? err.message
          : 'تعذر رفع الصورة، يرجى المحاولة مرة أخرى.'
      );
    } finally {
      setIsUploadingAvatar(false);
      setLoading(false);
    }
  };

  // Preset Spiritual Avatar select
  const handleSelectPresetAvatar = async (avatarEmoji: string) => {
    if (!currentUser) return;
    setIsUploadingAvatar(true);
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      const avatarUrl = `emoji:${avatarEmoji}`;
      setLocalPhotoUrl(avatarUrl);
      await updateUserAvatarEverywhere(currentUser, avatarUrl);
      await refreshUserProfile();
      setSuccessMsg('تم اختيار الرمز التعبيري كصورة شخصية ✅');
    } catch {
      setErrorMsg('تعذر تحديث الصورة الشخصية.');
    } finally {
      setIsUploadingAvatar(false);
      setLoading(false);
    }
  };

  // Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setErrorMsg(null);
    setSuccessMsg(null);

    if (newPassword.length < 8) {
      setErrorMsg('كلمة المرور يجب أن لا تقل عن 8 أحرف.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setErrorMsg('كلمتا المرور غير متطابقتين.');
      return;
    }

    setLoading(true);
    try {
      await updatePassword(currentUser, newPassword);
      setNewPassword('');
      setConfirmPassword('');
      setSuccessMsg('تم تغيير كلمة المرور بنجاح ✅');
    } catch (error: unknown) {
      const err = error as { code?: string; message?: string };
      setErrorMsg(getAuthErrorMessage(err.code || ''));
    } finally {
      setLoading(false);
    }
  };

  // Change Email
  const handleChangeEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !newEmail.trim()) return;
    setErrorMsg(null);
    setSuccessMsg(null);

    setLoading(true);
    try {
      await updateEmail(currentUser, newEmail.trim());
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, { email: newEmail.trim() });
      await sendEmailVerification(currentUser);
      await refreshUserProfile();
      setNewEmail('');
      setSuccessMsg('تم إرسال رابط تأكيد إلى البريد الجديد، يرجى تفعيله ✅');
    } catch (error: unknown) {
      const err = error as { code?: string; message?: string };
      setErrorMsg(getAuthErrorMessage(err.code || ''));
    } finally {
      setLoading(false);
    }
  };

  // Toggle Biometric Lock
  const handleToggleBiometricLock = async () => {
    if (!lockSettings.isEnabled) {
      // Activating lock: try biometric test
      if (biometricSupported) {
        const passed = await promptBiometricAuth();
        if (passed) {
          const updated = { isEnabled: true, type: 'biometric' as const };
          saveAppLockSettings(updated);
          setLockSettings(updated);
          setSuccessMsg('تم تفعيل حماية التطبيق بالبصمة بنجاح 🔒');
          return;
        }
      }
      // Fallback or pin
      const updated = { isEnabled: true, type: 'biometric' as const };
      saveAppLockSettings(updated);
      setLockSettings(updated);
      setSuccessMsg('تم تفعيل قفل الأمان للتطبيق 🔒');
    } else {
      const updated = { isEnabled: false, type: 'biometric' as const };
      saveAppLockSettings(updated);
      setLockSettings(updated);
      setSuccessMsg('تم إيقاف قفل الأمان.');
    }
  };

  // Delete Account
  const handleDeleteAccount = async () => {
    if (!currentUser || deleteConfirmText !== 'حذف نهائي') {
      setErrorMsg('يرجى كتابة عبارة "حذف نهائي" للتأكيد.');
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    try {
      const uid = currentUser.uid;
      // 1. Delete notification device doc if exists
      try {
        await deleteDoc(doc(db, 'notification_devices', uid));
      } catch {
        // Ignore
      }

      // 2. Delete Firestore user document
      const userRef = doc(db, 'users', uid);
      await deleteDoc(userRef);

      // 3. Atomically decrement global user counter
      try {
        await setDoc(
          doc(db, 'system_stats', 'global'),
          {
            totalUsersCount: increment(-1),
            updatedAt: new Date().toISOString(),
          },
          { merge: true }
        );
      } catch {
        // Ignore if offline
      }

      // 4. Delete Firebase Auth User
      await deleteUser(currentUser);

      setShowDeleteModal(false);
      onNavigate('tasbeeh');
    } catch (error: unknown) {
      const err = error as { code?: string; message?: string };
      setErrorMsg(getAuthErrorMessage(err.code || ''));
    } finally {
      setLoading(false);
    }
  };

  // Resend Email Verification
  const handleResendEmailVerification = async () => {
    if (!currentUser) return;
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      await sendEmailVerification(currentUser);
      setSuccessMsg('تم إرسال رابط تأكيد جديد إلى بريدك الإلكتروني بنجاح!');
    } catch (error: unknown) {
      setErrorMsg(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  // Refresh Email Verification State
  const handleRefreshEmailVerification = async () => {
    if (!currentUser) return;
    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);
    try {
      await currentUser.reload();
      await refreshUserProfile();
      if (currentUser.emailVerified) {
        setSuccessMsg('تم تأكيد بريدك الإلكتروني بنجاح ✅');
      } else {
        setErrorMsg('لم يتم تأكيد البريد بعد. يرجى فتح الرسالة في بريدك والضغط على الرابط أولاً.');
      }
    } catch (error: unknown) {
      setErrorMsg(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  // If user is not logged in: Show Guest Banner with invitation to log in
  if (!currentUser) {
    return (
      <div className="w-full max-w-2xl mx-auto space-y-6 animate-fade-in font-tajawal" dir="rtl">
        
        {/* Banner */}
        <div className="bg-gradient-to-br from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white p-6 sm:p-8 rounded-3xl shadow-xl border border-[#E6E6F0] relative overflow-hidden">
          <div className="absolute -left-10 -bottom-10 w-48 h-48 bg-[#EEEEFF] rounded-full blur-2xl" />
          
          <div className="relative z-10 flex flex-col sm:flex-row items-center gap-6 text-center sm:text-right">
            <div className="w-24 h-24 rounded-3xl bg-white/10 border-2 border-[#5B5FEF] flex items-center justify-center text-4xl shadow-inner shrink-0">
              📿
            </div>
            
            <div className="space-y-2 flex-1">
              <span className="inline-block px-3 py-1 bg-amber-400/20 text-amber-300 text-xs font-black rounded-full border border-amber-400/30">
                حسابك السحابي الآمن
              </span>
              <h2 className="text-2xl font-black text-amber-200">
                مرحباً بك في مسبحة رفيق المسلم
              </h2>
              <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed max-w-md">
                قم بتسجيل الدخول لحفظ تسبيحاتك، ومزامنة أذكارك وإحصائياتك عبر جميع أجهزتك، والحصول على مرتبتك الإيمانية الموثقة.
              </p>
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-white/15 flex flex-wrap items-center justify-center sm:justify-start gap-3 relative z-10">
            <button
              onClick={onOpenAuth}
              className="px-6 py-3 bg-white hover:bg-[#F7F7FC] text-[#4145C7] font-black text-sm rounded-2xl shadow-lg flex items-center gap-2 transition-transform active:scale-95 cursor-pointer"
            >
              <UserIcon className="w-4 h-4 text-[#5B5FEF]" />
              <span>تسجيل الدخول إلى رِفْق</span>
            </button>

            <button
              onClick={() => onNavigate('tasbeeh')}
              className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-2xl border border-white/20 transition-colors cursor-pointer"
            >
              متابعة التسبيح بدون حساب
            </button>
          </div>
        </div>

        {/* Current Local Stats Preview */}
        <div className="bg-white p-5 rounded-3xl shadow-sm border border-[#E6E6F0] space-y-4">
          <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
            <h3 className="font-black text-sm text-[#4145C7] flex items-center gap-2">
              <Trophy className="w-4 h-4 text-[#5B5FEF]" />
              <span>إحصائياتك المحلية الحالية على هذا الجهاز</span>
            </h3>
            <span className="text-[11px] text-[#77798C] bg-gray-100 px-2.5 py-1 rounded-full">
              محلياً (غير متزامن سحابياً)
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-center">
              <div className="text-xl font-black text-[#4145C7]">{realStats.totalTasbeeh.toLocaleString('ar-SA')}</div>
              <div className="text-[11px] text-[#77798C] mt-1 font-bold">إجمالي التسبيحات</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-center">
              <div className="text-xl font-black text-[#4145C7] flex items-center justify-center gap-1">
                <span>{realStats.currentStreak}</span>
                <Flame className="w-4 h-4 fill-amber-500" />
              </div>
              <div className="text-[11px] text-[#77798C] mt-1 font-bold">أيام الاستمرارية</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-center">
              <div className="text-xl font-black text-[#4CAF82]">{realStats.completedAthkar}</div>
              <div className="text-[11px] text-[#77798C] mt-1 font-bold">الأذكار المكتملة</div>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-center">
              <div className="text-xs font-black text-purple-700">{realStats.rank.name}</div>
              <div className="text-[11px] text-[#77798C] mt-1 font-bold">المرتبة الحالية</div>
            </div>
          </div>

          {/* Guest Earned Badges Preview */}
          <div className="pt-3 border-t border-[#E6E6F0] space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-black text-[#25263A] flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#E8B84A]" />
                <span>شارات ومكافآت الإنجاز ({realStats.achievements.unlockedBadges.length} / {realStats.achievements.badges.length})</span>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('harvest')}
                className="text-[11px] font-black text-[#5B5FEF] hover:underline cursor-pointer"
              >
                عرض في حصاد الأعمال ←
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {realStats.achievements.badges.slice(0, 4).map((badge) => (
                <div
                  key={badge.id}
                  onClick={() => onNavigate('harvest')}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer ${
                    badge.isUnlocked
                      ? 'bg-gradient-to-br from-[#FFFDF7] to-[#EEEEFF]/50 border-[#E8B84A]/60 shadow-2xs'
                      : 'bg-[#F7F7FC] border-[#E6E6F0] opacity-75'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xl">{badge.icon}</span>
                    {badge.isUnlocked ? (
                      <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-[#4CAF82]/15 text-[#4CAF82]">
                        مكتسبة
                      </span>
                    ) : (
                      <Lock className="w-3 h-3 text-[#77798C]" />
                    )}
                  </div>
                  <div className="text-[11px] font-black text-[#25263A] truncate">{badge.title}</div>
                  <div className="text-[10px] text-[#77798C] truncate">{badge.subtitle}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    );
  }

  // Logged-in User Profile Render
  const photoUrl = localPhotoUrl || userProfile?.photoURL || getSavedUserAvatar(currentUser?.uid) || currentUser?.photoURL;
  const isEmojiAvatar = photoUrl?.startsWith('emoji:');
  const emojiChar = isEmojiAvatar ? photoUrl.replace('emoji:', '') : '📿';

  return (
    <div className="w-full max-w-3xl mx-auto space-y-5 animate-fade-in font-tajawal" dir="rtl">
      
      {/* Hidden File Input for Avatar Upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleAvatarFileChange}
        className="hidden"
      />

      {/* Notifications / Alerts */}
      {successMsg && (
        <div className="p-3.5 rounded-2xl bg-[#4CAF82]/12 border border-[#4CAF82]/40 text-[#4CAF82] text-xs font-bold flex items-center justify-between shadow-xs animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />
            <span>{successMsg}</span>
          </div>
          <button onClick={() => setSuccessMsg(null)} className="text-[#4CAF82] hover:text-[#4CAF82]">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-300 text-rose-900 text-xs font-bold flex items-center justify-between shadow-xs animate-shake">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button onClick={() => setErrorMsg(null)} className="text-rose-700 hover:text-rose-900">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ════════════════ USER PROFILE HERO CARD ════════════════ */}
      <div className="bg-gradient-to-br from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white rounded-3xl p-5 sm:p-7 shadow-xl border border-[#E6E6F0] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#EEEEFF] rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-5">
          
          {/* Avatar with Gold Frame */}
          <div className="relative group shrink-0">
            <div
              onClick={() => fileInputRef.current?.click()}
              title="اضغط لتغيير صورة الملف الشخصي"
              className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-[#E8B84A] via-amber-200 to-[#E8B84A] shadow-lg flex items-center justify-center cursor-pointer"
            >
              <div className="w-full h-full rounded-full bg-[#5B5FEF] overflow-hidden flex items-center justify-center relative">
                {photoUrl && !isEmojiAvatar ? (
                  <img
                    src={photoUrl}
                    alt={currentUser.displayName || 'المستخدم'}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <span className="text-4xl select-none">{emojiChar}</span>
                )}
                {isUploadingAvatar && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <RefreshCw className="w-6 h-6 text-white animate-spin" />
                  </div>
                )}
              </div>
            </div>

            {/* Change Avatar Button */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploadingAvatar}
              title="تغيير صورة الملف الشخصي"
              className="absolute bottom-0 left-0 p-2 rounded-full bg-[#E8B84A] text-[#25263A] shadow-md hover:bg-amber-300 transition-transform active:scale-95 cursor-pointer"
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          {/* User Details */}
          <div className="flex-1 text-center sm:text-right space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-2xl font-black text-amber-200 flex items-center justify-center sm:justify-start gap-2">
                  <span>{userProfile?.displayName || currentUser.displayName || 'ذاكر لله'}</span>
                  {currentUser.emailVerified && (
                    <span title="بريد إلكتروني موثّق">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-400/20" />
                    </span>
                  )}
                </h2>
                <div className="text-xs text-emerald-100 flex items-center justify-center sm:justify-start gap-2 mt-0.5">
                  <Mail className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span dir="ltr">{currentUser.email || 'حساب بدون بريد'}</span>
                </div>
              </div>

              {/* Action Buttons: Edit Profile & Sync */}
              <div className="flex items-center justify-center sm:justify-end gap-2 pt-1 sm:pt-0 flex-wrap">
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => onNavigate('admin')}
                    className="px-3.5 py-2 bg-white text-[#4145C7] hover:bg-[#EEEEFF] border border-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                  >
                    <Shield className="w-3.5 h-3.5 text-[#5B5FEF]" />
                    <span>لوحة الإدارة</span>
                  </button>
                )}
                <button
                  onClick={() => triggerCloudSync()}
                  disabled={syncStatus === 'syncing'}
                  className="px-3.5 py-2 bg-white/10 hover:bg-white/20 border border-white/20 rounded-xl text-xs font-bold text-amber-200 flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-50"
                  title="مزامنة فورية لكافة الأجهزة"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${syncStatus === 'syncing' ? 'animate-spin text-amber-300' : ''}`} />
                  <span>{syncStatus === 'syncing' ? 'جارِ المزامنة...' : 'مزامنة سحابية'}</span>
                </button>

                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="px-3.5 py-2 bg-[#5B5FEF] hover:bg-amber-300 text-[#4145C7] rounded-xl text-xs font-black flex items-center gap-1.5 transition-transform active:scale-95 cursor-pointer shadow-xs"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditing ? 'إلغاء التعديل' : 'تعديل البيانات'}</span>
                </button>
              </div>
            </div>

            {/* Bio */}
            <p className="text-xs text-white/90 leading-relaxed italic bg-white/10 px-3 py-2 rounded-xl border border-white/10 max-w-xl">
              «{userProfile?.bio || 'اللهم اجعل لساني عامراً بذكرك، وقلبي بخشيتك.'}»
            </p>

            {/* Metadata tags */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 pt-1 text-[11px] text-emerald-100">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[#5B5FEF]" />
                <span>انضم في: {joinDate}</span>
              </span>
              {userProfile?.city && (
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>{userProfile.city}</span>
                </span>
              )}
              <span className="flex items-center gap-1 bg-white/10 px-2 py-0.5 rounded-md border border-white/10">
                <Cloud className="w-3.5 h-3.5 text-emerald-300" />
                <span>آخر مزامنة: {formattedSyncTime}</span>
              </span>
              <span className="flex items-center gap-1 bg-[#E8B84A]/20 text-amber-200 px-2.5 py-0.5 rounded-md border border-[#E8B84A]/40 font-black">
                <Award className="w-3.5 h-3.5 text-[#E8B84A]" />
                <span>{realStats.achievements.unlockedBadges.length} شارات مكتسبة</span>
              </span>
            </div>

            {/* Quick Earned Badges Strip on Hero Card */}
            {realStats.achievements.unlockedBadges.length > 0 && (
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 pt-1">
                {realStats.achievements.unlockedBadges.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setSelectedBadgeModal(b)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 border border-amber-300/40 text-[11px] font-black text-amber-100 transition-transform active:scale-95 cursor-pointer shadow-2xs"
                    title={b.description}
                  >
                    <span>{b.icon}</span>
                    <span>{b.title}</span>
                  </button>
                ))}
              </div>
            )}

            {/* Email Unverified Warning Banner */}
            {!currentUser.emailVerified && currentUser.email && (
              <div className="mt-3 p-2.5 bg-amber-500/20 border border-amber-400/40 rounded-xl text-xs text-amber-200 flex flex-wrap items-center justify-between gap-2">
                <span>البريد الإلكتروني لم يتم تفعيله بعد.</span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleRefreshEmailVerification}
                    disabled={loading}
                    className="px-2.5 py-1 bg-white/20 text-white font-bold rounded-lg text-[11px] hover:bg-white/30 cursor-pointer"
                  >
                    تحققت الآن
                  </button>
                  <button
                    type="button"
                    onClick={handleResendEmailVerification}
                    disabled={loading}
                    className="px-2.5 py-1 bg-amber-400 text-[#4145C7] font-black rounded-lg text-[11px] hover:bg-amber-300 cursor-pointer"
                  >
                    إرسال رابط التفعيل
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Spiritual Preset Avatars Row */}
        <div className="mt-4 pt-3 border-t border-white/15 flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <span className="text-[11px] text-emerald-100 shrink-0 font-bold">أفاتار إسلامي:</span>
          {['📿', '📖', '🕌', '🌙', '⭐', '🌿', '🤲'].map((emoji) => (
            <button
              key={emoji}
              type="button"
              onClick={() => handleSelectPresetAvatar(emoji)}
              className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 flex items-center justify-center text-base transition-transform hover:scale-110 cursor-pointer shrink-0"
              title={`اختيار ${emoji}`}
            >
              {emoji}
            </button>
          ))}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-1.5 rounded-xl bg-[#E8B84A] hover:bg-amber-300 text-[#25263A] font-black text-[11px] mr-2 shrink-0 flex items-center gap-1.5 shadow-2xs cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>تغيير صورة الملف الشخصي 📁</span>
          </button>
        </div>

      </div>

      {/* ════════════════ EDIT FORM (COLLAPSIBLE) ════════════════ */}
      {isEditing && (
        <form onSubmit={handleSaveProfile} className="bg-white p-5 rounded-3xl border border-[#E6E6F0] shadow-md space-y-4 animate-fade-in">
          <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
            <h3 className="text-sm font-black text-[#4145C7] flex items-center gap-1.5">
              <Edit3 className="w-4 h-4 text-[#5B5FEF]" />
              <span>تعديل بيانات الملف الشخصي</span>
            </h3>
            <button
              type="button"
              onClick={() => setIsEditing(false)}
              className="text-xs text-[#77798C] hover:text-[#25263A] cursor-pointer"
            >
              إلغاء
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-700">الاسم الكامل:</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 focus:border-[#5B5FEF] text-sm outline-hidden bg-[#F7F7FC]"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-700">المدينة / الدولة:</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 focus:border-[#5B5FEF] text-sm outline-hidden bg-[#F7F7FC]"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-700">النبذة الشخصية (Bio):</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={2}
              maxLength={150}
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-300 focus:border-[#5B5FEF] text-sm outline-hidden bg-[#F7F7FC]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-amber-200 text-xs font-black rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>حفظ التعديلات في السحابة</span>
            </button>
          </div>
        </form>
      )}

      {/* ════════════════ TAB CONTROLS ════════════════ */}
      <div className="flex items-center justify-between border-b border-[#E6E6F0] bg-white px-3 py-1.5 rounded-2xl shadow-2xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
            activeTab === 'overview'
              ? 'bg-[#5B5FEF] text-amber-200 shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A]'
          }`}
        >
          📊 الإحصائيات الحقيقية
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-[#5B5FEF] text-amber-200 shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A]'
          }`}
        >
          ⚙️ إعدادات الحساب
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all cursor-pointer ${
            activeTab === 'security'
              ? 'bg-[#5B5FEF] text-amber-200 shadow-xs'
              : 'text-[#77798C] hover:text-[#25263A]'
          }`}
        >
          🔒 الأمان والقفل
        </button>
      </div>

      {/* ════════════════ TAB 1: REAL CALCULATED STATS ════════════════ */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          {/* Main 4 Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            
            <div className="bg-white p-4 rounded-3xl border border-[#E6E6F0] shadow-2xs text-center relative overflow-hidden group hover:border-[#5B5FEF] transition-colors">
              <div className="text-2xl mb-1">📿</div>
              <div className="text-xl sm:text-2xl font-black text-[#4145C7]">
                {realStats.totalTasbeeh.toLocaleString('ar-SA')}
              </div>
              <div className="text-xs font-bold text-[#77798C] mt-0.5">إجمالي التسبيحات</div>
              <div className="text-[10px] text-gray-400 mt-1">طوال فترة استخدامك</div>
            </div>

            <div className="bg-white p-4 rounded-3xl border border-[#E6E6F0] shadow-2xs text-center relative overflow-hidden group hover:border-[#5B5FEF] transition-colors">
              <div className="text-2xl mb-1">🔥</div>
              <div className="text-xl sm:text-2xl font-black text-[#4145C7] flex items-center justify-center gap-1">
                <span>{realStats.currentStreak}</span>
                <span className="text-xs font-bold text-[#77798C]">يوم</span>
              </div>
              <div className="text-xs font-bold text-[#77798C] mt-0.5">سلسلة المواظبة</div>
              <div className="text-[10px] text-gray-400 mt-1">أطول سلسلة: {realStats.longestStreak} يوم</div>
            </div>

            <div className="bg-white p-4 rounded-3xl border border-[#E6E6F0] shadow-2xs text-center relative overflow-hidden group hover:border-[#5B5FEF] transition-colors">
              <div className="text-2xl mb-1">🌿</div>
              <div className="text-xl sm:text-2xl font-black text-[#4CAF82]">
                {realStats.completedAthkar}
              </div>
              <div className="text-xs font-bold text-[#77798C] mt-0.5">أذكار مكتملة</div>
              <div className="text-[10px] text-gray-400 mt-1">صباح، مساء، ونوم</div>
            </div>

            <div className="bg-white p-4 rounded-3xl border border-[#E6E6F0] shadow-2xs text-center relative overflow-hidden group hover:border-[#5B5FEF] transition-colors">
              <div className="text-2xl mb-1">{realStats.rank.badge || '⭐'}</div>
              <div className="text-sm font-black text-purple-700 truncate">
                {realStats.rank.name}
              </div>
              <div className="text-xs font-bold text-[#77798C] mt-0.5">المرتبة الإيمانية</div>
              <div className="text-[10px] text-gray-400 mt-1">المستوى {realStats.rank.level}</div>
            </div>

          </div>

          {/* Secondary Stats Breakdown */}
          <div className="bg-white p-5 rounded-3xl border border-[#E6E6F0] shadow-2xs space-y-4">
            <h4 className="text-xs font-black text-gray-700 uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
              <span>حصيلة العبادات والتلاوة</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              
              {/* Quran Khatmat */}
              <div className="p-3.5 rounded-2xl bg-[#EEEEFF]/50 border border-[#E6E6F0]/70 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center text-xl shrink-0">
                  📖
                </div>
                <div>
                  <div className="text-sm font-black text-[#4145C7]">
                    {realStats.khatmahCount} ختمات مكتملة
                  </div>
                  <div className="text-[11px] text-[#4145C7]">
                    {realStats.khatmahPages} صفحة في الختمة الحالية
                  </div>
                </div>
              </div>

              {/* Hadith Read */}
              <div className="p-3.5 rounded-2xl bg-[#4CAF82]/12/50 border border-[#4CAF82]/40/70 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#4CAF82]/12 text-[#4CAF82] flex items-center justify-center shrink-0">
                  <BookMarked className="w-5 h-5 text-[#4CAF82]" />
                </div>
                <div>
                  <div className="text-sm font-black text-[#4CAF82]">
                    {realStats.hadithFavoritesCount} حديث بالمفضلة
                  </div>
                  <div className="text-[11px] text-[#4CAF82]">
                    من الأحاديث الصحيحة الموثقة
                  </div>
                </div>
              </div>

              {/* Custom Athkar */}
              <div className="p-3.5 rounded-2xl bg-blue-50/50 border border-blue-200/70 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center text-xl shrink-0">
                  ✨
                </div>
                <div>
                  <div className="text-sm font-black text-blue-900">
                    {realStats.customAthkarCount} أذكار مخصصة
                  </div>
                  <div className="text-[11px] text-blue-700">
                    أذكار أضفتها بنفسك للمسبحة
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* ════════════════ ACHIEVEMENT BADGES & 7-DAY STREAK REWARDS IN PROFILE ════════════════ */}
          <div className="bg-white p-5 rounded-3xl border border-[#E6E6F0] shadow-2xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E6E6F0] pb-3">
              <div>
                <h4 className="text-sm font-black text-[#25263A] flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#E8B84A]" />
                  <span>شارات ومكافآت الإنجاز</span>
                  <span className="text-[11px] font-black px-2 py-0.5 rounded-lg bg-[#EEEEFF] text-[#5B5FEF]">
                    {realStats.achievements.unlockedBadges.length} / {realStats.achievements.badges.length} مكتسبة
                  </span>
                </h4>
                <p className="text-[11px] text-[#77798C] font-bold mt-0.5">
                  أكمل 7 أيام متتالية من الأذكار للحصول على وسام المواظب السبعي والشارات الرمزية
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('harvest')}
                className="px-3 py-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#5B5FEF] text-[#5B5FEF] hover:text-white text-xs font-black transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>فتح حصاد الأعمال</span>
              </button>
            </div>

            {/* 7-Day Consecutive Athkar Highlight Banner */}
            <div className="p-4 rounded-2xl bg-gradient-to-l from-[#5B5FEF]/10 via-[#EEEEFF]/60 to-[#FFFDF7] border border-[#5B5FEF]/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 border ${
                  realStats.achievements.sevenDayChallenge.isSevenDayBadgeUnlocked
                    ? 'bg-gradient-to-br from-[#E8B84A] to-[#D49B2A] text-white border-amber-300 shadow-sm'
                    : 'bg-white text-[#5B5FEF] border-[#E6E6F0]'
                }`}>
                  🏅
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-[#25263A]">تحدي 7 أيام متتالية من الأذكار</span>
                    {realStats.achievements.sevenDayChallenge.isSevenDayBadgeUnlocked && (
                      <span className="px-2 py-0.5 rounded-md bg-[#4CAF82]/15 text-[#4CAF82] text-[10px] font-black">
                        مُنجز ✓
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#77798C] font-bold mt-0.5">
                    {realStats.achievements.sevenDayChallenge.isSevenDayBadgeUnlocked
                      ? `أحرزت وسام المواظب السبعي (${Math.max(1, realStats.achievements.sevenDayChallenge.completedSevenDayCycles)} مرّة) — سلسلتك الحالية ${realStats.currentStreak} يوم`
                      : `أنجزت ${realStats.achievements.sevenDayChallenge.daysInCurrentCycle} من 7 أيام متتالية — يتبقى ${realStats.achievements.sevenDayChallenge.remainingDaysForNextBadge} أيام لنيل الشارة`}
                  </p>
                </div>
              </div>

              {/* Mini 7-Day Dots */}
              <div className="flex items-center gap-1.5 self-center sm:self-auto">
                {realStats.achievements.sevenDayChallenge.lastSevenDaysChain.map((step) => (
                  <div
                    key={step.dayIndex}
                    title={`${step.label}: ${step.isCompleted ? 'مكتمل' : 'غير مكتمل'}`}
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-black border transition-all ${
                      step.isCompleted
                        ? 'bg-[#4CAF82] text-white border-[#4CAF82] shadow-2xs'
                        : step.isCurrentTarget
                        ? 'bg-white text-[#5B5FEF] border-[#5B5FEF] border-dashed'
                        : 'bg-[#F7F7FC] text-[#77798C] border-[#E6E6F0]'
                    }`}
                  >
                    {step.isCompleted ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : step.dayIndex}
                  </div>
                ))}
              </div>
            </div>

            {/* All Symbolic Badges Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              {realStats.achievements.badges.map((badge) => (
                <button
                  key={badge.id}
                  type="button"
                  onClick={() => setSelectedBadgeModal(badge)}
                  className={`text-right p-3.5 rounded-2xl border transition-all flex flex-col justify-between relative overflow-hidden cursor-pointer group ${
                    badge.isUnlocked
                      ? badge.isFeatured7Day
                        ? 'bg-gradient-to-br from-[#FFFBEB] via-white to-[#FEF3C7]/50 border-[#E8B84A] shadow-xs hover:shadow-md'
                        : 'bg-gradient-to-br from-white to-[#EEEEFF]/40 border-[#5B5FEF]/40 shadow-2xs hover:border-[#5B5FEF]'
                      : 'bg-[#F7F7FC] border-[#E6E6F0] opacity-80 hover:opacity-100'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center text-2xl border transition-transform group-hover:scale-105 ${
                        badge.isUnlocked
                          ? badge.isFeatured7Day
                            ? 'bg-gradient-to-br from-[#E8B84A] to-[#D49B2A] text-white border-amber-300 shadow-xs'
                            : 'bg-[#EEEEFF] border-[#5B5FEF]/30'
                          : 'bg-gray-200/70 border-gray-300 grayscale'
                      }`}>
                        {badge.icon}
                      </div>

                      {badge.isUnlocked ? (
                        <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-[#4CAF82]/15 text-[#4CAF82] text-[10px] font-black">
                          <Check className="w-3 h-3 stroke-[3]" />
                          <span>مكتسبة</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-gray-200/80 text-[#77798C] text-[10px] font-bold">
                          <Lock className="w-3 h-3" />
                          <span>{badge.progressPercent}%</span>
                        </span>
                      )}
                    </div>

                    <h5 className="text-xs font-black text-[#25263A] mb-0.5">{badge.title}</h5>
                    <p className="text-[10px] font-bold text-[#5B5FEF] mb-2">{badge.subtitle}</p>
                  </div>

                  <div className="pt-2 border-t border-[#E6E6F0]/80 mt-1">
                    <div className="flex items-center justify-between text-[10px] font-bold text-[#77798C] mb-1">
                      <span>
                        {Math.min(badge.currentValue, badge.targetValue).toLocaleString('ar-SA')} / {badge.targetValue.toLocaleString('ar-SA')}
                      </span>
                      {badge.isUnlocked && badge.unlockedAt && (
                        <span className="text-[#4CAF82] truncate">{badge.unlockedAt}</span>
                      )}
                    </div>
                    <div className="w-full h-1.5 bg-[#E6E6F0] rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          badge.isUnlocked
                            ? 'bg-gradient-to-l from-[#4CAF82] to-emerald-400'
                            : 'bg-gradient-to-l from-[#5B5FEF] to-[#8C8FF8]'
                        }`}
                        style={{ width: `${badge.progressPercent}%` }}
                      />
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Badge Detail Modal in ProfileView */}
          {selectedBadgeModal && (
            <div
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
              onClick={() => setSelectedBadgeModal(null)}
            >
              <div
                className="bg-white border border-[#E6E6F0] rounded-3xl max-w-sm w-full p-6 shadow-2xl relative text-center space-y-4"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  type="button"
                  onClick={() => setSelectedBadgeModal(null)}
                  className="absolute top-4 left-4 w-8 h-8 rounded-full bg-[#F7F7FC] hover:bg-[#E6E6F0] flex items-center justify-center text-[#77798C] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className={`w-20 h-20 mx-auto rounded-3xl flex items-center justify-center text-4xl border shadow-md ${
                  selectedBadgeModal.isUnlocked
                    ? 'bg-gradient-to-br from-[#FFFBEB] to-[#EEEEFF] border-[#E8B84A]'
                    : 'bg-[#F7F7FC] border-[#E6E6F0] grayscale opacity-75'
                }`}>
                  {selectedBadgeModal.icon}
                </div>

                <div>
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-[11px] font-black mb-1.5 ${
                    selectedBadgeModal.isUnlocked
                      ? 'bg-[#4CAF82]/15 text-[#4CAF82]'
                      : 'bg-gray-100 text-[#77798C]'
                  }`}>
                    {selectedBadgeModal.isUnlocked ? '✨ شارة إنجاز مكتسبة في ملفك الشخصي' : '🔒 شارة قيد الإنجاز'}
                  </span>
                  <h4 className="text-lg font-black text-[#25263A]">{selectedBadgeModal.title}</h4>
                  <p className="text-xs font-bold text-[#5B5FEF] mt-0.5">{selectedBadgeModal.subtitle}</p>
                </div>

                <p className="text-xs text-[#77798C] leading-relaxed bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]">
                  {selectedBadgeModal.description}
                </p>

                <div className="space-y-1.5 text-right">
                  <div className="flex items-center justify-between text-xs font-black">
                    <span className="text-[#77798C]">نسبة الإنجاز:</span>
                    <span className="text-[#5B5FEF]">
                      {Math.min(selectedBadgeModal.currentValue, selectedBadgeModal.targetValue).toLocaleString('ar-SA')} / {selectedBadgeModal.targetValue.toLocaleString('ar-SA')} {selectedBadgeModal.unitLabel}
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-[#E6E6F0] rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        selectedBadgeModal.isUnlocked
                          ? 'bg-gradient-to-l from-[#4CAF82] to-emerald-400'
                          : 'bg-gradient-to-l from-[#5B5FEF] to-[#8C8FF8]'
                      }`}
                      style={{ width: `${selectedBadgeModal.progressPercent}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedBadgeModal(null);
                      onNavigate('harvest');
                    }}
                    className="flex-1 py-2.5 rounded-2xl bg-[#EEEEFF] text-[#5B5FEF] font-black text-xs hover:bg-[#5B5FEF] hover:text-white transition-colors cursor-pointer"
                  >
                    عرض في حصاد الأعمال
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedBadgeModal(null)}
                    className="flex-1 py-2.5 rounded-2xl bg-[#5B5FEF] text-white font-black text-xs hover:bg-[#4B4FD9] transition-colors cursor-pointer"
                  >
                    إغلاق
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ════════════════ TAB 2: ACCOUNT SETTINGS ════════════════ */}
      {activeTab === 'settings' && (
        <div className="bg-white p-5 rounded-3xl border border-[#E6E6F0] shadow-2xs space-y-6">
          
          {/* Linked Providers */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-gray-700 uppercase tracking-wider flex items-center gap-2">
              <Shield className="w-4 h-4 text-[#5B5FEF]" />
              <span>طرق تسجيل الدخول المرتبطة بحسابك</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="p-3 rounded-2xl bg-gray-50 border border-[#E6E6F0] flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#4CAF82]" />
                  <span className="font-bold">البريد الإلكتروني</span>
                </div>
                <span className="text-[#4CAF82] font-bold bg-[#4CAF82]/12 px-2 py-0.5 rounded-md text-[10px]">
                  {currentUser.email ? 'نشط ومربوط' : 'غير مرتبط'}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-gray-50 border border-[#E6E6F0] flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[#5B5FEF]" />
                  <span className="font-bold">حساب Google</span>
                </div>
                <span className={`font-bold px-2 py-0.5 rounded-md text-[10px] ${
                  currentUser.providerData.some((p) => p.providerId === 'google.com')
                    ? 'bg-[#4CAF82]/12 text-[#4CAF82]'
                    : 'bg-gray-200 text-[#77798C]'
                }`}>
                  {currentUser.providerData.some((p) => p.providerId === 'google.com') ? 'نشط ومربوط' : 'غير مرتبط'}
                </span>
              </div>
            </div>
          </div>

          {/* Change Email Section */}
          <form onSubmit={handleChangeEmail} className="space-y-3 pt-4 border-t border-[#E6E6F0]">
            <h4 className="text-xs font-black text-gray-700 flex items-center gap-1.5">
              <Mail className="w-4 h-4 text-[#5B5FEF]" />
              <span>تغيير البريد الإلكتروني:</span>
            </h4>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="البريد الإلكتروني الجديد"
                dir="ltr"
                className="flex-1 px-3.5 py-2 rounded-xl border border-gray-300 text-xs outline-hidden focus:border-[#5B5FEF] bg-[#F7F7FC]"
              />
              <button
                type="submit"
                disabled={loading || !newEmail.trim()}
                className="px-4 py-2 bg-[#5B5FEF] hover:bg-[#4CAF82] text-amber-200 text-xs font-black rounded-xl shadow-xs cursor-pointer disabled:opacity-50"
              >
                تحديث البريد
              </button>
            </div>
          </form>

          {/* Change Password Section */}
          <form onSubmit={handleChangePassword} className="space-y-3 pt-4 border-t border-[#E6E6F0]">
            <h4 className="text-xs font-black text-gray-700 flex items-center gap-1.5">
              <Key className="w-4 h-4 text-[#5B5FEF]" />
              <span>تغيير كلمة المرور:</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="كلمة المرور الجديدة (8 أحرف فأكثر)"
                dir="ltr"
                className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-xs outline-hidden focus:border-[#5B5FEF] bg-[#F7F7FC]"
              />
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="تأكيد كلمة المرور الجديدة"
                dir="ltr"
                className="w-full px-3.5 py-2 rounded-xl border border-gray-300 text-xs outline-hidden focus:border-[#5B5FEF] bg-[#F7F7FC]"
              />
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={loading || !newPassword}
                className="px-4 py-2 bg-[#5B5FEF] hover:bg-[#4CAF82] text-amber-200 text-xs font-black rounded-xl shadow-xs cursor-pointer disabled:opacity-50"
              >
                تحديث كلمة المرور
              </button>
            </div>
          </form>

          {/* Logout & Delete Area */}
          <div className="pt-4 border-t border-[#E6E6F0] flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={logout}
              className="px-4 py-2.5 rounded-2xl bg-gray-100 hover:bg-gray-200 text-[#25263A] text-xs font-black flex items-center gap-2 transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4 text-[#77798C]" />
              <span>تسجيل الخروج من الحساب</span>
            </button>

            <button
              type="button"
              onClick={() => setShowDeleteModal(true)}
              className="px-4 py-2.5 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-black flex items-center gap-2 transition-colors cursor-pointer border border-rose-200"
            >
              <Trash2 className="w-4 h-4 text-rose-600" />
              <span>حذف الحساب والبيانات نهائيًا</span>
            </button>
          </div>

        </div>
      )}

      {/* ════════════════ TAB 3: SECURITY & BIOMETRICS ════════════════ */}
      {activeTab === 'security' && (
        <div className="bg-white p-5 rounded-3xl border border-[#E6E6F0] shadow-2xs space-y-5">
          
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#4CAF82]/12 text-[#4145C7] flex items-center justify-center shrink-0">
              <Fingerprint className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-black text-[#25263A]">
                حماية الشاشات بالبصمة / Face ID / قفل الجهاز
              </h4>
              <p className="text-xs text-[#77798C] leading-relaxed">
                تفعيل التحقق البيومتري عند فتح التطبيق لضمان خصوصية تسبيحاتك وبياناتك الشخصية.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-gray-50 border border-[#E6E6F0] flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-[#25263A]">
                حالة قفل التطبيق:
              </div>
              <div className="text-[11px] text-[#77798C]">
                {lockSettings.isEnabled ? 'مفعل ومحمي ببصمة الإصبع / الوجه' : 'معطّل (الدخول مباشر)'}
              </div>
            </div>

            <button
              onClick={handleToggleBiometricLock}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer shadow-xs ${
                lockSettings.isEnabled
                  ? 'bg-rose-100 text-rose-700 hover:bg-rose-200'
                  : 'bg-[#4145C7] text-amber-200 hover:bg-[#4145C7]'
              }`}
            >
              {lockSettings.isEnabled ? 'إيقاف القفل' : 'تفعيل القفل بالبصمة'}
            </button>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#EEEEFF] border border-[#E6E6F0] text-xs text-[#4145C7] leading-relaxed space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-[#4145C7]">
              <Shield className="w-4 h-4 text-[#5B5FEF]" />
              <span>الأمان السحابي المشفر:</span>
            </div>
            <p>
              تتم حماية كافة بياناتك وأذكارك عبر أنظمة تشفير سحابية آمنة، ويتم تشفير كلمات المرور باستخدام أحدث معايير الأمان المعتمدة.
            </p>
          </div>

        </div>
      )}

      {/* ════════════════ MODAL: DELETE ACCOUNT CONFIRMATION ════════════════ */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs font-tajawal animate-fade-in" dir="rtl">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-rose-300 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-lg font-black text-rose-800">
                تأكيد حذف الحساب نهائياً
              </h3>
              <p className="text-xs text-[#77798C] leading-relaxed">
                هذا الإجراء نهائي ولا يمكن التراجع عنه. سيتم حذف جميع تسبيحاتك، أذكارك المخصصة، سجل الإحصائيات والمفضلة من حسابك السحابي بشكل كامل.
              </p>
            </div>

            <div className="space-y-1 text-right">
              <label className="text-xs font-bold text-gray-700">
                للتأكيد، اكتب عبارة <span className="text-rose-600 font-black">"حذف نهائي"</span> أدناه:
              </label>
              <input
                type="text"
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                placeholder="حذف نهائي"
                className="w-full px-3.5 py-2.5 rounded-xl border border-rose-300 text-center font-bold text-sm outline-hidden focus:border-rose-500 bg-rose-50/50"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteModal(false)}
                className="px-4 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold cursor-pointer"
              >
                إلغاء وتراجع
              </button>

              <button
                type="button"
                onClick={handleDeleteAccount}
                disabled={loading || deleteConfirmText !== 'حذف نهائي'}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black shadow-md cursor-pointer disabled:opacity-50"
              >
                تأكيد الحذف النهائي
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
