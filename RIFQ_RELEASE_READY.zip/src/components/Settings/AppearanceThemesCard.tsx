import React from 'react';
import { Palette, Sun, Moon, Monitor, Check, Sparkles } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { ThemeId, ThemeMode, resolveThemeTokens } from '../../theme/themes';

interface AppearanceThemesCardProps {
  onShowToast?: (msg: string) => void;
}

export const AppearanceThemesCard: React.FC<AppearanceThemesCardProps> = ({
  onShowToast,
}) => {
  const {
    themeId,
    themeMode,
    isDark,
    systemPrefersDark,
    theme,
    availableThemes,
    setThemeId,
    setThemeMode,
  } = useTheme();

  const colors = theme.colors;

  const handleSelectTheme = (id: ThemeId, nameAr: string, emoji: string) => {
    setThemeId(id);
    if (onShowToast) {
      onShowToast(`تم تطبيق ثيم ${emoji} ${nameAr}`);
    }
  };

  const handleSelectMode = (mode: ThemeMode) => {
    setThemeMode(mode);
    if (onShowToast) {
      const label =
        mode === 'light'
          ? '☀️ الوضع الفاتح'
          : mode === 'dark'
          ? '🌙 الوضع الداكن'
          : '⚙️ الوضع التلقائي حسب النظام';
      onShowToast(`تم تفعيل ${label}`);
    }
  };

  const modeLabelAr =
    themeMode === 'system'
      ? `⚙️ تلقائي (${systemPrefersDark ? 'النظام داكن' : 'النظام فاتح'})`
      : isDark
      ? '🌙 داكن'
      : '☀️ فاتح';

  return (
    <section
      aria-label="المظهر والثيمات"
      style={{
        backgroundColor: colors.surface,
        borderColor: colors.border,
        boxShadow: colors.shadow,
        color: colors.text,
      }}
      className="rounded-3xl p-5 sm:p-6 border space-y-5 relative overflow-hidden transition-colors duration-250"
      dir="rtl"
    >
      {/* Top gradient accent bar */}
      <div
        className="absolute top-0 right-0 left-0 h-1.5"
        style={{ background: colors.headerGradient }}
      />

      {/* Section Header + Current Active Theme Banner ("المظهر الحالي") */}
      <div
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b"
        style={{ borderColor: colors.divider }}
      >
        <div className="flex items-center gap-3.5">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border"
            style={{
              backgroundColor: colors.primaryLight,
              borderColor: colors.border,
              color: colors.primary,
            }}
          >
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <h3
              className="text-lg font-black font-cairo"
              style={{ color: colors.text }}
            >
              المظهر والثيمات
            </h3>
            <p
              className="text-xs mt-0.5 font-medium"
              style={{ color: colors.textSecondary }}
            >
              اختر الهوية البصرية الكاملة لتطبيق رِفْق مع تطبيق فوري وحفظ تلقائي
            </p>
          </div>
        </div>

        {/* المظهر الحالي */}
        <div
          className="px-4 py-2.5 rounded-2xl border flex items-center justify-between sm:justify-start gap-3 shrink-0"
          style={{
            backgroundColor: colors.backgroundSecondary,
            borderColor: colors.border,
          }}
        >
          <div>
            <span
              className="block text-[10px] font-bold"
              style={{ color: colors.textMuted }}
            >
              المظهر الحالي
            </span>
            <div className="flex items-center gap-2 mt-0.5">
              <span
                className="text-sm font-black font-cairo"
                style={{ color: colors.primary }}
              >
                {theme.definition.emoji} {theme.definition.nameAr}
              </span>
              <span
                className="text-xs font-bold"
                style={{ color: colors.textSecondary }}
              >
                · {modeLabelAr}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Light / Dark / System Mode Selector */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span
            className="text-xs font-black flex items-center gap-1.5"
            style={{ color: colors.text }}
          >
            <Sparkles className="w-3.5 h-3.5" style={{ color: colors.accent }} />
            <span>وضع الإضاءة (فاتح / داكن / تلقائي):</span>
          </span>
          <span
            className="text-[11px] font-bold"
            style={{ color: colors.textMuted }}
          >
            {themeMode === 'system'
              ? 'يتبع إعدادات جهازك تلقائياً'
              : themeMode === 'dark'
              ? 'الوضع الداكن مفعّل دائماً'
              : 'الوضع الفاتح مفعّل دائماً'}
          </span>
        </div>

        <div
          className="grid grid-cols-3 gap-2 p-1.5 rounded-2xl border"
          style={{
            backgroundColor: colors.background,
            borderColor: colors.border,
          }}
        >
          {[
            { id: 'light' as ThemeMode, label: '☀️ فاتح', icon: Sun },
            { id: 'dark' as ThemeMode, label: '🌙 داكن', icon: Moon },
            {
              id: 'system' as ThemeMode,
              label: '⚙️ تلقائي حسب النظام',
              icon: Monitor,
            },
          ].map((item) => {
            const isActive = themeMode === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectMode(item.id)}
                style={{
                  backgroundColor: isActive ? colors.primary : 'transparent',
                  color: isActive ? colors.buttonText : colors.textSecondary,
                  boxShadow: isActive ? colors.shadowSoft : 'none',
                }}
                className="py-2.5 px-2 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Themes Grid with Real Component Previews */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <span
            className="text-xs font-black"
            style={{ color: colors.text }}
          >
            اختر ثيم التطبيق ({availableThemes.length} ثيمات متكاملة):
          </span>
          <span
            className="text-[11px] font-bold"
            style={{ color: colors.textMuted }}
          >
            معاينة حقيقية للألوان والبطاقات والأزرار
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {availableThemes.map((item) => {
            const isSelected = themeId === item.id;
            // Resolve preview tokens according to the card's theme and current mode
            const previewResolved = resolveThemeTokens(
              item.id,
              item.id === 'day' || item.id === 'girly' ? 'light' : themeMode,
              systemPrefersDark
            );
            const pTokens = previewResolved.tokens;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() =>
                  handleSelectTheme(item.id, item.nameAr, item.emoji)
                }
                style={{
                  backgroundColor: colors.surfaceElevated,
                  borderColor: isSelected ? colors.primary : colors.border,
                  boxShadow: isSelected ? colors.shadowStrong : colors.shadowSoft,
                }}
                className={`group rounded-2xl p-3 text-right border-2 transition-all duration-200 flex flex-col justify-between cursor-pointer ${
                  isSelected ? 'scale-[1.01]' : 'hover:scale-[1.01]'
                }`}
              >
                {/* Real Live Component Mini-Preview Box */}
                <div
                  className="w-full rounded-xl p-3 border space-y-2.5 transition-colors relative overflow-hidden"
                  style={{
                    backgroundColor: pTokens.background,
                    borderColor: pTokens.border,
                  }}
                >
                  {/* Top Header Gradient Strip inside Preview */}
                  <div
                    className="absolute top-0 right-0 left-0 h-1"
                    style={{ background: pTokens.headerGradient }}
                  />

                  {/* Mini Top Bar inside Preview */}
                  <div className="flex items-center justify-between pt-0.5">
                    <div className="flex items-center gap-1.5">
                      <span
                        className="w-2.5 h-2.5 rounded-full inline-block"
                        style={{ backgroundColor: pTokens.primary }}
                      />
                      <span
                        className="text-[10px] font-black font-cairo"
                        style={{ color: pTokens.text }}
                      >
                        رِفْـق | RIFQ
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span
                        className="w-3 h-3 rounded-full border"
                        style={{
                          backgroundColor: pTokens.primary,
                          borderColor: pTokens.border,
                        }}
                        title="اللون الأساسي"
                      />
                      <span
                        className="w-3 h-3 rounded-full border"
                        style={{
                          backgroundColor: pTokens.secondary,
                          borderColor: pTokens.border,
                        }}
                        title="اللون المساند"
                      />
                      <span
                        className="w-3 h-3 rounded-full border"
                        style={{
                          backgroundColor: pTokens.accent,
                          borderColor: pTokens.border,
                        }}
                        title="لون التمييز"
                      />
                      <span
                        className="w-3 h-3 rounded-full border"
                        style={{
                          backgroundColor: pTokens.surface,
                          borderColor: pTokens.border,
                        }}
                        title="لون البطاقة"
                      />
                    </div>
                  </div>

                  {/* Mini Card inside Preview */}
                  <div
                    className="rounded-lg p-2.5 border space-y-1.5"
                    style={{
                      backgroundColor: pTokens.surface,
                      borderColor: pTokens.border,
                      boxShadow: pTokens.shadowSoft,
                    }}
                  >
                    <div
                      className="text-[11px] font-bold leading-snug"
                      style={{ color: pTokens.text }}
                    >
                      أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ
                    </div>
                    <div className="flex items-center justify-between pt-1">
                      <span
                        className="text-[9px] font-bold"
                        style={{ color: pTokens.textMuted }}
                      >
                        الورد اليومي · ٣٣ تسبيحة
                      </span>
                      <span
                        className="px-2 py-0.5 rounded-md text-[9px] font-black"
                        style={{
                          backgroundColor: pTokens.primary,
                          color: pTokens.buttonText,
                        }}
                      >
                        تسبيح
                      </span>
                    </div>
                  </div>
                </div>

                {/* Theme Title, Subtitle & Active Indicator */}
                <div className="mt-3 pt-1 flex items-center justify-between gap-2 w-full">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-base">{item.emoji}</span>
                      <span
                        className="text-sm font-black font-cairo truncate"
                        style={{ color: colors.text }}
                      >
                        {item.nameAr}
                      </span>
                    </div>
                    <p
                      className="text-[11px] truncate mt-0.5"
                      style={{ color: colors.textMuted }}
                    >
                      {item.subtitleAr}
                    </p>
                  </div>

                  {isSelected ? (
                    <span
                      className="px-2.5 py-1 rounded-xl text-[11px] font-black flex items-center gap-1 shrink-0"
                      style={{
                        backgroundColor: colors.primary,
                        color: colors.buttonText,
                      }}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[2.8]" />
                      <span>محدد</span>
                    </span>
                  ) : (
                    <span
                      className="px-2.5 py-1 rounded-xl text-[11px] font-bold border shrink-0 transition-colors"
                      style={{
                        backgroundColor: colors.background,
                        borderColor: colors.border,
                        color: colors.textSecondary,
                      }}
                    >
                      اختيار
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
};
