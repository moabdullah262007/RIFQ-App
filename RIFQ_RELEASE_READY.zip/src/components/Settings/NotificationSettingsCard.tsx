import React, { useState, useEffect, useCallback } from 'react';
import {
  Bell,
  BellOff,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  X,
  Clock,
  ChevronDown,
  ChevronUp,
  Settings,
} from 'lucide-react';
import {
  NotificationManager,
  UnifiedNotificationSettings,
  loadUnifiedNotificationSettings,
  saveUnifiedNotificationSettings,
  subscribeToNotificationSettings,
  syncFullNotificationScheduleWithServiceWorker,
  sendTestNotification,
  openSystemNotificationSettings,
  isNativeAndroidPlatform,
  RIFQ_NOTIFICATION_CHANNELS,
} from '../../utils/notifications';
import { openAppSettings } from '../../utils/permissionManager';

/**
 * ══════════════════════════════════════════════════════════════════════════
 * NotificationSettingsCard — صفحة/بطاقة إعدادات الإشعارات الحقيقية في «رِفْق | RIFQ»
 * - تفحص حالة الصلاحية الفعلية من Android (POST_NOTIFICATIONS + NotificationManagerCompat) أو المتصفح
 * - تعيد الفحص تلقائياً عند العودة للتطبيق (focus / visibilitychange / permissions.onchange)
 * - تعرض "إشعارات الجهاز متوقفة" مع زر "السماح بالإشعارات" عند رفض الإذن ولا تعرض "الإشعارات مفعلة" أبداً إذا كان الإذن مرفوضاً
 * - توفر إعداداً مستقلاً لكل نوع إشعار (أذكار الصباح، أذكار المساء، مواقيت الصلاة، الورد، التذكيرات اليومية، رحلتي، حصاد العبادات، تحديثات التطبيق)
 * - تحدث الجدولة في Android AlarmManager و Service Worker فوراً عند تفعيل/تعطيل أي إشعار أو تعديل وقته
 * - ترسل إشعار نظام Android حقيقي + تسجله في مركز الإشعارات عند الضغط على "إرسال إشعار تجريبي"
 * ══════════════════════════════════════════════════════════════════════════
 */
export const NotificationSettingsCard: React.FC = () => {
  const [loading, setLoading] = useState<boolean>(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(false);
  const [permanentlyBlocked, setPermanentlyBlocked] = useState<boolean>(false);
  const [permissionStateText, setPermissionStateText] = useState<'granted' | 'denied' | 'default'>('default');
  const [unified, setUnified] = useState<UnifiedNotificationSettings>(() =>
    loadUnifiedNotificationSettings()
  );
  const [showDetailedTimes, setShowDetailedTimes] = useState<boolean>(true);
  const [testingSend, setTestingSend] = useState<boolean>(false);

  const [snackMsg, setSnackMsg] = useState<{ success: boolean; text: string } | null>(null);
  const [settingsGuide, setSettingsGuide] = useState<{ title: string; steps: string[] } | null>(
    null
  );

  const checkPermission = useCallback(async () => {
    const detailed = await NotificationManager.getDetailedStatus();
    const enabled = Boolean(detailed.granted && detailed.areNotificationsEnabled);
    const blocked = enabled
      ? false
      : Boolean(detailed.permanentlyBlocked || detailed.postNotificationsPermission === 'denied');

    setNotificationsEnabled(enabled);
    setPermanentlyBlocked(blocked);
    setPermissionStateText(
      enabled
        ? 'granted'
        : blocked || detailed.postNotificationsPermission === 'denied'
        ? 'denied'
        : 'default'
    );
    setUnified(loadUnifiedNotificationSettings());
    setLoading(false);
  }, []);

  useEffect(() => {
    checkPermission();

    const handleResume = () => {
      if (document.visibilityState === 'visible') {
        checkPermission();
      }
    };

    const unsubscribeSettings = subscribeToNotificationSettings((updatedSettings) => {
      setUnified(updatedSettings);
    });

    window.addEventListener('focus', checkPermission);
    document.addEventListener('visibilitychange', handleResume);

    let permStatusObj: PermissionStatus | null = null;
    if (typeof navigator !== 'undefined' && 'permissions' in navigator) {
      navigator.permissions
        .query({ name: 'notifications' as PermissionName })
        .then((status) => {
          permStatusObj = status;
          status.onchange = () => {
            checkPermission();
          };
        })
        .catch(() => {
          // ignore if unsupported
        });
    }

    return () => {
      unsubscribeSettings();
      window.removeEventListener('focus', checkPermission);
      document.removeEventListener('visibilitychange', handleResume);
      if (permStatusObj) {
        permStatusObj.onchange = null;
      }
    };
  }, [checkPermission]);

  const showToast = (success: boolean, text: string) => {
    setSnackMsg({ success, text });
    setTimeout(() => setSnackMsg(null), 4500);
  };

  const handleOpenDeviceNotificationSettings = async (channelId?: string) => {
    if (isNativeAndroidPlatform()) {
      await openSystemNotificationSettings(channelId);
      setTimeout(() => {
        checkPermission();
      }, 1000);
      return;
    }

    const guide = openAppSettings('notifications');
    if (!guide.openedDirectly) {
      setSettingsGuide({
        title: guide.instructions.title,
        steps: guide.instructions.steps,
      });
    }
  };

  const handleRequestOrOpenSettings = async () => {
    if (permanentlyBlocked) {
      await handleOpenDeviceNotificationSettings();
      return;
    }

    const granted = await NotificationManager.requestPermission();
    await checkPermission();

    if (granted) {
      syncFullNotificationScheduleWithServiceWorker();
      const testSent = await sendTestNotification();
      showToast(
        true,
        testSent
          ? 'تم تفعيل إشعارات الجهاز وإرسال إشعار حقيقي لشريط الإشعارات بنجاح'
          : 'تم تفعيل إشعارات الجهاز بنجاح'
      );
    } else {
      showToast(false, 'إشعارات الجهاز متوقفة — اضغط على «السماح بالإشعارات» لتفعيلها من إعدادات التطبيق');
    }
  };

  const handleSendTestNotification = async () => {
    setTestingSend(true);
    try {
      const success = await sendTestNotification();
      await checkPermission();
      showToast(
        success,
        success
          ? 'تم إرسال الإشعار بنجاح إلى شريط إشعارات الجهاز ومركز التذكيرات'
          : 'فشل إرسال الإشعار - تحقق من الإعدادات وصلاحية إشعارات الجهاز'
      );
    } finally {
      setTestingSend(false);
    }
  };

  const handleChannelToggle = (channelId: string, nextValue: boolean) => {
    if (!notificationsEnabled) {
      showToast(false, 'إشعارات الجهاز متوقفة — يرجى السماح بالإشعارات أولاً');
      return;
    }
    NotificationManager.setChannelEnabled(channelId, nextValue);
    setUnified(loadUnifiedNotificationSettings());
    showToast(
      true,
      nextValue
        ? 'تم تفعيل هذا النوع من الإشعارات وتحديث الجدولة على الجهاز'
        : 'تم إيقاف هذا النوع وإلغاء إشعاراته المجدولة'
    );
  };

  const handleSubSettingChange = (
    partial: Partial<UnifiedNotificationSettings>,
    feedbackText?: string
  ) => {
    if (!notificationsEnabled) {
      showToast(false, 'إشعارات الجهاز متوقفة — يرجى السماح بالإشعارات أولاً');
      return;
    }
    const updated = saveUnifiedNotificationSettings(partial);
    setUnified(updated);
    if (feedbackText) {
      showToast(true, feedbackText);
    }
  };

  if (loading) {
    return (
      <div className="bg-[#F7F7FC] rounded-3xl p-6 border border-[#E6E6F0] flex items-center justify-center">
        <div className="w-7 h-7 border-3 border-[#5B5FEF] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const statusBadgeText = notificationsEnabled
    ? 'مفعلة'
    : permanentlyBlocked || permissionStateText === 'denied'
    ? 'غير مفعلة (متوقفة)'
    : 'غير مفعلة';

  const statusTitle = notificationsEnabled
    ? '🔔 إشعارات الجهاز: مفعلة'
    : 'إشعارات الجهاز متوقفة';

  const statusSubtitle = notificationsEnabled
    ? 'تصل إشعارات رِفْق الحقيقية إلى شريط إشعارات Android وشاشة القفل ومركز التذكيرات داخل التطبيق'
    : 'اسمح لرِفْق بإرسال التذكيرات حتى تصلك أوقات الأذكار والمواقيت والتنبيهات المهمة.';

  return (
    <div
      className="bg-[#F7F7FC] rounded-3xl p-5 sm:p-6 shadow-sm border border-[#E6E6F0] space-y-4"
      dir="rtl"
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-black text-[#5B5FEF]">🔔 إشعارات الجهاز والتذكيرات</h3>
          <span
            className={`px-2.5 py-0.5 rounded-full text-[11px] font-black border ${
              notificationsEnabled
                ? 'bg-[#4CAF82]/15 text-[#4CAF82] border-[#4CAF82]/40'
                : 'bg-[#D95C6A]/15 text-[#D95C6A] border-[#D95C6A]/40'
            }`}
          >
            {statusBadgeText}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => handleOpenDeviceNotificationSettings()}
            className="px-3 py-1.5 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="فتح إعدادات إشعارات الجهاز"
          >
            <Settings className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>فتح إعدادات الإشعارات</span>
          </button>

          <button
            type="button"
            onClick={checkPermission}
            className="p-2 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] transition-colors cursor-pointer"
            title="إعادة فحص الحالة الحقيقية من الجهاز"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Real Device Status Card */}
      <div
        className="bg-white rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 border transition-colors"
        style={{
          borderColor: notificationsEnabled ? '#4CAF82' : '#D95C6A',
          borderWidth: '1.5px',
        }}
      >
        <div className="flex items-center gap-3.5">
          {notificationsEnabled ? (
            <div className="w-11 h-11 rounded-2xl bg-[#4CAF82]/12 text-[#4CAF82] flex items-center justify-center shrink-0">
              <Bell className="w-6 h-6" />
            </div>
          ) : (
            <div className="w-11 h-11 rounded-2xl bg-[#D95C6A]/12 text-[#D95C6A] flex items-center justify-center shrink-0">
              <BellOff className="w-6 h-6" />
            </div>
          )}
          <div className="flex-1">
            <div className="font-black text-base text-[#25263A]">{statusTitle}</div>
            <div className="text-xs text-[#77798C] mt-0.5 leading-relaxed">{statusSubtitle}</div>
          </div>
        </div>

        {!notificationsEnabled && (
          <button
            type="button"
            onClick={handleRequestOrOpenSettings}
            className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs shadow-sm transition-all cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
          >
            {permanentlyBlocked && <ExternalLink className="w-3.5 h-3.5" />}
            <span>السماح بالإشعارات</span>
          </button>
        )}
      </div>

      {/* Independent Notification Type Settings (Requirement 15) */}
      <div className="bg-white rounded-2xl border border-[#E6E6F0] overflow-hidden">
        <button
          type="button"
          onClick={() => setShowDetailedTimes((prev) => !prev)}
          className="w-full px-4 py-3.5 flex items-center justify-between text-right hover:bg-[#F7F7FC] transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#5B5FEF]" />
            <span className="text-sm font-black text-[#25263A]">
              إعدادات كل نوع إشعار وأوقات التذكير المجدولة
            </span>
          </div>
          {showDetailedTimes ? (
            <ChevronUp className="w-4 h-4 text-[#77798C]" />
          ) : (
            <ChevronDown className="w-4 h-4 text-[#77798C]" />
          )}
        </button>

        {showDetailedTimes && (
          <div className="p-4 pt-2 border-t border-[#E6E6F0] space-y-2.5 text-xs">
            {/* 1. أذكار الصباح */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">أذكار الصباح ☀️</span>
                <span className="text-[11px] text-[#77798C] block">تذكير يومي يفتح صفحة أذكار الصباح مباشرة</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={unified.morningAthkarTime}
                  disabled={!notificationsEnabled || !unified.morningAthkarEnabled}
                  onChange={(e) =>
                    handleSubSettingChange(
                      { morningAthkarTime: e.target.value, azkarChannelEnabled: true },
                      `تم تحديث موعد أذكار الصباح إلى ${e.target.value} وإعادة جدولة الإشعار`
                    )
                  }
                  className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 font-mono font-bold text-[#4145C7] text-xs disabled:opacity-40 focus:border-[#5B5FEF] focus:outline-hidden"
                />
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.azkarChannelEnabled && unified.morningAthkarEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleSubSettingChange(
                        {
                          morningAthkarEnabled: e.target.checked,
                          ...(e.target.checked ? { azkarChannelEnabled: true } : {}),
                        },
                        e.target.checked
                          ? 'تم تفعيل إشعار أذكار الصباح وجدولته على الجهاز'
                          : 'تم إيقاف إشعار أذكار الصباح وإلغاء جدولته'
                      )
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 2. أذكار المساء */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">أذكار المساء 🌙</span>
                <span className="text-[11px] text-[#77798C] block">تذكير يومي يفتح صفحة أذكار المساء مباشرة</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={unified.eveningAthkarTime}
                  disabled={!notificationsEnabled || !unified.eveningAthkarEnabled}
                  onChange={(e) =>
                    handleSubSettingChange(
                      { eveningAthkarTime: e.target.value, azkarChannelEnabled: true },
                      `تم تحديث موعد أذكار المساء إلى ${e.target.value} وإعادة جدولة الإشعار`
                    )
                  }
                  className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 font-mono font-bold text-[#4145C7] text-xs disabled:opacity-40 focus:border-[#5B5FEF] focus:outline-hidden"
                />
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.azkarChannelEnabled && unified.eveningAthkarEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleSubSettingChange(
                        {
                          eveningAthkarEnabled: e.target.checked,
                          ...(e.target.checked ? { azkarChannelEnabled: true } : {}),
                        },
                        e.target.checked
                          ? 'تم تفعيل إشعار أذكار المساء وجدولته على الجهاز'
                          : 'تم إيقاف إشعار أذكار المساء وإلغاء جدولته'
                      )
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 3. مواقيت الصلاة */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">مواقيت الصلاة والأذان 🕌</span>
                <span className="text-[11px] text-[#77798C] block">جدولة تلقائية حسب مواقيت مدينتك الحقيقية وتفتح صفحة المواقيت</span>
              </div>
              <div className="flex items-center gap-2">
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.adhanChannelEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleChannelToggle(RIFQ_NOTIFICATION_CHANNELS.prayer, e.target.checked)
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 4. الورد القرآني */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">الورد القرآني اليومي 📖</span>
                <span className="text-[11px] text-[#77798C] block">تذكير بقراءة الورد القرآني ويفتح صفحة المصحف والورد</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={unified.quranWirdReminderTime}
                  disabled={!notificationsEnabled || !unified.quranWirdReminderEnabled}
                  onChange={(e) =>
                    handleSubSettingChange(
                      { quranWirdReminderTime: e.target.value, quranChannelEnabled: true },
                      `تم تحديث موعد تذكير الورد القرآني إلى ${e.target.value}`
                    )
                  }
                  className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 font-mono font-bold text-[#4145C7] text-xs disabled:opacity-40 focus:border-[#5B5FEF] focus:outline-hidden"
                />
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.quranChannelEnabled && unified.quranWirdReminderEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleSubSettingChange(
                        {
                          quranWirdReminderEnabled: e.target.checked,
                          ...(e.target.checked ? { quranChannelEnabled: true } : {}),
                        },
                        e.target.checked
                          ? 'تم تفعيل تذكير الورد القرآني'
                          : 'تم إيقاف تذكير الورد القرآني'
                      )
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 5. التذكيرات اليومية والأدعية */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">التذكيرات اليومية ودعاء اليوم 🤲</span>
                <span className="text-[11px] text-[#77798C] block">تذكيرات الأدعية والتسبيح المخصصة وتفتح صفحة التذكيرات</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={unified.duaOfTheDayTime}
                  disabled={!notificationsEnabled || !unified.remindersChannelEnabled}
                  onChange={(e) =>
                    handleSubSettingChange(
                      { duaOfTheDayTime: e.target.value, remindersChannelEnabled: true, duaOfTheDayEnabled: true },
                      `تم ضبط موعد التذكيرات اليومية على ${e.target.value}`
                    )
                  }
                  className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 font-mono font-bold text-[#4145C7] text-xs disabled:opacity-40 focus:border-[#5B5FEF] focus:outline-hidden"
                />
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.remindersChannelEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleChannelToggle(RIFQ_NOTIFICATION_CHANNELS.reminders, e.target.checked)
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 6. رحلتي */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">رحلتي (غراس والرفقة الصالحة) 🌱</span>
                <span className="text-[11px] text-[#77798C] block">تذكير بورد رحلتي اليومي ويفتح صفحة رحلتي مباشرة</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={unified.journeyReminderTime}
                  disabled={!notificationsEnabled || !unified.journeyReminderEnabled}
                  onChange={(e) =>
                    handleSubSettingChange(
                      { journeyReminderTime: e.target.value },
                      `تم ضبط موعد تذكير رحلتي على ${e.target.value}`
                    )
                  }
                  className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 font-mono font-bold text-[#4145C7] text-xs disabled:opacity-40 focus:border-[#5B5FEF] focus:outline-hidden"
                />
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.journeyReminderEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleSubSettingChange(
                        { journeyReminderEnabled: e.target.checked },
                        e.target.checked ? 'تم تفعيل تذكير رحلتي' : 'تم إيقاف تذكير رحلتي'
                      )
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 7. حصاد العبادات */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">حصاد العبادات (المحاسبة اليومية) 🌾</span>
                <span className="text-[11px] text-[#77798C] block">تذكير مسائي لتسجيل عباداتك ويفتح صفحة حصاد العبادات</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={unified.harvestReminderTime}
                  disabled={!notificationsEnabled || !unified.harvestReminderEnabled}
                  onChange={(e) =>
                    handleSubSettingChange(
                      { harvestReminderTime: e.target.value },
                      `تم ضبط موعد تذكير حصاد العبادات على ${e.target.value}`
                    )
                  }
                  className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 font-mono font-bold text-[#4145C7] text-xs disabled:opacity-40 focus:border-[#5B5FEF] focus:outline-hidden"
                />
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.harvestReminderEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleSubSettingChange(
                        { harvestReminderEnabled: e.target.checked },
                        e.target.checked
                          ? 'تم تفعيل تذكير حصاد العبادات'
                          : 'تم إيقاف تذكير حصاد العبادات'
                      )
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 8. أذكار النوم */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">أذكار النوم 🌌</span>
                <span className="text-[11px] text-[#77798C] block">تذكير بأذكار النوم وآية الكرسي قبل ختام اليوم</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="time"
                  value={unified.sleepAthkarTime}
                  disabled={!notificationsEnabled || !unified.sleepAthkarEnabled}
                  onChange={(e) =>
                    handleSubSettingChange(
                      { sleepAthkarTime: e.target.value, azkarChannelEnabled: true },
                      `تم ضبط موعد أذكار النوم على ${e.target.value}`
                    )
                  }
                  className="bg-white border border-[#E6E6F0] rounded-lg px-2 py-1 font-mono font-bold text-[#4145C7] text-xs disabled:opacity-40 focus:border-[#5B5FEF] focus:outline-hidden"
                />
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.azkarChannelEnabled && unified.sleepAthkarEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleSubSettingChange(
                        {
                          sleepAthkarEnabled: e.target.checked,
                          ...(e.target.checked ? { azkarChannelEnabled: true } : {}),
                        },
                        e.target.checked ? 'تم تفعيل إشعار أذكار النوم' : 'تم إيقاف إشعار أذكار النوم'
                      )
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>

            {/* 9. تحديثات التطبيق ومواسم الخير */}
            <div className="flex items-center justify-between gap-2 bg-[#F7F7FC] px-3.5 py-2.5 rounded-xl border border-[#E6E6F0]">
              <div>
                <span className="font-bold text-[#25263A] block">تحديثات التطبيق ومواسم الخير ✨</span>
                <span className="text-[11px] text-[#77798C] block">إشعارات التحديثات والمناسبات الإسلامية</span>
              </div>
              <div className="flex items-center gap-2">
                <label
                  className={`relative inline-flex items-center ${
                    notificationsEnabled ? 'cursor-pointer' : 'cursor-not-allowed opacity-40'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={notificationsEnabled && unified.updatesChannelEnabled}
                    disabled={!notificationsEnabled}
                    onChange={(e) =>
                      handleChannelToggle(RIFQ_NOTIFICATION_CHANNELS.updates, e.target.checked)
                    }
                    className="sr-only peer"
                  />
                  <div className="w-10 h-5 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-2.5">
        {!notificationsEnabled ? (
          <button
            type="button"
            onClick={handleRequestOrOpenSettings}
            className="w-full py-3.5 px-4 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-sm shadow-sm transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            {permanentlyBlocked && <ExternalLink className="w-4 h-4" />}
            <span>السماح بالإشعارات</span>
          </button>
        ) : (
          <button
            type="button"
            disabled={testingSend}
            onClick={handleSendTestNotification}
            className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] font-black text-sm transition-all cursor-pointer disabled:opacity-50"
          >
            {testingSend ? 'جارٍ إرسال إشعار الجهاز...' : 'إرسال إشعار تجريبي لشريط إشعارات الجهاز'}
          </button>
        )}
      </div>

      {/* Real Feedback SnackBar */}
      {snackMsg && (
        <div
          className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
            snackMsg.success ? 'bg-[#5B5FEF] text-white' : 'bg-[#D95C6A] text-white'
          }`}
        >
          {snackMsg.success ? (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0" />
          )}
          <span>{snackMsg.text}</span>
        </div>
      )}

      {/* System Settings Guidance Modal when blocked in OS/Browser */}
      {settingsGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-[#E6E6F0] space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-base font-black text-[#25263A]">{settingsGuide.title}</h4>
              <button
                onClick={() => setSettingsGuide(null)}
                className="p-1.5 rounded-lg hover:bg-gray-100 text-[#77798C] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <ul className="space-y-2 text-xs text-[#25263A] leading-relaxed">
              {settingsGuide.steps.map((step, idx) => (
                <li
                  key={idx}
                  className="p-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] font-bold"
                >
                  {step}
                </li>
              ))}
            </ul>
            <button
              onClick={() => {
                setSettingsGuide(null);
                checkPermission();
              }}
              className="w-full py-3 rounded-xl bg-[#5B5FEF] text-white font-black text-xs cursor-pointer"
            >
              تم التفعيل — إعادة فحص الحالة الآن
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
