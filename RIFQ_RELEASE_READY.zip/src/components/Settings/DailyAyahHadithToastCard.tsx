import React, { useState, useEffect } from 'react';
import {
  Bell,
  Sparkles,
  BookOpen,
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  Check,
  Copy,
  Share2,
  CheckCircle2,
  Calendar,
  History,
  Layers,
  ChevronDown,
  ChevronUp,
  Settings2
} from 'lucide-react';
import {
  DailyAyahHadithToastConfig,
  DailyToastItem,
  loadDailyAyahHadithToastConfig,
  saveDailyAyahHadithToastConfig,
  getDailyItemForToday,
  triggerManualTestToast
} from '../../utils/dailyAyahHadithToastService';
import { soundManager } from '../../utils/audio';

interface DailyAyahHadithToastCardProps {
  onShowToast?: (msg: string) => void;
}

export const DailyAyahHadithToastCard: React.FC<DailyAyahHadithToastCardProps> = ({
  onShowToast,
}) => {
  const [config, setConfig] = useState<DailyAyahHadithToastConfig>(() =>
    loadDailyAyahHadithToastConfig()
  );
  const [todayItem, setTodayItem] = useState<DailyToastItem>(() => getDailyItemForToday(false));
  const [isCopied, setIsCopied] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [isTesting, setIsTesting] = useState(false);

  useEffect(() => {
    setConfig(loadDailyAyahHadithToastConfig());
    setTodayItem(getDailyItemForToday(false));
  }, []);

  const updateConfig = (partial: Partial<DailyAyahHadithToastConfig>) => {
    const updated = { ...config, ...partial };
    setConfig(updated);
    saveDailyAyahHadithToastConfig(updated);
    if (onShowToast) {
      onShowToast('تم حفظ إعدادات التنبيهات المنبثقة بنجاح 🔔');
    }
  };

  const handleTestToast = (type?: 'ayah' | 'hadith') => {
    setIsTesting(true);
    soundManager.triggerHaptic(30);
    const item = triggerManualTestToast(type);
    if (onShowToast) {
      onShowToast(
        item.type === 'ayah'
          ? 'تم إطلاق تنبيه تجريبي: آية قرآنية كريمة'
          : 'تم إطلاق تنبيه تجريبي: حديث نبوي شريف'
      );
    }
    setTimeout(() => setIsTesting(false), 800);
  };

  const handleRefreshTodayItem = () => {
    const newItem = getDailyItemForToday(true);
    setTodayItem(newItem);
    soundManager.triggerHaptic(20);
    if (onShowToast) {
      onShowToast('تم اختيار آية/حديث مبارك جديد لليوم');
    }
  };

  const handleCopyTodayItem = async () => {
    const shareText = `${todayItem.text}\n— ${todayItem.source}`;
    try {
      await navigator.clipboard.writeText(shareText);
      setIsCopied(true);
      soundManager.triggerHaptic(25);
      if (onShowToast) {
        onShowToast('تم نسخ نص الآية/الحديث إلى الحافظة');
      }
      setTimeout(() => setIsCopied(false), 2000);
    } catch {
      // ignore
    }
  };

  const handleShareTodayItem = async () => {
    const shareText = `${todayItem.text}\n— ${todayItem.source}\n(تطبيق رِفْق | الرفيق الإسلامي)`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: todayItem.type === 'ayah' ? 'آية اليوم المباركة' : 'حديث اليوم الشريف',
          text: shareText,
        });
        return;
      } catch {
        // fallback
      }
    }
    handleCopyTodayItem();
  };

  return (
    <section
      aria-label="تنبيهات الآيات والأحاديث المنبثقة اليومية"
      className="rounded-3xl p-5 sm:p-6 border space-y-5 relative overflow-hidden transition-colors duration-250"
      style={{
        backgroundColor: 'var(--theme-surface)',
        borderColor: 'var(--theme-border)',
        boxShadow: 'var(--theme-shadow)',
        color: 'var(--theme-text)',
      }}
      dir="rtl"
    >
      {/* Top accent bar */}
      <div
        className="absolute top-0 right-0 left-0 h-1.5"
        style={{ background: 'var(--theme-header-gradient)' }}
      />

      {/* Header */}
      <div
        className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b"
        style={{ borderColor: 'var(--theme-divider)' }}
      >
        <div className="flex items-center gap-3.5">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border"
            style={{
              backgroundColor: 'var(--theme-primary-light)',
              borderColor: 'var(--theme-border)',
              color: 'var(--theme-primary)',
            }}
          >
            <BookOpen className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-black font-cairo" style={{ color: 'var(--theme-text)' }}>
                تنبيهات الآيات والأحاديث المنبثقة
              </h3>
              <span
                className="px-2 py-0.5 rounded-full text-[10px] font-bold"
                style={{
                  backgroundColor: 'var(--theme-primary-light)',
                  color: 'var(--theme-primary)',
                }}
              >
                Toast Notifications
              </span>
            </div>
            <p className="text-xs mt-0.5 font-medium" style={{ color: 'var(--theme-text-secondary)' }}>
              رسائل منبثقة يومية عشوائية بآية قرآنية محكمة أو حديث نبوي شريف مع إمكانية القراءة والنسخ
            </p>
          </div>
        </div>

        {/* Main Master Switch */}
        <label className="flex items-center gap-2.5 cursor-pointer self-start sm:self-center">
          <span className="text-xs font-bold" style={{ color: 'var(--theme-text-muted)' }}>
            {config.enabled ? 'مفعلة' : 'متوقفة'}
          </span>
          <div className="relative inline-flex items-center">
            <input
              type="checkbox"
              checked={config.enabled}
              onChange={(e) => updateConfig({ enabled: e.target.checked })}
              className="sr-only peer"
            />
            <div
              className="w-11 h-6 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all"
              style={{
                backgroundColor: config.enabled ? 'var(--theme-primary)' : undefined,
              }}
            />
          </div>
        </label>
      </div>

      {config.enabled && (
        <div className="space-y-4 animate-fade-in">
          {/* Content Type Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold font-cairo" style={{ color: 'var(--theme-text)' }}>
              نوع المحتوى اليومي المفضل:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-cairo">
              {[
                {
                  id: 'both' as const,
                  label: 'آيات وأحاديث عشوائياً',
                  desc: 'تنوع مبارك بين القرآن والسنة',
                  icon: '✨',
                },
                {
                  id: 'ayah_only' as const,
                  label: 'آيات قرآنية كريمة فقط',
                  desc: 'تلاوات وتدبرات من كتاب الله',
                  icon: '📖',
                },
                {
                  id: 'hadith_only' as const,
                  label: 'أحاديث نبوية شريفة فقط',
                  desc: 'هدي وسنة الحبيب المصطفى ﷺ',
                  icon: '📜',
                },
              ].map((item) => {
                const isActive = config.contentType === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => updateConfig({ contentType: item.id })}
                    className="p-3 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between gap-1.5"
                    style={{
                      backgroundColor: isActive ? 'var(--theme-primary-light)' : 'var(--theme-surface-elevated)',
                      borderColor: isActive ? 'var(--theme-primary)' : 'var(--theme-border)',
                      color: 'var(--theme-text)',
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-base">{item.icon}</span>
                      {isActive && (
                        <div
                          className="w-5 h-5 rounded-full flex items-center justify-center text-white"
                          style={{ backgroundColor: 'var(--theme-primary)' }}
                        >
                          <Check className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                    <div>
                      <span className="font-bold block text-xs" style={{ color: isActive ? 'var(--theme-primary-dark)' : 'var(--theme-text)' }}>
                        {item.label}
                      </span>
                      <span className="text-[10px] block mt-0.5" style={{ color: 'var(--theme-text-muted)' }}>
                        {item.desc}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Options Toggles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div
              className="p-3.5 rounded-2xl border flex items-center justify-between gap-3"
              style={{
                backgroundColor: 'var(--theme-background-secondary)',
                borderColor: 'var(--theme-border)',
              }}
            >
              <div className="flex items-center gap-2.5">
                <Calendar className="w-4 h-4" style={{ color: 'var(--theme-primary)' }} />
                <div>
                  <span className="font-bold text-xs block" style={{ color: 'var(--theme-text)' }}>
                    ظهور عند فتح التطبيق
                  </span>
                  <span className="text-[10px] block" style={{ color: 'var(--theme-text-muted)' }}>
                    يظهر تلقائياً أول مرة تفتح التطبيق كل يوم
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={config.triggerOnAppOpen}
                onChange={(e) => updateConfig({ triggerOnAppOpen: e.target.checked })}
                className="w-4 h-4 rounded-md cursor-pointer accent-[#5B5FEF]"
                style={{ accentColor: 'var(--theme-primary)' }}
              />
            </div>

            <div
              className="p-3.5 rounded-2xl border flex items-center justify-between gap-3"
              style={{
                backgroundColor: 'var(--theme-background-secondary)',
                borderColor: 'var(--theme-border)',
              }}
            >
              <div className="flex items-center gap-2.5">
                <Volume2 className="w-4 h-4" style={{ color: 'var(--theme-primary)' }} />
                <div>
                  <span className="font-bold text-xs block" style={{ color: 'var(--theme-text)' }}>
                    صوت رنين هادئ
                  </span>
                  <span className="text-[10px] block" style={{ color: 'var(--theme-text-muted)' }}>
                    نغمة تنبيه لطيفة عند انبثاق الرسالة
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={config.soundEnabled}
                onChange={(e) => updateConfig({ soundEnabled: e.target.checked })}
                className="w-4 h-4 rounded-md cursor-pointer"
                style={{ accentColor: 'var(--theme-primary)' }}
              />
            </div>
          </div>

          {/* Interactive Live Testing & Preview */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold font-cairo flex items-center gap-1.5" style={{ color: 'var(--theme-text)' }}>
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>تجربة التنبيه المنبثق الفوري (Live Toast Preview):</span>
              </label>
              <span className="text-[11px]" style={{ color: 'var(--theme-text-muted)' }}>
                اضغط لتجربة الظهور في الواجهة
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => handleTestToast()}
                disabled={isTesting}
                className="px-4 py-2.5 rounded-xl font-cairo font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-xs active:scale-95 disabled:opacity-50"
                style={{
                  backgroundColor: 'var(--theme-primary)',
                  color: 'var(--theme-button-text)',
                }}
              >
                <Play className="w-3.5 h-3.5" />
                <span>إطلاق تنبيه منبثق عشوائي الآن</span>
              </button>

              <button
                type="button"
                onClick={() => handleTestToast('ayah')}
                className="px-3 py-2 rounded-xl font-cairo font-bold text-xs border flex items-center gap-1.5 transition-all cursor-pointer hover:opacity-90"
                style={{
                  backgroundColor: 'var(--theme-surface-elevated)',
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-text)',
                }}
              >
                <BookOpen className="w-3.5 h-3.5" style={{ color: 'var(--theme-primary)' }} />
                <span>تجربة آية</span>
              </button>

              <button
                type="button"
                onClick={() => handleTestToast('hadith')}
                className="px-3 py-2 rounded-xl font-cairo font-bold text-xs border flex items-center gap-1.5 transition-all cursor-pointer hover:opacity-90"
                style={{
                  backgroundColor: 'var(--theme-surface-elevated)',
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-text)',
                }}
              >
                <Sparkles className="w-3.5 h-3.5" style={{ color: 'var(--theme-primary)' }} />
                <span>تجربة حديث</span>
              </button>
            </div>
          </div>

          {/* Today's Wisdom Spotlight inside Settings */}
          <div
            className="p-4 sm:p-5 rounded-2xl border space-y-3 relative overflow-hidden"
            style={{
              backgroundColor: 'var(--theme-background-secondary)',
              borderColor: 'var(--theme-border)',
            }}
          >
            <div className="flex items-center justify-between border-b pb-2" style={{ borderColor: 'var(--theme-divider)' }}>
              <div className="flex items-center gap-2">
                <span
                  className="px-2.5 py-0.5 rounded-full text-[11px] font-black font-cairo"
                  style={{
                    backgroundColor: 'var(--theme-primary-light)',
                    color: 'var(--theme-primary)',
                  }}
                >
                  {todayItem.type === 'ayah' ? '📖 آية اليوم المختارة' : '📜 حديث اليوم المختار'}
                </span>
                <span className="text-[11px]" style={{ color: 'var(--theme-text-muted)' }}>
                  المعروض لليوم
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleRefreshTodayItem}
                  className="p-1.5 rounded-lg border hover:opacity-80 transition-colors cursor-pointer"
                  style={{
                    backgroundColor: 'var(--theme-surface)',
                    borderColor: 'var(--theme-border)',
                    color: 'var(--theme-primary)',
                  }}
                  title="اختيار آية أو حديث آخر"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={handleCopyTodayItem}
                  className="p-1.5 rounded-lg border hover:opacity-80 transition-colors cursor-pointer"
                  style={{
                    backgroundColor: 'var(--theme-surface)',
                    borderColor: 'var(--theme-border)',
                    color: 'var(--theme-text)',
                  }}
                  title="نسخ النص"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
                <button
                  type="button"
                  onClick={handleShareTodayItem}
                  className="p-1.5 rounded-lg border hover:opacity-80 transition-colors cursor-pointer"
                  style={{
                    backgroundColor: 'var(--theme-surface)',
                    borderColor: 'var(--theme-border)',
                    color: 'var(--theme-text)',
                  }}
                  title="مشاركة"
                >
                  <Share2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="text-center py-2 space-y-2">
              <p
                className="font-amiri text-lg sm:text-xl font-bold leading-loose select-text"
                style={{ color: 'var(--theme-text)' }}
              >
                {todayItem.text}
              </p>

              <div
                className="inline-block px-3 py-1 rounded-xl text-xs font-cairo font-bold border"
                style={{
                  backgroundColor: 'var(--theme-surface)',
                  borderColor: 'var(--theme-border)',
                  color: 'var(--theme-primary-dark)',
                }}
              >
                {todayItem.source}
              </div>

              {todayItem.benefit && (
                <p className="text-xs leading-relaxed font-cairo" style={{ color: 'var(--theme-text-secondary)' }}>
                  💡 {todayItem.benefit}
                </p>
              )}
            </div>
          </div>

          {/* Previous History Toggle */}
          {config.history && config.history.length > 0 && (
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setShowHistory(!showHistory)}
                className="flex items-center gap-1.5 text-xs font-bold font-cairo cursor-pointer hover:underline"
                style={{ color: 'var(--theme-primary)' }}
              >
                <History className="w-3.5 h-3.5" />
                <span>سجل الآيات والأحاديث السابقة ({config.history.length})</span>
                {showHistory ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              {showHistory && (
                <div
                  className="mt-2.5 p-3 rounded-2xl border space-y-2 max-h-56 overflow-y-auto animate-fade-in"
                  style={{
                    backgroundColor: 'var(--theme-surface-elevated)',
                    borderColor: 'var(--theme-border)',
                  }}
                >
                  {config.history.map((hist, idx) => (
                    <div
                      key={hist.id || idx}
                      className="p-2.5 rounded-xl border flex items-start justify-between gap-2 text-xs"
                      style={{
                        backgroundColor: 'var(--theme-surface)',
                        borderColor: 'var(--theme-border)',
                      }}
                    >
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span
                            className="text-[10px] font-bold px-1.5 py-0.5 rounded-md"
                            style={{
                              backgroundColor: 'var(--theme-primary-light)',
                              color: 'var(--theme-primary)',
                            }}
                          >
                            {hist.type === 'ayah' ? 'آية' : 'حديث'}
                          </span>
                          <span className="text-[10px]" style={{ color: 'var(--theme-text-muted)' }}>
                            {hist.source}
                          </span>
                        </div>
                        <p className="font-amiri text-sm leading-relaxed truncate" style={{ color: 'var(--theme-text)' }}>
                          {hist.text}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={async () => {
                          try {
                            await navigator.clipboard.writeText(`${hist.text}\n— ${hist.source}`);
                            soundManager.triggerHaptic(20);
                            if (onShowToast) onShowToast('تم النسخ إلى الحافظة');
                          } catch {
                            // ignore
                          }
                        }}
                        className="p-1 rounded-lg hover:opacity-80 text-gray-500 hover:text-gray-700 cursor-pointer"
                        title="نسخ"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
};
