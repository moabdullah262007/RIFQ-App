import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  CheckCircle2, 
  Plus, 
  Minus, 
  PlusCircle, 
  RotateCcw, 
  X, 
  Check, 
  Sun, 
  Moon, 
  Bed, 
  Sparkles, 
  CheckCheck,
  Share2,
  Copy
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { DhikrItem, ScreenType, UserSettings, WardType } from '../types';
import { MORNING_ATHKAR, EVENING_ATHKAR, SLEEP_ATHKAR, PRAYER_ATHKAR } from '../data/athkarData';
import { soundManager } from '../utils/audio';
import { loadWardProgress, saveWardProgress } from '../utils/storage';
import { DhikrShareModal } from './DhikrShareModal';

interface WardViewProps {
  initialWardType?: WardType;
  customAthkar: DhikrItem[];
  onAddCustomDhikr: (item: Omit<DhikrItem, 'id' | 'countDone' | 'isCustom'>) => void;
  onNavigate: (screen: ScreenType) => void;
  settings: UserSettings;
  onRecordIncrement: (dhikrText: string, amount?: number, isWardCompletion?: boolean) => void;
}

export const WardView: React.FC<WardViewProps> = ({
  initialWardType = 'morning',
  customAthkar,
  onAddCustomDhikr,
  onNavigate,
  settings,
  onRecordIncrement,
}) => {
  const [selectedWard, setSelectedWard] = useState<WardType>(initialWardType);
  const [wardCounts, setWardCounts] = useState<Record<string, number>>(() => loadWardProgress());
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    const handleSync = () => {
      setWardCounts(loadWardProgress());
    };
    window.addEventListener('rifq-user-data-synced', handleSync);
    return () => {
      window.removeEventListener('rifq-user-data-synced', handleSync);
    };
  }, []);

  const updateAndPersistWardCounts = (updater: (prev: Record<string, number>) => Record<string, number>) => {
    setWardCounts((prev) => {
      const next = updater(prev);
      saveWardProgress(next);
      return next;
    });
  };
  const [newText, setNewText] = useState('');
  const [newRepeats, setNewRepeats] = useState<number>(3);
  const [newSource, setNewSource] = useState('');
  const [modalError, setModalError] = useState('');
  const [sharingDhikr, setSharingDhikr] = useState<DhikrItem | null>(null);
  const [copiedDhikrId, setCopiedDhikrId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Get current list of athkar
  const baseList = {
    morning: MORNING_ATHKAR,
    evening: EVENING_ATHKAR,
    sleep: SLEEP_ATHKAR,
    prayer: PRAYER_ATHKAR,
  }[selectedWard];

  const wardTitle = {
    morning: 'أذكار الصباح',
    evening: 'أذكار المساء',
    sleep: 'أذكار النوم',
    prayer: 'أذكار بعد الصلاة',
  }[selectedWard];

  const wardCustomItems = customAthkar.filter(c => c.category === selectedWard || c.category === 'custom');
  const currentList = [...baseList, ...wardCustomItems];

  const completedCount = currentList.filter(
    (item) => (wardCounts[item.id] || 0) >= item.countTarget
  ).length;

  const totalItems = currentList.length;
  const overallPercentage = totalItems > 0 ? Math.round((completedCount / totalItems) * 100) : 0;

  const handleIncrement = (item: DhikrItem) => {
    const cur = wardCounts[item.id] || 0;
    const next = cur + 1;
    updateAndPersistWardCounts(prev => ({ ...prev, [item.id]: next }));

    if (settings.soundEnabled) {
      soundManager.playBeadClick(settings.soundVolume, settings.soundType);
    }
    if (settings.vibrationEnabled) {
      soundManager.triggerHaptic(20);
    }

    const justCompleted = next === item.countTarget;
    onRecordIncrement(item.text, 1, justCompleted);

    if (justCompleted) {
      if (settings.soundEnabled) {
        soundManager.playCompletionChime(settings.soundVolume);
      }
      // If all items completed
      if (completedCount + 1 === totalItems) {
        try {
          confetti({
            particleCount: 70,
            spread: 80,
            origin: { y: 0.6 },
            colors: ['#5B5FEF', '#E8B84A', '#72B7E8', '#E99AC7'],
          });
        } catch {
          // ignore
        }
      }
    }
  };

  const handleDecrement = (item: DhikrItem) => {
    const cur = wardCounts[item.id] || 0;
    if (cur > 0) {
      updateAndPersistWardCounts(prev => ({ ...prev, [item.id]: cur - 1 }));
    }
  };

  const handleCompleteAll = () => {
    const newCounts: Record<string, number> = {};
    currentList.forEach(item => {
      newCounts[item.id] = item.countTarget;
    });
    updateAndPersistWardCounts(prev => ({ ...prev, ...newCounts }));
    if (settings.soundEnabled) {
      soundManager.playCompletionChime(settings.soundVolume);
    }
    try {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.5 },
      });
    } catch {
      // ignore
    }
  };

  const handleResetAll = () => {
    const resetCounts: Record<string, number> = {};
    currentList.forEach(item => {
      resetCounts[item.id] = 0;
    });
    updateAndPersistWardCounts(prev => ({ ...prev, ...resetCounts }));
  };

  const handleSaveCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) {
      setModalError('الرجاء كتابة نص الذكر');
      return;
    }
    if (newRepeats <= 0) {
      setModalError('عدد التكرارات يجب أن يكون 1 على الأقل');
      return;
    }

    onAddCustomDhikr({
      text: newText.trim(),
      countTarget: Number(newRepeats) || 1,
      source: newSource.trim() || 'ذكر مخصص',
      category: selectedWard,
    });

    setNewText('');
    setNewRepeats(3);
    setNewSource('');
    setModalError('');
    setShowAddModal(false);
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6 pb-16 select-none" dir="rtl">
      
      {/* Ward Category Switcher Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-white p-2 rounded-2xl border border-[#E6E6F0] shadow-sm">
        {[
          { id: 'morning', label: 'أذكار الصباح', icon: <Sun className="w-4 h-4 text-amber-500" /> },
          { id: 'evening', label: 'أذكار المساء', icon: <Moon className="w-4 h-4 text-indigo-500" /> },
          { id: 'sleep', label: 'أذكار النوم', icon: <Bed className="w-4 h-4 text-purple-500" /> },
          { id: 'prayer', label: 'بعد الصلاة', icon: <Sparkles className="w-4 h-4 text-[#4CAF82]" /> },
        ].map(w => {
          const isSelected = selectedWard === w.id;
          return (
            <button
              key={w.id}
              onClick={() => setSelectedWard(w.id as WardType)}
              className={`p-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                isSelected
                  ? 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white shadow-sm scale-102'
                  : 'bg-[#F7F7FC]/70 text-[#25263A] hover:bg-[#F7F7FC]'
              }`}
            >
              {w.icon}
              <span>{w.label}</span>
            </button>
          );
        })}
      </div>

      {/* Top Bar: Title in Gold, Back Arrow, Complete All */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-[#E6E6F0] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('tasbeeh')}
            className="p-2 rounded-xl text-[#25263A] hover:bg-[#F7F7FC] transition-colors"
            title="الرجوع للرئيسية"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xl font-extrabold text-[#5B5FEF] font-tajawal">
              {wardTitle}
            </h2>
            <p className="text-xs text-[#77798C]">حصن المسلم ووردك المبارك</p>
          </div>
        </div>

        <button
          onClick={handleCompleteAll}
          className="text-xs bg-[#4CAF82]/12 text-[#4145C7] border border-[#4CAF82]/40 px-3 py-1.5 rounded-xl font-bold hover:bg-[#4CAF82]/12 transition-colors flex items-center gap-1.5 cursor-pointer"
        >
          <CheckCheck className="w-4 h-4 text-[#4CAF82]" />
          <span>تحديد الكل</span>
        </button>
      </div>

      {/* Progress Summary Card */}
      <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#E6E6F0] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-[#4CAF82]" />
            <span className="text-base font-bold text-[#4CAF82] font-tajawal">
              مكتمل ({completedCount})
            </span>
          </div>
          <span className="text-sm font-semibold text-[#77798C]">
            {completedCount} من {totalItems}
          </span>
        </div>

        {/* Overall Progress Bar */}
        <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden p-0.5 border border-[#E6E6F0]">
          <div
            className="h-full bg-gradient-to-r from-[#5B5FEF] via-[#72B7E8] to-[#4CAF82] rounded-full transition-all duration-300"
            style={{ width: `${overallPercentage}%` }}
          />
        </div>

        <div className="flex justify-between items-center text-xs text-gray-400">
          <span>نسبة الإنجاز الإجمالية</span>
          <span className="font-bold text-[#5B5FEF]">{overallPercentage}%</span>
        </div>
      </div>

      {/* Vertical Athkar Items List */}
      <div className="space-y-3">
        {currentList.map((item, index) => {
          const count = wardCounts[item.id] || 0;
          const isItemCompleted = count >= item.countTarget;
          const ratio = Math.min(100, Math.round((count / item.countTarget) * 100));

          return (
            <div
              key={item.id}
              className={`rounded-2xl p-4 transition-all duration-300 border flex flex-col justify-between ${
                isItemCompleted
                  ? 'bg-[#4CAF82]/12/90 border-[#4CAF82]/40 shadow-xs'
                  : 'bg-white border-[#E6E6F0] hover:border-[#E6E6F0] shadow-xs'
              }`}
            >
              <div className="flex items-start gap-3">
                {/* Index Circle */}
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                  isItemCompleted ? 'bg-[#5B5FEF] text-white' : 'bg-[#F7F7FC] text-[#77798C]'
                }`}>
                  {isItemCompleted ? <Check className="w-4 h-4" /> : index + 1}
                </div>

                {/* Text & Meta */}
                <div className="flex-1 space-y-2">
                  <p className="text-base sm:text-lg font-bold text-[#25263A] leading-relaxed font-tajawal">
                    {item.text}
                  </p>

                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="text-[#77798C]">{item.source}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-[#5B5FEF] font-semibold">
                        المدقق: {item.countTarget}
                      </span>
                      <span className={`font-black ${isItemCompleted ? 'text-[#4CAF82]' : 'text-[#4CAF82]'}`}>
                        {count} / {item.countTarget}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Toolbar: Share, Copy, and Counter */}
              <div className="mt-3 pt-3 border-t border-[#E6E6F0] flex flex-wrap items-center justify-between gap-3">
                {/* Left: Share & Copy Buttons */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSharingDhikr({
                        ...item,
                        title: wardTitle
                      });
                    }}
                    title="مشاركة الذكر كبطاقة مصممة أو نص منسق مع بصمة التطبيق"
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 text-[#4145C7] border border-[#4CAF82]/40/80 text-xs font-black transition-all cursor-pointer shadow-2xs active:scale-95"
                  >
                    <Share2 className="w-3.5 h-3.5 text-[#4145C7]" />
                    <span>مشاركة</span>
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      const copyText = `« ${item.text} »\n\n[${item.source}]\n— منقول من تطبيق «رِفْق | RIFQ» ✨`;
                      navigator.clipboard.writeText(copyText);
                      setCopiedDhikrId(item.id);
                      showToast('تم نسخ الذكر مع بصمة التطبيق بنجاح 📋');
                      setTimeout(() => setCopiedDhikrId(null), 2000);
                    }}
                    title="نسخ نص الذكر مع البصمة"
                    className="p-1.5 rounded-xl text-[#77798C] hover:text-[#4145C7] hover:bg-gray-100 border border-[#E6E6F0] transition-colors cursor-pointer"
                  >
                    {copiedDhikrId === item.id ? (
                      <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Right: Counter Controls & Progress Indicator */}
                <div className="flex items-center gap-3">
                  <div className="w-20 sm:w-28 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-200 ${
                        isItemCompleted ? 'bg-[#5B5FEF]' : 'bg-gradient-to-r from-[#72B7E8] to-[#4CAF82]'
                      }`}
                      style={{ width: `${ratio}%` }}
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleDecrement(item)}
                      disabled={count === 0}
                      aria-label="تقليل التكرار"
                      className="w-8 h-8 rounded-full bg-gray-100 text-[#77798C] hover:bg-gray-200 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center transition-colors cursor-pointer"
                    >
                      <Minus className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleIncrement(item)}
                      aria-label="زيادة التكرار"
                      className={`w-8 h-8 rounded-full text-white flex items-center justify-center transition-transform active:scale-95 shadow-xs cursor-pointer ${
                        isItemCompleted ? 'bg-[#5B5FEF] hover:bg-[#5B5FEF]' : 'bg-[#4CAF82] hover:bg-[#4145C7]'
                      }`}
                    >
                      {isItemCompleted ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Actions: Add custom dhikr + Reset counters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
        <button
          onClick={() => setShowAddModal(true)}
          className="w-full py-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#b8953c] text-white font-extrabold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <PlusCircle className="w-5 h-5" />
          <span>إضافة ذكر للورد</span>
        </button>

        <button
          onClick={handleResetAll}
          className="w-full py-3 rounded-2xl bg-white border border-gray-300 text-[#25263A] hover:bg-gray-100 font-bold text-sm shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4 text-[#77798C]" />
          <span>تصفير العدادات</span>
        </button>
      </div>

      {/* Add Custom Dhikr Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fade-in" dir="rtl">
          <div className="bg-white rounded-[20px] p-6 max-w-[500px] w-[90%] shadow-2xl border border-[#E6E6F0] space-y-4 relative animate-scale-up">
            
            {/* Close Button in top right */}
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 left-4 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-[#77798C] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-black text-[#5B5FEF] font-tajawal text-center">
              إضافة ذكر للورد
            </h3>

            {modalError && (
              <div className="bg-red-50 text-red-600 p-2.5 rounded-xl text-xs font-semibold text-center">
                {modalError}
              </div>
            )}

            <form onSubmit={handleSaveCustom} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  نص الذكر *
                </label>
                <textarea
                  rows={3}
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  placeholder="اكتب نص الذكر أو الدعاء المبارك..."
                  className="w-full bg-[#F7F7FC]/70 border border-gray-300 rounded-xl p-3 text-sm text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  عدد التكرارات المطلوبة *
                </label>
                <input
                  type="number"
                  min={1}
                  max={1000}
                  value={newRepeats}
                  onChange={(e) => setNewRepeats(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#F7F7FC]/70 border border-gray-300 rounded-xl p-3 text-sm text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#25263A] mb-1.5">
                  المصدر (اختياري)
                </label>
                <input
                  type="text"
                  value={newSource}
                  onChange={(e) => setNewSource(e.target.value)}
                  placeholder="مثال: دعاء مأثور، أو سورة معينة"
                  className="w-full bg-[#F7F7FC]/70 border border-gray-300 rounded-xl p-3 text-sm text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-extrabold text-sm shadow-md hover:shadow-lg transition-all"
                >
                  حفظ وإضافة
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-3 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-sm transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ─── Share Dhikr Modal (Designed Image & Formatted Text) ─── */}
      <DhikrShareModal
        dhikr={sharingDhikr}
        isOpen={!!sharingDhikr}
        onClose={() => setSharingDhikr(null)}
      />

      {/* ─── Floating Toast Notification ─── */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#5B5FEF] text-white px-4 py-2.5 rounded-full shadow-lg text-xs font-black flex items-center gap-2 border border-[#E6E6F0] animate-fade-in pointer-events-none whitespace-nowrap">
          <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
