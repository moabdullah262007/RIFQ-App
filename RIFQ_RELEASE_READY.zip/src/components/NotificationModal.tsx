import React, { useState, useEffect } from 'react';
import {
  Bell,
  X,
  CheckCheck,
  BookOpen,
  Settings,
  Play,
  Pause,
  Square,
  Volume2,
  ExternalLink,
} from 'lucide-react';
import { NotificationItem, WardType, ScreenType } from '../types';
import {
  subscribeToAdhanPlayer,
  AdhanPlayerState,
  startOrResumeAdhanAudio,
  pauseAdhanAudio,
  stopAdhanAudio,
} from '../utils/prayerAudio';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkAllRead: () => void;
  onOpenWard?: (ward: WardType) => void;
  onNavigateScreen?: (screen: ScreenType, dhikrId?: string) => void;
  onOpenSettings?: () => void;
}

const SCREEN_ACTION_LABELS: Partial<Record<ScreenType, string>> = {
  prayers: 'فتح مواقيت الصلاة 🕌',
  quran: 'فتح المصحف والورد القرآني 📖',
  ward: 'فتح صفحة الأذكار والورد 📿',
  daily_reminders: 'فتح التذكيرات اليومية 🔔',
  journey: 'فتح رحلتي (غراس) 🌱',
  harvest: 'فتح حصاد العبادات 🌾',
  moment_dhikr: 'فتح ذكر اللحظة ✨',
  tasbeeh: 'فتح المسبحة الإلكترونية 📿',
  athkar: 'فتح الأذكار والأدعية المأثورة 🤲',
  wudu_prayer: 'فتح تعلّم الوضوء والصلاة 🕌',
};

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
  onOpenWard,
  onNavigateScreen,
  onOpenSettings,
}) => {
  const [adhanState, setAdhanState] = useState<AdhanPlayerState | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToAdhanPlayer((state) => {
      setAdhanState(state);
    });
    return () => unsubscribe();
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in" dir="rtl">
      <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-[#E6E6F0] flex flex-col max-h-[85vh] relative space-y-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-[#4145C7] font-tajawal">
                مركز التذكيرات والإشعارات
              </h3>
              <p className="text-xs text-[#77798C]">سجل إشعارات الجهاز والتذكيرات والمواقيت</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {onOpenSettings && (
              <button
                onClick={() => {
                  onClose();
                  onOpenSettings();
                }}
                title="إعدادات مواعيد الإشعارات"
                className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-[#77798C] transition-colors cursor-pointer"
              >
                <Settings className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-[#77798C] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications list */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {notifications.length === 0 ? (
            <div className="text-center py-8 text-gray-400 space-y-2">
              <Bell className="w-10 h-10 mx-auto text-gray-300" />
              <p className="text-sm font-medium">لا توجد إشعارات مسجلة حالياً</p>
              <p className="text-xs text-[#77798C]">
                عند حلول موعد أي تذكير أو صلاة، سيظهر الإشعار في شريط إشعارات هاتفك ويُسجّل هنا تلقائياً
              </p>
            </div>
          ) : (
            notifications.map((n) => {
              const isPrayerNotification =
                n.actionScreen === 'prayers' ||
                n.title.includes('أذان') ||
                n.title.includes('صلاة') ||
                n.message.includes('أذان') ||
                n.message.includes('حي على الصلاة');

              const targetScreen: ScreenType | undefined =
                n.actionScreen || (isPrayerNotification ? 'prayers' : undefined);

              return (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    n.read
                      ? 'bg-gray-50/70 border-[#E6E6F0] opacity-85'
                      : 'bg-[#F7F7FC] border-[#E6E6F0] shadow-xs'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-bold text-[#25263A] flex items-center gap-1.5 flex-wrap">
                      {!n.read && (
                        <span className="w-2 h-2 rounded-full bg-[#5B5FEF] inline-block shrink-0" />
                      )}
                      {n.type === 'achievement' && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold border border-amber-300">
                          وسام جديد 🏅
                        </span>
                      )}
                      {n.type === 'goal' && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                          إنجاز الهدف 🎉
                        </span>
                      )}
                      <span>{n.title}</span>
                    </h4>
                    <span className="text-[11px] text-gray-400 shrink-0">{n.time}</span>
                  </div>
                  <p className="text-xs text-[#77798C] leading-relaxed">{n.message}</p>

                  {/* Adhan Audio Controls (Start / Pause / Stop) for Prayer Notifications */}
                  {isPrayerNotification && (
                    <div className="mt-2.5 pt-2 border-t border-[#E6E6F0] flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#4145C7]">
                        <Volume2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
                        <span>التحكم بصوت الأذان:</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {adhanState?.isPlaying ? (
                          <button
                            type="button"
                            onClick={() => pauseAdhanAudio()}
                            className="text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-xs transition-transform active:scale-95 cursor-pointer"
                          >
                            <Pause className="w-3.5 h-3.5 fill-current" />
                            <span>إيقاف مؤقت</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => startOrResumeAdhanAudio()}
                            className="text-xs font-bold bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-xs transition-transform active:scale-95 cursor-pointer"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" />
                            <span>{adhanState?.isPaused ? 'متابعة الأذان' : 'بدء الأذان'}</span>
                          </button>
                        )}

                        {(adhanState?.isPlaying || adhanState?.isPaused) && (
                          <button
                            type="button"
                            onClick={() => stopAdhanAudio()}
                            className="text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-xs transition-transform active:scale-95 cursor-pointer"
                          >
                            <Square className="w-3 h-3 fill-current" />
                            <span>إيقاف</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Direct Action if notification is linked to a Ward or Screen */}
                  {(n.actionWard && onOpenWard) || (targetScreen && onNavigateScreen) ? (
                    <div className="mt-2.5 pt-2 border-t border-[#E6E6F0]/50 flex justify-end">
                      {n.actionWard && onOpenWard ? (
                        <button
                          onClick={() => {
                            onClose();
                            onOpenWard(n.actionWard!);
                          }}
                          className="text-xs font-bold bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs transition-transform active:scale-95 cursor-pointer"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>
                            قراءة{' '}
                            {n.actionWard === 'morning'
                              ? 'أذكار الصباح'
                              : n.actionWard === 'evening'
                              ? 'أذكار المساء'
                              : n.actionWard === 'sleep'
                              ? 'أذكار النوم'
                              : 'الورد'}{' '}
                            الآن
                          </span>
                        </button>
                      ) : targetScreen && onNavigateScreen ? (
                        <button
                          onClick={() => {
                            onClose();
                            onNavigateScreen(targetScreen, n.actionDhikrId);
                          }}
                          className="text-xs font-bold bg-[#5B5FEF] hover:bg-[#4145C7] text-white px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs transition-transform active:scale-95 cursor-pointer"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>{SCREEN_ACTION_LABELS[targetScreen] || 'فتح الصفحة الآن'}</span>
                        </button>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              );
            })
          )}
        </div>

        {/* Action button */}
        <div className="pt-2 border-t border-[#E6E6F0] flex items-center justify-between gap-3">
          <button
            onClick={onMarkAllRead}
            className="text-xs text-[#4CAF82] hover:text-[#4145C7] font-bold flex items-center gap-1.5 px-3 py-2 rounded-xl hover:bg-[#4CAF82]/12 transition-colors cursor-pointer"
          >
            <CheckCheck className="w-4 h-4" />
            <span>تعيين الكل كمقروء</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-bold text-xs shadow-sm hover:shadow-md transition-all cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
