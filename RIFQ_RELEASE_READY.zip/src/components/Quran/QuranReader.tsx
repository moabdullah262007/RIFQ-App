import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowRight,
  Bookmark,
  Share2,
  Copy,
  Check,
  ChevronRight,
  ChevronLeft,
  Settings,
  Eye,
  EyeOff,
  BookOpen,
  Globe,
  Star,
  Sliders,
  X,
  Sparkles,
  Play,
  Pause,
  Gauge,
} from 'lucide-react';
import { SurahDetail, AyahItem, SURAH_LIST } from '../../data/quranData';
import {
  getSurahDetail,
  saveLastRead,
  toggleBookmark,
  loadBookmarks,
  updateBookmarkNote,
  removeBookmarkById,
  toggleFavoriteSurah,
  loadFavoriteSurahs,
  TafseerType,
  TAFSEER_CONFIG,
  getAyahTafseer,
} from '../../utils/quranService';
import { TafseerModal } from './TafseerModal';
import { VerseCardModal } from './VerseCardModal';
import { BookmarksModal } from './BookmarksModal';

interface QuranReaderProps {
  surahNumber: number;
  initialAyahNumber?: number;
  onBack: () => void;
  onNavigateSurah: (number: number) => void;
}

const AUTO_SCROLL_PRESETS = [
  { id: 'slow' as const, label: 'بطيء', speed: 15 },
  { id: 'medium' as const, label: 'متوسط', speed: 26 },
  { id: 'fast' as const, label: 'سريع', speed: 42 },
];

export const QuranReader: React.FC<QuranReaderProps> = ({
  surahNumber,
  initialAyahNumber = 1,
  onBack,
  onNavigateSurah,
}) => {
  // Navigation tabs in header: 'mushaf' | 'tafseer' | 'translation'
  const [activeTab, setActiveTab] = useState<'mushaf' | 'tafseer' | 'translation'>('mushaf');

  // Surah data & loading
  const [surah, setSurah] = useState<SurahDetail | null>(null);
  const [loading, setLoading] = useState(true);

  // Reader customization state
  const [fontSize, setFontSize] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_quran_font_size');
    return saved ? parseInt(saved, 10) : 26;
  });
  const [themeMode, setThemeMode] = useState<'beige' | 'white' | 'dark'>(() => {
    const saved = localStorage.getItem('rifq_quran_theme');
    return (saved as any) || 'beige';
  });

  // Memorization hide mode (وضع الإخفاء)
  const [isHideMode, setIsHideMode] = useState(false);
  const [revealedAyahs, setRevealedAyahs] = useState<Record<number, boolean>>({});

  // Active Bottom Sheet for clicked ayah
  const [selectedAyahForSheet, setSelectedAyahForSheet] = useState<AyahItem | null>(null);

  // Modals
  const [tafseerAyah, setTafseerAyah] = useState<AyahItem | null>(null);
  const [shareCardAyah, setShareCardAyah] = useState<AyahItem | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isBookmarksModalOpen, setIsBookmarksModalOpen] = useState(false);
  const [highlightedAyahNumber, setHighlightedAyahNumber] = useState<number | null>(null);
  const pendingScrollAyahRef = useRef<number | null>(null);

  // Tafseer view selector for the 'tafseer' tab
  const [selectedTafseerType, setSelectedTafseerType] = useState<TafseerType>('muyassar');
  const [tafseerList, setTafseerList] = useState<Record<number, string>>({});
  const [loadingTabTafseer, setLoadingTabTafseer] = useState(false);

  // Translation view language
  const [transLang, setTransLang] = useState<'en' | 'fr' | 'ur'>('en');

  // Bookmarks & Favorites
  const [bookmarks, setBookmarks] = useState(loadBookmarks());
  const [favorites, setFavorites] = useState(loadFavoriteSurahs());
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedAyahNumber, setCopiedAyahNumber] = useState<number | null>(null);

  // Jump Slider state (ayah progression)
  const [currentProgressAyah, setCurrentProgressAyah] = useState<number>(initialAyahNumber);
  const ayahElementsRef = useRef<Record<number, HTMLElement | null>>({});

  // ─────────────────────────────────────────────────────────────
  // 📖 حالة وإعدادات التمرير التلقائي (Auto-Scroll via requestAnimationFrame)
  // ─────────────────────────────────────────────────────────────
  const [isAutoScrolling, setIsAutoScrolling] = useState(false);
  const [isAutoScrollPausedByManual, setIsAutoScrollPausedByManual] = useState(false);
  const [showAutoScrollControls, setShowAutoScrollControls] = useState(false);
  const [autoScrollSpeed, setAutoScrollSpeed] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_quran_autoscroll_speed');
    const parsed = saved ? parseFloat(saved) : 26;
    return Number.isFinite(parsed) ? Math.min(60, Math.max(8, parsed)) : 26;
  });

  const autoScrollSpeedRef = useRef<number>(autoScrollSpeed);
  const rafIdRef = useRef<number | null>(null);
  const lastFrameTimeRef = useRef<number | null>(null);
  const virtualScrollTopRef = useRef<number | null>(null);
  const isUserTouchingRef = useRef<boolean>(false);
  const touchStartYRef = useRef<number | null>(null);
  const lastVisibleSyncTimeRef = useRef<number>(0);
  const lastSavedReadTimeRef = useRef<number>(0);
  const currentProgressAyahRef = useRef<number>(currentProgressAyah);

  useEffect(() => {
    currentProgressAyahRef.current = currentProgressAyah;
  }, [currentProgressAyah]);

  useEffect(() => {
    autoScrollSpeedRef.current = autoScrollSpeed;
  }, [autoScrollSpeed]);

  const updateAutoScrollSpeed = (newSpeed: number) => {
    const clamped = Math.min(60, Math.max(8, Math.round(newSpeed)));
    setAutoScrollSpeed(clamped);
    autoScrollSpeedRef.current = clamped;
    localStorage.setItem('rifq_quran_autoscroll_speed', clamped.toString());
  };

  const getActiveSpeedPreset = (speed: number): 'slow' | 'medium' | 'fast' => {
    if (speed <= 19) return 'slow';
    if (speed <= 34) return 'medium';
    return 'fast';
  };

  const getActiveScrollContainer = (): HTMLElement | null => {
    return (document.scrollingElement as HTMLElement) || document.documentElement;
  };

  const syncVisibleAyahFromScroll = (forceSave = false) => {
    if (!surah || !surah.ayahs || surah.ayahs.length === 0) return;

    const now = performance.now();
    if (!forceSave && now - lastVisibleSyncTimeRef.current < 180) return;
    lastVisibleSyncTimeRef.current = now;

    const focalY = Math.min(220, window.innerHeight * 0.32);
    const ayahs = surah.ayahs;
    let low = 0;
    let high = ayahs.length - 1;
    let bestAyahNum = currentProgressAyahRef.current || 1;
    let foundAny = false;

    while (low <= high) {
      const mid = (low + high) >> 1;
      const ayahNum = ayahs[mid].numberInSurah;
      const el = ayahElementsRef.current[ayahNum];
      if (!el) break;
      const rect = el.getBoundingClientRect();
      foundAny = true;
      if (rect.top <= focalY + 32) {
        bestAyahNum = ayahNum;
        low = mid + 1;
      } else {
        high = mid - 1;
      }
    }

    if (!foundAny) return;

    if (bestAyahNum !== currentProgressAyahRef.current) {
      currentProgressAyahRef.current = bestAyahNum;
      setCurrentProgressAyah(bestAyahNum);
    }

    if (forceSave || now - lastSavedReadTimeRef.current >= 2000) {
      lastSavedReadTimeRef.current = now;
      const ayahObj = ayahs.find((a) => a.numberInSurah === bestAyahNum) || ayahs[0];
      saveLastRead({
        surahNumber: surah.number,
        surahName: surah.name,
        ayahNumber: bestAyahNum,
        ayahText: ayahObj?.text || '',
        timestamp: Date.now(),
      });
    }
  };

  const stopAutoScroll = (pausedByManual = false) => {
    if (rafIdRef.current !== null) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }
    lastFrameTimeRef.current = null;
    virtualScrollTopRef.current = null;
    setIsAutoScrolling(false);
    setIsAutoScrollPausedByManual(pausedByManual);
    syncVisibleAyahFromScroll(true);
  };

  const toggleAutoScroll = () => {
    if (isAutoScrolling) {
      stopAutoScroll(false);
      return;
    }

    setShowAutoScrollControls(true);
    setIsAutoScrollPausedByManual(false);

    const target = getActiveScrollContainer();
    if (target) {
      const isAtVeryBottom =
        target.scrollHeight > target.clientHeight + 4 &&
        target.scrollTop + target.clientHeight >= target.scrollHeight - 4;
      if (isAtVeryBottom) {
        target.scrollTop = 0;
        virtualScrollTopRef.current = 0;
      } else {
        virtualScrollTopRef.current = target.scrollTop;
      }
    }
    lastFrameTimeRef.current = null;
    setIsAutoScrolling(true);
  };

  useEffect(() => {
    if (!isAutoScrolling || loading || !surah) {
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
      return;
    }

    let isCancelled = false;

    const step = (timestamp: number) => {
      if (isCancelled) return;

      const target = getActiveScrollContainer();
      if (!target) {
        rafIdRef.current = requestAnimationFrame(step);
        return;
      }

      if (isUserTouchingRef.current) {
        lastFrameTimeRef.current = timestamp;
        virtualScrollTopRef.current = target.scrollTop;
        rafIdRef.current = requestAnimationFrame(step);
        return;
      }

      if (lastFrameTimeRef.current === null) {
        lastFrameTimeRef.current = timestamp;
        if (virtualScrollTopRef.current === null) {
          virtualScrollTopRef.current = target.scrollTop;
        }
      }

      const dtSeconds = Math.min((timestamp - lastFrameTimeRef.current) / 1000, 0.1);
      lastFrameTimeRef.current = timestamp;

      const maxScrollTop = Math.max(0, target.scrollHeight - target.clientHeight);
      if (maxScrollTop <= 1) {
        rafIdRef.current = requestAnimationFrame(step);
        return;
      }

      const currentVirtual =
        virtualScrollTopRef.current !== null ? virtualScrollTopRef.current : target.scrollTop;
      const baseTop =
        Math.abs(currentVirtual - target.scrollTop) > 8 ? target.scrollTop : currentVirtual;
      const nextTop = baseTop + autoScrollSpeedRef.current * dtSeconds;

      if (nextTop >= maxScrollTop - 0.5) {
        target.scrollTop = maxScrollTop;
        virtualScrollTopRef.current = maxScrollTop;
        setIsAutoScrolling(false);
        setIsAutoScrollPausedByManual(false);
        syncVisibleAyahFromScroll(true);
        showToast(`وصلت إلى نهاية سورة ${surah.name} — توقف التمرير التلقائي`);
        return;
      }

      virtualScrollTopRef.current = nextTop;
      target.scrollTop = nextTop;
      syncVisibleAyahFromScroll(false);

      rafIdRef.current = requestAnimationFrame(step);
    };

    rafIdRef.current = requestAnimationFrame(step);

    return () => {
      isCancelled = true;
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
    };
  }, [isAutoScrolling, loading, surah, activeTab]);

  useEffect(() => {
    if (selectedAyahForSheet || tafseerAyah || shareCardAyah || isBookmarksModalOpen) {
      if (isAutoScrolling) {
        stopAutoScroll(true);
      }
    }
  }, [selectedAyahForSheet, tafseerAyah, shareCardAyah, isBookmarksModalOpen]);

  useEffect(() => {
    return () => {
      if (rafIdRef.current !== null) {
        cancelAnimationFrame(rafIdRef.current);
        rafIdRef.current = null;
      }
    };
  }, []);

  const handleReaderTouchStart = (e: React.TouchEvent) => {
    isUserTouchingRef.current = true;
    if (e.touches && e.touches.length > 0) {
      touchStartYRef.current = e.touches[0].clientY;
    }
  };

  const handleReaderTouchMove = (e: React.TouchEvent) => {
    if (touchStartYRef.current !== null && e.touches && e.touches.length > 0) {
      const deltaY = Math.abs(e.touches[0].clientY - touchStartYRef.current);
      if (deltaY > 7 && isAutoScrolling) {
        stopAutoScroll(true);
      }
    }
  };

  const handleReaderTouchEnd = () => {
    isUserTouchingRef.current = false;
    touchStartYRef.current = null;
    if (!isAutoScrolling) {
      syncVisibleAyahFromScroll(true);
    }
  };

  const handleReaderWheel = (e: React.WheelEvent) => {
    if (Math.abs(e.deltaY) > 1 && isAutoScrolling) {
      stopAutoScroll(true);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Save font size
  const handleFontSizeChange = (size: number) => {
    setFontSize(size);
    localStorage.setItem('rifq_quran_font_size', size.toString());
  };

  // Save theme
  const handleThemeChange = (mode: 'beige' | 'white' | 'dark') => {
    setThemeMode(mode);
    localStorage.setItem('rifq_quran_theme', mode);
  };

  // Fetch surah details
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setRevealedAyahs({});
    setSelectedAyahForSheet(null);

    getSurahDetail(surahNumber)
      .then((data) => {
        if (isMounted && data) {
          setSurah(data);
          setLoading(false);

          // Update last read position in storage
          const ayahsList = Array.isArray(data.ayahs) ? data.ayahs.filter(Boolean) : [];
          const targetAyah =
            ayahsList.find((a) => a.numberInSurah === initialAyahNumber) || ayahsList[0];
          saveLastRead({
            surahNumber: data.number ?? surahNumber,
            surahName: data.name || '',
            ayahNumber: targetAyah ? targetAyah.numberInSurah : 1,
            ayahText: targetAyah ? targetAyah.text : '',
            timestamp: Date.now(),
          });

          // Scroll to initial ayah if set and not 1
          if (initialAyahNumber > 1) {
            setTimeout(() => {
              const el = ayahElementsRef.current[initialAyahNumber];
              if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }, 300);
          }
        }
      })
      .catch((err) => {
        console.error('Failed to load surah', err);
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [surahNumber]);

  // Load tafseers for all ayahs if in 'tafseer' tab
  useEffect(() => {
    if (activeTab !== 'tafseer' || !surah) return;

    if (selectedTafseerType === 'muyassar') {
      const map: Record<number, string> = {};
      surah.ayahs.forEach((a) => {
        if (a.tafseer) map[a.numberInSurah] = a.tafseer;
      });
      setTafseerList(map);
      return;
    }

    let isMounted = true;
    setLoadingTabTafseer(true);

    // Fetch batch or first batch of tafsirs
    Promise.all(
      surah.ayahs.map(async (a) => {
        try {
          const res = await getAyahTafseer(surah.number, a.numberInSurah, selectedTafseerType);
          return { num: a.numberInSurah, text: res.text };
        } catch {
          return { num: a.numberInSurah, text: a.tafseer || '' };
        }
      })
    ).then((results) => {
      if (isMounted) {
        const map: Record<number, string> = {};
        results.forEach((r) => {
          map[r.num] = r.text;
        });
        setTafseerList(map);
        setLoadingTabTafseer(false);
      }
    });

    return () => {
      isMounted = false;
    };
  }, [activeTab, selectedTafseerType, surah]);

  // Bookmark toggle
  const handleToggleBookmark = (ayah: AyahItem) => {
    if (!surah) return;
    const updated = toggleBookmark({
      surahNumber: surah.number,
      surahName: surah.name,
      ayahNumber: ayah.numberInSurah,
      ayahText: ayah.text,
    });
    setBookmarks(updated);
    const isNowBookmarked = updated.some(
      (b) => b.surahNumber === surah.number && b.ayahNumber === ayah.numberInSurah
    );
    showToast(isNowBookmarked ? 'تمت إضافة الآية للعلامات المرجعية 🔖' : 'تمت إزالة العلامة المرجعية');
  };

  const handleDeleteBookmarkById = (id: string) => {
    const updated = removeBookmarkById(id);
    setBookmarks(updated);
    showToast('تمت إزالة العلامة المرجعية');
  };

  const handleUpdateBookmarkNote = (surahNum: number, ayahNum: number, note: string) => {
    const updated = updateBookmarkNote(surahNum, ayahNum, note);
    setBookmarks(updated);
    showToast(note.trim() ? 'تم حفظ ملاحظة العلامة المرجعية ✨' : 'تم تحديث العلامة المرجعية');
  };

  const handleSelectBookmarkTarget = (targetSurahNum: number, targetAyahNum: number) => {
    if (isAutoScrolling) {
      stopAutoScroll(false);
    }
    setActiveTab('mushaf');
    pendingScrollAyahRef.current = targetAyahNum;
    setCurrentProgressAyah(targetAyahNum);
    currentProgressAyahRef.current = targetAyahNum;

    const targetMeta = SURAH_LIST.find((s) => s.number === targetSurahNum);
    if (targetMeta) {
      showToast(`تم الانتقال إلى سورة ${targetMeta.name} — الآية ${targetAyahNum} 🔖`);
    }

    if (targetSurahNum !== surahNumber) {
      onNavigateSurah(targetSurahNum);
    } else {
      setTimeout(() => {
        const el = ayahElementsRef.current[targetAyahNum];
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          setHighlightedAyahNumber(targetAyahNum);
          setTimeout(() => {
            setHighlightedAyahNumber((prev) => (prev === targetAyahNum ? null : prev));
          }, 2800);
        }
      }, 120);
    }
  };

  useEffect(() => {
    if (loading || !surah || surah.number !== surahNumber) return;
    const targetAyah = pendingScrollAyahRef.current;
    if (!targetAyah) return;
    pendingScrollAyahRef.current = null;
    setTimeout(() => {
      const el = ayahElementsRef.current[targetAyah];
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        setHighlightedAyahNumber(targetAyah);
        setTimeout(() => {
          setHighlightedAyahNumber((prev) => (prev === targetAyah ? null : prev));
        }, 2800);
      }
    }, 180);
  }, [loading, surah, surahNumber]);

  const isAyahBookmarked = (ayahNum: number) => {
    return bookmarks.some((b) => b.surahNumber === surahNumber && b.ayahNumber === ayahNum);
  };

  // Favorite toggle
  const handleToggleFavoriteSurah = () => {
    if (!surah) return;
    const updated = toggleFavoriteSurah(surah.number);
    setFavorites(updated);
    showToast(
      updated.includes(surah.number)
        ? `تمت إضافة سورة ${surah.name} إلى المفضلة ⭐`
        : `تمت إزالة سورة ${surah.name} من المفضلة`
    );
  };

  // Copy Ayah
  const handleCopyAyah = (ayah: AyahItem) => {
    if (!surah) return;
    const text = `﴿ ${ayah.text} ﴾ [سورة ${surah.name}: ${ayah.numberInSurah}]`;
    navigator.clipboard.writeText(text);
    setCopiedAyahNumber(ayah.numberInSurah);
    showToast('تم نسخ الآية الكريمة بنجاح 📋');
    setTimeout(() => setCopiedAyahNumber(null), 2000);
  };

  // Memorization toggle single ayah
  const handleToggleAyahReveal = (ayahNumber: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setRevealedAyahs((prev) => ({
      ...prev,
      [ayahNumber]: !prev[ayahNumber],
    }));
  };

  // Jump to Ayah from bottom slider
  const handleJumpToAyah = (ayahNum: number) => {
    setCurrentProgressAyah(ayahNum);
    currentProgressAyahRef.current = ayahNum;
    const el = ayahElementsRef.current[ayahNum];
    if (el) {
      el.scrollIntoView({ behavior: isAutoScrolling ? 'auto' : 'smooth', block: 'center' });
      setTimeout(() => {
        const target = getActiveScrollContainer();
        if (target) {
          virtualScrollTopRef.current = target.scrollTop;
        }
        syncVisibleAyahFromScroll(true);
      }, 60);
    }
  };

  const currentMeta = SURAH_LIST.find((s) => s.number === surahNumber);
  const currentJuz = surah?.juz || currentMeta?.juz || 1;
  const currentHizb = Math.min(60, Math.max(1, (currentJuz - 1) * 2 + 1));
  const isSurahFavorite = favorites.includes(surahNumber);

  // Background and text color themes
  const themeClasses = {
    beige: 'bg-[#F7F7FC] text-[#25263A]',
    white: 'bg-[#FFFFFF] text-[#25263A]',
    dark: 'bg-[#121212] text-[#E6E6F0]',
  }[themeMode];

  const pageContainerBg = {
    beige: 'bg-[#F7F7FC]',
    white: 'bg-[#FFFFFF]',
    dark: 'bg-[#181818]',
  }[themeMode];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${themeClasses} flex flex-col pb-36 select-none`} dir="rtl">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-18 left-1/2 -translate-x-1/2 z-50 bg-[#5B5FEF] text-white px-5 py-2.5 rounded-2xl shadow-xl text-xs font-bold border border-amber-300/40 animate-fade-in flex items-center gap-2">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────
          【1】الشريط العلوي (App Bar)
          • خلفية بيضاء #FFFFFF مع حد ذهبي رفيع أسفل
          • يمين: زر رجوع + "الجزء X" ذهبي
          • وسط: 3 تبويبات ("المصحف"، "التفسير"، "الترجمة")
          • يسار: "سورة ..." + تنقل بين السور
      ───────────────────────────────────────────────────────────── */}
      <header
        className={`sticky top-0 z-40 px-3 md:px-6 py-2.5 border-b border-[#E6E6F0] backdrop-blur-md transition-colors ${
          themeMode === 'dark' ? 'bg-[#1A1A1A]/95 text-white' : 'bg-[#FFFFFF]/95 text-[#25263A]'
        } shadow-xs`}
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
          {/* Right: Back button + "الجزء X" */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={onBack}
              className="p-2 rounded-xl text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title="رجوع للفهرس"
            >
              <ArrowRight className="w-5 h-5" />
            </button>

            <span className="px-2.5 py-1 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] text-[#5B5FEF] text-xs font-bold">
              الجزء {currentJuz}
            </span>
          </div>

          {/* Center: 3 Navigation Tabs ("المصحف"، "التفسير"، "الترجمة") */}
          <div className="flex items-center bg-[#F7F7FC] dark:bg-white/10 p-1 rounded-2xl border border-[#E6E6F0] text-xs font-bold">
            <button
              onClick={() => setActiveTab('mushaf')}
              className={`px-3 md:px-4 py-1.5 rounded-xl transition-all cursor-pointer ${
                activeTab === 'mushaf'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              المصحف
            </button>
            <button
              onClick={() => setActiveTab('tafseer')}
              className={`px-3 md:px-4 py-1.5 rounded-xl transition-all cursor-pointer ${
                activeTab === 'tafseer'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              التفسير
            </button>
            <button
              onClick={() => setActiveTab('translation')}
              className={`px-3 md:px-4 py-1.5 rounded-xl transition-all cursor-pointer ${
                activeTab === 'translation'
                  ? 'bg-[#5B5FEF] text-white shadow-xs font-bold'
                  : 'text-[#77798C] dark:text-gray-400 hover:text-[#5B5FEF]'
              }`}
            >
              الترجمة
            </button>
          </div>

          {/* Left: Surah Name + Prev/Next Chevrons */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              disabled={surahNumber <= 1}
              onClick={() => onNavigateSurah(surahNumber - 1)}
              className="p-1.5 rounded-xl border border-[#E6E6F0] text-[#77798C] dark:text-gray-300 disabled:opacity-25 hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title="السورة السابقة"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <div className="text-center px-1">
              <span className="text-xs md:text-sm font-bold font-amiri text-[#5B5FEF] block truncate max-w-[90px] md:max-w-[130px]">
                سورة {surah?.name || currentMeta?.name}
              </span>
            </div>

            <button
              disabled={surahNumber >= 114}
              onClick={() => onNavigateSurah(surahNumber + 1)}
              className="p-1.5 rounded-xl border border-[#E6E6F0] text-[#77798C] dark:text-gray-300 disabled:opacity-25 hover:bg-[#EEEEFF] transition-colors cursor-pointer"
              title="السورة التالية"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main
        className="max-w-3xl w-full mx-auto px-3 md:px-6 py-4 flex-1"
        onTouchStart={handleReaderTouchStart}
        onTouchMove={handleReaderTouchMove}
        onTouchEnd={handleReaderTouchEnd}
        onTouchCancel={handleReaderTouchEnd}
        onWheel={handleReaderWheel}
      >
        {/* Loading Indicator */}
        {loading && (
          <div className="py-28 flex flex-col items-center justify-center gap-3">
            <div className="w-10 h-10 border-4 border-[#5B5FEF] border-t-transparent rounded-full animate-spin" />
            <span className="text-xs text-[#77798C] font-bold">جارِ تحميل نص السورة الكريمة...</span>
          </div>
        )}

        {!loading && surah && (
          <>
            {/* ═════════════════════════════════════════════════════════
                TAB 1: المصحف (الوضع المتصل مثل المصحف الحقيقي)
            ═════════════════════════════════════════════════════════ */}
            {activeTab === 'mushaf' && (
              <div
                className={`relative rounded-3xl p-5 md:p-8 transition-colors shadow-sm ${pageContainerBg} border-2 border-[#5B5FEF]`}
              >
                {/* Thin double golden frame (2px) around the page */}
                <div className="absolute inset-2 border border-[#E6E6F0] rounded-2xl pointer-events-none" />

                {/* ─────────────────────────────────────────────────────────────
                    【2】عنوان السورة (Surah Header)
                    • إطار ذهبي مزدوج مزخرف
                    • زخارف نباتية إسلامية على الجانبين
                    • اسم السورة بخط Amiri ذهبي كبير (28px)
                    • خلفية بيضاء بإطار ذهبي عريض 3px
                ───────────────────────────────────────────────────────────── */}
                <div className="text-center mb-6 pt-2">
                  <div className="inline-block relative">
                    <div className="bg-white dark:bg-[#202020] px-8 py-3 rounded-2xl border-[3px] border-[#5B5FEF] shadow-sm flex items-center justify-center gap-3 min-w-[260px] md:min-w-[340px]">
                      {/* Islamic arabesque floral flourish right */}
                      <span className="text-[#5B5FEF] text-lg select-none">❁ ❁</span>

                      <h1 className="text-2xl md:text-3xl font-black font-amiri tracking-wide text-[#5B5FEF]">
                        سُورَةُ {surah.name}
                      </h1>

                      {/* Islamic arabesque floral flourish left */}
                      <span className="text-[#5B5FEF] text-lg select-none">❁ ❁</span>
                    </div>

                    {/* Surah mini metadata pill under header */}
                    <div className="mt-2 flex items-center justify-center gap-2 text-xs text-[#77798C] dark:text-gray-400 font-semibold">
                      <span>{surah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'}</span>
                      <span>•</span>
                      <span>{surah.numberOfAyahs} آيات</span>
                      <span>•</span>
                      <span>الجزء {surah.juz}</span>
                    </div>
                  </div>

                  {/* ─────────────────────────────────────────────────────────────
                      【3】البسملة
                      • بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ بخط Amiri 28px بني غامق
                      • في المنتصف بدون إطار
                      • (ما عدا سورة التوبة)
                      • (سورة الفاتحة: البسملة آية رقم 1)
                  ───────────────────────────────────────────────────────────── */}
                  {surah.bismillahPre && (
                    <div
                      className={`mt-6 mb-4 font-amiri text-2xl md:text-3xl font-bold tracking-wider text-center select-none ${
                        themeMode === 'dark' ? 'text-[#E6E6F0]' : 'text-[#25263A]'
                      }`}
                    >
                      بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                    </div>
                  )}
                </div>

                {/* ─────────────────────────────────────────────────────────────
                    【4】نص السورة الكامل (متصل مثل المصحف)
                    • النص كامل ومتصل كأنه صفحة مصحف حقيقية
                    • لا فواصل بين الآيات
                    • رقم كل آية داخل دائرة ذهبية مزخرفة ﴿١﴾ في نهاية الآية
                    • Text Align: Justify
                    • RTL
                ───────────────────────────────────────────────────────────── */}
                <div
                  className={`font-amiri text-justify leading-[2.2] md:leading-[2.4] transition-all p-2 md:p-4 rounded-xl ${
                    themeMode === 'dark' ? 'text-[#E6E6F0]' : 'text-[#25263A]'
                  }`}
                  style={{ fontSize: `${fontSize}px` }}
                >
                  {surah.ayahs.map((ayah) => {
                    const isBookmarked = isAyahBookmarked(ayah.numberInSurah);
                    const isHighlighted = highlightedAyahNumber === ayah.numberInSurah;
                    const isRevealedInHideMode = revealedAyahs[ayah.numberInSurah];
                    const isMasked = isHideMode && !isRevealedInHideMode;

                    return (
                      <span
                        key={ayah.numberInSurah}
                        ref={(el) => (ayahElementsRef.current[ayah.numberInSurah] = el)}
                        onClick={() => setSelectedAyahForSheet(ayah)}
                        className={`inline transition-all px-0.5 rounded-lg cursor-pointer ${
                          isHighlighted
                            ? 'bg-amber-200/80 dark:bg-amber-500/30 ring-2 ring-[#E8B84A]'
                            : isBookmarked
                            ? 'bg-[#EEEEFF] dark:bg-[#5B5FEF]/25 border-b-2 border-[#E8B84A]'
                            : 'hover:bg-[#EEEEFF]'
                        }`}
                        title="انقر لعرض الخيارات والتفسير وحفظ علامة مرجعية"
                      >
                        {/* Ayah Text (or masked if Hide Mode is on) */}
                        <span
                          className={`transition-all duration-300 ${
                            isMasked
                              ? 'filter blur-[7px] opacity-40 select-none bg-amber-200/30 rounded px-1'
                              : ''
                          }`}
                        >
                          {ayah.text}
                        </span>{' '}

                        {/* Inline Decorated Gold Verse Circle ﴿١﴾ */}
                        <span
                          onClick={(e) => {
                            if (isHideMode) {
                              handleToggleAyahReveal(ayah.numberInSurah, e);
                            }
                          }}
                          className={`inline-flex items-center justify-center min-w-[28px] h-7 px-1 mx-1 my-0.5 rounded-full border border-[#5B5FEF] text-[#5B5FEF] font-mono text-[0.8em] font-bold align-baseline select-none transition-transform hover:scale-110 ${
                            isMasked ? 'bg-[#EEEEFF] ring-1 ring-[#5B5FEF]' : ''
                          }`}
                          title={isHideMode ? 'انقر لإظهار/إخفاء الآية' : `آية رقم ${ayah.numberInSurah}`}
                        >
                          ﴿{ayah.numberInSurah}﴾
                        </span>{' '}
                      </span>
                    );
                  })}
                </div>

                {/* Bottom of Surah decorative seal */}
                <div className="mt-8 pt-4 border-t border-[#E6E6F0] text-center flex items-center justify-center gap-3 text-xs text-[#5B5FEF] font-bold">
                  <span>۞ ❁ نِهَايَةُ سُورَةِ {surah.name} ❁ ۞</span>
                </div>
              </div>
            )}

            {/* ═════════════════════════════════════════════════════════
                TAB 2: التفسير الميسر والموثوق
            ═════════════════════════════════════════════════════════ */}
            {activeTab === 'tafseer' && (
              <div className="space-y-4">
                {/* Tafseer Mufassir Selector Bar */}
                <div className="bg-white dark:bg-[#1A1A1A] p-3 rounded-2xl border border-[#E6E6F0] shadow-xs flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-bold text-[#77798C] dark:text-gray-400">
                    اختر كتاب التفسير:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(Object.keys(TAFSEER_CONFIG) as TafseerType[]).map((key) => {
                      const conf = TAFSEER_CONFIG[key];
                      const isSelected = selectedTafseerType === key;
                      return (
                        <button
                          key={key}
                          onClick={() => setSelectedTafseerType(key)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#5B5FEF] text-white shadow-xs'
                              : 'bg-[#F7F7FC] dark:bg-white/5 text-[#25263A] dark:text-gray-300 hover:bg-[#EEEEFF]'
                          }`}
                        >
                          {conf.name}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Author Info */}
                <div className="px-2 text-xs text-[#77798C] flex items-center justify-between">
                  <span className="font-bold text-[#5B5FEF]">
                    {TAFSEER_CONFIG[selectedTafseerType].author}
                  </span>
                  <span>المصدر: مجمع الملك فهد لطباعة المصحف الشريف</span>
                </div>

                {/* Tafseer Verses List */}
                {loadingTabTafseer ? (
                  <div className="py-20 flex flex-col items-center justify-center gap-2 text-[#5B5FEF]">
                    <div className="w-8 h-8 border-3 border-[#5B5FEF] border-t-transparent rounded-full animate-spin" />
                    <span className="text-xs font-bold text-[#77798C]">جارِ جلب التفسير المعتمد...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {surah.ayahs.map((ayah) => (
                      <div
                        key={ayah.numberInSurah}
                        className="bg-white dark:bg-[#1A1A1A] p-4 rounded-2xl border border-[#E6E6F0] shadow-xs"
                      >
                        <div className="flex items-center justify-between border-b border-[#E6E6F0] dark:border-white/10 pb-2 mb-2">
                          <span className="text-xs font-bold text-[#5B5FEF]">
                            الآية {ayah.numberInSurah}
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleToggleBookmark(ayah)}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                                isAyahBookmarked(ayah.numberInSurah)
                                  ? 'bg-[#5B5FEF] text-white'
                                  : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] hover:text-[#5B5FEF]'
                              }`}
                              title="حفظ علامة مرجعية"
                            >
                              <Bookmark
                                className={`w-3.5 h-3.5 ${
                                  isAyahBookmarked(ayah.numberInSurah) ? 'fill-[#E8B84A] text-[#E8B84A]' : ''
                                }`}
                              />
                              <span>{isAyahBookmarked(ayah.numberInSurah) ? 'محفوظة' : 'حفظ علامة'}</span>
                            </button>
                            <button
                              onClick={() => handleCopyAyah(ayah)}
                              className="p-1 rounded-lg text-gray-400 hover:text-[#5B5FEF] transition-colors cursor-pointer"
                              title="نسخ الآية"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        <p className="font-amiri text-lg text-[#25263A] dark:text-[#E6E6F0] mb-2 leading-relaxed">
                          ﴿ {ayah.text} ﴾
                        </p>
                        <div className="p-3 rounded-xl bg-[#F7F7FC]/50 dark:bg-white/5 text-sm text-[#25263A] dark:text-gray-300 leading-relaxed font-sans">
                          {tafseerList[ayah.numberInSurah] ||
                            ayah.tafseer ||
                            'التفسير متوفر عند الاتصال بالشبكة.'}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ═════════════════════════════════════════════════════════
                TAB 3: ترجمة معاني القرآن
            ═════════════════════════════════════════════════════════ */}
            {activeTab === 'translation' && (
              <div className="space-y-4">
                {/* Language Selector */}
                <div className="bg-white dark:bg-[#1A1A1A] p-3 rounded-2xl border border-[#E6E6F0] shadow-xs flex items-center justify-between">
                  <span className="text-xs font-bold text-[#77798C] dark:text-gray-400">
                    لغة الترجمة المعتمدة:
                  </span>
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => setTransLang('en')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        transLang === 'en'
                          ? 'bg-[#5B5FEF] text-white shadow-xs'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] dark:text-gray-300'
                      }`}
                    >
                      English (Sahih International)
                    </button>
                    <button
                      onClick={() => setTransLang('fr')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        transLang === 'fr'
                          ? 'bg-[#5B5FEF] text-white shadow-xs'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] dark:text-gray-300'
                      }`}
                    >
                      Français (Hamidullah)
                    </button>
                    <button
                      onClick={() => setTransLang('ur')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        transLang === 'ur'
                          ? 'bg-[#5B5FEF] text-white shadow-xs'
                          : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] dark:text-gray-300'
                      }`}
                    >
                      اردو (Jalandhry)
                    </button>
                  </div>
                </div>

                {/* Translation Verses List */}
                <div className="space-y-3">
                  {surah.ayahs.map((ayah) => {
                    const transText =
                      transLang === 'en'
                        ? ayah.translationEn
                        : transLang === 'fr'
                        ? ayah.translationFr
                        : ayah.translationUr;

                    return (
                      <div
                        key={ayah.numberInSurah}
                        className="bg-white dark:bg-[#1A1A1A] p-4 rounded-2xl border border-[#E6E6F0] shadow-xs"
                      >
                        <div className="flex items-center justify-between border-b border-[#E6E6F0] dark:border-white/10 pb-2 mb-2">
                          <span className="text-xs font-bold text-[#5B5FEF]">
                            الآية {ayah.numberInSurah}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleToggleBookmark(ayah)}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                              isAyahBookmarked(ayah.numberInSurah)
                                ? 'bg-[#5B5FEF] text-white'
                                : 'bg-[#F7F7FC] dark:bg-white/5 text-[#77798C] hover:text-[#5B5FEF]'
                            }`}
                            title="حفظ علامة مرجعية"
                          >
                            <Bookmark
                              className={`w-3.5 h-3.5 ${
                                isAyahBookmarked(ayah.numberInSurah) ? 'fill-[#E8B84A] text-[#E8B84A]' : ''
                              }`}
                            />
                            <span>{isAyahBookmarked(ayah.numberInSurah) ? 'محفوظة' : 'حفظ علامة'}</span>
                          </button>
                        </div>
                        <p className="font-amiri text-lg text-[#25263A] dark:text-[#E6E6F0] mb-2 leading-relaxed">
                          ﴿ {ayah.text} ﴾
                        </p>
                        <div
                          className="p-3 rounded-xl bg-gray-50 dark:bg-white/5 text-sm text-gray-700 dark:text-gray-300 leading-relaxed font-sans"
                          dir={transLang === 'ur' ? 'rtl' : 'ltr'}
                        >
                          {transText || 'Translation available online.'}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* ─────────────────────────────────────────────────────────────
          【6】الشريط السفلي (Bottom Bar)
          • ⚙️ (الإعدادات) → تعديل الخط والثيم
          • 🔖 (إشارة مرجعية) → حفظ الموضع الحالي
          • وضع الإخفاء ⬜ (Toggle) → إخفاء الآيات للحفظ
          • "حزب X" → مؤشر الحزب الحالي
          • شريط تمرير أفقي أسفل الشاشة → للتنقل السريع
      ───────────────────────────────────────────────────────────── */}
      <footer
        className={`fixed bottom-0 left-0 right-0 z-40 border-t border-[#E6E6F0] backdrop-blur-md transition-colors ${
          themeMode === 'dark' ? 'bg-[#1A1A1A]/95 text-white' : 'bg-[#FFFFFF]/95 text-[#25263A]'
        } shadow-lg py-2.5 px-4`}
      >
        <div className="max-w-2xl mx-auto flex flex-col gap-2">
          {/* لوحة التحكم في التمرير التلقائي والسرعة */}
          {(isAutoScrolling || isAutoScrollPausedByManual || showAutoScrollControls) && (
            <div className="p-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-white/5 border border-[#5B5FEF]/30 space-y-2 animate-fade-in">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      isAutoScrolling
                        ? 'bg-emerald-500 animate-pulse shadow-xs shadow-emerald-500/50'
                        : isAutoScrollPausedByManual
                        ? 'bg-amber-500'
                        : 'bg-gray-400'
                    }`}
                  />
                  <span className="text-[11px] sm:text-xs font-bold text-[#25263A] dark:text-white">
                    {isAutoScrolling
                      ? 'التمرير التلقائي يعمل حاليًا'
                      : isAutoScrollPausedByManual
                      ? 'توقف مؤقتًا بسبب التفاعل اليدوي — يمكنك الاستئناف من نفس الموضع'
                      : 'إعدادات سرعة التمرير التلقائي'}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  {AUTO_SCROLL_PRESETS.map((preset) => {
                    const isPresetActive = getActiveSpeedPreset(autoScrollSpeed) === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => updateAutoScrollSpeed(preset.speed)}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                          isPresetActive
                            ? 'bg-[#5B5FEF] text-white shadow-2xs'
                            : 'bg-white dark:bg-white/10 text-[#77798C] dark:text-gray-300 border border-[#E6E6F0] hover:border-[#5B5FEF]'
                        }`}
                      >
                        {preset.label}
                      </button>
                    );
                  })}

                  {!isAutoScrolling && (
                    <button
                      type="button"
                      onClick={() => {
                        setShowAutoScrollControls(false);
                        setIsAutoScrollPausedByManual(false);
                      }}
                      className="p-1 rounded-lg text-gray-400 hover:text-[#77798C] mr-1 cursor-pointer"
                      title="إخفاء شريط السرعة"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2.5 pt-0.5">
                <Gauge className="w-3.5 h-3.5 text-[#5B5FEF] shrink-0" />
                <span className="text-[11px] text-[#77798C] dark:text-gray-400 font-bold shrink-0">
                  السرعة:
                </span>
                <button
                  type="button"
                  onClick={() => updateAutoScrollSpeed(autoScrollSpeed - 3)}
                  className="w-6 h-6 rounded-lg bg-white dark:bg-white/10 border border-[#E6E6F0] text-[#5B5FEF] font-bold text-xs flex items-center justify-center hover:bg-[#EEEEFF] cursor-pointer shrink-0"
                  title="إبطاء السرعة"
                >
                  -
                </button>
                <input
                  type="range"
                  min={8}
                  max={60}
                  step={1}
                  value={autoScrollSpeed}
                  onChange={(e) => updateAutoScrollSpeed(parseInt(e.target.value, 10))}
                  className="w-full accent-[#5B5FEF] h-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg cursor-pointer"
                />
                <button
                  type="button"
                  onClick={() => updateAutoScrollSpeed(autoScrollSpeed + 3)}
                  className="w-6 h-6 rounded-lg bg-white dark:bg-white/10 border border-[#E6E6F0] text-[#5B5FEF] font-bold text-xs flex items-center justify-center hover:bg-[#EEEEFF] cursor-pointer shrink-0"
                  title="زيادة السرعة"
                >
                  +
                </button>
                <span className="text-[11px] font-bold text-[#5B5FEF] font-mono min-w-[34px] text-left shrink-0">
                  {Math.round((autoScrollSpeed / 26) * 10) / 10}x
                </span>
              </div>
            </div>
          )}

          {/* Top row of Bottom Bar */}
          <div className="flex items-center justify-between gap-2">
            {/* Left buttons (⚙️ Settings, 🔖 Bookmark, ⭐ Favorite) */}
            <div className="flex items-center gap-1.5">
              {/* Auto-Scroll Play / Stop Button */}
              <button
                type="button"
                onClick={toggleAutoScroll}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  isAutoScrolling
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500 shadow-xs'
                    : isAutoScrollPausedByManual
                    ? 'bg-amber-500 hover:bg-amber-600 text-white border-amber-500 shadow-xs'
                    : 'bg-[#EEEEFF] text-[#5B5FEF] border-[#5B5FEF]/30 hover:bg-[#5B5FEF] hover:text-white'
                }`}
                title={isAutoScrolling ? 'إيقاف التمرير التلقائي' : 'بدء التمرير التلقائي'}
              >
                {isAutoScrolling ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    <span>إيقاف التمرير</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>التمرير التلقائي</span>
                  </>
                )}
              </button>
              <button
                onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                className={`p-2 rounded-xl border border-[#E6E6F0] text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer ${
                  isSettingsOpen ? 'bg-[#5B5FEF] text-white' : ''
                }`}
                title="تعديل الخط والثيم"
              >
                <Settings className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  if (surah) {
                    const currentAyah =
                      surah.ayahs[Math.min(currentProgressAyah - 1, surah.ayahs.length - 1)] ||
                      surah.ayahs[0];
                    if (currentAyah) handleToggleBookmark(currentAyah);
                  }
                }}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  isAyahBookmarked(currentProgressAyah)
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                    : 'border-[#E6E6F0] text-[#5B5FEF] hover:bg-[#EEEEFF]'
                }`}
                title="حفظ الآية الحالية في العلامات المرجعية"
              >
                <Bookmark
                  className={`w-4 h-4 ${
                    isAyahBookmarked(currentProgressAyah) ? 'fill-[#E8B84A] text-[#E8B84A]' : ''
                  }`}
                />
              </button>

              <button
                type="button"
                onClick={() => setIsBookmarksModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl border border-[#E6E6F0] bg-[#F7F7FC] dark:bg-white/5 text-[#5B5FEF] hover:bg-[#EEEEFF] transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                title="عرض قائمة العلامات المرجعية"
              >
                <Bookmark className="w-3.5 h-3.5 fill-[#E8B84A]" />
                <span>العلامات ({bookmarks.length})</span>
              </button>

              <button
                onClick={handleToggleFavoriteSurah}
                className={`p-2 rounded-xl border border-[#E6E6F0] transition-colors cursor-pointer ${
                  isSurahFavorite ? 'text-amber-500 bg-[#EEEEFF] dark:bg-amber-950/40' : 'text-gray-400'
                }`}
                title="إضافة للمفضلة"
              >
                <Star className={`w-4 h-4 ${isSurahFavorite ? 'fill-amber-500' : ''}`} />
              </button>
            </div>

            {/* Middle: وضع الإخفاء ⬜ Toggle */}
            <button
              onClick={() => {
                setIsHideMode(!isHideMode);
                showToast(!isHideMode ? 'تم تفعيل وضع الإخفاء للحفظ والتسميع 👁️' : 'تم إلغاء وضع الإخفاء');
              }}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                isHideMode
                  ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-sm'
                  : 'bg-[#F7F7FC] dark:bg-white/10 text-[#25263A] dark:text-gray-300 border-[#E6E6F0] hover:bg-[#EEEEFF]'
              }`}
            >
              {isHideMode ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              <span>وضع الإخفاء</span>
            </button>

            {/* Right: "حزب X" badge */}
            <div className="px-3 py-1 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] text-[#5B5FEF] text-xs font-bold font-mono">
              حزب {currentHizb}
            </div>
          </div>

          {/* Bottom row: Ayah Quick Scroller / Slider */}
          {surah && surah.numberOfAyahs > 1 && (
            <div className="flex items-center gap-3 pt-1">
              <span className="text-[11px] text-[#77798C] font-mono shrink-0">آية 1</span>
              <input
                type="range"
                min={1}
                max={surah.numberOfAyahs}
                value={currentProgressAyah}
                onChange={(e) => handleJumpToAyah(parseInt(e.target.value, 10))}
                className="w-full accent-[#E8B84A] cursor-pointer h-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none"
              />
              <span className="text-[11px] text-[#5B5FEF] font-mono shrink-0 font-bold">
                {currentProgressAyah}/{surah.numberOfAyahs}
              </span>
            </div>
          )}
        </div>
      </footer>

      {/* ─────────────────────────────────────────────────────────────
          【7】نافذة الإعدادات (Settings Modal/Popover)
      ───────────────────────────────────────────────────────────── */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3" dir="rtl">
          <div className="fixed inset-0 bg-black/50 backdrop-blur-xs" onClick={() => setIsSettingsOpen(false)} />
          <div className="relative w-full max-w-sm bg-white dark:bg-[#1A1A1A] rounded-3xl p-5 border-2 border-[#5B5FEF] shadow-2xl z-10 animate-slide-up">
            <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0] mb-4">
              <h3 className="font-bold text-base text-[#5B5FEF]">إعدادات المصحف الشريف</h3>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-[#77798C]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Font size control (20px to 36px) */}
            <div className="mb-5">
              <div className="flex items-center justify-between text-xs font-bold text-[#77798C] dark:text-gray-300 mb-2">
                <span>حجم خط القرآن:</span>
                <span className="text-[#5B5FEF] font-mono">{fontSize}px</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-400">أصغر</span>
                <input
                  type="range"
                  min={20}
                  max={36}
                  value={fontSize}
                  onChange={(e) => handleFontSizeChange(parseInt(e.target.value, 10))}
                  className="w-full accent-[#E8B84A] cursor-pointer"
                />
                <span className="text-xs text-gray-400">أكبر</span>
              </div>
            </div>

            {/* Theme selector (Beige / White / Dark) */}
            <div>
              <span className="block text-xs font-bold text-[#77798C] dark:text-gray-300 mb-2">
                مظهر القراءة وخلفية الصفحة:
              </span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => handleThemeChange('beige')}
                  className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    themeMode === 'beige'
                      ? 'border-[#5B5FEF] ring-2 ring-[#5B5FEF] bg-[#F7F7FC] text-[#25263A]'
                      : 'border-[#E6E6F0] bg-[#F7F7FC] text-[#25263A]'
                  }`}
                >
                  <span className="w-5 h-5 rounded-full bg-[#F7F7FC] border border-[#5B5FEF]" />
                  <span>بيج ورقي</span>
                </button>

                <button
                  onClick={() => handleThemeChange('white')}
                  className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    themeMode === 'white'
                      ? 'border-[#5B5FEF] ring-2 ring-[#5B5FEF] bg-white text-[#25263A]'
                      : 'border-[#E6E6F0] bg-white text-[#25263A]'
                  }`}
                >
                  <span className="w-5 h-5 rounded-full bg-white border border-gray-300" />
                  <span>أبيض ناصع</span>
                </button>

                <button
                  onClick={() => handleThemeChange('dark')}
                  className={`p-2.5 rounded-2xl border text-xs font-bold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                    themeMode === 'dark'
                      ? 'border-[#5B5FEF] ring-2 ring-[#5B5FEF] bg-[#121212] text-white'
                      : 'border-gray-700 bg-[#121212] text-white'
                  }`}
                >
                  <span className="w-5 h-5 rounded-full bg-[#121212] border border-gray-600" />
                  <span>وضع ليلي</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─────────────────────────────────────────────────────────────
          【8】الضغط على الآية: القائمة السفلية (Bottom Sheet)
          • 📋 نسخ الآية
          • 📤 مشاركة الآية
          • 🔖 إشارة مرجعية
          • 📖 التفسير
          • ⭐ إضافة للمفضلة
      ───────────────────────────────────────────────────────────── */}
      {selectedAyahForSheet && (
        <div className="fixed inset-0 z-50 flex items-end justify-center" dir="rtl">
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-xs animate-fade-in"
            onClick={() => setSelectedAyahForSheet(null)}
          />

          <div className="relative w-full max-w-lg bg-white dark:bg-[#1A1A1A] rounded-t-3xl border-t-2 border-r-2 border-l-2 border-[#5B5FEF] p-5 shadow-2xl z-10 animate-slide-up">
            {/* Header with Ayah preview */}
            <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0] mb-3">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-[#5B5FEF] text-white font-mono text-xs font-bold flex items-center justify-center">
                  {selectedAyahForSheet.numberInSurah}
                </span>
                <div>
                  <h4 className="text-sm font-bold font-amiri text-[#5B5FEF]">
                    سورة {surah?.name} — الآية {selectedAyahForSheet.numberInSurah}
                  </h4>
                  <p className="text-[11px] text-[#77798C]">الجزء {selectedAyahForSheet.juz}</p>
                </div>
              </div>

              <button
                onClick={() => setSelectedAyahForSheet(null)}
                className="p-1.5 rounded-xl text-gray-400 hover:text-[#77798C] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Ayah Snippet */}
            <div className="p-3 bg-[#F7F7FC] dark:bg-white/5 rounded-2xl border border-[#E6E6F0] text-center mb-4">
              <p className="font-amiri text-lg text-[#25263A] dark:text-[#E6E6F0] line-clamp-3">
                ﴿ {selectedAyahForSheet.text} ﴾
              </p>
            </div>

            {/* Action buttons grid */}
            <div className="grid grid-cols-4 gap-2 text-center">
              {/* 📋 نسخ */}
              <button
                onClick={() => {
                  handleCopyAyah(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className="p-3 rounded-2xl bg-[#F7F7FC] dark:bg-white/10 hover:bg-[#EEEEFF] transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-5 h-5 text-[#5B5FEF]" />
                <span className="text-xs font-bold text-[#25263A] dark:text-gray-300">نسخ</span>
              </button>

              {/* 📤 مشاركة */}
              <button
                onClick={() => {
                  setShareCardAyah(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className="p-3 rounded-2xl bg-[#F7F7FC] dark:bg-white/10 hover:bg-[#EEEEFF] transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer"
              >
                <Share2 className="w-5 h-5 text-[#5B5FEF]" />
                <span className="text-xs font-bold text-[#25263A] dark:text-gray-300">مشاركة</span>
              </button>

              {/* 🔖 إشارة مرجعية */}
              <button
                onClick={() => {
                  handleToggleBookmark(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className="p-3 rounded-2xl bg-[#F7F7FC] dark:bg-white/10 hover:bg-[#EEEEFF] transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer"
              >
                <Bookmark
                  className={`w-5 h-5 ${
                    isAyahBookmarked(selectedAyahForSheet.numberInSurah)
                      ? 'text-[#5B5FEF] fill-[#E8B84A]'
                      : 'text-[#5B5FEF]'
                  }`}
                />
                <span className="text-xs font-bold text-[#25263A] dark:text-gray-300">إشارة</span>
              </button>

              {/* 📖 التفسير */}
              <button
                onClick={() => {
                  setTafseerAyah(selectedAyahForSheet);
                  setSelectedAyahForSheet(null);
                }}
                className="p-3 rounded-2xl bg-[#5B5FEF] text-white hover:bg-[#4145C7] transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <BookOpen className="w-5 h-5" />
                <span className="text-xs font-bold">التفسير</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tafseer Detailed Modal */}
      {tafseerAyah && surah && (
        <TafseerModal
          isOpen={true}
          onClose={() => setTafseerAyah(null)}
          surahNumber={surah.number}
          surahName={surah.name}
          ayah={tafseerAyah}
        />
      )}

      {/* Share Image Card Modal */}
      {shareCardAyah && surah && (
        <VerseCardModal
          isOpen={true}
          onClose={() => setShareCardAyah(null)}
          surahName={surah.name}
          ayah={shareCardAyah}
        />
      )}

      {/* Bookmarks List Modal & Side Drawer */}
      <BookmarksModal
        isOpen={isBookmarksModalOpen}
        onClose={() => setIsBookmarksModalOpen(false)}
        bookmarks={bookmarks}
        onSelectBookmark={handleSelectBookmarkTarget}
        onDeleteBookmark={handleDeleteBookmarkById}
        onUpdateBookmarkNote={handleUpdateBookmarkNote}
        readerThemeMode={themeMode}
        currentSurahNumber={surahNumber}
        currentAyahNumber={currentProgressAyah}
        isCurrentAyahBookmarked={isAyahBookmarked(currentProgressAyah)}
        onBookmarkCurrentAyah={() => {
          if (!surah) return;
          const currentAyahObj =
            surah.ayahs[Math.min(currentProgressAyah - 1, surah.ayahs.length - 1)] || surah.ayahs[0];
          if (currentAyahObj) {
            handleToggleBookmark(currentAyahObj);
          }
        }}
      />
    </div>
  );
};
