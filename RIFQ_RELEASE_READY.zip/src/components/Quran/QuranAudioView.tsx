import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  QURAN_AUDIO_RECITERS,
  QuranAudioReciter,
  SURAH_LIST,
  SurahMeta,
  getResilientSurahAudioUrls,
  buildEveryAyahAudioUrl,
  formatSurahThreeDigits,
} from '../../data/quranAudioData';
import {
  initQuranAudioSqliteTables,
  syncRecitersFromMp3QuranApi,
  fetchQuranComChapterAudioUrl,
  getFavoriteReciterIds,
  toggleFavoriteReciterId,
  getFavoriteTracks,
  toggleFavoriteTrack,
  getRecentPlays,
  saveRecentPlay,
  getDownloadedTracks,
  getDownloadedTrackForSurah,
  verifyAndSyncOfflineDownloads,
  subscribeToOfflineDownloads,
  downloadSurahForOffline,
  getPlayableOfflineSurahUrl,
  removeOfflineDownload,
  getSavedSelectedReciterId,
  saveSelectedReciterId,
  formatBytesArabic,
  FavoriteTrackRecord,
  DownloadedTrackRecord,
  RecentPlayRecord,
} from '../../utils/quranAudioSqlite';
import { getSurahDetail } from '../../utils/quranService';
import { AyahItem } from '../../data/quranData';

interface QuranAudioViewProps {
  onBack?: () => void;
}

type AudioMainTab = 'reciters' | 'surahs' | 'favorites' | 'downloads' | 'recent';
type PlaybackRepeatMode = 'sequential' | 'repeat_one' | 'stop_after_one';

function normalizeArabicForSearch(text: string): string {
  return text
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .trim()
    .toLowerCase();
}

function formatTimeMMSS(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
  const totalSec = Math.floor(seconds);
  const hrs = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  if (hrs > 0) {
    return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

/**
 * أيقونة سماعة + مصحف ذهبية فاخرة (بدون أي لون بني)
 */
const GoldenHeadphonesMushafSvg: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden="true">
    {/* قوس السماعة الذهبي */}
    <path
      d="M6 16C6 10.477 10.477 6 16 6C21.523 6 26 10.477 26 16"
      stroke="#5B5FEF"
      strokeWidth="2.2"
      strokeLinecap="round"
    />
    {/* وسائد السماعة */}
    <rect x="4" y="15" width="4" height="7" rx="2" fill="#E8B84A" stroke="#5B5FEF" strokeWidth="1.2" />
    <rect x="24" y="15" width="4" height="7" rx="2" fill="#E8B84A" stroke="#5B5FEF" strokeWidth="1.2" />
    {/* المصحف المفتوح في الوسط */}
    <path
      d="M16 14.5C14.2 13.5 11.8 13.3 9.8 14V23.2C11.8 22.5 14.2 22.7 16 23.7C17.8 22.7 20.2 22.5 22.2 23.2V14C20.2 13.3 17.8 13.5 16 14.5Z"
      fill="#F7F7FC"
      stroke="#5B5FEF"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    <path d="M16 14.5V23.7" stroke="#5B5FEF" strokeWidth="1.4" strokeLinecap="round" />
    {/* حامل المصحف (الرحل) */}
    <path d="M11.5 25.5L16 23.8L20.5 25.5" stroke="#4CAF82" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export const QuranAudioView: React.FC<QuranAudioViewProps> = ({ onBack }) => {
  // Navigation & Tabs State
  const [activeTab, setActiveTab] = useState<AudioMainTab>('reciters');
  const [selectedReciterForPage, setSelectedReciterForPage] = useState<QuranAudioReciter | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchBar, setShowSearchBar] = useState(true);
  const [surahFilterInReciterPage, setSurahFilterInReciterPage] = useState<'all' | 'Meccan' | 'Medinan' | 'downloaded'>('all');
  const [quickReciterIdForSurahsTab, setQuickReciterIdForSurahsTab] = useState<string>(() => getSavedSelectedReciterId());
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Persistent Data State
  const [favReciterIds, setFavReciterIds] = useState<string[]>([]);
  const [favTracks, setFavTracks] = useState<FavoriteTrackRecord[]>([]);
  const [downloadedTracks, setDownloadedTracks] = useState<DownloadedTrackRecord[]>(() => getDownloadedTracks());
  const [recentPlays, setRecentPlays] = useState<RecentPlayRecord[]>([]);
  const [liveApiServers, setLiveApiServers] = useState<Record<number, string>>({});

  // Download Progress Map: `${reciterId}_${surahNumber}` -> percent
  const [downloadingMap, setDownloadingMap] = useState<Record<string, number>>({});
  // Failed Downloads Map: `${reciterId}_${surahNumber}` -> error message
  const [failedDownloadsMap, setFailedDownloadsMap] = useState<Record<string, string>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Audio Player State
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [currentReciter, setCurrentReciter] = useState<QuranAudioReciter>(() => {
    const savedId = getSavedSelectedReciterId();
    return QURAN_AUDIO_RECITERS.find((r) => r.id === savedId) || QURAN_AUDIO_RECITERS[0];
  });
  const [currentSurahNumber, setCurrentSurahNumber] = useState<number>(1);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isBuffering, setIsBuffering] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [repeatMode, setRepeatMode] = useState<PlaybackRepeatMode>('sequential');
  const [isFullPlayerOpen, setIsFullPlayerOpen] = useState<boolean>(false);
  const [hasActiveSession, setHasActiveSession] = useState<boolean>(false);

  // Ayah-by-Ayah Mode (EveryAyah.com) inside Full Player
  const [isAyahByAyahMode, setIsAyahByAyahMode] = useState<boolean>(false);
  const [currentAyahNumber, setCurrentAyahNumber] = useState<number>(1);
  const [surahAyahsText, setSurahAyahsText] = useState<AyahItem[]>([]);
  const [loadingSurahText, setLoadingSurahText] = useState<boolean>(false);

  // Sleep Timer State
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimerRemainingSeconds, setSleepTimerRemainingSeconds] = useState<number | null>(null);
  const [isSleepTimerPopoverOpen, setIsSleepTimerPopoverOpen] = useState<boolean>(false);

  // Fallback URL index tracking to prevent broken audio links
  const candidateUrlsRef = useRef<string[]>([]);
  const candidateIndexRef = useRef<number>(0);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  // Initialize Local Storage, Verify Physical Offline Files & Sync MP3Quran.net API
  useEffect(() => {
    initQuranAudioSqliteTables();
    setFavReciterIds(getFavoriteReciterIds());
    setFavTracks(getFavoriteTracks());
    setDownloadedTracks(getDownloadedTracks());
    const recents = getRecentPlays();
    setRecentPlays(recents);

    const savedReciterId = getSavedSelectedReciterId();
    const savedReciter = QURAN_AUDIO_RECITERS.find((r) => r.id === savedReciterId);
    if (savedReciter) {
      setQuickReciterIdForSurahsTab(savedReciter.id);
      setCurrentReciter(savedReciter);
    }

    if (recents.length > 0) {
      const last = recents[0];
      const foundReciter = QURAN_AUDIO_RECITERS.find((r) => r.id === last.reciterId);
      if (foundReciter) {
        setCurrentReciter(foundReciter);
        setCurrentSurahNumber(last.surahNumber);
      }
    }

    // Subscribe to reactive updates when offline files are verified or modified
    const unsubscribe = subscribeToOfflineDownloads((verifiedList) => {
      setDownloadedTracks(verifiedList);
    });

    // Immediately verify physical audio files on device storage
    verifyAndSyncOfflineDownloads()
      .then((verifiedList) => {
        setDownloadedTracks(verifiedList);
      })
      .catch(() => {});

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        verifyAndSyncOfflineDownloads()
          .then((verifiedList) => {
            setDownloadedTracks(verifiedList);
          })
          .catch(() => {});
      }
    };

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('focus', handleVisibilityOrFocus);
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    syncRecitersFromMp3QuranApi().then((servers) => {
      if (servers && Object.keys(servers).length > 0) {
        setLiveApiServers(servers);
      }
    });

    return () => {
      unsubscribe();
      window.removeEventListener('focus', handleVisibilityOrFocus);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load Surah Ayahs when Full Player is opened or Surah changes
  useEffect(() => {
    let active = true;
    setLoadingSurahText(true);
    getSurahDetail(currentSurahNumber)
      .then((detail) => {
        if (active && detail?.ayahs) {
          setSurahAyahsText(detail.ayahs);
        }
      })
      .catch(() => {})
      .finally(() => {
        if (active) setLoadingSurahText(false);
      });
    return () => {
      active = false;
    };
  }, [currentSurahNumber]);

  // Sleep timer countdown with gradual volume fade-out
  useEffect(() => {
    if (sleepTimerRemainingSeconds === null) return;
    if (sleepTimerRemainingSeconds <= 0) {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.volume = 1;
      }
      setIsPlaying(false);
      setSleepTimerMinutes(null);
      setSleepTimerRemainingSeconds(null);
      showToast('انتهى مؤقت النوم وتم إيقاف التلاوة تلقائياً');
      return;
    }
    if (sleepTimerRemainingSeconds <= 5 && audioRef.current) {
      audioRef.current.volume = Math.max(0.1, sleepTimerRemainingSeconds / 5);
    }
    const timer = setInterval(() => {
      setSleepTimerRemainingSeconds((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);
    return () => clearInterval(timer);
  }, [sleepTimerRemainingSeconds, showToast]);

  const currentSurahMeta: SurahMeta = useMemo(
    () => SURAH_LIST.find((s) => s.number === currentSurahNumber) || SURAH_LIST[0],
    [currentSurahNumber]
  );

  // Build resilient URLs including live MP3Quran API server if available
  const getCandidateUrlsForReciterAndSurah = useCallback(
    (reciter: QuranAudioReciter, surahNum: number): string[] => {
      const baseList = getResilientSurahAudioUrls(reciter, surahNum);
      const apiServer = liveApiServers[reciter.mp3QuranApiId];
      if (apiServer) {
        const cleanServer = apiServer.endsWith('/') ? apiServer : `${apiServer}/`;
        const apiAudioUrl = `${cleanServer}${formatSurahThreeDigits(surahNum)}.mp3`;
        return Array.from(new Set([apiAudioUrl, ...baseList]));
      }
      return baseList;
    },
    [liveApiServers]
  );

  // Update MediaSession metadata for background playback & system notifications
  const updateMediaSessionMetadata = useCallback(
    (reciter: QuranAudioReciter, surah: SurahMeta, ayahNum?: number) => {
      if ('mediaSession' in navigator) {
        try {
          navigator.mediaSession.metadata = new MediaMetadata({
            title: ayahNum
              ? `سورة ${surah.name} — الآية ${ayahNum}`
              : `سورة ${surah.name}`,
            artist: `الشيخ ${reciter.name}`,
            album: `رِفْق | القرآن الكريم — استماع (${reciter.rewaya})`,
            artwork: [
              {
                src: '/assets/icons/menu/ic_quran_audio.png',
                sizes: '128x128',
                type: 'image/png',
              },
            ],
          });
        } catch {
          // ignore
        }
      }
    },
    []
  );

  // Core function to start playing a Surah (or specific Ayah)
  const playRecitation = useCallback(
    async (
      reciter: QuranAudioReciter,
      surahNum: number,
      options?: { ayahMode?: boolean; ayahNumber?: number; resumeSeconds?: number }
    ) => {
      const surahMeta = SURAH_LIST.find((s) => s.number === surahNum) || SURAH_LIST[0];
      const useAyahMode = options?.ayahMode ?? isAyahByAyahMode;
      const targetAyah = options?.ayahNumber ?? 1;

      setCurrentReciter(reciter);
      setCurrentSurahNumber(surahNum);
      setHasActiveSession(true);
      setIsBuffering(true);

      if (!audioRef.current) {
        audioRef.current = new Audio();
        audioRef.current.preload = 'auto';
      }

      const audio = audioRef.current;
      audio.playbackRate = playbackSpeed;

      let effectiveReciter = reciter;
      const offlineNow = typeof navigator !== 'undefined' && navigator.onLine === false;

      if (useAyahMode && !offlineNow) {
        setCurrentAyahNumber(targetAyah);
        const ayahUrl = buildEveryAyahAudioUrl(reciter, surahNum, targetAyah);
        candidateUrlsRef.current = [
          ayahUrl,
          buildEveryAyahAudioUrl(QURAN_AUDIO_RECITERS[0], surahNum, targetAyah),
        ];
        candidateIndexRef.current = 0;
        audio.src = candidateUrlsRef.current[0];
      } else {
        // 1. Check if the Surah file exists locally on the device for this reciter
        let localPlayable = await getPlayableOfflineSurahUrl(reciter.id, surahNum);

        // 2. If offline and not downloaded for this reciter, check if downloaded for any other reciter
        if (!localPlayable && offlineNow) {
          const fallbackRecord = getDownloadedTrackForSurah(surahNum, reciter.id);
          if (fallbackRecord) {
            localPlayable = await getPlayableOfflineSurahUrl(fallbackRecord.reciterId, surahNum);
            const matchedReciter = QURAN_AUDIO_RECITERS.find((r) => r.id === fallbackRecord.reciterId);
            if (matchedReciter) {
              effectiveReciter = matchedReciter;
              setCurrentReciter(matchedReciter);
            }
          }
        }

        const candidates = getCandidateUrlsForReciterAndSurah(effectiveReciter, surahNum);

        if (localPlayable && localPlayable.url) {
          // Use the local file directly without re-downloading
          candidateUrlsRef.current = offlineNow
            ? [localPlayable.url]
            : [localPlayable.url, ...candidates];
        } else if (offlineNow) {
          setIsBuffering(false);
          setIsPlaying(false);
          showToast(`سورة ${surahMeta.name} غير محملة للاستماع بدون إنترنت`);
          return;
        } else {
          candidateUrlsRef.current = candidates;
        }

        candidateIndexRef.current = 0;
        audio.src = candidateUrlsRef.current[0];
      }

      updateMediaSessionMetadata(
        effectiveReciter,
        surahMeta,
        useAyahMode && !offlineNow ? targetAyah : undefined
      );

      try {
        await audio.play();
        if (options?.resumeSeconds && options.resumeSeconds > 2 && !useAyahMode) {
          audio.currentTime = options.resumeSeconds;
        }
        setIsPlaying(true);
        setIsBuffering(false);
        const updatedRecents = saveRecentPlay(
          effectiveReciter,
          surahNum,
          options?.resumeSeconds || 0,
          audio.duration || 0
        );
        setRecentPlays(updatedRecents);
      } catch {
        // Trigger fallback on initial play failure
        handleAudioErrorFallback(effectiveReciter, surahNum, useAyahMode && !offlineNow, targetAyah);
      }
    },
    [
      isAyahByAyahMode,
      playbackSpeed,
      getCandidateUrlsForReciterAndSurah,
      updateMediaSessionMetadata,
      showToast,
    ]
  );

  const handleAudioErrorFallback = useCallback(
    async (
      reciter: QuranAudioReciter,
      surahNum: number,
      ayahMode: boolean,
      ayahNum: number
    ) => {
      const audio = audioRef.current;
      if (!audio) return;

      const nextIdx = candidateIndexRef.current + 1;
      if (nextIdx < candidateUrlsRef.current.length) {
        candidateIndexRef.current = nextIdx;
        audio.src = candidateUrlsRef.current[nextIdx];
        try {
          await audio.play();
          setIsPlaying(true);
          setIsBuffering(false);
          return;
        } catch {
          // continue to next fallback
        }
      }

      // Query Quran.com API v4 dynamically as an extra safety net when online
      if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        setIsBuffering(false);
        setIsPlaying(false);
        return;
      }

      if (!ayahMode) {
        const quranComUrl = await fetchQuranComChapterAudioUrl(
          reciter.quranComRecitationId || 7,
          surahNum
        );
        if (quranComUrl && !candidateUrlsRef.current.includes(quranComUrl)) {
          candidateUrlsRef.current.push(quranComUrl);
          candidateIndexRef.current = candidateUrlsRef.current.length - 1;
          audio.src = quranComUrl;
          try {
            await audio.play();
            setIsPlaying(true);
            setIsBuffering(false);
            return;
          } catch {
            // ignore
          }
        }
      } else {
        const fallbackAyahUrl = buildEveryAyahAudioUrl(QURAN_AUDIO_RECITERS[0], surahNum, ayahNum);
        if (audio.src !== fallbackAyahUrl) {
          audio.src = fallbackAyahUrl;
          try {
            await audio.play();
            setIsPlaying(true);
            setIsBuffering(false);
            return;
          } catch {
            // ignore
          }
        }
      }

      setIsBuffering(false);
      setIsPlaying(false);
    },
    []
  );

  // Attach Audio Element Event Listeners
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.preload = 'auto';
    }
    const audio = audioRef.current;

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime || 0);
      if (audio.duration && Number.isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const onLoadedMetadata = () => {
      if (audio.duration && Number.isFinite(audio.duration)) {
        setDuration(audio.duration);
      }
      setIsBuffering(false);
    };

    const onWaiting = () => setIsBuffering(true);
    const onCanPlay = () => setIsBuffering(false);

    const onEnded = () => {
      if (isAyahByAyahMode) {
        const maxAyahs = currentSurahMeta.numberOfAyahs;
        if (currentAyahNumber < maxAyahs) {
          playRecitation(currentReciter, currentSurahNumber, {
            ayahMode: true,
            ayahNumber: currentAyahNumber + 1,
          });
          return;
        }
      }

      if (repeatMode === 'repeat_one') {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      } else if (repeatMode === 'sequential') {
        const nextSurah = currentSurahNumber < 114 ? currentSurahNumber + 1 : 1;
        playRecitation(currentReciter, nextSurah, {
          ayahMode: isAyahByAyahMode,
          ayahNumber: 1,
        });
      } else {
        setIsPlaying(false);
      }
    };

    const onError = () => {
      handleAudioErrorFallback(
        currentReciter,
        currentSurahNumber,
        isAyahByAyahMode,
        currentAyahNumber
      );
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('waiting', onWaiting);
    audio.addEventListener('canplay', onCanPlay);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onError);

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('waiting', onWaiting);
      audio.removeEventListener('canplay', onCanPlay);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('error', onError);
    };
  }, [
    currentReciter,
    currentSurahNumber,
    currentSurahMeta.numberOfAyahs,
    isAyahByAyahMode,
    currentAyahNumber,
    repeatMode,
    playRecitation,
    handleAudioErrorFallback,
  ]);

  // Bind MediaSession Hardware/Lockscreen Controls
  useEffect(() => {
    if (!('mediaSession' in navigator)) return;
    try {
      navigator.mediaSession.setActionHandler('play', () => {
        audioRef.current?.play();
        setIsPlaying(true);
      });
      navigator.mediaSession.setActionHandler('pause', () => {
        audioRef.current?.pause();
        setIsPlaying(false);
      });
      navigator.mediaSession.setActionHandler('previoustrack', () => {
        const prev = currentSurahNumber > 1 ? currentSurahNumber - 1 : 114;
        playRecitation(currentReciter, prev);
      });
      navigator.mediaSession.setActionHandler('nexttrack', () => {
        const next = currentSurahNumber < 114 ? currentSurahNumber + 1 : 1;
        playRecitation(currentReciter, next);
      });
      navigator.mediaSession.setActionHandler('seekbackward', () => {
        if (audioRef.current) {
          audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10);
        }
      });
      navigator.mediaSession.setActionHandler('seekforward', () => {
        if (audioRef.current) {
          audioRef.current.currentTime = Math.min(
            audioRef.current.duration || 0,
            audioRef.current.currentTime + 10
          );
        }
      });
    } catch {
      // ignore
    }
  }, [currentReciter, currentSurahNumber, playRecitation]);

  const togglePlayPause = () => {
    if (!hasActiveSession || !audioRef.current || !audioRef.current.src) {
      playRecitation(currentReciter, currentSurahNumber);
      return;
    }
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
      const updated = saveRecentPlay(
        currentReciter,
        currentSurahNumber,
        audioRef.current.currentTime || 0,
        audioRef.current.duration || 0
      );
      setRecentPlays(updated);
    } else {
      audioRef.current.play().catch(() => {
        playRecitation(currentReciter, currentSurahNumber);
      });
      setIsPlaying(true);
    }
  };

  const handleSeek = (newSeconds: number) => {
    if (audioRef.current && Number.isFinite(newSeconds)) {
      audioRef.current.currentTime = newSeconds;
      setCurrentTime(newSeconds);
    }
  };

  const handleSkipSeconds = (delta: number) => {
    if (!audioRef.current) return;
    const target = Math.max(0, Math.min(duration || 0, audioRef.current.currentTime + delta));
    audioRef.current.currentTime = target;
    setCurrentTime(target);
  };

  const handleChangeSpeed = (speed: number) => {
    setPlaybackSpeed(speed);
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  };

  const handleToggleFavReciter = (reciter: QuranAudioReciter) => {
    const res = toggleFavoriteReciterId(reciter.id);
    setFavReciterIds(res.ids);
    showToast(
      res.isFavorite
        ? `تمت إضافة الشيخ ${reciter.name} إلى المفضلة`
        : `تمت إزالة الشيخ ${reciter.name} من المفضلة`
    );
  };

  const handleToggleFavTrack = (reciter: QuranAudioReciter, surahNum: number) => {
    const surah = SURAH_LIST.find((s) => s.number === surahNum) || SURAH_LIST[0];
    const res = toggleFavoriteTrack(reciter, surahNum);
    setFavTracks(res.tracks);
    showToast(
      res.isFavorite
        ? `تمت إضافة سورة ${surah.name} (${reciter.name}) للمفضلة`
        : `تمت إزالة سورة ${surah.name} من المفضلة`
    );
  };

  const handleDownloadSurah = async (reciter: QuranAudioReciter, surahNum: number) => {
    const key = `${reciter.id}_${surahNum}`;
    if (downloadingMap[key] !== undefined) return;

    const surah = SURAH_LIST.find((s) => s.number === surahNum) || SURAH_LIST[0];

    // Clear any previous failure state for this track before starting
    setFailedDownloadsMap((prev) => {
      if (!prev[key]) return prev;
      const copy = { ...prev };
      delete copy[key];
      return copy;
    });

    setDownloadingMap((prev) => ({ ...prev, [key]: 5 }));

    try {
      const extraServer = liveApiServers[reciter.mp3QuranApiId];
      await downloadSurahForOffline(
        reciter,
        surahNum,
        (pct) => {
          setDownloadingMap((prev) => ({ ...prev, [key]: pct }));
        },
        extraServer
      );
      const verified = await verifyAndSyncOfflineDownloads();
      setDownloadedTracks(verified);
      showToast(`تم حفظ سورة ${surah.name} بصوت ${reciter.name} للاستماع بدون إنترنت`);
    } catch (err) {
      const errMsg =
        err instanceof Error && err.message
          ? err.message
          : `فشل تحميل سورة ${surah.name}`;
      setFailedDownloadsMap((prev) => ({ ...prev, [key]: errMsg }));
      setDownloadedTracks(getDownloadedTracks());
      showToast(`فشل تحميل سورة ${surah.name} — يمكنك إعادة المحاولة`);
    } finally {
      setTimeout(() => {
        setDownloadingMap((prev) => {
          const copy = { ...prev };
          delete copy[key];
          return copy;
        });
      }, 400);
    }
  };

  const handleDeleteDownload = async (reciterId: string, surahNum: number) => {
    const key = `${reciterId}_${surahNum}`;
    const updated = await removeOfflineDownload(reciterId, surahNum);
    setDownloadedTracks(updated);
    setFailedDownloadsMap((prev) => {
      if (!prev[key]) return prev;
      const copy = { ...prev };
      delete copy[key];
      return copy;
    });
    showToast('تم حذف الملف الصوتي للسورة من مساحة تخزين الجهاز');
  };

  const handleSetSleepTimer = (minutes: number | null) => {
    if (audioRef.current) {
      audioRef.current.volume = 1;
    }
    setSleepTimerMinutes(minutes);
    setSleepTimerRemainingSeconds(minutes ? minutes * 60 : null);
    setIsSleepTimerPopoverOpen(false);
    if (minutes) {
      showToast(`تم ضبط مؤقت النوم: ستتوقف التلاوة تلقائياً بعد ${minutes} دقيقة`);
    } else {
      showToast('تم إيقاف مؤقت النوم');
    }
  };

  // Filtered Reciters (25 Reciters)
  const filteredReciters = useMemo(() => {
    if (!searchQuery.trim()) return QURAN_AUDIO_RECITERS;
    const q = normalizeArabicForSearch(searchQuery);
    return QURAN_AUDIO_RECITERS.filter(
      (r) =>
        normalizeArabicForSearch(r.name).includes(q) ||
        normalizeArabicForSearch(r.rewaya).includes(q) ||
        String(r.number) === q
    );
  }, [searchQuery]);

  // Filtered Surahs
  const filteredSurahs = useMemo(() => {
    const q = normalizeArabicForSearch(searchQuery);
    return SURAH_LIST.filter((s) => {
      if (selectedReciterForPage) {
        if (surahFilterInReciterPage === 'Meccan' && s.revelationType !== 'Meccan') return false;
        if (surahFilterInReciterPage === 'Medinan' && s.revelationType !== 'Medinan') return false;
        if (
          surahFilterInReciterPage === 'downloaded' &&
          !downloadedTracks.some((d) => d.id === `${selectedReciterForPage.id}_${s.number}`)
        ) {
          return false;
        }
      }
      if (!q) return true;
      return (
        normalizeArabicForSearch(s.name).includes(q) ||
        s.englishName.toLowerCase().includes(q) ||
        String(s.number) === q
      );
    });
  }, [searchQuery, selectedReciterForPage, surahFilterInReciterPage, downloadedTracks]);

  const quickSelectedReciter = useMemo(
    () =>
      QURAN_AUDIO_RECITERS.find((r) => r.id === quickReciterIdForSurahsTab) ||
      QURAN_AUDIO_RECITERS[0],
    [quickReciterIdForSurahsTab]
  );

  return (
    <div
      className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-32 font-cairo"
      dir="rtl"
    >
      {/* ==================== الشريط العلوي ==================== */}
      <header className="sticky top-0 z-30 bg-[#FFFFFF] border-b border-[#E6E6F0] shadow-[0_2px_10px_rgba(0,0,0,0.04)]">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                if (selectedReciterForPage) {
                  setSelectedReciterForPage(null);
                } else if (onBack) {
                  onBack();
                }
              }}
              aria-label="رجوع"
              className="w-10 h-10 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center hover:bg-[#F7F7FC] transition-colors cursor-pointer"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path
                  d="M9 18L15 12L9 6"
                  stroke="#5B5FEF"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            <div className="w-10 h-10 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0">
              <GoldenHeadphonesMushafSvg size={24} />
            </div>

            <div>
              <h1 className="font-cairo font-bold text-lg md:text-xl text-[#25263A] leading-tight">
                {selectedReciterForPage ? selectedReciterForPage.name : 'القرآن — استماع'}
              </h1>
              <p className="text-xs text-[#77798C]">
                {selectedReciterForPage
                  ? `${selectedReciterForPage.rewaya} · 114 سورة`
                  : '25 قارئاً معتمداً · تلاوات متصلة وبدون إنترنت'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* زر البحث */}
            <button
              type="button"
              onClick={() => setShowSearchBar((prev) => !prev)}
              aria-label="بحث"
              className={`w-10 h-10 rounded-full border flex items-center justify-center transition-colors cursor-pointer ${
                showSearchBar
                  ? 'bg-[#5B5FEF] border-[#5B5FEF] text-white'
                  : 'bg-[#EEEEFF] border-[#E6E6F0] text-[#4145C7]'
              }`}
            >
              <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
                <circle
                  cx="11"
                  cy="11"
                  r="7"
                  stroke={showSearchBar ? '#FFFFFF' : '#E8B84A'}
                  strokeWidth="2.2"
                />
                <path
                  d="M20 20L16.5 16.5"
                  stroke={showSearchBar ? '#FFFFFF' : '#E8B84A'}
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            {/* زر المفضلة */}
            <button
              type="button"
              onClick={() => {
                setSelectedReciterForPage(null);
                setActiveTab('favorites');
              }}
              aria-label="المفضلة"
              className={`w-10 h-10 rounded-full border flex items-center justify-center transition-colors cursor-pointer ${
                activeTab === 'favorites' && !selectedReciterForPage
                  ? 'bg-[#5B5FEF] border-[#5B5FEF]'
                  : 'bg-[#F7F7FC] border-[#E6E6F0] hover:border-[#5B5FEF]'
              }`}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path
                  d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                  fill={
                    activeTab === 'favorites' && !selectedReciterForPage
                      ? '#FFFFFF'
                      : favReciterIds.length + favTracks.length > 0
                      ? '#E8B84A'
                      : 'none'
                  }
                  stroke={
                    activeTab === 'favorites' && !selectedReciterForPage
                      ? '#FFFFFF'
                      : '#E8B84A'
                  }
                  strokeWidth="2"
                />
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* إشعار علوي سريع */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-[#FFFFFF] border-2 border-[#5B5FEF] text-[#25263A] px-5 py-2.5 rounded-2xl shadow-xl flex items-center gap-2.5 animate-fade-in">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="9" stroke="#4CAF82" strokeWidth="2" />
            <path
              d="M8.5 12.5L10.8 14.8L15.5 9.5"
              stroke="#4CAF82"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="text-sm font-bold">{toastMessage}</span>
        </div>
      )}

      <main className="max-w-5xl mx-auto px-4 pt-5 space-y-5">
        {/* ==================== البطاقة الترحيبية ==================== */}
        {!selectedReciterForPage && (
          <section className="relative overflow-hidden bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-6 shadow-[0_6px_20px_rgba(201,168,76,0.12)]">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="text-center md:text-right space-y-2">
                <p
                  className="text-2xl md:text-3xl font-bold text-[#5B5FEF] leading-relaxed"
                  style={{ fontFamily: "'Amiri', serif" }}
                >
                  ﴿وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا﴾
                </p>
                <p className="text-xs text-[#77798C]">سورة المزمل — الآية ٤</p>
                <h2 className="text-base md:text-lg font-bold text-[#25263A]">
                  استمع لتلاوات أشهر القراء
                </h2>
                <p className="text-xs md:text-sm text-[#77798C] leading-relaxed max-w-2xl">
                  تلاوات قرآنية كاملة لـ ٢٥ قارئاً من كبار قراء العالم الإسلامي عبر خوادم موثوقة مع دعم التشغيل في الخلفية والتحميل للاستماع بدون إنترنت.
                </p>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => playRecitation(currentReciter, currentSurahNumber)}
                  className="px-5 py-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold text-sm flex items-center gap-2.5 shadow-md transition-all cursor-pointer"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="#FFFFFF">
                    <path d="M8 5.14V19.14L19 12.14L8 5.14Z" />
                  </svg>
                  <span>
                    {hasActiveSession
                      ? `متابعة: سورة ${currentSurahMeta.name}`
                      : `استمع الآن: سورة ${currentSurahMeta.name}`}
                  </span>
                </button>
              </div>
            </div>
          </section>
        )}

        {/* ==================== التبويبات الـ 5 (عند عدم فتح صفحة شيخ) ==================== */}
        {!selectedReciterForPage && (
          <nav
            aria-label="تبويبات القرآن استماع"
            className="bg-[#FFFFFF] p-1.5 rounded-2xl border border-[#E6E6F0] flex items-center gap-1 overflow-x-auto no-scrollbar"
          >
            {(
              [
                { id: 'reciters', label: 'الشيوخ', count: QURAN_AUDIO_RECITERS.length },
                { id: 'surahs', label: 'السور', count: 114 },
                {
                  id: 'favorites',
                  label: 'المفضلة',
                  count: favReciterIds.length + favTracks.length,
                },
                {
                  id: 'downloads',
                  label: 'التحميلات',
                  count: downloadedTracks.length,
                },
                { id: 'recent', label: 'آخر استماع', count: recentPlays.length },
              ] as { id: AudioMainTab; label: string; count: number }[]
            ).map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 min-w-[105px] py-2.5 px-3 rounded-xl font-bold text-xs md:text-sm transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                    active
                      ? 'bg-[#5B5FEF] text-[#FFFFFF] shadow-sm'
                      : 'text-[#25263A] hover:bg-[#F7F7FC]'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`text-[11px] ${
                      active ? 'text-[#FFFFFF]/90' : 'text-[#77798C]'
                    }`}
                  >
                    ({tab.count})
                  </span>
                </button>
              );
            })}
          </nav>
        )}

        {/* ==================== شريط البحث ==================== */}
        {showSearchBar && (
          <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] px-4 py-3 flex items-center gap-3 shadow-xs">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="shrink-0">
              <circle cx="11" cy="11" r="7" stroke="#5B5FEF" strokeWidth="2.2" />
              <path d="M20 20L16.5 16.5" stroke="#5B5FEF" strokeWidth="2.2" strokeLinecap="round" />
            </svg>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                selectedReciterForPage
                  ? `ابحث في سور الشيخ ${selectedReciterForPage.name}...`
                  : 'ابحث باسم الشيخ أو السورة...'
              }
              className="w-full bg-transparent text-sm text-[#25263A] placeholder-[#77798C] focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="مسح البحث"
                className="text-xs text-[#77798C] hover:text-[#25263A] cursor-pointer"
              >
                مسح
              </button>
            )}
          </div>
        )}

        {/* ==================== الشاشة 2: صفحة الشيخ وسوره الـ 114 ==================== */}
        {selectedReciterForPage ? (
          <section className="space-y-4">
            {/* بطاقة معلومات الشيخ */}
            <div className="bg-[#FFFFFF] rounded-2xl border border-[#E6E6F0] p-5 shadow-xs">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-[#F7F7FC] border-2 border-[#5B5FEF] flex items-center justify-center shrink-0">
                    <GoldenHeadphonesMushafSvg size={32} />
                  </div>
                  <div>
                    <h2 className="font-bold text-lg md:text-xl text-[#25263A]">
                      الشيخ {selectedReciterForPage.name}
                    </h2>
                    <p className="text-xs text-[#4CAF82] font-bold mt-0.5">
                      {selectedReciterForPage.rewaya} · {selectedReciterForPage.surahCount} تلاوة
                    </p>
                    <p className="text-xs text-[#77798C] mt-1 leading-relaxed">
                      {selectedReciterForPage.bio}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => playRecitation(selectedReciterForPage, 1)}
                    className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold text-xs md:text-sm flex items-center gap-2 cursor-pointer"
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="#FFFFFF">
                      <path d="M8 5.14V19.14L19 12.14L8 5.14Z" />
                    </svg>
                    <span>تشغيل الختمة كاملة</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleFavReciter(selectedReciterForPage)}
                    className="w-10 h-10 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
                    aria-label="إضافة الشيخ للمفضلة"
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                      <path
                        d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                        fill={
                          favReciterIds.includes(selectedReciterForPage.id)
                            ? '#E8B84A'
                            : 'none'
                        }
                        stroke="#5B5FEF"
                        strokeWidth="2"
                      />
                    </svg>
                  </button>
                </div>
              </div>

              {/* فلاتر السور داخل صفحة الشيخ */}
              <div className="mt-4 pt-4 border-t border-[#E6E6F0] flex flex-wrap items-center gap-2">
                {(
                  [
                    { id: 'all', label: 'جميع السور (114)' },
                    { id: 'Meccan', label: 'السور المكية' },
                    { id: 'Medinan', label: 'السور المدنية' },
                    { id: 'downloaded', label: 'المحملة Offline' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setSurahFilterInReciterPage(f.id)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      surahFilterInReciterPage === f.id
                        ? 'bg-[#5B5FEF] text-white'
                        : 'bg-[#F7F7FC] text-[#25263A] hover:border-[#5B5FEF]'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* قائمة سور الشيخ */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredSurahs.map((surah) => {
                const isCurrentActive =
                  hasActiveSession &&
                  currentReciter.id === selectedReciterForPage.id &&
                  currentSurahNumber === surah.number;
                const trackKey = `${selectedReciterForPage.id}_${surah.number}`;
                const isFav = favTracks.some((t) => t.id === trackKey);
                const downloadedRecord = downloadedTracks.find(
                  (d) => d.id === trackKey && d.downloadStatus === 'downloaded'
                );
                const isDownloaded = Boolean(downloadedRecord);
                const dlProgress = downloadingMap[trackKey];
                const hasFailed = Boolean(failedDownloadsMap[trackKey]) && !isDownloaded && dlProgress === undefined;

                return (
                  <div
                    key={surah.number}
                    className={`bg-[#FFFFFF] rounded-2xl p-3.5 border transition-all flex items-center justify-between gap-3 ${
                      isCurrentActive
                        ? 'border-[#5B5FEF] shadow-[0_4px_14px_rgba(201,168,76,0.2)]'
                        : 'border-[#E6E6F0] hover:border-[#5B5FEF]'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0 font-bold text-sm text-[#25263A]">
                        {surah.number}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3
                            className="font-bold text-lg text-[#25263A] truncate"
                            style={{ fontFamily: "'Amiri', serif" }}
                          >
                            سُورَةُ {surah.name}
                          </h3>
                          {isDownloaded && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] text-[11px] font-bold">
                              ✓ تم التحميل
                            </span>
                          )}
                          {hasFailed && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-red-500/10 text-red-600 text-[11px] font-bold">
                              فشل التحميل
                            </span>
                          )}
                          {!isOnline && !isDownloaded && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/10 text-amber-700 text-[11px] font-bold">
                              غير متاحة Offline
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#77798C]">
                          {surah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} ·{' '}
                          {surah.numberOfAyahs} آية · الجزء {surah.juz}
                          {isDownloaded && downloadedRecord?.fileSizeBytes
                            ? ` · ${formatBytesArabic(downloadedRecord.fileSizeBytes)}`
                            : ''}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* زر التحميل للاستماع بدون إنترنت / إعادة المحاولة / حذف التحميل */}
                      <button
                        type="button"
                        disabled={!isOnline && !isDownloaded}
                        onClick={() =>
                          isDownloaded
                            ? handleDeleteDownload(selectedReciterForPage.id, surah.number)
                            : handleDownloadSurah(selectedReciterForPage, surah.number)
                        }
                        aria-label={
                          isDownloaded
                            ? 'تم التحميل - اضغط للحذف'
                            : hasFailed
                            ? 'إعادة محاولة التحميل'
                            : 'تحميل السورة'
                        }
                        className={`h-9 rounded-xl border flex items-center justify-center transition-colors cursor-pointer ${
                          hasFailed
                            ? 'px-2.5 bg-red-50 border-red-300 text-red-600'
                            : isDownloaded
                            ? 'w-9 bg-[#4CAF82]/10 border-[#4CAF82]/40'
                            : !isOnline
                            ? 'w-9 bg-[#F7F7FC] border-[#E6E6F0] opacity-50 cursor-not-allowed'
                            : 'w-9 bg-[#F7F7FC] border-[#E6E6F0]'
                        }`}
                        title={
                          isDownloaded
                            ? 'تم تحميل السورة على الجهاز (اضغط لحذف الملف المحلي)'
                            : hasFailed
                            ? 'فشل التحميل — اضغط لإعادة المحاولة'
                            : 'تحميل للاستماع Offline'
                        }
                      >
                        {dlProgress !== undefined ? (
                          <span className="text-[10px] font-bold text-[#5B5FEF]">
                            {dlProgress}%
                          </span>
                        ) : isDownloaded ? (
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                            <path
                              d="M5 13L9 17L19 7"
                              stroke="#4CAF82"
                              strokeWidth="2.4"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        ) : hasFailed ? (
                          <span className="text-[11px] font-bold">إعادة</span>
                        ) : (
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                            <path
                              d="M12 4V15M12 15L8 11M12 15L16 11M5 19H19"
                              stroke="#5B5FEF"
                              strokeWidth="2"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        )}
                      </button>

                      {/* زر المفضلة */}
                      <button
                        type="button"
                        onClick={() => handleToggleFavTrack(selectedReciterForPage, surah.number)}
                        aria-label="مفضلة السورة"
                        className="w-9 h-9 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
                      >
                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none">
                          <path
                            d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                            fill={isFav ? '#E8B84A' : 'none'}
                            stroke="#5B5FEF"
                            strokeWidth="2"
                          />
                        </svg>
                      </button>

                      {/* زر التشغيل */}
                      <button
                        type="button"
                        onClick={() => {
                          if (isCurrentActive) {
                            togglePlayPause();
                          } else {
                            playRecitation(selectedReciterForPage, surah.number, {
                              ayahMode: false,
                            });
                          }
                        }}
                        className={`px-3.5 h-9 rounded-xl font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-colors ${
                          isCurrentActive && isPlaying
                            ? 'bg-[#5B5FEF] text-white'
                            : 'bg-[#5B5FEF] hover:bg-[#4145C7] text-white'
                        }`}
                      >
                        {isCurrentActive && isPlaying ? (
                          <>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="#FFFFFF">
                              <rect x="6" y="5" width="4" height="14" rx="1" />
                              <rect x="14" y="5" width="4" height="14" rx="1" />
                            </svg>
                            <span>إيقاف</span>
                          </>
                        ) : (
                          <>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="#FFFFFF">
                              <path d="M8 5.14V19.14L19 12.14L8 5.14Z" />
                            </svg>
                            <span>استمع</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        ) : (
          <>
            {/* ==================== التبويب 1: قائمة الشيوخ (25 قارئ) ==================== */}
            {activeTab === 'reciters' && (
              <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {filteredReciters.map((reciter) => {
                  const isFavReciter = favReciterIds.includes(reciter.id);
                  const isCurrentReciterPlaying =
                    hasActiveSession && currentReciter.id === reciter.id && isPlaying;

                  return (
                    <div
                      key={reciter.id}
                      className={`bg-[#FFFFFF] rounded-2xl p-4 border transition-all flex flex-col justify-between gap-4 ${
                        isCurrentReciterPlaying
                          ? 'border-[#5B5FEF] shadow-[0_6px_18px_rgba(201,168,76,0.2)]'
                          : 'border-[#E6E6F0] hover:border-[#5B5FEF] shadow-[0_2px_8px_rgba(0,0,0,0.04)]'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3.5 min-w-0">
                          {/* صورة رمزية (دائرة ذهبية) */}
                          <div className="w-14 h-14 rounded-full bg-[#F7F7FC] border-2 border-[#5B5FEF] flex items-center justify-center shrink-0 shadow-inner">
                            <GoldenHeadphonesMushafSvg size={28} />
                          </div>

                          <div className="min-w-0">
                            <h3 className="font-cairo font-bold text-base text-[#25263A] leading-snug truncate">
                              {reciter.name}
                            </h3>
                            <p className="text-xs text-[#77798C] mt-0.5 truncate">
                              {reciter.rewaya}
                            </p>
                            <p className="text-xs font-bold text-[#4CAF82] mt-1">
                              {reciter.surahCount} تلاوة كاملة
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleToggleFavReciter(reciter)}
                          aria-label="إضافة للمفضلة"
                          className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center shrink-0 cursor-pointer"
                        >
                          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                            <path
                              d="M12 20.5C12 20.5 4 15.2 4 9.3C4 6.4 6.3 4.2 9 4.2C10.7 4.2 12 5.1 12 5.1C12 5.1 13.3 4.2 15 4.2C17.7 4.2 20 6.4 20 9.3C20 15.2 12 20.5 12 20.5Z"
                              fill={isFavReciter ? '#E8B84A' : 'none'}
                              stroke="#5B5FEF"
                              strokeWidth="2"
                            />
                          </svg>
                        </button>
                      </div>

                      <div className="flex items-center gap-2 pt-2 border-t border-[#F7F7FC]">
                        {/* زر استمع (يفتح صفحة الشيخ ويشغل التلاوة) */}
                        <button
                          type="button"
                          onClick={() => {
                            saveSelectedReciterId(reciter.id);
                            setQuickReciterIdForSurahsTab(reciter.id);
                            setSelectedReciterForPage(reciter);
                            if (!hasActiveSession || currentReciter.id !== reciter.id) {
                              playRecitation(reciter, currentSurahNumber);
                            }
                          }}
                          className="flex-1 py-2.5 px-4 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-[#FFFFFF] font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
                        >
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="#FFFFFF">
                            <path d="M8 5.14V19.14L19 12.14L8 5.14Z" />
                          </svg>
                          <span>استمع</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            saveSelectedReciterId(reciter.id);
                            setQuickReciterIdForSurahsTab(reciter.id);
                            setSelectedReciterForPage(reciter);
                          }}
                          className="py-2.5 px-3.5 rounded-xl bg-[#F7F7FC] hover:bg-[#F7F7FC] text-[#25263A] border border-[#E6E6F0] font-bold text-xs transition-colors cursor-pointer"
                        >
                          تصفح السور
                        </button>
                      </div>
                    </div>
                  );
                })}
              </section>
            )}

            {/* ==================== التبويب 2: قائمة السور (114 سورة) ==================== */}
            {activeTab === 'surahs' && (
              <section className="space-y-4">
                {/* شريط اختيار القارئ السريع */}
                <div className="bg-[#FFFFFF] rounded-2xl p-4 border border-[#E6E6F0] flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <GoldenHeadphonesMushafSvg size={24} />
                    <span className="text-sm font-bold text-[#25263A]">
                      القارئ المختار لتشغيل السور:
                    </span>
                  </div>
                  <select
                    value={quickReciterIdForSurahsTab}
                    onChange={(e) => {
                      const newId = e.target.value;
                      setQuickReciterIdForSurahsTab(newId);
                      saveSelectedReciterId(newId);
                    }}
                    className="w-full sm:w-auto bg-[#F7F7FC] border border-[#5B5FEF] rounded-xl px-3.5 py-2 text-sm font-bold text-[#25263A] focus:outline-none"
                  >
                    {QURAN_AUDIO_RECITERS.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.number}. {r.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredSurahs.map((surah) => {
                    const isCurrent =
                      hasActiveSession &&
                      currentReciter.id === quickSelectedReciter.id &&
                      currentSurahNumber === surah.number;
                    const trackKey = `${quickSelectedReciter.id}_${surah.number}`;
                    const exactDownload = downloadedTracks.find(
                      (d) => d.id === trackKey && d.downloadStatus === 'downloaded'
                    );
                    const anySurahDownload =
                      exactDownload ||
                      downloadedTracks.find(
                        (d) => d.surahNumber === surah.number && d.downloadStatus === 'downloaded'
                      );
                    const isDownloaded = Boolean(exactDownload);
                    const isAvailableOfflineAnyReciter = Boolean(anySurahDownload);
                    const dlProgress = downloadingMap[trackKey];
                    const hasFailed =
                      Boolean(failedDownloadsMap[trackKey]) &&
                      !isDownloaded &&
                      dlProgress === undefined;

                    return (
                      <div
                        key={surah.number}
                        className={`bg-[#FFFFFF] rounded-2xl p-3.5 border flex items-center justify-between gap-3 ${
                          isCurrent ? 'border-[#5B5FEF] shadow-md' : 'border-[#E6E6F0]'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center font-bold text-sm text-[#25263A] shrink-0">
                            {surah.number}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3
                                className="font-bold text-lg text-[#25263A] truncate"
                                style={{ fontFamily: "'Amiri', serif" }}
                              >
                                سُورَةُ {surah.name}
                              </h3>
                              {isDownloaded && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] text-[11px] font-bold">
                                  ✓ تم التحميل
                                </span>
                              )}
                              {!isDownloaded && isAvailableOfflineAnyReciter && anySurahDownload && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] text-[11px] font-bold">
                                  ✓ محملة ({anySurahDownload.reciterName})
                                </span>
                              )}
                              {hasFailed && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-red-500/10 text-red-600 text-[11px] font-bold">
                                  فشل التحميل
                                </span>
                              )}
                              {!isOnline && !isAvailableOfflineAnyReciter && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-500/10 text-amber-700 text-[11px] font-bold">
                                  غير متاحة Offline
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-[#77798C]">
                              {surah.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} ·{' '}
                              {surah.numberOfAyahs} آية · بصوت {quickSelectedReciter.name}
                              {isDownloaded && exactDownload?.fileSizeBytes
                                ? ` · ${formatBytesArabic(exactDownload.fileSizeBytes)}`
                                : ''}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            disabled={!isOnline && !isDownloaded}
                            onClick={() =>
                              isDownloaded
                                ? handleDeleteDownload(quickSelectedReciter.id, surah.number)
                                : handleDownloadSurah(quickSelectedReciter, surah.number)
                            }
                            aria-label={
                              isDownloaded
                                ? 'تم التحميل - اضغط للحذف'
                                : hasFailed
                                ? 'إعادة محاولة التحميل'
                                : 'تحميل السورة'
                            }
                            title={
                              isDownloaded
                                ? 'تم تحميل السورة على الجهاز (اضغط لحذف الملف المحلي)'
                                : hasFailed
                                ? 'فشل التحميل — اضغط لإعادة المحاولة'
                                : 'تحميل السورة للاستماع بدون إنترنت'
                            }
                            className={`h-9 rounded-xl border flex items-center justify-center transition-colors cursor-pointer ${
                              hasFailed
                                ? 'px-2.5 bg-red-50 border-red-300 text-red-600'
                                : isDownloaded
                                ? 'w-9 bg-[#4CAF82]/10 border-[#4CAF82]/40'
                                : !isOnline
                                ? 'w-9 bg-[#F7F7FC] border-[#E6E6F0] opacity-50 cursor-not-allowed'
                                : 'w-9 bg-[#F7F7FC] border-[#E6E6F0]'
                            }`}
                          >
                            {dlProgress !== undefined ? (
                              <span className="text-[10px] font-bold text-[#5B5FEF]">
                                {dlProgress}%
                              </span>
                            ) : isDownloaded ? (
                              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                                <path
                                  d="M5 13L9 17L19 7"
                                  stroke="#4CAF82"
                                  strokeWidth="2.4"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                />
                              </svg>
                            ) : hasFailed ? (
                              <span className="text-[11px] font-bold">إعادة</span>
                            ) : (
                              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                                <path
                                  d="M12 4V15M12 15L8 11M12 15L16 11M5 19H19"
                                  stroke="#5B5FEF"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                />
                              </svg>
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              isCurrent
                                ? togglePlayPause()
                                : playRecitation(quickSelectedReciter, surah.number)
                            }
                            className="px-4 h-9 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="#FFFFFF">
                              <path d="M8 5.14V19.14L19 12.14L8 5.14Z" />
                            </svg>
                            <span>{isCurrent && isPlaying ? 'إيقاف' : 'استمع'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            )}

            {/* ==================== التبويب 3: المفضلة ==================== */}
            {activeTab === 'favorites' && (
              <section className="space-y-5">
                {/* القراء المفضلون */}
                <div className="bg-[#FFFFFF] rounded-2xl p-5 border border-[#E6E6F0] space-y-3">
                  <h3 className="font-bold text-base text-[#25263A]">
                    القراء المفضلون ({favReciterIds.length})
                  </h3>
                  {favReciterIds.length === 0 ? (
                    <div className="bg-[#F7F7FC] rounded-xl p-4 flex items-center justify-between gap-3">
                      <p className="text-xs text-[#77798C]">
                        لم تقم بإضافة شيوخ إلى المفضلة بعد. يمكنك اختيار أي قارئ من قائمة الـ ٢٥ قارئاً.
                      </p>
                      <button
                        type="button"
                        onClick={() => setActiveTab('reciters')}
                        className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold shrink-0 cursor-pointer"
                      >
                        استعرض القراء
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {QURAN_AUDIO_RECITERS.filter((r) => favReciterIds.includes(r.id)).map(
                        (reciter) => (
                          <div
                            key={reciter.id}
                            className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0] flex items-center justify-between gap-3"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-10 h-10 rounded-full bg-white border border-[#E6E6F0] flex items-center justify-center shrink-0">
                                <GoldenHeadphonesMushafSvg size={20} />
                              </div>
                              <div className="min-w-0">
                                <p className="font-bold text-sm text-[#25263A] truncate">
                                  {reciter.name}
                                </p>
                                <p className="text-xs text-[#77798C] truncate">{reciter.rewaya}</p>
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => setSelectedReciterForPage(reciter)}
                              className="px-3 py-1.5 rounded-lg bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
                            >
                              استمع
                            </button>
                          </div>
                        )
                      )}
                    </div>
                  )}
                </div>

                {/* التلاوات المفضلة */}
                <div className="bg-[#FFFFFF] rounded-2xl p-5 border border-[#E6E6F0] space-y-3">
                  <h3 className="font-bold text-base text-[#25263A]">
                    السور والتلاوات المفضلة ({favTracks.length})
                  </h3>
                  {favTracks.length === 0 ? (
                    <div className="bg-[#F7F7FC] rounded-xl p-4 flex items-center justify-between gap-3">
                      <p className="text-xs text-[#77798C]">
                        اضغط على أيقونة القلب بجانب أي سورة لحفظها في قائمة التلاوات المفضلة للوصول السريع.
                      </p>
                      <button
                        type="button"
                        onClick={() => setActiveTab('surahs')}
                        className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold shrink-0 cursor-pointer"
                      >
                        تصفح السور
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {favTracks.map((item) => {
                        const reciter =
                          QURAN_AUDIO_RECITERS.find((r) => r.id === item.reciterId) ||
                          QURAN_AUDIO_RECITERS[0];
                        return (
                          <div
                            key={item.id}
                            className="bg-[#F7F7FC] rounded-xl p-3.5 border border-[#E6E6F0] flex items-center justify-between gap-3"
                          >
                            <div>
                              <h4
                                className="font-bold text-base text-[#25263A]"
                                style={{ fontFamily: "'Amiri', serif" }}
                              >
                                سُورَةُ {item.surahName}
                              </h4>
                              <p className="text-xs text-[#77798C]">بصوت الشيخ {item.reciterName}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => playRecitation(reciter, item.surahNumber)}
                                className="px-3.5 py-1.5 rounded-lg bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
                              >
                                تشغيل
                              </button>
                              <button
                                type="button"
                                onClick={() => handleToggleFavTrack(reciter, item.surahNumber)}
                                className="p-1.5 rounded-lg bg-white border border-[#E6E6F0] text-[#77798C] text-xs cursor-pointer"
                              >
                                إزالة
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </section>
            )}

            {/* ==================== التبويب 4: التحميلات (Offline) ==================== */}
            {activeTab === 'downloads' && (
              <section className="bg-[#FFFFFF] rounded-2xl p-5 border border-[#E6E6F0] space-y-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h3 className="font-bold text-base text-[#25263A]">
                      التلاوات المحملة للاستماع بدون إنترنت ({downloadedTracks.length})
                    </h3>
                    <p className="text-xs text-[#77798C]">
                      تُحفظ السور المحملة في ذاكرة الجهاز لتعمل مباشرة بدون الحاجة لاتصال بالإنترنت.
                    </p>
                  </div>
                </div>

                {downloadedTracks.length === 0 ? (
                  <div className="bg-[#F7F7FC] rounded-xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="space-y-1 text-center sm:text-right">
                      <p className="font-bold text-sm text-[#25263A]">
                        ابدأ بتحميل سورك المفضلة للاستماع Offline
                      </p>
                      <p className="text-xs text-[#77798C]">
                        يمكنك تحميل سورة الفاتحة أو الكهف أو الملك بضغطة واحدة للاستماع في أي وقت.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDownloadSurah(currentReciter, 1)}
                      className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold shrink-0 cursor-pointer"
                    >
                      تحميل سورة الفاتحة ({currentReciter.name})
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {downloadedTracks.map((d) => {
                      const reciter =
                        QURAN_AUDIO_RECITERS.find((r) => r.id === d.reciterId) ||
                        QURAN_AUDIO_RECITERS[0];
                      return (
                        <div
                          key={d.id}
                          className="bg-[#F7F7FC] rounded-xl p-3.5 border border-[#E6E6F0] flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <h4
                              className="font-bold text-base text-[#25263A]"
                              style={{ fontFamily: "'Amiri', serif" }}
                            >
                              سُورَةُ {d.surahName}
                            </h4>
                            <p className="text-xs text-[#77798C] truncate">
                              الشيخ {d.reciterName} · {formatBytesArabic(d.fileSizeBytes)}
                            </p>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              type="button"
                              onClick={() => playRecitation(reciter, d.surahNumber)}
                              className="px-3.5 py-1.5 rounded-lg bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
                            >
                              تشغيل Offline
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteDownload(d.reciterId, d.surahNumber)}
                              className="px-2.5 py-1.5 rounded-lg bg-white border border-[#E6E6F0] text-xs text-[#77798C] cursor-pointer"
                            >
                              حذف
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>
            )}

            {/* ==================== التبويب 5: آخر استماع ==================== */}
            {activeTab === 'recent' && (
              <section className="bg-[#FFFFFF] rounded-2xl p-5 border border-[#E6E6F0] space-y-4">
                <h3 className="font-bold text-base text-[#25263A]">
                  سجل آخر الاستماع ({recentPlays.length})
                </h3>
                {recentPlays.length === 0 ? (
                  <div className="bg-[#F7F7FC] rounded-xl p-5 flex items-center justify-between gap-4">
                    <p className="text-xs text-[#77798C]">
                      اختر قارئاً أو سورة لبدء الاستماع، وسيتم حفظ موضع التوقف تلقائياً هنا.
                    </p>
                    <button
                      type="button"
                      onClick={() => playRecitation(QURAN_AUDIO_RECITERS[0], 1)}
                      className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold shrink-0 cursor-pointer"
                    >
                      تشغيل سورة الفاتحة
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {recentPlays.map((item) => {
                      const reciter =
                        QURAN_AUDIO_RECITERS.find((r) => r.id === item.reciterId) ||
                        QURAN_AUDIO_RECITERS[0];
                      return (
                        <div
                          key={item.id}
                          className="bg-[#F7F7FC] rounded-xl p-3.5 border border-[#E6E6F0] flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <h4
                              className="font-bold text-base text-[#25263A]"
                              style={{ fontFamily: "'Amiri', serif" }}
                            >
                              سُورَةُ {item.surahName}
                            </h4>
                            <p className="text-xs text-[#77798C] truncate">
                              الشيخ {item.reciterName}
                              {item.positionSeconds > 5
                                ? ` · التوقف عند ${formatTimeMMSS(item.positionSeconds)}`
                                : ''}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() =>
                              playRecitation(reciter, item.surahNumber, {
                                resumeSeconds: item.positionSeconds,
                              })
                            }
                            className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold shrink-0 cursor-pointer"
                          >
                            متابعة الاستماع
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>
            )}
          </>
        )}
      </main>

      {/* ==================== الشريط السفلي للمشغل الصوتي (Mini Player) ==================== */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-[#FFFFFF] border-t-2 border-[#5B5FEF] shadow-[0_-6px_24px_rgba(0,0,0,0.08)]">
        {/* شريط التقدم الرفيع */}
        <div className="w-full h-1.5 bg-[#F7F7FC]">
          <div
            className="h-full bg-[#5B5FEF] transition-all duration-200"
            style={{
              width: `${duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0}%`,
            }}
          />
        </div>

        <div className="max-w-5xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
          <div
            onClick={() => setIsFullPlayerOpen(true)}
            className="flex items-center gap-3 min-w-0 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center shrink-0">
              <GoldenHeadphonesMushafSvg size={24} />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <p
                  className="font-bold text-base text-[#25263A] truncate"
                  style={{ fontFamily: "'Amiri', serif" }}
                >
                  سُورَةُ {currentSurahMeta.name}
                </p>
                {isBuffering && (
                  <span className="text-[11px] text-[#5B5FEF] font-bold">جاري التحميل...</span>
                )}
              </div>
              <p className="text-xs text-[#77798C] truncate">
                الشيخ {currentReciter.name} · {formatTimeMMSS(currentTime)} /{' '}
                {formatTimeMMSS(duration)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* السورة السابقة */}
            <button
              type="button"
              onClick={() =>
                playRecitation(
                  currentReciter,
                  currentSurahNumber > 1 ? currentSurahNumber - 1 : 114
                )
              }
              aria-label="السورة السابقة"
              className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path
                  d="M9 18L15 12L9 6"
                  stroke="#5B5FEF"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* تشغيل / إيقاف */}
            <button
              type="button"
              onClick={togglePlayPause}
              aria-label={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
              className="w-11 h-11 rounded-full bg-[#5B5FEF] hover:bg-[#4145C7] text-white flex items-center justify-center shadow-md cursor-pointer"
            >
              {isPlaying ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#FFFFFF">
                  <rect x="6" y="5" width="4" height="14" rx="1" />
                  <rect x="14" y="5" width="4" height="14" rx="1" />
                </svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#FFFFFF">
                  <path d="M8 5.14V19.14L19 12.14L8 5.14Z" />
                </svg>
              )}
            </button>

            {/* السورة التالية */}
            <button
              type="button"
              onClick={() =>
                playRecitation(
                  currentReciter,
                  currentSurahNumber < 114 ? currentSurahNumber + 1 : 1
                )
              }
              aria-label="السورة التالية"
              className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path
                  d="M15 18L9 12L15 6"
                  stroke="#5B5FEF"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>

            {/* أيقونة الساعة في شريط التحكم لفتح واجهة مؤقت النوم (15، 30، 60 دقيقة) */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsSleepTimerPopoverOpen((prev) => !prev)}
                aria-label="مؤقت النوم"
                title="مؤقت النوم (Sleep Timer)"
                className={`h-9 px-2.5 rounded-full border flex items-center gap-1.5 transition-colors cursor-pointer ${
                  sleepTimerRemainingSeconds !== null
                    ? 'bg-[#5B5FEF] border-[#5B5FEF] text-white'
                    : 'bg-[#F7F7FC] border-[#E6E6F0] text-[#25263A] hover:border-[#5B5FEF]'
                }`}
              >
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" className="shrink-0">
                  <circle
                    cx="12"
                    cy="12"
                    r="9"
                    stroke={sleepTimerRemainingSeconds !== null ? '#FFFFFF' : '#E8B84A'}
                    strokeWidth="2.2"
                  />
                  <path
                    d="M12 7V12L15 14"
                    stroke={sleepTimerRemainingSeconds !== null ? '#FFFFFF' : '#E8B84A'}
                    strokeWidth="2.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                {sleepTimerRemainingSeconds !== null && (
                  <span className="text-[11px] font-bold">
                    {formatTimeMMSS(sleepTimerRemainingSeconds)}
                  </span>
                )}
              </button>

              {/* نافذة مؤقت النوم المنبثقة فوق شريط التحكم */}
              {isSleepTimerPopoverOpen && (
                <div className="absolute bottom-12 left-0 w-64 bg-[#FFFFFF] rounded-2xl border-2 border-[#5B5FEF] shadow-2xl p-3.5 z-50 space-y-2.5">
                  <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-2">
                    <div className="flex items-center gap-1.5">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="9" stroke="#5B5FEF" strokeWidth="2.2" />
                        <path
                          d="M12 7V12L15 14"
                          stroke="#5B5FEF"
                          strokeWidth="2.2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      <span className="text-xs font-bold text-[#25263A]">
                        مؤقت النوم (Sleep Timer)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsSleepTimerPopoverOpen(false)}
                      className="text-xs text-[#77798C] hover:text-[#25263A] cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>

                  <p className="text-[11px] text-[#77798C]">
                    اختر وقت إيقاف التلاوة تلقائياً:
                  </p>

                  <div className="grid grid-cols-3 gap-1.5">
                    {([15, 30, 60] as const).map((mins) => {
                      const isActiveTimer = sleepTimerMinutes === mins;
                      return (
                        <button
                          key={mins}
                          type="button"
                          onClick={() => handleSetSleepTimer(isActiveTimer ? null : mins)}
                          className={`py-2 px-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            isActiveTimer
                              ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                              : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                          }`}
                        >
                          {mins} د
                        </button>
                      );
                    })}
                  </div>

                  {sleepTimerRemainingSeconds !== null && (
                    <div className="pt-1 flex items-center justify-between">
                      <span className="text-[11px] font-bold text-[#4CAF82]">
                        المتبقي: {formatTimeMMSS(sleepTimerRemainingSeconds)}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleSetSleepTimer(null)}
                        className="text-[11px] font-bold text-[#25263A] underline cursor-pointer"
                      >
                        إلغاء المؤقت
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* أزرار مؤقت النوم السريعة في المشغل السفلي (15، 30، 60 دقيقة) */}
            <div className="hidden md:flex items-center gap-1 bg-[#F7F7FC] px-2.5 py-1.5 rounded-xl border border-[#E6E6F0]">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" className="shrink-0">
                <circle cx="12" cy="12" r="9" stroke="#5B5FEF" strokeWidth="2" />
                <path
                  d="M12 7V12L15 14"
                  stroke="#5B5FEF"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span className="text-[11px] font-bold text-[#25263A] ml-1">
                {sleepTimerRemainingSeconds !== null
                  ? formatTimeMMSS(sleepTimerRemainingSeconds)
                  : 'مؤقت النوم:'}
              </span>
              {([15, 30, 60] as const).map((mins) => {
                const isActiveTimer = sleepTimerMinutes === mins;
                return (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => handleSetSleepTimer(isActiveTimer ? null : mins)}
                    className={`px-2 py-0.5 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                      isActiveTimer
                        ? 'bg-[#5B5FEF] text-white'
                        : 'bg-white text-[#25263A] border border-[#E6E6F0] hover:border-[#5B5FEF]'
                    }`}
                  >
                    {mins} د
                  </button>
                );
              })}
            </div>

            {/* فتح المشغل الكامل */}
            <button
              type="button"
              onClick={() => setIsFullPlayerOpen(true)}
              className="px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] cursor-pointer hidden sm:block"
            >
              المشغل الكامل
            </button>
          </div>
        </div>
      </div>

      {/* ==================== الشاشة 3: المشغل الصوتي الكامل (Full Player Modal) ==================== */}
      {isFullPlayerOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 md:p-6">
          <div className="bg-[#FFFFFF] w-full max-w-2xl rounded-3xl border-2 border-[#5B5FEF] shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            {/* رأس المشغل الكامل */}
            <div className="bg-[#F7F7FC] px-5 py-4 border-b border-[#E6E6F0] flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <GoldenHeadphonesMushafSvg size={24} />
                <div>
                  <h3 className="font-bold text-sm text-[#25263A]">
                    المشغل القرآني المتقدم — رِفْق
                  </h3>
                  <p className="text-[11px] text-[#4CAF82] font-bold">
                    يدعم التشغيل في الخلفية وإشعارات النظام والتحميل Offline
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsFullPlayerOpen(false)}
                aria-label="إغلاق المشغل"
                className="w-9 h-9 rounded-full bg-white border border-[#E6E6F0] flex items-center justify-center cursor-pointer"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M18 6L6 18M6 6L18 18"
                    stroke="#5B5FEF"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                  />
                </svg>
              </button>
            </div>

            {/* محتوى المشغل */}
            <div className="p-5 overflow-y-auto space-y-5">
              {/* معلومات السورة والقارئ */}
              <div className="text-center space-y-2">
                <div className="w-20 h-20 mx-auto rounded-full bg-[#F7F7FC] border-2 border-[#5B5FEF] flex items-center justify-center shadow-inner">
                  <GoldenHeadphonesMushafSvg size={42} />
                </div>
                <h2
                  className="text-3xl font-bold text-[#25263A]"
                  style={{ fontFamily: "'Amiri', serif" }}
                >
                  سُورَةُ {currentSurahMeta.name}
                </h2>
                <p className="text-sm font-bold text-[#5B5FEF]">الشيخ {currentReciter.name}</p>
                <p className="text-xs text-[#77798C]">
                  {currentReciter.rewaya} ·{' '}
                  {currentSurahMeta.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} ·{' '}
                  {currentSurahMeta.numberOfAyahs} آية
                </p>
              </div>

              {/* التبديل بين التلاوة الكاملة (mp3quran) أو آية بآية (everyayah) */}
              <div className="bg-[#F7F7FC] p-1.5 rounded-2xl border border-[#E6E6F0] flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setIsAyahByAyahMode(false);
                    playRecitation(currentReciter, currentSurahNumber, { ayahMode: false });
                  }}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    !isAyahByAyahMode ? 'bg-[#5B5FEF] text-white' : 'text-[#25263A]'
                  }`}
                >
                  السورة كاملة (mp3quran.net)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsAyahByAyahMode(true);
                    playRecitation(currentReciter, currentSurahNumber, {
                      ayahMode: true,
                      ayahNumber: currentAyahNumber,
                    });
                  }}
                  className={`flex-1 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                    isAyahByAyahMode ? 'bg-[#5B5FEF] text-white' : 'text-[#25263A]'
                  }`}
                >
                  آية بآية مع النص (everyayah.com)
                </button>
              </div>

              {/* صندوق عرض الآيات عند تفعيل وضع آية بآية أو المصحف المتزامن */}
              <div className="bg-[#F7F7FC] rounded-2xl p-4 border border-[#E6E6F0] max-h-48 overflow-y-auto space-y-2">
                <div className="flex items-center justify-between text-xs text-[#77798C] mb-1">
                  <span>آيات سورة {currentSurahMeta.name} (اضغط على أي آية للاستماع إليها مباشرة)</span>
                  {isAyahByAyahMode && (
                    <span className="font-bold text-[#4CAF82]">
                      الآية الحالية: {currentAyahNumber} من {currentSurahMeta.numberOfAyahs}
                    </span>
                  )}
                </div>
                {loadingSurahText ? (
                  <p className="text-center text-xs text-[#77798C] py-4">
                    جاري تحميل نص السورة...
                  </p>
                ) : (
                  <div className="space-y-2">
                    {surahAyahsText.map((ayah) => {
                      const activeAyah =
                        isAyahByAyahMode && currentAyahNumber === ayah.numberInSurah;
                      return (
                        <button
                          key={ayah.numberInSurah}
                          type="button"
                          onClick={() => {
                            setIsAyahByAyahMode(true);
                            playRecitation(currentReciter, currentSurahNumber, {
                              ayahMode: true,
                              ayahNumber: ayah.numberInSurah,
                            });
                          }}
                          className={`w-full text-right p-2.5 rounded-xl border transition-all cursor-pointer block ${
                            activeAyah
                              ? 'bg-[#FFFFFF] border-[#5B5FEF] shadow-xs'
                              : 'bg-white/70 border-transparent hover:border-[#E6E6F0]'
                          }`}
                        >
                          <p
                            className="text-lg leading-loose text-[#25263A]"
                            style={{ fontFamily: "'Amiri', serif" }}
                          >
                            {ayah.text}{' '}
                            <span className="text-[#5B5FEF] font-bold text-sm">
                              ﴿{ayah.numberInSurah}﴾
                            </span>
                          </p>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* شريط التقدم (Seekbar) */}
              <div className="space-y-1.5">
                <input
                  type="range"
                  min={0}
                  max={duration > 0 ? duration : 100}
                  value={currentTime}
                  onChange={(e) => handleSeek(Number(e.target.value))}
                  className="w-full accent-[#E8B84A] cursor-pointer"
                />
                <div className="flex items-center justify-between text-xs text-[#77798C] font-bold">
                  <span>{formatTimeMMSS(currentTime)}</span>
                  <span>{formatTimeMMSS(duration)}</span>
                </div>
              </div>

              {/* أزرار التحكم الرئيسية */}
              <div className="flex items-center justify-center gap-3 md:gap-5">
                <button
                  type="button"
                  onClick={() => handleSkipSeconds(-10)}
                  className="px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] cursor-pointer"
                >
                  -10 ث
                </button>

                <button
                  type="button"
                  onClick={() =>
                    playRecitation(
                      currentReciter,
                      currentSurahNumber > 1 ? currentSurahNumber - 1 : 114
                    )
                  }
                  className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center cursor-pointer"
                  aria-label="السورة السابقة"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M9 18L15 12L9 6"
                      stroke="#5B5FEF"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>

                <button
                  type="button"
                  onClick={togglePlayPause}
                  className="w-16 h-16 rounded-full bg-[#5B5FEF] hover:bg-[#4145C7] text-white flex items-center justify-center shadow-lg cursor-pointer"
                  aria-label={isPlaying ? 'إيقاف مؤقت' : 'تشغيل'}
                >
                  {isPlaying ? (
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="#FFFFFF">
                      <rect x="6" y="5" width="4" height="14" rx="1" />
                      <rect x="14" y="5" width="4" height="14" rx="1" />
                    </svg>
                  ) : (
                    <svg width="26" height="26" viewBox="0 0 24 24" fill="#FFFFFF">
                      <path d="M8 5.14V19.14L19 12.14L8 5.14Z" />
                    </svg>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() =>
                    playRecitation(
                      currentReciter,
                      currentSurahNumber < 114 ? currentSurahNumber + 1 : 1
                    )
                  }
                  className="w-11 h-11 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center cursor-pointer"
                  aria-label="السورة التالية"
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <path
                      d="M15 18L9 12L15 6"
                      stroke="#5B5FEF"
                      strokeWidth="2.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>

                <button
                  type="button"
                  onClick={() => handleSkipSeconds(10)}
                  className="px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] cursor-pointer"
                >
                  +10 ث
                </button>

                {/* أيقونة الساعة في شريط التحكم للمشغل الكامل */}
                <button
                  type="button"
                  onClick={() => {
                    const cycle: (number | null)[] = [null, 15, 30, 60];
                    const next = cycle[(cycle.indexOf(sleepTimerMinutes) + 1) % cycle.length];
                    handleSetSleepTimer(next);
                  }}
                  aria-label="مؤقت النوم"
                  title="مؤقت النوم (15، 30، 60 دقيقة)"
                  className={`w-11 h-11 rounded-full border flex items-center justify-center transition-colors cursor-pointer ${
                    sleepTimerRemainingSeconds !== null
                      ? 'bg-[#5B5FEF] border-[#5B5FEF] text-white'
                      : 'bg-[#EEEEFF] border-[#5B5FEF] text-[#4145C7]'
                  }`}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <circle
                      cx="12"
                      cy="12"
                      r="9"
                      stroke={sleepTimerRemainingSeconds !== null ? '#FFFFFF' : '#E8B84A'}
                      strokeWidth="2.2"
                    />
                    <path
                      d="M12 7V12L15 14"
                      stroke={sleepTimerRemainingSeconds !== null ? '#FFFFFF' : '#E8B84A'}
                      strokeWidth="2.2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </div>

              {/* قسم مؤقت النوم المخصص (Sleep Timer: 15، 30، 60 دقيقة) */}
              <div className="bg-[#F7F7FC] rounded-2xl p-3.5 border border-[#E6E6F0] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="9" stroke="#5B5FEF" strokeWidth="2.2" />
                      <path
                        d="M12 7V12L15 14"
                        stroke="#5B5FEF"
                        strokeWidth="2.2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    <span className="text-xs md:text-sm font-bold text-[#25263A]">
                      مؤقت النوم (إيقاف التلاوة تلقائياً)
                    </span>
                  </div>
                  {sleepTimerRemainingSeconds !== null && (
                    <span className="text-xs font-bold text-[#4CAF82]">
                      الوقت المتبقي: {formatTimeMMSS(sleepTimerRemainingSeconds)}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-4 gap-2">
                  {([15, 30, 60] as const).map((mins) => {
                    const active = sleepTimerMinutes === mins;
                    return (
                      <button
                        key={mins}
                        type="button"
                        onClick={() => handleSetSleepTimer(active ? null : mins)}
                        className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                          active
                            ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                            : 'bg-white text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                        }`}
                      >
                        {mins} دقيقة
                      </button>
                    );
                  })}
                  <button
                    type="button"
                    onClick={() => handleSetSleepTimer(null)}
                    disabled={sleepTimerMinutes === null}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      sleepTimerMinutes === null
                        ? 'bg-white/50 text-[#77798C] border-[#E6E6F0] cursor-not-allowed'
                        : 'bg-white text-[#25263A] border-[#E6E6F0] hover:border-[#5B5FEF]'
                    }`}
                  >
                    إيقاف المؤقت
                  </button>
                </div>
              </div>

              {/* أدوات التحكم الإضافية: السرعة، التكرار، التحميل */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-3 border-t border-[#F7F7FC]">
                {/* السرعة */}
                <button
                  type="button"
                  onClick={() => {
                    const speeds = [0.75, 1, 1.25, 1.5, 2];
                    const next = speeds[(speeds.indexOf(playbackSpeed) + 1) % speeds.length];
                    handleChangeSpeed(next);
                  }}
                  className="py-2.5 px-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] cursor-pointer"
                >
                  السرعة: {playbackSpeed}x
                </button>

                {/* وضع التكرار */}
                <button
                  type="button"
                  onClick={() => {
                    const next: PlaybackRepeatMode =
                      repeatMode === 'sequential'
                        ? 'repeat_one'
                        : repeatMode === 'repeat_one'
                        ? 'stop_after_one'
                        : 'sequential';
                    setRepeatMode(next);
                  }}
                  className="py-2.5 px-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] cursor-pointer"
                >
                  {repeatMode === 'sequential'
                    ? 'تشغيل متتالي'
                    : repeatMode === 'repeat_one'
                    ? 'تكرار السورة'
                    : 'إيقاف بعد السورة'}
                </button>

                {/* تحميل السورة Offline */}
                {(() => {
                  const currentKey = `${currentReciter.id}_${currentSurahNumber}`;
                  const isCurrentDownloaded = downloadedTracks.some(
                    (d) => d.id === currentKey && d.downloadStatus === 'downloaded'
                  );
                  const currentDlProgress = downloadingMap[currentKey];
                  const currentFailed =
                    Boolean(failedDownloadsMap[currentKey]) &&
                    !isCurrentDownloaded &&
                    currentDlProgress === undefined;

                  return (
                    <button
                      type="button"
                      disabled={!isOnline && !isCurrentDownloaded}
                      onClick={() =>
                        isCurrentDownloaded
                          ? handleDeleteDownload(currentReciter.id, currentSurahNumber)
                          : handleDownloadSurah(currentReciter, currentSurahNumber)
                      }
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                        currentDlProgress !== undefined
                          ? 'bg-[#5B5FEF] text-white'
                          : isCurrentDownloaded
                          ? 'bg-[#4CAF82] text-white'
                          : currentFailed
                          ? 'bg-red-600 text-white'
                          : 'bg-[#5B5FEF] text-white'
                      }`}
                    >
                      {currentDlProgress !== undefined
                        ? `جاري التحميل... ${currentDlProgress}%`
                        : isCurrentDownloaded
                        ? '✓ تم التحميل (حذف)'
                        : currentFailed
                        ? 'فشل التحميل — إعادة المحاولة'
                        : 'تحميل السورة Offline'}
                    </button>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
