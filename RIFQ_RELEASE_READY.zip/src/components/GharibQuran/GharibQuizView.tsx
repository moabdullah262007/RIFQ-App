import React, { useState } from 'react';
import {
  GharibQuizQuestion,
  GharibQuizQuestionType,
  GharibQuizResultEntry,
  generateGharibQuiz,
  loadQuizResults,
  saveQuizResult,
} from '../../utils/gharibQuranStorage';
import {
  GharibCheckSvg,
  GharibCrossSvg,
  GharibQuizSvg,
  GharibRefreshSvg,
  GharibShareSvg,
} from './GharibQuranIcons';

interface GharibQuizViewProps {
  darkMode: boolean;
  onShowToast: (msg: string) => void;
  onOpenWordDetail: (wordId: number) => void;
}

export const GharibQuizView: React.FC<GharibQuizViewProps> = ({
  darkMode,
  onShowToast,
  onOpenWordDetail,
}) => {
  const [questionCount, setQuestionCount] = useState<number>(10);
  const [questionType, setQuestionType] = useState<GharibQuizQuestionType>('word_meaning');
  const [difficulty, setDifficulty] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');

  const [questions, setQuestions] = useState<GharibQuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isConfirmed, setIsConfirmed] = useState<boolean>(false);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [wrongCount, setWrongCount] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [quizHistory, setQuizHistory] = useState<GharibQuizResultEntry[]>(loadQuizResults);

  const cardBg = darkMode ? 'bg-[#1E1E1E] border-[#E6E6F0] text-[#F7F7FC]' : 'bg-white border-[#E6E6F0] text-[#25263A]';
  const subCardBg = darkMode ? 'bg-[#121212] border-[#E6E6F0]' : 'bg-[#F7F7FC] border-[#E6E6F0]';
  const mutedText = darkMode ? 'text-stone-400' : 'text-[#77798C]';

  const startQuiz = () => {
    const generated = generateGharibQuiz(questionCount, questionType, difficulty);
    setQuestions(generated);
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsConfirmed(false);
    setCorrectCount(0);
    setWrongCount(0);
    setIsFinished(false);
  };

  const handleConfirmAnswer = () => {
    if (selectedOption === null || isConfirmed) return;
    const currentQ = questions[currentIndex];
    const isCorrect = selectedOption === currentQ.correctIndex;
    setIsConfirmed(true);
    if (isCorrect) {
      setCorrectCount((prev) => prev + 1);
    } else {
      setWrongCount((prev) => prev + 1);
    }
  };

  const finishQuizNow = (finalCorrect: number, finalWrong: number, totalAnswered: number) => {
    const total = Math.max(1, totalAnswered);
    const accuracy = Math.round((finalCorrect / total) * 100);
    const updated = saveQuizResult({
      total,
      correct: finalCorrect,
      wrong: finalWrong,
      accuracy,
      questionType,
      difficulty,
    });
    setQuizHistory(updated);
    setIsFinished(true);
  };

  const handleNextQuestion = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsConfirmed(false);
    } else {
      finishQuizNow(correctCount, wrongCount, questions.length);
    }
  };

  const handleShareResult = () => {
    const total = Math.max(1, correctCount + wrongCount);
    const accuracy = Math.round((correctCount / total) * 100);
    const text = `نتيجتي في اختبار «غريب القرآن» بتطبيق رِفْق | RIFQ:\n• عدد الأسئلة: ${total}\n• الإجابات الصحيحة: ${correctCount}\n• الأخطاء: ${wrongCount}\n• نسبة الدقة: ${accuracy}%`;
    if (navigator.share) {
      navigator.share({ title: 'اختبار غريب القرآن — رِفْق', text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      onShowToast('تم نسخ نتيجة الاختبار لمشاركتها');
    }
  };

  // 1. Setup Screen
  if (questions.length === 0) {
    return (
      <div className="space-y-4 animate-fade-in">
        <div className={`rounded-[16px] border p-5 shadow-xs ${cardBg}`}>
          <div className="flex items-center gap-2.5 mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-[#5B5FEF]">
              <GharibQuizSvg size={22} />
            </div>
            <div>
              <h3 className="font-cairo font-bold text-lg">إعدادات الاختبار التفاعلي</h3>
              <p className={`text-xs ${mutedText}`}>اختبر معرفتك بمعاني ومصادر غريب القرآن الكريم</p>
            </div>
          </div>

          {/* عدد الأسئلة */}
          <div className="mb-4">
            <label className="block font-cairo font-bold text-xs mb-2 text-[#5B5FEF]">
              عدد الأسئلة
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[5, 10, 15, 20].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setQuestionCount(num)}
                  className={`py-2.5 rounded-xl font-cairo font-bold text-sm border transition-all cursor-pointer tabular-nums ${
                    questionCount === num
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                      : `${subCardBg} hover:border-[#5B5FEF]`
                  }`}
                >
                  {num} أسئلة
                </button>
              ))}
            </div>
          </div>

          {/* نوع السؤال */}
          <div className="mb-4">
            <label className="block font-cairo font-bold text-xs mb-2 text-[#5B5FEF]">
              نوع السؤال
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                { id: 'word_meaning', label: 'ما معنى الكلمة؟' },
                { id: 'meaning_to_word', label: 'ما الكلمة التي تعني...؟' },
                { id: 'word_to_surah', label: 'من أي سورة؟' },
                { id: 'mixed', label: 'اختبار شامل (متنوع)' },
              ].map((typeObj) => (
                <button
                  key={typeObj.id}
                  type="button"
                  onClick={() => setQuestionType(typeObj.id as GharibQuizQuestionType)}
                  className={`py-2.5 px-3 rounded-xl font-cairo font-bold text-xs text-right border transition-all cursor-pointer flex items-center justify-between ${
                    questionType === typeObj.id
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : `${subCardBg} hover:border-[#5B5FEF]`
                  }`}
                >
                  <span>{typeObj.label}</span>
                  <span className="w-2.5 h-2.5 rounded-full border border-current" />
                </button>
              ))}
            </div>
          </div>

          {/* مستوى الصعوبة */}
          <div className="mb-5">
            <label className="block font-cairo font-bold text-xs mb-2 text-[#5B5FEF]">
              مستوى الصعوبة
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'easy', label: 'سهل' },
                { id: 'medium', label: 'متوسط' },
                { id: 'hard', label: 'متقدم' },
              ].map((diff) => (
                <button
                  key={diff.id}
                  type="button"
                  onClick={() => setDifficulty(diff.id as 'all' | 'easy' | 'medium' | 'hard')}
                  className={`py-2 rounded-xl font-cairo font-bold text-xs border transition-all cursor-pointer ${
                    difficulty === diff.id
                      ? 'bg-[#25263A] text-[#5B5FEF] border-[#5B5FEF]'
                      : `${subCardBg} hover:border-[#5B5FEF]`
                  }`}
                >
                  {diff.label}
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={startQuiz}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-sm shadow-md hover:opacity-95 active:scale-98 transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <GharibQuizSvg size={18} />
            <span>بدء الاختبار الآن</span>
          </button>
        </div>

        {/* سجل الاختبارات السابقة */}
        {quizHistory.length > 0 && (
          <div className={`rounded-[16px] border p-4 ${cardBg}`}>
            <h4 className="font-cairo font-bold text-sm text-[#5B5FEF] mb-3">
              سجل نتائجك السابقة ({quizHistory.length})
            </h4>
            <div className="space-y-2 max-h-56 overflow-y-auto">
              {quizHistory.slice(0, 6).map((res) => (
                <div
                  key={res.id}
                  className={`p-3 rounded-xl border flex items-center justify-between text-xs ${subCardBg}`}
                >
                  <div>
                    <span className="font-bold">
                      {res.correct} صحيحة من {res.total}
                    </span>
                    <span className={`mx-2 ${mutedText}`}>•</span>
                    <span className={mutedText}>
                      {new Date(res.date).toLocaleDateString('ar-EG')}
                    </span>
                  </div>
                  <span
                    className={`font-cairo font-bold tabular-nums px-2.5 py-0.5 rounded-lg ${
                      res.accuracy >= 70
                        ? 'text-[#4CAF82] bg-[#4CAF82]/12'
                        : 'text-[#D95C6A] bg-[#D95C6A]/10'
                    }`}
                  >
                    {res.accuracy}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // 2. Results Screen
  if (isFinished) {
    const totalAnswered = Math.max(1, correctCount + wrongCount);
    const accuracy = Math.round((correctCount / totalAnswered) * 100);

    return (
      <div className={`rounded-[16px] border p-6 text-center space-y-5 animate-fade-in ${cardBg}`}>
        <div className="w-16 h-16 rounded-full bg-[#EEEEFF] border-2 border-[#5B5FEF] flex items-center justify-center mx-auto text-[#5B5FEF]">
          <GharibCheckSvg size={34} />
        </div>

        <div>
          <h3 className="font-cairo font-bold text-xl">نتيجة الاختبار</h3>
          <p className={`text-xs mt-1 ${mutedText}`}>
            أحسنت المثابرة في تدبر معاني كتاب الله عز وجل
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className={`p-3 rounded-xl border ${subCardBg}`}>
            <span className={`block text-[11px] ${mutedText}`}>عدد الأسئلة</span>
            <span className="font-cairo font-bold text-lg tabular-nums">{totalAnswered}</span>
          </div>
          <div className="p-3 rounded-xl border border-[#4CAF82]/40 bg-[#4CAF82]/12 text-[#4CAF82]">
            <span className="block text-[11px]">الإجابات الصحيحة</span>
            <span className="font-cairo font-bold text-lg tabular-nums">{correctCount}</span>
          </div>
          <div className="p-3 rounded-xl border border-[#D95C6A]/40 bg-[#D95C6A]/10 text-[#D95C6A]">
            <span className="block text-[11px]">الأخطاء</span>
            <span className="font-cairo font-bold text-lg tabular-nums">{wrongCount}</span>
          </div>
          <div className={`p-3 rounded-xl border border-[#5B5FEF] ${subCardBg}`}>
            <span className={`block text-[11px] ${mutedText}`}>الدقة %</span>
            <span className="font-cairo font-bold text-lg text-[#5B5FEF] tabular-nums">
              {accuracy}%
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button
            type="button"
            onClick={startQuiz}
            className="flex-1 py-3 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
          >
            <GharibRefreshSvg size={16} />
            <span>إعادة الاختبار</span>
          </button>
          <button
            type="button"
            onClick={handleShareResult}
            className={`flex-1 py-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all ${subCardBg}`}
          >
            <GharibShareSvg size={16} />
            <span>مشاركة النتيجة</span>
          </button>
          <button
            type="button"
            onClick={() => setQuestions([])}
            className={`px-4 py-3 rounded-xl border font-cairo font-bold text-xs cursor-pointer ${subCardBg}`}
          >
            الإعدادات
          </button>
        </div>
      </div>
    );
  }

  // 3. Active Question Screen
  const currentQ = questions[currentIndex];
  const progressPercent = Math.round(((currentIndex + 1) / questions.length) * 100);

  return (
    <div className={`rounded-[16px] border p-5 space-y-4 animate-fade-in ${cardBg}`}>
      {/* Header Progress */}
      <div className="flex items-center justify-between text-xs font-cairo font-bold">
        <span className="text-[#5B5FEF] tabular-nums">
          السؤال {currentIndex + 1} من {questions.length}
        </span>
        <div className="flex items-center gap-3 tabular-nums">
          <span className="text-[#4CAF82]">صحيح: {correctCount}</span>
          <span className="text-[#D95C6A]">خطأ: {wrongCount}</span>
        </div>
      </div>

      <div className="w-full h-2 rounded-full bg-[#EEEEFF] overflow-hidden">
        <div
          className="h-full bg-[#5B5FEF] transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Question Prompt Box */}
      <div className={`rounded-2xl border p-5 text-center space-y-2.5 ${subCardBg}`}>
        <p className={`text-xs font-cairo font-bold ${mutedText}`}>{currentQ.promptLabel}</p>
        <p className="font-amiri font-bold text-2xl sm:text-3xl text-[#5B5FEF] leading-relaxed">
          {currentQ.promptHighlight}
        </p>
        <p className={`text-xs font-amiri ${mutedText}`}>
          سورة {currentQ.wordRecord.surahName} • آية {currentQ.wordRecord.ayahNumber}
        </p>
      </div>

      {/* Options */}
      <div className="space-y-2.5">
        {currentQ.options.map((optionText, idx) => {
          const isSelected = selectedOption === idx;
          const isCorrectOption = idx === currentQ.correctIndex;

          let optionStyle = `${subCardBg} hover:border-[#5B5FEF]`;
          if (!isConfirmed && isSelected) {
            optionStyle = 'bg-[#EEEEFF] border-[#5B5FEF] ring-1 ring-[#5B5FEF]';
          } else if (isConfirmed) {
            if (isCorrectOption) {
              optionStyle = 'bg-[#5B5FEF] text-white border-[#4CAF82]';
            } else if (isSelected && !isCorrectOption) {
              optionStyle = 'bg-[#D95C6A] text-white border-[#D95C6A]';
            }
          }

          return (
            <button
              key={idx}
              type="button"
              disabled={isConfirmed}
              onClick={() => setSelectedOption(idx)}
              className={`w-full p-3.5 rounded-xl border text-right font-cairo font-bold text-sm transition-all flex items-center justify-between gap-3 cursor-pointer ${optionStyle}`}
            >
              <span className="leading-relaxed">{optionText}</span>
              <span className="shrink-0">
                {isConfirmed && isCorrectOption ? (
                  <GharibCheckSvg size={20} />
                ) : isConfirmed && isSelected && !isCorrectOption ? (
                  <GharibCrossSvg size={20} />
                ) : (
                  <span
                    className={`block w-4 h-4 rounded-full border ${
                      isSelected ? 'border-[#5B5FEF] bg-[#5B5FEF]' : 'border-current opacity-40'
                    }`}
                  />
                )}
              </span>
            </button>
          );
        })}
      </div>

      {/* Explanation Box after Confirming */}
      {isConfirmed && (
        <div
          className={`p-3.5 rounded-xl border text-xs space-y-1 animate-fade-in ${
            selectedOption === currentQ.correctIndex
              ? 'bg-[#4CAF82]/12 border-[#4CAF82]/40 text-[#4CAF82]'
              : 'bg-[#D95C6A]/10 border-[#D95C6A]/40 text-[#D95C6A]'
          }`}
        >
          <div className="font-bold">
            {selectedOption === currentQ.correctIndex
              ? 'إجابة صحيحة بارك الله فيك'
              : `إجابة غير صحيحة — الصواب: ${currentQ.options[currentQ.correctIndex]}`}
          </div>
          <p className={darkMode ? 'text-stone-300' : 'text-[#25263A]'}>
            {currentQ.wordRecord.detailedExplanation}
          </p>
          <div className="flex items-center justify-between pt-1">
            <span className={mutedText}>المصدر: {currentQ.wordRecord.source}</span>
            <button
              type="button"
              onClick={() => onOpenWordDetail(currentQ.wordRecord.id)}
              className="text-[#5B5FEF] underline font-bold cursor-pointer"
            >
              عرض بطاقة الكلمة
            </button>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center gap-2.5 pt-2">
        {!isConfirmed ? (
          <button
            type="button"
            disabled={selectedOption === null}
            onClick={handleConfirmAnswer}
            className="flex-1 py-3 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-sm disabled:opacity-45 cursor-pointer active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <GharibCheckSvg size={18} />
            <span>الإجابة</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={handleNextQuestion}
            className="flex-1 py-3 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-sm cursor-pointer active:scale-95 transition-all"
          >
            {currentIndex + 1 < questions.length ? 'السؤال التالي' : 'عرض النتيجة النهائية'}
          </button>
        )}

        <button
          type="button"
          onClick={() =>
            finishQuizNow(
              correctCount,
              wrongCount,
              Math.max(1, correctCount + wrongCount)
            )
          }
          className={`px-4 py-3 rounded-xl border font-cairo font-bold text-xs cursor-pointer ${subCardBg}`}
        >
          إنهاء الاختبار
        </button>
      </div>
    </div>
  );
};
