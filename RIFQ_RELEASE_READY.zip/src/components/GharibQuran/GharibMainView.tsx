import React, { useState, useEffect, useMemo } from 'react';
import { ArrowRight, Moon, Sun, ChevronLeft, X } from 'lucide-react';
import { SURAH_LIST } from '../../data/quranData';
import {
  GHARIB_SOURCES,
  GharibWordRecord,
  SURAH_GHARIB_COUNTS,
  TOTAL_GHARIB_CORPUS_COUNT,
  normalizeArabicForSearch,
} from '../../data/gharibQuranData';
import {
  GharibDailyWordEntry,
  GharibFavoriteEntry,
  GharibSettings,
  exportGharibWordAsImage,
  fetchAndCacheSurahGharibWords,
  getGharibProgressStats,
  loadAllCachedGharibWords,
  loadDailyWordsLog,
  loadGharibFavorites,
  loadGharibSettings,
  recordWordViewedToday,
  saveGharibSettings,
  sendGharibInstantNotification,
  toggleGharibFavorite,
} from '../../utils/gharibQuranStorage';
import {
  GharibBellSvg,
  GharibBookSvg,
  GharibCalendarSvg,
  GharibCheckSvg,
  GharibCopySvg,
  GharibImageShareSvg,
  GharibMushafPenSvg,
  GharibQuizSvg,
  GharibRefreshSvg,
  GharibSearchSvg,
  GharibShareSvg,
  GharibStarSvg,
  GharibStatsSvg,
  GharibSurahFrameSvg,
} from './GharibQuranIcons';
import { GharibQuizView } from './GharibQuizView';

type GharibSubScreen =
  | 'dashboard'
  | 'surahs'
  | 'surah_words'
  | 'word_detail'
  | 'search'
  | 'quiz'
  | 'favorites';

interface GharibMainViewProps {
  onBack: () => void;
}

const ARABIC_LETTERS = [
  'أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص',
  'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي',
];

export const GharibMainView: React.FC<GharibMainViewProps> = ({ onBack }) => {
  const [subScreen, setSubScreen] = useState<GharibSubScreen>('dashboard');
  const [previousScreen, setPreviousScreen] = useState<GharibSubScreen>('dashboard');
  const [allWords, setAllWords] = useState<GharibWordRecord[]>(loadAllCachedGharibWords);
  const [favorites, setFavorites] = useState<GharibFavoriteEntry[]>(loadGharibFavorites);
  const [dailyLog, setDailyLog] = useState<GharibDailyWordEntry[]>(loadDailyWordsLog);
  const [settings, setSettings] = useState<GharibSettings>(loadGharibSettings);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Daily word rotation index (defaulting to Surah Sad ayah 16 / Abasa 30 or daily deterministic seed)
  const [dailyWordIndex, setDailyWordIndex] = useState<number>(() => {
    const daySeed = new Date().getDate() + new Date().getMonth() * 31;
    const words = loadAllCachedGharibWords();
    const sadIdx = words.findIndex((w) => w.wordPlain === 'غلبا' || w.wordPlain === 'قطنا');
    return sadIdx >= 0 ? sadIdx : daySeed % words.length;
  });

  // Selected Surah & Word Detail states
  const [selectedSurahId, setSelectedSurahId] = useState<number>(1);
  const [surahWordsLoading, setSurahWordsLoading] = useState<boolean>(false);
  const [surahFilterQuery, setSurahFilterQuery] = useState<string>('');
  const [selectedWordId, setSelectedWordId] = useState<number>(89);

  // Search states (Screen 4)
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchFilterMode, setSearchFilterMode] = useState<'all' | 'surah' | 'letter'>('all');
  const [searchSurahId, setSearchSurahId] = useState<number>(0);
  const [searchLetter, setSearchLetter] = useState<string>('');

  // Favorites states (Screen 6)
  const [favSearchQuery, setFavSearchQuery] = useState<string>('');
  const [favSurahFilter, setFavSurahFilter] = useState<number>(0);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2600);
  };

  const currentDailyWord = useMemo(() => {
    return allWords[dailyWordIndex % allWords.length] || allWords[0];
  }, [allWords, dailyWordIndex]);

  useEffect(() => {
    if (currentDailyWord) {
      const updated = recordWordViewedToday(currentDailyWord.id);
      setDailyLog(updated);
    }
  }, [currentDailyWord]);

  const progressStats = useMemo(
    () => getGharibProgressStats(dailyLog, settings),
    [dailyLog, settings]
  );

  const favoriteIdsSet = useMemo(
    () => new Set(favorites.map((f) => f.wordId)),
    [favorites]
  );

  const handleToggleFavorite = (wordId: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const res = toggleGharibFavorite(wordId);
    setFavorites(res.favorites);
    showToast(res.isFavorite ? 'تمت إضافة الكلمة إلى المفضلة' : 'تمت إزالة الكلمة من المفضلة');
  };

  const handleCopyWord = (word: GharibWordRecord, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = `﴿${word.word}﴾\nالآية: ﴿${word.ayahText}﴾ [سورة ${word.surahName} - آية ${word.ayahNumber}]\nالمعنى: ${word.meaning}\nالمصدر: ${word.source}\n— تطبيق رِفْق | RIFQ`;
    navigator.clipboard.writeText(text);
    showToast('تم نسخ الكلمة ومعناها ومصدرها بنجاح');
  };

  const handleShareWord = (word: GharibWordRecord, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = `📖 من غريب القرآن الكريم:\n﴿${word.word}﴾\n﴿${word.ayahText}﴾ [سورة ${word.surahName}: ${word.ayahNumber}]\n• المعنى: ${word.meaning}\n• المصدر: ${word.source}\n— تطبيق رِفْق | RIFQ`;
    if (navigator.share) {
      navigator.share({ title: `غريب القرآن: ﴿${word.word}﴾`, text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      showToast('تم نسخ البطاقة لمشاركتها');
    }
  };

  const handleShareAsImage = async (word: GharibWordRecord) => {
    showToast('جارٍ تجهيز بطاقة الصورة عالية الدقة...');
    const ok = await exportGharibWordAsImage(word);
    if (ok) {
      showToast('تم تصدير ومشاركة بطاقة الكلمة كصورة بنجاح');
    }
  };

  const handleAnotherDailyWord = () => {
    const nextIdx = (dailyWordIndex + 1) % allWords.length;
    setDailyWordIndex(nextIdx);
    const nextWord = allWords[nextIdx];
    if (nextWord) {
      const updated = recordWordViewedToday(nextWord.id);
      setDailyLog(updated);
    }
  };

  const handleOpenSurahWords = async (surahId: number) => {
    setSelectedSurahId(surahId);
    setPreviousScreen('surahs');
    setSubScreen('surah_words');
    setSurahWordsLoading(true);
    const fetched = await fetchAndCacheSurahGharibWords(surahId);
    if (fetched.length > 0) {
      setAllWords(loadAllCachedGharibWords());
    }
    setSurahWordsLoading(false);
  };

  const handleOpenWordDetail = (wordId: number) => {
    setSelectedWordId(wordId);
    setPreviousScreen(subScreen === 'word_detail' ? 'dashboard' : subScreen);
    setSubScreen('word_detail');
    const updated = recordWordViewedToday(wordId);
    setDailyLog(updated);
  };

  const handleUpdateSettings = (patch: Partial<GharibSettings>) => {
    const updated = { ...settings, ...patch };
    setSettings(updated);
    saveGharibSettings(updated);
  };

  // Filtered words for Search Screen (Screen 4)
  const searchResults = useMemo(() => {
    const normQuery = normalizeArabicForSearch(searchQuery);
    return allWords.filter((w) => {
      if (searchFilterMode === 'surah' && searchSurahId > 0 && w.surahId !== searchSurahId) {
        return false;
      }
      if (searchFilterMode === 'letter' && searchLetter && w.firstLetter !== searchLetter) {
        return false;
      }
      if (!normQuery) return true;
      const hay = normalizeArabicForSearch(
        `${w.word} ${w.wordPlain} ${w.meaning} ${w.surahName} ${w.root} ${w.ayahText}`
      );
      return hay.includes(normQuery);
    });
  }, [allWords, searchQuery, searchFilterMode, searchSurahId, searchLetter]);

  // Filtered words for Surah Words Screen (Screen 2 detail)
  const currentSurahWords = useMemo(() => {
    return allWords
      .filter((w) => w.surahId === selectedSurahId)
      .sort((a, b) => a.ayahNumber - b.ayahNumber);
  }, [allWords, selectedSurahId]);

  // Selected Word Detail (Screen 3)
  const selectedWordDetail = useMemo(() => {
    return allWords.find((w) => w.id === selectedWordId) || currentDailyWord;
  }, [allWords, selectedWordId, currentDailyWord]);

  // Favorites list (Screen 6)
  const favoriteWordsList = useMemo(() => {
    const normQ = normalizeArabicForSearch(favSearchQuery);
    return favorites
      .map((fav) => {
        const word = allWords.find((w) => w.id === fav.wordId);
        return word ? { fav, word } : null;
      })
      .filter((item): item is { fav: GharibFavoriteEntry; word: GharibWordRecord } => {
        if (!item) return false;
        if (favSurahFilter > 0 && item.word.surahId !== favSurahFilter) return false;
        if (!normQ) return true;
        const hay = normalizeArabicForSearch(
          `${item.word.word} ${item.word.meaning} ${item.word.surahName}`
        );
        return hay.includes(normQ);
      });
  }, [favorites, allWords, favSearchQuery, favSurahFilter]);

  const darkMode = settings.darkMode;
  const pageBg = darkMode ? 'bg-[#121212] text-[#F7F7FC]' : 'bg-[#F7F7FC] text-[#25263A]';
  const cardBg = darkMode
    ? 'bg-[#1E1E1E] border-[#E6E6F0] text-[#F7F7FC]'
    : 'bg-[#FFFFFF] border-[#E6E6F0] text-[#25263A]';
  const ivoryBg = darkMode
    ? 'bg-[#171717] border-[#E6E6F0] text-[#F7F7FC]'
    : 'bg-[#F7F7FC] border-[#E6E6F0] text-[#25263A]';
  const beigeBoxBg = darkMode
    ? 'bg-[#242424] border-[#E6E6F0] text-stone-300'
    : 'bg-[#F7F7FC] border-[#E6E6F0] text-[#77798C]';
  const mutedText = darkMode ? 'text-stone-400' : 'text-[#77798C]';

  const meaningFontSizeClass =
    settings.fontSize === 'large'
      ? 'text-[18px]'
      : settings.fontSize === 'small'
      ? 'text-[14px]'
      : 'text-[16px]';

  const handleHeaderBack = () => {
    if (subScreen === 'dashboard') {
      onBack();
    } else if (subScreen === 'word_detail') {
      setSubScreen(previousScreen || 'dashboard');
    } else if (subScreen === 'surah_words') {
      setSubScreen('surahs');
    } else {
      setSubScreen('dashboard');
    }
  };

  return (
    <div
      className={`min-h-[82vh] rounded-[22px] p-3 sm:p-5 transition-colors duration-300 select-none ${pageBg}`}
      dir="rtl"
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-24 right-1/2 translate-x-1/2 z-50 bg-[#25263A] text-[#F7F7FC] px-5 py-2.5 rounded-full text-xs font-cairo font-bold shadow-2xl border border-[#5B5FEF] flex items-center gap-2 animate-fade-in">
          <GharibCheckSvg size={16} className="text-[#5B5FEF] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ── 【الشريط العلوي الموحد】رجوع + غريب القرآن + بحث + مفضلة + وضع ليلي + إشعارات ── */}
      <header
        className={`rounded-[16px] border px-3.5 py-3 mb-4 flex items-center justify-between gap-2 shadow-xs ${cardBg}`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={handleHeaderBack}
            aria-label="رجوع"
            className={`w-10 h-10 rounded-xl border flex items-center justify-center cursor-pointer active:scale-95 transition-all shrink-0 ${ivoryBg}`}
          >
            <ArrowRight className="w-5 h-5 text-[#5B5FEF]" />
          </button>

          <div
            onClick={() => setSubScreen('dashboard')}
            className="flex items-center gap-2 cursor-pointer truncate"
          >
            <GharibMushafPenSvg size={30} className="shrink-0" />
            <div className="truncate">
              <h1 className="font-cairo font-bold text-base sm:text-lg text-[#5B5FEF] leading-tight truncate">
                {subScreen === 'word_detail'
                  ? `كلمة: ﴿${selectedWordDetail.word}﴾`
                  : subScreen === 'surah_words'
                  ? `غريب سورة ${SURAH_LIST.find((s) => s.number === selectedSurahId)?.name || ''}`
                  : 'غريب القرآن'}
              </h1>
              <p className={`text-[11px] font-cairo truncate ${mutedText}`}>
                معجم الألفاظ القرآنية من أمهات كتب التفسير واللغة
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {/* زر البحث */}
          <button
            type="button"
            onClick={() => setSubScreen('search')}
            aria-label="البحث في غريب القرآن"
            title="البحث"
            className={`w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-all ${
              subScreen === 'search'
                ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                : `${ivoryBg} text-[#5B5FEF] hover:border-[#5B5FEF]`
            }`}
          >
            <GharibSearchSvg size={18} />
          </button>

          {/* زر المفضلة */}
          <button
            type="button"
            onClick={() => setSubScreen('favorites')}
            aria-label="المفضلة"
            title="المفضلة"
            className={`relative w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-all ${
              subScreen === 'favorites'
                ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                : `${ivoryBg} text-[#5B5FEF] hover:border-[#5B5FEF]`
            }`}
          >
            <GharibStarSvg size={18} filled={favorites.length > 0} />
            {favorites.length > 0 && (
              <span className="absolute -top-1 -left-1 min-w-[16px] h-4 px-1 rounded-full bg-[#5B5FEF] text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                {favorites.length}
              </span>
            )}
          </button>

          {/* زر الإشعارات والإعدادات */}
          <button
            type="button"
            onClick={() => setShowSettingsModal(true)}
            aria-label="إعدادات غريب القرآن والإشعارات"
            title="الإشعارات اليومية والإعدادات"
            className={`w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-all ${ivoryBg} text-[#5B5FEF] hover:border-[#5B5FEF]`}
          >
            <GharibBellSvg size={18} />
          </button>

          {/* زر الوضع الليلي */}
          <button
            type="button"
            onClick={() => handleUpdateSettings({ darkMode: !darkMode })}
            aria-label="تبديل الوضع الليلي"
            title="الوضع الليلي"
            className={`w-9 h-9 rounded-xl border flex items-center justify-center cursor-pointer transition-all ${ivoryBg} text-[#5B5FEF] hover:border-[#5B5FEF]`}
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* ════════════════════════════════════════════════════════════════════════
          📱 الشاشة 1: الشاشة الرئيسية (Dashboard)
         ════════════════════════════════════════════════════════════════════════ */}
      {subScreen === 'dashboard' && (
        <div className="space-y-4 animate-fade-in">
          {/* 【البطاقة الرئيسية: كلمة اليوم】 */}
          <div className={`rounded-[16px] border p-4 sm:p-5 shadow-xs ${cardBg}`}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-[#5B5FEF]">
                <GharibBookSvg size={20} />
                <h2 className="font-cairo font-bold text-base">كلمة اليوم</h2>
              </div>
              <button
                type="button"
                onClick={() => handleToggleFavorite(currentDailyWord.id)}
                className="p-2 rounded-xl border border-[#E6E6F0] text-[#5B5FEF] hover:bg-[#EEEEFF] cursor-pointer transition-all"
                aria-label="إضافة للمفضلة"
              >
                <GharibStarSvg
                  size={18}
                  filled={favoriteIdsSet.has(currentDailyWord.id)}
                />
              </button>
            </div>

            {/* البطاقة الداخلية العاجية للكلمة */}
            <div
              onClick={() => handleOpenWordDetail(currentDailyWord.id)}
              className={`rounded-[16px] border p-5 text-center space-y-3 cursor-pointer transition-all hover:border-[#5B5FEF] ${ivoryBg}`}
            >
              {/* الكلمة القرآنية بخط Amiri 36px ذهبي */}
              <div className="font-amiri font-bold text-[36px] text-[#5B5FEF] leading-relaxed">
                ﴿{currentDailyWord.word}﴾
              </div>

              {/* الآية الكريمة */}
              <p className="font-amiri text-lg sm:text-xl leading-loose opacity-95 max-w-xl mx-auto">
                ﴿{currentDailyWord.ayahText}﴾
              </p>

              {/* المعنى */}
              <div className="pt-2 border-t border-[#E6E6F0]">
                <span className="block font-cairo font-bold text-xs text-[#5B5FEF] mb-1">
                  المعنى:
                </span>
                <p className={`font-cairo font-bold ${meaningFontSizeClass} leading-relaxed`}>
                  {currentDailyWord.meaning}
                </p>
              </div>

              {/* السورة ورقم الآية والمصدر */}
              <div className={`pt-1 flex items-center justify-center gap-2 flex-wrap text-xs font-cairo font-bold ${mutedText}`}>
                <span className="text-[#5B5FEF]">
                  سورة {currentDailyWord.surahName} - آية {currentDailyWord.ayahNumber}
                </span>
                <span>•</span>
                <span>{currentDailyWord.source}</span>
              </div>
            </div>

            {/* أزرار البطاقة: مشاركة + نسخ + كلمة أخرى */}
            <div className="grid grid-cols-2 gap-2.5 mt-3.5">
              <button
                type="button"
                onClick={() => handleShareWord(currentDailyWord)}
                className={`py-2.5 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all ${ivoryBg}`}
              >
                <GharibShareSvg size={16} className="text-[#5B5FEF]" />
                <span>مشاركة</span>
              </button>

              <button
                type="button"
                onClick={() => handleCopyWord(currentDailyWord)}
                className={`py-2.5 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all ${ivoryBg}`}
              >
                <GharibCopySvg size={16} className="text-[#5B5FEF]" />
                <span>نسخ</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleAnotherDailyWord}
              className="w-full mt-2.5 py-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 shadow-xs hover:opacity-95 active:scale-98 transition-all cursor-pointer"
            >
              <GharibRefreshSvg size={16} />
              <span>كلمة أخرى</span>
            </button>
          </div>

          {/* 【الإحصائيات】 */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className={`rounded-[16px] border p-3.5 text-center ${cardBg}`}>
              <div className="w-8 h-8 rounded-full bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto mb-1.5">
                <GharibStatsSvg size={16} />
              </div>
              <span className={`block text-[11px] font-cairo ${mutedText}`}>كلمات اليوم</span>
              <span className="font-cairo font-bold text-sm sm:text-base text-[#5B5FEF] tabular-nums">
                {progressStats.todayCount} / {progressStats.dailyTarget}
              </span>
            </div>

            <div className={`rounded-[16px] border p-3.5 text-center ${cardBg}`}>
              <div className="w-8 h-8 rounded-full bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto mb-1.5">
                <GharibCalendarSvg size={16} />
              </div>
              <span className={`block text-[11px] font-cairo ${mutedText}`}>الأسبوع</span>
              <span className="font-cairo font-bold text-sm sm:text-base tabular-nums">
                {progressStats.weekCount} كلمة
              </span>
            </div>

            <div className={`rounded-[16px] border p-3.5 text-center ${cardBg}`}>
              <div className="w-8 h-8 rounded-full bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto mb-1.5">
                <GharibBookSvg size={16} />
              </div>
              <span className={`block text-[11px] font-cairo ${mutedText}`}>إجمالي الكلمات</span>
              <span className="font-cairo font-bold text-sm sm:text-base text-[#5B5FEF] tabular-nums">
                {TOTAL_GHARIB_CORPUS_COUNT} كلمة
              </span>
            </div>
          </div>

          {/* 【الأزرار الرئيسية الـ 4】 */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setSubScreen('surahs')}
              className={`rounded-[16px] border p-4 text-right flex items-center justify-between cursor-pointer active:scale-95 transition-all hover:border-[#5B5FEF] ${cardBg}`}
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-[#5B5FEF] shrink-0">
                  <GharibBookSvg size={22} />
                </div>
                <div>
                  <span className="block font-cairo font-bold text-sm">فهرس السور</span>
                  <span className={`text-[11px] ${mutedText}`}>114 سورة كريمة</span>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#5B5FEF] shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => setSubScreen('search')}
              className={`rounded-[16px] border p-4 text-right flex items-center justify-between cursor-pointer active:scale-95 transition-all hover:border-[#5B5FEF] ${cardBg}`}
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-[#5B5FEF] shrink-0">
                  <GharibSearchSvg size={22} />
                </div>
                <div>
                  <span className="block font-cairo font-bold text-sm">البحث</span>
                  <span className={`text-[11px] ${mutedText}`}>فلاتر بالسورة والحرف</span>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#5B5FEF] shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => setSubScreen('quiz')}
              className={`rounded-[16px] border p-4 text-right flex items-center justify-between cursor-pointer active:scale-95 transition-all hover:border-[#5B5FEF] ${cardBg}`}
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-[#5B5FEF] shrink-0">
                  <GharibQuizSvg size={22} />
                </div>
                <div>
                  <span className="block font-cairo font-bold text-sm">اختبر نفسك</span>
                  <span className={`text-[11px] ${mutedText}`}>اختبارات تفاعلية</span>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#5B5FEF] shrink-0" />
            </button>

            <button
              type="button"
              onClick={() => setSubScreen('favorites')}
              className={`rounded-[16px] border p-4 text-right flex items-center justify-between cursor-pointer active:scale-95 transition-all hover:border-[#5B5FEF] ${cardBg}`}
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-[#5B5FEF] shrink-0">
                  <GharibStarSvg size={22} filled={favorites.length > 0} />
                </div>
                <div>
                  <span className="block font-cairo font-bold text-sm">المفضلة</span>
                  <span className={`text-[11px] tabular-nums ${mutedText}`}>
                    {favorites.length} كلمة محفوظة
                  </span>
                </div>
              </div>
              <ChevronLeft className="w-4 h-4 text-[#5B5FEF] shrink-0" />
            </button>
          </div>

          {/* 【المصادر الحقيقية المعتمدة】 */}
          <div className={`rounded-[16px] border p-4 ${cardBg}`}>
            <h3 className="font-cairo font-bold text-xs text-[#5B5FEF] mb-2.5">
              المصادر العلمية واللغوية المعتمدة في المعجم
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {GHARIB_SOURCES.map((src) => (
                <div
                  key={src.id}
                  className={`px-3 py-2 rounded-xl border text-xs flex items-center justify-between ${beigeBoxBg}`}
                >
                  <span className="font-cairo font-bold">{src.bookTitle}</span>
                  <span className="text-[11px] opacity-80">{src.author}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          📱 الشاشة 2: فهرس السور (114 سورة)
         ════════════════════════════════════════════════════════════════════════ */}
      {subScreen === 'surahs' && (
        <div className="space-y-3 animate-fade-in">
          <div className={`rounded-[16px] border p-3 ${cardBg}`}>
            <div className="relative">
              <input
                type="text"
                value={surahFilterQuery}
                onChange={(e) => setSurahFilterQuery(e.target.value)}
                placeholder="ابحث باسم السورة أو رقمها (1 - 114)..."
                className={`w-full pr-10 pl-4 py-2.5 rounded-xl border text-sm font-cairo focus:outline-none focus:border-[#5B5FEF] ${ivoryBg}`}
              />
              <GharibSearchSvg
                size={18}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#5B5FEF]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {SURAH_LIST.filter((s) => {
              if (!surahFilterQuery.trim()) return true;
              const q = normalizeArabicForSearch(surahFilterQuery);
              return (
                normalizeArabicForSearch(s.name).includes(q) ||
                String(s.number).includes(q)
              );
            }).map((surah) => {
              const gharibCount = SURAH_GHARIB_COUNTS[surah.number] || 12;
              return (
                <div
                  key={surah.number}
                  onClick={() => handleOpenSurahWords(surah.number)}
                  className={`rounded-[16px] border p-3.5 flex items-center justify-between gap-3 cursor-pointer hover:border-[#5B5FEF] active:scale-98 transition-all ${cardBg}`}
                >
                  <div className="flex items-center gap-3">
                    <GharibSurahFrameSvg number={surah.number} />
                    <div>
                      <h3 className="font-cairo font-bold text-sm sm:text-base">
                        سورة {surah.name}
                      </h3>
                      <p className={`text-xs font-cairo tabular-nums ${mutedText}`}>
                        {gharibCount} كلمة غريبة • {surah.numberOfAyahs} آية
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    className="px-3.5 py-1.5 rounded-xl bg-[#EEEEFF] border border-[#E6E6F0] text-[#5B5FEF] font-cairo font-bold text-xs flex items-center gap-1 hover:bg-[#4145C7] hover:text-white transition-colors cursor-pointer"
                  >
                    <span>دخول</span>
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          📱 الشاشة 2 (ب): قائمة الكلمات الغريبة داخل السورة
         ════════════════════════════════════════════════════════════════════════ */}
      {subScreen === 'surah_words' && (
        <div className="space-y-3 animate-fade-in">
          <div className={`rounded-[16px] border p-4 flex items-center justify-between ${cardBg}`}>
            <div>
              <h2 className="font-cairo font-bold text-base text-[#5B5FEF]">
                مفردات وغريب سورة {SURAH_LIST.find((s) => s.number === selectedSurahId)?.name}
              </h2>
              <p className={`text-xs ${mutedText}`}>
                اضغط على أي كلمة لعرض الشرح التفصيلي والمصادر اللغوية
              </p>
            </div>
            <button
              type="button"
              onClick={() => setSubScreen('surahs')}
              className={`px-3 py-1.5 rounded-xl border font-cairo font-bold text-xs cursor-pointer ${ivoryBg}`}
            >
              كل السور
            </button>
          </div>

          {surahWordsLoading && (
            <div className={`rounded-[16px] border p-4 text-center text-xs font-cairo ${cardBg}`}>
              جارٍ تحميل وتوثيق جميع مفردات السورة للعمل بدون إنترنت...
            </div>
          )}

          <div className="space-y-2.5">
            {currentSurahWords.map((item) => (
              <div
                key={item.id}
                onClick={() => handleOpenWordDetail(item.id)}
                className={`rounded-[16px] border p-4 space-y-2.5 cursor-pointer hover:border-[#5B5FEF] transition-all ${cardBg}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-amiri font-bold text-2xl sm:text-3xl text-[#5B5FEF]">
                      ﴿{item.word}﴾
                    </span>
                    <span className={`mr-2 text-xs font-cairo font-bold tabular-nums ${mutedText}`}>
                      • الآية {item.ayahNumber}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => handleCopyWord(item, e)}
                      aria-label="نسخ"
                      className={`p-2 rounded-lg border text-[#5B5FEF] cursor-pointer ${ivoryBg}`}
                    >
                      <GharibCopySvg size={15} />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleShareWord(item, e)}
                      aria-label="مشاركة"
                      className={`p-2 rounded-lg border text-[#5B5FEF] cursor-pointer ${ivoryBg}`}
                    >
                      <GharibShareSvg size={15} />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => handleToggleFavorite(item.id, e)}
                      aria-label="مفضلة"
                      className={`p-2 rounded-lg border text-[#5B5FEF] cursor-pointer ${ivoryBg}`}
                    >
                      <GharibStarSvg size={15} filled={favoriteIdsSet.has(item.id)} />
                    </button>
                  </div>
                </div>

                <p className={`font-cairo font-bold ${meaningFontSizeClass} leading-relaxed`}>
                  {item.meaning}
                </p>

                <div className={`text-xs font-cairo flex items-center justify-between pt-1 ${mutedText}`}>
                  <span>المصدر: {item.source}</span>
                  <span className="text-[#5B5FEF] font-bold">التفاصيل ←</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          📱 الشاشة 3: تفاصيل الكلمة (Word Detail View)
         ════════════════════════════════════════════════════════════════════════ */}
      {subScreen === 'word_detail' && selectedWordDetail && (
        <div className={`rounded-[16px] border p-5 sm:p-6 space-y-5 animate-fade-in ${cardBg}`}>
          {/* الكلمة القرآنية بخط Amiri 36px ذهبي */}
          <div className="text-center space-y-1">
            <div className="font-amiri font-bold text-[36px] sm:text-[42px] text-[#5B5FEF] leading-relaxed">
              {selectedWordDetail.word}
            </div>
            <span className={`inline-block text-xs font-cairo font-bold ${mutedText}`}>
              الجذر اللغوي: ({selectedWordDetail.root})
            </span>
          </div>

          {/* بطاقة الآية الكريمة */}
          <div className={`rounded-[16px] border p-5 text-center space-y-3 ${ivoryBg}`}>
            <p className="font-amiri font-bold text-xl sm:text-2xl leading-loose">
              ﴿{selectedWordDetail.ayahText}﴾
            </p>
            <div className="text-xs font-cairo font-bold text-[#5B5FEF]">
              سورة {selectedWordDetail.surahName} - آية {selectedWordDetail.ayahNumber}
            </div>
          </div>

          {/* المعنى */}
          <div className="space-y-2 text-center">
            <div className="text-xs font-cairo font-bold text-[#5B5FEF] tracking-wide">
              ─── المعنى ───
            </div>
            <p className={`font-cairo font-bold ${meaningFontSizeClass} leading-relaxed`}>
              {selectedWordDetail.meaning}
            </p>
            <p className={`font-cairo text-sm leading-relaxed pt-1 ${mutedText}`}>
              {selectedWordDetail.detailedExplanation}
            </p>
          </div>

          {/* المصادر */}
          <div className="space-y-2">
            <div className="text-xs font-cairo font-bold text-[#5B5FEF] text-center tracking-wide">
              ─── المصدر ───
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className={`p-3 rounded-xl border flex items-center gap-2.5 text-sm font-cairo font-bold ${beigeBoxBg}`}>
                <GharibBookSvg size={18} className="text-[#5B5FEF] shrink-0" />
                <span>{selectedWordDetail.source}</span>
              </div>
              <div className={`p-3 rounded-xl border flex items-center gap-2.5 text-sm font-cairo font-bold ${beigeBoxBg}`}>
                <GharibBookSvg size={18} className="text-[#5B5FEF] shrink-0" />
                <span>{selectedWordDetail.secondarySource}</span>
              </div>
            </div>
          </div>

          {/* أزرار التحكم السفلية */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
            <button
              type="button"
              onClick={() => handleCopyWord(selectedWordDetail)}
              className={`py-3 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all ${ivoryBg}`}
            >
              <GharibCopySvg size={16} className="text-[#5B5FEF]" />
              <span>نسخ</span>
            </button>

            <button
              type="button"
              onClick={() => handleShareWord(selectedWordDetail)}
              className={`py-3 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all ${ivoryBg}`}
            >
              <GharibShareSvg size={16} className="text-[#5B5FEF]" />
              <span>مشاركة</span>
            </button>

            <button
              type="button"
              onClick={() => handleShareAsImage(selectedWordDetail)}
              className={`py-3 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all ${ivoryBg}`}
            >
              <GharibImageShareSvg size={16} className="text-[#5B5FEF]" />
              <span>مشاركة كصورة</span>
            </button>

            <button
              type="button"
              onClick={() => handleToggleFavorite(selectedWordDetail.id)}
              className={`py-3 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all ${
                favoriteIdsSet.has(selectedWordDetail.id)
                  ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                  : ivoryBg
              }`}
            >
              <GharibStarSvg
                size={16}
                filled={favoriteIdsSet.has(selectedWordDetail.id)}
              />
              <span>{favoriteIdsSet.has(selectedWordDetail.id) ? 'في المفضلة' : 'مفضلة'}</span>
            </button>
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          📱 الشاشة 4: البحث (Search View)
         ════════════════════════════════════════════════════════════════════════ */}
      {subScreen === 'search' && (
        <div className="space-y-3.5 animate-fade-in">
          <div className={`rounded-[16px] border p-4 space-y-3 ${cardBg}`}>
            {/* شريط البحث */}
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={`ابحث في ${TOTAL_GHARIB_CORPUS_COUNT} كلمة (بالكلمة أو المعنى أو السورة)...`}
                className={`w-full pr-10 pl-9 py-3 rounded-xl border text-sm font-cairo focus:outline-none focus:border-[#5B5FEF] ${ivoryBg}`}
              />
              <GharibSearchSvg
                size={18}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#5B5FEF]"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-[#77798C] cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* الفلاتر: الكل | حسب السورة | حسب الحرف */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'surah', label: 'حسب السورة' },
                { id: 'letter', label: 'حسب الحرف' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setSearchFilterMode(tab.id as 'all' | 'surah' | 'letter');
                    if (tab.id === 'all') {
                      setSearchSurahId(0);
                      setSearchLetter('');
                    }
                  }}
                  className={`py-2 rounded-xl font-cairo font-bold text-xs border transition-all cursor-pointer ${
                    searchFilterMode === tab.id
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : `${ivoryBg} hover:border-[#5B5FEF]`
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* فلتر السورة */}
            {searchFilterMode === 'surah' && (
              <select
                value={searchSurahId}
                onChange={(e) => setSearchSurahId(Number(e.target.value))}
                className={`w-full p-2.5 rounded-xl border font-cairo font-bold text-xs ${ivoryBg}`}
              >
                <option value={0}>جميع السور (114 سورة)</option>
                {SURAH_LIST.map((s) => (
                  <option key={s.number} value={s.number}>
                    {s.number}. سورة {s.name}
                  </option>
                ))}
              </select>
            )}

            {/* فلتر الحرف */}
            {searchFilterMode === 'letter' && (
              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                {ARABIC_LETTERS.map((letter) => (
                  <button
                    key={letter}
                    type="button"
                    onClick={() =>
                      setSearchLetter((prev) => (prev === letter ? '' : letter))
                    }
                    className={`w-8 h-8 rounded-lg border font-cairo font-bold text-xs cursor-pointer transition-all ${
                      searchLetter === letter
                        ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                        : `${ivoryBg} hover:border-[#5B5FEF]`
                    }`}
                  >
                    {letter}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* النتائج */}
          <div className="space-y-2.5">
            {searchResults.map((item) => (
              <div
                key={item.id}
                onClick={() => handleOpenWordDetail(item.id)}
                className={`rounded-[16px] border p-4 flex items-center justify-between gap-3 cursor-pointer hover:border-[#5B5FEF] transition-all ${cardBg}`}
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-amiri font-bold text-2xl text-[#5B5FEF]">
                      ﴿{item.word}﴾
                    </span>
                    <span className={`text-xs font-cairo font-bold ${mutedText}`}>
                      سورة {item.surahName} • آية {item.ayahNumber}
                    </span>
                  </div>
                  <p className={`font-cairo font-bold text-sm leading-relaxed line-clamp-2`}>
                    {item.meaning}
                  </p>
                  <span className={`block text-[11px] font-cairo ${mutedText}`}>
                    {item.source}
                  </span>
                </div>

                <ChevronLeft className="w-5 h-5 text-[#5B5FEF] shrink-0" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          📱 الشاشة 5: اختبر نفسك (Quiz View)
         ════════════════════════════════════════════════════════════════════════ */}
      {subScreen === 'quiz' && (
        <GharibQuizView
          darkMode={darkMode}
          onShowToast={showToast}
          onOpenWordDetail={handleOpenWordDetail}
        />
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          📱 الشاشة 6: المفضلة (Favorites View)
         ════════════════════════════════════════════════════════════════════════ */}
      {subScreen === 'favorites' && (
        <div className="space-y-3.5 animate-fade-in">
          <div className={`rounded-[16px] border p-4 space-y-3 ${cardBg}`}>
            <div className="flex items-center justify-between">
              <h2 className="font-cairo font-bold text-base text-[#5B5FEF]">
                الكلمات المحفوظة في المفضلة ({favorites.length})
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div className="relative">
                <input
                  type="text"
                  value={favSearchQuery}
                  onChange={(e) => setFavSearchQuery(e.target.value)}
                  placeholder="بحث في المفضلة..."
                  className={`w-full pr-9 pl-3 py-2 rounded-xl border text-xs font-cairo ${ivoryBg}`}
                />
                <GharibSearchSvg
                  size={15}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#5B5FEF]"
                />
              </div>

              <select
                value={favSurahFilter}
                onChange={(e) => setFavSurahFilter(Number(e.target.value))}
                className={`p-2 rounded-xl border font-cairo font-bold text-xs ${ivoryBg}`}
              >
                <option value={0}>تصنيف حسب السورة: الكل</option>
                {SURAH_LIST.map((s) => (
                  <option key={s.number} value={s.number}>
                    سورة {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {favoriteWordsList.length === 0 ? (
            <div className={`rounded-[16px] border p-8 text-center space-y-3 ${cardBg}`}>
              <div className="w-12 h-12 rounded-full bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto">
                <GharibStarSvg size={24} />
              </div>
              <p className="font-cairo font-bold text-sm">لا توجد كلمات محفوظة في المفضلة حالياً</p>
              <button
                type="button"
                onClick={() => setSubScreen('surahs')}
                className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs cursor-pointer"
              >
                استعراض فهرس السور
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {favoriteWordsList.map(({ word }) => (
                <div
                  key={word.id}
                  onClick={() => handleOpenWordDetail(word.id)}
                  className={`rounded-[16px] border p-4 flex items-center justify-between gap-3 cursor-pointer hover:border-[#5B5FEF] transition-all ${cardBg}`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-amiri font-bold text-2xl text-[#5B5FEF]">
                        ﴿{word.word}﴾
                      </span>
                      <span className={`text-xs font-cairo font-bold ${mutedText}`}>
                        سورة {word.surahName} • آية {word.ayahNumber}
                      </span>
                    </div>
                    <p className="font-cairo font-bold text-sm">{word.meaning}</p>
                    <span className={`block text-[11px] ${mutedText}`}>{word.source}</span>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => handleToggleFavorite(word.id, e)}
                    aria-label="إزالة من المفضلة"
                    className="p-2 rounded-xl text-[#5B5FEF] hover:bg-[#D95C6A]/10 hover:text-[#D95C6A] cursor-pointer"
                  >
                    <GharibStarSvg size={20} filled />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── نافذة إعدادات غريب القرآن والإشعارات اليومية (جدول settings) ── */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className={`w-full max-w-md rounded-[20px] border p-5 space-y-4 shadow-2xl ${cardBg}`}>
            <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-3">
              <div className="flex items-center gap-2 text-[#5B5FEF]">
                <GharibBellSvg size={20} />
                <h3 className="font-cairo font-bold text-base">الإشعارات اليومية والإعدادات</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSettingsModal(false)}
                className="p-1.5 rounded-lg hover:bg-[#EEEEFF] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* تفعيل الإشعار اليومي */}
            <div className="flex items-center justify-between">
              <div>
                <span className="block font-cairo font-bold text-sm">إشعار يومي بكلمة غريبة</span>
                <span className={`text-xs ${mutedText}`}>تنبيه يومي حقيقي بمعنى كلمة قرآنية</span>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleUpdateSettings({ notificationEnabled: !settings.notificationEnabled })
                }
                className={`w-12 h-7 rounded-full p-1 transition-colors cursor-pointer ${
                  settings.notificationEnabled ? 'bg-[#4CAF82]' : 'bg-stone-400'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.notificationEnabled ? '-translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* وقت الإشعار */}
            <div className="flex items-center justify-between">
              <span className="font-cairo font-bold text-sm">وقت الإشعار اليومي</span>
              <input
                type="time"
                value={settings.notificationTime}
                onChange={(e) => handleUpdateSettings({ notificationTime: e.target.value })}
                className={`px-3 py-1.5 rounded-xl border font-cairo font-bold text-xs tabular-nums ${ivoryBg}`}
              />
            </div>

            {/* عدد الكلمات يومياً (1 - 15) */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-cairo font-bold text-sm">عدد الكلمات اليومية</span>
                <span className="font-cairo font-bold text-xs text-[#5B5FEF] tabular-nums">
                  {settings.dailyWordsCount} كلمة / يومياً
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={15}
                value={settings.dailyWordsCount}
                onChange={(e) =>
                  handleUpdateSettings({ dailyWordsCount: Number(e.target.value) })
                }
                className="w-full accent-[#E8B84A] cursor-pointer"
              />
            </div>

            {/* حجم الخط */}
            <div>
              <span className="block font-cairo font-bold text-sm mb-2">حجم خط المعاني</span>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'small', label: 'صغير' },
                  { id: 'medium', label: 'متوسط' },
                  { id: 'large', label: 'كبير' },
                ].map((sz) => (
                  <button
                    key={sz.id}
                    type="button"
                    onClick={() =>
                      handleUpdateSettings({ fontSize: sz.id as 'small' | 'medium' | 'large' })
                    }
                    className={`py-2 rounded-xl border font-cairo font-bold text-xs cursor-pointer ${
                      settings.fontSize === sz.id
                        ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                        : ivoryBg
                    }`}
                  >
                    {sz.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={async () => {
                const sent = await sendGharibInstantNotification(currentDailyWord);
                showToast(
                  sent
                    ? 'تم إرسال إشعار كلمة اليوم بنجاح'
                    : 'تم حفظ إعدادات الإشعار اليومي بنجاح'
                );
                setShowSettingsModal(false);
              }}
              className="w-full py-3 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs cursor-pointer active:scale-95 transition-all"
            >
              حفظ وتجربة الإشعار الفوري الآن
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
