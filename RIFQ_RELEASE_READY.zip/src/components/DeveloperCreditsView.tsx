import React, { useState, useEffect, useRef } from 'react';
import {
  Code2,
  Send,
  Bot,
  Mail,
  ExternalLink,
  Sparkles,
  Heart,
  Copy,
  Check,
  Share2,
  ArrowRight,
  ShieldCheck,
  MessageCircle,
  Smartphone,
  CheckCircle2,
  Headphones,
  Bug,
  Lightbulb,
  Clock,
  ImagePlus,
  Trash2,
  RefreshCw,
  MessageSquare,
  AlertCircle,
  FileText,
  UserCheck,
  Eye,
  X,
} from 'lucide-react';
import { ScreenType } from '../types';
import { shareRifqApp } from '../utils/shareRifq';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import {
  submitUserReportToFirestore,
  fetchUserOwnReports,
  subscribeToUserOwnReports,
  collectSafeDeviceDiagnosticInfo,
  compressScreenshotFileToDataUrl,
  formatAdminOperationError,
  getReportStatusLabel,
  ReportCategory,
  ReportStatus,
  UserReportRecord,
  SafeDeviceDiagnosticInfo,
} from '../utils/adminService';

interface DeveloperCreditsViewProps {
  onBack?: () => void;
  onNavigate?: (screen: ScreenType) => void;
}

const BUG_ISSUE_TYPES: { id: string; label: string; category: ReportCategory }[] = [
  { id: 'bug_crash', label: 'خلل برمجي أو توقف مفاجئ في التطبيق', category: 'bug' },
  { id: 'bug_audio_quran', label: 'مشكلة في الصوتيات أو المصحف الشريف', category: 'bug' },
  { id: 'bug_notifications', label: 'مشكلة في الإشعارات أو مواقيت الصلاة', category: 'bug' },
  { id: 'bug_ui', label: 'مشكلة في التصميم أو عرض الشاشات', category: 'bug' },
  { id: 'account_sync', label: 'مشكلة في الحساب أو المزامنة السحابية', category: 'account' },
  { id: 'content_note', label: 'ملاحظة على محتوى شرعي أو نص', category: 'content' },
  { id: 'group_wird', label: 'مشكلة في مجموعات الختمة (وِرد)', category: 'group' },
  { id: 'other_issue', label: 'مشكلة أخرى', category: 'other' },
];

const FEATURE_SUGGESTION_TYPES: { id: string; label: string }[] = [
  { id: 'sug_new_feature', label: 'إضافة ميزة إيمانية أو قرآنية جديدة' },
  { id: 'sug_improve_section', label: 'تطوير وتحسين قسم حالي في رِفْق' },
  { id: 'sug_ui_theme', label: 'تحسين التصميم أو الثيمات أو الخطوط' },
  { id: 'sug_notifications', label: 'تحسين الإشعارات والتذكيرات اليومية' },
  { id: 'sug_wird_tasbeeh', label: 'تطوير الختمات الجماعية (وِرد) أو المسبحة' },
  { id: 'sug_general', label: 'اقتراح عام لتطوير تطبيق رِفْق' },
];

export const DeveloperCreditsView: React.FC<DeveloperCreditsViewProps> = ({
  onBack,
}) => {
  // Official existing RIFQ links & identifiers — strictly preserved
  const telegramChannelUrl = 'https://t.me/RafiqAlMuslim1';
  const telegramBotUrl = 'https://t.me/Quuran4_bot';
  const developerEmail = 'mo.abdullah262007@gmail.com';
  const developerName = 'محمد عبدالله';
  const botUsername = '@Quuran4_bot';

  const { currentUser, openAuthModal } = useAuth();
  const { theme } = useTheme();

  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  const [activeSupportTab, setActiveSupportTab] = useState<'bug' | 'suggestion' | 'history'>('bug');

  // Bug Report Form State
  const [selectedBugTypeId, setSelectedBugTypeId] = useState<string>(BUG_ISSUE_TYPES[0].id);
  const [bugTitle, setBugTitle] = useState('');
  const [bugDescription, setBugDescription] = useState('');
  const [bugScreenshotDataUrl, setBugScreenshotDataUrl] = useState<string | null>(null);
  const [compressingScreenshot, setCompressingScreenshot] = useState(false);
  const [includeDeviceInfo, setIncludeDeviceInfo] = useState(true);
  const [deviceInfoPreview, setDeviceInfoPreview] = useState<SafeDeviceDiagnosticInfo>(() =>
    collectSafeDeviceDiagnosticInfo(theme?.definition?.nameAr)
  );
  const [submittingBug, setSubmittingBug] = useState(false);
  const [bugSuccessRecord, setBugSuccessRecord] = useState<UserReportRecord | null>(null);
  const [bugErrorMsg, setBugErrorMsg] = useState<string | null>(null);

  // Feature Suggestion Form State
  const [selectedSuggestionType, setSelectedSuggestionType] = useState<string>(
    FEATURE_SUGGESTION_TYPES[0].label
  );
  const [suggestionTitle, setSuggestionTitle] = useState('');
  const [suggestionDescription, setSuggestionDescription] = useState('');
  const [suggestionScreenshot, setSuggestionScreenshot] = useState<string | null>(null);
  const [submittingSuggestion, setSubmittingSuggestion] = useState(false);
  const [suggestionSuccessRecord, setSuggestionSuccessRecord] = useState<UserReportRecord | null>(
    null
  );
  const [suggestionErrorMsg, setSuggestionErrorMsg] = useState<string | null>(null);

  // User's Real Reports & Suggestions History from Firestore
  const [myReports, setMyReports] = useState<UserReportRecord[]>([]);
  const [loadingReports, setLoadingReports] = useState<boolean>(true);
  const [historyFilter, setHistoryFilter] = useState<'all' | 'bug' | 'suggestion'>('all');
  const [enlargedScreenshotUrl, setEnlargedScreenshotUrl] = useState<string | null>(null);

  const bugFileInputRef = useRef<HTMLInputElement | null>(null);
  const suggestionFileInputRef = useRef<HTMLInputElement | null>(null);
  const supportCenterSectionRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setDeviceInfoPreview(collectSafeDeviceDiagnosticInfo(theme?.definition?.nameAr));
  }, [theme?.definition?.nameAr]);

  // Real-time subscription to the user's own reports & suggestions in Firestore
  useEffect(() => {
    setLoadingReports(true);
    const unsub = subscribeToUserOwnReports(currentUser?.uid || null, (records) => {
      setMyReports(records);
      setLoadingReports(false);
    });
    return () => unsub();
  }, [currentUser?.uid]);

  const handleManualRefreshReports = async () => {
    setLoadingReports(true);
    try {
      const list = await fetchUserOwnReports(currentUser?.uid || null);
      setMyReports(list);
    } catch (err) {
      setBugErrorMsg(formatAdminOperationError(err));
    } finally {
      setLoadingReports(false);
    }
  };

  const handleCopy = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopiedItem(identifier);
    setTimeout(() => {
      setCopiedItem(null);
    }, 2000);
  };

  const handleShareApp = async () => {
    const result = await shareRifqApp();
    if (result === 'copied') {
      setCopiedItem('share');
      setTimeout(() => setCopiedItem(null), 2000);
    }
  };

  const handleScreenshotSelect = async (
    e: React.ChangeEvent<HTMLInputElement>,
    target: 'bug' | 'suggestion'
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setCompressingScreenshot(true);
    if (target === 'bug') setBugErrorMsg(null);
    else setSuggestionErrorMsg(null);

    try {
      const dataUrl = await compressScreenshotFileToDataUrl(file);
      if (target === 'bug') {
        setBugScreenshotDataUrl(dataUrl);
      } else {
        setSuggestionScreenshot(dataUrl);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'تعذر إرفاق لقطة الشاشة.';
      if (target === 'bug') setBugErrorMsg(msg);
      else setSuggestionErrorMsg(msg);
    } finally {
      setCompressingScreenshot(false);
      e.target.value = '';
    }
  };

  const handleBugSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingBug(true);
    setBugErrorMsg(null);
    setBugSuccessRecord(null);

    const chosenIssue =
      BUG_ISSUE_TYPES.find((t) => t.id === selectedBugTypeId) || BUG_ISSUE_TYPES[0];

    try {
      const currentDeviceInfo = includeDeviceInfo
        ? collectSafeDeviceDiagnosticInfo(theme?.definition?.nameAr)
        : null;

      const created = await submitUserReportToFirestore({
        category: chosenIssue.category,
        issueType: chosenIssue.label,
        subject: bugTitle,
        description: bugDescription,
        screenshotDataUrl: bugScreenshotDataUrl,
        deviceInfo: currentDeviceInfo,
      });

      setBugTitle('');
      setBugDescription('');
      setBugScreenshotDataUrl(null);
      setBugSuccessRecord(created);
      await handleManualRefreshReports();
    } catch (err) {
      setBugErrorMsg(formatAdminOperationError(err));
    } finally {
      setSubmittingBug(false);
    }
  };

  const handleSuggestionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingSuggestion(true);
    setSuggestionErrorMsg(null);
    setSuggestionSuccessRecord(null);

    try {
      const currentDeviceInfo = collectSafeDeviceDiagnosticInfo(theme?.definition?.nameAr);
      const created = await submitUserReportToFirestore({
        category: 'suggestion',
        issueType: selectedSuggestionType,
        subject: suggestionTitle,
        description: suggestionDescription,
        screenshotDataUrl: suggestionScreenshot,
        deviceInfo: currentDeviceInfo,
      });

      setSuggestionTitle('');
      setSuggestionDescription('');
      setSuggestionScreenshot(null);
      setSuggestionSuccessRecord(created);
      await handleManualRefreshReports();
    } catch (err) {
      setSuggestionErrorMsg(formatAdminOperationError(err));
    } finally {
      setSubmittingSuggestion(false);
    }
  };

  const renderStatusBadge = (status: ReportStatus) => {
    const label = getReportStatusLabel(status);
    switch (status) {
      case 'open':
      case 'new':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-amber-50 text-amber-700 border border-amber-200">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            <span>{label}</span>
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-blue-50 text-blue-700 border border-blue-200">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
            <span>{label}</span>
          </span>
        );
      case 'resolved':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>{label}</span>
          </span>
        );
      case 'closed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-gray-100 text-gray-700 border border-gray-200">
            <span>{label}</span>
          </span>
        );
    }
  };

  const filteredHistory = myReports.filter((item) => {
    if (historyFilter === 'all') return true;
    if (historyFilter === 'suggestion') return item.category === 'suggestion';
    return item.category !== 'suggestion';
  });

  const scrollToSupportForm = (tab: 'bug' | 'suggestion' | 'history') => {
    setActiveSupportTab(tab);
    supportCenterSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 pb-20 font-tajawal animate-fade-in" dir="rtl">
      {/* Top Navigation Bar with Back Button */}
      <div className="flex items-center justify-between bg-white/90 backdrop-blur-md p-3.5 rounded-2xl border border-[#E6E6F0] shadow-2xs">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold text-[#4145C7] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4" />
          <span>رجوع</span>
        </button>

        <div className="flex items-center gap-1.5">
          <Code2 className="w-4 h-4 text-[#5B5FEF]" />
          <span className="text-sm font-black text-[#4145C7]">مركز تواصل ودعم رِفْق</span>
        </div>

        <button
          onClick={handleShareApp}
          title="مشاركة التطبيق"
          className="p-2 rounded-xl text-[#4145C7] hover:bg-[#EEEEFF] transition-colors cursor-pointer"
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>

      {/* Main Developer Hero Card */}
      <div className="relative overflow-hidden bg-gradient-to-br from-[#4145C7] via-[#4145C7] to-[#2E3192] text-white rounded-3xl p-6 sm:p-8 shadow-md border-2 border-[#E6E6F0]">
        <div className="absolute top-0 right-0 w-48 h-48 bg-[#EEEEFF]/15 rounded-full blur-2xl pointer-events-none -mr-16 -mt-16" />
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#E8B84A]/15 rounded-full blur-xl pointer-events-none -ml-12 -mb-12" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-right">
          {/* Developer Avatar Badge */}
          <div className="relative">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-tr from-[#E8B84A] via-[#E5CE85] to-amber-200 p-1 shadow-lg flex items-center justify-center">
              <div className="w-full h-full bg-[#4145C7] rounded-[22px] flex items-center justify-center text-white shadow-inner">
                <Code2 className="w-10 h-10 sm:w-12 sm:h-12 text-[#E8B84A]" />
              </div>
            </div>
            <div
              className="absolute -bottom-2 -right-2 bg-gradient-to-r from-[#E8B84A] to-amber-400 text-[#25263A] rounded-full p-1.5 shadow-md border-2 border-[#4145C7]"
              title="مطور معتمد"
            >
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>

          {/* Developer Title and Purpose */}
          <div className="flex-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-amber-200 text-xs font-bold border border-white/15 mb-2 backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>مطور تطبيق «رِفْق | RIFQ»</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-wide">
              {developerName}
            </h1>

            <p className="text-sm text-blue-100/90 leading-relaxed mt-2 max-w-lg">
              تم تطوير هذا التطبيق لوجه الله تعالى كصدقة جارية، بهدف تيسير الذكر اليومي وتلاوة القرآن الكريم وملازمة الطاعات لكل مسلم.
            </p>

            <div className="mt-4 flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs">
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-xl bg-white/10 text-white font-medium">
                <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
                <span>نسألكم خالص الدعاء</span>
              </span>
              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-xl bg-white/10 text-white font-medium">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-300" />
                <span>خالٍ من أي إعلانات</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          🛠️ الدعم الفني — بطاقة "دعم رِفْق" الرسمية
         ═══════════════════════════════════════════════════════════════════════ */}
      <div className="bg-gradient-to-br from-white via-[#F7F7FC] to-[#EEEEFF]/50 rounded-3xl p-5 sm:p-6 border-2 border-[#5B5FEF]/25 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-[#5B5FEF] to-[#4145C7] text-white flex items-center justify-center shadow-md shadow-[#5B5FEF]/20 shrink-0">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-black text-[#25263A]">دعم رِفْق</h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-black border border-emerald-200">
                  مركز الدعم الرسمي
                </span>
              </div>
              <p className="text-xs sm:text-sm text-[#77798C] mt-1 leading-relaxed">
                واجهت مشكلة أو محتاج مساعدة؟ تواصل مع فريق دعم رِفْق.
              </p>
            </div>
          </div>

          <a
            href={telegramChannelUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-5 py-3 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 text-white text-xs font-black flex items-center justify-center gap-2 shadow-md shadow-[#5B5FEF]/20 transition-all cursor-pointer shrink-0"
          >
            <Headphones className="w-4 h-4" />
            <span>تواصل مع الدعم</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Quick Support Actions Bar */}
        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#E6E6F0]">
          <button
            type="button"
            onClick={() => scrollToSupportForm('bug')}
            className={`py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
              activeSupportTab === 'bug'
                ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                : 'bg-white text-[#25263A] border-[#E6E6F0] hover:bg-[#EEEEFF]/60'
            }`}
          >
            <Bug className="w-3.5 h-3.5 shrink-0" />
            <span>الإبلاغ عن مشكلة</span>
          </button>

          <button
            type="button"
            onClick={() => scrollToSupportForm('suggestion')}
            className={`py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
              activeSupportTab === 'suggestion'
                ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                : 'bg-white text-[#25263A] border-[#E6E6F0] hover:bg-[#EEEEFF]/60'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5 shrink-0" />
            <span>اقتراح ميزة</span>
          </button>

          <button
            type="button"
            onClick={() => scrollToSupportForm('history')}
            className={`py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
              activeSupportTab === 'history'
                ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                : 'bg-white text-[#25263A] border-[#E6E6F0] hover:bg-[#EEEEFF]/60'
            }`}
          >
            <Clock className="w-3.5 h-3.5 shrink-0" />
            <span>بلاغاتي ({myReports.length})</span>
          </button>
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          🐛 الإبلاغ عن مشكلة  |  💡 اقتراح ميزة  |  📋 متابعة البلاغات (Firebase)
         ═══════════════════════════════════════════════════════════════════════ */}
      <div
        ref={supportCenterSectionRef}
        className="bg-white rounded-3xl border border-[#E6E6F0] shadow-xs overflow-hidden"
      >
        {/* Section Header & Account Binding Status */}
        <div className="p-4 sm:p-5 bg-[#F7F7FC] border-b border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm sm:text-base font-black text-[#25263A] flex items-center gap-2">
              {activeSupportTab === 'bug' && (
                <>
                  <Bug className="w-4 h-4 text-[#D95C6A]" />
                  <span>الإبلاغ عن مشكلة تقنية أو محتوى</span>
                </>
              )}
              {activeSupportTab === 'suggestion' && (
                <>
                  <Lightbulb className="w-4 h-4 text-[#E8B84A]" />
                  <span>اقتراح ميزة لتطوير رِفْق</span>
                </>
              )}
              {activeSupportTab === 'history' && (
                <>
                  <Clock className="w-4 h-4 text-[#5B5FEF]" />
                  <span>سجل بلاغاتي واقتراحاتي وحالتها</span>
                </>
              )}
            </h2>
            <p className="text-[11px] text-[#77798C] mt-0.5">
              يتم حفظ جميع البلاغات والاقتراحات فعلياً في قاعدة بيانات Firebase ومراجعتها من فريق رِفْق.
            </p>
          </div>

          {currentUser ? (
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-[11px] font-bold shrink-0">
              <UserCheck className="w-3.5 h-3.5" />
              <span>مرتبط بحسابك: {currentUser.displayName || currentUser.email}</span>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => openAuthModal('login')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#5B5FEF] text-[#4145C7] hover:text-white border border-[#E6E6F0] text-[11px] font-bold transition-colors cursor-pointer shrink-0"
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>تسجيل الدخول لربط البلاغات بحسابك</span>
            </button>
          )}
        </div>

        <div className="p-5 sm:p-6">
          {/* ─── TAB 1: 🐛 الإبلاغ عن مشكلة ─── */}
          {activeSupportTab === 'bug' && (
            <form onSubmit={handleBugSubmit} className="space-y-4">
              {bugErrorMsg && (
                <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs font-bold flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{bugErrorMsg}</span>
                </div>
              )}

              {bugSuccessRecord && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-2">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2 font-black text-xs text-emerald-800">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>تم إرسال البلاغ وحفظه فعلياً في قاعدة بيانات رِفْق بنجاح!</span>
                    </div>
                    {renderStatusBadge(bugSuccessRecord.status)}
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-emerald-700 pt-1">
                    <span className="font-mono font-bold" dir="ltr">
                      ID: #{bugSuccessRecord.id}
                    </span>
                    <span>•</span>
                    <span>
                      وقت الإرسال: {new Date(bugSuccessRecord.createdAt).toLocaleString('ar-SA')}
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveSupportTab('history')}
                      className="underline font-black text-emerald-800 cursor-pointer mr-auto"
                    >
                      عرض في سجل بلاغاتي
                    </button>
                  </div>
                </div>
              )}

              {/* نوع المشكلة */}
              <div>
                <label className="block text-xs font-black text-[#25263A] mb-1.5">
                  نوع المشكلة
                </label>
                <select
                  value={selectedBugTypeId}
                  onChange={(e) => setSelectedBugTypeId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                >
                  {BUG_ISSUE_TYPES.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* عنوان المشكلة */}
              <div>
                <label className="block text-xs font-black text-[#25263A] mb-1.5">
                  عنوان المشكلة
                </label>
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={200}
                  value={bugTitle}
                  onChange={(e) => setBugTitle(e.target.value)}
                  placeholder="اكتب عنواناً مختصراً وواضحاً للمشكلة..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>

              {/* وصف المشكلة */}
              <div>
                <label className="block text-xs font-black text-[#25263A] mb-1.5">
                  وصف المشكلة
                </label>
                <textarea
                  required
                  minLength={5}
                  maxLength={3500}
                  rows={4}
                  value={bugDescription}
                  onChange={(e) => setBugDescription(e.target.value)}
                  placeholder="اشرح تفاصيل المشكلة، ومتى حدثت، والخطوات التي قمت بها..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF] leading-relaxed"
                />
              </div>

              {/* إرفاق Screenshot */}
              <div className="space-y-2">
                <label className="block text-xs font-black text-[#25263A]">
                  إرفاق لقطة شاشة (Screenshot) — اختياري
                </label>

                <input
                  ref={bugFileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleScreenshotSelect(e, 'bug')}
                  className="hidden"
                />

                {!bugScreenshotDataUrl ? (
                  <button
                    type="button"
                    disabled={compressingScreenshot}
                    onClick={() => bugFileInputRef.current?.click()}
                    className="w-full py-3 px-4 rounded-2xl border-2 border-dashed border-[#E6E6F0] hover:border-[#5B5FEF] bg-[#F7F7FC] hover:bg-[#EEEEFF]/30 text-xs font-bold text-[#77798C] hover:text-[#4145C7] flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <ImagePlus className="w-4 h-4 text-[#5B5FEF]" />
                    <span>
                      {compressingScreenshot
                        ? 'جاري تجهيز وضغط لقطة الشاشة...'
                        : 'اضغط لإرفاق صورة أو لقطة شاشة للمشكلة'}
                    </span>
                  </button>
                ) : (
                  <div className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={bugScreenshotDataUrl}
                        alt="Screenshot preview"
                        className="w-14 h-14 object-cover rounded-xl border border-[#E6E6F0] cursor-pointer"
                        onClick={() => setEnlargedScreenshotUrl(bugScreenshotDataUrl)}
                      />
                      <div>
                        <div className="text-xs font-black text-[#25263A]">
                          تم إرفاق لقطة الشاشة بنجاح
                        </div>
                        <div className="text-[11px] text-[#77798C]">
                          ستُرسل الصورة بأمان مع البلاغ لفريق الدعم
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setBugScreenshotDataUrl(null)}
                      className="p-2 rounded-xl bg-white hover:bg-red-50 text-[#D95C6A] border border-[#E6E6F0] cursor-pointer"
                      title="إزالة الصورة"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              {/* معلومات الجهاز والتطبيق الأساسية بشكل آمن */}
              <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-2.5">
                <label className="flex items-center justify-between cursor-pointer">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-[#5B5FEF]" />
                    <span className="text-xs font-black text-[#25263A]">
                      إرفاق معلومات الجهاز والتطبيق الأساسية بشكل آمن
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={includeDeviceInfo}
                    onChange={(e) => setIncludeDeviceInfo(e.target.checked)}
                    className="w-4 h-4 accent-[#5B5FEF] cursor-pointer"
                  />
                </label>

                {includeDeviceInfo && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1 text-[11px] text-[#77798C]">
                    <div className="bg-white px-2.5 py-1.5 rounded-xl border border-[#E6E6F0]">
                      <span className="block text-[10px] text-gray-400">إصدار رِفْق</span>
                      <span className="font-bold text-[#25263A]" dir="ltr">
                        v{deviceInfoPreview.appVersion}
                      </span>
                    </div>
                    <div className="bg-white px-2.5 py-1.5 rounded-xl border border-[#E6E6F0]">
                      <span className="block text-[10px] text-gray-400">المنصة</span>
                      <span className="font-bold text-[#25263A]">{deviceInfoPreview.platform}</span>
                    </div>
                    <div className="bg-white px-2.5 py-1.5 rounded-xl border border-[#E6E6F0]">
                      <span className="block text-[10px] text-gray-400">النظام / المتصفح</span>
                      <span className="font-bold text-[#25263A]" dir="ltr">
                        {deviceInfoPreview.browserOrOs}
                      </span>
                    </div>
                    <div className="bg-white px-2.5 py-1.5 rounded-xl border border-[#E6E6F0]">
                      <span className="block text-[10px] text-gray-400">أبعاد الشاشة</span>
                      <span className="font-bold text-[#25263A]" dir="ltr">
                        {deviceInfoPreview.screenResolution}
                      </span>
                    </div>
                    <div className="bg-white px-2.5 py-1.5 rounded-xl border border-[#E6E6F0]">
                      <span className="block text-[10px] text-gray-400">حالة الشبكة</span>
                      <span className="font-bold text-[#25263A]">
                        {deviceInfoPreview.onlineStatus}
                      </span>
                    </div>
                    {deviceInfoPreview.theme && (
                      <div className="bg-white px-2.5 py-1.5 rounded-xl border border-[#E6E6F0]">
                        <span className="block text-[10px] text-gray-400">الثيم النشط</span>
                        <span className="font-bold text-[#25263A]">{deviceInfoPreview.theme}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={submittingBug || compressingScreenshot}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 disabled:opacity-50 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-[#5B5FEF]/20 transition-all cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>{submittingBug ? 'جاري إرسال البلاغ وحفظه...' : 'إرسال البلاغ'}</span>
              </button>
            </form>
          )}

          {/* ─── TAB 2: 💡 اقتراح ميزة ─── */}
          {activeSupportTab === 'suggestion' && (
            <form onSubmit={handleSuggestionSubmit} className="space-y-4">
              {suggestionErrorMsg && (
                <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs font-bold flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{suggestionErrorMsg}</span>
                </div>
              )}

              {suggestionSuccessRecord && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-2">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2 font-black text-xs text-emerald-800">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>جزاك الله خيراً! تم حفظ اقتراحك فعلياً في قاعدة بيانات رِفْق.</span>
                    </div>
                    {renderStatusBadge(suggestionSuccessRecord.status)}
                  </div>
                  <div className="flex flex-wrap items-center gap-3 text-[11px] text-emerald-700 pt-1">
                    <span className="font-mono font-bold" dir="ltr">
                      ID: #{suggestionSuccessRecord.id}
                    </span>
                    <span>•</span>
                    <span>
                      وقت الإرسال:{' '}
                      {new Date(suggestionSuccessRecord.createdAt).toLocaleString('ar-SA')}
                    </span>
                    <button
                      type="button"
                      onClick={() => setActiveSupportTab('history')}
                      className="underline font-black text-emerald-800 cursor-pointer mr-auto"
                    >
                      متابعة حالة الاقتراح
                    </button>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-black text-[#25263A] mb-1.5">
                  مجال الاقتراح
                </label>
                <select
                  value={selectedSuggestionType}
                  onChange={(e) => setSelectedSuggestionType(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                >
                  {FEATURE_SUGGESTION_TYPES.map((item) => (
                    <option key={item.id} value={item.label}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-[#25263A] mb-1.5">
                  عنوان الميزة المقترحة
                </label>
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={200}
                  value={suggestionTitle}
                  onChange={(e) => setSuggestionTitle(e.target.value)}
                  placeholder="مثال: إضافة إحصائية أسبوعية لورد القرآن أو تنبيه صوتي مخصص..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF]"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-[#25263A] mb-1.5">
                  شرح الاقتراح وكيف سيفيد مستخدمي رِفْق
                </label>
                <textarea
                  required
                  minLength={5}
                  maxLength={3500}
                  rows={4}
                  value={suggestionDescription}
                  onChange={(e) => setSuggestionDescription(e.target.value)}
                  placeholder="اكتب تفاصيل فكرتك أو الميزة التي تتمنى رؤيتها في التحديثات القادمة..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF] leading-relaxed"
                />
              </div>

              {/* Optional Screenshot for Suggestion */}
              <div className="space-y-2">
                <label className="block text-xs font-black text-[#25263A]">
                  إرفاق صورة توضيحية للاقتراح — اختياري
                </label>
                <input
                  ref={suggestionFileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleScreenshotSelect(e, 'suggestion')}
                  className="hidden"
                />
                {!suggestionScreenshot ? (
                  <button
                    type="button"
                    disabled={compressingScreenshot}
                    onClick={() => suggestionFileInputRef.current?.click()}
                    className="w-full py-2.5 px-4 rounded-2xl border-2 border-dashed border-[#E6E6F0] hover:border-[#E8B84A] bg-[#F7F7FC] text-xs font-bold text-[#77798C] flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <ImagePlus className="w-4 h-4 text-[#E8B84A]" />
                    <span>إرفاق صورة توضيحية (اختياري)</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={suggestionScreenshot}
                        alt="Suggestion preview"
                        className="w-14 h-14 object-cover rounded-xl border border-[#E6E6F0] cursor-pointer"
                        onClick={() => setEnlargedScreenshotUrl(suggestionScreenshot)}
                      />
                      <span className="text-xs font-bold text-[#25263A]">
                        تم إرفاق الصورة التوضيحية
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSuggestionScreenshot(null)}
                      className="p-2 rounded-xl bg-white hover:bg-red-50 text-[#D95C6A] border border-[#E6E6F0] cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={submittingSuggestion || compressingScreenshot}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-[#E8B84A] to-[#4145C7] hover:brightness-105 disabled:opacity-50 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
              >
                <Lightbulb className="w-4 h-4" />
                <span>
                  {submittingSuggestion
                    ? 'جاري حفظ الاقتراح في Firebase...'
                    : 'إرسال الاقتراح لتطوير رِفْق'}
                </span>
              </button>
            </form>
          )}

          {/* ─── TAB 3: 📋 سجل البلاغات والاقتراحات الحقيقية من Firebase ─── */}
          {activeSupportTab === 'history' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  {(
                    [
                      { id: 'all', label: `الكل (${myReports.length})` },
                      {
                        id: 'bug',
                        label: `البلاغات (${
                          myReports.filter((r) => r.category !== 'suggestion').length
                        })`,
                      },
                      {
                        id: 'suggestion',
                        label: `الاقتراحات (${
                          myReports.filter((r) => r.category === 'suggestion').length
                        })`,
                      },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setHistoryFilter(tab.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer border transition-all ${
                        historyFilter === tab.id
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#77798C] border-[#E6E6F0]'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleManualRefreshReports}
                  disabled={loadingReports}
                  className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] text-xs font-bold text-[#4145C7] flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingReports ? 'animate-spin' : ''}`} />
                  <span>تحديث</span>
                </button>
              </div>

              {loadingReports ? (
                <div className="p-10 text-center space-y-2">
                  <RefreshCw className="w-6 h-6 text-[#5B5FEF] animate-spin mx-auto" />
                  <p className="text-xs font-bold text-[#77798C]">
                    جاري جلب سجل البلاغات والاقتراحات من Firebase...
                  </p>
                </div>
              ) : filteredHistory.length === 0 ? (
                /* Real Empty State — Zero Fake Data */
                <div className="p-8 sm:p-10 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] text-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-[#EEEEFF] text-[#5B5FEF] flex items-center justify-center mx-auto">
                    <FileText className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-black text-[#25263A]">
                    لا توجد بلاغات أو اقتراحات مسجلة حتى الآن
                  </h4>
                  <p className="text-xs text-[#77798C] max-w-sm mx-auto leading-relaxed">
                    عند إرسالك لأي بلاغ عن مشكلة أو اقتراح ميزة جديدة، سيظهر هنا فوراً مع رقمه المرجعي وحالته الحقيقية ورد الإدارة.
                  </p>
                  <div className="flex items-center justify-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setActiveSupportTab('bug')}
                      className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold cursor-pointer"
                    >
                      إرسال بلاغ جديد
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSupportTab('suggestion')}
                      className="px-4 py-2 rounded-xl bg-white border border-[#E6E6F0] text-[#25263A] text-xs font-bold cursor-pointer"
                    >
                      اقتراح ميزة
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredHistory.map((rep) => {
                    const isSuggestion = rep.category === 'suggestion';
                    return (
                      <div
                        key={rep.id}
                        className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] space-y-3 transition-all"
                      >
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                className={`px-2 py-0.5 rounded-md text-[10px] font-black border ${
                                  isSuggestion
                                    ? 'bg-amber-50 text-amber-800 border-amber-200'
                                    : 'bg-rose-50 text-rose-700 border-rose-200'
                                }`}
                              >
                                {isSuggestion ? '💡 اقتراح ميزة' : '🐛 بلاغ مشكلة'}
                              </span>
                              {rep.issueType && (
                                <span className="text-[11px] font-bold text-[#4145C7]">
                                  {rep.issueType}
                                </span>
                              )}
                            </div>
                            <h4 className="font-black text-sm text-[#25263A]">{rep.subject}</h4>
                          </div>

                          {renderStatusBadge(rep.status)}
                        </div>

                        <p className="text-xs text-[#25263A] leading-relaxed whitespace-pre-wrap bg-white p-3 rounded-xl border border-[#E6E6F0]/80">
                          {rep.description}
                        </p>

                        {/* Attached Screenshot if present */}
                        {rep.screenshotDataUrl && (
                          <div className="flex items-center gap-2.5">
                            <img
                              src={rep.screenshotDataUrl}
                              alt="مرفق البلاغ"
                              onClick={() => setEnlargedScreenshotUrl(rep.screenshotDataUrl || null)}
                              className="w-16 h-16 object-cover rounded-xl border border-[#E6E6F0] cursor-pointer hover:opacity-90"
                            />
                            <button
                              type="button"
                              onClick={() => setEnlargedScreenshotUrl(rep.screenshotDataUrl || null)}
                              className="text-[11px] font-bold text-[#5B5FEF] flex items-center gap-1 cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>عرض لقطة الشاشة المرفقة</span>
                            </button>
                          </div>
                        )}

                        {/* Metadata Footer: Real ID, userId, Timestamp */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#E6E6F0] text-[11px] text-[#77798C]">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[10px] bg-white px-2 py-0.5 rounded border border-[#E6E6F0]" dir="ltr">
                              ID: {rep.id}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleCopy(rep.id, `rep_${rep.id}`)}
                              className="text-[#4145C7] hover:underline text-[10px] font-bold cursor-pointer"
                            >
                              {copiedItem === `rep_${rep.id}` ? 'تم نسخ المعرف' : 'نسخ المعرف'}
                            </button>
                          </div>

                          <div className="flex items-center gap-2">
                            {rep.userId && (
                              <span className="text-[10px] text-emerald-700 font-bold">
                                مسجل بحسابك
                              </span>
                            )}
                            <span>
                              {rep.createdAt
                                ? new Date(rep.createdAt).toLocaleString('ar-SA')
                                : 'غير متاح'}
                            </span>
                          </div>
                        </div>

                        {/* Official Admin Reply if present */}
                        {rep.adminResponse && (
                          <div className="p-3.5 rounded-xl bg-white border-2 border-[#5B5FEF]/30 space-y-1.5">
                            <div className="text-xs font-black text-[#4145C7] flex items-center gap-1.5">
                              <MessageSquare className="w-4 h-4 text-[#5B5FEF]" />
                              <span>رد فريق دعم رِفْق الرسمي:</span>
                            </div>
                            <p className="text-xs text-[#25263A] leading-relaxed whitespace-pre-wrap">
                              {rep.adminResponse}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          📢 قنوات رِفْق الرسمية  |  🤖 بوت رِفْق  |  ✉️ البريد الإلكتروني
         ═══════════════════════════════════════════════════════════════════════ */}
      <div className="space-y-3">
        <h2 className="text-sm font-black text-[#4145C7] flex items-center gap-2 px-1">
          <span>قنوات رِفْق الرسمية والتواصل المباشر</span>
          <span className="h-px flex-1 bg-gradient-to-l from-transparent via-[#E8B84A]/30 to-transparent" />
        </h2>

        <div className="grid grid-cols-1 gap-3.5">
          {/* 1. 📢 قناة رِفْق الرسمية */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-sky-100 hover:border-[#2AABEE]/40 shadow-xs hover:shadow-sm transition-all">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#2AABEE] to-[#179cde] text-white flex items-center justify-center shadow-md shadow-sky-500/20 shrink-0">
                  <Send className="w-6 h-6 transform -rotate-12 translate-x-0.5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-black text-[#4145C7]">
                      قناة رفيق المسلم على تيليجرام
                    </h3>
                    <span className="px-2 py-0.5 rounded-full bg-sky-50 text-[#2AABEE] text-[10px] font-bold border border-sky-200">
                      قناة رِفْق الرسمية
                    </span>
                  </div>
                  <p className="text-xs text-[#77798C] mt-1">
                    تابع الأذكار، التحديثات الرسمية، الفوائد اليومية، والجديد في تطبيق رِفْق.
                  </p>
                  <p className="text-xs font-mono text-gray-400 mt-1" dir="ltr">
                    {telegramChannelUrl}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <a
                  href={telegramChannelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#2AABEE] to-[#179cde] hover:brightness-105 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span>فتح القناة</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <button
                  onClick={() => handleCopy(telegramChannelUrl, 'channel')}
                  title="نسخ الرابط"
                  className="px-3 py-2.5 rounded-xl bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-bold border border-[#E6E6F0] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedItem === 'channel' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
                      <span className="text-[#4CAF82]">تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#77798C]" />
                      <span>نسخ الرابط</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* 2. 🤖 بوت رِفْق */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-indigo-100 hover:border-indigo-300 shadow-xs hover:shadow-sm transition-all">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white flex items-center justify-center shadow-md shadow-indigo-500/20 shrink-0">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-black text-[#4145C7]">بوت رِفْق</h3>
                    <span className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-[10px] font-bold border border-indigo-200">
                      تيليجرام بوت
                    </span>
                  </div>
                  <p className="text-xs text-[#77798C] mt-1">
                    تواصل مع البوت للحصول على الأذكار، والآيات الكريمة، والتذكيرات المباشرة.
                  </p>
                  <p className="text-xs font-mono font-bold text-indigo-700 mt-1" dir="ltr">
                    {botUsername}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <a
                  href={telegramBotUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:brightness-105 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span>بدء البوت</span>
                  <MessageCircle className="w-3.5 h-3.5" />
                </a>

                <button
                  onClick={() => handleCopy(botUsername, 'bot')}
                  title="نسخ معرف البوت"
                  className="px-3 py-2.5 rounded-xl bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-bold border border-[#E6E6F0] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedItem === 'bot' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
                      <span className="text-[#4CAF82]">تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#77798C]" />
                      <span>نسخ</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* 3. ✉️ البريد الإلكتروني للمطور */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border border-[#E6E6F0] hover:border-[#5B5FEF]/40 shadow-xs hover:shadow-sm transition-all">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#E8B84A] to-[#4145C7] text-white flex items-center justify-center shadow-md shadow-[#E8B84A]/20 shrink-0">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base font-black text-[#4145C7]">
                      البريد الإلكتروني للمطور
                    </h3>
                    <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] text-[10px] font-bold border border-[#E6E6F0]">
                      مراسلة رسمية
                    </span>
                  </div>
                  <p className="text-xs text-[#77798C] mt-1">
                    للاقتراحات، الإبلاغ عن أي ملاحظات، أو الاستفسارات البرمجية المباشرة.
                  </p>
                  <p className="text-xs font-mono font-bold text-gray-700 mt-1" dir="ltr">
                    {developerEmail}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <a
                  href={`mailto:${developerEmail}`}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:brightness-105 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                >
                  <span>إرسال بريد</span>
                  <Mail className="w-3.5 h-3.5" />
                </a>

                <button
                  onClick={() => handleCopy(developerEmail, 'email')}
                  title="نسخ البريد الإلكتروني"
                  className="px-3 py-2.5 rounded-xl bg-gray-50 hover:bg-gray-100 text-gray-700 text-xs font-bold border border-[#E6E6F0] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedItem === 'email' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#4CAF82]" />
                      <span className="text-[#4CAF82]">تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#77798C]" />
                      <span>نسخ البريد</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Share and Duaa Card */}
      <div className="bg-gradient-to-br from-[#F7F7FC] to-amber-50/50 rounded-3xl p-5 border border-[#E6E6F0] text-center space-y-3">
        <div className="w-10 h-10 mx-auto rounded-full bg-[#4145C7]/10 text-[#4145C7] flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-[#4145C7]" />
        </div>
        <h4 className="text-sm font-black text-[#4145C7]">«الدَّالُّ عَلَى الخَيْرِ كَفَاعِلِهِ»</h4>
        <p className="text-xs text-[#77798C] max-w-md mx-auto leading-relaxed">
          شارك تطبيق «رِفْق | RIFQ» مع أهلك وأصحابك ليكون لك أجر كل تسبيحة وذكر وقراءة قرآن إلى يوم القيامة.
        </p>
        <button
          onClick={handleShareApp}
          className="px-5 py-2.5 rounded-xl bg-[#4145C7] hover:bg-[#4145C7]/90 text-white text-xs font-bold inline-flex items-center gap-2 shadow-md transition-all cursor-pointer"
        >
          <Share2 className="w-4 h-4" />
          <span>مشاركة تطبيق رِفْق ولك الأجر</span>
        </button>
      </div>

      {/* Bottom Intellectual & Copyright Badge */}
      <div className="text-center text-xs text-gray-400 space-y-1">
        <p className="font-bold text-[#77798C]">
          تطبيق رِفْق | RIFQ • برمجة وتطوير {developerName}
        </p>
        <p className="text-[11px] text-gray-400">
          جميع الحقوق محفوظة © 2026 • صدقة جارية خالصة لوجه الله
        </p>
      </div>

      {/* Lightbox Modal for Viewing Attached Screenshot */}
      {enlargedScreenshotUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setEnlargedScreenshotUrl(null)}
        >
          <div
            className="relative max-w-lg w-full bg-white rounded-3xl p-3 shadow-2xl border border-[#E6E6F0]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 px-1">
              <span className="text-xs font-black text-[#25263A]">معاينة لقطة الشاشة المرفقة</span>
              <button
                type="button"
                onClick={() => setEnlargedScreenshotUrl(null)}
                className="w-8 h-8 rounded-full bg-[#F7F7FC] flex items-center justify-center text-[#77798C] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <img
              src={enlargedScreenshotUrl}
              alt="لقطة الشاشة المرفقة"
              className="w-full max-h-[75vh] object-contain rounded-2xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
