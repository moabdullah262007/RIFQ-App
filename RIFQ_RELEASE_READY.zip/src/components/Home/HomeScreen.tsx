import React, { useState, useMemo, useCallback } from 'react';
import { ScreenType, WardType, CompanionCategoryId } from '../../types';
import { HeroCard } from './HeroCard';
import { HOME_SECTIONS, SectionCard, SectionItem, HomeSectionGroup } from './SectionsGrid';
import { DailyDuaCard } from './DailyDuaCard';
import { MomentDhikrCard } from './MomentDhikrCard';
import { GreetingTimeIcon, TasbeehSectionSvg } from './RifqSectionIcons';
import { getHijriDate } from '../../utils/prayerCalculator';

export { SectionCard as HomeSectionCard };

/**
 * قائمة أقسام شبكة الصفحة الرئيسية (HomeScreen)
 */
export const HOME_SCREEN_MENU_SECTIONS: SectionItem[] = HOME_SECTIONS;

const CATEGORY_TABS: { id: HomeSectionGroup; label: string }[] = [
  { id: 'all', label: 'الكل' },
  { id: 'quran_sunnah', label: 'القرآن والسنة' },
  { id: 'athkar_tasbeeh', label: 'الأذكار والتسبيح' },
  { id: 'fiqh_worship', label: 'الفقه والعبادات' },
  { id: 'tools_profile', label: 'الإحصائيات والحساب' },
];

interface HomeScreenProps {
  onNavigate: (screen: ScreenType) => void;
  onSelectWard: (wardType: WardType) => void;
  onOpenNotifications?: () => void;
  onOpenSidebar?: () => void;
  unreadCount?: number;
  onOpenMomentDhikr?: (dhikrId?: string) => void;
  onOpenCompanion?: (companionId?: string | null, category?: CompanionCategoryId | 'all' | 'favorites') => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  onSelectWard,
  onOpenMomentDhikr,
  onOpenCompanion,
}) => {
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedGroup, setSelectedGroup] = useState<HomeSectionGroup>('all');

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2500);
  }, []);

  // Dynamic Greeting based on time of day
  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour >= 4 && hour < 12) {
      return { text: 'صباح الخير', period: 'morning' as const };
    } else if (hour >= 12 && hour < 17) {
      return { text: 'طاب يومك', period: 'noon' as const };
    } else if (hour >= 17 && hour < 21) {
      return { text: 'مساء الخير', period: 'evening' as const };
    } else {
      return { text: 'طاب مساؤك', period: 'night' as const };
    }
  }, []);

  // Formatted date string
  const dateFormatted = useMemo(() => {
    const now = new Date();
    const gregorian = now.toLocaleDateString('ar-EG', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
    });
    const hijri = getHijriDate(now);
    return {
      gregorian,
      hijri: hijri.formatted,
    };
  }, []);

  const handleSectionNavigate = useCallback(
    (screen: ScreenType) => {
      if (screen === 'companions_stories' && onOpenCompanion) {
        onOpenCompanion(null, 'all');
      } else {
        onNavigate(screen);
      }
    },
    [onNavigate, onOpenCompanion]
  );

  const visibleSections = useMemo(() => {
    if (selectedGroup === 'all') return HOME_SCREEN_MENU_SECTIONS;
    return HOME_SCREEN_MENU_SECTIONS.filter((item) => item.group === selectedGroup);
  }, [selectedGroup]);

  return (
    <div className="w-full space-y-6 animate-fade-in pb-8 select-none" dir="rtl">
      {/* Toast popup in bottom of screen */}
      {toastMessage && (
        <div className="fixed bottom-22 sm:bottom-20 right-1/2 translate-x-1/2 z-50 bg-[#25263A] text-white px-5 py-2.5 rounded-full text-xs font-black shadow-xl border border-[#5B5FEF]/40 flex items-center gap-2.5 animate-fade-in pointer-events-none whitespace-nowrap">
          <TasbeehSectionSvg size={18} />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ── 【1】قسم الترحيب والتاريخ ── */}
      <div className="px-1">
        <h2 className="text-xl sm:text-2xl font-black text-[#25263A] font-cairo flex items-center gap-2.5">
          <span className="w-9 h-9 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shadow-2xs shrink-0">
            <GreetingTimeIcon period={greeting.period} size={22} />
          </span>
          <span>{greeting.text}</span>
        </h2>

        <div className="flex items-center gap-2 text-xs text-[#77798C] font-cairo font-semibold mt-1.5 flex-wrap px-1">
          <span>{dateFormatted.gregorian}</span>
          <span className="text-[#5B5FEF] font-bold">·</span>
          <span className="text-[#4145C7] font-bold">{dateFormatted.hijri}</span>
        </div>
      </div>

      {/* ── 【2】بطاقة بارزة: ذكر ونصيحة اليوم (HeroCard) ── */}
      <HeroCard
        onNavigate={onNavigate}
        onSelectWard={onSelectWard}
        onShowToast={showToast}
      />

      {/* ── 【3】شبكة الأقسام الرئيسية (Main Sections Grid) ── */}
      <section aria-label="أقسام رِفْـق">
        <div className="flex items-center justify-between mb-3 px-1">
          <div className="flex items-center gap-2.5">
            <span className="w-1.5 h-6 rounded-full bg-[#5B5FEF] inline-block" />
            <h3 className="text-[20px] font-black text-[#25263A] font-cairo tracking-tight">
              أقسام رِفْـق
            </h3>
          </div>
          <span className="text-xs font-cairo font-bold text-[#77798C]">
            {visibleSections.length} قسماً مباركاً
          </span>
        </div>

        {/* شريط تصنيفات الأقسام المنظم */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2.5 mb-2 no-scrollbar">
          {CATEGORY_TABS.map((tab) => {
            const isSelected = selectedGroup === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSelectedGroup(tab.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-cairo font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#5B5FEF] text-white shadow-xs'
                    : 'bg-[#EEEEFF] text-[#4145C7] hover:bg-[#E2E2FF]'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        <div
          className="grid grid-cols-4 md:grid-cols-6 gap-[10px]"
          role="navigation"
          aria-label="أقسام رِفْـق"
        >
          {visibleSections.map((item) => (
            <SectionCard
              key={item.id}
              item={item}
              onNavigate={handleSectionNavigate}
            />
          ))}
        </div>
      </section>

      {/* ── 【4】بطاقة «ذكر اللحظة» الموقوتة ── */}
      {onOpenMomentDhikr && (
        <MomentDhikrCard onOpenMomentDhikr={onOpenMomentDhikr} />
      )}

      {/* ── 【5】بطاقة «دعاء اليوم» ── */}
      <div>
        <DailyDuaCard onShowToast={showToast} onNavigate={onNavigate} />
      </div>
    </div>
  );
};
