import React, { useId } from 'react';
import { ScreenType, WardType } from '../../types';
import { useSafeTheme } from '../../context/ThemeContext';

export interface SectionIconProps {
  size?: number;
  className?: string;
}

/**
 * خريطة مسارات الأيقونات المتوافقة مع جميع المكونات
 */
export const RIFQ_PNG_ICONS: Record<string, string> = {
  tasbeeh: 'assets/icons/menu/ic_misbaha.png',
  prayers: 'assets/icons/menu/ic_mosque.png',
  quran: 'assets/icons/menu/ic_quran.png',
  quran_audio: 'assets/icons/menu/ic_quran_audio.png',
  wird: 'assets/icons/menu/ic_wird.png',
  ward: 'assets/icons/menu/ic_wird.png',
  gharib_quran: 'assets/icons/menu/ic_gharib.png',
  tajweed: 'assets/icons/menu/ic_tajweed.png',
  tadabbur: 'assets/icons/menu/ic_tadabbur.png',
  hadith: 'assets/icons/menu/ic_hadith.png',
  arbain_nawawiya: 'assets/icons/menu/ic_arbain_nawawiya.png',
  zakat_mawarith: 'assets/icons/menu/ic_zakat.png',
  hijri_fasting: 'assets/icons/menu/ic_hijri.png',
  hajj_umrah: 'assets/icons/menu/ic_hajj.png',
  ruqyah_medicine: 'assets/icons/menu/ic_ruqyah.png',
  companions_stories: 'assets/icons/menu/ic_companions.png',
  prophetic_biography: 'assets/icons/menu/ic_seerah.svg',
  wasaya: 'assets/icons/menu/ic_wasaya.png',
  kids_stories: 'assets/icons/menu/ic_kids_stories.png',
  fiqh_muyassar: 'assets/icons/menu/ic_fiqh_muyassar.png',
  athkar: 'assets/icons/menu/ic_azkar.png',
  hisn_almuslim: 'assets/icons/menu/ic_azkar.png',
  moment_dhikr: 'assets/icons/menu/ic_azkar.png',
  graduation: 'assets/icons/menu/ic_graduation.png',
  wudu_prayer: 'assets/icons/menu/ic_wudu.png',
  athar_tayyib: 'assets/icons/menu/ic_athar_tayyib.png',
  amana: 'assets/icons/menu/ic_amana.png',
  harvest: 'assets/icons/menu/ic_trophy.png',
  journey: 'assets/icons/menu/ic_palm_tree.png',
  daily_reminders: 'assets/icons/menu/ic_morning.png',
  muslim_woman: 'assets/icons/menu/ic_woman_flower.png',
  stats: 'assets/icons/menu/ic_statistics.png',
  profile: 'assets/icons/menu/ic_user.png',
  asmaa_allah: 'assets/icons/menu/ic_allah_names.png',
  settings: 'assets/icons/menu/ic_settings.png',
  credits: 'assets/icons/menu/ic_contact.png',
  home: 'assets/icons/menu/ic_home.png',
};

export interface SectionAccentMeta {
  primary: string;
  accent: string;
  softBg: string;
  borderTint: string;
}

/**
 * تحديد الهوية اللونية الفرعية لكل قسم:
 * - الأساسي دائماً: #5B5FEF
 * - اللمسة الثانوية (Accent): ذهبي #E8B84A | أزرق #72B7E8 | وردي #E99AC7
 */
export function getSectionAccentMeta(screenId: string, activeThemeId?: string): SectionAccentMeta {
  const resolvedThemeId =
    activeThemeId ||
    (typeof document !== 'undefined'
      ? document.documentElement.getAttribute('data-rifq-theme') || 'default'
      : 'default');

  if (resolvedThemeId === 'gold') {
    const primary = '#9C7627';
    switch (screenId) {
      case 'quran':
      case 'quran_audio':
      case 'gharib_quran':
      case 'tajweed':
      case 'tadabbur':
      case 'hadith':
      case 'arbain_nawawiya':
      case 'wasaya':
      case 'kids_stories':
      case 'companions_stories':
      case 'prophetic_biography':
      case 'our_history':
      case 'hajj_umrah':
      case 'zakat_mawarith':
        return {
          primary,
          accent: '#D4AF37', // Radiant Gold
          softBg: '#FAF7F0',
          borderTint: '#E8DEC8',
        };

      case 'athkar':
      case 'hisn_almuslim':
      case 'moment_dhikr':
      case 'wird':
      case 'ward':
      case 'daily_reminders':
      case 'prayers':
      case 'wudu_prayer':
      case 'athar_tayyib':
      case 'amana':
      case 'fiqh_muyassar':
      case 'hijri_fasting':
      case 'ruqyah_medicine':
      case 'asmaa_allah':
      case 'dua_corner':
        return {
          primary,
          accent: '#C5A059', // Champagne Gold
          softBg: '#FAF7F0',
          borderTint: '#E8DEC8',
        };

      case 'tasbeeh':
      case 'muslim_woman':
      case 'harvest':
      case 'journey':
      default:
        return {
          primary,
          accent: '#7D65A0', // Subtle Royal Violet touch with Gold
          softBg: '#FAF7F0',
          borderTint: '#E8DEC8',
        };
    }
  }

  if (resolvedThemeId === 'girly') {
    const primary = '#D98FA8';
    switch (screenId) {
      case 'quran':
      case 'quran_audio':
      case 'gharib_quran':
      case 'tajweed':
      case 'tadabbur':
      case 'hadith':
      case 'arbain_nawawiya':
      case 'wasaya':
      case 'kids_stories':
      case 'companions_stories':
      case 'prophetic_biography':
      case 'our_history':
      case 'hajj_umrah':
      case 'zakat_mawarith':
        return {
          primary,
          accent: '#CFA06A', // Rose Gold
          softBg: '#FFF8FA',
          borderTint: '#F2DCE4',
        };

      case 'athkar':
      case 'hisn_almuslim':
      case 'moment_dhikr':
      case 'wird':
      case 'ward':
      case 'daily_reminders':
      case 'prayers':
      case 'wudu_prayer':
      case 'athar_tayyib':
      case 'amana':
      case 'fiqh_muyassar':
      case 'hijri_fasting':
      case 'ruqyah_medicine':
      case 'asmaa_allah':
      case 'dua_corner':
        return {
          primary,
          accent: '#B98CC8', // Soft Lavender
          softBg: '#FFF8FA',
          borderTint: '#F2DCE4',
        };

      case 'tasbeeh':
      case 'muslim_woman':
      case 'harvest':
      case 'journey':
      default:
        return {
          primary,
          accent: '#D98FA8', // Soft Rose
          softBg: '#FFF8FA',
          borderTint: '#F2DCE4',
        };
    }
  }

  const primary = '#5B5FEF';
  switch (screenId) {
    case 'quran':
    case 'quran_audio':
    case 'gharib_quran':
    case 'tajweed':
    case 'tadabbur':
    case 'hadith':
    case 'arbain_nawawiya':
    case 'wasaya':
    case 'kids_stories':
    case 'companions_stories':
    case 'prophetic_biography':
    case 'our_history':
    case 'hajj_umrah':
    case 'zakat_mawarith':
      return {
        primary,
        accent: '#E8B84A',
        softBg: '#F7F7FC',
        borderTint: '#E6E6F0',
      };

    case 'athkar':
    case 'hisn_almuslim':
    case 'moment_dhikr':
    case 'wird':
    case 'ward':
    case 'daily_reminders':
    case 'prayers':
    case 'wudu_prayer':
    case 'athar_tayyib':
    case 'amana':
    case 'fiqh_muyassar':
    case 'hijri_fasting':
    case 'ruqyah_medicine':
    case 'asmaa_allah':
    case 'dua_corner':
      return {
        primary,
        accent: '#72B7E8',
        softBg: '#F7F7FC',
        borderTint: '#E6E6F0',
      };

    case 'tasbeeh':
    case 'muslim_woman':
    case 'harvest':
    case 'journey':
      return {
        primary,
        accent: '#E8B84A',
        softBg: '#F7F7FC',
        borderTint: '#E6E6F0',
      };

    default:
      return {
        primary,
        accent: '#72B7E8',
        softBg: '#F7F7FC',
        borderTint: '#E6E6F0',
      };
  }
}

/**
 * الإطار الموحد لجميع أيقونات رِفْق (Unified Rifq Icon Medallion):
 * - خلفية دائرية فاتحة جداً ومريحة للعين (#FFFEFA -> #F3F2FC)
 * - إطار دائري ناعم بلون ذهبي هادئ (#DEB253 / #E6BD64)
 * - تدرجات بنفسجية/زرقاء (#5B5FEF -> #4145C7) ولمسات ذهبية (#F4C44E -> #E09F32)
 * - في الثيم البناتي (girly): يتكيف تلقائياً مع درجات Rose, Lavender, Rose Gold, Cream
 * - نفس الحجم (viewBox 0 0 64 64) ونفس الـ padding ونفس الـ visual weight
 */
export interface MedallionIconIds {
  purple: string;
  purpleSoft: string;
  purpleDark: string;
  gold: string;
  goldSoft: string;
  green: string;
  blue: string;
  skin: string;
  // Reactive theme color tokens for inner SVG strokes/fills
  isGirly: boolean;
  lavenderStroke: string;
  lavenderFill: string;
  lavenderSoftBg: string;
  lavenderBorder: string;
  roseGoldTone: string;
  roseGoldLight: string;
  beadHighlight: string;
  sparkleTone: string;
  inkDark: string;
  rehalStroke: string;
  scrollRoll: string;
  scrollPaper: string;
  scrollBorder: string;
  scrollBottom: string;
  lensTint: string;
}

const RifqMedallionBase: React.FC<{
  size: number;
  className?: string;
  label: string;
  children: (ids: MedallionIconIds) => React.ReactNode;
}> = ({ size, className = '', label, children }) => {
  const { themeId, isDark, isGirly } = useSafeTheme();
  const rawId = useId().replace(/:/g, '');
  // Scope gradient IDs with active themeId & mode so SVG url(#...) paint servers repaint immediately on theme switch
  const scope = `${rawId}_${themeId}_${isDark ? 'd' : 'l'}`;

  const ids: MedallionIconIds = {
    purple: `rifq_p_${scope}`,
    purpleSoft: `rifq_ps_${scope}`,
    purpleDark: `rifq_pd_${scope}`,
    gold: `rifq_g_${scope}`,
    goldSoft: `rifq_gs_${scope}`,
    green: `rifq_gr_${scope}`,
    blue: `rifq_bl_${scope}`,
    skin: `rifq_sk_${scope}`,
    isGirly,
    lavenderStroke: isGirly ? '#B98CC8' : '#9FA4FF',
    lavenderFill: isGirly ? '#C896D4' : '#7E84F7',
    lavenderSoftBg: isGirly ? '#F6ECF9' : '#EAEBFF',
    lavenderBorder: isGirly ? '#DFC5EB' : '#C5C8FF',
    roseGoldTone: isGirly ? '#CFA06A' : '#E8B84A',
    roseGoldLight: isGirly ? '#FFF4E6' : '#FFF3C4',
    beadHighlight: isGirly ? '#F9E6F0' : '#D9DCFF',
    sparkleTone: isGirly ? '#CFA06A' : '#9FA4FF',
    inkDark: isGirly ? '#593347' : '#25286B',
    rehalStroke: isGirly ? '#CFA06A' : '#D4883A',
    scrollRoll: isGirly ? '#D5AEDF' : '#B2B5F2',
    scrollPaper: isGirly ? '#FFF8FC' : '#F2F2FF',
    scrollBorder: isGirly ? '#E6CCE9' : '#C8CAFA',
    scrollBottom: isGirly ? '#F3E3F7' : '#D8DAFF',
    lensTint: isGirly ? '#F5E6FA' : '#DCE6FF',
  };

  const bgId = `rifq_bg_${scope}`;
  const ringId = `rifq_ring_${scope}`;

  return (
    <svg
      key={`${themeId}-${isDark ? 'dark' : 'light'}`}
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      className={`select-none shrink-0 ${className}`}
      aria-label={label}
      data-rifq-icon-theme={themeId}
      role="img"
    >
      <defs>
        <radialGradient id={bgId} cx="35%" cy="28%" r="72%">
          <stop offset="0%" stopColor={isGirly ? '#FFFDFB' : '#FFFEFA'} />
          <stop offset="65%" stopColor={isGirly ? '#FFF7FA' : '#F8F7FD'} />
          <stop offset="100%" stopColor={isGirly ? '#F9EBF4' : '#EFEFF9'} />
        </radialGradient>
        <linearGradient id={ringId} x1="10" y1="8" x2="54" y2="56" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#F0CFA3' : '#F0CB75'} />
          <stop offset="50%" stopColor={isGirly ? '#CFA06A' : '#D7A444'} />
          <stop offset="100%" stopColor={isGirly ? '#B98CC8' : '#E6BC63'} />
        </linearGradient>
        <linearGradient id={ids.purple} x1="16" y1="14" x2="48" y2="50" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#E6A1B8' : '#7C80FF'} />
          <stop offset="52%" stopColor={isGirly ? '#D98FA8' : '#5B5FEF'} />
          <stop offset="100%" stopColor={isGirly ? '#B98CC8' : '#4145C7'} />
        </linearGradient>
        <linearGradient id={ids.purpleSoft} x1="18" y1="16" x2="46" y2="48" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#F2BDD0' : '#A5A8FF'} />
          <stop offset="100%" stopColor={isGirly ? '#B98CC8' : '#6C70F5'} />
        </linearGradient>
        <linearGradient id={ids.purpleDark} x1="18" y1="18" x2="46" y2="50" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#B56582' : '#474BC9'} />
          <stop offset="100%" stopColor={isGirly ? '#7D4663' : '#2B2E85'} />
        </linearGradient>
        <linearGradient id={ids.gold} x1="20" y1="14" x2="46" y2="48" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#F5D8B5' : '#FFE17D'} />
          <stop offset="55%" stopColor={isGirly ? '#CFA06A' : '#F4C047'} />
          <stop offset="100%" stopColor={isGirly ? '#B5834E' : '#DC9B2B'} />
        </linearGradient>
        <linearGradient id={ids.goldSoft} x1="18" y1="16" x2="46" y2="48" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#FFF6ED' : '#FFF6D6'} />
          <stop offset="100%" stopColor={isGirly ? '#E6C296' : '#F5D076'} />
        </linearGradient>
        <linearGradient id={ids.green} x1="20" y1="16" x2="44" y2="46" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#7EC8A5' : '#68D391'} />
          <stop offset="100%" stopColor={isGirly ? '#4B9673' : '#2F855A'} />
        </linearGradient>
        <linearGradient id={ids.blue} x1="20" y1="16" x2="44" y2="46" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor={isGirly ? '#E3C7EE' : '#8CC5FF'} />
          <stop offset="100%" stopColor={isGirly ? '#B98CC8' : '#4A7BE8'} />
        </linearGradient>
        <linearGradient id={ids.skin} x1="20" y1="18" x2="44" y2="46" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FCD8C0" />
          <stop offset="100%" stopColor="#EAA887" />
        </linearGradient>
      </defs>

      {/* الخلفية الدائرية الموحدة والإطار الذهبي الهادئ */}
      <circle
        cx="32"
        cy="32"
        r="29.2"
        fill={`url(#${bgId})`}
        stroke={`url(#${ringId})`}
        strokeWidth="1.6"
      />
      <circle
        cx="32"
        cy="32"
        r="27.2"
        fill="none"
        stroke="#FFFFFF"
        strokeWidth="0.9"
        strokeOpacity="0.9"
      />

      {children(ids)}
    </svg>
  );
};

/** 1. المسبحة — حلقة سبحة بنفسجية ثلاثية الأبعاد مع الشرابة واللمسات المضيئة */
export const TasbeehSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => {
  const beads = Array.from({ length: 12 }, (_, i) => {
    const angle = (i * Math.PI * 2) / 12 - Math.PI / 2;
    return {
      cx: 32 + Math.cos(angle) * 11.2,
      cy: 26.8 + Math.sin(angle) * 11.2,
    };
  });

  return (
    <RifqMedallionBase size={size} className={className} label="المسبحة">
      {(ids) => (
        <>
          <circle cx="32" cy="26.8" r="11.2" stroke={ids.lavenderStroke} strokeWidth="1.1" strokeDasharray="2 2" />
          {beads.map((b, idx) => (
            <g key={idx}>
              <circle cx={b.cx} cy={b.cy} r="2.8" fill={`url(#${ids.purple})`} />
              <circle cx={b.cx - 0.8} cy={b.cy - 0.8} r="0.85" fill={ids.beadHighlight} fillOpacity="0.85" />
            </g>
          ))}
          {/* خرزة الشاهد والشرابة السفلية */}
          <circle cx="32" cy="40.2" r="2.2" fill={`url(#${ids.purpleDark})`} />
          <rect x="30.2" y="42" width="3.6" height="1.8" rx="0.8" fill={`url(#${ids.gold})`} />
          <path d="M30.5 43.8L28.6 50.2H35.4L33.5 43.8H30.5Z" fill={`url(#${ids.purple})`} />
          <path d="M30.2 50.2H33.8" stroke={`url(#${ids.gold})`} strokeWidth="1.2" strokeLinecap="round" />
          {/* نجوم لمعان هادئة */}
          <path d="M18 35.5L18.8 37.2L20.5 38L18.8 38.8L18 40.5L17.2 38.8L15.5 38L17.2 37.2L18 35.5Z" fill={ids.sparkleTone} />
          <path d="M46 36.5L46.7 38L48.2 38.7L46.7 39.4L46 40.9L45.3 39.4L43.8 38.7L45.3 38L46 36.5Z" fill={ids.lavenderStroke} />
        </>
      )}
    </RifqMedallionBase>
  );
};

/** 2. المواقيت — مسجد بنفسجي بقبة وهلال ذهبي ومئذنة رشيقة */
export const PrayersSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="المواقيت">
    {(ids) => (
      <>
        {/* الهلال الذهبي أعلى القبة */}
        <path
          d="M30.5 14.5A3.2 3.2 0 1 1 26.8 18.8A2.5 2.5 0 1 0 30.5 14.5Z"
          fill={`url(#${ids.gold})`}
        />
        <path d="M28.5 19.2V22" stroke={`url(#${ids.gold})`} strokeWidth="1.4" strokeLinecap="round" />

        {/* المئذنة اليمنى */}
        <rect x="41.5" y="23.5" width="4.5" height="22.5" rx="1" fill={`url(#${ids.purpleSoft})`} />
        <path d="M41 23.5C41 21 42.2 19.2 43.75 18.2C45.3 19.2 46.5 21 46.5 23.5H41Z" fill={`url(#${ids.purple})`} />
        <rect x="40.5" y="27" width="6.5" height="1.6" rx="0.8" fill={`url(#${ids.gold})`} />
        <rect x="43" y="30.5" width="1.5" height="3.5" rx="0.75" fill={ids.inkDark} />

        {/* القبة الرئيسية */}
        <path
          d="M17.5 34.5C17.5 27.5 22.4 22.2 28.5 21.5C34.6 22.2 39.5 27.5 39.5 34.5H17.5Z"
          fill={`url(#${ids.purple})`}
        />
        {/* جسم المسجد السفلي */}
        <rect x="16" y="34.5" width="31" height="12" rx="2" fill={ids.scrollBottom} />
        <rect x="16" y="34.5" width="24.5" height="12" rx="2" fill={`url(#${ids.purpleSoft})`} />
        {/* بوابة المسجد والنوافذ */}
        <path d="M25 46.5V39.8C25 37.9 26.6 36.5 28.5 36.5C30.4 36.5 32 37.9 32 39.8V46.5H25Z" fill={`url(#${ids.purpleDark})`} />
        <rect x="19.5" y="38.5" width="2.6" height="4.2" rx="1.3" fill="#FFFFFF" fillOpacity="0.8" />
        <rect x="35" y="38.5" width="2.6" height="4.2" rx="1.3" fill="#FFFFFF" fillOpacity="0.8" />
        <path d="M14 46.5H50" stroke={`url(#${ids.purpleDark})`} strokeWidth="1.6" strokeLinecap="round" />
      </>
    )}
  </RifqMedallionBase>
);

/** 3. القرآن — مصحف مفتوح على حامل خشبي ذهبي (رحل) */
export const QuranSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="القرآن">
    {(ids) => (
      <>
        {/* الحامل الخشبي / الذهبي (الرحل) */}
        <path
          d="M19 46.5L32 36.5L45 46.5M23 36L41 46.5M41 36L23 46.5"
          stroke={ids.rehalStroke}
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* الغلاف البنفسجي للمصحف المفتوح */}
        <path
          d="M13.5 29.5L32 36.5L50.5 29.5L48 22L32 28.5L16 22L13.5 29.5Z"
          fill={`url(#${ids.purple})`}
        />
        {/* الصفحات البيضاء المشرقة */}
        <path
          d="M15.5 27.5C20.5 26.5 26.5 28 32 32.5V23.5C26.5 19.5 20.5 19 16.5 20.5L15.5 27.5Z"
          fill="#FFFFFF"
          stroke={ids.lavenderBorder}
          strokeWidth="1"
          strokeLinejoin="round"
        />
        <path
          d="M48.5 27.5C43.5 26.5 37.5 28 32 32.5V23.5C37.5 19.5 43.5 19 47.5 20.5L48.5 27.5Z"
          fill={ids.scrollPaper}
          stroke={ids.lavenderBorder}
          strokeWidth="1"
          strokeLinejoin="round"
        />
        {/* سطور الآيات */}
        <path
          d="M19.5 23.2L28.5 26.2M19 25.8L28 28.8M44.5 23.2L35.5 26.2M45 25.8L36 28.8"
          stroke={ids.lavenderStroke}
          strokeWidth="1.3"
          strokeLinecap="round"
        />
      </>
    )}
  </RifqMedallionBase>
);

/** 4. القرآن — استماع — سماعات رأس بنفسجية تحيط بالمصحف الشريف */
export const QuranAudioSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="القرآن — استماع">
    {(ids) => (
      <>
        {/* قوس السماعة */}
        <path
          d="M16.5 34V29C16.5 20.4 23.4 14 32 14C40.6 14 47.5 20.4 47.5 29V34"
          stroke={`url(#${ids.purple})`}
          strokeWidth="3.2"
          strokeLinecap="round"
        />
        {/* وسائد الأذن */}
        <rect x="13.5" y="29" width="5.5" height="11" rx="2.75" fill={`url(#${ids.purpleDark})`} />
        <rect x="45" y="29" width="5.5" height="11" rx="2.75" fill={`url(#${ids.purpleDark})`} />

        {/* المصحف في المنتصف */}
        <rect x="23" y="25" width="18" height="21" rx="2.5" fill={`url(#${ids.purple})`} />
        <path d="M25.5 43.5H39.5V45.5H25.5C24.7 45.5 24 44.9 24 44.2C24 43.8 24.7 43.5 25.5 43.5Z" fill="#FFFFFF" />
        {/* نجمة الربع حزب الذهبية وسط المصحف */}
        <rect x="29" y="31" width="6" height="6" rx="0.8" fill={`url(#${ids.gold})`} />
        <rect x="29" y="31" width="6" height="6" rx="0.8" transform="rotate(45 32 34)" fill={`url(#${ids.gold})`} />
        <circle cx="32" cy="34" r="1.5" fill={`url(#${ids.purpleDark})`} />
        {/* شريط العلامة المرجعية */}
        <path d="M30.5 45V49.5L32 48.2L33.5 49.5V45" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 5. وِرد | WIRD — مصحف/كتاب الورد البنفسجي بنجمة ذهبية وشريط علامة */
export const WirdSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="وِرد | WIRD">
    {(ids) => (
      <>
        <rect x="18" y="15" width="27" height="32" rx="3.5" fill={`url(#${ids.purple})`} />
        <path d="M18 18.5C18 16.6 19.6 15 21.5 15H22.5V47H21.5C19.6 47 18 45.4 18 43.5V18.5Z" fill={`url(#${ids.purpleDark})`} />
        {/* أطراف الصفحات السفلية */}
        <rect x="20.5" y="41.5" width="23.5" height="4" rx="1.8" fill="#FFFFFF" />
        {/* نجمة ثمانية ذهبية في الوسط */}
        <rect x="28" y="24" width="9" height="9" rx="1" fill={`url(#${ids.gold})`} />
        <rect x="28" y="24" width="9" height="9" rx="1" transform="rotate(45 32.5 28.5)" fill={`url(#${ids.gold})`} />
        <circle cx="32.5" cy="28.5" r="2.5" fill={`url(#${ids.purple})`} />
        {/* شريط العلامة البرتقالي/الذهبي */}
        <path d="M29.5 43.5V50.5L32 48.8L34.5 50.5V43.5H29.5Z" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 6. الأربعون النووية — كتاب بنفسجي بشارة 40 الذهبية البارزة */
export const ArbainNawawiyaSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الأربعون النووية">
    {(ids) => (
      <>
        <rect x="18" y="15" width="27" height="32" rx="3.5" fill={`url(#${ids.purple})`} />
        <path d="M18 18.5C18 16.6 19.6 15 21.5 15H22.5V47H21.5C19.6 47 18 45.4 18 43.5V18.5Z" fill={`url(#${ids.purpleDark})`} />
        <rect x="20.5" y="42" width="23.5" height="3.8" rx="1.8" fill="#FFFFFF" />
        {/* إطار زخرفي ذهبي وميدالية الرقم 40 */}
        <circle cx="32.8" cy="28.5" r="8.2" fill={`url(#${ids.gold})`} stroke={ids.roseGoldLight} strokeWidth="1" />
        <text
          x="32.8"
          y="32.2"
          textAnchor="middle"
          fill={ids.inkDark}
          fontSize="10.5"
          fontWeight="900"
          fontFamily="Cairo, sans-serif"
        >
          40
        </text>
      </>
    )}
  </RifqMedallionBase>
);

/** 7. وصايا الرسول ﷺ — مخطوطة كريمة مع ريشة كتابة بنفسجية وسطور ذهبية */
export const WasayaSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="وصايا الرسول ﷺ">
    {(ids) => (
      <>
        {/* أسطوانة المخطوطة العلوية */}
        <rect x="15.5" y="17" width="24" height="4.5" rx="2.2" fill={ids.scrollRoll} />
        <circle cx="17.5" cy="19.25" r="2.2" fill={`url(#${ids.purpleDark})`} />
        {/* جسم الرقعة/المخطوطة */}
        <rect x="18" y="19" width="21" height="26" rx="2" fill={ids.scrollPaper} stroke={ids.scrollBorder} strokeWidth="1" />
        {/* أسطوانة المخطوطة السفلية */}
        <rect x="16.5" y="42.5" width="25" height="5" rx="2.5" fill={ids.scrollBottom} stroke={ids.scrollRoll} strokeWidth="1" />
        <circle cx="20" cy="45" r="2.2" fill={`url(#${ids.purple})`} />
        {/* سطور الوصية الذهبية */}
        <path
          d="M22.5 25H34.5M22.5 29.5H34.5M22.5 34H32M22.5 38.5H29.5"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.9"
          strokeLinecap="round"
        />
        {/* ريشة القلم البنفسجية */}
        <path
          d="M47.5 20.5C41.5 21 36.5 25.8 35 33.5L32.5 41.5L38.5 37.5C44.2 35.2 48 28.5 47.5 20.5Z"
          fill={`url(#${ids.purple})`}
        />
        <path d="M32 42L42.5 26.5" stroke={ids.roseGoldLight} strokeWidth="1.2" strokeLinecap="round" />
      </>
    )}
  </RifqMedallionBase>
);

/** 8. قصص الصحابة — قارئان مع كتاب السيرة البنفسجي المفتوح كما في الصورة المرجعية */
export const CompanionsStoriesSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="قصص الصحابة">
    {(ids) => (
      <>
        {/* القارئ الأيسر */}
        <circle cx="24" cy="25.5" r="6" fill={`url(#${ids.skin})`} />
        <path d="M18 24.5C18 20.5 20.8 18.2 24.5 18.2C27.8 18.2 30 20.2 30 23.5C27.5 22 25 21.8 22 22.8C20 23.4 18.8 24.2 18 24.5Z" fill={ids.inkDark} />
        <circle cx="22.3" cy="25.8" r="0.8" fill={ids.inkDark} />
        <circle cx="26" cy="25.8" r="0.8" fill={ids.inkDark} />
        <path d="M23 28.2Q24.2 29.3 25.5 28.2" stroke="#C97A63" strokeWidth="1" strokeLinecap="round" />

        {/* القارئة اليمنى */}
        <path d="M33.5 26C33.5 20.5 36.8 18.5 40.5 18.5C44.5 18.5 47.2 21.5 47.5 27.5C47.7 30.5 46.5 33 45 33.5H35.5C34 32 33.5 29 33.5 26Z" fill={ids.inkDark} />
        <circle cx="40" cy="26" r="5.6" fill={`url(#${ids.skin})`} />
        <path d="M34.5 24.5C35.5 20.5 38.5 19.2 41.8 19.8C44.2 20.2 45.8 22.2 46 25C43.5 23.2 40.8 22.5 38 23.2L34.5 24.5Z" fill={ids.inkDark} />
        <circle cx="38.2" cy="26.2" r="0.8" fill={ids.inkDark} />
        <circle cx="41.8" cy="26.2" r="0.8" fill={ids.inkDark} />
        <path d="M39 28.5Q40 29.5 41.2 28.5" stroke="#C97A63" strokeWidth="1" strokeLinecap="round" />

        {/* الكتاب البنفسجي المفتوح في الأسفل */}
        <path
          d="M18.5 33.5L32 36.8L45.5 33.5V45.5L32 48.5L18.5 45.5V33.5Z"
          fill={`url(#${ids.purple})`}
        />
        <path d="M20 32.2L32 35.4L44 32.2" stroke="#FFFFFF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M32 35.5V48.2" stroke={`url(#${ids.purpleDark})`} strokeWidth="1.4" strokeLinecap="round" />
      </>
    )}
  </RifqMedallionBase>
);

/** 10. قصص الأطفال — طفلان (ولد وبنت بحجاب بنفسجي وذهبي) يقرآن في كتاب قصص مفتوح أمام قلعة خيالية وهلال ونجوم كما في الصورة المرجعية */
export const KidsStoriesSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="قصص الأطفال">
    {(ids) => (
      <>
        {/* قلعة القصص الخيالية الناعمة في الخلفية */}
        <g opacity="0.28" fill={ids.lavenderFill}>
          <rect x="26" y="13.5" width="12" height="12" rx="1" />
          <rect x="21" y="17" width="5" height="8.5" />
          <rect x="38" y="17" width="5" height="8.5" />
          <path d="M25 13.5L32 7.5L39 13.5H25Z" />
          <path d="M20 17L23.5 12L27 17H20Z" />
          <path d="M37 17L40.5 12L44 17H37Z" />
        </g>

        {/* الهلال الذهبي والنجوم المتلألئة */}
        <path d="M44.5 12A4.2 4.2 0 1 0 48.5 17.2A3.3 3.3 0 1 1 44.5 12Z" fill={`url(#${ids.gold})`} />
        <path d="M17.5 13.5L18.2 15L19.7 15.7L18.2 16.4L17.5 17.9L16.8 16.4L15.3 15.7L16.8 15L17.5 13.5Z" fill={`url(#${ids.gold})`} />
        <circle cx="32" cy="10.5" r="1.1" fill={`url(#${ids.gold})`} />

        {/* الولد على اليسار */}
        <path d="M14.5 42C14.5 35.8 19 33.2 23.8 33.2C27.8 33.2 30.5 35.8 31 42H14.5Z" fill={`url(#${ids.purple})`} />
        <path d="M20.8 33.2L23.8 36.5L26.8 33.2" stroke={`url(#${ids.gold})`} strokeWidth="1.1" fill="none" />
        <circle cx="23.5" cy="26.2" r="6.2" fill={`url(#${ids.skin})`} />
        <path d="M17.2 25.2C17.2 20.2 21 18.4 25 18.8C28.2 19.2 30 21.5 29.6 24.8C27.6 22.4 24.5 21.8 21.2 22.8C19.4 23.3 18 24.2 17.2 25.2Z" fill="#3B2820" />
        <circle cx="21.6" cy="26.5" r="0.85" fill="#25263A" />
        <circle cx="25.6" cy="26.5" r="0.85" fill="#25263A" />
        <circle cx="20.2" cy="28" r="1.1" fill="#F48FB1" opacity="0.45" />
        <circle cx="26.8" cy="28" r="1.1" fill="#F48FB1" opacity="0.45" />
        <path d="M22.3 28.8Q23.6 30.1 24.9 28.8" stroke="#8D5524" strokeWidth="0.9" strokeLinecap="round" fill="none" />

        {/* البنت بالحجاب البنفسجي والذهبي على اليمين */}
        <path d="M32.5 42C33 35.2 35.5 32.5 40.5 32.5C45.5 32.5 49.2 35.8 49.5 42H32.5Z" fill={`url(#${ids.purpleDark})`} />
        <circle cx="40.5" cy="26.2" r="7.2" fill={`url(#${ids.purple})`} />
        <path d="M34 27.2A6.8 6.8 0 0 0 47 27.2" stroke={`url(#${ids.gold})`} strokeWidth="1.1" fill="none" />
        <circle cx="40.5" cy="26.6" r="5.3" fill={`url(#${ids.skin})`} />
        <circle cx="38.7" cy="26.6" r="0.85" fill="#25263A" />
        <circle cx="42.5" cy="26.6" r="0.85" fill="#25263A" />
        <circle cx="37.5" cy="28" r="1.1" fill="#F48FB1" opacity="0.45" />
        <circle cx="43.7" cy="28" r="1.1" fill="#F48FB1" opacity="0.45" />
        <path d="M39.3 28.9Q40.5 30.1 41.7 28.9" stroke="#8D5524" strokeWidth="0.9" strokeLinecap="round" fill="none" />

        {/* الكتاب المفتوح المضيء في المقدمة */}
        <path
          d="M16 41.5Q24 37.5 32 41Q40 37.5 48 41.5L47 48.5Q39.5 45 32 48Q24.5 45 17 48.5L16 41.5Z"
          fill="#FFFDF7"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.8"
          strokeLinejoin="round"
        />
        <path d="M32 41V48" stroke={`url(#${ids.gold})`} strokeWidth="1.5" />
        <circle cx="16.5" cy="44.2" r="1.8" fill={`url(#${ids.skin})`} />
        <circle cx="47.5" cy="44.2" r="1.8" fill={`url(#${ids.skin})`} />
        <circle cx="32" cy="36.5" r="1.3" fill={`url(#${ids.gold})`} />
        <circle cx="28" cy="34.8" r="0.95" fill={`url(#${ids.gold})`} />
        <circle cx="36" cy="34.8" r="0.95" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 11. الأحاديث — مخطوطة نبوية يتوسطها شعار المسجد البنفسجي وسطور الحديث */
export const HadithSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الأحاديث">
    {(ids) => (
      <>
        <rect x="16" y="16.5" width="30" height="4.5" rx="2.2" fill={ids.scrollRoll} />
        <circle cx="18" cy="18.75" r="2.2" fill={`url(#${ids.purple})`} />
        <rect x="19" y="19" width="26" height="27" rx="2" fill={ids.scrollPaper} stroke={ids.scrollBorder} strokeWidth="1" />
        <rect x="17" y="44" width="30" height="4.8" rx="2.4" fill={ids.scrollBottom} stroke={ids.scrollRoll} strokeWidth="1" />
        <circle cx="20.5" cy="46.4" r="2.2" fill={`url(#${ids.purple})`} />

        {/* شعار المسجد داخل المخطوطة */}
        <path d="M27.5 31C27.5 27.8 29.5 25.5 32 25C34.5 25.5 36.5 27.8 36.5 31H27.5Z" fill={`url(#${ids.purple})`} />
        <rect x="26.5" y="31" width="11" height="4.5" rx="0.8" fill={`url(#${ids.purpleSoft})`} />
        <rect x="36" y="23.5" width="2" height="12" rx="0.6" fill={`url(#${ids.purpleDark})`} />
        {/* سطور الحديث */}
        <path d="M24 38.5H40M26 41.5H38" stroke={ids.lavenderStroke} strokeWidth="1.6" strokeLinecap="round" />
      </>
    )}
  </RifqMedallionBase>
);

/** 12. غريب القرآن — كتاب مفتوح مع عدسة مكبرة بنفسجية وذهبية */
export const GharibSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="غريب القرآن">
    {(ids) => (
      <>
        {/* الكتاب المفتوح */}
        <path d="M14.5 22.5L30.5 25.5L46.5 22.5V42.5L30.5 45.5L14.5 42.5V22.5Z" fill={`url(#${ids.purple})`} />
        <path d="M16.5 20.2L30.5 23.5V43L16.5 39.8V20.2Z" fill="#FFFFFF" stroke={ids.lavenderBorder} strokeWidth="1" />
        <path d="M44.5 20.2L30.5 23.5V43L44.5 39.8V20.2Z" fill={ids.scrollPaper} stroke={ids.lavenderBorder} strokeWidth="1" />
        <path
          d="M19.5 25.5L27.5 27.2M19.5 29.2L27.5 31M19.5 33L27.5 34.8M19.5 36.8L26 38.2M41.5 25.5L33.5 27.2M41.5 29.2L33.5 31"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        {/* العدسة المكبرة */}
        <circle cx="39.5" cy="36.5" r="7.2" fill={ids.lensTint} fillOpacity="0.85" stroke={`url(#${ids.purple})`} strokeWidth="2.8" />
        <circle cx="39.5" cy="36.5" r="5.4" stroke={`url(#${ids.gold})`} strokeWidth="1.1" />
        <path d="M44.8 41.8L49.5 46.5" stroke={`url(#${ids.purpleDark})`} strokeWidth="3.2" strokeLinecap="round" />
      </>
    )}
  </RifqMedallionBase>
);

/** 13. أحكام التجويد — مصحف مزخرف بإطار ذهبي وشمسة زخرفية وشريط علامة */
export const TajweedSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="أحكام التجويد">
    {(ids) => (
      <>
        <rect x="18" y="15" width="27" height="32" rx="3.5" fill={`url(#${ids.purple})`} />
        <path d="M18 18.5C18 16.6 19.6 15 21.5 15H22.5V47H21.5C19.6 47 18 45.4 18 43.5V18.5Z" fill={`url(#${ids.purpleDark})`} />
        <rect x="20.5" y="42" width="23.5" height="3.8" rx="1.8" fill="#FFFFFF" />
        {/* الإطار الذهبي الداخلي */}
        <rect x="24" y="18.5" width="17.5" height="20.5" rx="1.5" stroke={`url(#${ids.gold})`} strokeWidth="1.3" />
        {/* الشمسة الزخرفية الذهبية في المركز */}
        <path d="M32.75 22.5L37.5 28.75L32.75 35L28 28.75L32.75 22.5Z" fill={`url(#${ids.gold})`} />
        <circle cx="32.75" cy="28.75" r="2.2" fill={`url(#${ids.purple})`} />
        {/* شريط العلامة */}
        <path d="M27.5 43.8V50.5L29.8 48.8L32 50.5V43.8H27.5Z" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 14. الفقه الميسر — كتاب الفقه البنفسجي يتوسطه ميزان العدل الذهبي */
export const FiqhMuyassarSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الفقه الميسر">
    {(ids) => (
      <g transform="rotate(-6 32 32)">
        <rect x="18" y="15" width="27" height="32" rx="3.5" fill={`url(#${ids.purple})`} />
        <path d="M18 18.5C18 16.6 19.6 15 21.5 15H22.5V47H21.5C19.6 47 18 45.4 18 43.5V18.5Z" fill={`url(#${ids.purpleDark})`} />
        <rect x="20.5" y="42" width="23.5" height="3.8" rx="1.8" fill="#FFFFFF" />
        {/* ميزان العدل الذهبي على الغلاف */}
        <path d="M32.8 21V35.5M28.5 35.5H37M26.5 24.5H39" stroke={`url(#${ids.gold})`} strokeWidth="1.8" strokeLinecap="round" />
        <path d="M26.5 24.5L24.2 30H28.8L26.5 24.5ZM39 24.5L36.7 30H41.3L39 24.5Z" fill={`url(#${ids.gold})`} />
      </g>
    )}
  </RifqMedallionBase>
);

/** 15. آية وفائدة — كفّ بنفسجية تحتضن نبتة خضراء يانعة مع لمعان ذهبي */
export const TadabburSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="آية وفائدة">
    {(ids) => (
      <>
        {/* النبتة الخضراء */}
        <path d="M33 34V22" stroke="#2F855A" strokeWidth="2.2" strokeLinecap="round" />
        <path
          d="M33 28C27 28 24.5 23.5 25.5 18.5C30.5 18.5 33 22.5 33 28Z"
          fill={`url(#${ids.green})`}
        />
        <path
          d="M33 25.5C38.5 25.5 41.5 21 40.5 16C35.5 16 33 20 33 25.5Z"
          fill={`url(#${ids.green})`}
        />
        {/* اليد البنفسجية الحانية */}
        <path
          d="M16.5 39.5C18.5 35.5 23.5 34.5 29.5 35.5H37.5C39.2 35.5 40.5 36.8 40.5 38.2C40.5 39.5 39.2 40.5 37.5 40.5H32.5L45.5 36.2C47.2 35.6 48.8 36.8 48.5 38.5C48.2 40.2 42.5 44.5 35.5 45.5C28.5 46.5 21.5 45.5 16.5 44V39.5Z"
          fill={`url(#${ids.purple})`}
        />
        {/* لمعان ذهبي */}
        <path d="M20 26L20.8 27.6L22.4 28.4L20.8 29.2L20 30.8L19.2 29.2L17.6 28.4L19.2 27.6L20 26Z" fill={`url(#${ids.gold})`} />
        <path d="M45 27.5L45.6 28.8L46.9 29.4L45.6 30L45 31.3L44.4 30L43.1 29.4L44.4 28.8L45 27.5Z" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 16. الزكاة والمواريث — ميزان العدل البنفسجي بكفتين ذهبيتين */
export const ZakatMawarithSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الزكاة والمواريث">
    {(ids) => (
      <>
        {/* العمود والقاعدة البنفسجية */}
        <rect x="30.4" y="19" width="3.2" height="25" rx="1.5" fill={`url(#${ids.purple})`} />
        <rect x="23" y="43.5" width="18" height="3.8" rx="1.9" fill={`url(#${ids.purple})`} />
        <circle cx="32" cy="18" r="2.4" fill={`url(#${ids.gold})`} />
        {/* الذراع الأفقية */}
        <path d="M18.5 23.5H45.5" stroke={`url(#${ids.purpleDark})`} strokeWidth="2.4" strokeLinecap="round" />
        {/* سلاسل الكفتين */}
        <path
          d="M19.5 23.5L15.5 34.5M19.5 23.5L23.5 34.5M44.5 23.5L40.5 34.5M44.5 23.5L48.5 34.5"
          stroke={ids.lavenderStroke}
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        {/* الكفتان الذهبيتان */}
        <path d="M14 34.5H25C25 37.8 22.5 40 19.5 40C16.5 40 14 37.8 14 34.5Z" fill={`url(#${ids.gold})`} />
        <path d="M39 34.5H50C50 37.8 47.5 40 44.5 40C41.5 40 39 37.8 39 34.5Z" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 17. التقويم والصيام — تقويم بنفسجي يتوسطه هلال الصيام الذهبي والنجوم */
export const HijriFastingSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="التقويم والصيام">
    {(ids) => (
      <>
        <rect x="17" y="19" width="30" height="27" rx="5" fill={ids.lavenderSoftBg} stroke={`url(#${ids.purple})`} strokeWidth="1.8" />
        <path d="M17 24C17 21.2 19.2 19 22 19H42C44.8 19 47 21.2 47 24V26.5H17V24Z" fill={`url(#${ids.purple})`} />
        {/* حلقات التقويم العلوية */}
        <rect x="23" y="16" width="2.8" height="6" rx="1.4" fill={`url(#${ids.purpleDark})`} />
        <rect x="30.6" y="16" width="2.8" height="6" rx="1.4" fill={`url(#${ids.purpleDark})`} />
        <rect x="38.2" y="16" width="2.8" height="6" rx="1.4" fill={`url(#${ids.purpleDark})`} />
        {/* الهلال الذهبي والنجوم */}
        <path
          d="M35.5 31.2A6.2 6.2 0 1 1 27.8 39.5A4.8 4.8 0 1 0 35.5 31.2Z"
          fill={`url(#${ids.gold})`}
        />
        <path d="M36.5 31L37.2 32.5L38.7 33.2L37.2 33.9L36.5 35.4L35.8 33.9L34.3 33.2L35.8 32.5L36.5 31Z" fill={`url(#${ids.gold})`} />
        <circle cx="24" cy="32" r="1" fill={ids.lavenderStroke} />
        <circle cx="40" cy="39" r="1" fill={ids.lavenderStroke} />
      </>
    )}
  </RifqMedallionBase>
);

/** 18. الحج والعمرة — الكعبة المشرفة بحزامها الذهبي مع طائرة السفر البنفسجية */
export const HajjUmrahSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الحج والعمرة">
    {(ids) => (
      <>
        {/* مجسم الكعبة المشرفة ثلاثي الأبعاد */}
        <path d="M16 22.5L29.5 17.5L43 22.5V42.5L29.5 46.5L16 42.5V22.5Z" fill="#252850" />
        <path d="M29.5 17.5L43 22.5V42.5L29.5 46.5V17.5Z" fill="#1B1E3D" />
        {/* الحزام الذهبي */}
        <path d="M16 26.5L29.5 22.2L43 26.5V29.8L29.5 25.5L16 29.8V26.5Z" fill={`url(#${ids.gold})`} />
        {/* باب الكعبة والزخارف الذهبية */}
        <rect x="33.5" y="32.5" width="3.8" height="7" rx="0.8" fill={`url(#${ids.gold})`} />
        <rect x="20" y="31.5" width="3" height="2" rx="0.5" fill={`url(#${ids.gold})`} />
        <rect x="24.5" y="30.2" width="3" height="2" rx="0.5" fill={`url(#${ids.gold})`} />

        {/* طائرة السفر البنفسجية في الزاوية السفلية اليمنى */}
        <path
          d="M32 45.5L48.5 35.5C50 34.6 51.5 35.8 50.5 37.3L43.5 44.5L46.5 48.5L44.2 49.8L40 45.8L35 48.2L32 45.5Z"
          fill={`url(#${ids.purpleSoft})`}
          stroke="#FFFFFF"
          strokeWidth="0.9"
          strokeLinejoin="round"
        />
      </>
    )}
  </RifqMedallionBase>
);

/** 19. الأذكار — كفّا الدعاء المرفوعتان بأكمام بنفسجية ونجوم مضيئة */
export const AthkarSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الأذكار">
    {(ids) => (
      <>
        {/* الكف اليسرى */}
        <path
          d="M21 38.5L19.5 29.5C19.2 26.5 21 22.5 23.5 21.5C25.2 20.8 26.8 22 27.2 24.5L28.5 29.5C29.5 28 31 28.5 31 30.5L30.2 37.5L26.5 40.5L21 38.5Z"
          fill={`url(#${ids.skin})`}
          stroke="#DF9A78"
          strokeWidth="0.8"
        />
        {/* الكف اليمنى */}
        <path
          d="M43 38.5L44.5 29.5C44.8 26.5 43 22.5 40.5 21.5C38.8 20.8 37.2 22 36.8 24.5L35.5 29.5C34.5 28 33 28.5 33 30.5L33.8 37.5L37.5 40.5L43 38.5Z"
          fill={`url(#${ids.skin})`}
          stroke="#DF9A78"
          strokeWidth="0.8"
        />
        {/* الأكمام البنفسجية */}
        <path d="M18.5 40L27.5 38.2L29.2 45.5L20.2 47.5L18.5 40Z" fill={`url(#${ids.purple})`} />
        <path d="M45.5 40L36.5 38.2L34.8 45.5L43.8 47.5L45.5 40Z" fill={`url(#${ids.purple})`} />
        <circle cx="24.5" cy="42.5" r="1" fill={`url(#${ids.gold})`} />
        <circle cx="39.5" cy="42.5" r="1" fill={`url(#${ids.gold})`} />

        {/* نجوم الذكر المضيئة */}
        <path d="M32 15.5L32.8 17.2L34.5 18L32.8 18.8L32 20.5L31.2 18.8L29.5 18L31.2 17.2L32 15.5Z" fill={`url(#${ids.gold})`} />
        <path d="M16.5 26.5L17.2 27.8L18.5 28.5L17.2 29.2L16.5 30.5L15.8 29.2L14.5 28.5L15.8 27.8L16.5 26.5Z" fill={ids.lavenderStroke} />
        <path d="M47.5 26.5L48.2 27.8L49.5 28.5L48.2 29.2L47.5 30.5L46.8 29.2L45.5 28.5L46.8 27.8L47.5 26.5Z" fill={ids.lavenderStroke} />
      </>
    )}
  </RifqMedallionBase>
);

/** 20. الرقية والطب النبوي — وعاء الأعشاب البنفسجي وأوراق الشفاء الخضراء */
export const RuqyahMedicineSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الرقية والطب النبوي">
    {(ids) => (
      <>
        {/* أوراق الأعشاب والزيتون */}
        <path d="M24 35C19 32 17.5 27 19.5 23.5C23.5 25 25.5 29.5 24 35Z" fill={`url(#${ids.green})`} />
        <path d="M31 35C28 29 29 23.5 32.5 20C35.5 23.5 35 29.5 31 35Z" fill={`url(#${ids.green})`} />
        <path d="M39 35C43.5 32.5 45.5 27.5 43.5 23.5C39.5 25 37.5 29.5 39 35Z" fill={`url(#${ids.green})`} />
        {/* براعم اللافندر/الزيتون البنفسجية */}
        <ellipse cx="38.5" cy="21" rx="2.2" ry="3.2" transform="rotate(20 38.5 21)" fill={`url(#${ids.purpleSoft})`} />
        <ellipse cx="27" cy="27" rx="1.8" ry="2.8" transform="rotate(-18 27 27)" fill={`url(#${ids.purpleSoft})`} />
        {/* نجمة الشفاء الذهبية */}
        <path d="M23.5 18L24.5 20.2L26.7 21.2L24.5 22.2L23.5 24.4L22.5 22.2L20.3 21.2L22.5 20.2L23.5 18Z" fill={`url(#${ids.gold})`} />

        {/* الوعاء البنفسجي */}
        <path
          d="M17.5 34.5H46.5C46.5 42.2 40.2 47.5 32 47.5C23.8 47.5 17.5 42.2 17.5 34.5Z"
          fill={`url(#${ids.purple})`}
        />
        <ellipse cx="32" cy="34.5" rx="14.5" ry="2.5" fill={`url(#${ids.purpleSoft})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 21. تعليم الوضوء — كفّ بنفسجية تعلوها 3 قطرات ماء صافية */
export const WuduPrayerSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="تعليم الوضوء">
    {(ids) => (
      <>
        {/* قطرات الماء الثلاث */}
        <path d="M31.5 14.5C31.5 14.5 26.5 21 26.5 24.5C26.5 27.3 28.7 29.5 31.5 29.5C34.3 29.5 36.5 27.3 36.5 24.5C36.5 21 31.5 14.5 31.5 14.5Z" fill={`url(#${ids.blue})`} />
        <path d="M29.2 23.5C29.2 25 29.8 26.2 31 26.8" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" />

        <path d="M21.5 21C21.5 21 18.5 25.2 18.5 27.5C18.5 29.2 19.8 30.5 21.5 30.5C23.2 30.5 24.5 29.2 24.5 27.5C24.5 25.2 21.5 21 21.5 21Z" fill={`url(#${ids.blue})`} />
        <path d="M40.5 22.5C40.5 22.5 38 26 38 28C38 29.4 39.1 30.5 40.5 30.5C41.9 30.5 43 29.4 43 28C43 26 40.5 22.5 40.5 22.5Z" fill={`url(#${ids.blue})`} />

        {/* الكف البنفسجية */}
        <path
          d="M17.5 39.5C19.5 35.5 24.5 34 30.5 35H37.5C39 35 40.2 36 40.2 37.4C40.2 38.7 39 39.6 37.5 39.6H32.5L44.5 35.5C46.2 34.8 47.8 36 47.4 37.8C47 39.5 41.5 44.2 35 45.5C28.5 46.8 21.5 45.8 17.5 44V39.5Z"
          fill={`url(#${ids.purple})`}
        />
      </>
    )}
  </RifqMedallionBase>
);

/** 22. رِفْق للمرأة — سيدة مسلمة بحجاب بنفسجي أنيق مع قلب وردي ناعم */
export const MuslimWomanSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="رِفْق للمرأة">
    {(ids) => (
      <>
        {/* الوجه الجانبي */}
        <path
          d="M31 20.5C35.8 20.5 38.8 24 38.8 28.5C38.8 32.8 35.8 35.8 31.5 35.8H28V20.5H31Z"
          fill={`url(#${ids.skin})`}
        />
        {/* الحجاب البنفسجي الانسيابي */}
        <path
          d="M28.5 16.5C22.5 16.5 18.5 21.5 18.5 28.5C18.5 34.5 20.5 39.5 17.5 44.5C22.5 47.5 31.5 48 39.5 45.5C39.5 41 36.5 37.5 33.5 35.5C30.5 33.5 30.5 29.5 32.5 26.5C34 24.2 36.5 23 37.5 22C35.5 18.5 32.5 16.5 28.5 16.5Z"
          fill={`url(#${ids.purple})`}
        />
        <path
          d="M22.5 27.5C22.5 33.5 26 38.5 33.5 42.5"
          stroke={ids.lavenderStroke}
          strokeWidth="1.4"
          strokeLinecap="round"
        />
        {/* دبوس الحجاب الذهبي */}
        <circle cx="30" cy="31" r="1.3" fill={`url(#${ids.gold})`} />

        {/* القلب الوردي الناعم */}
        <path
          d="M44.5 37.5C44.5 37.5 40.5 35 40.5 32.5C40.5 31 41.7 30 43 30C43.8 30 44.5 30.6 44.5 30.6C44.5 30.6 45.2 30 46 30C47.3 30 48.5 31 48.5 32.5C48.5 35 44.5 37.5 44.5 37.5Z"
          fill="#F687B3"
        />
      </>
    )}
  </RifqMedallionBase>
);

/** 23. أسماء الله — نجمة ثمانية ذهبية وبنفسجية تتوسطها مخطوطة «الله» */
export const AsmaaAllahSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="أسماء الله">
    {(ids) => (
      <>
        {/* النجمة الثمانية الذهبية الخارجية */}
        <rect x="17.5" y="17.5" width="29" height="29" rx="3" fill={`url(#${ids.gold})`} />
        <rect x="17.5" y="17.5" width="29" height="29" rx="3" transform="rotate(45 32 32)" fill={`url(#${ids.gold})`} />
        {/* النجمة الثمانية البنفسجية الداخلية */}
        <rect x="20" y="20" width="24" height="24" rx="2" fill={`url(#${ids.purple})`} />
        <rect x="20" y="20" width="24" height="24" rx="2" transform="rotate(45 32 32)" fill={`url(#${ids.purple})`} />
        {/* مخطوطة لفظ الجلالة (الله) باللون الذهبي */}
        <text
          x="32"
          y="36.8"
          textAnchor="middle"
          fill="#FFE484"
          fontSize="14.5"
          fontWeight="900"
          fontFamily="Amiri, Cairo, serif"
        >
          الله
        </text>
      </>
    )}
  </RifqMedallionBase>
);

/** 24. التذكيرات اليومية — مصباح ذهبي مضيء بأشعة بنفسجية */
export const DailyRemindersSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="التذكيرات اليومية">
    {(ids) => (
      <>
        {/* أشعة الإضاءة البنفسجية */}
        <path
          d="M32 13.5V16.5M19 19L21.2 21.2M45 19L42.8 21.2M14.5 30H17.5M46.5 30H49.5"
          stroke={`url(#${ids.purple})`}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        {/* زجاجة المصباح الذهبية */}
        <path
          d="M32 19.5C26.2 19.5 21.8 23.8 21.8 29.2C21.8 32.8 23.8 35.8 26.5 37.5L27.4 41H36.6L37.5 37.5C40.2 35.8 42.2 32.8 42.2 29.2C42.2 23.8 37.8 19.5 32 19.5Z"
          fill={`url(#${ids.gold})`}
        />
        {/* فتيل الإضاءة الداخلي */}
        <path d="M29.5 39.5V32.5C29.5 31 30.6 30 32 30C33.4 30 34.5 31 34.5 32.5V39.5" stroke="#FFF9E6" strokeWidth="1.6" strokeLinecap="round" />
        {/* قاعدة المصباح البنفسجية */}
        <rect x="27.5" y="41" width="9" height="3.5" rx="1.5" fill={`url(#${ids.purple})`} />
        <rect x="29" y="44.5" width="6" height="2.8" rx="1.4" fill={`url(#${ids.purpleDark})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 26. حصاد الأعمال — أعمدة النمو البنفسجية مع سهم الارتقاء الذهبي */
export const HarvestSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="حصاد الأعمال">
    {(ids) => (
      <>
        {/* سهم الارتقاء الذهبي */}
        <path
          d="M19.5 30.5C25.5 28.5 32.5 24 39.5 17.5"
          stroke={`url(#${ids.gold})`}
          strokeWidth="2.5"
          strokeLinecap="round"
        />
        <path
          d="M34.5 17.5H40V23"
          stroke={`url(#${ids.gold})`}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* الأعمدة الثلاثة الصاعدة */}
        <rect x="18" y="35" width="6.5" height="11" rx="1.8" fill={`url(#${ids.purpleSoft})`} />
        <rect x="28.8" y="29.5" width="6.5" height="16.5" rx="1.8" fill={`url(#${ids.purple})`} />
        <rect x="39.5" y="24" width="6.5" height="22" rx="1.8" fill={`url(#${ids.purpleDark})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 27. الإحصائيات — لوحة التقارير مع المخطط الدائري والأعمدة البيانية */
export const StatsSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الإحصائيات">
    {(ids) => (
      <>
        <rect x="18" y="16.5" width="28" height="31" rx="4" fill={ids.lavenderSoftBg} stroke={`url(#${ids.purpleSoft})`} strokeWidth="1.6" />
        {/* سطور البيانات اليسرى */}
        <path d="M22 23.5H28.5M22 28H27.5M22 32.5H27.5M22 39H28.5M22 42.5H28.5" stroke={`url(#${ids.purple})`} strokeWidth="1.8" strokeLinecap="round" />
        {/* المخطط الدائري (Pie Chart) */}
        <circle cx="37.5" cy="28" r="5.2" fill={`url(#${ids.purple})`} />
        <path d="M37.5 28V22.8A5.2 5.2 0 0 1 42.7 28H37.5Z" fill={`url(#${ids.gold})`} />
        {/* الأعمدة البيانية السفلية */}
        <rect x="33" y="40.5" width="2.4" height="4" rx="0.8" fill={`url(#${ids.purpleSoft})`} />
        <rect x="36.8" y="38" width="2.4" height="6.5" rx="0.8" fill={`url(#${ids.purple})`} />
        <rect x="40.6" y="35.5" width="2.4" height="9" rx="0.8" fill={`url(#${ids.purpleDark})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 28. الملف الشخصي — مجسم المستخدم البنفسجي مع ترس الإعدادات الفرعي */
export const ProfileSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الملف الشخصي">
    {(ids) => (
      <>
        <circle cx="30" cy="24" r="6.5" fill={`url(#${ids.purple})`} />
        <path
          d="M18 43.5C18 37.2 23.2 33 30 33C36.8 33 42 37.2 42 43.5C42 44.6 41.1 45.5 40 45.5H20C18.9 45.5 18 44.6 18 43.5Z"
          fill={`url(#${ids.purple})`}
        />
        {/* ترس الحساب الصغير */}
        <circle cx="41.5" cy="40.5" r="5.8" fill="#FFFFFF" />
        <circle cx="41.5" cy="40.5" r="4.2" fill={`url(#${ids.isGirly ? ids.gold : ids.purpleDark})`} />
        <path
          d="M41.5 34.5V46.5M35.5 40.5H47.5M37.3 36.3L45.7 44.7M45.7 36.3L37.3 44.7"
          stroke={`url(#${ids.isGirly ? ids.gold : ids.purpleDark})`}
          strokeWidth="2"
          strokeLinecap="round"
        />
        <circle cx="41.5" cy="40.5" r="1.8" fill="#FFFFFF" />
      </>
    )}
  </RifqMedallionBase>
);

/** 29. الإعدادات — ترس الضبط البنفسجي ثلاثي الأبعاد */
export const SettingsSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الإعدادات">
    {(ids) => (
      <>
        <path
          d="M32 16V48M16 32H48M20.7 20.7L43.3 43.3M43.3 20.7L20.7 43.3"
          stroke={`url(#${ids.purple})`}
          strokeWidth="5.2"
          strokeLinecap="round"
        />
        <circle cx="32" cy="32" r="12.5" fill={`url(#${ids.purple})`} />
        <circle cx="32" cy="32" r="8" fill={`url(#${ids.purpleDark})`} />
        <circle cx="32" cy="32" r="4.5" fill={ids.scrollPaper} />
      </>
    )}
  </RifqMedallionBase>
);

/** 30. تواصل المطور — نافذة البرمجة </> مع ظرف الرسالة والطائرة الورقية */
export const CreditsSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="تواصل المطور">
    {(ids) => (
      <>
        {/* نافذة الكود */}
        <rect x="20" y="18" width="24" height="17" rx="3.5" fill={ids.lavenderSoftBg} stroke={`url(#${ids.purple})`} strokeWidth="1.8" />
        <path
          d="M28 24L25 26.5L28 29M36 24L39 26.5L36 29M33 23L31 30"
          stroke={`url(#${ids.purpleDark})`}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* ظرف البريد السفلي */}
        <rect x="19" y="32" width="16.5" height="12" rx="2" fill={`url(#${ids.purpleSoft})`} stroke={`url(#${ids.purple})`} strokeWidth="1.2" />
        <path d="M19.5 33L27.25 38.5L35 33" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />

        {/* الطائرة الورقية */}
        <path d="M35.5 39.5L47.5 33L43.5 45.5L39.5 41.5L35.5 39.5Z" fill={`url(#${ids.purple})`} />
        <path d="M39.5 41.5L47.5 33" stroke={`url(#${ids.gold})`} strokeWidth="1.4" strokeLinecap="round" />
      </>
    )}
  </RifqMedallionBase>
);

/** 31. التحفيظ — قبعة التخرج والإجازة القرآنية البنفسجية والذهبية */
export const GraduationSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="التحفيظ">
    {(ids) => (
      <>
        <path d="M22 31V39.5C22 42.5 26.5 45 32 45C37.5 45 42 42.5 42 39.5V31" fill={`url(#${ids.purpleDark})`} />
        <path d="M14 27.5L32 19.5L50 27.5L32 35.5L14 27.5Z" fill={`url(#${ids.purple})`} />
        <path d="M32 27.5L45 31.5V41" stroke={`url(#${ids.gold})`} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="45" cy="42" r="2" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 32. أثر طيّب — الشاهد التذكاري المقوس الهادئ، زهرة الزنبق البيضاء، الحمامة الصاعدة، ومنارة المسجد */
export const AtharTayyibSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="أثر طيّب">
    {(ids) => (
      <>
        {/* هالة خلفية ناعمة */}
        <circle cx="32" cy="32" r="26" fill={`url(#${ids.purpleSoft})`} opacity="0.35" />

        {/* منارة المسجد وقبة الهلال البعيدة في الخلفية يميناً */}
        <rect x="47" y="24" width="2.4" height="18" rx="0.5" fill={ids.lavenderFill} opacity="0.75" />
        <path d="M47 24L48.2 21L49.4 24Z" fill={`url(#${ids.gold})`} />
        <path d="M41 33C41 28.5 44 26 46 26C48 26 51 28.5 51 33H41Z" fill={ids.lavenderFill} opacity="0.65" />
        <circle cx="46" cy="24.5" r="0.9" fill={`url(#${ids.gold})`} />

        {/* الشاهد التذكاري المقوس — Arched Monument */}
        <path
          d="M21 44V26C21 21 25.5 17 32 17C38.5 17 43 21 43 26V44H21Z"
          fill="#FFFFFF"
          stroke={`url(#${ids.purple})`}
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
        {/* قوس ذهبي داخلي ناعم */}
        <path
          d="M25 43V28C25 24 28 21.5 32 21.5C36 21.5 39 24 39 28V43"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.2"
          strokeLinecap="round"
        />

        {/* صورة ظلية كريمة للشخص في قلب القوس */}
        <circle cx="32" cy="27.5" r="3.2" fill={`url(#${ids.purple})`} />
        <path
          d="M27.5 38.5C27.5 34.5 29.5 33 32 33C34.5 33 36.5 34.5 36.5 38.5"
          fill={`url(#${ids.purple})`}
        />

        {/* زخرفة إسلامية رباعية ذهبية أسفل الشاهد */}
        <circle cx="32" cy="41" r="1.1" fill={`url(#${ids.gold})`} />
        <path d="M30 41H34M32 39V43" stroke={`url(#${ids.gold})`} strokeWidth="0.8" strokeLinecap="round" />

        {/* الحمامة البيضاء الصاعدة نحو السماء يميناً */}
        <g transform="translate(38, 14) scale(0.65)">
          <path
            d="M5 10C8 6 14 3 17 5C15 8 13 11 11 14C8 14 6 12 5 10Z"
            fill="#FFFFFF"
            stroke={`url(#${ids.purpleDark})`}
            strokeWidth="0.9"
          />
          <path
            d="M11 14C14 13 18 10 20 12C18 14 15 16 13 16C12 16 11 15 11 14Z"
            fill="#FFFFFF"
            stroke={`url(#${ids.purpleDark})`}
            strokeWidth="0.9"
          />
          <circle cx="6" cy="9" r="0.6" fill={`url(#${ids.gold})`} />
        </g>

        {/* زهرة الزنبق البيضاء والأوراق البنفسجية أسفل يسار الشاهد */}
        <g transform="translate(16, 36) scale(0.7)">
          <path d="M4 14C1 10 3 4 8 3C8 8 7 12 4 14Z" fill={`url(#${ids.purpleSoft})`} stroke={`url(#${ids.gold})`} strokeWidth="0.9" />
          <path d="M12 16C16 12 16 6 12 3C10 7 10 12 12 16Z" fill={`url(#${ids.purpleSoft})`} stroke={`url(#${ids.gold})`} strokeWidth="0.9" />
          <path d="M8 8C4 5 5 1 8 0C11 1 12 5 8 8Z" fill="#FFFFFF" stroke={`url(#${ids.gold})`} strokeWidth="1" />
          <path d="M8 8C2 7 2 3 5 2C6 5 7 7 8 8Z" fill="#FFFFFF" stroke={`url(#${ids.gold})`} strokeWidth="0.9" />
          <path d="M8 8C14 7 14 3 11 2C10 5 9 7 8 8Z" fill="#FFFFFF" stroke={`url(#${ids.gold})`} strokeWidth="0.9" />
          <circle cx="8" cy="5" r="1.1" fill={`url(#${ids.gold})`} />
        </g>

        {/* نجوم إشعاع صغيرة */}
        <circle cx="21" cy="18" r="0.7" fill={`url(#${ids.gold})`} />
        <circle cx="43" cy="17" r="0.8" fill={`url(#${ids.gold})`} />
        <circle cx="47" cy="30" r="0.6" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 33. أمانة — خزنة الأمانة، صك التوثيق، درع الحفظ، وأغصان الزيتون */
export const AmanaSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="أمانة">
    {(ids) => (
      <>
        {/* خلفية المحراب الإسلامي الزمردي الداكن */}
        <path
          d="M17 48V28C17 21 23 15 32 15C41 15 47 21 47 28V48H17Z"
          fill="#1C4B47"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.4"
          strokeLinejoin="round"
        />

        {/* صك / وثيقة الدين الورقية خلف الخزنة */}
        <path
          d="M23 19C23 18 24 17 25 17H39C40 17 41 18 41 19V32H23V19Z"
          fill="#FFFDF3"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1"
        />
        {/* تفاصيل المخطوطة: قوس صغير وخطوط كتابة */}
        <path d="M30 20C30 19 31 18 32 18C33 18 34 19 34 20" stroke="#1C4B47" strokeWidth="0.8" fill="none" />
        <line x1="26" y1="23" x2="38" y2="23" stroke="#2B6B63" strokeWidth="0.9" strokeLinecap="round" />
        <line x1="26" y1="26" x2="36" y2="26" stroke="#2B6B63" strokeWidth="0.9" strokeLinecap="round" />
        <line x1="26" y1="29" x2="34" y2="29" stroke="#2B6B63" strokeWidth="0.9" strokeLinecap="round" />

        {/* الخزنة / الصندوق الزمردي المتين */}
        <rect
          x="19"
          y="31"
          width="26"
          height="16"
          rx="3.5"
          fill="#2B6B63"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.2"
        />
        {/* الحزام الذهبي الأفقي على الخزنة */}
        <line x1="19" y1="36" x2="45" y2="36" stroke={`url(#${ids.gold})`} strokeWidth="1.2" />

        {/* القفل الذهبي المعلق في المنتصف */}
        <path
          d="M29.5 36V33C29.5 31.5 30.5 30.5 32 30.5C33.5 30.5 34.5 31.5 34.5 33V36"
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.4"
          fill="none"
          strokeLinecap="round"
        />
        <rect x="28" y="35" width="8" height="7.5" rx="2" fill={`url(#${ids.gold})`} />
        {/* فتحة المفتاح */}
        <circle cx="32" cy="38" r="0.9" fill="#1C4B47" />
        <path d="M31.6 38.5L31.3 40.5H32.7L32.4 38.5Z" fill="#1C4B47" />

        {/* درع الحفظ الذهبي على اليمين */}
        <g transform="translate(37, 35) scale(0.65)">
          <path
            d="M8 2L14 4V9C14 13 11 16 8 18C5 16 2 13 2 9V4L8 2Z"
            fill={`url(#${ids.gold})`}
            stroke="#FFF4D0"
            strokeWidth="0.8"
          />
          <path
            d="M8 5L12 6.5V9.5C12 12 10 14 8 15.5C6 14 4 12 4 9.5V6.5L8 5Z"
            fill="#1C4B47"
          />
          <circle cx="8" cy="9.5" r="1.1" fill={`url(#${ids.gold})`} />
        </g>

        {/* أغصان وأوراق الزيتون على اليسار */}
        <g transform="translate(15, 34) scale(0.65)">
          <path d="M6 18C3 15 2 10 4 6C7 9 7 14 6 18Z" fill="#78B372" stroke={`url(#${ids.gold})`} strokeWidth="0.7" />
          <path d="M7 18C10 16 12 12 11 8C8 10 7 14 7 18Z" fill="#589B52" stroke={`url(#${ids.gold})`} strokeWidth="0.7" />
        </g>

        {/* نجوم التألق */}
        <circle cx="21" cy="22" r="0.7" fill={`url(#${ids.gold})`} />
        <circle cx="44" cy="22" r="0.7" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 32. الرئيسية — قبة المنزل الإسلامي البنفسجية والباب الذهبي */
export const HomeSectionSvg: React.FC<SectionIconProps> = ({ size = 32, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="الرئيسية">
    {(ids) => (
      <>
        <path d="M17 30L32 18L47 30V45C47 46.1 46.1 47 45 47H19C17.9 47 17 46.1 17 45V30Z" fill={`url(#${ids.purple})`} />
        <path d="M28 47V37C28 34.8 29.8 33 32 33C34.2 33 36 34.8 36 37V47H28Z" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 33. رحلتي — مسار الارتقاء الإيماني مع النبتة المباركة والنجمة الذهبية */
export const JourneySectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="رحلتي">
    {(ids) => (
      <>
        {/* المسار المتدرج نحو القمة */}
        <path
          d="M18 45C22 41 25 36 28 34C32 31.5 35 32 39 27C41.5 24 43.5 20.5 45 18"
          stroke={`url(#${ids.purple})`}
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeDasharray="1 0"
        />
        {/* نقاط المراحل على المسار */}
        <circle cx="19.5" cy="43.5" r="2.6" fill={`url(#${ids.purpleDark})`} stroke="#FFFFFF" strokeWidth="1" />
        <circle cx="30.5" cy="33" r="2.8" fill={`url(#${ids.purple})`} stroke="#FFFFFF" strokeWidth="1" />
        {/* نبتة النمو والغراس المبارك */}
        <path
          d="M29.5 31.5V22.5"
          stroke={`url(#${ids.green})`}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
        <path
          d="M29.5 26.5C29.5 22.5 23.5 20.5 20.5 23.5C20.5 27.5 25.5 28.5 29.5 26.5Z"
          fill={`url(#${ids.green})`}
        />
        <path
          d="M29.5 24.5C29.5 20.5 35.5 18.5 38.5 21.5C38.5 25.5 33.5 26.5 29.5 24.5Z"
          fill={`url(#${ids.gold})`}
        />
        {/* نجمة الإنجاز في أعلى المسار */}
        <path
          d="M45 14L46.3 16.8L49.3 17.2L47.1 19.3L47.6 22.3L45 20.8L42.4 22.3L42.9 19.3L40.7 17.2L43.7 16.8L45 14Z"
          fill={`url(#${ids.gold})`}
        />
      </>
    )}
  </RifqMedallionBase>
);

/** 34. السيرة النبوية — القبة الخضراء والمنارة البيضاء والهلال الذهبي والكتاب المفتوح والمسبحة */
export const PropheticBiographySectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="السيرة النبوية">
    {(ids) => (
      <>
        {/* هلال ذهبي مشرق ونجوم السماء */}
        <path
          d="M41.5 15.5C38.8 16.4 37.4 19.4 38.5 22.1C39.6 24.8 42.6 26 45.2 24.7C42.6 25.1 40.3 23.6 39.6 21.3C38.9 19 39.8 16.6 41.5 15.5Z"
          fill={`url(#${ids.gold})`}
        />
        <circle cx="19.5" cy="18.5" r="1" fill={`url(#${ids.gold})`} />
        <circle cx="33.5" cy="15.5" r="0.9" fill={`url(#${ids.gold})`} />

        {/* المنارة البيضاء النبوية */}
        <rect
          x="21.5"
          y="21"
          width="4.2"
          height="16.5"
          rx="0.8"
          fill="#FFFFFF"
          stroke={`url(#${ids.purple})`}
          strokeWidth="1.1"
        />
        <path d="M21.5 21L23.6 16.2L25.7 21Z" fill={`url(#${ids.gold})`} />
        <line x1="20.8" y1="25" x2="26.4" y2="25" stroke={`url(#${ids.gold})`} strokeWidth="1.2" strokeLinecap="round" />

        {/* القبة الخضراء الشريفة */}
        <path
          d="M26.5 34.5C26.5 26.5 31.5 22 35 19.6C38.5 22 43.5 26.5 43.5 34.5Z"
          fill={`url(#${ids.green})`}
          stroke={`url(#${ids.gold})`}
          strokeWidth="1.2"
        />
        <line x1="35" y1="17" x2="35" y2="19.6" stroke={`url(#${ids.gold})`} strokeWidth="1.3" strokeLinecap="round" />

        {/* قاعدة المسجد النبوي */}
        <rect
          x="19.5"
          y="34"
          width="25"
          height="5.2"
          rx="1"
          fill={`url(#${ids.purpleSoft})`}
          stroke={`url(#${ids.purple})`}
          strokeWidth="1.1"
        />

        {/* الكتاب المفتوح في المقدمة */}
        <path
          d="M18 45.5C23 43.5 28.5 44.5 32 46.8C35.5 44.5 41 43.5 46 45.5L47.2 39.8C42 38 36 39 32 41.5C28 39 22 38 16.8 39.8Z"
          fill={`url(#${ids.gold})`}
          stroke={`url(#${ids.purpleDark})`}
          strokeWidth="1.1"
          strokeLinejoin="round"
        />
        <line x1="32" y1="41.5" x2="32" y2="46.8" stroke={`url(#${ids.purpleDark})`} strokeWidth="1.2" />

        {/* حبات المسبحة الذهبية أسفل الكتاب */}
        <circle cx="26" cy="48.5" r="1.1" fill={`url(#${ids.gold})`} />
        <circle cx="29" cy="49.4" r="1.1" fill={`url(#${ids.gold})`} />
        <circle cx="32" cy="49.8" r="1.3" fill={`url(#${ids.gold})`} />
        <circle cx="35" cy="49.4" r="1.1" fill={`url(#${ids.gold})`} />
        <circle cx="38" cy="48.5" r="1.1" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/** 36. تاريخنا الإسلامي — قلعة إسلامية شامخة مع هلال ذهبي وراية ومخطوطة تاريخية */
export const OurHistorySectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="تاريخنا">
    {(ids) => (
      <>
        {/* أسوار القلعة التاريخية وأبراجها */}
        <path
          d="M17 44V29L20.5 29V25H23V29H27V25H29.5V29H34.5V25H37V29H41V25H43.5V29L47 29V44H17Z"
          fill={`url(#${ids.purpleDark})`}
        />
        {/* بوابة القلعة الإسلامية المقوسة بنمط حدوة الفرس */}
        <path
          d="M28 44V34C28 31.8 29.8 30 32 30C34.2 30 36 31.8 36 34V44H28Z"
          fill={`url(#${ids.gold})`}
        />
        {/* قبة المسجد التاريخي الذهبية في المنتصف خلف البرج */}
        <path
          d="M25.5 25C25.5 19.5 32 16 32 16C32 16 38.5 19.5 38.5 25H25.5Z"
          fill={`url(#${ids.gold})`}
          stroke={ids.roseGoldLight}
          strokeWidth="0.8"
        />
        {/* هلال المئذنة الشامخ */}
        <circle cx="32" cy="13.2" r="2.2" fill={`url(#${ids.gold})`} />
        {/* راية التاريخ الخضراء/الذهبية */}
        <path d="M22 25V17M22 17L16.5 19.5L22 22" stroke={`url(#${ids.gold})`} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
        {/* خطوط أحجار الأسوار التاريخية المتقنة */}
        <path d="M19 35H25M39 35H45M21 40H26M38 40H43" stroke={ids.roseGoldLight} strokeWidth="1" strokeLinecap="round" opacity="0.85" />
      </>
    )}
  </RifqMedallionBase>
);

/** 37. ركن الدعاء — كفّان مرفوعان بالضراعة والمناجاة مع أنوار وبركات وهلال مضيء */
export const DuaCornerSectionSvg: React.FC<SectionIconProps> = ({ size = 48, className = '' }) => (
  <RifqMedallionBase size={size} className={className} label="ركن الدعاء">
    {(ids) => (
      <>
        {/* هالة النور الذهبية المنبعثة من الدعاء */}
        <circle cx="32" cy="22" r="11" fill={`url(#${ids.gold})`} opacity="0.22" />
        
        {/* أشعة النور الصاعدة */}
        <path d="M32 14V10M24 16L21 13M40 16L43 13" stroke={`url(#${ids.gold})`} strokeWidth="1.4" strokeLinecap="round" />

        {/* هلال ونجمة الإجابة في الأعلى */}
        <path
          d="M34 14C34 11.2 31.8 9 29 9C28.2 9 27.5 9.2 26.8 9.5C28.2 10.5 29.2 12.1 29.2 14C29.2 15.9 28.2 17.5 26.8 18.5C27.5 18.8 28.2 19 29 19C31.8 19 34 16.8 34 14Z"
          fill={`url(#${ids.gold})`}
        />
        <circle cx="34.5" cy="11.5" r="1.1" fill={ids.roseGoldLight} />

        {/* الكف الأيمن بالدعاء */}
        <path
          d="M20 41C18 36 21 28 25 24C26.5 22.5 28 23 28.5 24.5C29 26 27.5 28.5 26.5 30.5L30 27C31 26 32.5 26.5 32.5 28C32.5 29.5 30.5 32 29.5 33.5L32 32C33 31.5 34 32.5 33.5 34C32.8 36.2 30.5 41 27 43C24 44.5 20.8 43.5 20 41Z"
          fill={`url(#${ids.purple})`}
        />

        {/* الكف الأيسر بالدعاء */}
        <path
          d="M44 41C46 36 43 28 39 24C37.5 22.5 36 23 35.5 24.5C35 26 36.5 28.5 37.5 30.5L34 27C33 26 31.5 26.5 31.5 28C31.5 29.5 33.5 32 34.5 33.5L32 32C31 31.5 30 32.5 30.5 34C31.2 36.2 33.5 41 37 43C40 44.5 43.2 43.5 44 41Z"
          fill={`url(#${ids.purpleDark})`}
        />

        {/* خطوط اتصال الكفين وتلاقي الضراعة */}
        <path d="M26 43C30 45 34 45 38 43" stroke={`url(#${ids.gold})`} strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="32" cy="27" r="1.8" fill={`url(#${ids.gold})`} />
      </>
    )}
  </RifqMedallionBase>
);

/**
 * حاوية دائرة الأيقونة الموحدة للقوائم والأقسام
 */
export const RifqMenuIconCircle: React.FC<{
  screenId: ScreenType;
  circleSize?: number;
  iconSize?: number;
  isActive?: boolean;
  className?: string;
}> = ({ screenId, circleSize = 38, iconSize = 34, isActive = false, className = '' }) => {
  const { isGirly } = useSafeTheme();
  return (
    <span
      style={{
        width: circleSize,
        height: circleSize,
        filter: isActive
          ? isGirly
            ? 'drop-shadow(0 2px 6px rgba(185, 140, 200, 0.32))'
            : 'drop-shadow(0 2px 6px rgba(91, 95, 239, 0.22))'
          : undefined,
      }}
      className={`rounded-full flex items-center justify-center shrink-0 transition-all duration-200 ${
        isActive ? 'scale-105' : ''
      } ${className}`}
    >
      <RifqSectionIcon screenId={screenId} size={iconSize} />
    </span>
  );
};

/**
 * أيقونات أوقات التحية والأوراد بصيغة SVG متناسقة تتفاعل لحظياً مع الثيم النشط
 */
export const GreetingTimeIcon: React.FC<{
  period: 'morning' | 'noon' | 'evening' | 'night';
  size?: number;
  className?: string;
}> = ({ period, size = 24, className = '' }) => {
  const { themeId, isGirly } = useSafeTheme();
  const primaryStroke = isGirly ? '#D98FA8' : '#5B5FEF';
  const roseGoldColor = isGirly ? '#CFA06A' : '#E8B84A';
  const lavenderColor = isGirly ? '#B98CC8' : '#72B7E8';

  if (period === 'morning' || period === 'noon') {
    return (
      <svg
        key={`greeting-${period}-${themeId}`}
        width={size}
        height={size}
        viewBox="0 0 28 28"
        fill="none"
        data-rifq-icon-theme={themeId}
        className={className}
      >
        <circle
          cx="14"
          cy="14"
          r="5.5"
          fill={roseGoldColor}
          fillOpacity="0.35"
          stroke={primaryStroke}
          strokeWidth="1.7"
        />
        <path
          d="M14 4V6.5M14 21.5V24M4 14H6.5M21.5 14H24M7 7L8.8 8.8M19.2 19.2L21 21M21 7L19.2 8.8M8.8 19.2L7 21"
          stroke={roseGoldColor}
          strokeWidth="1.7"
          strokeLinecap="round"
        />
      </svg>
    );
  }
  return (
    <svg
      key={`greeting-${period}-${themeId}`}
      width={size}
      height={size}
      viewBox="0 0 28 28"
      fill="none"
      data-rifq-icon-theme={themeId}
      className={className}
    >
      <path
        d="M18.5 7.5A6.5 6.5 0 1 1 11.5 18.5A5 5 0 1 0 18.5 7.5Z"
        fill={lavenderColor}
        fillOpacity="0.38"
        stroke={primaryStroke}
        strokeWidth="1.7"
      />
      <circle cx="20" cy="9" r="1.3" fill={roseGoldColor} />
    </svg>
  );
};

export const WardTypeIcon: React.FC<{
  type: WardType;
  size?: number;
  className?: string;
}> = ({ type, size = 24, className = '' }) => {
  switch (type) {
    case 'morning':
      return <GreetingTimeIcon period="morning" size={size} className={className} />;
    case 'evening':
      return <GreetingTimeIcon period="evening" size={size} className={className} />;
    case 'sleep':
      return <GreetingTimeIcon period="night" size={size} className={className} />;
    case 'prayer':
    default:
      return <TasbeehSectionSvg size={size} className={className} />;
  }
};

/**
 * مكوّن موحّد يعرض أيقونة SVG الاحترافية لكل قسم من أقسام «رِفْق | RIFQ»
 */
export const RifqSectionIcon: React.FC<{
  screenId: ScreenType | string;
  size?: number;
  className?: string;
}> = ({ screenId, size = 48, className = '' }) => {
  switch (screenId) {
    case 'tasbeeh':
      return <TasbeehSectionSvg size={size} className={className} />;
    case 'prayers':
      return <PrayersSectionSvg size={size} className={className} />;
    case 'quran':
      return <QuranSectionSvg size={size} className={className} />;
    case 'quran_audio':
      return <QuranAudioSectionSvg size={size} className={className} />;
    case 'wird':
    case 'ward':
      return <WirdSectionSvg size={size} className={className} />;
    case 'gharib_quran':
      return <GharibSectionSvg size={size} className={className} />;
    case 'tajweed':
      return <TajweedSectionSvg size={size} className={className} />;
    case 'tadabbur':
      return <TadabburSectionSvg size={size} className={className} />;
    case 'hadith':
      return <HadithSectionSvg size={size} className={className} />;
    case 'arbain_nawawiya':
      return <ArbainNawawiyaSectionSvg size={size} className={className} />;
    case 'zakat_mawarith':
      return <ZakatMawarithSectionSvg size={size} className={className} />;
    case 'hijri_fasting':
      return <HijriFastingSectionSvg size={size} className={className} />;
    case 'hajj_umrah':
      return <HajjUmrahSectionSvg size={size} className={className} />;
    case 'ruqyah_medicine':
      return <RuqyahMedicineSectionSvg size={size} className={className} />;
    case 'companions_stories':
      return <CompanionsStoriesSectionSvg size={size} className={className} />;
    case 'prophetic_biography':
      return <PropheticBiographySectionSvg size={size} className={className} />;
    case 'wasaya':
      return <WasayaSectionSvg size={size} className={className} />;
    case 'kids_stories':
      return <KidsStoriesSectionSvg size={size} className={className} />;
    case 'fiqh_muyassar':
      return <FiqhMuyassarSectionSvg size={size} className={className} />;
    case 'athkar':
    case 'hisn_almuslim':
    case 'moment_dhikr':
      return <AthkarSectionSvg size={size} className={className} />;
    case 'graduation':
      return <GraduationSectionSvg size={size} className={className} />;
    case 'wudu_prayer':
      return <WuduPrayerSectionSvg size={size} className={className} />;
    case 'athar_tayyib':
      return <AtharTayyibSectionSvg size={size} className={className} />;
    case 'amana':
      return <AmanaSectionSvg size={size} className={className} />;
    case 'harvest':
      return <HarvestSectionSvg size={size} className={className} />;
    case 'journey':
      return <JourneySectionSvg size={size} className={className} />;
    case 'daily_reminders':
      return <DailyRemindersSectionSvg size={size} className={className} />;
    case 'muslim_woman':
      return <MuslimWomanSectionSvg size={size} className={className} />;
    case 'stats':
      return <StatsSectionSvg size={size} className={className} />;
    case 'profile':
      return <ProfileSectionSvg size={size} className={className} />;
    case 'asmaa_allah':
      return <AsmaaAllahSectionSvg size={size} className={className} />;
    case 'our_history':
      return <OurHistorySectionSvg size={size} className={className} />;
    case 'dua_corner':
      return <DuaCornerSectionSvg size={size} className={className} />;
    case 'settings':
      return <SettingsSectionSvg size={size} className={className} />;
    case 'credits':
      return <CreditsSectionSvg size={size} className={className} />;
    case 'admin':
      return <SettingsSectionSvg size={size} className={className} />;
    case 'home':
    default:
      return <HomeSectionSvg size={size} className={className} />;
  }
};
