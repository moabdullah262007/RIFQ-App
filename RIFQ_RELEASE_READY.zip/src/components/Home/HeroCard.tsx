import React, { useState, useEffect } from 'react';
import { Copy, Share2, Check, RefreshCw } from 'lucide-react';
import { ScreenType, WardType } from '../../types';
import { soundManager } from '../../utils/audio';

export interface DailyWisdomItem {
  id: string;
  category: 'dhikr' | 'advice';
  badgeTitle: string;
  text: string;
  source: string;
  virtue?: string;
}

interface RippleEffect {
  id: number;
  x: number;
  y: number;
  size: number;
}

export const DAILY_WISDOM_ITEMS: DailyWisdomItem[] = [
  {
    id: '1',
    category: 'dhikr',
    badgeTitle: 'ذكر اليوم',
    text: '«سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ»',
    source: 'متفق عليه',
    virtue: 'حبيبتانِ إلى الرَّحمن، خفيفتانِ على اللسان، ثقيلتانِ في الميزان'
  },
  {
    id: '2',
    category: 'advice',
    badgeTitle: 'نصيحة اليوم',
    text: '«احْرِصْ عَلَىٰ مَا يَنْفَعُكَ، وَاسْتَعِنْ بِاللَّهِ وَلَا تَعْجَزْ»',
    source: 'صحيح مسلم',
    virtue: 'وصية نبوية جامعة للهمّة العالية والاستعانة بالخالق عز وجل'
  },
  {
    id: '3',
    category: 'dhikr',
    badgeTitle: 'ذكر اليوم',
    text: '«لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ»',
    source: 'متفق عليه',
    virtue: 'كنزٌ من كنوز الجنة وباب عظيم لتيسير الأمور وانشراح الصدر'
  },
  {
    id: '4',
    category: 'advice',
    badgeTitle: 'نصيحة اليوم',
    text: '«اتَّقِ اللَّهَ حَيْثُمَا كُنْتَ، وَأَتْبِعِ السَّيِّئَةَ الْحَسَنَةَ تَمْحُهَا، وَخَالِقِ النَّاسَ بِخُلُقٍ حَسَنٍ»',
    source: 'جامع الترمذي',
    virtue: 'قاعدة الحياة السعيدة في معاملة الله والنفس والناس'
  },
  {
    id: '5',
    category: 'dhikr',
    badgeTitle: 'ذكر اليوم',
    text: '«أَسْتَغْفِرُ اللَّهَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيَّ الْقَيُّومَ وَأَتُوبُ إِلَيْهِ»',
    source: 'سنن أبي داود والترمذي',
    virtue: 'من قالها غُفرت ذنوبه وإن كان فرَّ من الزحف'
  },
  {
    id: '6',
    category: 'advice',
    badgeTitle: 'نصيحة اليوم',
    text: '«عَجَبًا لِأَمْرِ الْمُؤْمِنِ، إِنَّ أَمْرَهُ كُلَّهُ خَيْرٌ؛ إِنْ أَصَابَتْهُ سَرَّاءُ شَكَرَ فَكَانَ خَيْرًا لَهُ، وَإِنْ أَصَابَتْهُ ضَرَّاءُ صَبَرَ فَكَانَ خَيْرًا لَهُ»',
    source: 'صحيح مسلم',
    virtue: 'سكينة القلب والرضا بقضاء الله في كل حين'
  },
  {
    id: '7',
    category: 'dhikr',
    badgeTitle: 'ذكر اليوم',
    text: '«اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ»',
    source: 'صحيح البخاري (سيد الاستغفار)',
    virtue: 'من قالها موقناً بها فمات من يومه أو ليلته دخل الجنة'
  },
  {
    id: '8',
    category: 'advice',
    badgeTitle: 'نصيحة اليوم',
    text: '«مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الْآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ»',
    source: 'متفق عليه',
    virtue: 'حفظ اللسان مفتاح السلامة وركيزة الخلق الرفيع'
  }
];

interface HeroCardProps {
  onNavigate?: (screen: ScreenType) => void;
  onSelectWard?: (wardType: WardType) => void;
  onShowToast?: (message: string) => void;
}

export const HeroCard: React.FC<HeroCardProps> = ({
  onNavigate,
  onShowToast
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);
  const [isRotating, setIsRotating] = useState<boolean>(false);
  const [filter, setFilter] = useState<'all' | 'dhikr' | 'advice'>('all');
  
  // Ripple effects state for buttons and card
  const [ripples, setRipples] = useState<{ [btnId: string]: RippleEffect[] }>({});

  // Helper to trigger ripple
  const triggerRipple = (e: React.MouseEvent<HTMLElement>, key: string) => {
    const target = e.currentTarget;
    const rect = target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const size = Math.max(rect.width, rect.height) * 2;
    const id = Date.now() + Math.random();

    setRipples((prev) => ({
      ...prev,
      [key]: [...(prev[key] || []).slice(-2), { id, x, y, size }]
    }));

    setTimeout(() => {
      setRipples((prev) => ({
        ...prev,
        [key]: (prev[key] || []).filter((r) => r.id !== id)
      }));
    }, 600);
  };

  // Load daily item based on day of year by default
  useEffect(() => {
    try {
      const now = new Date();
      const start = new Date(now.getFullYear(), 0, 0);
      const diff = now.getTime() - start.getTime();
      const oneDay = 1000 * 60 * 60 * 24;
      const dayOfYear = Math.floor(diff / oneDay);
      const initialIdx = dayOfYear % DAILY_WISDOM_ITEMS.length;
      setCurrentIndex(initialIdx);
    } catch {
      setCurrentIndex(0);
    }
  }, []);

  const filteredItems = filter === 'all' 
    ? DAILY_WISDOM_ITEMS 
    : DAILY_WISDOM_ITEMS.filter((item) => item.category === filter);

  const currentItem = filteredItems[currentIndex % filteredItems.length] || DAILY_WISDOM_ITEMS[0];

  const handleNext = (e: React.MouseEvent<HTMLButtonElement>) => {
    triggerRipple(e, 'next');

    // Subtle haptic
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try { navigator.vibrate(25); } catch {}
    }
    soundManager.triggerHaptic(25);

    setIsRotating(true);
    setCurrentIndex((prev) => (prev + 1) % filteredItems.length);
    setTimeout(() => setIsRotating(false), 300);
  };

  const handleCopy = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    triggerRipple(e, 'copy');

    // Haptic feedback
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try { navigator.vibrate(35); } catch {}
    }
    soundManager.triggerHaptic(35);

    const fullShareText = `${currentItem.text}\n\nالمصدر: ${currentItem.source}${currentItem.virtue ? `\nالفضل: ${currentItem.virtue}` : ''}\n— من تطبيق رِفْـق | RIFQ`;

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(fullShareText);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = fullShareText;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      if (onShowToast) {
        onShowToast('تم نسخ الذكر بنجاح');
      }
      setTimeout(() => setCopied(false), 2000);
    } catch {
      if (onShowToast) {
        onShowToast('تم نسخ الذكر بنجاح');
      }
    }
  };

  const handleShare = async (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    triggerRipple(e, 'share');

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try { navigator.vibrate(35); } catch {}
    }
    soundManager.triggerHaptic(35);

    const fullShareText = `${currentItem.text}\n\nالمصدر: ${currentItem.source}${currentItem.virtue ? `\n${currentItem.virtue}` : ''}\n— عبر تطبيق رِفْـق | RIFQ`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: currentItem.badgeTitle,
          text: fullShareText,
          url: window.location.href
        });
      } catch {
        // User dismissed or share error
      }
    } else {
      await handleCopy(e);
      if (onShowToast) {
        onShowToast('تم نسخ النص لمشاركته عبر تطبيقاتك');
      }
    }
  };

  return (
    <section 
      id="hero-card-daily-wisdom"
      aria-label="بطاقة ذكر ونصيحة اليوم"
      className="relative w-full bg-[#FFFFFF] rounded-[22px] overflow-hidden border border-[#E6E6F0] shadow-[0_4px_20px_rgba(37,38,58,0.05)] hover:shadow-[0_8px_28px_rgba(91,95,239,0.10)] transition-all duration-300 select-none text-right animate-fade-in group"
      dir="rtl"
    >
      {/* Top Modern Highlighting Bar */}
      <div className="absolute top-0 right-0 left-0 h-[3.5px] bg-gradient-to-r from-[#5B5FEF] via-[#72B7E8] to-[#E8B84A]" />

      {/* Decorative Islamic Arch & Minaret Silhouette Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] flex items-end justify-start overflow-hidden">
        <svg
          viewBox="0 0 500 200"
          className="w-[320px] h-[170px] text-[#5B5FEF] fill-current transform translate-y-3 -translate-x-4"
          preserveAspectRatio="none"
        >
          <path d="M 50,200 L 50,90 L 70,90 L 70,60 L 60,60 L 60,40 L 75,20 L 90,40 L 90,60 L 80,60 L 80,90 L 100,90 L 100,200 Z" />
          <path d="M 120,200 L 120,120 Q 180,50 240,120 L 240,200 Z" />
          <path d="M 230,200 L 230,70 L 250,70 L 250,45 L 240,45 L 240,25 L 255,10 L 270,25 L 270,45 L 260,45 L 260,70 L 280,70 L 280,200 Z" />
          <circle cx="180" cy="45" r="5" />
          <path d="M 180,35 L 180,45" stroke="currentColor" strokeWidth="2" />
          <path d="M 270,200 L 270,140 Q 320,90 370,140 L 370,200 Z" />
        </svg>
      </div>

      {/* Subtle Ambient Glow Circles */}
      <div className="absolute -top-12 -left-12 w-40 h-40 rounded-full bg-[#5B5FEF]/8 blur-2xl pointer-events-none" />
      <div className="absolute -bottom-10 -right-10 w-36 h-36 rounded-full bg-[#72B7E8]/10 blur-xl pointer-events-none" />

      {/* Card Inner Content */}
      <div className="relative z-10 p-4 sm:p-5 flex flex-col justify-between gap-3.5">
        
        {/* Header: Filter Chips & Next/Refresh Button */}
        <div className="flex items-center justify-between gap-2 border-b border-[#E6E6F0] pb-2.5">
          {/* Category Filter Chips */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              id="hero-filter-all"
              onClick={(e) => {
                triggerRipple(e, 'filter-all');
                setFilter('all');
                setCurrentIndex(0);
              }}
              className={`relative overflow-hidden inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                filter === 'all'
                  ? 'bg-[#5B5FEF] text-white shadow-2xs'
                  : 'bg-[#EEEEFF] text-[#4145C7] hover:bg-[#E2E2FF]'
              }`}
            >
              <span>الكل</span>
              {ripples['filter-all']?.map((r) => (
                <span
                  key={r.id}
                  className="absolute rounded-full bg-white/40 pointer-events-none animate-ripple"
                  style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
                />
              ))}
            </button>

            <button
              type="button"
              id="hero-filter-dhikr"
              onClick={(e) => {
                triggerRipple(e, 'filter-dhikr');
                setFilter('dhikr');
                setCurrentIndex(0);
              }}
              className={`relative overflow-hidden inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                filter === 'dhikr'
                  ? 'bg-[#5B5FEF] text-white shadow-2xs'
                  : 'bg-[#EEEEFF] text-[#4145C7] hover:bg-[#E2E2FF]'
              }`}
            >
              <span>أذكار</span>
              {ripples['filter-dhikr']?.map((r) => (
                <span
                  key={r.id}
                  className="absolute rounded-full bg-white/40 pointer-events-none animate-ripple"
                  style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
                />
              ))}
            </button>

            <button
              type="button"
              id="hero-filter-advice"
              onClick={(e) => {
                triggerRipple(e, 'filter-advice');
                setFilter('advice');
                setCurrentIndex(0);
              }}
              className={`relative overflow-hidden inline-flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                filter === 'advice'
                  ? 'bg-[#5B5FEF] text-white shadow-2xs'
                  : 'bg-[#EEEEFF] text-[#4145C7] hover:bg-[#E2E2FF]'
              }`}
            >
              <span>نصائح</span>
              {ripples['filter-advice']?.map((r) => (
                <span
                  key={r.id}
                  className="absolute rounded-full bg-white/40 pointer-events-none animate-ripple"
                  style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
                />
              ))}
            </button>
          </div>

          {/* Refresh / Next Button with Ripple */}
          <button
            type="button"
            id="hero-btn-next-wisdom"
            onClick={handleNext}
            title="تبديل إلى نصيحة أو ذكر آخر"
            aria-label="تبديل إلى ذكر أو نصيحة أخرى"
            className="relative overflow-hidden flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#EEEEFF] hover:bg-[#E2E2FF] text-[#4145C7] text-xs font-bold transition-all active:scale-95 cursor-pointer group"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#5B5FEF] transition-transform duration-300 ${isRotating ? 'rotate-180 text-[#4145C7]' : 'group-hover:rotate-45'}`} />
            <span className="text-xs font-black">ذكر آخر</span>
            {ripples['next']?.map((r) => (
              <span
                key={r.id}
                className="absolute rounded-full bg-[#5B5FEF]/20 pointer-events-none animate-ripple"
                style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
              />
            ))}
          </button>
        </div>

        {/* Center: Main Dhikr / Advice Text */}
        <div className="py-1">
          {/* Kicker Label */}
          <div className="flex items-center gap-1.5 text-[#5B5FEF] font-black text-xs mb-2">
            <span className="w-2 h-2 rounded-full bg-[#E8B84A] inline-block" />
            <span className="tracking-wide">{currentItem.badgeTitle}</span>
          </div>

          {/* Primary Sacred Text */}
          <blockquote className="text-base sm:text-lg md:text-[20px] font-bold text-[#25263A] leading-relaxed font-amiri tracking-wide select-text py-1">
            {currentItem.text}
          </blockquote>

          {/* Reference & Virtue Footer */}
          <div className="mt-2.5 flex items-center justify-between flex-wrap gap-2 text-xs text-[#77798C]">
            <span className="font-bold text-[#4145C7]">
              {currentItem.source}
            </span>
            {currentItem.virtue && (
              <span className="text-[#77798C] font-medium text-[12px] truncate max-w-xs sm:max-w-md">
                {currentItem.virtue}
              </span>
            )}
          </div>
        </div>

        {/* Footer: Action Buttons */}
        <div className="flex items-center justify-between gap-2.5 pt-2.5 border-t border-[#E6E6F0]">
          {/* Quick Tasbeeh link if available */}
          {onNavigate && (
            <button
              type="button"
              id="hero-btn-goto-tasbeeh"
              onClick={(e) => {
                triggerRipple(e, 'tasbeeh');
                onNavigate('tasbeeh');
              }}
              className="relative overflow-hidden text-xs text-[#4145C7] hover:text-[#5B5FEF] font-bold inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg hover:bg-[#EEEEFF] transition-colors cursor-pointer"
            >
              <span>تسبيح بالمسبحة</span>
              {ripples['tasbeeh']?.map((r) => (
                <span
                  key={r.id}
                  className="absolute rounded-full bg-[#5B5FEF]/20 pointer-events-none animate-ripple"
                  style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
                />
              ))}
            </button>
          )}

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2 mr-auto">
            {/* 1. زر النسخ (Secondary Button: #EEEEFF / #4145C7) */}
            <button
              type="button"
              id="hero-btn-copy"
              onClick={handleCopy}
              aria-label="نسخ الذكر"
              className="relative overflow-hidden inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#EEEEFF] hover:bg-[#E2E2FF] text-[#4145C7] font-black text-xs transition-all active:scale-95 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-[#4CAF82] stroke-[2.5]" />
                  <span className="text-[#4CAF82] font-black">تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-[#4145C7]" />
                  <span>نسخ</span>
                </>
              )}
              {ripples['copy']?.map((r) => (
                <span
                  key={r.id}
                  className="absolute rounded-full bg-[#5B5FEF]/20 pointer-events-none animate-ripple"
                  style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
                />
              ))}
            </button>

            {/* 2. زر المشاركة (Primary Button: #5B5FEF / #FFFFFF) */}
            <button
              type="button"
              id="hero-btn-share"
              onClick={handleShare}
              aria-label="مشاركة الذكر"
              className="relative overflow-hidden inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs shadow-2xs transition-all active:scale-95 cursor-pointer"
            >
              <Share2 className="w-4 h-4 text-white" />
              <span>مشاركة</span>
              {ripples['share']?.map((r) => (
                <span
                  key={r.id}
                  className="absolute rounded-full bg-white/40 pointer-events-none animate-ripple"
                  style={{ left: r.x, top: r.y, width: r.size, height: r.size }}
                />
              ))}
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};

