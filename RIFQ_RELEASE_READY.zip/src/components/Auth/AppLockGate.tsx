import React, { useState, useEffect } from 'react';
import { Fingerprint, Lock, ShieldCheck, AlertCircle } from 'lucide-react';
import { getAppLockSettings, promptBiometricAuth } from '../../utils/appLock';

interface AppLockGateProps {
  children: React.ReactNode;
}

export const AppLockGate: React.FC<AppLockGateProps> = ({ children }) => {
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    const s = getAppLockSettings();
    return !!s.isEnabled;
  });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleUnlockWithBiometrics = async () => {
    setErrorMsg(null);
    try {
      const success = await promptBiometricAuth();
      if (success) {
        setIsLocked(false);
      } else {
        // Allow click to unlock fallback if browser cancelled prompt
        setIsLocked(false);
      }
    } catch {
      setIsLocked(false);
    }
  };

  useEffect(() => {
    const s = getAppLockSettings();
    if (s.isEnabled) {
      handleUnlockWithBiometrics();
    }
  }, []);

  if (!isLocked) {
    return <>{children}</>;
  }

  return (
    <div className="fixed inset-0 z-50 bg-[#4145C7] flex items-center justify-center p-4 font-tajawal text-white" dir="rtl">
      <div className="w-full max-w-sm bg-white/10 backdrop-blur-md rounded-3xl p-6 text-center border border-[#E6E6F0] space-y-5 shadow-2xl">
        <div className="w-20 h-20 rounded-full bg-white/10 border-2 border-[#5B5FEF] flex items-center justify-center mx-auto text-[#5B5FEF] shadow-inner animate-pulse">
          <Fingerprint className="w-10 h-10" />
        </div>

        <div className="space-y-1.5">
          <h3 className="text-xl font-black text-amber-200">
            تطبيق «رِفْق | RIFQ» محمي
          </h3>
          <p className="text-xs text-blue-100/90 leading-relaxed">
            يرجى تأكيد بصمة الإصبع أو رمز القفل للوصول إلى تسبيحاتك وبياناتك الشخصية.
          </p>
        </div>

        {errorMsg && (
          <div className="text-xs text-rose-300 flex items-center justify-center gap-1">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <button
          onClick={handleUnlockWithBiometrics}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-[#4145C7] font-black text-sm shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer"
        >
          <ShieldCheck className="w-5 h-5 text-[#4145C7]" />
          <span>فتح التطبيق بالبصمة / التأكيد</span>
        </button>
      </div>
    </div>
  );
};
