import React, { useState, useEffect, useMemo } from 'react';
import {
  Menu,
  Plus,
  Users,
  Search,
  Globe,
  Lock,
  X,
  CheckCircle2,
  AlertCircle,
  User,
  LogOut,
  Send,
  MessageCircle,
  Loader2,
} from 'lucide-react';
import { ScreenType, WardType } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { getTodayDateString } from '../../utils/storage';
import {
  WirdGroupDoc,
  WirdPlanType,
  QURAN_SURAH_OPTIONS,
  loadCachedWirdGroups,
  fetchAllRealWirdGroups,
  fetchWirdGroupByJoinCode,
  createRealWirdGroup,
  joinByCode,
  redistributeParts,
  completeMemberWirdReading,
  postWirdGroupMessage,
  advanceGroupDay,
  promoteGroupMemberToAdmin,
  removeGroupMemberAndRedistribute,
  handleGroupJoinRequest,
  updateWirdGroupSettings,
  deleteWirdGroup,
  getPlanLabel,
  resolveEffectiveMemberUserId,
  subscribeToWirdGroupRealtime,
} from '../../utils/wirdService';
import {
  getPendingWirdInviteCode,
  savePendingWirdInviteCode,
  clearPendingWirdInviteCode,
  extractWirdInviteCodeFromUrl,
  clearWirdInviteQueryFromWindowUrl,
  sanitizeWirdInviteCode,
} from '../../utils/wirdInviteService';
import {
  WirdMushafPenSvg,
  WirdGroupSvgIcon,
  WIRD_GROUP_ICONS,
  WirdGroupIconId,
  EmptyGroupsSvg,
} from './WirdIcons';
import { WirdGroupDetailView } from './WirdGroupDetailView';
import { WirdMushafReader } from './WirdMushafReader';

interface WirdMainViewProps {
  onSelectWard?: (ward: WardType) => void;
  onNavigate?: (screen: ScreenType) => void;
}

export const WirdMainView: React.FC<WirdMainViewProps> = ({ onNavigate }) => {
  const { currentUser, userProfile, loading: authLoading, openAuthModal, logout } = useAuth();

  const currentUserId = currentUser?.uid || 'local_authenticated_reader';
  const currentUserName =
    userProfile?.displayName ||
    currentUser?.displayName ||
    currentUser?.email?.split('@')[0] ||
    'قارئ رِفْق';
  const currentUserEmail =
    userProfile?.email || currentUser?.email || 'حساب رِفْق السحابي';
  const photoUrl = userProfile?.photoURL || currentUser?.photoURL || '';

  const [groups, setGroups] = useState<WirdGroupDoc[]>(loadCachedWirdGroups);
  const [loadingGroups, setLoadingGroups] = useState<boolean>(true);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterMode, setFilterMode] = useState<'all' | 'mine' | 'public'>('all');

  // Modals & Drawers state
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState<boolean>(false);

  // Create Group Form States
  const [groupName, setGroupName] = useState('');
  const [planType, setPlanType] = useState<WirdPlanType>('khatma');
  const [customSurahName, setCustomSurahName] = useState(QURAN_SURAH_OPTIONS[0].name);
  const [customStartPage, setCustomStartPage] = useState(1);
  const [customEndPage, setCustomEndPage] = useState(604);
  const [targetDays, setTargetDays] = useState(30);
  const [startDate, setStartDate] = useState(getTodayDateString());
  const [selectedIcon, setSelectedIcon] = useState<WirdGroupIconId>('mushaf_pen');
  const [isPublicGroup, setIsPublicGroup] = useState<boolean>(true);
  const [description, setDescription] = useState('');
  const [createError, setCreateError] = useState<string | null>(null);
  const [isSubmittingCreate, setIsSubmittingCreate] = useState(false);

  // Join Group Modal States
  const [joinCodeInput, setJoinCodeInput] = useState('');
  const [joinAsFriend, setJoinAsFriend] = useState(false);
  const [friendDisplayName, setFriendDisplayName] = useState('');
  const [joinFeedback, setJoinFeedback] = useState<{
    type: 'error' | 'success';
    text: string;
  } | null>(null);
  const [isSubmittingJoin, setIsSubmittingJoin] = useState(false);
  const [invitedGroupPreview, setInvitedGroupPreview] = useState<WirdGroupDoc | null>(null);
  const [loadingGroupPreview, setLoadingGroupPreview] = useState<boolean>(false);

  // Mushaf Reader Modal State
  const [mushafReader, setMushafReader] = useState<{
    isOpen: boolean;
    startPage: number;
    endPage: number;
    title: string;
    groupId: string;
  } | null>(null);

  // Global status banner
  const [banner, setBanner] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const showBanner = (text: string, type: 'success' | 'error' = 'success') => {
    setBanner({ text, type });
    setTimeout(() => setBanner(null), 3500);
  };

  const refreshGroups = async () => {
    setLoadingGroups(true);
    const loaded = await fetchAllRealWirdGroups();
    setGroups(loaded);
    setLoadingGroups(false);
  };

  // Handle incoming invite code from URL, Android App Link / Deep Link, or pending storage
  const activateInviteJoinFlow = async (rawCode: string) => {
    const cleaned = sanitizeWirdInviteCode(rawCode);
    if (!cleaned) return;

    savePendingWirdInviteCode(cleaned);
    clearWirdInviteQueryFromWindowUrl();

    setSelectedGroupId(null);
    setJoinCodeInput(cleaned);
    setIsJoinModalOpen(true);

    if (authLoading) {
      return;
    }

    if (!currentUser) {
      setJoinFeedback({
        type: 'error',
        text: `لديك دعوة للانضمام إلى مجموعة وِرد بكود (${cleaned}). يرجى تسجيل الدخول أولاً ليتم فتح المجموعة وإضافتك إليها تلقائياً.`,
      });
      openAuthModal('login');
    } else {
      setJoinFeedback(null);
    }

    setLoadingGroupPreview(true);
    try {
      const found = await fetchWirdGroupByJoinCode(cleaned);
      setInvitedGroupPreview(found);
      if (!found && currentUser) {
        setJoinFeedback({
          type: 'error',
          text: 'كود الدعوة غير صالح',
        });
      }
    } finally {
      setLoadingGroupPreview(false);
    }
  };

  useEffect(() => {
    void refreshGroups();

    const urlCode = extractWirdInviteCodeFromUrl();
    const pendingCode = getPendingWirdInviteCode();
    const targetCode = urlCode || pendingCode;
    if (targetCode) {
      void activateInviteJoinFlow(targetCode);
    }

    const handleDeepLinkEvent = (e: Event) => {
      const customEv = e as CustomEvent<{ inviteCode?: string }>;
      const code = customEv.detail?.inviteCode || getPendingWirdInviteCode();
      if (code) {
        void activateInviteJoinFlow(code);
      }
    };

    window.addEventListener('rifq-wird-invite-deep-link', handleDeepLinkEvent);
    return () => {
      window.removeEventListener('rifq-wird-invite-deep-link', handleDeepLinkEvent);
    };
  }, []);

  // Automatically resume pending invite flow as soon as user logs in
  useEffect(() => {
    if (authLoading) return;
    if (currentUser) {
      void refreshGroups();
      const pendingCode = getPendingWirdInviteCode();
      if (pendingCode) {
        void activateInviteJoinFlow(pendingCode);
      }
    }
  }, [currentUser?.uid, authLoading]);

  // Live Firestore lookup when typing/pasting a 6-character invite code in the Join Modal
  useEffect(() => {
    if (!isJoinModalOpen) {
      setInvitedGroupPreview(null);
      setLoadingGroupPreview(false);
      return;
    }
    const cleaned = sanitizeWirdInviteCode(joinCodeInput);
    if (cleaned.length < 4) {
      setInvitedGroupPreview(null);
      setLoadingGroupPreview(false);
      return;
    }

    let cancelled = false;
    setLoadingGroupPreview(true);
    const timer = window.setTimeout(async () => {
      try {
        const found = await fetchWirdGroupByJoinCode(cleaned);
        if (!cancelled) {
          setInvitedGroupPreview(found);
        }
      } finally {
        if (!cancelled) {
          setLoadingGroupPreview(false);
        }
      }
    }, 200);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [joinCodeInput, isJoinModalOpen, currentUser?.uid]);

  // Real-time Firestore listener when viewing a specific group
  useEffect(() => {
    if (!selectedGroupId) return;
    const unsub = subscribeToWirdGroupRealtime(selectedGroupId, (liveGroup) => {
      if (!liveGroup) {
        setGroups(loadCachedWirdGroups());
        setSelectedGroupId(null);
        return;
      }
      setGroups([...loadCachedWirdGroups()]);
    });
    return () => {
      unsub();
    };
  }, [selectedGroupId]);

  const selectedGroup = useMemo(
    () => groups.find((g) => g.id === selectedGroupId) || null,
    [groups, selectedGroupId]
  );

  const filteredGroups = useMemo(() => {
    return groups.filter((g) => {
      if (!g.isActive) return false;

      const isMyGroup = g.members.some((m) => m.userId === currentUserId);
      if (filterMode === 'mine' && !isMyGroup) return false;
      if (filterMode === 'public' && !g.isPublic && !isMyGroup) return false;
      if (filterMode === 'all' && !g.isPublic && !isMyGroup) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        return (
          g.groupName.toLowerCase().includes(q) ||
          g.description.toLowerCase().includes(q) ||
          g.joinCode.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [groups, filterMode, searchQuery, currentUserId]);

  // Handle Create Group Submission
  const handleCreateGroupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);

    if (!groupName.trim()) {
      setCreateError('يرجى إدخال اسم المجموعة');
      return;
    }

    if (!currentUser) {
      setCreateError('يرجى تسجيل الدخول أولاً لإنشاء مجموعة حقيقية وحفظها في قاعدة البيانات.');
      openAuthModal('login');
      return;
    }

    setIsSubmittingCreate(true);
    try {
      const created = await createRealWirdGroup({
        groupName,
        description,
        planType,
        customSurahName: planType === 'surah_custom' ? customSurahName : undefined,
        customStartPage: planType === 'custom' ? customStartPage : undefined,
        customEndPage: planType === 'custom' ? customEndPage : undefined,
        targetDays: Math.max(1, Number(targetDays) || 30),
        startDate,
        icon: selectedIcon,
        isPublic: isPublicGroup,
        adminId: currentUser.uid,
        adminName: currentUserName,
        adminAvatar: photoUrl,
      });

      setGroups(loadCachedWirdGroups());
      setIsCreateModalOpen(false);
      setGroupName('');
      setDescription('');
      setSelectedGroupId(created.id);
      showBanner(
        `تم إنشاء المجموعة «${created.groupName}» بنجاح! كود الدعوة: ${created.joinCode}`,
        'success'
      );
    } catch {
      setCreateError('حدث خطأ أثناء إنشاء المجموعة في قاعدة البيانات، يرجى المحاولة مرة أخرى');
    } finally {
      setIsSubmittingCreate(false);
    }
  };

  // Handle Join By Code Submission
  const handleJoinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setJoinFeedback(null);

    const cleanedCode = sanitizeWirdInviteCode(joinCodeInput);
    setJoinCodeInput(cleanedCode);

    if (!cleanedCode) {
      setJoinFeedback({ type: 'error', text: 'كود الدعوة غير صالح' });
      return;
    }

    if (!currentUser) {
      savePendingWirdInviteCode(cleanedCode);
      setJoinFeedback({
        type: 'error',
        text: 'يرجى تسجيل الدخول أولاً للانضمام إلى المجموعة ومزامنة وردك في قاعدة البيانات.',
      });
      openAuthModal('login');
      return;
    }

    const targetUserId = currentUser.uid;
    let targetUserName = currentUserName;

    if (joinAsFriend && friendDisplayName.trim()) {
      targetUserName = friendDisplayName.trim();
    }

    setIsSubmittingJoin(true);
    try {
      const res = await joinByCode(
        cleanedCode,
        targetUserId,
        targetUserName,
        currentUserEmail
      );

      if (res.alreadyMember && res.group) {
        clearPendingWirdInviteCode();
        const updatedList = loadCachedWirdGroups();
        setGroups(updatedList);
        setJoinFeedback({
          type: 'success',
          text: 'أنت عضو بالفعل في هذه المجموعة! جاري فتح المجموعة...',
        });
        setTimeout(() => {
          setIsJoinModalOpen(false);
          setJoinCodeInput('');
          setFriendDisplayName('');
          setJoinAsFriend(false);
          setJoinFeedback(null);
          setSelectedGroupId(res.group!.id);
        }, 600);
      } else if (res.error) {
        setJoinFeedback({ type: 'error', text: res.error });
      } else if (res.success) {
        clearPendingWirdInviteCode();
        setJoinFeedback({ type: 'success', text: res.success });
        const updatedList = loadCachedWirdGroups();
        setGroups(updatedList);

        if (res.group && !res.pending) {
          setTimeout(() => {
            setIsJoinModalOpen(false);
            setJoinCodeInput('');
            setFriendDisplayName('');
            setJoinAsFriend(false);
            setJoinFeedback(null);
            setSelectedGroupId(res.group!.id);
          }, 800);
        }
      }
    } finally {
      setIsSubmittingJoin(false);
    }
  };

  return (
    <div className="min-h-[80vh] bg-[#F7F7FC] rounded-[20px] p-3 sm:p-5 space-y-5 select-none" dir="rtl">
      {/* Global Notification Banner */}
      {banner && (
        <div
          className={`p-3.5 rounded-2xl border font-cairo font-bold text-xs sm:text-sm flex items-center justify-between gap-2 shadow-sm animate-fade-in ${
            banner.type === 'error'
              ? 'bg-[#D95C6A]/10 border-[#D95C6A] text-[#D95C6A]'
              : 'bg-[#4CAF82]/12 border-[#4CAF82] text-[#4CAF82]'
          }`}
        >
          <div className="flex items-center gap-2">
            {banner.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            )}
            <span>{banner.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setBanner(null)}
            className="cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* ── 【الشاشة 1】شريط علوي: القائمة الجانبية (ذهبي) + "وِرد | WIRD" Cairo Bold ذهبي 22px + صورة المستخدم 40px بإطار ذهبي ── */}
      <div className="bg-[#FFFFFF] rounded-[20px] px-4 py-3 border border-[#E6E6F0] shadow-xs flex items-center justify-between">
        <button
          type="button"
          onClick={() => setIsDrawerOpen(true)}
          aria-label="القائمة الجانبية لوِرد"
          className="w-10 h-10 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center text-[#4145C7] transition-colors cursor-pointer"
        >
          <Menu className="w-5 h-5 text-[#5B5FEF]" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center">
            <WirdMushafPenSvg size={22} />
          </div>
          <h1 className="font-cairo font-bold text-[22px] text-[#5B5FEF] tracking-tight">
            وِرد | WIRD
          </h1>
        </div>

        <button
          type="button"
          onClick={() => {
            if (currentUser && onNavigate) {
              onNavigate('profile');
            } else {
              openAuthModal('login');
            }
          }}
          title={currentUserName}
          className="w-[40px] h-[40px] rounded-full bg-[#F7F7FC] border-2 border-[#5B5FEF] overflow-hidden flex items-center justify-center cursor-pointer shrink-0 shadow-2xs"
        >
          {photoUrl && !photoUrl.startsWith('emoji:') ? (
            <img
              src={photoUrl}
              alt={currentUserName}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <User className="w-5 h-5 text-[#5B5FEF]" />
          )}
        </button>
      </div>

      {/* إذا تم اختيار مجموعة، اعرض 【الشاشة 4】صفحة المجموعة */}
      {selectedGroup ? (
        <WirdGroupDetailView
          group={selectedGroup}
          currentUserId={currentUserId}
          currentUserName={currentUserName}
          onBack={() => setSelectedGroupId(null)}
          onOpenMushaf={(startPage, endPage, title) =>
            setMushafReader({
              isOpen: true,
              startPage,
              endPage,
              title,
              groupId: selectedGroup.id,
            })
          }
          onCompleteMyWird={async () => {
            await completeMemberWirdReading(
              selectedGroup.id,
              currentUserId,
              currentUserName
            );
            setGroups([...loadCachedWirdGroups()]);
            showBanner('تقبل الله طاعتك! تم تسجيل إتمام وردك اليومي بنجاح');
          }}
          onRedistribute={async () => {
            await redistributeParts(
              selectedGroup.id,
              currentUserId,
              currentUserName
            );
            setGroups([...loadCachedWirdGroups()]);
          }}
          onAdvanceDay={async () => {
            const prevDay = selectedGroup.currentDay;
            const updated = await advanceGroupDay(
              selectedGroup.id,
              currentUserId,
              currentUserName
            );
            setGroups([...loadCachedWirdGroups()]);
            if (updated) {
              const effId = resolveEffectiveMemberUserId(updated, currentUserId);
              const nextMyDist =
                updated.distribution.find(
                  (d) => d.userId === effId && d.dayNumber === updated.currentDay
                ) ||
                updated.distribution.find((d) => d.dayNumber === updated.currentDay);
              const rangeText = nextMyDist
                ? ` (الصفحات ${nextMyDist.pageFrom} → ${nextMyDist.pageTo})`
                : '';
              showBanner(
                updated.currentDay === prevDay
                  ? `تم إتمام اليوم الأخير (${updated.currentDay} من ${updated.targetDays}) واكتملت الختمة بنجاح!`
                  : `تم إنهاء اليوم ${prevDay} والانتقال إلى اليوم ${updated.currentDay} من ${updated.targetDays}${rangeText}`,
                'success'
              );
            }
          }}
          onSendMessage={async (message, category) => {
            await postWirdGroupMessage({
              groupId: selectedGroup.id,
              userId: currentUserId,
              userName: currentUserName,
              message,
              category,
            });
            setGroups(loadCachedWirdGroups());
          }}
          onPromoteMember={async (targetUserId) => {
            await promoteGroupMemberToAdmin(
              selectedGroup.id,
              targetUserId,
              currentUserId,
              currentUserName
            );
            setGroups(loadCachedWirdGroups());
          }}
          onRemoveMember={async (targetUserId) => {
            await removeGroupMemberAndRedistribute(
              selectedGroup.id,
              targetUserId,
              currentUserId,
              currentUserName
            );
            setGroups(loadCachedWirdGroups());
          }}
          onHandleJoinRequest={async (requestId, approve) => {
            await handleGroupJoinRequest({
              groupId: selectedGroup.id,
              requestId,
              approve,
              adminId: currentUserId,
              adminName: currentUserName,
            });
            setGroups(loadCachedWirdGroups());
          }}
          onUpdateSettings={async (updates) => {
            await updateWirdGroupSettings(
              selectedGroup.id,
              updates,
              currentUserId,
              currentUserName
            );
            setGroups(loadCachedWirdGroups());
          }}
          onDeleteGroup={async () => {
            await deleteWirdGroup(selectedGroup.id);
            setGroups(loadCachedWirdGroups());
            setSelectedGroupId(null);
            showBanner('تم حذف المجموعة نهائياً');
          }}
          onOpenJoinModal={(prefillCode) => {
            setJoinFeedback(null);
            setJoinCodeInput((prefillCode || '').replace(/\s+/g, '').toUpperCase());
            setIsJoinModalOpen(true);
          }}
        />
      ) : (
        /* ── 【الشاشة 1】شاشة المجموعات الرئيسية ── */
        <div className="space-y-5">
          {/* ■ زرا "إنشاء مجموعة جديدة" (48%) و "الانضمام بمجموعة" (48%) */}
          <div className="flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => {
                setCreateError(null);
                setIsCreateModalOpen(true);
              }}
              className="w-[48%] py-3.5 px-3 rounded-[16px] bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] hover:brightness-105 text-[#FFFFFF] font-cairo font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <span className="w-6 h-6 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shrink-0">
                <Plus className="w-4 h-4 text-[#5B5FEF]" />
              </span>
              <span>إنشاء مجموعة جديدة</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setJoinFeedback(null);
                setJoinCodeInput('');
                setIsJoinModalOpen(true);
              }}
              className="w-[48%] py-3.5 px-3 rounded-[16px] bg-[#4CAF82] hover:bg-[#4145C7] text-[#FFFFFF] font-cairo font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <span className="w-6 h-6 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shrink-0">
                <Users className="w-3.5 h-3.5 text-[#4CAF82]" />
              </span>
              <span>الانضمام بمجموعة</span>
            </button>
          </div>

          {/* ■ شريط البحث: خلفية بيج + إطار ذهبي عند التركيز + تصفية فورية */}
          <div className="space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 text-[#5B5FEF] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن مجموعة..."
                className="w-full pr-10 pl-4 py-3 rounded-[16px] bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:ring-2 focus:ring-[#5B5FEF]/30 focus:outline-none font-cairo text-sm text-[#25263A] placeholder:text-[#77798C]"
              />
            </div>

            {/* تبويبات التصفية */}
            <div className="flex items-center gap-2">
              {(
                [
                  { id: 'all', label: 'كل المجموعات' },
                  { id: 'mine', label: 'مجموعاتي' },
                  { id: 'public', label: 'المجموعات العامة' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilterMode(tab.id)}
                  className={`px-3.5 py-1.5 rounded-xl font-cairo font-bold text-xs border transition-colors cursor-pointer ${
                    filterMode === tab.id
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                      : 'bg-[#FFFFFF] text-[#25263A] border-[#E6E6F0] hover:bg-[#F7F7FC]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* ■ قائمة المجموعات أو الحالة الفارغة */}
          {loadingGroups ? (
            <div className="bg-[#FFFFFF] rounded-[20px] p-10 border border-[#E6E6F0] flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-[#5B5FEF]" />
              <p className="font-cairo font-bold text-sm text-[#25263A]">
                جاري مزامنة المجموعات من قاعدة البيانات...
              </p>
            </div>
          ) : filteredGroups.length === 0 ? (
            /* حالة فارغة: أيقونة SVG 64px + "لا توجد مجموعات بعد" + زر "إنشاء مجموعة جديدة" */
            <div className="bg-[#FFFFFF] rounded-[20px] p-8 sm:p-10 border border-[#E6E6F0] flex flex-col items-center justify-center text-center space-y-4 shadow-xs">
              <EmptyGroupsSvg size={64} />
              <div className="space-y-1">
                <h3 className="font-cairo font-bold text-lg text-[#25263A]">
                  لا توجد مجموعات بعد
                </h3>
                <p className="font-cairo text-xs text-[#77798C] max-w-sm">
                  أنشئ مجموعتك القرآنية الأولى الآن أو انضم بمجموعة عبر كود الدعوة ليبدأ النظام بتوزيع الأجزاء تلقائياً بالتساوي.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(true)}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-cairo font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إنشاء مجموعة جديدة</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {filteredGroups.map((group) => {
                const activeMembers = group.members.filter(
                  (m) => m.isActive !== false
                );
                const todayDists = group.distribution.filter(
                  (d) => d.dayNumber === group.currentDay
                );
                const myDist = todayDists.find(
                  (d) => d.userId === currentUserId
                );
                const sampleDist = myDist || todayDists[0];
                const dailyPagesCount = sampleDist
                  ? sampleDist.pageTo - sampleDist.pageFrom + 1
                  : Math.ceil(group.totalPages / Math.max(1, group.targetDays));
                const completedCount = todayDists.filter(
                  (d) => d.isCompleted
                ).length;
                const progressPct =
                  activeMembers.length > 0
                    ? Math.round((completedCount / activeMembers.length) * 100)
                    : 0;

                return (
                  <div
                    key={group.id}
                    className="bg-[#FFFFFF] rounded-[20px] p-4 border border-[#E6E6F0]/70 hover:border-[#5B5FEF] shadow-xs hover:shadow-[0_0_20px_rgba(201,168,76,0.35)] transition-all duration-300 flex flex-col justify-between gap-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        {/* أيقونة المجموعة (SVG 36px داخل دائرة بيضاء بإطار ذهبي) */}
                        <div className="w-12 h-12 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shrink-0">
                          <WirdGroupSvgIcon icon={group.icon} size={30} />
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h3 className="font-cairo font-bold text-base text-[#25263A] truncate">
                              {group.groupName}
                            </h3>
                            <span className="font-cairo text-[11px] font-bold text-[#E8B84A]">
                              • {group.isPublic ? 'عامة' : 'خاصة'}
                            </span>
                          </div>
                          <p className="font-cairo text-xs text-[#77798C] line-clamp-1 mt-0.5">
                            {group.description}
                          </p>
                        </div>
                      </div>

                      <span className="font-cairo text-[11px] font-bold text-[#5B5FEF] shrink-0">
                        #{group.joinCode}
                      </span>
                    </div>

                    {/* معلومات الأعضاء والورد اليومي وشريط التقدم */}
                    <div className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0] space-y-2">
                      <div className="flex items-center justify-between text-xs font-cairo font-bold text-[#25263A]">
                        <span>عدد الأعضاء: {activeMembers.length}</span>
                        <span className="text-[#E8B84A]">
                          الورد اليومي: {dailyPagesCount}/{group.totalPages} صفحة
                        </span>
                      </div>

                      <div className="w-full h-2 rounded-full bg-[#F7F7FC] overflow-hidden border border-[#E6E6F0]">
                        <div
                          className="h-full bg-gradient-to-l from-[#72B7E8] to-[#4CAF82] rounded-full transition-all duration-300"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[11px] font-cairo text-[#77798C]">
                        <span>{getPlanLabel(group.planType, group.customSurahName)}</span>
                        <span className="font-bold text-[#4CAF82]">
                          إنجاز اليوم: {progressPct}%
                        </span>
                      </div>
                    </div>

                    {/* زر "دخول" (أخضر #4CAF82) */}
                    <button
                      type="button"
                      onClick={() => setSelectedGroupId(group.id)}
                      className="w-full py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs sm:text-sm transition-colors cursor-pointer"
                    >
                      دخول
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ── 【الشاشة 2】نافذة إنشاء مجموعة ── */}
      {isCreateModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-3 sm:p-4 animate-fade-in"
          dir="rtl"
        >
          <div className="bg-[#FFFFFF] w-full max-w-lg rounded-[20px] border-2 border-[#5B5FEF] p-5 sm:p-6 shadow-2xl max-h-[92vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center">
                  <WirdMushafPenSvg size={22} />
                </div>
                <h2 className="font-cairo font-bold text-lg text-[#25263A]">
                  إنشاء مجموعة وِرد جديدة
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {createError && (
              <div className="p-3 rounded-xl bg-[#D95C6A]/10 border border-[#D95C6A] text-[#D95C6A] font-cairo font-bold text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{createError}</span>
              </div>
            )}

            <form onSubmit={handleCreateGroupSubmit} className="space-y-4">
              <div>
                <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                  اسم المجموعة *
                </label>
                <input
                  type="text"
                  required
                  value={groupName}
                  onChange={(e) => setGroupName(e.target.value)}
                  placeholder="مثال: ختمة الأسرة المباركة"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                    نوع الخطة
                  </label>
                  <select
                    value={planType}
                    onChange={(e) => setPlanType(e.target.value as WirdPlanType)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
                  >
                    <option value="khatma">ختمة كاملة (30 جزء)</option>
                    <option value="juz_amma">جزء عم (الجزء 30)</option>
                    <option value="surah_custom">سور محددة</option>
                    <option value="custom">خطة مخصصة</option>
                  </select>
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                    عدد الأيام (افتراضي 30)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={365}
                    value={targetDays}
                    onChange={(e) => setTargetDays(Number(e.target.value) || 30)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
                  />
                </div>
              </div>

              {planType === 'surah_custom' && (
                <div>
                  <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                    اختر السورة المحددة
                  </label>
                  <select
                    value={customSurahName}
                    onChange={(e) => setCustomSurahName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
                  >
                    {QURAN_SURAH_OPTIONS.map((s) => (
                      <option key={s.number} value={s.name}>
                        {s.name} (ص {s.startPage} إلى ص {s.endPage})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {planType === 'custom' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1">
                      من صفحة (1 - 604)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={604}
                      value={customStartPage}
                      onChange={(e) => setCustomStartPage(Number(e.target.value) || 1)}
                      className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] font-cairo text-sm text-[#25263A]"
                    />
                  </div>
                  <div>
                    <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1">
                      إلى صفحة (1 - 604)
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={604}
                      value={customEndPage}
                      onChange={(e) => setCustomEndPage(Number(e.target.value) || 604)}
                      className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] font-cairo text-sm text-[#25263A]"
                    />
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                    تاريخ البدء
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
                  />
                </div>

                <div>
                  <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                    نوع المجموعة
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setIsPublicGroup(true)}
                      className={`py-2.5 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                        isPublicGroup
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                      }`}
                    >
                      <Globe className="w-4 h-4" />
                      <span>عامة</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsPublicGroup(false)}
                      className={`py-2.5 px-3 rounded-xl border font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer ${
                        !isPublicGroup
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                      }`}
                    >
                      <Lock className="w-4 h-4" />
                      <span>خاصة</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* شبكة أيقونات المجموعة (SVG داخل دوائر بيضاء بإطار ذهبي) */}
              <div>
                <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                  أيقونة المجموعة (SVG)
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {WIRD_GROUP_ICONS.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setSelectedIcon(item.id)}
                      className={`p-2 rounded-xl border flex flex-col items-center gap-1 cursor-pointer transition-all ${
                        selectedIcon === item.id
                          ? 'bg-[#F7F7FC] border-[#5B5FEF] ring-2 ring-[#5B5FEF]/40'
                          : 'bg-white border-[#E6E6F0] hover:border-[#5B5FEF]'
                      }`}
                    >
                      <div className="w-9 h-9 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center">
                        <WirdGroupSvgIcon icon={item.id} size={22} />
                      </div>
                      <span className="font-cairo text-[10px] font-bold text-[#25263A] truncate w-full text-center">
                        {item.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                  الوصف (اختياري)
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="اكتب هدف المجموعة أو رسالة ترحيبية للأعضاء..."
                  className="w-full px-3.5 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-sm text-[#25263A]"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmittingCreate}
                className="w-full py-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer disabled:opacity-60"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  {isSubmittingCreate ? 'جاري إنشاء المجموعة وتوزيع الأجزاء...' : 'إنشاء المجموعة'}
                </span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ── 【الشاشة 3】نافذة الانضمام بمجموعة ── */}
      {isJoinModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-3 sm:p-4 animate-fade-in"
          dir="rtl"
        >
          <div className="bg-[#FFFFFF] w-full max-w-md rounded-[20px] border-2 border-[#5B5FEF] p-5 sm:p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#F7F7FC] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                  <Users className="w-4 h-4 text-[#4CAF82]" />
                </div>
                <h2 className="font-cairo font-bold text-lg text-[#25263A]">
                  الانضمام بمجموعة
                </h2>
              </div>
              <button
                type="button"
                onClick={() => {
                  clearPendingWirdInviteCode();
                  setIsJoinModalOpen(false);
                }}
                className="p-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {joinFeedback && (
              <div
                className={`p-3.5 rounded-xl border font-cairo font-bold text-xs sm:text-sm flex flex-col gap-2 ${
                  joinFeedback.type === 'error'
                    ? 'bg-[#D95C6A]/10 border-[#D95C6A] text-[#D95C6A]'
                    : 'bg-[#4CAF82]/12 border-[#4CAF82] text-[#4CAF82]'
                }`}
              >
                <div className="flex items-center gap-2">
                  {joinFeedback.type === 'error' ? (
                    <AlertCircle className="w-4 h-4 shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                  )}
                  <span>{joinFeedback.text}</span>
                </div>
                {!currentUser && (
                  <button
                    type="button"
                    onClick={() => openAuthModal('login')}
                    className="w-full py-2 px-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <User className="w-3.5 h-3.5" />
                    <span>تسجيل الدخول الآن للمتابعة والانضمام</span>
                  </button>
                )}
              </div>
            )}

            {/* معاينة بيانات المجموعة الحقيقية من Firestore عند إدخال أو فتح كود الدعوة */}
            {loadingGroupPreview && (
              <div className="p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center gap-2 text-xs font-cairo font-bold text-[#5B5FEF]">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جاري جلب بيانات المجموعة الحقيقية من Firestore...</span>
              </div>
            )}

            {invitedGroupPreview && !loadingGroupPreview && (
              <div className="p-3.5 rounded-2xl bg-[#F7F7FC] border-2 border-[#5B5FEF] space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-[#FFFFFF] border border-[#E6E6F0] flex items-center justify-center shrink-0">
                      <WirdGroupSvgIcon icon={invitedGroupPreview.icon} size={24} />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-cairo font-bold text-sm text-[#25263A] truncate">
                        {invitedGroupPreview.groupName}
                      </h3>
                      <p className="font-cairo text-[11px] text-[#77798C]">
                        {getPlanLabel(
                          invitedGroupPreview.planType,
                          invitedGroupPreview.customSurahName
                        )}{' '}
                        • المشرف: {invitedGroupPreview.adminName}
                      </p>
                      <p className="font-cairo text-[11px] text-[#5B5FEF] font-bold mt-0.5">
                        اليوم {invitedGroupPreview.currentDay} من {invitedGroupPreview.targetDays} • الصفحات {invitedGroupPreview.startPageRange} إلى {invitedGroupPreview.endPageRange}
                      </p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-[#FFFFFF] border border-[#E6E6F0] font-cairo font-bold text-[11px] text-[#4CAF82] shrink-0">
                    {invitedGroupPreview.members.length} عضو
                  </span>
                </div>

                {invitedGroupPreview.members.some(
                  (m) => m.userId === currentUserId && m.isActive !== false
                ) && (
                  <button
                    type="button"
                    onClick={() => {
                      clearPendingWirdInviteCode();
                      const cached = loadCachedWirdGroups();
                      if (!cached.some((g) => g.id === invitedGroupPreview.id)) {
                        setGroups([invitedGroupPreview, ...cached]);
                      }
                      setIsJoinModalOpen(false);
                      setSelectedGroupId(invitedGroupPreview.id);
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-[#4CAF82] hover:brightness-95 text-white font-cairo font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>أنت عضو بالفعل • فتح المجموعة الآن</span>
                  </button>
                )}
              </div>
            )}

            {!loadingGroupPreview &&
              !invitedGroupPreview &&
              sanitizeWirdInviteCode(joinCodeInput).length >= 6 &&
              !joinFeedback && (
                <div className="p-3 rounded-xl bg-[#D95C6A]/10 border border-[#D95C6A] font-cairo font-bold text-xs text-[#D95C6A] flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>كود الدعوة غير صالح</span>
                </div>
              )}

            <form onSubmit={handleJoinSubmit} className="space-y-4">
              {/* ■ حقل "كود الدعوة": تحويل تلقائي لحروف كبيرة + إزالة المسافات */}
              <div>
                <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1.5">
                  كود الدعوة
                </label>
                <input
                  type="text"
                  required
                  maxLength={64}
                  value={joinCodeInput}
                  onChange={(e) => {
                    const sanitized = sanitizeWirdInviteCode(e.target.value);
                    setJoinCodeInput(sanitized);
                    if (joinFeedback) setJoinFeedback(null);
                  }}
                  onPaste={(e) => {
                    e.preventDefault();
                    const pasted = e.clipboardData.getData('text') || '';
                    const sanitized = sanitizeWirdInviteCode(pasted);
                    setJoinCodeInput(sanitized);
                    if (joinFeedback) setJoinFeedback(null);
                  }}
                  placeholder="أدخل كود الدعوة (مثال: AB12CD)"
                  dir="ltr"
                  className="w-full px-4 py-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo font-bold text-center text-lg tracking-widest text-[#25263A] uppercase"
                />
                <p className="font-cairo text-[11px] text-[#77798C] mt-1.5 text-center">
                  يتم تلقائياً إزالة المسافات وتحويل الأحرف إلى كبيرة (Uppercase)
                </p>
              </div>

              {/* خيار الانضمام بحساب المستخدم أو تسجيل انضمام صديق مدعو */}
              <div className="bg-[#F7F7FC] rounded-xl p-3 border border-[#E6E6F0] space-y-2.5">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setJoinAsFriend(false);
                      setJoinFeedback(null);
                    }}
                    className={`py-2 px-2.5 rounded-lg font-cairo font-bold text-xs border transition-colors cursor-pointer ${
                      !joinAsFriend
                        ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                        : 'bg-[#FFFFFF] text-[#25263A] border-[#E6E6F0]'
                    }`}
                  >
                    بحسابي ({currentUserName})
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setJoinAsFriend(true);
                      setJoinFeedback(null);
                    }}
                    className={`py-2 px-2.5 rounded-lg font-cairo font-bold text-xs border transition-colors cursor-pointer ${
                      joinAsFriend
                        ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                        : 'bg-[#FFFFFF] text-[#25263A] border-[#E6E6F0]'
                    }`}
                  >
                    انضمام صديق مدعو
                  </button>
                </div>

                {joinAsFriend && (
                  <div>
                    <label className="block font-cairo font-bold text-xs text-[#25263A] mb-1">
                      اسم الصديق المنضم بالمجموعة
                    </label>
                    <input
                      type="text"
                      value={friendDisplayName}
                      onChange={(e) => setFriendDisplayName(e.target.value)}
                      placeholder="اكتب اسم الصديق ليتم توزيع ورده تلقائياً..."
                      className="w-full px-3 py-2 rounded-xl bg-[#FFFFFF] border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-cairo text-xs text-[#25263A]"
                    />
                  </div>
                )}
              </div>

              {/* ■ زر "انضمام" (أخضر #4CAF82) */}
              <button
                type="submit"
                disabled={isSubmittingJoin}
                className="w-full py-3 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-cairo font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer disabled:opacity-60"
              >
                <Users className="w-4 h-4" />
                <span>{isSubmittingJoin ? 'جاري البحث والتحقق في Firestore...' : 'انضمام'}</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ── 【الشاشة 5】صفحة المصحف المدمج مع قفل الورد الحقيقي والتحقق من Firestore ── */}
      {mushafReader?.isOpen && (() => {
        const readerGroup = groups.find((g) => g.id === mushafReader.groupId);
        const effId = readerGroup
          ? resolveEffectiveMemberUserId(readerGroup, currentUserId)
          : currentUserId;
        const myDist =
          readerGroup?.distribution.find(
            (d) =>
              d.userId === effId &&
              d.dayNumber === (readerGroup?.currentDay || 1)
          ) ||
          readerGroup?.distribution.find(
            (d) => d.dayNumber === (readerGroup?.currentDay || 1)
          );
        return (
          <WirdMushafReader
            groupId={mushafReader.groupId}
            userId={effId}
            currentDay={readerGroup?.currentDay}
            initialPage={myDist?.pageFrom ?? mushafReader.startPage}
            targetEndPage={myDist?.pageTo ?? mushafReader.endPage}
            partNumber={myDist?.partNumber}
            surahName={myDist?.surahName}
            isCompleted={Boolean(myDist?.isCompleted)}
            title={mushafReader.title}
            onClose={() => {
              setGroups([...loadCachedWirdGroups()]);
              setMushafReader(null);
            }}
            onCompleteWird={async () => {
              await completeMemberWirdReading(
                mushafReader.groupId,
                currentUserId,
                currentUserName
              );
              setGroups([...loadCachedWirdGroups()]);
              showBanner('تقبل الله طاعتك! تم تسجيل إنهاء قراءة وردك اليومي بنجاح');
            }}
          />
        );
      })()}

      {/* ── 【الشاشة 7】القائمة الجانبية الخاصة بوِرد ── */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-50 flex" dir="rtl">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setIsDrawerOpen(false)}
          />
          <div className="relative w-[290px] max-w-[85vw] bg-[#FFFFFF] h-full shadow-2xl border-l-2 border-[#5B5FEF] flex flex-col justify-between z-10 p-5">
            <div className="space-y-5">
              {/* صورة + اسم + بريد */}
              <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#FFFFFF] border-2 border-[#5B5FEF] overflow-hidden flex items-center justify-center shrink-0">
                  {photoUrl && !photoUrl.startsWith('emoji:') ? (
                    <img
                      src={photoUrl}
                      alt={currentUserName}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <User className="w-6 h-6 text-[#5B5FEF]" />
                  )}
                </div>
                <div className="min-w-0">
                  <h3 className="font-cairo font-bold text-sm text-[#25263A] truncate">
                    {currentUserName}
                  </h3>
                  <p className="font-cairo text-xs text-[#77798C] truncate" dir="ltr">
                    {currentUserEmail}
                  </p>
                </div>
              </div>

              {/* الروابط: المجموعات | مجموعاتي | حسابي | تواصل | قناة التليجرام */}
              <nav className="space-y-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedGroupId(null);
                    setFilterMode('all');
                    setIsDrawerOpen(false);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl hover:bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-sm flex items-center gap-3 cursor-pointer"
                >
                  <WirdMushafPenSvg size={20} />
                  <span>المجموعات</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedGroupId(null);
                    setFilterMode('mine');
                    setIsDrawerOpen(false);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl hover:bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-sm flex items-center gap-3 cursor-pointer"
                >
                  <Users className="w-5 h-5 text-[#5B5FEF]" />
                  <span>مجموعاتي</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsDrawerOpen(false);
                    if (onNavigate) onNavigate('profile');
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl hover:bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-sm flex items-center gap-3 cursor-pointer"
                >
                  <User className="w-5 h-5 text-[#5B5FEF]" />
                  <span>حسابي</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsDrawerOpen(false);
                    if (onNavigate) onNavigate('credits');
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl hover:bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-sm flex items-center gap-3 cursor-pointer"
                >
                  <MessageCircle className="w-5 h-5 text-[#5B5FEF]" />
                  <span>تواصل</span>
                </button>

                <a
                  href="https://t.me/rifq_app"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full px-3.5 py-2.5 rounded-xl hover:bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-sm flex items-center gap-3"
                >
                  <Send className="w-5 h-5 text-[#5B5FEF]" />
                  <span>قناة التليجرام</span>
                </a>
              </nav>
            </div>

            {/* تسجيل الخروج (أحمر #D95C6A) */}
            <div className="pt-4 border-t border-[#F7F7FC]">
              {currentUser ? (
                <button
                  type="button"
                  onClick={async () => {
                    await logout();
                    setIsDrawerOpen(false);
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#D95C6A] hover:bg-[#D95C6A] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>تسجيل الخروج</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setIsDrawerOpen(false);
                    openAuthModal('login');
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  <User className="w-4 h-4" />
                  <span>تسجيل الدخول</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
