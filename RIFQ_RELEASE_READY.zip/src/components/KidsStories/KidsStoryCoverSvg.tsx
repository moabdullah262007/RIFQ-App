import React from 'react';
import { KidsStoryIllustrationId } from '../../data/kidsStoriesData';

interface CoverProps {
  type: KidsStoryIllustrationId | string;
  className?: string;
}

/**
 * High-clarity vector illustrations for all 22 children's stories in RIFQ.
 * Designed with RIFQ's warm purple/blue, gold, and soft pastel palette.
 */
export const KidsStoryCoverSvg: React.FC<CoverProps> = ({ type, className = 'w-full h-full' }) => {
  switch (type) {
    case 'flying_fox':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#EEF2FF" />
          <circle cx="265" cy="40" r="24" fill="#FDE047" opacity="0.8" />
          <path d="M0 138 Q110 110 220 135 T320 125 L320 180 L0 180 Z" fill="#86EFAC" />
          {/* Fluffy clouds */}
          <ellipse cx="75" cy="52" rx="34" ry="14" fill="#FFFFFF" />
          <circle cx="62" cy="44" r="14" fill="#FFFFFF" />
          <circle cx="88" cy="44" r="16" fill="#FFFFFF" />
          {/* Cute Fox with wooden glider wings */}
          <g transform="translate(115, 48)">
            <path d="M5 42 L85 42 L72 56 L18 56 Z" fill="#6366F1" stroke="#4338CA" strokeWidth="2" />
            <ellipse cx="45" cy="64" rx="18" ry="22" fill="#F97316" />
            <path d="M30 32 L34 14 L44 26 Z" fill="#EA580C" />
            <path d="M60 32 L56 14 L46 26 Z" fill="#EA580C" />
            <circle cx="45" cy="36" r="15" fill="#F97316" />
            <circle cx="40" cy="34" r="2.5" fill="#1E1B4B" />
            <circle cx="50" cy="34" r="2.5" fill="#1E1B4B" />
            <circle cx="45" cy="40" r="3" fill="#1E1B4B" />
          </g>
        </svg>
      );

    case 'rabbit_star':
    case 'star_world_friend':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#1E1B4B" />
          <circle cx="55" cy="38" r="2" fill="#FEF08A" />
          <circle cx="265" cy="35" r="2.5" fill="#FEF08A" />
          <circle cx="230" cy="75" r="1.8" fill="#FFFFFF" />
          <path d="M0 142 Q160 122 320 142 L320 180 L0 180 Z" fill="#312E81" />
          {/* Glowing Star */}
          <g transform="translate(175, 25)">
            <circle cx="30" cy="30" r="28" fill="#FACC15" opacity="0.22" />
            <path d="M30 6 L37 21 L54 23 L41 35 L44 52 L30 43 L16 52 L19 35 L6 23 L23 21 Z" fill="#FDE047" stroke="#F59E0B" strokeWidth="2" />
          </g>
          {/* Cute White Rabbit looking at the star */}
          <g transform="translate(95, 72)">
            <ellipse cx="22" cy="14" rx="5" ry="14" transform="rotate(-10 22 14)" fill="#FFFFFF" stroke="#818CF8" strokeWidth="2" />
            <ellipse cx="34" cy="14" rx="5" ry="14" transform="rotate(10 34 14)" fill="#FFFFFF" stroke="#818CF8" strokeWidth="2" />
            <circle cx="28" cy="32" r="14" fill="#FFFFFF" />
            <circle cx="24" cy="30" r="2" fill="#1E1B4B" />
            <circle cx="32" cy="30" r="2" fill="#1E1B4B" />
            <circle cx="28" cy="34" r="2" fill="#F472B6" />
            <ellipse cx="28" cy="52" rx="13" ry="15" fill="#FFFFFF" />
          </g>
        </svg>
      );

    case 'sami_forest':
    case 'garden_treasure':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#ECFDF5" />
          <path d="M0 135 Q160 110 320 135 L320 180 L0 180 Z" fill="#4ADE80" />
          {/* Winding forest path */}
          <path d="M130 180 Q155 145 165 125" stroke="#FDE68A" strokeWidth="22" strokeLinecap="round" />
          {/* Trees */}
          <g transform="translate(45, 32)">
            <rect x="24" y="65" width="12" height="45" fill="#92400E" />
            <circle cx="30" cy="48" r="28" fill="#16A34A" />
            <circle cx="18" cy="60" r="20" fill="#22C55E" />
            <circle cx="42" cy="60" r="20" fill="#22C55E" />
          </g>
          <g transform="translate(215, 36)">
            <rect x="24" y="65" width="12" height="45" fill="#92400E" />
            <circle cx="30" cy="48" r="26" fill="#16A34A" />
            <circle cx="20" cy="58" r="18" fill="#22C55E" />
          </g>
          {/* Golden Compass / Treasure */}
          <circle cx="160" cy="82" r="22" fill="#FEF08A" stroke="#F59E0B" strokeWidth="3" />
          <path d="M160 66 L165 82 L160 98 L155 82 Z" fill="#4F46E5" />
        </svg>
      );

    case 'cat_bell':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#FFF1F2" />
          <g transform="translate(115, 36)">
            <path d="M20 35 L24 10 L40 26 Z" fill="#6366F1" />
            <path d="M70 35 L66 10 L50 26 Z" fill="#6366F1" />
            <circle cx="45" cy="44" r="24" fill="#818CF8" />
            <circle cx="36" cy="40" r="3.5" fill="#FFFFFF" />
            <circle cx="54" cy="40" r="3.5" fill="#FFFFFF" />
            <path d="M42 47 L48 47 L45 51 Z" fill="#F472B6" />
            {/* Collar & Golden Bell */}
            <rect x="27" y="64" width="36" height="6" rx="3" fill="#F43F5E" />
            <circle cx="45" cy="74" r="9" fill="#FACC15" stroke="#D97706" strokeWidth="2" />
            <circle cx="45" cy="76" r="2.5" fill="#92400E" />
          </g>
        </svg>
      );

    case 'glowing_garden':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#1E1B4B" />
          <path d="M0 140 Q160 120 320 140 L320 180 L0 180 Z" fill="#312E81" />
          {[85, 160, 235].map((x, idx) => (
            <g key={idx} transform={`translate(${x - 20}, 55)`}>
              <circle cx="20" cy="24" r="24" fill="#FACC15" opacity="0.22" />
              <rect x="18" y="34" width="4" height="52" fill="#4ADE80" />
              <circle cx="20" cy="24" r="12" fill={idx === 1 ? '#F472B6' : '#818CF8'} />
              <circle cx="20" cy="24" r="6" fill="#FEF08A" />
            </g>
          ))}
        </svg>
      );

    case 'patient_bird':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#FFFBEB" />
          <path d="M0 132 Q150 112 300 124" stroke="#92400E" strokeWidth="8" strokeLinecap="round" fill="none" />
          <g transform="translate(120, 52)">
            {/* Nest */}
            <path d="M10 62 Q40 88 70 62 Z" fill="#D97706" stroke="#92400E" strokeWidth="2.5" />
            {/* Cute Bird */}
            <ellipse cx="40" cy="44" rx="22" ry="18" fill="#4F46E5" />
            <circle cx="54" cy="32" r="14" fill="#6366F1" />
            <path d="M66 30 L78 34 L66 38 Z" fill="#F59E0B" />
            <circle cx="58" cy="29" r="2.8" fill="#FFFFFF" />
          </g>
        </svg>
      );

    case 'magic_toy_city':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#F5F3FF" />
          <g transform="translate(75, 38)">
            <rect x="15" y="45" width="42" height="65" rx="6" fill="#818CF8" />
            <path d="M10 45 L36 15 L62 45 Z" fill="#F59E0B" />
            <rect x="65" y="32" width="48" height="78" rx="6" fill="#6366F1" />
            <path d="M60 32 L89 4 L118 32 Z" fill="#EC4899" />
            <rect x="120" y="50" width="40" height="60" rx="6" fill="#34D399" />
            <path d="M116 50 L140 22 L164 50 Z" fill="#FBBF24" />
          </g>
        </svg>
      );

    case 'blue_planet':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#1E1B4B" />
          <circle cx="60" cy="40" r="2" fill="#FEF08A" />
          <circle cx="265" cy="52" r="2.5" fill="#FEF08A" />
          <circle cx="85" cy="135" r="2" fill="#FFFFFF" />
          <g transform="translate(160, 90)">
            <circle cx="0" cy="0" r="44" fill="#38BDF8" />
            <path d="M-28 -12 Q-5 -24 18 -8 T32 15" stroke="#4ADE80" strokeWidth="12" strokeLinecap="round" fill="none" />
            <ellipse cx="0" cy="0" rx="72" ry="18" transform="rotate(-18)" stroke="#FDE047" strokeWidth="5" fill="none" />
          </g>
        </svg>
      );

    case 'little_bear_friend':
    case 'helpful_lion':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#FEF3C7" />
          <path d="M0 140 Q160 120 320 140 L320 180 L0 180 Z" fill="#86EFAC" />
          <g transform="translate(115, 38)">
            <circle cx="22" cy="24" r="12" fill="#B45309" />
            <circle cx="68" cy="24" r="12" fill="#B45309" />
            <circle cx="45" cy="48" r="32" fill="#F59E0B" />
            <circle cx="45" cy="50" r="24" fill="#FDE68A" />
            <circle cx="36" cy="44" r="3.5" fill="#1E1B4B" />
            <circle cx="54" cy="44" r="3.5" fill="#1E1B4B" />
            <ellipse cx="45" cy="53" rx="5" ry="3.5" fill="#78350F" />
            <path d="M38 60 Q45 66 52 60" stroke="#78350F" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          </g>
        </svg>
      );

    case 'dream_bag':
    case 'bedtime_tale':
    case 'forgetful_moon':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#1E1B4B" />
          <circle cx="55" cy="42" r="2" fill="#FDE68A" />
          <circle cx="265" cy="45" r="2.5" fill="#FDE68A" />
          <circle cx="235" cy="115" r="1.8" fill="#FFFFFF" />
          <g transform="translate(115, 28)">
            <circle cx="45" cy="58" r="52" fill="#818CF8" opacity="0.18" />
            <path d="M55 15 A44 44 0 1 0 90 92 A34 34 0 1 1 55 15 Z" fill="#FDE047" stroke="#F59E0B" strokeWidth="2" />
            <path d="M36 55 Q42 60 48 55" stroke="#78350F" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <circle cx="34" cy="63" r="4" fill="#F472B6" opacity="0.5" />
          </g>
        </svg>
      );

    case 'determined_ant':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#FEF3C7" />
          <path d="M0 132 Q160 108 320 132 L320 180 L0 180 Z" fill="#86EFAC" />
          <ellipse cx="160" cy="68" rx="52" ry="15" fill="#F59E0B" stroke="#B45309" strokeWidth="2.5" />
          {[110, 160, 210].map((x, idx) => (
            <g key={idx} transform={`translate(${x - 15}, 84)`}>
              <circle cx="15" cy="10" r="9" fill="#4338CA" />
              <circle cx="12" cy="8" r="2" fill="#FFFFFF" />
              <circle cx="18" cy="8" r="2" fill="#FFFFFF" />
              <ellipse cx="15" cy="25" rx="7" ry="9" fill="#4F46E5" />
              <ellipse cx="15" cy="40" rx="9" ry="10" fill="#312E81" />
            </g>
          ))}
        </svg>
      );

    case 'salma_wonder_book':
    case 'bismillah_blessing':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#EEF2FF" />
          <g transform="translate(95, 45)">
            <path d="M10 76 Q38 64 65 76 Q92 64 120 76 L120 26 Q92 14 65 26 Q38 14 10 26 Z" fill="#FFFFFF" stroke="#4F46E5" strokeWidth="3" />
            <path d="M65 26 L65 76" stroke="#4F46E5" strokeWidth="2.5" />
            <path d="M65 2 L69 12 L80 12 L71 18 L74 28 L65 22 L56 28 L59 18 L50 12 L61 12 Z" fill="#F59E0B" />
            <circle cx="38" cy="14" r="4" fill="#818CF8" />
            <circle cx="92" cy="14" r="4" fill="#FBBF24" />
          </g>
        </svg>
      );

    case 'color_world':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#F0F9FF" />
          <path d="M40 165 A120 120 0 0 1 280 165" stroke="#F87171" strokeWidth="10" fill="none" opacity="0.75" />
          <path d="M50 165 A110 110 0 0 1 270 165" stroke="#FBBF24" strokeWidth="10" fill="none" opacity="0.75" />
          <path d="M60 165 A100 100 0 0 1 260 165" stroke="#34D399" strokeWidth="10" fill="none" opacity="0.75" />
          <path d="M70 165 A90 90 0 0 1 250 165" stroke="#6366F1" strokeWidth="10" fill="none" opacity="0.75" />
        </svg>
      );

    case 'day_without_laziness':
    case 'morning_smile':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#FEF9C3" />
          <g transform="translate(160, 90)">
            <circle cx="0" cy="0" r="56" fill="#FDE047" opacity="0.45" />
            <circle cx="0" cy="0" r="40" fill="#FACC15" stroke="#F59E0B" strokeWidth="3" />
            <circle cx="-13" cy="-6" r="4" fill="#78350F" />
            <circle cx="13" cy="-6" r="4" fill="#78350F" />
            <path d="M-14 10 Q0 22 14 10" stroke="#78350F" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          </g>
        </svg>
      );

    case 'funny_monkey':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#FEF3C7" />
          <path d="M0 142 Q160 120 320 142 L320 180 L0 180 Z" fill="#FDE68A" />
          {/* Cute Monkey with Chef Hat & Banana Pie */}
          <g transform="translate(115, 36)">
            <circle cx="15" cy="54" r="10" fill="#92400E" />
            <circle cx="75" cy="54" r="10" fill="#92400E" />
            <circle cx="45" cy="56" r="26" fill="#B45309" />
            <ellipse cx="45" cy="62" rx="18" ry="14" fill="#FDE68A" />
            {/* Chef Hat */}
            <path d="M26 32 Q24 10 45 12 Q66 10 64 32 Z" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="2" />
            <rect x="27" y="28" width="36" height="8" rx="3" fill="#FFFFFF" stroke="#CBD5E1" strokeWidth="1.5" />
            <circle cx="37" cy="50" r="3.2" fill="#1E1B4B" />
            <circle cx="53" cy="50" r="3.2" fill="#1E1B4B" />
            <path d="M36 63 Q45 71 54 63" stroke="#78350F" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          </g>
        </svg>
      );

    case 'little_penguin':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#E0F2FE" />
          <path d="M0 138 Q160 118 320 138 L320 180 L0 180 Z" fill="#FFFFFF" />
          <g transform="translate(125, 38)">
            <ellipse cx="35" cy="56" rx="24" ry="32" fill="#1E1B4B" />
            <ellipse cx="35" cy="60" rx="16" ry="24" fill="#FFFFFF" />
            <circle cx="28" cy="40" r="3" fill="#FFFFFF" />
            <circle cx="42" cy="40" r="3" fill="#FFFFFF" />
            <path d="M30 46 L40 46 L35 53 Z" fill="#F59E0B" />
            <ellipse cx="23" cy="88" rx="7" ry="4" fill="#F59E0B" />
            <ellipse cx="47" cy="88" rx="7" ry="4" fill="#F59E0B" />
          </g>
        </svg>
      );

    case 'happy_dolphin':
    case 'submarine_sea':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#E0F2FE" />
          <path d="M0 130 Q80 115 160 130 T320 130 L320 180 L0 180 Z" fill="#38BDF8" />
          <circle cx="230" cy="68" r="14" fill="#FEF08A" stroke="#F59E0B" strokeWidth="2.5" />
          <g transform="translate(85, 42)">
            <path d="M15 65 Q55 15 105 48 Q80 55 60 72 Z" fill="#4F46E5" />
            <circle cx="82" cy="44" r="3" fill="#FFFFFF" />
            <path d="M52 28 L42 12 L64 24 Z" fill="#4338CA" />
          </g>
        </svg>
      );

    case 'wise_owl':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#312E81" />
          <circle cx="65" cy="42" r="2.5" fill="#FDE047" />
          <circle cx="255" cy="38" r="2.5" fill="#FDE047" />
          <path d="M40 135 L280 135" stroke="#92400E" strokeWidth="8" strokeLinecap="round" />
          <g transform="translate(125, 42)">
            <ellipse cx="35" cy="54" rx="26" ry="32" fill="#6366F1" />
            <ellipse cx="35" cy="60" rx="16" ry="20" fill="#E0E7FF" />
            <circle cx="25" cy="40" r="9" fill="#FFFFFF" stroke="#F59E0B" strokeWidth="2.5" />
            <circle cx="45" cy="40" r="9" fill="#FFFFFF" stroke="#F59E0B" strokeWidth="2.5" />
            <circle cx="25" cy="40" r="3.5" fill="#1E1B4B" />
            <circle cx="45" cy="40" r="3.5" fill="#1E1B4B" />
            <path d="M31 48 L39 48 L35 55 Z" fill="#F59E0B" />
          </g>
        </svg>
      );

    case 'friendly_robot':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#EEF2FF" />
          <g transform="translate(115, 32)">
            <line x1="45" y1="6" x2="45" y2="22" stroke="#4F46E5" strokeWidth="4" />
            <circle cx="45" cy="6" r="6" fill="#F59E0B" />
            <rect x="15" y="22" width="60" height="48" rx="14" fill="#6366F1" stroke="#4338CA" strokeWidth="3" />
            <rect x="24" y="31" width="42" height="28" rx="8" fill="#1E1B4B" />
            <circle cx="36" cy="42" r="4" fill="#38BDF8" />
            <circle cx="54" cy="42" r="4" fill="#38BDF8" />
            <path d="M36 51 Q45 57 54 51" stroke="#FDE047" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <rect x="22" y="74" width="46" height="36" rx="10" fill="#818CF8" />
            <path d="M45 84 L49 90 L45 96 L41 90 Z" fill="#FDE047" />
          </g>
        </svg>
      );

    case 'space_rocket':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#1E1B4B" />
          <circle cx="60" cy="40" r="2.5" fill="#FDE047" />
          <circle cx="260" cy="50" r="3" fill="#FDE047" />
          <circle cx="95" cy="130" r="2" fill="#FFFFFF" />
          <g transform="translate(135, 24)">
            <path d="M25 8 Q48 35 45 85 L5 85 Q2 35 25 8 Z" fill="#FFFFFF" stroke="#6366F1" strokeWidth="3" />
            <path d="M25 8 Q36 22 35 34 L15 34 Q14 22 25 8 Z" fill="#4F46E5" />
            <circle cx="25" cy="54" r="10" fill="#38BDF8" stroke="#4F46E5" strokeWidth="3" />
            <path d="M5 68 L-8 88 L5 85 Z" fill="#F59E0B" />
            <path d="M45 68 L58 88 L45 85 Z" fill="#F59E0B" />
            <path d="M16 86 L25 112 L34 86 Z" fill="#FACC15" />
          </g>
        </svg>
      );

    case 'bee_hive':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#FEF9C3" />
          <g transform="translate(120, 34)">
            <ellipse cx="40" cy="55" rx="34" ry="40" fill="#F59E0B" stroke="#B45309" strokeWidth="3" />
            <line x1="12" y1="42" x2="68" y2="42" stroke="#B45309" strokeWidth="3" />
            <line x1="8" y1="58" x2="72" y2="58" stroke="#B45309" strokeWidth="3" />
            <line x1="14" y1="74" x2="66" y2="74" stroke="#B45309" strokeWidth="3" />
            <circle cx="40" cy="64" r="8" fill="#78350F" />
          </g>
          {/* Cute Little Bee */}
          <g transform="translate(65, 55)">
            <ellipse cx="20" cy="20" rx="14" ry="10" fill="#FACC15" stroke="#1E1B4B" strokeWidth="2" />
            <ellipse cx="16" cy="10" rx="6" ry="8" fill="#FFFFFF" opacity="0.85" />
            <ellipse cx="24" cy="10" rx="6" ry="8" fill="#FFFFFF" opacity="0.85" />
          </g>
        </svg>
      );

    case 'lantern_night':
    case 'honest_merchant':
    case 'treehouse_club':
    case 'rainbow_island':
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#1E1B4B" />
          <circle cx="160" cy="90" r="56" fill="#FACC15" opacity="0.2" />
          <g transform="translate(132, 32)">
            <path d="M18 18 L38 18 L44 32 L12 32 Z" fill="#D97706" />
            <rect x="14" y="32" width="28" height="48" rx="6" fill="#FEF08A" stroke="#F59E0B" strokeWidth="3" />
            <circle cx="28" cy="56" r="9" fill="#F59E0B" />
            <rect x="10" y="80" width="36" height="8" rx="3" fill="#B45309" />
          </g>
        </svg>
      );

    case 'quick_thinking_rabbit':
    default:
      return (
        <svg viewBox="0 0 320 180" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="320" height="180" fill="#EEF2FF" />
          <path d="M0 138 Q160 115 320 138 L320 180 L0 180 Z" fill="#86EFAC" />
          <g transform="translate(125, 48)">
            <ellipse cx="24" cy="14" rx="6" ry="16" transform="rotate(-10 24 14)" fill="#FFFFFF" stroke="#4F46E5" strokeWidth="2.5" />
            <ellipse cx="42" cy="14" rx="6" ry="16" transform="rotate(10 42 14)" fill="#FFFFFF" stroke="#4F46E5" strokeWidth="2.5" />
            <circle cx="33" cy="36" r="18" fill="#FFFFFF" stroke="#4F46E5" strokeWidth="2.5" />
            <circle cx="27" cy="34" r="2.8" fill="#1E1B4B" />
            <circle cx="39" cy="34" r="2.8" fill="#1E1B4B" />
            <circle cx="33" cy="40" r="2.5" fill="#F472B6" />
            <path d="M28 45 Q33 49 38 45" stroke="#1E1B4B" strokeWidth="2" strokeLinecap="round" fill="none" />
          </g>
        </svg>
      );
  }
};

/**
 * Hero badge illustration matching the user's attached reference image:
 * Circular medallion with gold border, fairy-tale castle silhouette, crescent moon,
 * and a happy boy and girl reading an open glowing book together.
 */
export const KidsStoriesHeroMedallion: React.FC<{ className?: string }> = ({ className = 'w-16 h-16' }) => (
  <svg viewBox="0 0 120 120" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="ks_hero_bg" cx="50%" cy="42%" r="55%">
        <stop offset="0%" stopColor="#FFFDF9" />
        <stop offset="70%" stopColor="#F3F1FB" />
        <stop offset="100%" stopColor="#E6E4F8" />
      </radialGradient>
      <linearGradient id="ks_gold_ring" x1="0" y1="0" x2="120" y2="120" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#F7D98C" />
        <stop offset="50%" stopColor="#D9B15F" />
        <stop offset="100%" stopColor="#C49A45" />
      </linearGradient>
    </defs>
    {/* Outer Medallion */}
    <circle cx="60" cy="60" r="56" fill="url(#ks_hero_bg)" stroke="url(#ks_gold_ring)" strokeWidth="4" />
    <circle cx="60" cy="60" r="51" stroke="#EAE4D7" strokeWidth="1" />

    {/* Soft Castle Silhouette in Background */}
    <g opacity="0.28" fill="#818CF8">
      <rect x="46" y="24" width="28" height="28" rx="2" />
      <rect x="36" y="32" width="10" height="20" />
      <rect x="74" y="32" width="10" height="20" />
      <path d="M44 24 L60 10 L76 24 Z" />
      <path d="M34 32 L41 21 L48 32 Z" />
      <path d="M72 32 L79 21 L86 32 Z" />
    </g>

    {/* Golden Crescent & Sparkles */}
    <path d="M84 22 A9 9 0 1 0 93 33 A7 7 0 1 1 84 22 Z" fill="#F5B841" />
    <circle cx="30" cy="28" r="2.2" fill="#F5B841" />
    <circle cx="60" cy="18" r="2" fill="#F5B841" />

    {/* Boy on Left */}
    <g>
      <path d="M24 84 C24 71 34 66 43 66 C51 66 56 71 57 84 Z" fill="#4A55D6" />
      <path d="M37 66 L43 73 L49 66" stroke="#F5B841" strokeWidth="2" fill="none" />
      <circle cx="42" cy="51" r="13.5" fill="#FDE2C8" />
      <path d="M28 49 C28 38 36 34 45 35 C52 36 56 41 55 48 C51 43 44 42 37 44 C33 45 30 47 28 49 Z" fill="#3B2820" />
      <circle cx="38" cy="52" r="1.8" fill="#2D232E" />
      <circle cx="47" cy="52" r="1.8" fill="#2D232E" />
      <circle cx="35" cy="55" r="2.2" fill="#F48FB1" opacity="0.45" />
      <circle cx="50" cy="55" r="2.2" fill="#F48FB1" opacity="0.45" />
      <path d="M40 57 Q42.5 60 45 57" stroke="#8D5524" strokeWidth="1.6" strokeLinecap="round" fill="none" />
    </g>

    {/* Girl in Hijab on Right */}
    <g>
      <path d="M61 84 C62 70 67 64 78 64 C88 64 96 71 96 84 Z" fill="#5E60CE" />
      <circle cx="78" cy="51" r="15.5" fill="#5E60CE" />
      <path d="M64 53 A14.5 14.5 0 0 0 92 53" stroke="#F5B841" strokeWidth="2" fill="none" />
      <circle cx="78" cy="52" r="11.5" fill="#FDE2C8" />
      <circle cx="74" cy="52" r="1.8" fill="#2D232E" />
      <circle cx="83" cy="52" r="1.8" fill="#2D232E" />
      <circle cx="71.5" cy="55" r="2.2" fill="#F48FB1" opacity="0.45" />
      <circle cx="85.5" cy="55" r="2.2" fill="#F48FB1" opacity="0.45" />
      <path d="M75.5 57 Q78 60 80.5 57" stroke="#8D5524" strokeWidth="1.6" strokeLinecap="round" fill="none" />
    </g>

    {/* Open Golden Storybook in Foreground */}
    <g>
      <path
        d="M28 84 Q44 76 60 83 Q76 76 92 84 L90 98 Q75 91 60 97 Q45 91 30 98 Z"
        fill="#FFFDF7"
        stroke="#D99B26"
        strokeWidth="3"
        strokeLinejoin="round"
      />
      <path d="M60 83 L60 97" stroke="#D99B26" strokeWidth="2.5" />
      <circle cx="29" cy="89" r="3.8" fill="#FDE2C8" />
      <circle cx="91" cy="89" r="3.8" fill="#FDE2C8" />
      <circle cx="60" cy="74" r="2.5" fill="#F5B841" />
      <circle cx="52" cy="70" r="1.8" fill="#F5B841" />
      <circle cx="68" cy="70" r="1.8" fill="#F5B841" />
    </g>
  </svg>
);
