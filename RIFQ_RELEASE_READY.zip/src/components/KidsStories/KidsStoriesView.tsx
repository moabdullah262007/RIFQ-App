import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  ArrowRight,
  Search,
  Heart,
  Sparkles,
  Clock,
  BookOpen,
  Share2,
  Shuffle,
  CheckCircle2,
  X,
  Lightbulb,
  Users,
  ZoomIn,
  ZoomOut,
  Moon,
  Sun,
  RotateCcw,
  Volume2,
  Square,
  Star,
  Trophy,
  HelpCircle,
  Compass,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  KIDS_STORIES,
  KIDS_STORY_CATEGORIES,
  KIDS_AGE_RANGES,
  KIDS_READING_TIME_GROUPS,
  KidsStory,
  KidsStoryCategory,
  KidsAgeRange,
  KidsReadingTimeGroup,
  getKidsCategoryMeta,
  getStoryOfTheDay,
  getStoryFunExtras,
} from '../../data/kidsStoriesData';
import { KidsStoryCoverSvg, KidsStoriesHeroMedallion } from './KidsStoryCoverSvg';
import { soundManager } from '../../utils/audio';

interface KidsStoriesViewProps {
  onBack: () => void;
}

const FAVORITES_STORAGE_KEY = 'rifq_kids_stories_favorites_v1';
const COMPLETED_STORAGE_KEY = 'rifq_kids_stories_completed_v1';
const STARS_STORAGE_KEY = 'rifq_kids_stories_stars_v1';
const SOLVED_QUIZZES_STORAGE_KEY = 'rifq_kids_stories_solved_quizzes_v1';

function getReaderRankTitle(completedCount: number, starsCount: number): {
  title: string;
  nextTarget: number;
  subtitle: string;
} {
  const score = completedCount * 10 + starsCount;
  if (score >= 250) {
    return {
      title: 'حكيم مكتبة رِفْق 👑',
      nextTarget: 500,
      subtitle: 'ما شاء الله! أنت قارئ بارع ومثقف صغير متميز',
    };
  }
  if (score >= 120) {
    return {
      title: 'فارس القراءة الذهبي 🌟',
      nextTarget: 250,
      subtitle: 'إنجاز رائع! واصل جمع النجوم واكتشاف الحكايات',
    };
  }
  if (score >= 40) {
    return {
      title: 'مستكشف الحكايات 🧭',
      nextTarget: 120,
      subtitle: 'بداية مشرقة في عالم القصص الممتعة والنافعة',
    };
  }
  return {
    title: 'قارئ ناشئ 🌱',
    nextTarget: 40,
    subtitle: 'اقرأ قصتك الأولى وأجب عن تحدي الذكاء لتجمع النجوم!',
  };
}

/**
 * Reusable Category Filter Bar component with story counts
 */
const CategoryFilterBar: React.FC<{
  selectedCategory: KidsStoryCategory | 'all';
  onSelectCategory: (cat: KidsStoryCategory | 'all') => void;
  categoryCounts: Record<string, number>;
}> = ({ selectedCategory, onSelectCategory, categoryCounts }) => {
  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-1 no-scrollbar" dir="rtl">
      <button
        type="button"
        onClick={() => onSelectCategory('all')}
        className={`shrink-0 px-4 py-2 rounded-2xl text-sm font-bold transition-all duration-200 border flex items-center gap-1.5 ${
          selectedCategory === 'all'
            ? 'bg-[#4F46E5] text-white border-[#4F46E5] shadow-md shadow-indigo-500/20 scale-[1.02]'
            : 'bg-white/90 text-[#2E2A4A] border-[#E6DFD3] hover:border-[#C9A84C] hover:bg-[#FAF7F0]'
        }`}
      >
        <span>الكل</span>
        <span
          className={`px-1.5 py-0.2 rounded-full text-[11px] ${
            selectedCategory === 'all' ? 'bg-white/20 text-white' : 'bg-[#EEF2FF] text-[#4F46E5]'
          }`}
        >
          {KIDS_STORIES.length}
        </span>
      </button>
      {KIDS_STORY_CATEGORIES.map((cat) => {
        const isActive = selectedCategory === cat.id;
        const count = categoryCounts[cat.id] || 0;
        return (
          <button
            key={cat.id}
            type="button"
            onClick={() => onSelectCategory(cat.id)}
            className={`shrink-0 px-4 py-2 rounded-2xl text-sm font-bold transition-all duration-200 border flex items-center gap-1.5 ${
              isActive
                ? 'bg-[#4F46E5] text-white border-[#4F46E5] shadow-md shadow-indigo-500/20 scale-[1.02]'
                : 'bg-white/90 text-[#2E2A4A] border-[#E6DFD3] hover:border-[#C9A84C] hover:bg-[#FAF7F0]'
            }`}
          >
            <span>{cat.title}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[11px] ${
                isActive ? 'bg-white/20 text-white' : 'bg-[#F4F1EA] text-[#6E688F]'
              }`}
            >
              {count}
            </span>
          </button>
        );
      })}
    </div>
  );
};

/**
 * Reusable Story Card component
 */
const StoryCard: React.FC<{
  story: KidsStory;
  isFavorite: boolean;
  isCompleted: boolean;
  isQuizSolved: boolean;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onOpenStory: (story: KidsStory) => void;
}> = ({ story, isFavorite, isCompleted, isQuizSolved, onToggleFavorite, onOpenStory }) => {
  const categoryMeta = getKidsCategoryMeta(story.category);

  return (
    <div
      onClick={() => onOpenStory(story)}
      className="group bg-white rounded-3xl border border-[#EAE3D5] shadow-sm hover:shadow-xl hover:border-[#C9A84C]/60 transition-all duration-300 overflow-hidden flex flex-col cursor-pointer"
      dir="rtl"
    >
      {/* Illustration Banner */}
      <div className="relative h-44 w-full overflow-hidden bg-[#F5F3FF]">
        <KidsStoryCoverSvg
          type={story.image}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Top Overlay Badges */}
        <div className="absolute top-3 inset-x-3 flex items-center justify-between gap-2">
          <span
            style={{
              backgroundColor: categoryMeta.softBg,
              color: categoryMeta.accentColor,
              borderColor: categoryMeta.borderColor,
            }}
            className="px-3 py-1 rounded-full text-xs font-bold border backdrop-blur-sm shadow-xs"
          >
            {story.categoryLabel}
          </span>

          <button
            type="button"
            onClick={(e) => onToggleFavorite(story.id, e)}
            aria-label={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
            className={`w-9 h-9 rounded-full flex items-center justify-center backdrop-blur-md transition-all shadow-xs ${
              isFavorite
                ? 'bg-rose-500 text-white scale-105'
                : 'bg-white/90 text-slate-600 hover:text-rose-500 hover:bg-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Bottom Overlay Metadata */}
        <div className="absolute bottom-2.5 inset-x-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 bg-white/92 backdrop-blur-sm px-2.5 py-1 rounded-full text-[11px] font-bold text-[#3D385B] shadow-xs">
            <Users className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>{story.ageRange}</span>
          </div>

          <div className="flex items-center gap-1.5 bg-white/92 backdrop-blur-sm px-2.5 py-1 rounded-full text-[11px] font-bold text-[#3D385B] shadow-xs">
            <Clock className="w-3.5 h-3.5 text-[#C9A84C]" />
            <span>{story.readingTime}</span>
          </div>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="text-lg font-extrabold text-[#1E1B4B] group-hover:text-[#4F46E5] transition-colors leading-snug">
              {story.title}
            </h3>
            <div className="flex items-center gap-1 shrink-0">
              {isQuizSolved && (
                <span
                  title="أجبت عن تحدي القصة"
                  className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200 text-[11px] font-bold"
                >
                  <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                  +5
                </span>
              )}
              {isCompleted && (
                <span
                  title="تمت قراءة القصة"
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-bold"
                >
                  <CheckCircle2 className="w-3 h-3" />
                  مقروءة
                </span>
              )}
            </div>
          </div>

          <p className="text-sm text-[#5A5575] line-clamp-2 leading-relaxed mb-4">
            {story.description}
          </p>
        </div>

        <div className="pt-3 border-t border-[#F3EFE6] flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#8A7132] truncate">
            <Lightbulb className="w-3.5 h-3.5 text-[#C9A84C] shrink-0" />
            <span className="truncate">{story.moralLesson}</span>
          </div>

          <span className="shrink-0 inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#EEF2FF] group-hover:bg-[#4F46E5] text-[#4F46E5] group-hover:text-white text-xs font-bold transition-colors">
            <BookOpen className="w-3.5 h-3.5" />
            اقرأ القصة
          </span>
        </div>
      </div>
    </div>
  );
};

/**
 * Full Story Reader View component with Interactive Audio Narrator, Fun Fact, & Interactive Quiz
 */
const StoryReaderView: React.FC<{
  story: KidsStory;
  isFavorite: boolean;
  isQuizSolved: boolean;
  onToggleFavorite: (id: string) => void;
  onBack: () => void;
  onPickAnotherStory: (currentId: string) => void;
  onMarkCompleted: (id: string) => void;
  onAwardQuizStars: (storyId: string, starsEarned: number) => void;
}> = ({
  story,
  isFavorite,
  isQuizSolved,
  onToggleFavorite,
  onBack,
  onPickAnotherStory,
  onMarkCompleted,
  onAwardQuizStars,
}) => {
  const [fontSizeLevel, setFontSizeLevel] = useState<number>(1);
  const [warmComfortMode, setWarmComfortMode] = useState<boolean>(false);
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [shareFeedback, setShareFeedback] = useState<string | null>(null);

  // Audio Narrator state
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [activeParagraphIdx, setActiveParagraphIdx] = useState<number | null>(null);
  const [speechRate, setSpeechRate] = useState<number>(0.95);

  // Interactive Quiz state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [heroMissionDone, setHeroMissionDone] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const categoryMeta = getKidsCategoryMeta(story.category);
  const funExtras = useMemo(() => getStoryFunExtras(story), [story]);

  const stopNarration = useCallback(() => {
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch {
      // ignore
    }
    setIsSpeaking(false);
    setActiveParagraphIdx(null);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    onMarkCompleted(story.id);
    setSelectedAnswers({});
    setHeroMissionDone(false);
    stopNarration();
    return () => {
      stopNarration();
    };
  }, [story.id, onMarkCompleted, stopNarration]);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      const docHeight =
        document.documentElement.scrollHeight - document.documentElement.clientHeight;
      if (docHeight <= 0) {
        setScrollProgress(100);
        return;
      }
      const pct = Math.min(100, Math.max(0, Math.round((scrollTop / docHeight) * 100)));
      setScrollProgress(pct);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [story.id]);

  const startNarration = (fromIndex = 0, rate = speechRate) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      setShareFeedback('المتصفح الحالي لا يدعم القراءة الصوتية التلقائية');
      setTimeout(() => setShareFeedback(null), 3000);
      return;
    }

    window.speechSynthesis.cancel();
    setIsSpeaking(true);

    const paragraphs = [
      `قصة: ${story.title}.`,
      ...story.content,
      `ماذا تعلمنا من القصة؟ ${story.moralLesson}`,
    ];

    const speakStep = (idx: number) => {
      if (idx >= paragraphs.length) {
        setIsSpeaking(false);
        setActiveParagraphIdx(null);
        return;
      }

      // Highlight paragraph index (0 is title, 1..n are story.content, last is moralLesson)
      if (idx >= 1 && idx <= story.content.length) {
        setActiveParagraphIdx(idx - 1);
      } else {
        setActiveParagraphIdx(null);
      }

      const utter = new SpeechSynthesisUtterance(paragraphs[idx]);
      utter.lang = 'ar-SA';
      utter.rate = rate;
      utter.pitch = 1.05;

      utter.onend = () => {
        speakStep(idx + 1);
      };
      utter.onerror = () => {
        setIsSpeaking(false);
        setActiveParagraphIdx(null);
      };

      window.speechSynthesis.speak(utter);
    };

    speakStep(fromIndex);
  };

  const handleToggleNarration = () => {
    if (isSpeaking) {
      stopNarration();
    } else {
      startNarration(0, speechRate);
    }
  };

  const handleAnswerQuiz = (questionId: string, optionIdx: number, correctIndex: number) => {
    setSelectedAnswers((prev) => {
      const next = { ...prev, [questionId]: optionIdx };

      // Check if all quiz questions for this story are now answered correctly
      const allCorrect = funExtras.quiz.every(
        (q) => (q.id === questionId ? optionIdx : next[q.id]) === q.correctIndex
      );

      if (optionIdx === correctIndex) {
        soundManager.playCompletionChime(0.6);
        try {
          confetti({
            particleCount: 45,
            spread: 65,
            origin: { y: 0.7 },
            colors: ['#4F46E5', '#F59E0B', '#FDE047', '#34D399'],
          });
        } catch {
          // ignore
        }
      }

      if (allCorrect && !isQuizSolved) {
        onAwardQuizStars(story.id, 5);
      }

      return next;
    });
  };

  const handleShare = async () => {
    const shareText = `📚 قصة: ${story.title}\n\n${story.description}\n\n💡 ماذا تعلمنا؟\n${story.moralLesson}\n\n— من قسم قصص الأطفال في تطبيق رِفْق`;
    try {
      if (navigator.share) {
        await navigator.share({
          title: `قصة: ${story.title} | تطبيق رِفْق`,
          text: shareText,
        });
        return;
      }
    } catch {
      // Fallback to clipboard copy
    }

    try {
      await navigator.clipboard.writeText(shareText);
      setShareFeedback('تم نسخ القصة والفائدة لمشاركتها');
      setTimeout(() => setShareFeedback(null), 3000);
    } catch {
      setShareFeedback('تعذر النسخ التلقائي');
      setTimeout(() => setShareFeedback(null), 3000);
    }
  };

  const fontSizeClasses =
    fontSizeLevel === 0
      ? 'text-lg leading-[2.1]'
      : fontSizeLevel === 1
      ? 'text-xl sm:text-2xl leading-[2.25]'
      : 'text-2xl sm:text-3xl leading-[2.35]';

  return (
    <div
      ref={containerRef}
      dir="rtl"
      className={`min-h-screen pb-24 transition-colors duration-300 ${
        warmComfortMode ? 'bg-[#1E1B36] text-[#F5F2EB]' : 'bg-[#F8F5EE] text-[#1E1B4B]'
      }`}
    >
      {/* Sticky Top Reading Navigation Bar */}
      <div
        className={`sticky top-0 z-30 backdrop-blur-md border-b transition-colors ${
          warmComfortMode
            ? 'bg-[#1E1B36]/95 border-[#342F5C]'
            : 'bg-white/95 border-[#EAE2D3]'
        }`}
      >
        <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              stopNarration();
              onBack();
            }}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl text-sm font-bold transition-colors ${
              warmComfortMode
                ? 'bg-[#2D2852] text-white hover:bg-[#3A3468]'
                : 'bg-[#F3EFE6] text-[#2E2A4A] hover:bg-[#E7E0D2]'
            }`}
          >
            <ArrowRight className="w-4 h-4" />
            <span>المكتبة</span>
          </button>

          <h2 className="text-sm sm:text-base font-extrabold truncate max-w-[160px] sm:max-w-xs">
            {story.title}
          </h2>

          {/* Reader Controls */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleToggleNarration}
              title={isSpeaking ? 'إيقاف الراوي الصوتي' : 'الاستماع للقصة بصوت الراوي'}
              className={`px-3 py-2 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 transition-all ${
                isSpeaking
                  ? 'bg-amber-500 text-white shadow-sm animate-pulse'
                  : warmComfortMode
                  ? 'bg-[#2D2852] text-amber-300 hover:bg-[#3A3468]'
                  : 'bg-[#EEF2FF] text-[#4F46E5] hover:bg-[#E0E7FF]'
              }`}
            >
              {isSpeaking ? <Square className="w-3.5 h-3.5 fill-current" /> : <Volume2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{isSpeaking ? 'إيقاف الراوي' : 'استمع للقصة'}</span>
            </button>
            <button
              type="button"
              onClick={() => setFontSizeLevel((prev) => Math.max(0, prev - 1))}
              disabled={fontSizeLevel === 0}
              title="تصغير الخط"
              className={`p-2 rounded-xl transition-colors disabled:opacity-40 ${
                warmComfortMode
                  ? 'bg-[#2D2852] text-white hover:bg-[#3A3468]'
                  : 'bg-[#F3EFE6] text-[#2E2A4A] hover:bg-[#E7E0D2]'
              }`}
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setFontSizeLevel((prev) => Math.min(2, prev + 1))}
              disabled={fontSizeLevel === 2}
              title="تكبير الخط"
              className={`p-2 rounded-xl transition-colors disabled:opacity-40 ${
                warmComfortMode
                  ? 'bg-[#2D2852] text-white hover:bg-[#3A3468]'
                  : 'bg-[#F3EFE6] text-[#2E2A4A] hover:bg-[#E7E0D2]'
              }`}
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setWarmComfortMode((prev) => !prev)}
              title={warmComfortMode ? 'الوضع النهاري' : 'وضع القراءة الليلي الهادئ'}
              className={`p-2 rounded-xl transition-colors ${
                warmComfortMode
                  ? 'bg-amber-400/20 text-amber-300'
                  : 'bg-[#F3EFE6] text-[#4F46E5] hover:bg-[#E7E0D2]'
              }`}
            >
              {warmComfortMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => onToggleFavorite(story.id)}
              title={isFavorite ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
              className={`p-2 rounded-xl transition-colors ${
                isFavorite
                  ? 'bg-rose-500 text-white'
                  : warmComfortMode
                  ? 'bg-[#2D2852] text-slate-300 hover:text-rose-400'
                  : 'bg-[#F3EFE6] text-slate-600 hover:text-rose-500'
              }`}
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>

        {/* Smooth Progress Bar */}
        <div className="w-full h-1 bg-[#EAE3D5]/50 overflow-hidden">
          <div
            className="h-full bg-gradient-to-l from-[#4F46E5] to-[#C9A84C] transition-all duration-150"
            style={{ width: `${scrollProgress}%` }}
          />
        </div>
      </div>

      {/* Main Story Content Container */}
      <div className="max-w-3xl mx-auto px-4 pt-6 space-y-6">
        {/* Story Hero Card */}
        <div
          className={`rounded-3xl overflow-hidden border shadow-sm ${
            warmComfortMode
              ? 'bg-[#262246] border-[#3B3566]'
              : 'bg-white border-[#EAE2D3]'
          }`}
        >
          <div className="h-56 sm:h-64 w-full relative bg-[#EEF2FF]">
            <KidsStoryCoverSvg type={story.image} className="w-full h-full object-cover" />
          </div>

          <div className="p-6 sm:p-8">
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span
                style={{
                  backgroundColor: categoryMeta.softBg,
                  color: categoryMeta.accentColor,
                  borderColor: categoryMeta.borderColor,
                }}
                className="px-3.5 py-1 rounded-full text-xs font-bold border"
              >
                {story.categoryLabel}
              </span>
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                  warmComfortMode
                    ? 'bg-[#342F5C] text-indigo-200'
                    : 'bg-[#F4F1EA] text-[#4A4468]'
                }`}
              >
                <Users className="w-3.5 h-3.5 text-[#5B5FEF]" />
                العمر المناسب: {story.ageRange}
              </span>
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                  warmComfortMode
                    ? 'bg-[#342F5C] text-amber-200'
                    : 'bg-[#F4F1EA] text-[#4A4468]'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-[#C9A84C]" />
                وقت القراءة: {story.readingTime}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold leading-snug mb-3">
              {story.title}
            </h1>
            <p
              className={`text-base leading-relaxed ${
                warmComfortMode ? 'text-indigo-200' : 'text-[#5A5575]'
              }`}
            >
              {story.description}
            </p>

            {/* Interactive Audio Storyteller Bar */}
            <div
              className={`mt-5 p-3.5 rounded-2xl border flex flex-wrap items-center justify-between gap-3 ${
                warmComfortMode
                  ? 'bg-[#1E1B36] border-[#3B3566]'
                  : 'bg-[#FAF7F0] border-[#EAE2D3]'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleToggleNarration}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-extrabold inline-flex items-center gap-2 transition-all ${
                    isSpeaking
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'bg-[#4F46E5] hover:bg-[#4338CA] text-white shadow-sm'
                  }`}
                >
                  {isSpeaking ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-current" />
                      <span>إيقاف القراءة الصوتية</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4" />
                      <span>الراوي الصوتي: استمع للقصة</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex items-center gap-1.5 text-xs font-bold">
                <span className="opacity-75">السرعة:</span>
                {[
                  { label: 'هادئ', rate: 0.85 },
                  { label: 'عادي', rate: 0.95 },
                  { label: 'نشيط', rate: 1.12 },
                ].map((opt) => (
                  <button
                    key={opt.label}
                    type="button"
                    onClick={() => {
                      setSpeechRate(opt.rate);
                      if (isSpeaking) {
                        startNarration(
                          activeParagraphIdx !== null ? activeParagraphIdx + 1 : 0,
                          opt.rate
                        );
                      }
                    }}
                    className={`px-2.5 py-1 rounded-lg border transition-all ${
                      speechRate === opt.rate
                        ? 'bg-[#C9A84C] text-white border-[#C9A84C]'
                        : warmComfortMode
                        ? 'bg-[#2D2852] text-indigo-200 border-[#3B3566]'
                        : 'bg-white text-[#4A4468] border-[#E2DACB]'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Story Paragraphs Card */}
        <article
          className={`rounded-3xl p-6 sm:p-10 border shadow-sm space-y-6 ${
            warmComfortMode
              ? 'bg-[#262246] border-[#3B3566]'
              : 'bg-white border-[#EAE2D3]'
          }`}
        >
          {story.content.map((paragraph, index) => {
            const isHighlighted = activeParagraphIdx === index;
            return (
              <p
                key={index}
                onClick={() => {
                  if (isSpeaking) {
                    startNarration(index + 1, speechRate);
                  }
                }}
                className={`${fontSizeClasses} font-medium tracking-normal text-justify rounded-2xl transition-all duration-300 ${
                  isHighlighted
                    ? warmComfortMode
                      ? 'bg-amber-400/15 border-r-4 border-amber-400 pr-4 py-2 text-amber-100'
                      : 'bg-[#FEF9C3]/70 border-r-4 border-[#F59E0B] pr-4 py-2 text-[#1E1B4B]'
                    : warmComfortMode
                    ? 'text-[#F5F2EB]'
                    : 'text-[#221F3B]'
                }`}
              >
                {paragraph}
              </p>
            );
          })}

          {/* End of Story Celebration Badge */}
          <div className="pt-6 flex flex-col items-center justify-center text-center">
            <div
              className={`inline-flex items-center gap-2 px-6 py-2.5 rounded-full border font-extrabold text-base shadow-xs ${
                warmComfortMode
                  ? 'bg-[#342F5C] border-[#C9A84C]/50 text-[#FDE68A]'
                  : 'bg-[#FFFBEB] border-[#F59E0B]/40 text-[#92400E]'
              }`}
            >
              <Sparkles className="w-5 h-5 text-[#F59E0B]" />
              <span>النهاية</span>
              <Sparkles className="w-5 h-5 text-[#F59E0B]" />
            </div>
          </div>
        </article>

        {/* "What Did We Learn?" Moral Highlight Card */}
        <div
          className={`rounded-3xl p-6 sm:p-8 border-2 shadow-sm relative overflow-hidden ${
            warmComfortMode
              ? 'bg-gradient-to-br from-[#2E2956] to-[#231F42] border-[#C9A84C]/60'
              : 'bg-gradient-to-br from-[#EEF2FF] via-[#FAF7F0] to-[#FEF3C7] border-[#C9A84C]'
          }`}
        >
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#F59E0B] text-white flex items-center justify-center shrink-0 shadow-md">
              <Lightbulb className="w-6 h-6" />
            </div>
            <div className="space-y-1.5">
              <span className="text-xs font-extrabold uppercase tracking-wider text-[#B45309]">
                فائدة القصة
              </span>
              <h3 className="text-lg sm:text-xl font-extrabold">ماذا تعلمنا من القصة؟</h3>
              <p
                className={`text-base sm:text-lg font-bold leading-relaxed ${
                  warmComfortMode ? 'text-amber-100' : 'text-[#312E81]'
                }`}
              >
                {story.moralLesson}
              </p>
            </div>
          </div>
        </div>

        {/* Fun Fact & Imagination Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div
            className={`rounded-3xl p-5 border shadow-xs ${
              warmComfortMode
                ? 'bg-[#262246] border-[#3B3566]'
                : 'bg-white border-[#EAE2D3]'
            }`}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-[#4F46E5] mb-2">
              <Sparkles className="w-4 h-4 text-[#F59E0B]" />
              <span>هل تعلم؟ (معلومة مدهشة)</span>
            </div>
            <p
              className={`text-sm leading-relaxed font-medium ${
                warmComfortMode ? 'text-indigo-100' : 'text-[#4A4468]'
              }`}
            >
              {funExtras.funFact}
            </p>
          </div>

          <div
            className={`rounded-3xl p-5 border shadow-xs ${
              warmComfortMode
                ? 'bg-[#262246] border-[#3B3566]'
                : 'bg-white border-[#EAE2D3]'
            }`}
          >
            <div className="flex items-center gap-2 text-sm font-extrabold text-[#D97706] mb-2">
              <Compass className="w-4 h-4 text-[#4F46E5]" />
              <span>تخيل وشارك مع عائلتك</span>
            </div>
            <p
              className={`text-sm leading-relaxed font-medium ${
                warmComfortMode ? 'text-indigo-100' : 'text-[#4A4468]'
              }`}
            >
              {funExtras.thinkPrompt}
            </p>
          </div>
        </div>

        {/* Hero Daily Good Deed Challenge */}
        <div
          className={`rounded-3xl p-5 border flex flex-wrap items-center justify-between gap-4 ${
            warmComfortMode
              ? 'bg-[#2D2852] border-[#4338CA]'
              : 'bg-[#F5F3FF] border-[#D6D8FF]'
          }`}
        >
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 text-xs font-extrabold text-[#4F46E5]">
              <Award className="w-4 h-4 text-[#F59E0B]" />
              <span>مهمة البطل الصغير العملية</span>
            </div>
            <p className="text-sm sm:text-base font-bold">{funExtras.heroChallenge}</p>
          </div>
          <button
            type="button"
            onClick={() => {
              if (!heroMissionDone) {
                setHeroMissionDone(true);
                soundManager.playCompletionChime(0.5);
              }
            }}
            className={`px-4 py-2 rounded-2xl text-xs font-extrabold transition-all shrink-0 ${
              heroMissionDone
                ? 'bg-emerald-600 text-white'
                : 'bg-[#4F46E5] hover:bg-[#4338CA] text-white'
            }`}
          >
            {heroMissionDone ? 'أحسنت يا بطل الخير! ✅' : 'سأنفذ المهمة بإذن الله 🤝'}
          </button>
        </div>

        {/* Interactive Story Quiz Card */}
        <div
          className={`rounded-3xl p-6 sm:p-8 border shadow-sm space-y-5 ${
            warmComfortMode
              ? 'bg-[#262246] border-[#3B3566]'
              : 'bg-white border-[#EAE2D3]'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-[#EEF2FF] text-[#4F46E5] flex items-center justify-center">
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-extrabold">تحدي ذكاء القصة التفاعلي 🎯</h3>
                <p className="text-xs opacity-75">
                  أجب عن السؤالين لتحصل على 5 نجوم ذهبية في جواز القارئ الصغير!
                </p>
              </div>
            </div>

            {isQuizSolved && (
              <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-100 text-amber-800 text-xs font-extrabold">
                <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                <span>مكتمل (+5 نجوم)</span>
              </span>
            )}
          </div>

          <div className="space-y-5">
            {funExtras.quiz.map((q, qIdx) => {
              const chosenIdx = selectedAnswers[q.id];
              const isAnswered = chosenIdx !== undefined;
              const isCorrect = chosenIdx === q.correctIndex;

              return (
                <div
                  key={q.id}
                  className={`p-4 sm:p-5 rounded-2xl border space-y-3 ${
                    warmComfortMode
                      ? 'bg-[#1E1B36] border-[#342F5C]'
                      : 'bg-[#FAF7F0] border-[#EAE2D3]'
                  }`}
                >
                  <p className="text-sm sm:text-base font-extrabold">
                    {qIdx + 1}. {q.question}
                  </p>

                  <div className="space-y-2">
                    {q.options.map((opt, optIdx) => {
                      const isThisSelected = chosenIdx === optIdx;
                      const isThisRight = optIdx === q.correctIndex;

                      let btnStyle = warmComfortMode
                        ? 'bg-[#262246] border-[#3B3566] text-white hover:border-[#6366F1]'
                        : 'bg-white border-[#E2DACB] text-[#1E1B4B] hover:border-[#4F46E5]';

                      if (isAnswered) {
                        if (isThisRight) {
                          btnStyle = 'bg-emerald-600 border-emerald-600 text-white';
                        } else if (isThisSelected && !isThisRight) {
                          btnStyle = 'bg-rose-500 border-rose-500 text-white';
                        }
                      }

                      return (
                        <button
                          key={optIdx}
                          type="button"
                          onClick={() => handleAnswerQuiz(q.id, optIdx, q.correctIndex)}
                          className={`w-full text-right px-4 py-3 rounded-xl border text-xs sm:text-sm font-bold transition-all flex items-center justify-between gap-2 ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {isAnswered && isThisRight && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>

                  {isAnswered && (
                    <div
                      className={`p-3 rounded-xl text-xs font-bold ${
                        isCorrect
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {isCorrect ? q.explanation : 'فكّر مرة أخرى وجرب الخيار الصحيح يا بطل! 💡'}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Share Toast Feedback */}
        {shareFeedback && (
          <div className="p-3.5 rounded-2xl bg-emerald-600 text-white text-center text-sm font-bold shadow-md">
            {shareFeedback}
          </div>
        )}

        {/* Interactive Bottom Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <button
            type="button"
            onClick={() => onToggleFavorite(story.id)}
            className={`flex items-center justify-center gap-2 py-3.5 px-5 rounded-2xl font-bold text-sm border transition-all ${
              isFavorite
                ? 'bg-rose-500 text-white border-rose-500 shadow-md shadow-rose-500/20'
                : warmComfortMode
                ? 'bg-[#262246] text-white border-[#3B3566] hover:border-rose-400'
                : 'bg-white text-[#2E2A4A] border-[#E2DACB] hover:border-rose-400'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
            <span>{isFavorite ? 'محفوظة في المفضلة' : 'إضافة للمفضلة'}</span>
          </button>

          <button
            type="button"
            onClick={handleShare}
            className={`flex items-center justify-center gap-2 py-3.5 px-5 rounded-2xl font-bold text-sm border transition-all ${
              warmComfortMode
                ? 'bg-[#262246] text-white border-[#3B3566] hover:bg-[#322D59]'
                : 'bg-white text-[#2E2A4A] border-[#E2DACB] hover:bg-[#FAF7F0]'
            }`}
          >
            <Share2 className="w-4 h-4 text-[#4F46E5]" />
            <span>مشاركة القصة</span>
          </button>

          <button
            type="button"
            onClick={() => {
              stopNarration();
              onPickAnotherStory(story.id);
            }}
            className="flex items-center justify-center gap-2 py-3.5 px-5 rounded-2xl font-bold text-sm bg-[#4F46E5] hover:bg-[#4338CA] text-white shadow-md shadow-indigo-500/20 transition-all"
          >
            <Shuffle className="w-4 h-4" />
            <span>قصة أخرى</span>
          </button>
        </div>
      </div>
    </div>
  );
};

/**
 * Main Kids Stories Page Component (📚 قصص الأطفال - 64 قصة تفاعلية ممتعة)
 */
export const KidsStoriesView: React.FC<KidsStoriesViewProps> = ({ onBack }) => {
  const [selectedStory, setSelectedStory] = useState<KidsStory | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<KidsStoryCategory | 'all'>('all');
  const [selectedAge, setSelectedAge] = useState<KidsAgeRange | 'all'>('all');
  const [selectedTimeGroup, setSelectedTimeGroup] = useState<KidsReadingTimeGroup | 'all'>('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState<boolean>(false);
  const [spinningStoryTitle, setSpinningStoryTitle] = useState<string | null>(null);

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [completedIds, setCompletedIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(COMPLETED_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [starsCount, setStarsCount] = useState<number>(() => {
    try {
      const raw = localStorage.getItem(STARS_STORAGE_KEY);
      return raw ? Number(JSON.parse(raw)) || 0 : 0;
    } catch {
      return 0;
    }
  });

  const [solvedQuizzes, setSolvedQuizzes] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(SOLVED_QUIZZES_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favorites));
    } catch {
      // Ignore storage quota errors
    }
  }, [favorites]);

  useEffect(() => {
    try {
      localStorage.setItem(COMPLETED_STORAGE_KEY, JSON.stringify(completedIds));
    } catch {
      // Ignore storage quota errors
    }
  }, [completedIds]);

  useEffect(() => {
    try {
      localStorage.setItem(STARS_STORAGE_KEY, JSON.stringify(starsCount));
    } catch {
      // Ignore
    }
  }, [starsCount]);

  useEffect(() => {
    try {
      localStorage.setItem(SOLVED_QUIZZES_STORAGE_KEY, JSON.stringify(solvedQuizzes));
    } catch {
      // Ignore
    }
  }, [solvedQuizzes]);

  const handleToggleFavorite = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleMarkCompleted = useMemo(
    () => (id: string) => {
      setCompletedIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
    },
    []
  );

  const handleAwardQuizStars = useCallback((storyId: string, starsEarned: number) => {
    setSolvedQuizzes((prev) => {
      if (prev.includes(storyId)) return prev;
      setStarsCount((s) => s + starsEarned);
      return [...prev, storyId];
    });
  }, []);

  const storyOfTheDay = useMemo(() => getStoryOfTheDay(), []);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const s of KIDS_STORIES) {
      counts[s.category] = (counts[s.category] || 0) + 1;
    }
    return counts;
  }, []);

  const readerRank = useMemo(
    () => getReaderRankTitle(completedIds.length, starsCount),
    [completedIds.length, starsCount]
  );

  const filteredStories = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return KIDS_STORIES.filter((story) => {
      if (showFavoritesOnly && !favorites.includes(story.id)) {
        return false;
      }
      if (selectedCategory !== 'all' && story.category !== selectedCategory) {
        return false;
      }
      if (selectedAge !== 'all' && story.ageRange !== selectedAge) {
        return false;
      }
      if (selectedTimeGroup !== 'all' && story.readingTimeGroup !== selectedTimeGroup) {
        return false;
      }
      if (q) {
        const catMeta = getKidsCategoryMeta(story.category);
        const matchesTitle = story.title.toLowerCase().includes(q);
        const matchesDesc = story.description.toLowerCase().includes(q);
        const matchesMoral = story.moralLesson.toLowerCase().includes(q);
        const matchesCat = story.categoryLabel.toLowerCase().includes(q);
        const matchesKeywords = catMeta.keywords.some((k) => k.toLowerCase().includes(q));
        return matchesTitle || matchesDesc || matchesMoral || matchesCat || matchesKeywords;
      }
      return true;
    });
  }, [searchQuery, selectedCategory, selectedAge, selectedTimeGroup, showFavoritesOnly, favorites]);

  const handleOpenRandomStory = (excludeId?: string) => {
    const pool = KIDS_STORIES.filter((s) => s.id !== excludeId);
    if (pool.length === 0) return;

    // Fun surprise spinner animation when triggered from main view
    if (!excludeId) {
      let ticks = 0;
      const interval = window.setInterval(() => {
        const tempStory = pool[Math.floor(Math.random() * pool.length)];
        setSpinningStoryTitle(tempStory.title);
        ticks += 1;
        if (ticks >= 7) {
          window.clearInterval(interval);
          const chosen = pool[Math.floor(Math.random() * pool.length)];
          setSpinningStoryTitle(null);
          setSelectedStory(chosen);
        }
      }, 90);
      return;
    }

    const randomIndex = Math.floor(Math.random() * pool.length);
    setSelectedStory(pool[randomIndex]);
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedAge('all');
    setSelectedTimeGroup('all');
    setShowFavoritesOnly(false);
  };

  if (selectedStory) {
    return (
      <StoryReaderView
        story={selectedStory}
        isFavorite={favorites.includes(selectedStory.id)}
        isQuizSolved={solvedQuizzes.includes(selectedStory.id)}
        onToggleFavorite={(id) => handleToggleFavorite(id)}
        onBack={() => setSelectedStory(null)}
        onPickAnotherStory={(currentId) => handleOpenRandomStory(currentId)}
        onMarkCompleted={handleMarkCompleted}
        onAwardQuizStars={handleAwardQuizStars}
      />
    );
  }

  const isDefaultView =
    !searchQuery.trim() &&
    selectedCategory === 'all' &&
    selectedAge === 'all' &&
    selectedTimeGroup === 'all' &&
    !showFavoritesOnly;

  return (
    <div className="min-h-screen bg-[#F8F5EE] text-[#1E1B4B] pb-24" dir="rtl">
      {/* Top Header Banner */}
      <div className="bg-gradient-to-b from-[#EDE9FE]/80 via-[#F5F0E8] to-[#F8F5EE] border-b border-[#E6DFD3] pt-6 pb-6 px-4">
        <div className="max-w-6xl mx-auto space-y-5">
          {/* Navigation & Quick Actions Row */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={onBack}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white border border-[#E2DACB] text-[#2E2A4A] text-sm font-bold shadow-2xs hover:border-[#C9A84C] transition-all"
            >
              <ArrowRight className="w-4 h-4 text-[#4F46E5]" />
              <span>الرئيسية</span>
            </button>

            <div className="flex items-center gap-2">
              {/* Favorites Filter Button */}
              <button
                type="button"
                onClick={() => setShowFavoritesOnly((prev) => !prev)}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold border transition-all ${
                  showFavoritesOnly
                    ? 'bg-rose-500 text-white border-rose-500 shadow-md shadow-rose-500/20'
                    : 'bg-white text-[#2E2A4A] border-[#E2DACB] hover:border-rose-300'
                }`}
              >
                <Heart className={`w-4 h-4 ${showFavoritesOnly ? 'fill-current' : 'text-rose-500'}`} />
                <span>المفضلة</span>
                <span
                  className={`px-2 py-0.5 rounded-full text-xs ${
                    showFavoritesOnly ? 'bg-white/20 text-white' : 'bg-rose-50 text-rose-600'
                  }`}
                >
                  {favorites.length}
                </span>
              </button>

              {/* Surprise Story Wheel Button */}
              <button
                type="button"
                onClick={() => handleOpenRandomStory()}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-[#4F46E5] hover:bg-[#4338CA] text-white text-sm font-bold shadow-md shadow-indigo-500/20 transition-all"
              >
                <Shuffle className="w-4 h-4" />
                <span>{spinningStoryTitle ? 'جاري الاختيار...' : 'مفاجأة الحكايات 🎲'}</span>
              </button>
            </div>
          </div>

          {/* Surprise Spinner Banner if spinning */}
          {spinningStoryTitle && (
            <div className="p-4 rounded-2xl bg-gradient-to-l from-[#4F46E5] to-[#C9A84C] text-white text-center font-extrabold text-base shadow-md animate-pulse">
              🎲 دولاب الحكايات يختار لك: «{spinningStoryTitle}»...
            </div>
          )}

          {/* Title, Hero Medallion & Little Reader Passport Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-7 flex items-center gap-4 bg-white/90 backdrop-blur-sm p-4 sm:p-5 rounded-3xl border border-[#EAE2D3] shadow-xs">
              <KidsStoriesHeroMedallion className="w-16 h-16 sm:w-20 sm:h-20 shrink-0" />
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#EEF2FF] text-[#4F46E5] text-xs font-extrabold">
                  <Sparkles className="w-3.5 h-3.5 text-[#C9A84C]" />
                  <span>مكتبة رِفْق التفاعلية ({KIDS_STORIES.length} قصة مصورة)</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1E1B4B]">
                  قصص الأطفال المسلية
                </h1>
                <p className="text-sm sm:text-base text-[#5A5575] font-medium">
                  حكايات ممتعة، راوٍ صوتي تفاعلي، وتحديات ذكاء في كل قصة!
                </p>
              </div>
            </div>

            {/* Little Reader Passport Card */}
            <div className="lg:col-span-5 bg-gradient-to-br from-[#FFFBEB] via-white to-[#EEF2FF] p-4 sm:p-5 rounded-3xl border border-[#E6DFD3] shadow-xs flex flex-col justify-between">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-2xl bg-[#F59E0B]/15 text-[#D97706] flex items-center justify-center">
                    <Trophy className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-[#8A7132]">جواز القارئ الصغير</span>
                    <h3 className="text-sm sm:text-base font-extrabold text-[#1E1B4B]">
                      {readerRank.title}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-extrabold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    {starsCount} نجمة
                  </span>
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-extrabold">
                    <BookOpen className="w-3.5 h-3.5" />
                    {completedIds.length}/{KIDS_STORIES.length}
                  </span>
                </div>
              </div>

              <p className="text-xs text-[#5A5575] font-semibold mt-2">
                {readerRank.subtitle}
              </p>
            </div>
          </div>

          {/* Instant Search Input */}
          <div className="relative">
            <Search className="w-5 h-5 text-[#6E688F] absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في 64 قصة بالعنوان أو الحيوان أو المغامرة أو القيمة التربوية..."
              className="w-full pr-12 pl-10 py-3.5 rounded-2xl bg-white border border-[#E2DACB] focus:border-[#4F46E5] focus:outline-none text-sm sm:text-base text-[#1E1B4B] placeholder:text-[#8C86AA] shadow-xs transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="مسح البحث"
                className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Primary Category Filter Bar */}
          <CategoryFilterBar
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            categoryCounts={categoryCounts}
          />

          {/* Secondary Filters: Age Range & Reading Time */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            {/* Age Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              <span className="text-xs font-bold text-[#6E688F] ml-1 shrink-0">العمر:</span>
              <button
                type="button"
                onClick={() => setSelectedAge('all')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  selectedAge === 'all'
                    ? 'bg-[#C9A84C] text-white shadow-2xs'
                    : 'bg-white/80 text-[#4A4468] border border-[#E6DFD3] hover:border-[#C9A84C]'
                }`}
              >
                كل الأعمار
              </button>
              {KIDS_AGE_RANGES.map((age) => (
                <button
                  key={age}
                  type="button"
                  onClick={() => setSelectedAge(age)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                    selectedAge === age
                      ? 'bg-[#C9A84C] text-white shadow-2xs'
                      : 'bg-white/80 text-[#4A4468] border border-[#E6DFD3] hover:border-[#C9A84C]'
                  }`}
                >
                  {age}
                </button>
              ))}
            </div>

            {/* Reading Time Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              <span className="text-xs font-bold text-[#6E688F] ml-1 shrink-0">المدة:</span>
              <button
                type="button"
                onClick={() => setSelectedTimeGroup('all')}
                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  selectedTimeGroup === 'all'
                    ? 'bg-[#312E81] text-white shadow-2xs'
                    : 'bg-white/80 text-[#4A4468] border border-[#E6DFD3] hover:border-[#312E81]'
                }`}
              >
                كل الأوقات
              </button>
              {KIDS_READING_TIME_GROUPS.map((tf) => (
                <button
                  key={tf}
                  type="button"
                  onClick={() => setSelectedTimeGroup(tf)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all shrink-0 ${
                    selectedTimeGroup === tf
                      ? 'bg-[#312E81] text-white shadow-2xs'
                      : 'bg-white/80 text-[#4A4468] border border-[#E6DFD3] hover:border-[#312E81]'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-6xl mx-auto px-4 pt-6 space-y-8">
        {/* Featured "Story of the Day" Banner */}
        {isDefaultView && storyOfTheDay && (
          <div
            onClick={() => setSelectedStory(storyOfTheDay)}
            className="cursor-pointer group rounded-3xl bg-gradient-to-l from-[#312E81] via-[#4338CA] to-[#4F46E5] text-white p-5 sm:p-7 shadow-lg hover:shadow-xl transition-all overflow-hidden relative"
          >
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              <div className="md:col-span-7 space-y-3">
                <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-400/20 border border-amber-300/40 text-amber-200 text-xs font-extrabold">
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>قصة اليوم المميزة</span>
                </div>

                <h2 className="text-2xl sm:text-3xl font-extrabold leading-tight">
                  {storyOfTheDay.title}
                </h2>

                <p className="text-sm sm:text-base text-indigo-100 leading-relaxed line-clamp-2">
                  {storyOfTheDay.description}
                </p>

                <div className="flex flex-wrap items-center gap-3 pt-1 text-xs font-bold text-indigo-100">
                  <span className="inline-flex items-center gap-1 bg-white/15 px-3 py-1 rounded-full">
                    <Users className="w-3.5 h-3.5 text-amber-300" />
                    {storyOfTheDay.ageRange}
                  </span>
                  <span className="inline-flex items-center gap-1 bg-white/15 px-3 py-1 rounded-full">
                    <Clock className="w-3.5 h-3.5 text-amber-300" />
                    {storyOfTheDay.readingTime}
                  </span>
                  <span className="inline-flex items-center gap-1 bg-white/15 px-3 py-1 rounded-full">
                    <Volume2 className="w-3.5 h-3.5 text-amber-300" />
                    مع الراوي الصوتي وتحدي النجوم
                  </span>
                </div>

                <div className="pt-2">
                  <span className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-[#F59E0B] group-hover:bg-[#D97706] text-white font-extrabold text-sm shadow-md transition-colors">
                    <BookOpen className="w-4 h-4" />
                    <span>اقرأ واستمع لقصة اليوم</span>
                  </span>
                </div>
              </div>

              <div className="md:col-span-5 h-44 sm:h-48 rounded-2xl overflow-hidden border-2 border-white/20 shadow-inner bg-white/10">
                <KidsStoryCoverSvg
                  type={storyOfTheDay.image}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* Section Count & Active Filter Summary */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-extrabold text-[#1E1B4B]">
              {showFavoritesOnly
                ? 'القصص المفضلة'
                : selectedCategory === 'all'
                ? 'جميع القصص الممتعة'
                : getKidsCategoryMeta(selectedCategory).title}
            </h2>
            <span className="px-2.5 py-0.5 rounded-full bg-[#EAE3D5] text-[#3D385B] text-xs font-extrabold">
              {filteredStories.length} قصة
            </span>
          </div>

          {!isDefaultView && (
            <button
              type="button"
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#4F46E5] hover:underline"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة ضبط الفلاتر</span>
            </button>
          )}
        </div>

        {/* Stories Grid or Empty State */}
        {filteredStories.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredStories.map((story) => (
              <StoryCard
                key={story.id}
                story={story}
                isFavorite={favorites.includes(story.id)}
                isCompleted={completedIds.includes(story.id)}
                isQuizSolved={solvedQuizzes.includes(story.id)}
                onToggleFavorite={handleToggleFavorite}
                onOpenStory={(s) => setSelectedStory(s)}
              />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-3xl border border-[#EAE2D3] p-10 text-center max-w-md mx-auto my-8 space-y-4 shadow-xs">
            <div className="w-16 h-16 rounded-full bg-[#EEF2FF] text-[#4F46E5] flex items-center justify-center mx-auto">
              <BookOpen className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-extrabold text-[#1E1B4B]">
              {showFavoritesOnly
                ? 'لا توجد قصص في المفضلة حتى الآن'
                : 'لم نجد قصصاً مطابقة لبحثك'}
            </h3>
            <p className="text-sm text-[#5A5575] leading-relaxed">
              {showFavoritesOnly
                ? 'اضغط على رمز القلب في أي قصة تعجبك لتجدها محفوظة هنا في كل وقت.'
                : 'جرّب البحث بكلمة أخرى أو اختيار تصنيف مختلف لاستكشاف المزيد من الحكايات.'}
            </p>
            <button
              type="button"
              onClick={handleResetFilters}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-[#4F46E5] text-white text-sm font-bold hover:bg-[#4338CA] transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              <span>عرض جميع القصص</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
