import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Bell,
  BellOff,
  Clock,
  Check,
  CheckCheck,
  Trash2,
  Plus,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  Sparkles,
  Award,
  ShieldCheck,
  Play,
  ExternalLink,
  Calendar,
  AlertCircle,
  X,
  Target,
  ChevronRight,
} from 'lucide-react';
import {
  DailyReminderItem,
  DailyReminderPreferences,
  ReminderCategory,
  PRESET_DUAS_AND_TASBIHS,
  loadDailyReminders,
  saveDailyReminders,
  loadReminderPreferences,
  saveReminderPreferences,
  fireDailyReminderItem,
  formatTime12HourArabic,
  isWithinQuietHours,
} from '../../utils/dailyRemindersService';
import {
  getNotificationPermission,
  requestNotificationPermission,
  subscribeToNotificationSettings,
  saveUnifiedNotificationSettings,
  openSystemNotificationSettings,
  NotificationManager,
  PermissionState,
} from '../../utils/notifications';
import {
  getCurrentCity,
  getPrayerSettings,
  savePrayerSettings,
  triggerTestAdhan,
} from '../../utils/prayerScheduler';
import {
  calculateAllPrayerData,
  formatPrayerTime,
} from '../../utils/prayerCalculator';
import {
  loadGoalNotificationPreferences,
  saveGoalNotificationPreferences,
  sendTestGoalNotification,
  sendTestAchievementNotification,
  GoalNotificationPreferences,
} from '../../utils/goalAndAchievementNotificationService';
import {
  loadSettings,
  loadHistory,
  getTodayRecord,
} from '../../utils/storage';
import { evaluateAchievementBadges } from '../../utils/achievementBadges';
import { loadPrayerTrackerHistory } from '../../utils/prayerFocusService';
import { ScreenType, WardType, PrayerKey, PrayerSettings } from '../../types';

interface DailyRemindersViewProps {
  onBack?: () => void;
  onNavigate?: (screen: ScreenType) => void;
  onOpenWard?: (ward: WardType) => void;
  onSelectTasbeehDhikr?: (dhikrText: string, targetCount: number) => void;
}

const ARABIC_DAYS = [
  { day: 0, short: 'الأحد' },
  { day: 1, short: 'الإثنين' },
  { day: 2, short: 'الثلاثاء' },
  { day: 3, short: 'الأربعاء' },
  { day: 4, short: 'الخميس' },
  { day: 5, short: 'الجمعة' },
  { day: 6, short: 'السبت' },
];

const CATEGORY_LABELS: Record<ReminderCategory, string> = {
  morning_evening: 'أذكار الصباح والمساء',
  tasbeeh: 'ورد تسبيح يومي',
  dua: 'دعاء مأثور',
  istighfar: 'استغفار وتوبة',
  salawat: 'الصلاة على النبي ﷺ',
  sleep: 'أذكار النوم',
};

const PRAYER_DISPLAY_INFO: { key: PrayerKey; nameAr: string; desc: string; icon: string }[] = [
  { key: 'fajr', nameAr: 'الفجر', desc: 'أول النهار وقرآن الفجر المشهود', icon: '🌅' },
  { key: 'sunrise', nameAr: 'الشروق', desc: 'شروق الشمس ونهاية وقت الفجر', icon: '☀️' },
  { key: 'dhuhr', nameAr: 'الظهر', desc: 'زوال الشمس في كبد السماء', icon: '☀️' },
  { key: 'asr', nameAr: 'العصر', desc: 'الصلاة الوسطى وفضل عظيم', icon: '🌤️' },
  { key: 'maghrib', nameAr: 'المغرب', desc: 'غروب الشمس ووقت الإفطار', icon: '🌇' },
  { key: 'isha', nameAr: 'العشاء', desc: 'خاتمة صلوات الفريضة بالليل', icon: '🌌' },
];

export const DailyRemindersView: React.FC<DailyRemindersViewProps> = ({
  onBack,
  onNavigate,
  onOpenWard,
  onSelectTasbeehDhikr,
}) => {
  // Navigation sub-tabs: 'prayers' | 'adhkar' | 'goals' | 'settings'
  const [activeTab, setActiveTab] = useState<'prayers' | 'adhkar' | 'goals' | 'settings'>('prayers');

  // Adhkar Reminders State
  const [reminders, setReminders] = useState<DailyReminderItem[]>(() => loadDailyReminders());
  const [prefs, setPrefs] = useState<DailyReminderPreferences>(() => loadReminderPreferences());
  const [permissionState, setPermissionState] = useState<PermissionState>(() =>
    getNotificationPermission()
  );
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [selectedFilterCategory, setSelectedFilterCategory] = useState<string>('all');

  // Prayer Settings State
  const [prayerSettings, setPrayerSettingsState] = useState<PrayerSettings>(() => getPrayerSettings());
  const currentCity = useMemo(() => getCurrentCity(), []);
  const todayCalculated = useMemo(() => {
    try {
      return calculateAllPrayerData(
        currentCity.latitude,
        currentCity.longitude,
        new Date(),
        prayerSettings
      );
    } catch {
      return null;
    }
  }, [currentCity, prayerSettings]);

  // Goal & Achievement Notification Settings
  const [goalPrefs, setGoalPrefs] = useState<GoalNotificationPreferences>(() =>
    loadGoalNotificationPreferences()
  );

  // App Stats for Goals Tab
  const userSettings = useMemo(() => loadSettings(), []);
  const history = useMemo(() => loadHistory(), []);
  const todayRecord = useMemo(() => getTodayRecord(history), [history]);
  const badgeStats = useMemo(() => evaluateAchievementBadges(history), [history]);
  const prayerTracker = useMemo(() => loadPrayerTrackerHistory(), []);

  const todayStr = useMemo(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate()
    ).padStart(2, '0')}`;
  }, []);

  const completedPrayersTodayCount = useMemo(() => {
    const todayPrayers = prayerTracker[todayStr]?.prayers;
    if (!todayPrayers) return 0;
    return Object.entries(todayPrayers).filter(
      ([k, v]) => k !== 'sunrise' && v !== 'none' && v !== 'missed'
    ).length;
  }, [prayerTracker, todayStr]);

  // New Custom Reminder Form State
  const [newTitle, setNewTitle] = useState('');
  const [newText, setNewText] = useState('');
  const [newTime, setNewTime] = useState('08:00');
  const [newCategory, setNewCategory] = useState<ReminderCategory>('tasbeeh');
  const [newTarget, setNewTarget] = useState<number>(100);
  const [newDays, setNewDays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  const syncPermStatus = useCallback(async () => {
    try {
      const detailed = await NotificationManager.getDetailedStatus();
      if (detailed.granted && detailed.areNotificationsEnabled) {
        setPermissionState('granted');
      } else if (detailed.permanentlyBlocked || detailed.postNotificationsPermission === 'denied') {
        setPermissionState('denied');
      } else {
        setPermissionState(getNotificationPermission());
      }
    } catch {
      setPermissionState(getNotificationPermission());
    }
  }, []);

  useEffect(() => {
    syncPermStatus();
    const unsubscribe = subscribeToNotificationSettings(() => {
      setReminders(loadDailyReminders());
      setPrefs(loadReminderPreferences());
      setPrayerSettingsState(getPrayerSettings());
      setGoalPrefs(loadGoalNotificationPreferences());
      syncPermStatus();
    });
    window.addEventListener('focus', syncPermStatus);
    return () => {
      unsubscribe();
      window.removeEventListener('focus', syncPermStatus);
    };
  }, [syncPermStatus]);

  const handleUpdatePrefs = (partial: Partial<DailyReminderPreferences>) => {
    const updated = { ...prefs, ...partial };
    setPrefs(updated);
    saveReminderPreferences(updated);
    if (partial.masterEnabled !== undefined) {
      saveUnifiedNotificationSettings({ remindersChannelEnabled: partial.masterEnabled });
    }
    showToast('تم حفظ تفضيلات الإشعارات بنجاح');
  };

  const handleUpdateGoalPrefs = (partial: Partial<GoalNotificationPreferences>) => {
    const updated = { ...goalPrefs, ...partial };
    setGoalPrefs(updated);
    saveGoalNotificationPreferences(updated);
    showToast('تم حفظ إعدادات إشعارات الأهداف والأوسمة');
  };

  // Prayer Setting Updates
  const handleTogglePrayerNotification = (pkey: PrayerKey) => {
    const currentlyEnabled = prayerSettings.notifications[pkey] !== false;
    const nextVal = !currentlyEnabled;
    const updated: PrayerSettings = {
      ...prayerSettings,
      notifications: {
        ...prayerSettings.notifications,
        [pkey]: nextVal,
      },
    };
    setPrayerSettingsState(updated);
    savePrayerSettings(updated);
    showToast(
      nextVal
        ? `تم تفعيل تذكير صلاة ${PRAYER_DISPLAY_INFO.find((p) => p.key === pkey)?.nameAr || pkey}`
        : `تم إيقاف تذكير صلاة ${PRAYER_DISPLAY_INFO.find((p) => p.key === pkey)?.nameAr || pkey}`
    );
  };

  const handleTogglePrePrayerReminder = (pkey: PrayerKey) => {
    const currentAlert = prayerSettings.prayerAlerts?.[pkey] || {
      mode: pkey === 'sunrise' ? 'chime' : 'adhan',
      preReminder: pkey !== 'sunrise',
    };
    const nextPre = !currentAlert.preReminder;
    const updated: PrayerSettings = {
      ...prayerSettings,
      prayerAlerts: {
        ...prayerSettings.prayerAlerts,
        [pkey]: {
          ...currentAlert,
          preReminder: nextPre,
        },
      },
    };
    setPrayerSettingsState(updated);
    savePrayerSettings(updated);
    showToast(
      nextPre
        ? `تم تفعيل التذكير المبكر قبل صلاة ${PRAYER_DISPLAY_INFO.find((p) => p.key === pkey)?.nameAr || pkey}`
        : `تم إيقاف التذكير المبكر لصلاة ${PRAYER_DISPLAY_INFO.find((p) => p.key === pkey)?.nameAr || pkey}`
    );
  };

  const handleChangePrayerAlertMode = (pkey: PrayerKey, mode: 'adhan' | 'takbeer' | 'chime' | 'silent' | 'off') => {
    const currentAlert = prayerSettings.prayerAlerts?.[pkey] || {
      mode: 'adhan',
      preReminder: pkey !== 'sunrise',
    };
    const updated: PrayerSettings = {
      ...prayerSettings,
      prayerAlerts: {
        ...prayerSettings.prayerAlerts,
        [pkey]: {
          ...currentAlert,
          mode,
        },
      },
      notifications: {
        ...prayerSettings.notifications,
        [pkey]: mode !== 'off',
      },
    };
    setPrayerSettingsState(updated);
    savePrayerSettings(updated);
    showToast('تم تحديث نغمة التنبيه للصلاة');
  };

  const handleChangePreAdhanMinutes = (mins: number) => {
    const updated: PrayerSettings = {
      ...prayerSettings,
      preAdhanReminderMinutes: mins,
    };
    setPrayerSettingsState(updated);
    savePrayerSettings(updated);
    showToast(`تم تعيين وقت التذكير المبكر إلى ${mins} دقيقة قبل الأذان`);
  };

  // Adhkar Reminders Handlers
  const handleToggleReminder = (id: string) => {
    const updated = reminders.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
    setReminders(updated);
    saveDailyReminders(updated);
    const target = updated.find((r) => r.id === id);
    if (target) {
      if (id === 'rem_morning_athkar') {
        saveUnifiedNotificationSettings({ morningAthkarEnabled: target.enabled });
      } else if (id === 'rem_evening_athkar') {
        saveUnifiedNotificationSettings({ eveningAthkarEnabled: target.enabled });
      } else if (id === 'rem_sleep_athkar') {
        saveUnifiedNotificationSettings({ sleepAthkarEnabled: target.enabled });
      }
      showToast(
        target.enabled
          ? `تم تفعيل تذكير «${target.title}» الساعة ${formatTime12HourArabic(target.time)}`
          : `تم إيقاف تذكير «${target.title}»`
      );
    }
  };

  const handleTimeChange = (id: string, newTimeVal: string) => {
    const updated = reminders.map((r) => (r.id === id ? { ...r, time: newTimeVal } : r));
    setReminders(updated);
    saveDailyReminders(updated);
    if (id === 'rem_morning_athkar') {
      saveUnifiedNotificationSettings({ morningAthkarTime: newTimeVal });
    } else if (id === 'rem_evening_athkar') {
      saveUnifiedNotificationSettings({ eveningAthkarTime: newTimeVal });
    } else if (id === 'rem_sleep_athkar') {
      saveUnifiedNotificationSettings({ sleepAthkarTime: newTimeVal });
    }
    showToast(`تم تحديث وقت التذكير إلى ${formatTime12HourArabic(newTimeVal)}`);
  };

  const handleToggleDay = (id: string, dayNum: number) => {
    const updated = reminders.map((r) => {
      if (r.id !== id) return r;
      const exists = r.daysOfWeek.includes(dayNum);
      const nextDays = exists
        ? r.daysOfWeek.filter((d) => d !== dayNum)
        : [...r.daysOfWeek, dayNum].sort();
      return { ...r, daysOfWeek: nextDays.length > 0 ? nextDays : [dayNum] };
    });
    setReminders(updated);
    saveDailyReminders(updated);
  };

  const handleDeleteReminder = (id: string) => {
    const updated = reminders.filter((r) => r.id !== id);
    setReminders(updated);
    saveDailyReminders(updated);
    showToast('تم حذف التذكير');
  };

  const handleAddCustomReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newText.trim()) {
      showToast('يرجى إدخال عنوان التذكير ونصه');
      return;
    }

    const created: DailyReminderItem = {
      id: `custom_rem_${Date.now()}`,
      title: newTitle.trim(),
      dhikrOrDuaText: newText.trim(),
      category: newCategory,
      time: newTime || '08:00',
      enabled: true,
      daysOfWeek: newDays.length > 0 ? newDays : [0, 1, 2, 3, 4, 5, 6],
      targetCount: Math.max(1, newTarget),
      isCustom: true,
    };

    const updated = [created, ...reminders];
    setReminders(updated);
    saveDailyReminders(updated);
    setNewTitle('');
    setNewText('');
    setShowAddForm(false);
    showToast(`تمت إضافة تذكير «${created.title}» الساعة ${formatTime12HourArabic(created.time)}`);
  };

  const handleSelectPresetDhikr = (preset: typeof PRESET_DUAS_AND_TASBIHS[0]) => {
    setNewTitle(preset.title);
    setNewText(preset.text);
    setNewCategory(preset.category);
    setNewTarget(preset.target);
  };

  const handleRequestPermission = async () => {
    if (permissionState === 'denied') {
      await openSystemNotificationSettings();
    }
    const res = await requestNotificationPermission();
    setPermissionState(res);
    if (res === 'granted') {
      handleUpdatePrefs({ systemPushEnabled: true, masterEnabled: true });
      showToast('تم تفعيل إشعارات المتصفح والنظام بنجاح 🔔');
    } else {
      showToast('إشعارات المتصفح محظورة — يرجى تفعيلها من إعدادات المتصفح أو الموقع');
    }
  };

  // Filtered Adhkar Reminders
  const filteredReminders = useMemo(() => {
    if (selectedFilterCategory === 'all') return reminders;
    if (selectedFilterCategory === 'custom') return reminders.filter((r) => r.isCustom);
    if (selectedFilterCategory === 'wards') {
      return reminders.filter((r) => r.category === 'morning_evening' || r.category === 'sleep');
    }
    if (selectedFilterCategory === 'tasbeeh') {
      return reminders.filter((r) => r.category === 'tasbeeh' || r.category === 'istighfar' || r.category === 'salawat');
    }
    return reminders;
  }, [reminders, selectedFilterCategory]);

  return (
    <div className="min-h-screen bg-[#F7F7FC] text-[#25263A] pb-24 font-cairo" dir="rtl">
      {/* ── الشريط العلوي ── */}
      <header className="sticky top-0 z-30 bg-[#FFFFFF] border-b border-[#E6E6F0] shadow-xs">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                aria-label="رجوع"
                className="w-10 h-10 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center hover:bg-gray-100 cursor-pointer transition-colors"
              >
                <ChevronRight className="w-5 h-5 text-[#5B5FEF]" />
              </button>
            )}
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#5B5FEF] to-[#4145C7] text-white flex items-center justify-center shadow-xs shrink-0">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-black text-base md:text-lg text-[#25263A]">
                نظام التنبيهات والإشعارات اليومية
              </h1>
              <p className="text-[11px] text-[#77798C]">
                مسبحة رفيق المسلم • الصلوات، الأذكار، والأهداف
              </p>
            </div>
          </div>

          {activeTab === 'adhkar' && (
            <button
              type="button"
              onClick={() => setShowAddForm((prev) => !prev)}
              className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>{showAddForm ? 'إلغاء' : 'تذكير جديد'}</span>
            </button>
          )}
        </div>

        {/* ── TABS NAVIGATION ── */}
        <div className="max-w-4xl mx-auto px-4 flex items-center gap-1 overflow-x-auto border-t border-[#E6E6F0]/60 py-1.5 text-xs font-bold scrollbar-none">
          <button
            type="button"
            onClick={() => setActiveTab('prayers')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'prayers'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:bg-gray-100 hover:text-[#25263A]'
            }`}
          >
            <span>مواقيت الصلاة والأذان</span>
            <span className="text-sm">🕌</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('adhkar')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'adhkar'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:bg-gray-100 hover:text-[#25263A]'
            }`}
          >
            <span>الأذكار والأدعية اليومية</span>
            <span className="text-sm">📿</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                activeTab === 'adhkar' ? 'bg-white/20 text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              {reminders.filter((r) => r.enabled).length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('goals')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'goals'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:bg-gray-100 hover:text-[#25263A]'
            }`}
          >
            <span>الأهداف والأوسمة</span>
            <span className="text-sm">🏆</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer shrink-0 flex items-center gap-1.5 ${
              activeTab === 'settings'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] hover:bg-gray-100 hover:text-[#25263A]'
            }`}
          >
            <span>التفضيلات ووقت الهدوء</span>
            <span className="text-sm">⚙️</span>
          </button>
        </div>
      </header>

      {/* ── المحتوى الرئيسي ── */}
      <main className="max-w-4xl mx-auto px-4 py-5 space-y-5">
        {/* شريط حالة إذن الإشعارات للمتصفح والنظام */}
        {permissionState !== 'granted' ? (
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-50 to-amber-100/60 border border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-amber-900 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-700 flex items-center justify-center shrink-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-sm">
                  {permissionState === 'denied'
                    ? 'إشعارات المتصفح محظورة'
                    : 'فعّل إشعارات المتصفح والنظام لتصلك التنبيهات في وقتها'}
                </p>
                <p className="text-xs text-amber-800/80">
                  {permissionState === 'denied'
                    ? 'يرجى السماح بالإشعارات من أيقونة القفل أو الإعدادات في متصفحك'
                    : 'اضغط على تفعيل لتلقي تنبيهات الأذان والورد والأهداف المنجزة'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleRequestPermission}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs cursor-pointer transition-colors shrink-0"
            >
              السماح بالإشعارات 🔔
            </button>
          </div>
        ) : (
          <div className="p-3.5 rounded-2xl bg-[#4CAF82]/10 border border-[#4CAF82]/30 flex items-center justify-between gap-3 text-[#2E7D56] text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#4CAF82]" />
              <span className="font-bold">إشعارات المتصفح والنظام مفعّلة بنجاح ✓</span>
              {isWithinQuietHours(prefs) && (
                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold border border-amber-300">
                  وقت الهدوء نشط حالياً 🌙
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={async () => {
                const res = await NotificationManager.showNotification({
                  id: Date.now(),
                  title: 'اختبار إشعار المتصفح 🔔',
                  body: 'نظام إشعارات مسبحة رفيق المسلم يعمل بنجاح وبأعلى دقة!',
                });
                showToast(res ? 'تم إرسال إشعار التجربة بنجاح' : 'تعذر إرسال الإشعار');
              }}
              className="px-3 py-1.5 rounded-lg bg-white border border-[#4CAF82]/40 hover:bg-[#4CAF82]/10 font-bold text-[11px] cursor-pointer transition-colors shadow-2xs"
            >
              تجربة إشعار فوري 🔔
            </button>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            TAB 1: مواقيت الصلاة والأذان (Prayer Times Reminders)
            ══════════════════════════════════════════════════════════════════ */}
        {activeTab === 'prayers' && (
          <div className="space-y-4 animate-fade-in">
            {/* بطاقة ملخص المدينة والمواقيت */}
            <div className="p-4 rounded-3xl bg-white border border-[#E6E6F0] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#5B5FEF]/10 text-[#5B5FEF] flex items-center justify-center text-xl shrink-0">
                  🕌
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-black text-base text-[#25263A]">
                      مواقيت الصلاة بتوقيت {currentCity.nameAr}
                    </h2>
                    <span className="px-2 py-0.5 rounded-full bg-[#5B5FEF]/10 text-[#5B5FEF] text-[10px] font-bold">
                      {currentCity.countryAr}
                    </span>
                  </div>
                  <p className="text-xs text-[#77798C] mt-0.5">
                    طريقة الحساب: {prayerSettings.calculationMethod} • المذهب: {prayerSettings.madhab === 'Hanafi' ? 'الحنفي' : 'الجمهور (شافعي/مالكي/حنبلي)'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    const res = await triggerTestAdhan('maghrib');
                    showToast(res.message);
                  }}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-bold text-xs shadow-xs hover:shadow-md cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>تجربة الأذان والإشعار</span>
                </button>
                {onNavigate && (
                  <button
                    type="button"
                    onClick={() => onNavigate('prayers')}
                    className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-[#77798C] cursor-pointer"
                    title="فتح جدول الصلوات الكامل"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* إعداد التذكير المبكر قبل الأذان */}
            <div className="p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Clock className="w-5 h-5 text-[#5B5FEF]" />
                <div>
                  <p className="text-xs font-bold text-[#25263A]">
                    التذكير المبكر قبل دخول الوقت (الاستعداد بالوضوء)
                  </p>
                  <p className="text-[11px] text-[#77798C]">
                    إرسال إشعار تنبيهي لطيف قبل أذان الصلاة بعدة دقائق
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 self-end sm:self-center">
                {[5, 10, 15, 20, 30].map((mins) => {
                  const currentMins = prayerSettings.preAdhanReminderMinutes || 15;
                  const isSelected = currentMins === mins;
                  return (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => handleChangePreAdhanMinutes(mins)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#5B5FEF] text-white shadow-2xs'
                          : 'bg-gray-100 hover:bg-gray-200 text-[#77798C]'
                      }`}
                    >
                      {mins} د
                    </button>
                  );
                })}
              </div>
            </div>

            {/* قائمة الصلوات الست وإعدادات كل صلاة */}
            <div className="space-y-3">
              {PRAYER_DISPLAY_INFO.map((item) => {
                const isEnabled = prayerSettings.notifications[item.key] !== false;
                const pDate = todayCalculated?.times[item.key];
                const timeStr = pDate ? formatPrayerTime(pDate, '12h') : '--:--';
                const alertDetail = prayerSettings.prayerAlerts?.[item.key] || {
                  mode: item.key === 'sunrise' ? 'chime' : 'adhan',
                  preReminder: item.key !== 'sunrise',
                };
                const isNextPrayer = todayCalculated?.nextPrayer === item.key;

                return (
                  <div
                    key={item.key}
                    className={`p-4 rounded-2xl border transition-all ${
                      isNextPrayer
                        ? 'bg-gradient-to-r from-indigo-50/60 to-white border-[#5B5FEF]/40 shadow-xs'
                        : isEnabled
                        ? 'bg-white border-[#E6E6F0] shadow-xs'
                        : 'bg-gray-50/70 border-gray-200 opacity-75'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{item.icon}</span>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-sm text-[#25263A]">
                              صلاة {item.nameAr}
                            </h3>
                            {isNextPrayer && (
                              <span className="px-2 py-0.5 rounded-full bg-[#5B5FEF] text-white text-[10px] font-black animate-pulse">
                                الصلاة القادمة
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-[#77798C]">{item.desc}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-left">
                          <span className="font-mono font-black text-sm text-[#4145C7] dir-ltr inline-block">
                            {timeStr}
                          </span>
                        </div>

                        {/* Switch Master for this prayer */}
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={isEnabled}
                            onChange={() => handleTogglePrayerNotification(item.key)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                        </label>
                      </div>
                    </div>

                    {/* خيارات الصوت والتذكير المبكر عند التفعيل */}
                    {isEnabled && (
                      <div className="mt-3 pt-3 border-t border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
                        {/* خيار التذكير المبكر */}
                        {item.key !== 'sunrise' && (
                          <label className="flex items-center gap-2 text-[#77798C] hover:text-[#25263A] cursor-pointer">
                            <input
                              type="checkbox"
                              checked={Boolean(alertDetail.preReminder)}
                              onChange={() => handleTogglePrePrayerReminder(item.key)}
                              className="w-4 h-4 rounded text-[#5B5FEF] focus:ring-[#5B5FEF] border-gray-300"
                            />
                            <span className="text-[11px] font-bold">
                              تنبيه مبكر قبلها بـ {prayerSettings.preAdhanReminderMinutes || 15} دقيقة
                            </span>
                          </label>
                        )}

                        {/* محدد نغمة الصوت */}
                        <div className="flex items-center gap-2 self-end sm:self-auto">
                          <span className="text-[11px] text-[#77798C] font-bold">صوت الإشعار:</span>
                          <select
                            value={alertDetail.mode}
                            onChange={(e) =>
                              handleChangePrayerAlertMode(
                                item.key,
                                e.target.value as 'adhan' | 'takbeer' | 'chime' | 'silent' | 'off'
                              )
                            }
                            className="px-2.5 py-1 rounded-lg bg-gray-100 border border-gray-300 text-xs font-bold text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                          >
                            <option value="adhan">أذان كامل 🕌</option>
                            <option value="takbeer">تكبيرتان 📣</option>
                            <option value="chime">تنبيه هادئ 🔔</option>
                            <option value="silent">إشعار صامت فقط 🔕</option>
                            <option value="off">إيقاف التنبيه ❌</option>
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            TAB 2: الأذكار والأدعية اليومية (Specific Adhkar Reminders)
            ══════════════════════════════════════════════════════════════════ */}
        {activeTab === 'adhkar' && (
          <div className="space-y-4 animate-fade-in">
            {/* Filter chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-bold">
              {[
                { id: 'all', label: 'جميع الأذكار' },
                { id: 'wards', label: 'أوراد اليوم (الصباح، المساء، النوم)' },
                { id: 'tasbeeh', label: 'التسبيح والاستغفار والصلاة على النبي' },
                { id: 'custom', label: 'أذكاري المخصصة' },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setSelectedFilterCategory(f.id)}
                  className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer shrink-0 ${
                    selectedFilterCategory === f.id
                      ? 'bg-[#5B5FEF] text-white shadow-2xs'
                      : 'bg-white border border-[#E6E6F0] text-[#77798C] hover:bg-gray-100'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {/* نموذج إضافة تذكير بذكر مخصص */}
            {showAddForm && (
              <form
                onSubmit={handleAddCustomReminder}
                className="p-5 rounded-3xl bg-white border-2 border-[#5B5FEF]/30 shadow-md space-y-4 animate-fade-in"
              >
                <div className="flex items-center justify-between border-b border-[#E6E6F0] pb-2.5">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-[#5B5FEF]" />
                    <h3 className="font-bold text-sm text-[#25263A]">
                      إضافة تذكير بذكر أو دعاء مخصص
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="p-1.5 rounded-full hover:bg-gray-100 text-gray-400"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* أذكار وأدعية مأثورة جاهزة للاختيار السريع */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-[#77798C]">
                    أو اختر نموذجاً مباركاً جاهزاً:
                  </span>
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                    {PRESET_DUAS_AND_TASBIHS.map((p) => (
                      <button
                        key={p.title}
                        type="button"
                        onClick={() => handleSelectPresetDhikr(p)}
                        className="px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-[#5B5FEF]/10 hover:text-[#5B5FEF] text-gray-700 text-xs font-bold transition-colors shrink-0 cursor-pointer"
                      >
                        {p.title}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[#77798C] mb-1">
                      عنوان التذكير
                    </label>
                    <input
                      type="text"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="مثال: ورد التسبيح، سيد الاستغفار..."
                      className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#77798C] mb-1">
                      التصنيف
                    </label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value as ReminderCategory)}
                      className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                    >
                      <option value="tasbeeh">ورد تسبيح</option>
                      <option value="istighfar">استغفار وتوبة</option>
                      <option value="salawat">الصلاة على النبي ﷺ</option>
                      <option value="dua">دعاء مأثور</option>
                      <option value="morning_evening">أذكار</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#77798C] mb-1">
                    نص الذكر أو الدعاء
                  </label>
                  <textarea
                    rows={2}
                    value={newText}
                    onChange={(e) => setNewText(e.target.value)}
                    placeholder="اكتب نص الذكر أو الدعاء المبارك..."
                    className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-none focus:border-[#5B5FEF] resize-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-[#77798C] mb-1">
                      وقت التذكير اليومي (24 ساعة)
                    </label>
                    <input
                      type="time"
                      value={newTime}
                      onChange={(e) => setNewTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#77798C] mb-1">
                      العدد المستهدف للتسبيح
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={10000}
                      value={newTarget}
                      onChange={(e) => setNewTarget(parseInt(e.target.value, 10) || 1)}
                      className="w-full px-3 py-2 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0] text-xs font-bold text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#77798C] mb-1">
                    أيام التكرار الأسبوعية
                  </label>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {ARABIC_DAYS.map((d) => {
                      const isDaySelected = newDays.includes(d.day);
                      return (
                        <button
                          key={d.day}
                          type="button"
                          onClick={() => {
                            setNewDays((prev) =>
                              isDaySelected
                                ? prev.filter((x) => x !== d.day)
                                : [...prev, d.day].sort()
                            );
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                            isDaySelected
                              ? 'bg-[#5B5FEF] text-white shadow-2xs'
                              : 'bg-gray-100 text-[#77798C] hover:bg-gray-200'
                          }`}
                        >
                          {d.short}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="px-4 py-2 rounded-xl bg-gray-100 text-gray-700 text-xs font-bold hover:bg-gray-200 cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold hover:bg-[#4145C7] shadow-xs cursor-pointer"
                  >
                    حفظ التذكير المبارك
                  </button>
                </div>
              </form>
            )}

            {/* بطاقات الأذكار */}
            <div className="space-y-3">
              {filteredReminders.map((rem) => {
                return (
                  <div
                    key={rem.id}
                    className={`p-4 rounded-3xl border transition-all ${
                      rem.enabled
                        ? 'bg-white border-[#E6E6F0] shadow-xs'
                        : 'bg-gray-50/70 border-gray-200 opacity-75'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-bold text-sm text-[#25263A]">{rem.title}</h3>
                          <span className="px-2 py-0.5 rounded-md bg-gray-100 text-[#77798C] text-[10px] font-bold">
                            {CATEGORY_LABELS[rem.category] || 'أذكار'}
                          </span>
                          {rem.targetCount > 1 && (
                            <span className="px-2 py-0.5 rounded-md bg-[#5B5FEF]/10 text-[#5B5FEF] text-[10px] font-bold">
                              الهدف: {rem.targetCount} مرة
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-[#77798C] leading-relaxed line-clamp-2">
                          {rem.dhikrOrDuaText}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={rem.enabled}
                            onChange={() => handleToggleReminder(rem.id)}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                        </label>
                      </div>
                    </div>

                    {/* خيارات الوقت والأيام وإجراءات الذكر */}
                    <div className="mt-3 pt-3 border-t border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-[#77798C]" />
                        <span className="text-[11px] font-bold text-[#77798C]">وقت التذكير:</span>
                        <input
                          type="time"
                          value={rem.time}
                          onChange={(e) => handleTimeChange(rem.id, e.target.value)}
                          className="px-2 py-1 rounded-lg bg-gray-100 border border-gray-300 font-mono font-bold text-xs text-[#25263A] focus:outline-none focus:border-[#5B5FEF]"
                        />
                        <span className="text-[11px] font-bold text-[#5B5FEF]">
                          ({formatTime12HourArabic(rem.time)})
                        </span>
                      </div>

                      {/* أزرار التجربة والبدء بالمسبحة */}
                      <div className="flex items-center gap-1.5 self-end sm:self-auto">
                        <button
                          type="button"
                          onClick={async () => {
                            await fireDailyReminderItem(rem, prefs);
                            showToast(`تم إرسال إشعار تجريبي لـ «${rem.title}»`);
                          }}
                          className="p-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-[#77798C] transition-colors cursor-pointer"
                          title="تجربة إرسال هذا الإشعار الآن"
                        >
                          <Bell className="w-3.5 h-3.5" />
                        </button>

                        {onSelectTasbeehDhikr && (
                          <button
                            type="button"
                            onClick={() => onSelectTasbeehDhikr(rem.dhikrOrDuaText, rem.targetCount)}
                            className="px-2.5 py-1 rounded-lg bg-[#5B5FEF]/10 hover:bg-[#5B5FEF]/20 text-[#5B5FEF] font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
                          >
                            <span>تسبيح</span>
                            <span>📿</span>
                          </button>
                        )}

                        {rem.linkedWard && onOpenWard && (
                          <button
                            type="button"
                            onClick={() => onOpenWard(rem.linkedWard!)}
                            className="px-2.5 py-1 rounded-lg bg-[#4CAF82]/10 hover:bg-[#4CAF82]/20 text-[#4CAF82] font-bold text-[11px] transition-colors cursor-pointer"
                          >
                            فتح الورد 📖
                          </button>
                        )}

                        {rem.isCustom && (
                          <button
                            type="button"
                            onClick={() => handleDeleteReminder(rem.id)}
                            className="p-1.5 rounded-lg hover:bg-rose-50 text-rose-500 transition-colors cursor-pointer"
                            title="حذف هذا التذكير"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* محدد أيام الأسبوع */}
                    <div className="mt-2 flex items-center gap-1 overflow-x-auto pb-0.5">
                      <span className="text-[10px] text-[#77798C] ml-1 shrink-0">التكرار:</span>
                      {ARABIC_DAYS.map((d) => {
                        const active = rem.daysOfWeek.includes(d.day);
                        return (
                          <button
                            key={d.day}
                            type="button"
                            onClick={() => handleToggleDay(rem.id, d.day)}
                            className={`w-6 h-6 rounded-md text-[10px] font-bold flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                              active
                                ? 'bg-[#5B5FEF] text-white'
                                : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                            }`}
                          >
                            {d.short[0]}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            TAB 3: إنجاز الأهداف والأوسمة (Goals & Achievements)
            ══════════════════════════════════════════════════════════════════ */}
        {activeTab === 'goals' && (
          <div className="space-y-4 animate-fade-in">
            {/* ملخص التقدم الحقيقي للأهداف اليوم */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* الهدف اليومي للتسبيح */}
              <div className="p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-[#77798C]">
                  <span className="font-bold">هدف التسبيح اليومي</span>
                  <Target className="w-4 h-4 text-[#5B5FEF]" />
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-[#25263A]">
                    {todayRecord.totalCount}
                  </span>
                  <span className="text-xs text-[#77798C]">
                    / {userSettings.dailyGoal || 100} تسبيحة
                  </span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-[#5B5FEF] h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round(
                          (todayRecord.totalCount / Math.max(1, userSettings.dailyGoal || 100)) *
                            100
                        )
                      )}%`,
                    }}
                  />
                </div>
                <p className="text-[10px] text-[#77798C]">
                  {todayRecord.totalCount >= (userSettings.dailyGoal || 100)
                    ? '🎉 ما شاء الله! تم إكمال الهدف اليومي'
                    : `متبقي ${(userSettings.dailyGoal || 100) - todayRecord.totalCount} تسبيحة`}
                </p>
              </div>

              {/* الصلوات الخمس اليوم */}
              <div className="p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-[#77798C]">
                  <span className="font-bold">صلوات اليوم الخمس</span>
                  <span className="text-base">🕌</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-[#25263A]">
                    {completedPrayersTodayCount}
                  </span>
                  <span className="text-xs text-[#77798C]">/ 5 صلوات</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-[#4CAF82] h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, Math.round((completedPrayersTodayCount / 5) * 100))}%`,
                    }}
                  />
                </div>
                <p className="text-[10px] text-[#77798C]">
                  {completedPrayersTodayCount >= 5
                    ? '🌟 مبارك! أتممت صلوات اليوم كلها'
                    : `متبقي ${5 - completedPrayersTodayCount} صلوات لليوم`}
                </p>
              </div>

              {/* الأوسمة المكتسبة */}
              <div className="p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-[#77798C]">
                  <span className="font-bold">أوسمة الإنجاز</span>
                  <Award className="w-4 h-4 text-amber-500" />
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-black text-amber-600">
                    {badgeStats.unlockedBadges.length}
                  </span>
                  <span className="text-xs text-[#77798C]">
                    / {badgeStats.badges.length} وساماً
                  </span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round(
                          (badgeStats.unlockedBadges.length / Math.max(1, badgeStats.badges.length)) *
                            100
                        )
                      )}%`,
                    }}
                  />
                </div>
                <p className="text-[10px] text-[#77798C]">
                  سلسلة المواظبة الحالية: {badgeStats.sevenDayChallenge.currentStreak} يوم متتالي
                </p>
              </div>
            </div>

            {/* خيارات تفعيل إشعارات الأهداف والأوسمة */}
            <div className="p-5 rounded-3xl bg-white border border-[#E6E6F0] shadow-xs space-y-4">
              <div>
                <h3 className="font-black text-sm text-[#25263A] flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#5B5FEF]" />
                  <span>تفضيلات إشعارات الإنجازات والأهداف</span>
                </h3>
                <p className="text-xs text-[#77798C] mt-0.5">
                  أرسل إشعاراً فورياً على شاشة جهازك وشريط الإشعارات فور تحقيق أي إنجاز أو هدف
                </p>
              </div>

              <div className="space-y-3 pt-2">
                {/* الهدف اليومي للتسبيح */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div>
                    <p className="text-xs font-bold text-[#25263A]">
                      إشعار إكمال الهدف اليومي للتسبيح 🎉
                    </p>
                    <p className="text-[11px] text-[#77798C]">
                      ينبهك فور وصولك لـ {userSettings.dailyGoal || 100} تسبيحة في اليوم
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={goalPrefs.notifyOnTasbeehGoal}
                      onChange={(e) => handleUpdateGoalPrefs({ notifyOnTasbeehGoal: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>

                {/* الصلوات الخمس */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div>
                    <p className="text-xs font-bold text-[#25263A]">
                      إشعار إتمام الصلوات الخمس كاملة 🕌
                    </p>
                    <p className="text-[11px] text-[#77798C]">
                      ينبهك عند توثيق الفجر والظهر والعصر والمغرب والعشاء في يومك
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={goalPrefs.notifyOnPrayerGoal}
                      onChange={(e) => handleUpdateGoalPrefs({ notifyOnPrayerGoal: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>

                {/* الأوراد اليومية */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div>
                    <p className="text-xs font-bold text-[#25263A]">
                      إشعار إتمام الورد اليومي والأذكار 📿
                    </p>
                    <p className="text-[11px] text-[#77798C]">
                      ينبهك عند إنهاء ورد أذكار الصباح أو المساء أو النوم
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={goalPrefs.notifyOnWirdGoal}
                      onChange={(e) => handleUpdateGoalPrefs({ notifyOnWirdGoal: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>

                {/* الأوسمة والإنجازات الجديدة */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div>
                    <p className="text-xs font-bold text-[#25263A]">
                      إشعار فتح وسام جديد أو رتبة جديدة 🏅
                    </p>
                    <p className="text-[11px] text-[#77798C]">
                      ينبهك فور استحقاقك لأي وسام من أوسمة المواظبة والألفية والتسبيح
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={goalPrefs.notifyOnAchievements}
                      onChange={(e) => handleUpdateGoalPrefs({ notifyOnAchievements: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>

                {/* المؤثرات الصوتية والاحتفالية */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div>
                    <p className="text-xs font-bold text-[#25263A]">
                      مؤثرات الاحتفال الصوتية وقصاصات الفرح 🎊
                    </p>
                    <p className="text-[11px] text-[#77798C]">
                      تشغيل صوت تشجيعي مع قصاصات زينة عند إنجاز الأهداف
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={goalPrefs.soundEnabled}
                      onChange={(e) => handleUpdateGoalPrefs({ soundEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>
              </div>
            </div>

            {/* أزرار التجربة الحية لإشعارات الأهداف */}
            <div className="p-4 rounded-3xl bg-gradient-to-br from-indigo-50/70 to-indigo-100/40 border border-[#5B5FEF]/30 shadow-xs space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#5B5FEF]" />
                <h4 className="font-bold text-sm text-[#4145C7]">
                  تجربة إشعارات الأهداف والأوسمة الحية
                </h4>
              </div>
              <p className="text-xs text-[#77798C]">
                يمكنك الضغط على الأزرار أدناه لتجربة ظهور الإشعار في شريط هاتفك ومتصفحك وسماع صوت الاحتفال:
              </p>

              <div className="flex items-center gap-2 flex-wrap pt-1">
                <button
                  type="button"
                  onClick={async () => {
                    await sendTestGoalNotification();
                    showToast('تم إرسال إشعار إنجاز الهدف 🎉');
                  }}
                  className="px-4 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-bold text-xs shadow-xs cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <span>🎉 تجربة إشعار إنجاز الهدف</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    await sendTestAchievementNotification();
                    showToast('تم إرسال إشعار وسام جديد 🏅');
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <span>🏅 تجربة إشعار وسام جديد</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            TAB 4: التفضيلات ووقت الهدوء (Preferences & Quiet Hours)
            ══════════════════════════════════════════════════════════════════ */}
        {activeTab === 'settings' && (
          <div className="space-y-4 animate-fade-in">
            {/* التفضيلات العامة */}
            <div className="p-5 rounded-3xl bg-white border border-[#E6E6F0] shadow-xs space-y-4">
              <h3 className="font-bold text-sm text-[#25263A] flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#5B5FEF]" />
                <span>إعدادات الإشعارات والتنبيهات العامة</span>
              </h3>

              <div className="space-y-3">
                {/* المفتاح الرئيسي */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div>
                    <p className="text-xs font-bold text-[#25263A]">
                      المفتاح العام للتذكيرات والإشعارات
                    </p>
                    <p className="text-[11px] text-[#77798C]">
                      تشغيل أو إيقاف جميع التذكيرات بنقرة واحدة
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={prefs.masterEnabled}
                      onChange={(e) => handleUpdatePrefs({ masterEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>

                {/* أصوات الإشعارات */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div className="flex items-center gap-2.5">
                    {prefs.soundEnabled ? (
                      <Volume2 className="w-4 h-4 text-[#5B5FEF]" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-gray-400" />
                    )}
                    <div>
                      <p className="text-xs font-bold text-[#25263A]">الصوت والتنبيه الصوتي</p>
                      <p className="text-[11px] text-[#77798C]">
                        تشغيل النغمات والأذان عند حلول التذكيرات
                      </p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={prefs.soundEnabled}
                      onChange={(e) => handleUpdatePrefs({ soundEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>

                {/* الاهتزاز */}
                <div className="flex items-center justify-between p-3 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0]">
                  <div>
                    <p className="text-xs font-bold text-[#25263A]">الاهتزاز اللمسي (Haptic)</p>
                    <p className="text-[11px] text-[#77798C]">اهتزاز الجهاز عند وصول التذكير</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={prefs.vibrationEnabled}
                      onChange={(e) => handleUpdatePrefs({ vibrationEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]"></div>
                  </label>
                </div>
              </div>
            </div>

            {/* وقت الهدوء (Quiet Hours) */}
            <div className="p-5 rounded-3xl bg-white border border-[#E6E6F0] shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Moon className="w-5 h-5 text-indigo-600" />
                  <div>
                    <h3 className="font-bold text-sm text-[#25263A]">
                      وضع الهدوء التلقائي (عدم الإزعاج)
                    </h3>
                    <p className="text-xs text-[#77798C]">
                      كتم الإشعارات الصوتية أثناء أوقات النوم والراحة
                    </p>
                  </div>
                </div>

                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={prefs.quietHoursEnabled}
                    onChange={(e) => handleUpdatePrefs({ quietHoursEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              {prefs.quietHoursEnabled && (
                <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-indigo-900 mb-1">
                        يبدأ وقت الهدوء من:
                      </label>
                      <input
                        type="time"
                        value={prefs.quietHoursStart}
                        onChange={(e) => handleUpdatePrefs({ quietHoursStart: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-indigo-200 text-xs font-bold text-indigo-950 focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-indigo-900 mb-1">
                        وينتهي عند:
                      </label>
                      <input
                        type="time"
                        value={prefs.quietHoursEnd}
                        onChange={(e) => handleUpdatePrefs({ quietHoursEnd: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-white border border-indigo-200 text-xs font-bold text-indigo-950 focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>
                  <p className="text-[11px] text-indigo-800/80 leading-relaxed">
                    ملاحظة: تنبيه صلاة الفجر لن يتأثر بوضع الهدوء لضمان استيقاظك لصلاة الفجر في وقتها بإذن الله.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* رسالة إشعار منبثقة Toast */}
      {toastMsg && (
        <div className="fixed bottom-6 start-1/2 -translate-x-1/2 z-50 bg-[#25263A] text-white text-xs font-bold px-4 py-2.5 rounded-2xl shadow-xl border border-white/10 animate-fade-in flex items-center gap-2 max-w-sm text-center">
          <CheckCheck className="w-4 h-4 text-[#4CAF82] shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}
    </div>
  );
};
