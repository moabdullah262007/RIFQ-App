import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  Search, 
  Star, 
  Share2, 
  Copy, 
  ZoomIn, 
  ZoomOut, 
  Check, 
  Sparkles, 
  BookOpen, 
  HeartHandshake,
  Shield,
  HelpCircle,
  X
} from 'lucide-react';
import { ASMAA_ALLAH_NAMES, AsmaaAllahName } from '../../data/asmaaAllahData';

interface AsmaaAllahMainViewProps {
  onBackToHome: () => void;
}

export const AsmaaAllahMainView: React.FC<AsmaaAllahMainViewProps> = ({ onBackToHome }) => {
  const [selectedTab, setSelectedTab] = useState<'all' | 'jalal' | 'jamal' | 'kamal' | 'favorites'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedName, setSelectedName] = useState<AsmaaAllahName | null>(null);
  const [favorites, setFavorites] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('rifq_asmaa_allah_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [fontScale, setFontScale] = useState(1);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const toggleFavorite = (id: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setFavorites((prev) => {
      const isFav = prev.includes(id);
      const updated = isFav ? prev.filter((item) => item !== id) : [...prev, id];
      try {
        localStorage.setItem('rifq_asmaa_allah_favorites', JSON.stringify(updated));
      } catch {
        // ignore
      }
      showToast(isFav ? 'تم الحذف من المفضلة' : 'تمت الإضافة إلى المفضلة ⭐');
      return updated;
    });
  };

  const clearAllFavorites = () => {
    if (favorites.length === 0) return;
    if (window.confirm('هل تريد إفراغ قائمة المفضلة بالكامل؟')) {
      setFavorites([]);
      localStorage.setItem('rifq_asmaa_allah_favorites', JSON.stringify([]));
      showToast('تم إفراغ المفضلة بنجاح');
    }
  };

  // Filter names based on tab and search
  const filteredNames = ASMAA_ALLAH_NAMES.filter((item) => {
    const matchesSearch = 
      item.name.includes(searchQuery.trim()) ||
      item.meaning.includes(searchQuery.trim()) ||
      item.quranVerse.includes(searchQuery.trim()) ||
      item.hadithText.includes(searchQuery.trim());

    if (!matchesSearch) return false;

    if (selectedTab === 'all') return true;
    if (selectedTab === 'favorites') return favorites.includes(item.id);
    return item.category === selectedTab;
  });

  const copyToClipboard = (text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      showToast('تم النسخ إلى الحافظة بنجاح 📋');
    }
  };

  const shareName = (nameItem: AsmaaAllahName) => {
    const shareText = `🌟 من أسماء الله الحسنى: «${nameItem.name}»\n\n📖 المعنى: ${nameItem.meaning}\n\n✨ الدليل من القرآن: ${nameItem.quranVerse} (${nameItem.quranSurah})\n\n📜 الدليل من السنة: ${nameItem.hadithText} [${nameItem.hadithSource}]\n\n— تطبيق رِفْـق | RIFQ 🕌`;

    if (navigator.share) {
      navigator.share({
        title: `اسم الله: ${nameItem.name}`,
        text: shareText,
      }).catch(() => {});
    } else {
      copyToClipboard(shareText);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F7FC] pb-24 text-[#25263A]" dir="rtl">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-[#25263A] text-white px-5 py-2.5 rounded-full text-sm font-bold shadow-xl border border-[#5B5FEF] animate-fade-in flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ── App Bar ── */}
      <header className="sticky top-0 z-30 bg-[#F7F7FC]/95 backdrop-blur-md border-b border-[#E6E6F0] px-4 py-3 shadow-xs">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                if (selectedName) {
                  setSelectedName(null);
                } else {
                  onBackToHome();
                }
              }}
              className="p-2 rounded-xl bg-white/80 hover:bg-white text-[#25263A] border border-[#E6E6F0] shadow-xs transition-colors cursor-pointer"
              aria-label="الرجوع"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div className="flex flex-col">
              <h1 className="text-xl font-bold font-tajawal text-[#5B5FEF] leading-none">
                {selectedName ? selectedName.name : 'أسماء الله الحسنى'}
              </h1>
              <span className="text-[11px] text-[#77798C] font-tajawal mt-0.5">
                {selectedName ? `الاسم المبارك رقم ${selectedName.id}` : '٩٩ اسماً مباركاً موثقة بأدلتها'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {!selectedName && (
              <button
                onClick={() => setSelectedTab(selectedTab === 'favorites' ? 'all' : 'favorites')}
                className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 ${
                  selectedTab === 'favorites'
                    ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-sm'
                    : 'bg-white/80 text-[#25263A] border-[#E6E6F0] hover:bg-white'
                }`}
                title="المفضلة"
              >
                <Star className={`w-4 h-4 ${selectedTab === 'favorites' ? 'fill-white text-white' : 'text-[#5B5FEF]'}`} />
                <span className="text-xs font-bold font-tajawal">{favorites.length}</span>
              </button>
            )}

            {selectedName && (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => toggleFavorite(selectedName.id)}
                  className="p-2 rounded-xl bg-white border border-[#E6E6F0] text-[#5B5FEF] shadow-xs cursor-pointer"
                  title="إضافة للمفضلة"
                >
                  <Star className={`w-4 h-4 ${favorites.includes(selectedName.id) ? 'fill-[#E8B84A] text-[#5B5FEF]' : 'text-[#5B5FEF]'}`} />
                </button>
                <button
                  onClick={() => shareName(selectedName)}
                  className="p-2 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white shadow-xs cursor-pointer"
                  title="مشاركة الاسم"
                >
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-2xl mx-auto px-4 pt-4">
        {selectedName ? (
          /* ══════════════════════════════════════════
             الشاشة 2: تفاصيل الاسم المبارك
             ══════════════════════════════════════════ */
          <div className="space-y-4 animate-fade-in" style={{ fontSize: `${fontScale * 100}%` }}>
            {/* بطاقة الاسم الرئيسية */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#F7F7FC] via-[#F7F7FC] to-[#F7F7FC] border-2 border-[#5B5FEF] p-6 text-center shadow-[0_8px_24px_rgba(201,168,76,0.18)]">
              {/* زخرفة خلفية ومسجد */}
              <div className="absolute inset-0 pointer-events-none opacity-5 flex items-end justify-center">
                <svg viewBox="0 0 100 65" className="w-full h-36 text-[#5B5FEF] fill-current" preserveAspectRatio="none">
                  <path d="M 8,65 L 8,24 L 14,24 L 14,14 L 11,14 L 11,8 L 15,2 L 19,8 L 19,14 L 16,14 L 16,24 L 22,24 L 22,65 Z" />
                  <path d="M 28,65 L 28,34 Q 50,8 72,34 L 72,65 Z" />
                  <path d="M 78,65 L 78,28 L 83,28 L 83,18 L 81,18 L 81,12 L 85,5 L 89,12 L 89,18 L 87,18 L 87,28 L 92,28 L 92,65 Z" />
                </svg>
              </div>

              {/* رقم الاسم */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EEEEFF] border border-[#E6E6F0] text-[#4145C7] font-bold text-xs font-tajawal mb-2">
                <span>─── الاسم رقم {selectedName.id} ───</span>
              </div>

              {/* الاسم بالخط الأميري الكبير 56px */}
              <h2 className="text-[56px] font-bold font-serif text-[#5B5FEF] leading-none my-2 drop-shadow-[0_2px_4px_rgba(201,168,76,0.25)]">
                {selectedName.name}
              </h2>

              {/* المعنى الموجز */}
              <p className="text-sm font-tajawal text-[#77798C] max-w-md mx-auto mt-2 leading-relaxed">
                {selectedName.meaning}
              </p>

              {/* تصنيف الاسم */}
              <div className="mt-4 flex items-center justify-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold font-tajawal bg-white/80 border border-[#E6E6F0] text-[#25263A]">
                  {selectedName.category === 'jalal' && '👑 من أسماء الجلال والعظمة'}
                  {selectedName.category === 'jamal' && '🌸 من أسماء الجمال والرحمة'}
                  {selectedName.category === 'kamal' && '✨ من أسماء الكمال المطلق'}
                </span>
              </div>
            </div>

            {/* قسم "المعنى والشرح" */}
            <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs">
              <div className="flex items-center gap-2 mb-2.5">
                <span className="w-2 h-2 rounded-full bg-[#5B5FEF]" />
                <h3 className="text-base font-bold font-tajawal text-[#5B5FEF]">المعنى والشرح المفصل</h3>
              </div>
              <p className="text-sm font-tajawal text-[#25263A] leading-relaxed text-justify">
                {selectedName.meaning}
              </p>
              <div className="mt-3 pt-2.5 border-t border-[#F7F7FC] flex items-center gap-1.5 text-xs text-[#77798C] font-tajawal">
                <BookOpen className="w-3.5 h-3.5 text-[#5B5FEF]" />
                <span>المصدر المعتمد: {selectedName.source}</span>
              </div>
            </div>

            {/* قسم "الدليل من القرآن الكريم" */}
            <div className="bg-[#F7F7FC]/70 rounded-2xl p-5 border border-[#E6E6F0] shadow-xs">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-lg">📖</span>
                <h3 className="text-base font-bold font-tajawal text-[#4145C7]">الدليل من القرآن الكريم</h3>
              </div>
              <div className="p-4 rounded-xl bg-white/70 border border-[#E6E6F0] text-center my-2">
                <p className="text-lg md:text-xl font-bold font-serif text-[#25263A] leading-relaxed">
                  {selectedName.quranVerse}
                </p>
              </div>
              <p className="text-xs text-[#77798C] font-tajawal text-left">
                سورة {selectedName.quranSurah}
              </p>
            </div>

            {/* قسم "الدليل من السنة النبوية" */}
            <div className="bg-[#F7F7FC]/70 rounded-2xl p-5 border border-[#E6E6F0] shadow-xs">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-lg">📜</span>
                <h3 className="text-base font-bold font-tajawal text-[#4145C7]">الدليل من السنة النبوية المطهرة</h3>
              </div>
              <div className="p-4 rounded-xl bg-white/70 border border-[#E6E6F0] text-justify my-2">
                <p className="text-base md:text-lg font-serif text-[#25263A] leading-relaxed">
                  {selectedName.hadithText}
                </p>
              </div>
              <p className="text-xs text-[#77798C] font-tajawal text-left">
                تخريج الحديث: {selectedName.hadithSource}
              </p>
            </div>

            {/* قسم "فضل الاسم" */}
            <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
                <h3 className="text-base font-bold font-tajawal text-[#5B5FEF]">فضل وثمرة التعبد بهذا الاسم</h3>
              </div>
              <p className="text-sm font-tajawal text-[#25263A] leading-relaxed">
                {selectedName.virtue}
              </p>
            </div>

            {/* قسم "الفوائد الإيمانية والعملية" */}
            <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs">
              <div className="flex items-center gap-2 mb-3">
                <HeartHandshake className="w-4 h-4 text-[#5B5FEF]" />
                <h3 className="text-base font-bold font-tajawal text-[#5B5FEF]">الفوائد الإيمانية المستخلصة</h3>
              </div>
              <ul className="space-y-2">
                {selectedName.benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-sm font-tajawal text-[#25263A]">
                    <span className="w-5 h-5 rounded-full bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* شريط الإجراءات والتحكم بالخط أسفل الشاشة */}
            <div className="sticky bottom-4 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-3 border border-[#E6E6F0] shadow-lg flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  const shareText = `🌟 اسم الله: «${selectedName.name}»\n\n📖 المعنى: ${selectedName.meaning}\n\nالدليل: ${selectedName.quranVerse} (${selectedName.quranSurah})`;
                  copyToClipboard(shareText);
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-[#F7F7FC] border border-[#5B5FEF] text-[#25263A] text-xs font-bold font-tajawal flex items-center justify-center gap-1.5 hover:bg-[#F7F7FC] transition-colors cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5 text-[#5B5FEF]" />
                <span>نسخ الشرح</span>
              </button>

              <button
                onClick={() => shareName(selectedName)}
                className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white text-xs font-bold font-tajawal flex items-center justify-center gap-1.5 shadow-xs hover:brightness-105 transition-all cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>مشاركة</span>
              </button>

              {/* أزرار تكبير وتصغير الخط */}
              <div className="flex items-center gap-1 border-r border-[#E6E6F0] pr-2">
                <button
                  onClick={() => setFontScale((s) => Math.min(s + 0.1, 1.3))}
                  className="p-2 rounded-lg bg-[#F7F7FC] text-[#25263A] hover:bg-[#F7F7FC] cursor-pointer"
                  title="تكبير الخط"
                >
                  <ZoomIn className="w-4 h-4 text-[#5B5FEF]" />
                </button>
                <button
                  onClick={() => setFontScale((s) => Math.max(s - 0.1, 0.9))}
                  className="p-2 rounded-lg bg-[#F7F7FC] text-[#25263A] hover:bg-[#F7F7FC] cursor-pointer"
                  title="تصغير الخط"
                >
                  <ZoomOut className="w-4 h-4 text-[#5B5FEF]" />
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* ══════════════════════════════════════════
             الشاشة 1: الصفحة الرئيسية لأسماء الله الحسنى
             ══════════════════════════════════════════ */
          <div className="space-y-4">
            {/* ── 【2】Hero Section: الصورة المرفقة الرسمية ── */}
            <div className="relative rounded-3xl bg-gradient-to-b from-white via-[#F7F7FC]/40 to-[#F7F7FC] border border-[#E6E6F0] p-6 text-center shadow-[0_6px_20px_rgba(201,168,76,0.14)] overflow-hidden">
              <div className="flex flex-col items-center justify-center">
                {/* الصورة المرفقة الرسمية بحجم 250px × 250px في المنتصف مع Fade In + Scale Animation */}
                <div className="relative group animate-scale-in">
                  <div className="w-[250px] h-[250px] rounded-3xl overflow-hidden border-2 border-[#5B5FEF] shadow-[0_8px_25px_rgba(201,168,76,0.3)] bg-[#F7F7FC] flex items-center justify-center transition-transform duration-500 hover:scale-[1.02]">
                    <img
                      src="assets/icons/menu/ic_allah_names.png"
                      alt="أسماء الله الحسنى"
                      className="w-44 h-44 object-contain"
                    />
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#5B5FEF]" />
                  <h2 className="text-xl font-bold font-tajawal text-[#5B5FEF]">
                    الجامع لأسماء الله الحسنى
                  </h2>
                  <span className="w-1.5 h-1.5 rounded-full bg-[#5B5FEF]" />
                </div>
              </div>
            </div>

            {/* ── 【3】البطاقة الترحيبية بآية وحديث ── */}
            <div className="bg-white rounded-2xl p-5 border border-[#E6E6F0] shadow-xs space-y-3">
              <div className="p-3.5 rounded-xl bg-[#F7F7FC]/70 border border-[#E6E6F0] text-center">
                <p className="text-base font-serif font-bold text-[#25263A] leading-relaxed">
                  ﴿وَلِلَّهِ الْأَسْمَاءُ الْحُسْنَىٰ فَادْعُوهُ بِهَا﴾
                </p>
                <span className="text-[11px] text-[#77798C] font-tajawal mt-1 block">
                  سورة الأعراف: ١٨٠
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-[#F7F7FC]/70 border border-[#E6E6F0] text-center">
                <p className="text-xs md:text-sm font-serif text-[#25263A] leading-relaxed">
                  قال رسول الله ﷺ: «إِنَّ لِلَّهِ تِسْعَةً وَتِسْعِينَ اسْمًا، مِائَةً إِلَّا وَاحِدًا، مَنْ أَحْصَاهَا دَخَلَ الْجَنَّةَ»
                </p>
                <span className="text-[11px] text-[#77798C] font-tajawal mt-1 block">
                  صحيح البخاري (٢٧٣٦)، صحيح مسلم (٢٦٧٧)
                </span>
              </div>

              <button
                onClick={() => {
                  const firstElement = document.getElementById('asmaa-grid-section');
                  firstElement?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white font-bold font-tajawal text-sm shadow-md hover:brightness-105 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>ابدأ الرحلة المباركة ✨</span>
              </button>
            </div>

            {/* ── 【5】شريط البحث الفوري ── */}
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث بالاسم (مثال: الرحمن) أو بالمعنى (مثال: رحمة)..."
                className="w-full py-3 pr-10 pl-10 bg-white rounded-2xl border border-[#E6E6F0] text-sm font-tajawal text-[#25263A] placeholder-[#77798C] focus:outline-hidden focus:ring-2 focus:ring-[#5B5FEF] shadow-xs"
              />
              <Search className="w-4 h-4 text-[#5B5FEF] absolute top-1/2 -translate-y-1/2 right-3.5 pointer-events-none" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute top-1/2 -translate-y-1/2 left-3 text-[#77798C] hover:text-[#25263A] p-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* ── 【4】تبويبات التصنيفات ── */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
              {[
                { id: 'all', label: 'الكل (٩٩)' },
                { id: 'jalal', label: 'أسماء الجلال 👑' },
                { id: 'jamal', label: 'أسماء الجمال 🌸' },
                { id: 'kamal', label: 'أسماء الكمال ✨' },
                { id: 'favorites', label: `المفضلة (${favorites.length}) ⭐` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id as any)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold font-tajawal whitespace-nowrap transition-all cursor-pointer ${
                    selectedTab === tab.id
                      ? 'bg-[#5B5FEF] text-white shadow-xs'
                      : 'bg-white text-[#25263A] border border-[#E6E6F0] hover:bg-[#F7F7FC]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* ── العداد وزر الإفراغ في المفضلة ── */}
            <div id="asmaa-grid-section" className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <span className="w-1 h-4 bg-[#5B5FEF] rounded-full" />
                <span className="text-xs font-bold font-tajawal text-[#77798C]">
                  النتائج المعروضة: {filteredNames.length} اسماً مباركاً
                </span>
              </div>

              {selectedTab === 'favorites' && favorites.length > 0 && (
                <button
                  onClick={clearAllFavorites}
                  className="text-xs font-bold font-tajawal text-red-700 hover:underline cursor-pointer"
                >
                  إفراغ المفضلة
                </button>
              )}
            </div>

            {/* ── 【6】شبكة الأسماء (Grid 2×N) ── */}
            {filteredNames.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center border border-[#E6E6F0] shadow-xs">
                <p className="text-sm font-tajawal text-[#77798C]">
                  لا توجد نتائج مطابقة لبحثك في هذا القسم
                </p>
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="mt-3 px-4 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-bold font-tajawal"
                  >
                    مسح البحث
                  </button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {filteredNames.map((item, idx) => {
                  const isFav = favorites.includes(item.id);
                  return (
                    <div
                      key={item.id}
                      onClick={() => setSelectedName(item)}
                      style={{ animationDelay: `${(idx % 20) * 35}ms` }}
                      className="relative bg-white rounded-2xl p-3.5 border border-[#E6E6F0] hover:border-[#5B5FEF] shadow-[0_2px_8px_rgba(0,0,0,0.06)] hover:shadow-[0_4px_16px_rgba(201,168,76,0.2)] transition-all duration-200 cursor-pointer flex flex-col items-center justify-between text-center min-h-[148px] group hover:-translate-y-0.5 active:scale-[0.98]"
                    >
                      {/* زر المفضلة في أعلى اليمين */}
                      <button
                        onClick={(e) => toggleFavorite(item.id, e)}
                        className="absolute top-2.5 right-2.5 p-1 text-[#5B5FEF] hover:scale-110 transition-transform cursor-pointer z-10"
                        aria-label="إضافة للمفضلة"
                      >
                        <Star className={`w-4 h-4 ${isFav ? 'fill-[#E8B84A] text-[#5B5FEF]' : 'text-[#5B5FEF]/50'}`} />
                      </button>

                      {/* رقم الاسم داخل دائرة ذهبية 32px */}
                      <div className="w-8 h-8 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center text-[11px] font-bold font-tajawal text-[#4145C7] shadow-2xs mt-0.5">
                        {item.id}
                      </div>

                      {/* الاسم بالخط الأميري 24px ذهبي */}
                      <div className="my-1.5">
                        <span className="text-[24px] font-bold font-serif text-[#5B5FEF] group-hover:text-[#4145C7] transition-colors leading-tight drop-shadow-[0_1px_1px_rgba(201,168,76,0.15)]">
                          {item.name}
                        </span>
                      </div>

                      {/* المعنى الموجز: Cairo 12px رمادي (سطران) */}
                      <div className="w-full">
                        <p className="text-[12px] font-tajawal text-[#77798C] line-clamp-2 leading-relaxed">
                          {item.meaning}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
};
