import React, { useState } from 'react';
import { X, Package, Calendar, Clock, Bell, User, MapPin, FileText, Key, Laptop, DollarSign, Box, AlertCircle } from 'lucide-react';
import { TrustRecord, TrustItemType } from '../../utils/amanaStorage';

export interface AddEditTrustModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: TrustRecord) => void;
  initialTrust?: TrustRecord | null;
}

const TRUST_TYPE_OPTIONS: Array<{ type: TrustItemType; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { type: 'physical', label: 'شيء مادي', icon: Box },
  { type: 'document', label: 'مستند / وثيقة', icon: FileText },
  { type: 'key', label: 'مفتاح', icon: Key },
  { type: 'device', label: 'جهاز إلكتروني', icon: Laptop },
  { type: 'money', label: 'مبلغ مالي', icon: DollarSign },
  { type: 'other', label: 'أخرى', icon: Package },
];

export const AddEditTrustModal: React.FC<AddEditTrustModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialTrust,
}) => {
  const [ownerName, setOwnerName] = useState(initialTrust?.ownerName || '');
  const [title, setTitle] = useState(initialTrust?.title || '');
  const [itemType, setItemType] = useState<TrustItemType>(initialTrust?.itemType || 'physical');
  const [safeLocation, setSafeLocation] = useState(initialTrust?.safeLocation || '');
  const [receivedDate, setReceivedDate] = useState(
    initialTrust?.receivedDate || new Date().toISOString().split('T')[0]
  );
  const [returnDueDate, setReturnDueDate] = useState(initialTrust?.returnDueDate || '');
  const [notes, setNotes] = useState(initialTrust?.notes || '');

  // Reminder
  const [reminderEnabled, setReminderEnabled] = useState(initialTrust?.reminderEnabled || false);
  const [reminderTime, setReminderTime] = useState(initialTrust?.reminderTime || '10:00');

  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ownerName.trim()) {
      setErrorMsg('يرجى إدخال اسم صاحب الأمانة.');
      return;
    }
    if (!title.trim()) {
      setErrorMsg('يرجى إدخال وصف الأمانة أو اسمها.');
      return;
    }
    if (!safeLocation.trim()) {
      setErrorMsg('يرجى إدخال مكان حفظ الأمانة.');
      return;
    }

    const now = Date.now();
    const finalRecord: TrustRecord = {
      id: initialTrust?.id || `trust_${now}_${Math.random().toString(36).slice(2, 8)}`,
      ownerName: ownerName.trim(),
      title: title.trim(),
      itemType,
      safeLocation: safeLocation.trim(),
      receivedDate: receivedDate || new Date().toISOString().split('T')[0],
      returnDueDate: returnDueDate.trim() || undefined,
      status: initialTrust?.status || 'in_custody',
      returnedDate: initialTrust?.returnedDate,
      notes: notes.trim() || undefined,
      reminderEnabled: !!(reminderEnabled && returnDueDate),
      reminderTime: reminderTime || '10:00',
      createdAt: initialTrust?.createdAt || now,
      updatedAt: now,
    };

    onSave(finalRecord);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#25263A]/70 backdrop-blur-sm animate-fade-in overflow-y-auto"
      dir="rtl"
    >
      <div className="relative w-full max-w-lg bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl shadow-2xl border border-[#E6E6F0] dark:border-[#2D2E4A] max-h-[92vh] flex flex-col overflow-hidden my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-[#E6E6F0] dark:border-[#2D2E4A] bg-gradient-to-r from-[#FFFEFC] to-[#F7F7FC] dark:from-[#202138] dark:to-[#1A1B2E]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#FFF9E6] dark:bg-[#352D16] border border-[#E8B84A]/30 flex items-center justify-center text-[#E8B84A]">
              <Package className="w-5 h-5 text-[#D4A836]" />
            </div>
            <div>
              <h2 className="font-cairo font-black text-base sm:text-lg text-[#25263A] dark:text-[#F3F4F6]">
                {initialTrust ? 'تعديل بيانات الأمانة' : 'تسجيل أمانة جديدة 📦'}
              </h2>
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5]">
                حفظ الأمانات ومتابعة مواعيد استرجاعها
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-2xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] hover:text-[#25263A] dark:hover:text-[#F3F4F6] transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-2xl text-xs font-bold border border-red-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Owner Name */}
          <div>
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
              اسم صاحب الأمانة <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                placeholder="مثال: أحمد، محمد، جارنا أبو عبد الله..."
                required
                className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
              />
              <User className="w-4 h-4 text-[#77798C] absolute left-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Trust Title */}
          <div>
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
              وصف الأمانة <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: مفتاح المكتب، ظرف أوراق رسمية، ساعة يد..."
              required
              className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
            />
          </div>

          {/* Item Type Picker */}
          <div>
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1.5">
              نوع الأمانة
            </label>
            <div className="grid grid-cols-3 gap-2">
              {TRUST_TYPE_OPTIONS.map((opt) => {
                const Icon = opt.icon;
                const isSelected = itemType === opt.type;
                return (
                  <button
                    key={opt.type}
                    type="button"
                    onClick={() => setItemType(opt.type)}
                    className={`py-2 px-2 rounded-2xl text-[11px] font-bold border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      isSelected
                        ? 'bg-[#EEEEFF] dark:bg-[#282946] text-[#5B5FEF] dark:text-[#9FA4FF] border-[#5B5FEF] shadow-xs'
                        : 'bg-[#F7F7FC] dark:bg-[#202138] text-[#77798C] dark:text-[#9E9FB5] border-[#E6E6F0] dark:border-[#2D2E4A]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{opt.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Safe Location */}
          <div>
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
              مكان حفظها <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={safeLocation}
                onChange={(e) => setSafeLocation(e.target.value)}
                placeholder="مثال: درج المكتب العلوي، الخزنة الحديدية، الرف الثالث..."
                required
                className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
              />
              <MapPin className="w-4 h-4 text-[#77798C] absolute left-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Dates: Received & Return Due */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
                تاريخ الاستلام
              </label>
              <input
                type="date"
                value={receivedDate}
                onChange={(e) => setReceivedDate(e.target.value)}
                className="w-full px-3 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
                موعد الإعادة (إن وجد)
              </label>
              <input
                type="date"
                value={returnDueDate}
                onChange={(e) => setReturnDueDate(e.target.value)}
                className="w-full px-3 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none"
              />
            </div>
          </div>

          {/* Reminder Toggle if Return Due Date is set */}
          {returnDueDate && (
            <div className="p-3.5 rounded-2xl bg-[#FFFDF5] dark:bg-[#25263A]/40 border border-[#E8B84A]/30 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-[#E8B84A]" />
                  <span className="text-xs font-black text-[#25263A] dark:text-[#F3F4F6]">
                    تفعيل تذكير محلي عند موعد الإعادة
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={reminderEnabled}
                  onChange={(e) => setReminderEnabled(e.target.checked)}
                  className="w-4 h-4 rounded text-[#5B5FEF] cursor-pointer"
                />
              </div>

              {reminderEnabled && (
                <div className="pt-1 border-t border-[#E8B84A]/20">
                  <label className="block text-[11px] text-[#77798C] dark:text-[#9E9FB5] font-bold mb-1">
                    وقت التنبيه في يوم الموعد:
                  </label>
                  <input
                    type="time"
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-xl bg-white dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-bold"
                  />
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-[#77798C] dark:text-[#9E9FB5] mb-1">
              ملاحظات أو تفاصيل إضافية (اختيارية)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="شروط التسليم، رقم هاتف صاحب الأمانة..."
              className="w-full px-4 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] dark:text-[#9E9FB5] text-xs font-bold hover:bg-[#E6E6F0] transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer"
            >
              {initialTrust ? 'حفظ التعديلات' : 'حفظ الأمانة'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
