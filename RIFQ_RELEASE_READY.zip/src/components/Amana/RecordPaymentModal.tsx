import React, { useState } from 'react';
import { X, CheckCircle2, DollarSign, Calendar, FileText, AlertCircle, Sparkles } from 'lucide-react';
import { DebtRecord, calculateDebtBalance, recordDebtPayment } from '../../utils/amanaStorage';

export interface RecordPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  debt: DebtRecord;
  onPaymentSuccess: (updatedDebt: DebtRecord) => void;
}

export const RecordPaymentModal: React.FC<RecordPaymentModalProps> = ({
  isOpen,
  onClose,
  debt,
  onPaymentSuccess,
}) => {
  const { paidAmount, remainingAmount } = calculateDebtBalance(debt);

  const [amount, setAmount] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [note, setNote] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const numericEntered = parseFloat(amount) || 0;
  const newRemaining = Math.max(0, remainingAmount - numericEntered);
  const willCompleteSettlement = numericEntered >= remainingAmount && remainingAmount > 0;

  const handlePayFullRemaining = () => {
    setAmount(String(remainingAmount));
    setErrorMsg('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (numericEntered <= 0) {
      setErrorMsg('يرجى إدخال مبلغ صحيح للدفعة أكبر من الصفر.');
      return;
    }

    if (numericEntered > remainingAmount) {
      setErrorMsg(`مبلغ الدفعة (${numericEntered}) أكبر من المتبقي الفعلي (${remainingAmount} ${debt.currency}).`);
      return;
    }

    const updated = recordDebtPayment(debt.id, {
      amount: numericEntered,
      currency: debt.currency,
      paymentDate: paymentDate || new Date().toISOString().split('T')[0],
      note: note.trim() || undefined,
    });

    if (updated) {
      onPaymentSuccess(updated);
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#25263A]/70 backdrop-blur-sm animate-fade-in"
      dir="rtl"
    >
      <div className="relative w-full max-w-md bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl shadow-2xl border border-[#E6E6F0] dark:border-[#2D2E4A] p-5 sm:p-6 space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0] dark:border-[#2D2E4A]">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-[#EBF7EE] dark:bg-[#1E3825] border border-[#4CAF82]/30 flex items-center justify-center text-[#2E7D32] dark:text-[#81C784]">
              <DollarSign className="w-5 h-5 text-[#2E7D32]" />
            </div>
            <div>
              <h3 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6]">
                تسجيل دفعة سداد ➕
              </h3>
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5]">
                {debt.type === 'receivable' ? `استلام دفعة من ${debt.personName}` : `سداد دفعة لـ ${debt.personName}`}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Status Banner */}
        <div className="grid grid-cols-3 gap-2 p-3.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A]/50 border border-[#E6E6F0] dark:border-[#2D2E4A] text-center">
          <div>
            <span className="block text-[10px] text-[#77798C] dark:text-[#9E9FB5] font-bold">إجمالي الدين</span>
            <span className="text-xs sm:text-sm font-black text-[#25263A] dark:text-[#F3F4F6]">
              {debt.totalAmount.toLocaleString()} {debt.currency}
            </span>
          </div>

          <div>
            <span className="block text-[10px] text-[#4CAF82] font-bold">المدفوع سابقاً</span>
            <span className="text-xs sm:text-sm font-black text-[#2E7D32] dark:text-[#81C784]">
              {paidAmount.toLocaleString()} {debt.currency}
            </span>
          </div>

          <div>
            <span className="block text-[10px] text-[#E8B84A] font-bold">المتبقي حالياً</span>
            <span className="text-xs sm:text-sm font-black text-[#D97706] dark:text-[#FBBF24]">
              {remainingAmount.toLocaleString()} {debt.currency}
            </span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {errorMsg && (
            <div className="flex items-center gap-1.5 p-2.5 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-xl text-xs font-bold border border-red-200">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Amount Field + Quick Full Pay Button */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-[#25263A] dark:text-[#F3F4F6]">
                مبلغ الدفعة ({debt.currency}) <span className="text-red-500">*</span>
              </label>
              <button
                type="button"
                onClick={handlePayFullRemaining}
                className="text-[11px] font-bold text-[#5B5FEF] dark:text-[#9FA4FF] hover:underline cursor-pointer"
              >
                تسديد كامل المتبقي ({remainingAmount})
              </button>
            </div>
            <input
              type="number"
              step="any"
              min="0"
              max={remainingAmount}
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                setErrorMsg('');
              }}
              placeholder="0.00"
              required
              autoFocus
              className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-base font-black text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
            />
          </div>

          {/* Real-time Result Preview */}
          {numericEntered > 0 && (
            <div className={`p-3 rounded-2xl border text-xs font-bold flex items-center justify-between ${
              willCompleteSettlement
                ? 'bg-[#EBF7EE] dark:bg-[#1E3825] text-[#2E7D32] dark:text-[#81C784] border-[#A5D6A7]'
                : 'bg-[#FFFDF5] dark:bg-[#2A2718] text-[#8C6D1F] dark:text-[#FDD835] border-[#E8B84A]/30'
            }`}>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
                <span>
                  {willCompleteSettlement ? '✅ سيتم سداد الدين بالكامل بإذن الله' : `المتبقي بعد الدفعة: ${newRemaining.toLocaleString()} ${debt.currency}`}
                </span>
              </div>
            </div>
          )}

          {/* Date */}
          <div>
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
              تاريخ الدفعة
            </label>
            <input
              type="date"
              value={paymentDate}
              onChange={(e) => setPaymentDate(e.target.value)}
              className="w-full px-3 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none"
            />
          </div>

          {/* Note */}
          <div>
            <label className="block text-xs font-bold text-[#77798C] dark:text-[#9E9FB5] mb-1">
              ملاحظة على الدفعة (اختيارية)
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="مثال: نقداً باليد، تحويل عبر الحساب..."
              className="w-full px-3.5 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs text-[#25263A] dark:text-[#F3F4F6] focus:outline-none"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] text-xs font-bold cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-2xl bg-[#2E7D32] hover:bg-[#276A2B] text-white text-xs font-black transition-all active:scale-95 cursor-pointer shadow-md flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>تأكيد تسجيل الدفعة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
