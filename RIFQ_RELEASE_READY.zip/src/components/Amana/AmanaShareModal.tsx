import React, { useState } from 'react';
import { X, Share2, Copy, Check, ShieldCheck, AlertTriangle } from 'lucide-react';
import { DebtRecord, TrustRecord, calculateDebtBalance } from '../../utils/amanaStorage';

export interface AmanaShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  debt?: DebtRecord | null;
  trust?: TrustRecord | null;
}

export const AmanaShareModal: React.FC<AmanaShareModalProps> = ({
  isOpen,
  onClose,
  debt,
  trust,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || (!debt && !trust)) return null;

  let shareTitle = '';
  let shareText = '';

  if (debt) {
    const { paidAmount, remainingAmount, status } = calculateDebtBalance(debt);
    const typeLabel = debt.type === 'receivable' ? 'مستحق لي عند الطرف الآخر' : 'دين عليّ لصالح الطرف الآخر';
    const statusLabel = status === 'paid' ? 'مدفوع بالكامل ✅' : status === 'partially_paid' ? 'مدفوع جزئياً ⏳' : 'مستحق السداد ⚠️';

    shareTitle = `سند توثيق مالي • ${debt.personName}`;
    shareText = `📜 سند توثيق مالي — تطبيق رِفْق | أمانة
قال تعالى: ﴿وَلَا تَسْأَمُوا أَن تَكْتُبُوهُ صَغِيرًا أَوْ كَبِيرًا إِلَىٰ أَجَلِهِ﴾ [البقرة: 282]

الطرف المعني: ${debt.personName}
نوع العملية: ${typeLabel}
المبلغ الإجمالي: ${debt.totalAmount.toLocaleString()} ${debt.currency}
المسدد حتى الآن: ${paidAmount.toLocaleString()} ${debt.currency}
المتبقي: ${remainingAmount.toLocaleString()} ${debt.currency}
الحالة: ${statusLabel}
تاريخ التسجيل: ${debt.recordDate}
${debt.dueDate ? `تاريخ الاستحقاق: ${debt.dueDate}\n` : ''}${debt.description ? `البيان: ${debt.description}\n` : ''}
تم التوثيق عبر تطبيق «رِفْق | RIFQ» لحفظ الحقوق والأمانات.`;
  } else if (trust) {
    const statusLabel = trust.status === 'returned' ? 'تمت إعادتها بحمد الله ✅' : 'محفوظة في الحفظ والأمانة 📦';
    shareTitle = `إشعار حفظ أمانة • ${trust.ownerName}`;
    shareText = `📦 إشعار حفظ أمانة — تطبيق رِفْق | أمانة
قال رسول الله ﷺ: «أَدِّ الأَمَانَةَ إِلَى مَنِ ائْتَمَنَكَ» [سنن أبي داود]

صاحب الأمانة: ${trust.ownerName}
الأمانة المودعة: ${trust.title}
تاريخ الاستلام: ${trust.receivedDate}
${trust.returnDueDate ? `موعد الإعادة المحدد: ${trust.returnDueDate}\n` : ''}الحالة الحالية: ${statusLabel}

الأمانة مسجلة في دفتر الأمانات بتطبيق «رِفْق | RIFQ».`;
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
        });
      } catch {}
    } else {
      handleCopy();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#25263A]/70 backdrop-blur-sm animate-fade-in"
      dir="rtl"
    >
      <div className="relative w-full max-w-md bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl shadow-2xl border border-[#E6E6F0] dark:border-[#2D2E4A] p-5 sm:p-6 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0] dark:border-[#2D2E4A]">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-[#FFF9E6] dark:bg-[#352D16] border border-[#E8B84A]/30 flex items-center justify-center text-[#E8B84A]">
              <Share2 className="w-5 h-5 text-[#D4A836]" />
            </div>
            <div>
              <h3 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6]">
                مشاركة سند التوثيق 📤
              </h3>
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5]">
                تأكيد قبل مشاركة أي بيانات مالية
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Security Notice */}
        <div className="flex items-start gap-2 p-3 bg-[#EBF7EE] dark:bg-[#1E3825] rounded-2xl border border-[#A5D6A7]/40 text-xs text-[#2E7D32] dark:text-[#81C784]">
          <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
          <span>
            يتم مشاركة ملخص البيانات الموضحة أدناه فقط بموافقتك، ولا يتم أبداً كشف رمز الخزنة أو أي بيانات شخصية سرية أخرى.
          </span>
        </div>

        {/* Text Preview Box */}
        <div className="p-3.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A]/50 border border-[#E6E6F0] dark:border-[#2D2E4A] max-h-48 overflow-y-auto">
          <pre className="text-xs text-[#25263A] dark:text-[#F3F4F6] whitespace-pre-wrap font-sans leading-relaxed">
            {shareText}
          </pre>
        </div>

        {/* Actions */}
        <div className="pt-2 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] text-xs font-bold cursor-pointer"
          >
            إلغاء
          </button>

          <button
            type="button"
            onClick={handleCopy}
            className="px-4 py-2 rounded-2xl bg-[#EEEEFF] dark:bg-[#2B2D54] text-[#5B5FEF] dark:text-[#9FA4FF] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#4CAF82]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'تم النسخ' : 'نسخ النص'}</span>
          </button>

          <button
            type="button"
            onClick={handleNativeShare}
            className="px-5 py-2 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-black transition-all active:scale-95 cursor-pointer shadow-md flex items-center gap-1.5"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>مشاركة الآن</span>
          </button>
        </div>
      </div>
    </div>
  );
};
