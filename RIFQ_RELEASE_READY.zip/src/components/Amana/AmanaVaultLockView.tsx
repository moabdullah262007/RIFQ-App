import React, { useState, useEffect } from 'react';
import { Lock, ShieldCheck, Fingerprint, Delete, AlertCircle, Sparkles } from 'lucide-react';
import { verifyVaultPin, AmanaVaultSettings } from '../../utils/amanaStorage';
import { isBiometricAvailable, promptBiometricAuth } from '../../utils/appLock';

export interface AmanaVaultLockViewProps {
  vaultSettings: AmanaVaultSettings;
  onUnlockSuccess: () => void;
  onBack: () => void;
}

export const AmanaVaultLockView: React.FC<AmanaVaultLockViewProps> = ({
  vaultSettings,
  onUnlockSuccess,
  onBack,
}) => {
  const [pin, setPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [biometricSupported, setBiometricSupported] = useState(false);

  useEffect(() => {
    isBiometricAvailable().then((supported) => {
      setBiometricSupported(supported && vaultSettings.biometricEnabled);
      if (supported && vaultSettings.biometricEnabled) {
        handleBiometric();
      }
    });
  }, [vaultSettings.biometricEnabled]);

  const handleBiometric = async () => {
    try {
      const ok = await promptBiometricAuth();
      if (ok) {
        onUnlockSuccess();
      }
    } catch {
      // Biometric dismissed or failed
    }
  };

  const handleKeyPress = async (digit: string) => {
    if (isVerifying || pin.length >= 6) return;
    const nextPin = pin + digit;
    setPin(nextPin);
    setErrorMsg('');

    // If reached 4 digits or configured length, verify
    if (nextPin.length === 4 || nextPin.length === 6) {
      if (vaultSettings.pinHash && vaultSettings.pinSalt) {
        setIsVerifying(true);
        const isValid = await verifyVaultPin(nextPin, vaultSettings.pinHash, vaultSettings.pinSalt);
        setIsVerifying(false);
        if (isValid) {
          onUnlockSuccess();
        } else if (nextPin.length === 6 || !vaultSettings.pinHash) {
          setErrorMsg('رمز الدخول غير صحيح، يرجى المحاولة مرة أخرى.');
          setPin('');
        }
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    setPin('');
    setErrorMsg('');
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#FAF8FF] via-[#F7F7FC] to-[#EEEEFF] dark:from-[#171829] dark:via-[#1A1B2E] dark:to-[#121324] text-[#25263A] dark:text-[#F3F4F6] flex flex-col items-center justify-center p-4 transition-colors"
      dir="rtl"
    >
      <div className="w-full max-w-sm bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-6 sm:p-8 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-2xl text-center space-y-6 relative overflow-hidden">
        {/* Top Glow Accent */}
        <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-[#5B5FEF] via-[#E8B84A] to-[#4CAF82]" />

        {/* Lock Icon */}
        <div className="relative mx-auto w-20 h-20 rounded-3xl bg-gradient-to-br from-[#FFF9E6] to-[#FFEBB3] dark:from-[#352D16] dark:to-[#453616] border border-[#E8B84A]/40 flex items-center justify-center text-[#E8B84A] shadow-md">
          <Lock className="w-10 h-10 text-[#D4A836]" />
          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#4CAF82] border-2 border-white dark:border-[#1E1F35] flex items-center justify-center">
            <ShieldCheck className="w-2.5 h-2.5 text-white" />
          </span>
        </div>

        {/* Title & Prompt */}
        <div className="space-y-1">
          <h2 className="font-cairo font-black text-xl text-[#25263A] dark:text-[#F3F4F6]">
            خزنة أمانة 🔐
          </h2>
          <p className="text-xs text-[#77798C] dark:text-[#9E9FB5] leading-relaxed">
            القسم محمي برمز أمان خاص لحماية ديونك وأماناتك الحساسة
          </p>
        </div>

        {/* PIN Dots Display */}
        <div className="flex items-center justify-center gap-3 py-2">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = pin.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  isFilled
                    ? 'bg-[#5B5FEF] dark:bg-[#9FA4FF] scale-110 shadow-[0_0_8px_rgba(91,95,239,0.5)]'
                    : 'bg-[#E6E6F0] dark:bg-[#353655]'
                }`}
              />
            );
          })}
        </div>

        {errorMsg && (
          <div className="flex items-center justify-center gap-1.5 text-xs text-red-600 dark:text-red-400 font-bold animate-shake">
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-2.5 pt-2" dir="ltr">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleKeyPress(digit)}
              className="h-14 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] dark:bg-[#25263A] dark:hover:bg-[#2D2E4A] text-[#25263A] dark:text-[#F3F4F6] text-xl font-black transition-all active:scale-95 cursor-pointer shadow-xs border border-[#E6E6F0]/60 dark:border-[#2D2E4A]"
            >
              {digit}
            </button>
          ))}

          {/* Biometric or Clear */}
          {biometricSupported ? (
            <button
              type="button"
              onClick={handleBiometric}
              className="h-14 rounded-2xl bg-[#FFF9E6] hover:bg-[#FFEBB3] dark:bg-[#352D16] text-[#8C6D1F] dark:text-[#FDD835] text-xs font-bold transition-all active:scale-95 cursor-pointer flex flex-col items-center justify-center border border-[#E8B84A]/30"
              title="فتح بالبصمة"
            >
              <Fingerprint className="w-6 h-6 text-[#E8B84A]" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleClear}
              className="h-14 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] dark:bg-[#25263A] text-xs text-[#77798C] font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center border border-[#E6E6F0]/60 dark:border-[#2D2E4A]"
            >
              مسح
            </button>
          )}

          <button
            type="button"
            onClick={() => handleKeyPress('0')}
            className="h-14 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] dark:bg-[#25263A] dark:hover:bg-[#2D2E4A] text-[#25263A] dark:text-[#F3F4F6] text-xl font-black transition-all active:scale-95 cursor-pointer shadow-xs border border-[#E6E6F0]/60 dark:border-[#2D2E4A]"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleDelete}
            className="h-14 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] dark:bg-[#25263A] text-[#77798C] hover:text-red-500 transition-all active:scale-95 cursor-pointer flex items-center justify-center border border-[#E6E6F0]/60 dark:border-[#2D2E4A]"
            aria-label="حذف رقم"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Back Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={onBack}
            className="text-xs text-[#77798C] dark:text-[#9E9FB5] hover:text-[#5B5FEF] font-bold transition-colors cursor-pointer"
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    </div>
  );
};
