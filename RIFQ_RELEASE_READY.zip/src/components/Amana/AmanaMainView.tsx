import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowRight,
  Plus,
  Search,
  Filter,
  DollarSign,
  Package,
  Calendar as CalendarIcon,
  Lock,
  Unlock,
  ShieldCheck,
  Clock,
  CheckCircle2,
  AlertCircle,
  Share2,
  Trash2,
  Edit3,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ArrowDownLeft,
  ArrowUpRight,
  MapPin,
  Box,
  FileText,
  Key,
  Laptop,
  Fingerprint,
} from 'lucide-react';
import {
  DebtRecord,
  TrustRecord,
  AmanaVaultSettings,
  loadAmanaState,
  saveDebtRecord,
  deleteDebtRecord,
  saveTrustRecord,
  toggleTrustStatus,
  deleteTrustRecord,
  saveVaultSettings,
  calculateDebtBalance,
  groupDebtsByCurrency,
  hashVaultPin,
  verifyVaultPin,
} from '../../utils/amanaStorage';
import { isBiometricAvailable } from '../../utils/appLock';
import { AddEditDebtModal } from './AddEditDebtModal';
import { RecordPaymentModal } from './RecordPaymentModal';
import { AddEditTrustModal } from './AddEditTrustModal';
import { AmanaShareModal } from './AmanaShareModal';
import { AmanaVaultLockView } from './AmanaVaultLockView';

export interface AmanaMainViewProps {
  onBackToHome: () => void;
  initialTab?: 'dashboard' | 'debts' | 'trusts' | 'calendar' | 'vault';
}

export const AmanaMainView: React.FC<AmanaMainViewProps> = ({
  onBackToHome,
  initialTab = 'dashboard',
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'debts' | 'trusts' | 'calendar' | 'vault'>(initialTab);
  const [debts, setDebts] = useState<DebtRecord[]>([]);
  const [trusts, setTrusts] = useState<TrustRecord[]>([]);
  const [vaultSettings, setVaultSettings] = useState<AmanaVaultSettings>({
    isEnabled: false,
    biometricEnabled: false,
    autoLockMinutes: 5,
  });

  // Vault Unlock State
  const [isVaultUnlocked, setIsVaultUnlocked] = useState(false);
  const [isBiometricSupported, setIsBiometricSupported] = useState(false);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [debtFilter, setDebtFilter] = useState<'all' | 'receivable' | 'payable' | 'due' | 'partially_paid' | 'paid'>('all');
  const [trustFilter, setTrustFilter] = useState<'all' | 'in_custody' | 'returned'>('all');

  // Calendar selected date
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [calendarViewMonth, setCalendarViewMonth] = useState<Date>(new Date());

  // Modals
  const [isAddDebtOpen, setIsAddDebtOpen] = useState(false);
  const [editingDebt, setEditingDebt] = useState<DebtRecord | null>(null);

  const [paymentDebtTarget, setPaymentDebtTarget] = useState<DebtRecord | null>(null);

  const [isAddTrustOpen, setIsAddTrustOpen] = useState(false);
  const [editingTrust, setEditingTrust] = useState<TrustRecord | null>(null);

  const [shareDebtTarget, setShareDebtTarget] = useState<DebtRecord | null>(null);
  const [shareTrustTarget, setShareTrustTarget] = useState<TrustRecord | null>(null);

  const [deleteConfirmation, setDeleteConfirmation] = useState<{
    type: 'debt' | 'trust';
    id: string;
    name: string;
  } | null>(null);

  // Expanded debt & trust IDs for smooth motion expansion
  const [expandedDebtIds, setExpandedDebtIds] = useState<string[]>([]);
  const [expandedTrustIds, setExpandedTrustIds] = useState<string[]>([]);

  // Setup PIN state inside vault tab
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinFeedbackMsg, setPinFeedbackMsg] = useState('');

  // Load local data on mount
  useEffect(() => {
    const state = loadAmanaState();
    setDebts(state.debts);
    setTrusts(state.trusts);
    setVaultSettings(state.vaultSettings);

    // If vault is not enabled, mark unlocked by default
    if (!state.vaultSettings.isEnabled) {
      setIsVaultUnlocked(true);
    }

    isBiometricAvailable().then(setIsBiometricSupported);
  }, []);

  const refreshData = () => {
    const state = loadAmanaState();
    setDebts(state.debts);
    setTrusts(state.trusts);
    setVaultSettings(state.vaultSettings);
  };

  // If vault is enabled and currently locked, show lock screen
  if (vaultSettings.isEnabled && !isVaultUnlocked) {
    return (
      <AmanaVaultLockView
        vaultSettings={vaultSettings}
        onUnlockSuccess={() => setIsVaultUnlocked(true)}
        onBack={onBackToHome}
      />
    );
  }

  // Currency summary calculations
  const currencySummaries = useMemo(() => groupDebtsByCurrency(debts), [debts]);

  const activeTrustsCount = useMemo(
    () => trusts.filter((t) => t.status === 'in_custody').length,
    [trusts]
  );

  // Upcoming due dates (next 30 days)
  const upcomingDueItems = useMemo(() => {
    const today = new Date().toISOString().split('T')[0];
    const nextMonth = new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0];

    const upcomingDebts = debts
      .filter((d) => d.dueDate && d.dueDate >= today && d.dueDate <= nextMonth && d.status !== 'paid')
      .map((d) => ({
        type: 'debt' as const,
        id: d.id,
        title: d.personName,
        subtitle: `${d.type === 'receivable' ? 'لي عنده' : 'عليّ له'}: ${d.totalAmount} ${d.currency}`,
        dueDate: d.dueDate!,
      }));

    const upcomingTrusts = trusts
      .filter((t) => t.returnDueDate && t.returnDueDate >= today && t.returnDueDate <= nextMonth && t.status !== 'returned')
      .map((t) => ({
        type: 'trust' as const,
        id: t.id,
        title: t.title,
        subtitle: `لـ ${t.ownerName} (مكان الحفظ: ${t.safeLocation})`,
        dueDate: t.returnDueDate!,
      }));

    return [...upcomingDebts, ...upcomingTrusts].sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  }, [debts, trusts]);

  // Filtered Debts
  const filteredDebts = useMemo(() => {
    return debts.filter((d) => {
      // Type & Status Filter
      if (debtFilter === 'receivable' && d.type !== 'receivable') return false;
      if (debtFilter === 'payable' && d.type !== 'payable') return false;
      if (debtFilter === 'due' && d.status !== 'due') return false;
      if (debtFilter === 'partially_paid' && d.status !== 'partially_paid') return false;
      if (debtFilter === 'paid' && d.status !== 'paid') return false;

      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = d.personName.toLowerCase().includes(q);
        const matchesDesc = (d.description || '').toLowerCase().includes(q);
        const matchesNotes = (d.notes || '').toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesNotes) return false;
      }

      return true;
    });
  }, [debts, debtFilter, searchQuery]);

  // Filtered Trusts
  const filteredTrusts = useMemo(() => {
    return trusts.filter((t) => {
      if (trustFilter === 'in_custody' && t.status !== 'in_custody') return false;
      if (trustFilter === 'returned' && t.status !== 'returned') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesOwner = t.ownerName.toLowerCase().includes(q);
        const matchesTitle = t.title.toLowerCase().includes(q);
        const matchesLoc = t.safeLocation.toLowerCase().includes(q);
        if (!matchesOwner && !matchesTitle && !matchesLoc) return false;
      }

      return true;
    });
  }, [trusts, trustFilter, searchQuery]);

  // Calendar Highlighted Dates
  const calendarEventDates = useMemo(() => {
    const datesSet = new Set<string>();
    debts.forEach((d) => {
      if (d.dueDate && d.status !== 'paid') datesSet.add(d.dueDate);
    });
    trusts.forEach((t) => {
      if (t.returnDueDate && t.status !== 'returned') datesSet.add(t.returnDueDate);
    });
    return datesSet;
  }, [debts, trusts]);

  const itemsDueOnSelectedDate = useMemo(() => {
    const dList = debts.filter((d) => d.dueDate === selectedCalendarDate);
    const tList = trusts.filter((t) => t.returnDueDate === selectedCalendarDate);
    return { debts: dList, trusts: tList };
  }, [debts, trusts, selectedCalendarDate]);

  // Handlers
  const handleSaveDebt = (record: DebtRecord) => {
    saveDebtRecord(record);
    refreshData();
    setEditingDebt(null);
  };

  const handleSaveTrust = (record: TrustRecord) => {
    saveTrustRecord(record);
    refreshData();
    setEditingTrust(null);
  };

  const handleToggleTrust = (id: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'in_custody' ? 'returned' : 'in_custody';
    toggleTrustStatus(id, nextStatus);
    refreshData();
  };

  const confirmDelete = () => {
    if (!deleteConfirmation) return;
    if (deleteConfirmation.type === 'debt') {
      deleteDebtRecord(deleteConfirmation.id);
    } else {
      deleteTrustRecord(deleteConfirmation.id);
    }
    setDeleteConfirmation(null);
    refreshData();
  };

  const toggleExpandDebt = (id: string) => {
    setExpandedDebtIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleExpandTrust = (id: string) => {
    setExpandedTrustIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSetNewPin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length !== 4 && newPin.length !== 6) {
      setPinFeedbackMsg('يجب أن يتكون رمز PIN من 4 أو 6 أرقام.');
      return;
    }
    if (newPin !== confirmPin) {
      setPinFeedbackMsg('الرمزان غير متطابقين، يرجى إعادة الإدخال.');
      return;
    }

    const { hash, salt } = await hashVaultPin(newPin);
    const updated = {
      ...vaultSettings,
      isEnabled: true,
      pinHash: hash,
      pinSalt: salt,
    };
    saveVaultSettings(updated);
    setVaultSettings(updated);
    setNewPin('');
    setConfirmPin('');
    setPinFeedbackMsg('تم تفعيل وتعيين رمز الخزنة بنجاح 🔐');
  };

  const handleDisableVault = () => {
    const updated: AmanaVaultSettings = {
      ...vaultSettings,
      isEnabled: false,
      pinHash: undefined,
      pinSalt: undefined,
    };
    saveVaultSettings(updated);
    setVaultSettings(updated);
    setPinFeedbackMsg('تم إلغاء قفل الخزنة.');
  };

  return (
    <div className="min-h-screen bg-[#F7F7FC] dark:bg-[#121324] text-[#25263A] dark:text-[#F3F4F6] pb-24 transition-colors duration-250" dir="rtl">
      {/* Top Header Navigation */}
      <div className="w-full max-w-5xl mx-auto px-3 sm:px-4 py-4 sm:py-6 space-y-5">
        <div className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onBackToHome}
            className="flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] text-[#25263A] dark:text-[#F3F4F6] border border-[#E6E6F0] dark:border-[#2D2E4A] hover:bg-[#F7F7FC] transition-colors cursor-pointer text-xs font-bold shadow-xs"
          >
            <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
            <span>الرئيسية</span>
          </button>

          <div className="flex items-center gap-2">
            {/* Vault Status Indicator / Toggle */}
            <button
              type="button"
              onClick={() => setActiveTab('vault')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-bold border transition-all cursor-pointer ${
                vaultSettings.isEnabled
                  ? 'bg-[#EBF7EE] dark:bg-[#1E3825] text-[#2E7D32] dark:text-[#81C784] border-[#A5D6A7]'
                  : 'bg-[#FFF9E6] dark:bg-[#352D16] text-[#8C6D1F] dark:text-[#FDD835] border-[#E8B84A]/30'
              }`}
            >
              {vaultSettings.isEnabled ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
              <span>{vaultSettings.isEnabled ? 'الخزنة محمية 🔐' : 'حماية الخزنة'}</span>
            </button>
          </div>
        </div>

        {/* Section Banner with Quranic Verse & Slogan */}
        <div className="relative bg-gradient-to-b from-[#FFFEFC] via-[#FFFFFF] to-[#FAF8FF] dark:from-[#1E1F35] dark:via-[#202138] dark:to-[#171829] rounded-[32px] p-5 sm:p-7 border border-[#E8B84A]/30 dark:border-[#2D2E4A] shadow-[0_8px_30px_rgba(37,38,58,0.03)] overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-radial from-[#E8B84A]/12 via-[#4CAF82]/5 to-transparent pointer-events-none" />

          <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-5">
            <div className="space-y-2 text-center sm:text-right flex-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#EBF7EE] dark:bg-[#1E3825] text-[#2E7D32] dark:text-[#81C784] border border-[#A5D6A7]/40">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>أمانة • حقوقك وأماناتك في مكان واحد</span>
              </div>

              <h1 className="font-cairo font-black text-2xl sm:text-3xl text-[#25263A] dark:text-[#F3F4F6]">
                📜 أمانة
              </h1>

              {/* Quranic Verse */}
              <blockquote className="text-xs sm:text-sm text-[#4A4C62] dark:text-[#C5C6DC] font-medium leading-relaxed bg-[#F7F7FC]/80 dark:bg-[#25263A]/40 p-3 rounded-2xl border border-[#E6E6F0]/60 max-w-2xl">
                ﴿وَلَا تَسْأَمُوا أَن تَكْتُبُوهُ صَغِيرًا أَوْ كَبِيرًا إِلَىٰ أَجَلِهِ﴾
                <span className="block text-[11px] text-[#77798C] dark:text-[#9E9FB5] mt-1 font-bold">
                  سورة البقرة — الآية 282 • قال رسول الله ﷺ: «أَدِّ الأَمَانَةَ إِلَى مَنِ ائْتَمَنَكَ»
                </span>
              </blockquote>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setEditingDebt(null);
                  setIsAddDebtOpen(true);
                }}
                className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة دين جديد</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setEditingTrust(null);
                  setIsAddTrustOpen(true);
                }}
                className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-[#2E7D32] to-[#1E3825] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة أمانة جديدة</span>
              </button>
            </div>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex items-center gap-1.5 p-1.5 bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-2xl border border-[#E6E6F0] dark:border-[#2D2E4A] overflow-x-auto shadow-xs">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer text-center ${
              activeTab === 'dashboard'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] dark:text-[#9E9FB5] hover:bg-[#F7F7FC] dark:hover:bg-[#25263A]'
            }`}
          >
            📊 لوحة المتابعة
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('debts')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer text-center ${
              activeTab === 'debts'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] dark:text-[#9E9FB5] hover:bg-[#F7F7FC] dark:hover:bg-[#25263A]'
            }`}
          >
            💰 دفتر الديون ({debts.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('trusts')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer text-center ${
              activeTab === 'trusts'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] dark:text-[#9E9FB5] hover:bg-[#F7F7FC] dark:hover:bg-[#25263A]'
            }`}
          >
            📦 أماناتي ({trusts.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('calendar')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer text-center ${
              activeTab === 'calendar'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] dark:text-[#9E9FB5] hover:bg-[#F7F7FC] dark:hover:bg-[#25263A]'
            }`}
          >
            📅 التقويم
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('vault')}
            className={`flex-1 min-w-[90px] py-2 px-3 rounded-xl text-xs font-black transition-all cursor-pointer text-center ${
              activeTab === 'vault'
                ? 'bg-[#5B5FEF] text-white shadow-xs'
                : 'text-[#77798C] dark:text-[#9E9FB5] hover:bg-[#F7F7FC] dark:hover:bg-[#25263A]'
            }`}
          >
            🔐 الخزنة
          </button>
        </div>

        {/* ─────────────────────────────────────────────────────────────
            TAB 1: لوحة المتابعة (Dashboard)
            ───────────────────────────────────────────────────────────── */}
        {activeTab === 'dashboard' && (
          <div className="space-y-5 animate-fade-in">
            {/* Currencies Summary Cards (Strict separation by currency) */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-cairo font-black text-sm text-[#25263A] dark:text-[#F3F4F6]">
                  أرصدة الديون والحقوق المالية حسب العملة
                </h3>
              </div>

              {currencySummaries.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                  {currencySummaries.map((cur) => (
                    <div
                      key={cur.currency}
                      className="bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-5 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-xs space-y-4"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-[#E6E6F0] dark:border-[#2D2E4A]">
                        <span className="font-black text-base text-[#5B5FEF] dark:text-[#9FA4FF]">
                          عملة {cur.currency}
                        </span>
                        <span className="text-[11px] font-bold text-[#77798C] dark:text-[#9E9FB5]">
                          مستقلة وغير مدمجة
                        </span>
                      </div>

                      {/* Receivables (لي عندهم) */}
                      <div className="p-3 rounded-2xl bg-[#EBF7EE] dark:bg-[#1E3825]/60 border border-[#A5D6A7]/40 space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold text-[#2E7D32] dark:text-[#81C784]">
                          <span className="flex items-center gap-1">
                            <ArrowDownLeft className="w-3.5 h-3.5" />
                            <span>لي عند الآخرين (مستحق لي)</span>
                          </span>
                          <span className="font-black">{cur.receivableRemaining.toLocaleString()} {cur.currency}</span>
                        </div>
                        <div className="text-[11px] text-[#2E7D32]/80 flex justify-between">
                          <span>الإجمالي: {cur.receivableTotal.toLocaleString()}</span>
                          <span>المسدد: {cur.receivablePaid.toLocaleString()}</span>
                        </div>
                      </div>

                      {/* Payables (عليّ لهم) */}
                      <div className="p-3 rounded-2xl bg-[#FFF4E5] dark:bg-[#3D2915]/60 border border-[#F59E0B]/40 space-y-1">
                        <div className="flex items-center justify-between text-xs font-bold text-[#D97706] dark:text-[#FBBF24]">
                          <span className="flex items-center gap-1">
                            <ArrowUpRight className="w-3.5 h-3.5" />
                            <span>عليّ للآخرين (دين عليّ)</span>
                          </span>
                          <span className="font-black">{cur.payableRemaining.toLocaleString()} {cur.currency}</span>
                        </div>
                        <div className="text-[11px] text-[#D97706]/80 flex justify-between">
                          <span>الإجمالي: {cur.payableTotal.toLocaleString()}</span>
                          <span>المسدد: {cur.payablePaid.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 rounded-3xl bg-[#FFFFFF] dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] text-center space-y-2">
                  <DollarSign className="w-8 h-8 text-[#77798C] mx-auto opacity-50" />
                  <p className="text-xs font-bold text-[#77798C] dark:text-[#9E9FB5]">
                    لا توجد ديون مسجلة حتى الآن
                  </p>
                  <p className="text-[11px] text-[#77798C]">
                    يمكنك تسجيل الديون والحقوق المالية ليتم حسابها تلقائياً لكل عملة على حدة.
                  </p>
                </div>
              )}
            </div>

            {/* Trusts Overview & Upcoming Dues Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Trusts Quick Box */}
              <div className="bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-5 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-[#E8B84A]" />
                    <h4 className="font-cairo font-black text-sm text-[#25263A] dark:text-[#F3F4F6]">
                      أماناتي المودعة
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('trusts')}
                    className="text-xs font-bold text-[#5B5FEF] dark:text-[#9FA4FF] hover:underline cursor-pointer"
                  >
                    عرض الكل
                  </button>
                </div>

                {trusts.length > 0 ? (
                  <div className="grid grid-cols-2 gap-2 pt-1 text-center">
                    <div className="p-3 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#2D2E4A]">
                      <span className="block text-[11px] font-bold text-[#77798C]">بحوزتي حالياً</span>
                      <span className="text-lg font-black text-[#5B5FEF] dark:text-[#9FA4FF]">{activeTrustsCount}</span>
                    </div>
                    <div className="p-3 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#2D2E4A]">
                      <span className="block text-[11px] font-bold text-[#77798C]">تمت إعادتها</span>
                      <span className="text-lg font-black text-[#2E7D32] dark:text-[#81C784]">
                        {trusts.length - activeTrustsCount}
                      </span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-[#77798C] text-center py-4">
                    لا توجد أمانات مسجلة
                  </p>
                )}
              </div>

              {/* Upcoming Due Dates */}
              <div className="bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-5 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-[#5B5FEF]" />
                    <h4 className="font-cairo font-black text-sm text-[#25263A] dark:text-[#F3F4F6]">
                      استحقاقات قريبة (خلال 30 يوماً)
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('calendar')}
                    className="text-xs font-bold text-[#5B5FEF] dark:text-[#9FA4FF] hover:underline cursor-pointer"
                  >
                    التقويم
                  </button>
                </div>

                {upcomingDueItems.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {upcomingDueItems.slice(0, 4).map((item) => (
                      <div
                        key={item.id}
                        onClick={() => {
                          if (item.type === 'debt') {
                            setActiveTab('debts');
                            setExpandedDebtIds((prev) => (prev.includes(item.id) ? prev : [...prev, item.id]));
                          } else {
                            setActiveTab('trusts');
                            setExpandedTrustIds((prev) => (prev.includes(item.id) ? prev : [...prev, item.id]));
                          }
                        }}
                        className="flex items-center justify-between p-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] border border-[#E6E6F0]/60 hover:border-[#5B5FEF]/40 hover:bg-[#EEEEFF]/40 dark:hover:bg-[#2B2D54]/30 text-xs cursor-pointer transition-all active:scale-[0.99] group"
                        title="انقر للانتقال وعرض البطاقة وتفاصيلها الكاملة"
                      >
                        <div>
                          <span className="font-bold text-[#25263A] dark:text-[#F3F4F6] block group-hover:text-[#5B5FEF] transition-colors">
                            {item.title}
                          </span>
                          <span className="text-[11px] text-[#77798C]">{item.subtitle}</span>
                        </div>
                        <span className="px-2 py-1 rounded-xl text-[10px] font-bold bg-[#FFF9E6] dark:bg-[#352D16] text-[#8C6D1F] dark:text-[#FDD835]">
                          {item.dueDate}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-[#77798C] text-center py-4">
                    لا توجد مواعيد استحقاق قريبة في الأيام القادمة.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ─────────────────────────────────────────────────────────────
            TAB 2: دفتر الديون (Debts Ledger)
            ───────────────────────────────────────────────────────────── */}
        {activeTab === 'debts' && (
          <div className="space-y-4 animate-fade-in">
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row items-center gap-2.5">
              <div className="relative flex-1 w-full">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="البحث باسم الشخص أو وصف الدين..."
                  className="w-full px-4 py-2.5 pr-10 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none"
                />
                <Search className="w-4 h-4 text-[#77798C] absolute right-3.5 top-3 pointer-events-none" />
              </div>

              <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
                {(
                  [
                    { id: 'all', label: 'الكل' },
                    { id: 'receivable', label: 'لي عندهم' },
                    { id: 'payable', label: 'عليّ لهم' },
                    { id: 'due', label: 'مستحق' },
                    { id: 'partially_paid', label: 'مدفوع جزئياً' },
                    { id: 'paid', label: 'مدفوع بالكامل' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setDebtFilter(f.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                      debtFilter === f.id
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'bg-[#FFFFFF] dark:bg-[#1E1F35] text-[#77798C] border border-[#E6E6F0] dark:border-[#2D2E4A]'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Debts Header Bar: Count & Expand All / Collapse All Toggle */}
            {filteredDebts.length > 0 && (
              <div className="flex items-center justify-between text-xs px-1 text-[#77798C] dark:text-[#9E9FB5]">
                <span className="font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#5B5FEF]" />
                  <span>
                    {filteredDebts.length} {filteredDebts.length === 1 ? 'دين مسجل' : 'ديون مسجلة'} • اضغط على أي بطاقة لعرض كامل التفاصيل
                  </span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const allIds = filteredDebts.map((d) => d.id);
                    const allExpanded = allIds.every((id) => expandedDebtIds.includes(id));
                    if (allExpanded) {
                      setExpandedDebtIds((prev) => prev.filter((id) => !allIds.includes(id)));
                    } else {
                      setExpandedDebtIds((prev) => Array.from(new Set([...prev, ...allIds])));
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#F7F7FC] dark:bg-[#25263A] hover:bg-[#EEEEFF] dark:hover:bg-[#2D2E4A] text-[#5B5FEF] dark:text-[#9FA4FF] font-bold text-xs border border-[#E6E6F0] dark:border-[#2D2E4A] transition-all cursor-pointer shadow-2xs active:scale-95"
                >
                  {filteredDebts.every((d) => expandedDebtIds.includes(d.id)) ? (
                    <>
                      <ChevronUp className="w-3.5 h-3.5" />
                      <span>طي الكل</span>
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-3.5 h-3.5" />
                      <span>توسيع الكل</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Debts List */}
            {filteredDebts.length > 0 ? (
              <div className="grid grid-cols-1 gap-3.5">
                {filteredDebts.map((debt) => {
                  const { paidAmount, remainingAmount, status } = calculateDebtBalance(debt);
                  const isReceivable = debt.type === 'receivable';
                  const isExpanded = expandedDebtIds.includes(debt.id);
                  const percentPaid = debt.totalAmount > 0 ? Math.min(100, Math.round((paidAmount / debt.totalAmount) * 100)) : 100;

                  return (
                    <div
                      key={debt.id}
                      className={`bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-5 border transition-all duration-400 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                        isExpanded
                          ? 'border-[#5B5FEF] dark:border-[#5B5FEF] shadow-xl shadow-[#5B5FEF]/10 dark:shadow-[#5B5FEF]/20 ring-2 ring-[#5B5FEF]/20 scale-[1.008]'
                          : 'border-[#E6E6F0] dark:border-[#2D2E4A] hover:border-[#5B5FEF]/40 hover:shadow-md shadow-xs'
                      }`}
                    >
                      {/* Clickable Header for Smooth Motion Expansion */}
                      <div
                        onClick={() => toggleExpandDebt(debt.id)}
                        className="cursor-pointer select-none space-y-3 group"
                        title="انقر لتوسيع أو طي التفاصيل الكاملة وسجل السداد"
                      >
                        {/* Top Row: Type, Name, Status, and Animated Chevron Toggle */}
                        <div className="flex items-start justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span
                                className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-black ${
                                  isReceivable
                                    ? 'bg-[#EBF7EE] text-[#2E7D32] dark:bg-[#1E3825] dark:text-[#81C784] border border-[#A5D6A7]'
                                    : 'bg-[#FFF4E5] text-[#D97706] dark:bg-[#3D2915] dark:text-[#FBBF24] border border-[#F59E0B]'
                                }`}
                              >
                                {isReceivable ? (
                                  <>
                                    <ArrowDownLeft className="w-3.5 h-3.5" />
                                    <span>لي مال عنده</span>
                                  </>
                                ) : (
                                  <>
                                    <ArrowUpRight className="w-3.5 h-3.5" />
                                    <span>عليّ مال له</span>
                                  </>
                                )}
                              </span>

                              <h4 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6] group-hover:text-[#5B5FEF] dark:group-hover:text-[#9FA4FF] transition-colors">
                                {debt.personName}
                              </h4>
                            </div>

                            <p className="text-xs text-[#56586E] dark:text-[#C2C3D6] font-medium">
                              {debt.description}
                            </p>
                          </div>

                          {/* Status Badge + Motion Chevron Button */}
                          <div className="flex items-center gap-2 shrink-0">
                            {status === 'paid' ? (
                              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black bg-[#EBF7EE] text-[#2E7D32] dark:bg-[#1E3825] dark:text-[#81C784]">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>مدفوع بالكامل</span>
                              </span>
                            ) : status === 'partially_paid' ? (
                              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black bg-[#FFF9E6] text-[#D97706] dark:bg-[#352D16] dark:text-[#FDD835]">
                                <Clock className="w-3.5 h-3.5" />
                                <span>مدفوع جزئياً</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black bg-[#EEEEFF] text-[#5B5FEF] dark:bg-[#2B2D54] dark:text-[#9FA4FF]">
                                <span>مستحق السداد</span>
                              </span>
                            )}

                            {/* Motion Expand Button with Chevron */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleExpandDebt(debt.id);
                              }}
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shadow-2xs active:scale-95 ${
                                isExpanded
                                  ? 'bg-[#5B5FEF] text-white shadow-xs'
                                  : 'bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] group-hover:bg-[#EEEEFF] group-hover:text-[#5B5FEF] border border-[#E6E6F0] dark:border-[#2D2E4A]'
                              }`}
                              title={isExpanded ? 'طي التفاصيل' : 'توسيع لعرض التفاصيل وسجل السداد'}
                            >
                              <span className="text-[11px] font-bold">
                                {isExpanded ? 'طي' : 'تفاصيل'}
                              </span>
                              <ChevronDown
                                className={`w-3.5 h-3.5 transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                                  isExpanded ? 'rotate-180' : 'rotate-0'
                                }`}
                              />
                            </button>
                          </div>
                        </div>

                        {/* Amounts & Progress Bar */}
                        <div className="space-y-1.5 pt-1">
                          <div className="flex items-center justify-between text-xs font-bold">
                            <div>
                              <span className="text-[#77798C]">الإجمالي: </span>
                              <span className="font-black text-[#25263A] dark:text-[#F3F4F6]">
                                {debt.totalAmount.toLocaleString()} {debt.currency}
                              </span>
                            </div>
                            <div>
                              <span className="text-[#2E7D32] dark:text-[#81C784]">المدفوع: {paidAmount.toLocaleString()}</span>
                              <span className="mx-1.5 text-[#77798C]">|</span>
                              <span className="text-[#D97706] dark:text-[#FBBF24]">المتبقي: {remainingAmount.toLocaleString()}</span>
                            </div>
                          </div>

                          <div className="w-full h-2.5 bg-[#F7F7FC] dark:bg-[#25263A] rounded-full overflow-hidden border border-[#E6E6F0] dark:border-[#2D2E4A]">
                            <div
                              className={`h-full transition-all duration-500 ${
                                status === 'paid' ? 'bg-[#2E7D32]' : 'bg-[#5B5FEF]'
                              }`}
                              style={{ width: `${percentPaid}%` }}
                            />
                          </div>
                        </div>

                        {/* Compact Metadata Row */}
                        <div className="flex items-center justify-between text-[11px] text-[#77798C] dark:text-[#9E9FB5] pt-0.5">
                          <span>تاريخ التسجيل: {debt.recordDate}</span>
                          {debt.dueDate ? (
                            <span className="font-bold text-[#E8B84A]">
                              الاستحقاق: {debt.dueDate}
                            </span>
                          ) : (
                            <span className="text-[10px] text-[#5B5FEF] dark:text-[#9FA4FF] group-hover:underline">
                              {isExpanded ? 'اضغط لطي التفاصيل ▲' : 'اضغط لعرض السجل والتفاصيل ▼'}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Smooth Motion Accordion Details Container with Staggered Slide */}
                      <div
                        className="grid transition-[grid-template-rows,opacity] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
                        style={{
                          gridTemplateRows: isExpanded ? '1fr' : '0fr',
                          opacity: isExpanded ? 1 : 0,
                        }}
                      >
                        <div className="overflow-hidden">
                          <div
                            className={`pt-4 border-t border-[#E6E6F0] dark:border-[#2D2E4A] space-y-3.5 transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                              isExpanded ? 'translate-y-0 opacity-100' : '-translate-y-3 opacity-0 pointer-events-none'
                            }`}
                          >
                            {/* Notes (if any) */}
                            {debt.notes && (
                              <div className="p-3 rounded-2xl bg-[#FFFDF5] dark:bg-[#25263A]/40 border border-[#E8B84A]/25 text-xs text-[#25263A] dark:text-[#E2E3F0]">
                                <span className="font-bold text-[#8C6D1F] dark:text-[#FDD835] block mb-1">
                                  ملاحظات مسجلة:
                                </span>
                                <p className="leading-relaxed whitespace-pre-wrap">{debt.notes}</p>
                              </div>
                            )}

                            {/* Payment History */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <h5 className="font-black text-xs text-[#25263A] dark:text-[#F3F4F6] flex items-center gap-1.5">
                                  <Sparkles className="w-3.5 h-3.5 text-[#E8B84A]" />
                                  <span>سجل دفعات السداد ({debt.payments?.length || 0})</span>
                                </h5>
                                {status !== 'paid' && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setPaymentDebtTarget(debt);
                                    }}
                                    className="px-2.5 py-1 rounded-xl bg-[#EBF7EE] text-[#2E7D32] hover:bg-[#D4EDDA] text-[11px] font-black transition-colors cursor-pointer flex items-center gap-1"
                                  >
                                    <Plus className="w-3 h-3" />
                                    <span>تسجيل دفعة الآن</span>
                                  </button>
                                )}
                              </div>

                              {debt.payments && debt.payments.length > 0 ? (
                                <div className="space-y-1.5 max-h-44 overflow-y-auto pr-0.5">
                                  {debt.payments.map((p) => (
                                    <div
                                      key={p.id}
                                      className="flex items-center justify-between p-2.5 rounded-xl bg-[#F7F7FC] dark:bg-[#25263A] text-xs border border-[#E6E6F0]/60 dark:border-[#2D2E4A]/60"
                                    >
                                      <div>
                                        <span className="font-black text-[#2E7D32] dark:text-[#81C784]">
                                          + {p.amount.toLocaleString()} {p.currency}
                                        </span>
                                        {p.note && (
                                          <span className="text-[#77798C] mr-2">({p.note})</span>
                                        )}
                                      </div>
                                      <span className="text-[11px] text-[#77798C] font-medium">{p.paymentDate}</span>
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <p className="text-xs text-[#77798C] p-2 bg-[#F7F7FC] dark:bg-[#25263A] rounded-xl text-center">
                                  لم يتم تسجيل أي دفعات سداد بعد.
                                </p>
                              )}
                            </div>

                            {/* Expanded Actions Footer */}
                            <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-[#E6E6F0]/70 dark:border-[#2D2E4A]/70">
                              <div className="flex items-center gap-2">
                                {status !== 'paid' && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setPaymentDebtTarget(debt);
                                    }}
                                    className="px-3.5 py-2 rounded-xl bg-[#2E7D32] hover:bg-[#276A2B] text-white text-xs font-black transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 shadow-xs"
                                  >
                                    <Plus className="w-3.5 h-3.5" />
                                    <span>تسجيل دفعة</span>
                                  </button>
                                )}

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setShareDebtTarget(debt);
                                  }}
                                  className="px-3 py-2 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] dark:bg-[#25263A] text-[#5B5FEF] dark:text-[#9FA4FF] text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 border border-[#E6E6F0] dark:border-[#2D2E4A]"
                                >
                                  <Share2 className="w-3.5 h-3.5" />
                                  <span>مشاركة السند</span>
                                </button>
                              </div>

                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setEditingDebt(debt);
                                    setIsAddDebtOpen(true);
                                  }}
                                  className="p-2 rounded-xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] hover:text-[#5B5FEF] transition-colors cursor-pointer border border-[#E6E6F0] dark:border-[#2D2E4A]"
                                  title="تعديل بيانات الدين"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDeleteConfirmation({
                                      type: 'debt',
                                      id: debt.id,
                                      name: debt.personName,
                                    });
                                  }}
                                  className="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/40 text-[#77798C] hover:text-red-500 transition-colors cursor-pointer border border-[#E6E6F0] dark:border-[#2D2E4A]"
                                  title="حذف الدين"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-10 rounded-3xl bg-[#FFFFFF] dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] text-center space-y-3">
                <DollarSign className="w-10 h-10 text-[#77798C] mx-auto opacity-40" />
                <p className="text-xs font-bold text-[#77798C] dark:text-[#9E9FB5]">
                  {searchQuery ? 'لا توجد نتائج مطابقة لبحثك' : 'لا توجد ديون مسجلة في هذا القسم'}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setEditingDebt(null);
                    setIsAddDebtOpen(true);
                  }}
                  className="px-5 py-2 rounded-2xl bg-[#5B5FEF] text-white text-xs font-black hover:brightness-105 cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة دين جديد</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* ─────────────────────────────────────────────────────────────
            TAB 3: أماناتي (Trusts)
            ───────────────────────────────────────────────────────────── */}
        {activeTab === 'trusts' && (
          <div className="space-y-4 animate-fade-in">
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row items-center gap-2.5">
              <div className="relative flex-1 w-full">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="البحث باسم صاحب الأمانة أو الوصف أو مكان الحفظ..."
                  className="w-full px-4 py-2.5 pr-10 rounded-2xl bg-[#FFFFFF] dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none"
                />
                <Search className="w-4 h-4 text-[#77798C] absolute right-3.5 top-3 pointer-events-none" />
              </div>

              <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
                {(
                  [
                    { id: 'all', label: 'الكل' },
                    { id: 'in_custody', label: 'بحوزتي حالياً' },
                    { id: 'returned', label: 'تمت إعادتها' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setTrustFilter(f.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                      trustFilter === f.id
                        ? 'bg-[#5B5FEF] text-white shadow-xs'
                        : 'bg-[#FFFFFF] dark:bg-[#1E1F35] text-[#77798C] border border-[#E6E6F0] dark:border-[#2D2E4A]'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Trusts Header Bar: Count & Expand All / Collapse All Toggle */}
            {filteredTrusts.length > 0 && (
              <div className="flex items-center justify-between text-xs px-1 text-[#77798C] dark:text-[#9E9FB5]">
                <span className="font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#E8B84A]" />
                  <span>
                    {filteredTrusts.length} {filteredTrusts.length === 1 ? 'أمانة مسجلة' : 'أمانات مسجلة'} • اضغط على أي بطاقة لعرض كامل التفاصيل
                  </span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const allIds = filteredTrusts.map((t) => t.id);
                    const allExpanded = allIds.every((id) => expandedTrustIds.includes(id));
                    if (allExpanded) {
                      setExpandedTrustIds((prev) => prev.filter((id) => !allIds.includes(id)));
                    } else {
                      setExpandedTrustIds((prev) => Array.from(new Set([...prev, ...allIds])));
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#F7F7FC] dark:bg-[#25263A] hover:bg-[#FFF9E6] dark:hover:bg-[#352D16] text-[#D4A836] font-bold text-xs border border-[#E6E6F0] dark:border-[#2D2E4A] transition-all cursor-pointer shadow-2xs active:scale-95"
                >
                  {filteredTrusts.every((t) => expandedTrustIds.includes(t.id)) ? (
                    <>
                      <ChevronUp className="w-3.5 h-3.5" />
                      <span>طي الكل</span>
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-3.5 h-3.5" />
                      <span>توسيع الكل</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Trusts List */}
            {filteredTrusts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {filteredTrusts.map((trust) => {
                  const isInCustody = trust.status === 'in_custody';
                  const isExpanded = expandedTrustIds.includes(trust.id);

                  return (
                    <div
                      key={trust.id}
                      className={`bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-5 border transition-all duration-400 ease-[cubic-bezier(0.16,1,0.3,1)] flex flex-col justify-between ${
                        isExpanded
                          ? 'border-[#E8B84A] dark:border-[#E8B84A] shadow-xl shadow-[#E8B84A]/10 dark:shadow-[#E8B84A]/20 ring-2 ring-[#E8B84A]/20 scale-[1.008]'
                          : 'border-[#E6E6F0] dark:border-[#2D2E4A] hover:border-[#E8B84A]/40 hover:shadow-md shadow-xs'
                      }`}
                    >
                      {/* Clickable Header for Smooth Motion Expansion */}
                      <div
                        onClick={() => toggleExpandTrust(trust.id)}
                        className="cursor-pointer select-none space-y-3 group"
                        title="انقر لتوسيع أو طي التفاصيل والملاحظات ومكان الحفظ"
                      >
                        {/* Header: Title & Owner & Status & Motion Chevron */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5">
                            <div className="w-10 h-10 rounded-2xl bg-[#FFF9E6] dark:bg-[#352D16] border border-[#E8B84A]/30 flex items-center justify-center text-[#E8B84A] shrink-0">
                              {trust.itemType === 'key' ? (
                                <Key className="w-5 h-5 text-[#D4A836]" />
                              ) : trust.itemType === 'document' ? (
                                <FileText className="w-5 h-5 text-[#D4A836]" />
                              ) : trust.itemType === 'device' ? (
                                <Laptop className="w-5 h-5 text-[#D4A836]" />
                              ) : trust.itemType === 'money' ? (
                                <DollarSign className="w-5 h-5 text-[#D4A836]" />
                              ) : (
                                <Box className="w-5 h-5 text-[#D4A836]" />
                              )}
                            </div>

                            <div>
                              <h4 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6] leading-tight group-hover:text-[#E8B84A] transition-colors">
                                {trust.title}
                              </h4>
                              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5] mt-0.5 font-bold">
                                صاحب الأمانة: {trust.ownerName}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[11px] font-black ${
                                isInCustody
                                  ? 'bg-[#EEEEFF] text-[#5B5FEF] dark:bg-[#2B2D54] dark:text-[#9FA4FF]'
                                  : 'bg-[#EBF7EE] text-[#2E7D32] dark:bg-[#1E3825] dark:text-[#81C784]'
                              }`}
                            >
                              {isInCustody ? 'بحوزتي' : 'تمت إعادتها'}
                            </span>

                            {/* Motion Expand Button with Chevron */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleExpandTrust(trust.id);
                              }}
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer shadow-2xs active:scale-95 ${
                                isExpanded
                                  ? 'bg-[#E8B84A] text-white shadow-xs'
                                  : 'bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] group-hover:bg-[#FFF9E6] group-hover:text-[#D4A836] border border-[#E6E6F0] dark:border-[#2D2E4A]'
                              }`}
                              title={isExpanded ? 'طي التفاصيل' : 'توسيع لعرض تفاصيل الأمانة والمكان'}
                            >
                              <span className="text-[11px] font-bold">
                                {isExpanded ? 'طي' : 'تفاصيل'}
                              </span>
                              <ChevronDown
                                className={`w-3.5 h-3.5 transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                                  isExpanded ? 'rotate-180' : 'rotate-0'
                                }`}
                              />
                            </button>
                          </div>
                        </div>

                        {/* Location Badge */}
                        <div className="flex items-center gap-1.5 p-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] border border-[#E6E6F0]/60 text-xs">
                          <MapPin className="w-3.5 h-3.5 text-[#E8B84A] shrink-0" />
                          <span className="text-[#77798C] font-bold">مكان الحفظ:</span>
                          <span className="font-black text-[#25263A] dark:text-[#F3F4F6]">{trust.safeLocation}</span>
                        </div>

                        {/* Dates & Click Hint */}
                        <div className="flex items-center justify-between text-[11px] text-[#77798C] pt-0.5">
                          <span>تاريخ الاستلام: {trust.receivedDate}</span>
                          {trust.returnDueDate ? (
                            <span className="font-bold text-[#E8B84A]">
                              موعد الإعادة: {trust.returnDueDate}
                            </span>
                          ) : (
                            <span className="text-[10px] text-[#D4A836] group-hover:underline">
                              {isExpanded ? 'اضغط للطي ▲' : 'اضغط للتفاصيل والمكان ▼'}
                            </span>
                          )}
                          {trust.returnedDate && (
                            <span className="text-[#2E7D32] font-bold">تاريخ الإعادة: {trust.returnedDate}</span>
                          )}
                        </div>
                      </div>

                      {/* Smooth Motion Accordion Details Container with Staggered Slide */}
                      <div
                        className="grid transition-[grid-template-rows,opacity] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]"
                        style={{
                          gridTemplateRows: isExpanded ? '1fr' : '0fr',
                          opacity: isExpanded ? 1 : 0,
                        }}
                      >
                        <div className="overflow-hidden">
                          <div
                            className={`pt-3 border-t border-[#E6E6F0] dark:border-[#2D2E4A] space-y-3 transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                              isExpanded ? 'translate-y-0 opacity-100' : '-translate-y-3 opacity-0 pointer-events-none'
                            }`}
                          >
                            {/* Full Details Box */}
                            <div className="p-3 rounded-2xl bg-[#FFFDF5] dark:bg-[#25263A]/40 border border-[#E8B84A]/25 space-y-2 text-xs">
                              <div className="flex items-center justify-between">
                                <span className="text-[#77798C] font-bold">نوع الأمانة:</span>
                                <span className="font-black text-[#25263A] dark:text-[#F3F4F6]">
                                  {trust.itemType === 'key'
                                    ? 'مفتاح'
                                    : trust.itemType === 'document'
                                    ? 'مستند / وثيقة'
                                    : trust.itemType === 'device'
                                    ? 'جهاز إلكتروني'
                                    : trust.itemType === 'money'
                                    ? 'مبلغ مالي'
                                    : 'شيء مادي'}
                                </span>
                              </div>

                              <div className="flex items-center justify-between">
                                <span className="text-[#77798C] font-bold">مكان الحفظ المحدد:</span>
                                <span className="font-black text-[#25263A] dark:text-[#F3F4F6]">{trust.safeLocation}</span>
                              </div>

                              {trust.notes && (
                                <div className="pt-2 border-t border-[#E8B84A]/20">
                                  <span className="text-[#8C6D1F] dark:text-[#FDD835] font-bold block mb-1">
                                    ملاحظات وتفاصيل إضافية:
                                  </span>
                                  <p className="leading-relaxed whitespace-pre-wrap text-[#25263A] dark:text-[#E2E3F0]">
                                    {trust.notes}
                                  </p>
                                </div>
                              )}
                            </div>

                            {/* Card Actions Footer */}
                            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#E6E6F0]/70 dark:border-[#2D2E4A]/70">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleTrust(trust.id, trust.status);
                                }}
                                className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                                  isInCustody
                                    ? 'bg-[#EBF7EE] hover:bg-[#D4EDDA] text-[#2E7D32] dark:bg-[#1E3825] dark:text-[#81C784]'
                                    : 'bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#77798C] dark:bg-[#25263A]'
                                }`}
                              >
                                {isInCustody ? 'تحديد كـ "تمت الإعادة" ✅' : 'إعادة تعيين كـ "بحوزتي"'}
                              </button>

                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setShareTrustTarget(trust);
                                  }}
                                  className="p-1.5 rounded-xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] hover:text-[#5B5FEF] transition-colors cursor-pointer border border-[#E6E6F0] dark:border-[#2D2E4A]"
                                  title="مشاركة إشعار الأمانة"
                                >
                                  <Share2 className="w-4 h-4" />
                                </button>

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setEditingTrust(trust);
                                    setIsAddTrustOpen(true);
                                  }}
                                  className="p-1.5 rounded-xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] hover:text-[#5B5FEF] transition-colors cursor-pointer border border-[#E6E6F0] dark:border-[#2D2E4A]"
                                  title="تعديل الأمانة"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>

                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setDeleteConfirmation({
                                      type: 'trust',
                                      id: trust.id,
                                      name: trust.title,
                                    });
                                  }}
                                  className="p-1.5 rounded-xl hover:bg-red-50 dark:hover:bg-red-950/40 text-[#77798C] hover:text-red-500 transition-colors cursor-pointer border border-[#E6E6F0] dark:border-[#2D2E4A]"
                                  title="حذف الأمانة"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-10 rounded-3xl bg-[#FFFFFF] dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] text-center space-y-3">
                <Package className="w-10 h-10 text-[#77798C] mx-auto opacity-40" />
                <p className="text-xs font-bold text-[#77798C] dark:text-[#9E9FB5]">
                  {searchQuery ? 'لا توجد نتائج مطابقة لبحثك' : 'لا توجد أمانات مسجلة في هذا القسم'}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setEditingTrust(null);
                    setIsAddTrustOpen(true);
                  }}
                  className="px-5 py-2 rounded-2xl bg-[#2E7D32] text-white text-xs font-black hover:brightness-105 cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>إضافة أمانة جديدة</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* ─────────────────────────────────────────────────────────────
            TAB 4: التقويم (Calendar View)
            ───────────────────────────────────────────────────────────── */}
        {activeTab === 'calendar' && (
          <div className="bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-5 sm:p-7 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-xs space-y-6 animate-fade-in">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6]">
                  تقويم مواعيد الاستحقاق والإعادة 📅
                </h3>
                <p className="text-xs text-[#77798C] dark:text-[#9E9FB5]">
                  اضغط على أي تاريخ لعرض الديون والأمانات المستحقة في ذلك اليوم
                </p>
              </div>

              <input
                type="date"
                value={selectedCalendarDate}
                onChange={(e) => setSelectedCalendarDate(e.target.value)}
                className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-bold"
              />
            </div>

            {/* Selected Date Details */}
            <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A]/40 border border-[#E6E6F0] dark:border-[#2D2E4A] space-y-3">
              <h4 className="font-bold text-xs text-[#5B5FEF] dark:text-[#9FA4FF] flex items-center gap-1.5">
                <CalendarIcon className="w-4 h-4" />
                <span>المستحقات بتاريخ: {selectedCalendarDate}</span>
              </h4>

              {itemsDueOnSelectedDate.debts.length > 0 || itemsDueOnSelectedDate.trusts.length > 0 ? (
                <div className="space-y-2">
                  {itemsDueOnSelectedDate.debts.map((d) => (
                    <div
                      key={d.id}
                      onClick={() => {
                        setActiveTab('debts');
                        setExpandedDebtIds((prev) => (prev.includes(d.id) ? prev : [...prev, d.id]));
                      }}
                      className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] hover:border-[#5B5FEF]/40 hover:bg-[#EEEEFF]/30 dark:hover:bg-[#2B2D54]/20 text-xs cursor-pointer transition-all active:scale-[0.99] group shadow-2xs"
                      title="انقر للانتقال وعرض تفاصيل الدين وسجل السداد"
                    >
                      <div>
                        <span className="font-black text-[#25263A] dark:text-[#F3F4F6] block group-hover:text-[#5B5FEF] transition-colors">
                          دين: {d.personName} ({d.type === 'receivable' ? 'لي عنده' : 'عليّ له'})
                        </span>
                        <span className="text-[11px] text-[#77798C]">{d.description}</span>
                      </div>
                      <span className="font-black text-[#E8B84A]">
                        {d.totalAmount.toLocaleString()} {d.currency}
                      </span>
                    </div>
                  ))}

                  {itemsDueOnSelectedDate.trusts.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => {
                        setActiveTab('trusts');
                        setExpandedTrustIds((prev) => (prev.includes(t.id) ? prev : [...prev, t.id]));
                      }}
                      className="flex items-center justify-between p-3 rounded-xl bg-white dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] hover:border-[#E8B84A]/40 hover:bg-[#FFF9E6]/30 dark:hover:bg-[#352D16]/20 text-xs cursor-pointer transition-all active:scale-[0.99] group shadow-2xs"
                      title="انقر للانتقال وعرض تفاصيل الأمانة ومكان حفظها"
                    >
                      <div>
                        <span className="font-black text-[#25263A] dark:text-[#F3F4F6] block group-hover:text-[#D4A836] transition-colors">
                          أمانة: {t.title} (لـ {t.ownerName})
                        </span>
                        <span className="text-[11px] text-[#77798C]">مكان الحفظ: {t.safeLocation}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#EBF7EE] text-[#2E7D32]">
                        {t.status === 'in_custody' ? 'بحوزتي' : 'تمت الإعادة'}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-[#77798C] py-2">
                  لا توجد أي ديون أو أمانات مستحقة في هذا اليوم المحدد.
                </p>
              )}
            </div>
          </div>
        )}

        {/* ─────────────────────────────────────────────────────────────
            TAB 5: الخزنة والأمان (Vault & Security)
            ───────────────────────────────────────────────────────────── */}
        {activeTab === 'vault' && (
          <div className="bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-5 sm:p-7 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-xs space-y-6 animate-fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0] dark:border-[#2D2E4A]">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-[#FFF9E6] dark:bg-[#352D16] border border-[#E8B84A]/30 flex items-center justify-center text-[#E8B84A]">
                  <Lock className="w-5 h-5 text-[#D4A836]" />
                </div>
                <div>
                  <h3 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6]">
                    إعدادات حماية الخزنة 🔐
                  </h3>
                  <p className="text-xs text-[#77798C] dark:text-[#9E9FB5]">
                    تأمين بيانات الديون والأمانات برمز PIN وبصمة الإصبع
                  </p>
                </div>
              </div>

              {vaultSettings.isEnabled && (
                <button
                  type="button"
                  onClick={() => setIsVaultUnlocked(false)}
                  className="px-3.5 py-1.5 rounded-xl bg-[#5B5FEF] text-white text-xs font-black hover:brightness-105 cursor-pointer shadow-xs"
                >
                  قفل الخزنة الآن 🔒
                </button>
              )}
            </div>

            {pinFeedbackMsg && (
              <div className="p-3 bg-[#EBF7EE] dark:bg-[#1E3825] text-[#2E7D32] dark:text-[#81C784] rounded-2xl text-xs font-bold border border-[#A5D6A7]">
                {pinFeedbackMsg}
              </div>
            )}

            {/* Enable / Disable or Setup PIN */}
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#2D2E4A]">
                <div>
                  <span className="font-black text-xs text-[#25263A] dark:text-[#F3F4F6] block">
                    حالة قفل الخزنة
                  </span>
                  <span className="text-[11px] text-[#77798C] block mt-0.5">
                    {vaultSettings.isEnabled
                      ? 'الخزنة مفعلة ومحمية برمز مرور مشفر محلياً'
                      : 'الخزنة غير مقفلة حالياً ويمكن الدخول إليها مباشرة'}
                  </span>
                </div>

                {vaultSettings.isEnabled ? (
                  <button
                    type="button"
                    onClick={handleDisableVault}
                    className="px-3.5 py-1.5 rounded-xl bg-red-100 hover:bg-red-200 text-red-700 text-xs font-black transition-colors cursor-pointer"
                  >
                    تعطيل الحماية
                  </button>
                ) : (
                  <span className="text-xs font-bold text-[#E8B84A]">يرجى تعيين PIN أدناه</span>
                )}
              </div>

              {/* Set New PIN Form */}
              <form onSubmit={handleSetNewPin} className="p-4 rounded-2xl bg-[#FFFDF5] dark:bg-[#242136] border border-[#E8B84A]/30 space-y-3">
                <h4 className="font-black text-xs text-[#25263A] dark:text-[#F3F4F6]">
                  {vaultSettings.isEnabled ? 'تغيير رمز PIN الخزنة' : 'تعيين رمز PIN جديد للخزنة'}
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-[#77798C] mb-1">
                      رمز PIN (4 أو 6 أرقام):
                    </label>
                    <input
                      type="password"
                      maxLength={6}
                      value={newPin}
                      onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="••••"
                      required
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] text-sm font-black text-center tracking-widest"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-[#77798C] mb-1">
                      تأكيد رمز PIN:
                    </label>
                    <input
                      type="password"
                      maxLength={6}
                      value={confirmPin}
                      onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="••••"
                      required
                      className="w-full px-3 py-2 rounded-xl bg-white dark:bg-[#1E1F35] border border-[#E6E6F0] dark:border-[#2D2E4A] text-sm font-black text-center tracking-widest"
                    />
                  </div>
                </div>

                <div className="pt-1 flex justify-end">
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-[#5B5FEF] text-white text-xs font-black hover:brightness-105 cursor-pointer shadow-xs"
                  >
                    حفظ رمز PIN وتفعيل الخزنة
                  </button>
                </div>
              </form>

              {/* Biometric Toggle if supported */}
              {isBiometricSupported && (
                <div className="flex items-center justify-between p-4 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] border border-[#E6E6F0] dark:border-[#2D2E4A]">
                  <div className="flex items-center gap-2.5">
                    <Fingerprint className="w-5 h-5 text-[#5B5FEF]" />
                    <div>
                      <span className="font-black text-xs text-[#25263A] dark:text-[#F3F4F6] block">
                        فتح الخزنة ببصمة الإصبع / الوجه
                      </span>
                      <span className="text-[11px] text-[#77798C]">
                        استخدام المقاييس الحيوية للجهاز لإلغاء القفل بسرعة
                      </span>
                    </div>
                  </div>

                  <input
                    type="checkbox"
                    checked={vaultSettings.biometricEnabled}
                    onChange={(e) => {
                      const updated = { ...vaultSettings, biometricEnabled: e.target.checked };
                      saveVaultSettings(updated);
                      setVaultSettings(updated);
                    }}
                    className="w-5 h-5 rounded text-[#5B5FEF] cursor-pointer"
                  />
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <AddEditDebtModal
        isOpen={isAddDebtOpen}
        onClose={() => {
          setIsAddDebtOpen(false);
          setEditingDebt(null);
        }}
        onSave={handleSaveDebt}
        initialDebt={editingDebt}
      />

      {paymentDebtTarget && (
        <RecordPaymentModal
          isOpen={!!paymentDebtTarget}
          onClose={() => setPaymentDebtTarget(null)}
          debt={paymentDebtTarget}
          onPaymentSuccess={() => {
            refreshData();
            setPaymentDebtTarget(null);
          }}
        />
      )}

      <AddEditTrustModal
        isOpen={isAddTrustOpen}
        onClose={() => {
          setIsAddTrustOpen(false);
          setEditingTrust(null);
        }}
        onSave={handleSaveTrust}
        initialTrust={editingTrust}
      />

      <AmanaShareModal
        isOpen={!!shareDebtTarget || !!shareTrustTarget}
        onClose={() => {
          setShareDebtTarget(null);
          setShareTrustTarget(null);
        }}
        debt={shareDebtTarget}
        trust={shareTrustTarget}
      />

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#25263A]/70 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl p-6 border border-[#E6E6F0] dark:border-[#2D2E4A] shadow-2xl space-y-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 mx-auto flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-cairo font-black text-base text-[#25263A] dark:text-[#F3F4F6]">
                تأكيد حذف {deleteConfirmation.type === 'debt' ? 'الدين' : 'الأمانة'}
              </h3>
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5] mt-1 leading-relaxed">
                هل أنت متأكد من حذف «{deleteConfirmation.name}»؟ لن يمكن استرجاع هذا السجل بعد حذفه.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                className="flex-1 py-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] text-xs font-bold cursor-pointer"
              >
                تراجع
              </button>
              <button
                type="button"
                onClick={confirmDelete}
                className="flex-1 py-2.5 rounded-2xl bg-red-600 text-white text-xs font-black hover:bg-red-700 transition-colors cursor-pointer"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
