import React, { useState } from 'react';
import { X, Calendar, DollarSign, Clock, Bell, User, FileText, AlertCircle, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { DebtRecord, DebtType, COMMON_CURRENCIES } from '../../utils/amanaStorage';

export interface AddEditDebtModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: DebtRecord) => void;
  initialDebt?: DebtRecord | null;
}

export const AddEditDebtModal: React.FC<AddEditDebtModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialDebt,
}) => {
  const [personName, setPersonName] = useState(initialDebt?.personName || '');
  const [type, setType] = useState<DebtType>(initialDebt?.type || 'receivable');
  const [totalAmount, setTotalAmount] = useState<string>(initialDebt ? String(initialDebt.totalAmount) : '');
  const [currency, setCurrency] = useState(initialDebt?.currency || 'EGP');
  const [description, setDescription] = useState(initialDebt?.description || '');
  const [recordDate, setRecordDate] = useState(
    initialDebt?.recordDate || new Date().toISOString().split('T')[0]
  );
  const [dueDate, setDueDate] = useState(initialDebt?.dueDate || '');
  const [notes, setNotes] = useState(initialDebt?.notes || '');

  // Reminder settings
  const [reminderEnabled, setReminderEnabled] = useState(initialDebt?.reminderEnabled || false);
  const [reminderTime, setReminderTime] = useState(initialDebt?.reminderTime || '10:00');
  const [reminderDaysBefore, setReminderDaysBefore] = useState<number>(initialDebt?.reminderDaysBefore ?? 0);

  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personName.trim()) {
      setErrorMsg('يرجى إدخال اسم الشخص أو الجهة.');
      return;
    }

    const amountNum = parseFloat(totalAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      setErrorMsg('يرجى إدخال مبلغ صحيح أكبر من الصفر.');
      return;
    }

    const now = Date.now();
    const finalRecord: DebtRecord = {
      id: initialDebt?.id || `debt_${now}_${Math.random().toString(36).slice(2, 8)}`,
      personName: personName.trim(),
      type,
      totalAmount: amountNum,
      currency: currency.trim().toUpperCase() || 'EGP',
      description: description.trim() || (type === 'receivable' ? 'مستحق مالي' : 'دين مستحق'),
      recordDate: recordDate || new Date().toISOString().split('T')[0],
      dueDate: dueDate.trim() || undefined,
      status: initialDebt?.status || 'due',
      notes: notes.trim() || undefined,
      payments: initialDebt?.payments || [],
      reminderEnabled: !!(reminderEnabled && dueDate),
      reminderTime: reminderTime || '10:00',
      reminderDaysBefore,
      createdAt: initialDebt?.createdAt || now,
      updatedAt: now,
    };

    onSave(finalRecord);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-[#25263A]/70 backdrop-blur-sm animate-fade-in overflow-y-auto"
      dir="rtl"
    >
      <div className="relative w-full max-w-lg bg-[#FFFFFF] dark:bg-[#1E1F35] rounded-3xl shadow-2xl border border-[#E6E6F0] dark:border-[#2D2E4A] max-h-[92vh] flex flex-col overflow-hidden my-auto">
        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-[#E6E6F0] dark:border-[#2D2E4A] bg-gradient-to-r from-[#FFFEFC] to-[#F7F7FC] dark:from-[#202138] dark:to-[#1A1B2E]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#EEEEFF] dark:bg-[#282946] border border-[#5B5FEF]/20 flex items-center justify-center text-[#5B5FEF]">
              <DollarSign className="w-5 h-5 text-[#5B5FEF]" />
            </div>
            <div>
              <h2 className="font-cairo font-black text-base sm:text-lg text-[#25263A] dark:text-[#F3F4F6]">
                {initialDebt ? 'تعديل بيانات الدين' : 'تسجيل دين أو حق مالي جديد 📜'}
              </h2>
              <p className="text-xs text-[#77798C] dark:text-[#9E9FB5]">
                توثيق الحقوق والديون وفق الهدي النبوي
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-2xl hover:bg-[#F7F7FC] dark:hover:bg-[#25263A] text-[#77798C] hover:text-[#25263A] dark:hover:text-[#F3F4F6] transition-colors cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="flex items-center gap-2 p-3 bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 rounded-2xl text-xs font-bold border border-red-200 dark:border-red-900/50">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Operation Type Selector */}
          <div>
            <label className="block text-xs font-black text-[#25263A] dark:text-[#F3F4F6] mb-1.5">
              نوع العملية المالية <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setType('receivable')}
                className={`py-3 px-3 rounded-2xl text-xs font-black border transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  type === 'receivable'
                    ? 'bg-[#EBF7EE] dark:bg-[#1E3825] text-[#2E7D32] dark:text-[#81C784] border-[#4CAF82] shadow-xs'
                    : 'bg-[#F7F7FC] dark:bg-[#202138] text-[#77798C] dark:text-[#9E9FB5] border-[#E6E6F0] dark:border-[#2D2E4A]'
                }`}
              >
                <ArrowDownLeft className="w-4 h-4 text-[#4CAF82]" />
                <span>لي مال عنده (مستحق لي)</span>
              </button>

              <button
                type="button"
                onClick={() => setType('payable')}
                className={`py-3 px-3 rounded-2xl text-xs font-black border transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  type === 'payable'
                    ? 'bg-[#FFF4E5] dark:bg-[#3D2915] text-[#D97706] dark:text-[#FBBF24] border-[#F59E0B] shadow-xs'
                    : 'bg-[#F7F7FC] dark:bg-[#202138] text-[#77798C] dark:text-[#9E9FB5] border-[#E6E6F0] dark:border-[#2D2E4A]'
                }`}
              >
                <ArrowUpRight className="w-4 h-4 text-[#F59E0B]" />
                <span>عليّ مال له (دين عليّ)</span>
              </button>
            </div>
          </div>

          {/* Person Name */}
          <div>
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
              اسم الشخص أو الجهة <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                value={personName}
                onChange={(e) => setPersonName(e.target.value)}
                placeholder="مثال: أحمد عبد الله، شركة النور..."
                required
                className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
              />
              <User className="w-4 h-4 text-[#77798C] absolute left-3 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Amount & Currency */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
                المبلغ <span className="text-red-500">*</span>
              </label>
              <input
                type="number"
                step="any"
                min="0"
                value={totalAmount}
                onChange={(e) => setTotalAmount(e.target.value)}
                placeholder="0.00"
                required
                className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-sm font-black text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
                العملة
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full px-3 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-black text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors cursor-pointer"
              >
                {COMMON_CURRENCIES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code} — {c.nameAr}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
              وصف الدين أو سببه
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="مثال: قرض حسن، مستحقات شراء جهاز، إيجار..."
              className="w-full px-4 py-2.5 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
            />
          </div>

          {/* Dates: Record Date & Due Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
                تاريخ التسجيل
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={recordDate}
                  onChange={(e) => setRecordDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] mb-1">
                تاريخ الاستحقاق (اختياري)
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs font-bold text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Reminder Settings (Only if Due Date is provided) */}
          {dueDate && (
            <div className="p-3.5 rounded-2xl bg-[#FFFDF5] dark:bg-[#25263A]/40 border border-[#E8B84A]/30 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-[#E8B84A]" />
                  <span className="text-xs font-black text-[#25263A] dark:text-[#F3F4F6]">
                    تفعيل تذكير محلي قبل أو عند موعد الاستحقاق
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={reminderEnabled}
                  onChange={(e) => setReminderEnabled(e.target.checked)}
                  className="w-4 h-4 rounded text-[#5B5FEF] cursor-pointer"
                />
              </div>

              {reminderEnabled && (
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-[#E8B84A]/20">
                  <div>
                    <label className="block text-[11px] text-[#77798C] dark:text-[#9E9FB5] font-bold mb-1">
                      وقت التنبيه:
                    </label>
                    <input
                      type="time"
                      value={reminderTime}
                      onChange={(e) => setReminderTime(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-[#77798C] dark:text-[#9E9FB5] font-bold mb-1">
                      موعد الإشعار:
                    </label>
                    <select
                      value={reminderDaysBefore}
                      onChange={(e) => setReminderDaysBefore(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 rounded-xl bg-white dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] text-xs font-bold"
                    >
                      <option value={0}>في نفس يوم الاستحقاق</option>
                      <option value={1}>قبل الاستحقاق بيوم واحد</option>
                      <option value={3}>قبل الاستحقاق بـ 3 أيام</option>
                      <option value={7}>قبل الاستحقاق بأسبوع</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-[#77798C] dark:text-[#9E9FB5] mb-1">
              ملاحظات إضافية (اختيارية)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="شروط سداد، شهود، طريقة التحويل..."
              className="w-full px-4 py-2 rounded-2xl bg-[#FFFEFC] dark:bg-[#202138] border border-[#E6E6F0] dark:border-[#2D2E4A] focus:border-[#5B5FEF] text-xs text-[#25263A] dark:text-[#F3F4F6] focus:outline-none transition-colors resize-none"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#25263A] text-[#77798C] dark:text-[#9E9FB5] text-xs font-bold hover:bg-[#E6E6F0] transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white text-xs font-black hover:brightness-105 active:scale-95 transition-all shadow-md cursor-pointer"
            >
              {initialDebt ? 'حفظ التعديلات' : 'حفظ الدين'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
