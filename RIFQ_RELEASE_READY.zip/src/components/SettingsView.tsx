import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  ArrowRight, 
  Volume2, 
  VolumeX, 
  Smartphone, 
  Type, 
  Target, 
  Bell, 
  BellRing,
  Trash2, 
  Download, 
  Upload, 
  Check, 
  Sparkles,
  ShieldCheck,
  Sun,
  Moon,
  AlertCircle,
  CheckCircle2,
  Send,
  HelpCircle,
  Sliders,
  Award,
  ChevronLeft,
  User,
  Cloud,
  RefreshCw,
  Palette
} from 'lucide-react';
import { ScreenType, UserSettings } from '../types';
import { soundManager } from '../utils/audio';
import { DEFAULT_DHIKR_LIST } from '../utils/rosaryStorage';
import { ROSARY_THEMES, getRosaryTheme } from '../utils/rosaryThemes';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  sendTestNotification, 
  triggerPushNotification,
  RIFQ_NOTIFICATION_CHANNELS,
  isNotificationChannelEnabled,
  setNotificationChannelEnabled,
  subscribeToNotificationSettings,
  saveUnifiedNotificationSettings,
  openSystemNotificationSettings,
  NotificationManager,
  PermissionState 
} from '../utils/notifications';
import {
  loadDhikrNotificationSettings,
  saveDhikrNotificationSettings,
  sendTestMomentNotification,
  DhikrNotificationSettings,
} from '../utils/momentDhikrService';
import { triggerTestAdhan } from '../utils/prayerScheduler';
import { DeveloperCredits } from './DeveloperCredits';
import { PermissionsSettingsCard } from './Settings/PermissionsSettingsCard';
import { NotificationSettingsCard } from './Settings/NotificationSettingsCard';
import { DailyAyahHadithToastCard } from './Settings/DailyAyahHadithToastCard';
import { AppearanceThemesCard } from './Settings/AppearanceThemesCard';
import { PrayerFocusSettingsCard } from './PrayerFocus/PrayerFocusSettingsCard';
import { UserReportModal } from './Reports/UserReportModal';
import { useAuth } from '../context/AuthContext';

interface SettingsViewProps {
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onResetAllData: () => void;
  onNavigate: (screen: ScreenType) => void;
  onRestoreBackup: (jsonData: string) => boolean;
  onRestartFirstRunFlow?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onResetAllData,
  onNavigate,
  onRestoreBackup,
  onRestartFirstRunFlow,
}) => {
  const { currentUser, userProfile, isAdmin, openAuthModal, triggerCloudSync, syncStatus } = useAuth();
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<PermissionState>(() => getNotificationPermission());
  const [isTestingNotification, setIsTestingNotification] = useState(false);
  const [testStatusMsg, setTestStatusMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [customDhikrInput, setCustomDhikrInput] = useState('');

  const activeRosaryDhikr = settings.rosaryDhikr || 'سُبْحَانَ اللَّهِ';
  const activeRosaryTarget = settings.rosaryTarget || settings.defaultTarget || 100;
  const isRosarySoundActive = settings.rosarySoundEnabled !== undefined ? settings.rosarySoundEnabled : settings.soundEnabled;
  const isRosaryVibrationActive = settings.rosaryVibrationEnabled !== undefined ? settings.rosaryVibrationEnabled : settings.vibrationEnabled;
  const activeRosaryTheme = settings.rosaryTheme || 'emerald';
  const currentRosaryThemeObj = getRosaryTheme(activeRosaryTheme);

  // 5-Daily Dhikr Notifications State
  const [dhikrSettings, setDhikrSettings] = useState<DhikrNotificationSettings>(() => loadDhikrNotificationSettings());
  const [isTestingDhikrNotif, setIsTestingDhikrNotif] = useState(false);
  const [dhikrTestMsg, setDhikrTestMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const updateDhikrSettings = (partial: Partial<DhikrNotificationSettings>) => {
    const updated = { ...dhikrSettings, ...partial };
    setDhikrSettings(updated);
    saveDhikrNotificationSettings(updated);
    showSaved('تم حفظ إعدادات إشعارات الذكر 🔔');
  };

  const handleTestDhikrNotification = async () => {
    setIsTestingDhikrNotif(true);
    setDhikrTestMsg(null);
    try {
      const res = await sendTestMomentNotification();
      setPermissionStatus(getNotificationPermission());
      if (res.success) {
        setDhikrTestMsg({ type: 'success', text: res.message });
      } else {
        setDhikrTestMsg({ type: 'error', text: res.message });
      }
    } catch {
      setDhikrTestMsg({ type: 'error', text: 'حدث خطأ أثناء إرسال إشعار الذكر.' });
    } finally {
      setIsTestingDhikrNotif(false);
      setTimeout(() => setDhikrTestMsg(null), 6000);
    }
  };

  useEffect(() => {
    const checkPermissionOnResume = async () => {
      const detailed = await NotificationManager.getDetailedStatus();
      if (detailed.granted && detailed.areNotificationsEnabled) {
        setPermissionStatus('granted');
      } else if (detailed.permanentlyBlocked || detailed.postNotificationsPermission === 'denied') {
        setPermissionStatus('denied');
      } else {
        setPermissionStatus(getNotificationPermission());
      }
    };

    checkPermissionOnResume();

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        checkPermissionOnResume();
      }
    };

    window.addEventListener('focus', checkPermissionOnResume);
    document.addEventListener('visibilitychange', handleVisibility);

    if (typeof navigator !== 'undefined' && 'permissions' in navigator) {
      navigator.permissions
        .query({ name: 'notifications' as PermissionName })
        .then((permStatus) => {
          permStatus.onchange = () => checkPermissionOnResume();
        })
        .catch(() => {});
    }

    return () => {
      window.removeEventListener('focus', checkPermissionOnResume);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  const [channelStates, setChannelStates] = useState({
    adhan: isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.adhan),
    quran: isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.quran),
    azkar: isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.azkar),
    reminders: isNotificationChannelEnabled(RIFQ_NOTIFICATION_CHANNELS.reminders),
  });

  useEffect(() => {
    const unsubscribe = subscribeToNotificationSettings((unified) => {
      setChannelStates({
        adhan: unified.adhanChannelEnabled,
        quran: unified.quranChannelEnabled,
        azkar: unified.azkarChannelEnabled,
        reminders: unified.remindersChannelEnabled,
      });
    });
    return () => unsubscribe();
  }, []);

  const handleToggleChannel = (
    key: 'adhan' | 'quran' | 'azkar' | 'reminders',
    channelId: string,
    value: boolean
  ) => {
    setNotificationChannelEnabled(channelId, value);
    setChannelStates((prev) => ({ ...prev, [key]: value }));
  };

  const showSaved = (msg = 'تم حفظ التغييرات بنجاح') => {
    setSaveSuccessMsg(msg);
    setTimeout(() => setSaveSuccessMsg(null), 2600);
  };

  const [isTestingAdhan, setIsTestingAdhan] = useState(false);

  const handleRequestPermission = async () => {
    try {
      const result = await requestNotificationPermission();
      setPermissionStatus(result);
      if (result === 'granted') {
        onUpdateSettings({ pushNotificationsEnabled: true, remindersEnabled: true });
        await triggerPushNotification({
          title: 'رِفْق | RIFQ',
          message: 'تم تفعيل الإشعارات بنجاح في تطبيق رِفْق',
          tag: 'rifq-permission-granted',
          bypassChannelCheck: true,
        });
        showSaved('تم تفعيل الإشعارات بنجاح');
        setTestStatusMsg({
          type: 'success',
          text: 'الإشعارات مفعلة — ستستقبل الإشعارات من رِفْق',
        });
      } else if (result === 'denied') {
        setTestStatusMsg({
          type: 'error',
          text: 'الإشعارات متوقفة من إعدادات النظام — يرجى فتح إعدادات الإشعارات وتفعيلها.',
        });
      } else {
        setTestStatusMsg({
          type: 'error',
          text: 'الإشعارات غير مفعلة — فعّل الإشعارات لاستقبال التنبيهات.',
        });
      }
    } catch {
      setPermissionStatus(getNotificationPermission());
    }
  };

  const handleTriggerTestNotification = async () => {
    setIsTestingNotification(true);
    setTestStatusMsg(null);
    try {
      const success = await sendTestNotification();
      setPermissionStatus(getNotificationPermission());
      if (success) {
        setTestStatusMsg({
          type: 'success',
          text: 'تم إرسال الإشعار بنجاح',
        });
      } else {
        setTestStatusMsg({
          type: 'error',
          text: 'فشل إرسال الإشعار - تحقق من الإعدادات',
        });
      }
    } catch {
      setTestStatusMsg({
        type: 'error',
        text: 'فشل إرسال الإشعار - تحقق من الإعدادات',
      });
    } finally {
      setIsTestingNotification(false);
      setTimeout(() => setTestStatusMsg(null), 6000);
    }
  };

  const handleTestAdhanAudio = async () => {
    setIsTestingAdhan(true);
    try {
      const res = await triggerTestAdhan('maghrib');
      showSaved(res.message);
    } catch {
      showSaved('جاري تشغيل صوت الأذان التجريبي...');
    } finally {
      setTimeout(() => setIsTestingAdhan(false), 2500);
    }
  };

  const handleTestSound = (type: 'wooden_bead' | 'crystal_click' | 'soft_chime') => {
    onUpdateSettings({ soundType: type });
    soundManager.playBeadClick(settings.soundVolume, type);
    const label = type === 'wooden_bead' ? 'الخرز الخشبي' : type === 'crystal_click' ? 'نقرة الكريستال' : 'الرنين الهادئ';
    showSaved(`تم اختيار صوت: ${label}`);
  };

  const handleExportBackup = () => {
    const backupData = {
      settings: localStorage.getItem('mushaba_settings_v1'),
      history: localStorage.getItem('mushaba_history_v1'),
      favorites: localStorage.getItem('mushaba_favorites_v1'),
      customAthkar: localStorage.getItem('mushaba_custom_athkar_v1'),
      exportDate: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `نسخة_احتياطية_مسبحة_رفيق_المسلم_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showSaved('تم تصدير النسخة الاحتياطية بنجاح 💾');
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const success = onRestoreBackup(content);
        if (success) {
          showSaved('تمت استعادة النسخة الاحتياطية بنجاح! ✨');
        } else {
          alert('ملف النسخة الاحتياطية غير صالح.');
        }
      }
    };
    reader.readAsText(file);
  };

  const getSoundLabel = (type: string) => {
    switch(type) {
      case 'wooden_bead': return 'خرز خشبي مهدئ';
      case 'crystal_click': return 'نقرة كريستال نقية';
      case 'soft_chime': return 'رنين روحي ناعم';
      default: return 'نقر قياسي';
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6 pb-20 select-none font-tajawal" dir="rtl">
      
      {/* Save Toast Notification */}
      {saveSuccessMsg && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white px-5 py-3 rounded-full shadow-xl text-sm font-bold flex items-center gap-2.5 animate-fade-in border border-[#5B5FEF] shadow-[#E8B84A]/20">
          <Check className="w-4 h-4 text-[#5B5FEF]" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* ─── 0. Header Card ─── */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-[#E6E6F0] flex items-center justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-[#5B5FEF] via-[#E8B84A] to-[#4CAF82]" />
        
        <div className="flex items-center gap-3.5">
          <button
            onClick={() => onNavigate('tasbeeh')}
            className="w-10 h-10 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#25263A] flex items-center justify-center transition-all cursor-pointer border border-[#E6E6F0]"
            title="الرجوع للرئيسية"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-[#4145C7]">
                الإعدادات والتخصيص
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-[11px] font-bold">
                تفضيلات التطبيق
              </span>
            </div>
            <p className="text-xs text-[#77798C] mt-0.5">
              تخصيص المسبحة، المؤثرات، الخطوط، والتنبيهات بما يناسب وردك اليومي
            </p>
          </div>
        </div>

        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#F7F7FC] to-amber-100/60 text-[#4145C7] flex items-center justify-center border border-[#E6E6F0] shadow-xs">
          <SettingsIcon className="w-5 h-5" />
        </div>
      </div>

      {/* ─── 0.02. Card: 🎨 المظهر والثيمات (Appearance & Themes System) ─── */}
      <AppearanceThemesCard onShowToast={showSaved} />

      {/* ─── 0.03. Card: 🛡️ لوحة الإدارة المركزية (للأدمن الموثق فقط) ─── */}
      {isAdmin && (
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative overflow-hidden">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#EEEEFF] text-[#5B5FEF] border border-[#E6E6F0] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-base text-[#25263A]">
                  لوحة الإدارة المركزية (Admin Dashboard)
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-[10px] font-black">
                  صلاحية مسؤول موثقة
                </span>
              </div>
              <p className="text-xs text-[#77798C] mt-0.5">
                إدارة المستخدمين، الصلاحيات، إشعارات البث العام، مجموعات وِرد، البلاغات، وسجل التدقيق
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('admin')}
            className="px-5 py-2.5 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shrink-0"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>فتح لوحة الإدارة</span>
          </button>
        </div>
      )}

      {/* ─── 0.04. Card: ⚠️ مركز البلاغات والدعم الفني ─── */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-[#F7F7FC] text-[#5B5FEF] border border-[#E6E6F0] flex items-center justify-center shrink-0">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-black text-base text-[#25263A]">
              مركز البلاغات والدعم الفني
            </h3>
            <p className="text-xs text-[#77798C] mt-0.5">
              الإبلاغ عن مشكلة تقنية، محتوى، أو متابعة ردود الإدارة على بلاغاتك السابقة
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setIsReportModalOpen(true)}
          className="px-5 py-2.5 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] font-black text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shrink-0"
        >
          <Send className="w-4 h-4" />
          <span>إرسال بلاغ / متابعة بلاغاتي</span>
        </button>
      </div>

      <UserReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
      />

      {/* ─── 0.05. Card: 🔒 وضع الصلاة والتركيز (Prayer & Focus Mode) ─── */}
      <PrayerFocusSettingsCard
        onShowToast={showSaved}
        onNavigateToPrayers={() => onNavigate('prayers')}
      />

      {/* ─── 0.1. Card: إعدادات الإشعارات الرسمية (NotificationSettingsPage) ─── */}
      <NotificationSettingsCard />

      {/* ─── 0.15. Card: تنبيهات الآيات والأحاديث المنبثقة اليومية (Daily Ayah & Hadith Toast Notifications) ─── */}
      <DailyAyahHadithToastCard onShowToast={showSaved} />

      {/* ─── 0. Card: الحساب السحابي والمزامنة ─── */}
      <div className="bg-gradient-to-br from-[#5B5FEF] to-[#4CAF82] rounded-3xl p-5 text-white shadow-md border border-[#E6E6F0] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3.5 text-center sm:text-right">
          <div className="w-12 h-12 rounded-2xl bg-white/10 border border-[#E6E6F0] flex items-center justify-center text-amber-200 text-xl shrink-0 shadow-inner">
            <Cloud className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 justify-center sm:justify-start">
              <h3 className="font-black text-base text-amber-200">
                {currentUser ? 'الحساب والمزامنة السحابية' : 'المزامنة والحفظ السحابي'}
              </h3>
              {currentUser && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-[#4CAF82]/40/40 text-[10px] font-bold">
                  متصل ومحمي
                </span>
              )}
            </div>
            <p className="text-xs text-white/80 mt-0.5">
              {currentUser
                ? `مرحباً بك، ${userProfile?.displayName || currentUser.displayName || 'ذاكر لله'} • تسبيحاتك متزامنة عبر أجهزتك`
                : 'سجّل دخولك الآن لحفظ تسبيحاتك وأذكارك وإحصائياتك سحابياً عبر جميع أجهزتك'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-center">
          {currentUser ? (
            <>
              <button
                onClick={() => triggerCloudSync()}
                disabled={syncStatus === 'syncing'}
                className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold text-amber-200 flex items-center gap-1.5 transition-all cursor-pointer"
                title="مزامنة الآن"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncStatus === 'syncing' ? 'animate-spin' : ''}`} />
                <span>{syncStatus === 'syncing' ? 'مزامنة...' : 'مزامنة الآن'}</span>
              </button>
              <button
                onClick={() => onNavigate('profile')}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-[#4145C7] font-black text-xs shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <User className="w-3.5 h-3.5" />
                <span>إدارة الملف الشخصي</span>
              </button>
            </>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:opacity-95 text-[#4145C7] font-black text-xs shadow-md flex items-center gap-2 cursor-pointer"
            >
              <User className="w-4 h-4" />
              <span>تسجيل الدخول / إنشاء حساب</span>
            </button>
          )}
        </div>
      </div>

      {/* ─── 0. Card: ويدجت شاشة الهاتف (Home Screen Widgets) ─── */}
      <div className="bg-gradient-to-br from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] text-white rounded-3xl p-6 shadow-md border border-[#E6E6F0] space-y-4 relative overflow-hidden">
        <div className="absolute -left-10 -bottom-10 w-36 h-36 rounded-full bg-[#EEEEFF] pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-white/10 border border-[#E6E6F0] flex items-center justify-center text-amber-300 text-2xl shadow-inner shrink-0">
              <Smartphone className="w-6 h-6 text-[#5B5FEF]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-white font-tajawal">
                  ويدجت شاشة الهاتف (Widgets)
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-[#5B5FEF] text-[#4145C7] text-[10px] font-black">
                  جديد مخصص
                </span>
              </div>
              <p className="text-xs text-blue-100/90 mt-0.5 max-w-xl">
                أضف عداد التسبيح التفاعلي، وقت الصلاة القادم مع العد التنازلي، أو ذكر اليوم مباشرة لشاشة هاتفك الرئيسية (iOS و Android).
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigate('widgets')}
            className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-[#4145C7] font-black text-xs flex items-center justify-center gap-2 shadow-md hover:opacity-95 active:scale-95 transition-all cursor-pointer shrink-0"
          >
            <span>استعراض وتخصيص الويدجت</span>
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ─── 1. Card: تخصيص المسبحة والسبحة التفاعلية ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] space-y-5 relative overflow-hidden">
        {/* Top decorative accent */}
        <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7]" />

        {/* Card Header */}
        <div className="flex items-center justify-between pb-2 border-b border-[#E6E6F0]">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-[#4145C7] flex items-center justify-center text-2xl shadow-xs border border-[#E6E6F0]">
              📿
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-[#4145C7]">
                  تخصيص المسبحة والسبحة التفاعلية
                </h3>
                <span className="px-2 py-0.5 rounded-md bg-[#EEEEFF] text-[#4145C7] text-[10px] font-bold">
                  السبحة الافتراضية
                </span>
              </div>
              <p className="text-xs text-[#77798C] mt-0.5">
                تحديد الذكر الافتراضي، عدد الخرزات المستهدف لكل دورة، والاهتزاز والصوت الخاص
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigate('tasbeeh')}
            className="px-4 py-2 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:from-[#E8B84A] hover:to-[#E8B84A] text-white font-bold text-xs flex items-center gap-2 shadow-sm shadow-[#E8B84A]/40 border border-[#E6E6F0] transition-all cursor-pointer"
            title="فتح المسبحة وتجربة الإعدادات"
          >
            <span>فتح المسبحة</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 1.A اختيار الذكر النشط */}
        <div className="bg-[#F7F7FC] p-4.5 rounded-2xl border border-[#E6E6F0] space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#5B5FEF]" />
              <span className="text-xs font-black text-[#25263A]">الذكر المعتمد للمسبحة:</span>
              <span className="text-xs font-black text-[#4145C7] bg-white px-2.5 py-0.5 rounded-lg border border-[#E6E6F0] shadow-2xs">
                {activeRosaryDhikr}
              </span>
            </div>
            {/* Dynamic description */}
            <span className="text-[11px] font-bold text-[#4145C7]">
              الذكر الحالي: {activeRosaryDhikr} (المستهدف: {activeRosaryTarget} تسبيحة)
            </span>
          </div>

          {/* Preset Dhikr Chips Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
            {DEFAULT_DHIKR_LIST.slice(0, 8).map((d) => {
              const isSelected = activeRosaryDhikr === d.text;
              return (
                <button
                  key={d.id}
                  onClick={() => {
                    onUpdateSettings({ 
                      rosaryDhikr: d.text,
                      rosaryTarget: d.defaultTarget,
                      defaultTarget: d.defaultTarget
                    });
                    showSaved(`تم اختيار: ${d.title} (الهدف: ${d.defaultTarget})`);
                  }}
                  className={`p-2.5 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    isSelected
                      ? 'bg-gradient-to-b from-amber-50 to-emerald-50/80 border-[#5B5FEF] text-[#4145C7] ring-2 ring-[#5B5FEF]/40 shadow-xs'
                      : 'bg-white border-[#E6E6F0]/80 text-gray-700 hover:bg-[#F7F7FC] hover:border-[#E6E6F0]'
                  }`}
                >
                  <span className="text-[10px] font-bold text-gray-400 block">{d.title}</span>
                  <span className="text-xs font-black text-[#4145C7] leading-tight line-clamp-1">
                    {d.text}
                  </span>
                  <span className="text-[10px] text-[#4145C7] font-mono font-bold">هدف {d.defaultTarget}</span>
                </button>
              );
            })}
          </div>

          {/* Custom Dhikr Input Field */}
          <div className="pt-1 flex items-center gap-2">
            <input
              type="text"
              value={customDhikrInput}
              onChange={(e) => setCustomDhikrInput(e.target.value)}
              placeholder="أو اكتب أي ذكر مخصص للمسبحة هنا..."
              className="flex-1 bg-white border border-gray-300 rounded-xl px-3.5 py-2 text-xs text-[#25263A] focus:outline-hidden focus:border-[#5B5FEF] focus:ring-1 focus:ring-[#5B5FEF] shadow-2xs"
            />
            <button
              onClick={() => {
                if (customDhikrInput.trim()) {
                  onUpdateSettings({ rosaryDhikr: customDhikrInput.trim() });
                  showSaved(`تم تعيين الذكر المخصص: ${customDhikrInput.trim()}`);
                  setCustomDhikrInput('');
                }
              }}
              disabled={!customDhikrInput.trim()}
              className="px-4 py-2 bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:from-[#E8B84A] hover:to-[#E8B84A] disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-all shadow-xs shadow-[#E8B84A]/30 border border-[#E6E6F0] cursor-pointer shrink-0"
            >
              تعيين الذكر
            </button>
          </div>
        </div>

        {/* 1.B تحديد الهدف الرقمي لدورة المسبحة */}
        <div className="bg-[#F7F7FC] p-4.5 rounded-2xl border border-[#E6E6F0] space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-[#5B5FEF]" />
              <span className="text-xs font-black text-[#25263A]">عدد خرزات الدورة (الهدف المستهدف):</span>
            </div>
            {/* Dynamic description */}
            <span className="text-xs font-black font-mono text-[#4145C7] bg-white px-3 py-1 rounded-xl border border-[#E6E6F0] shadow-2xs">
              الهدف الحالي: {activeRosaryTarget} تسبيحة
            </span>
          </div>

          <p className="text-[11px] text-[#77798C]">
            عند إكمال {activeRosaryTarget} تسبيحة سيكتمل عداد الدورة ويصدر تنبيهاً لمسياً وصوتياً احتفالياً.
          </p>

          {/* Quick preset targets with golden style */}
          <div className="grid grid-cols-4 gap-2">
            {[33, 100, 500, 1000].map((t) => (
              <button
                key={t}
                onClick={() => {
                  onUpdateSettings({ rosaryTarget: t, defaultTarget: t });
                  showSaved(`تم تعيين هدف المسبحة إلى ${t} تسبيحة`);
                }}
                className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeRosaryTarget === t
                    ? 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white shadow-sm shadow-[#E8B84A]/30 border border-[#E6E6F0]'
                    : 'bg-white text-gray-700 border border-[#E6E6F0] hover:bg-gray-100'
                }`}
              >
                {t} تسبيحة
              </button>
            ))}
          </div>

          {/* Custom target numerical input */}
          <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-[#E6E6F0]">
            <div>
              <span className="text-xs text-gray-700 font-bold block">هدف رقمي مخصص للمسبحة:</span>
              <span className="text-[10px] text-gray-400">حدد أي عدد ترغب بإتمامه (1 - 100,000)</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="100000"
                value={activeRosaryTarget}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  if (!isNaN(val) && val > 0) {
                    onUpdateSettings({ rosaryTarget: val, defaultTarget: val });
                  }
                }}
                className="w-24 bg-[#F7F7FC] border border-[#E6E6F0] rounded-lg px-2.5 py-1 text-xs font-mono font-bold text-center text-[#4145C7] focus:outline-hidden focus:border-[#5B5FEF]"
              />
              <span className="text-xs text-[#77798C] font-bold">تسبيحة</span>
            </div>
          </div>
        </div>

        {/* 1.C اختيار لون وثيم المسبحة (Rosary Theme / Palette) */}
        <div className="bg-[#F7F7FC] p-4.5 rounded-2xl border border-[#E6E6F0] space-y-3.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-[#5B5FEF]" />
              <span className="text-xs font-black text-[#25263A]">لون وثيم المسبحة:</span>
              <span 
                className="text-xs font-black px-2.5 py-0.5 rounded-lg border shadow-2xs inline-flex items-center gap-1.5"
                style={{
                  backgroundColor: `${currentRosaryThemeObj.previewColor}18`,
                  borderColor: `${currentRosaryThemeObj.previewColor}40`,
                  color: currentRosaryThemeObj.previewColor
                }}
              >
                <span>{currentRosaryThemeObj.icon}</span>
                <span>{currentRosaryThemeObj.nameAr}</span>
              </span>
            </div>
            <span className="text-[11px] font-bold text-[#4145C7]">
              المظهر المطبق: {currentRosaryThemeObj.subtitleAr}
            </span>
          </div>

          <p className="text-[11px] text-[#77798C] leading-relaxed">
            اختر المظهر الجمالي المفضل لديك لحبات المسبحة والسبحة التفاعلية، ومؤشر الدورة، وزر التسبيح، والبريق التفاعلي.
          </p>

          {/* Grid of Themes */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            {ROSARY_THEMES.map((theme) => {
              const isSelected = activeRosaryTheme === theme.id;
              return (
                <button
                  key={theme.id}
                  onClick={() => {
                    onUpdateSettings({ rosaryTheme: theme.id });
                    showSaved(`تم تفعيل ثيم المسبحة: ${theme.nameAr}`);
                    soundManager.playBeadClick(settings.soundVolume, settings.soundType);
                  }}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between gap-2.5 group ${
                    isSelected
                      ? 'bg-white border-[#5B5FEF] ring-2 ring-[#5B5FEF]/50 shadow-md scale-[1.01]'
                      : 'bg-white/80 border-[#E6E6F0]/80 hover:border-[#E6E6F0] hover:bg-white hover:shadow-xs'
                  }`}
                >
                  {/* Top Bar with Bead Spherical Preview and Checkmark */}
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-1.5">
                      {/* Realistic 3D Bead Orb Swatch */}
                      <div 
                        className="w-6 h-6 rounded-full shadow-inner border border-white/60 flex items-center justify-center text-xs"
                        style={{
                          background: `radial-gradient(circle at 35% 30%, ${theme.beadGradient.stop0}, ${theme.beadGradient.stop25} 35%, ${theme.beadGradient.stop60} 70%, ${theme.beadGradient.stop100} 100%)`,
                          boxShadow: `0 2px 6px ${theme.previewColor}55`,
                        }}
                      />
                      {/* Active Bead Mini-Orb */}
                      <div 
                        className="w-3.5 h-3.5 rounded-full shadow-2xs border border-white/80"
                        style={{
                          background: `radial-gradient(circle at 35% 30%, ${theme.activeBeadGradient.stop0}, ${theme.activeBeadGradient.stop60} 70%, ${theme.activeBeadGradient.stop100} 100%)`,
                        }}
                      />
                    </div>

                    {/* Active Check Indicator Badge */}
                    {isSelected ? (
                      <span className="w-5 h-5 rounded-full bg-[#5B5FEF] text-white flex items-center justify-center text-[10px] shadow-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    ) : (
                      <span className="w-4 h-4 rounded-full border border-gray-300 group-hover:border-[#E6E6F0] transition-colors" />
                    )}
                  </div>

                  {/* Theme Name & Subtitle */}
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-black">
                      <span>{theme.icon}</span>
                      <span style={{ color: isSelected ? theme.previewColor : '#5B5FEF' }}>
                        {theme.nameAr}
                      </span>
                    </div>
                    <span className="text-[10px] text-[#77798C] block leading-tight mt-0.5">
                      {theme.subtitleAr}
                    </span>
                  </div>

                  {/* Miniature Palette Preview Bar */}
                  <div 
                    className="h-1.5 w-full rounded-full mt-0.5"
                    style={{
                      background: `linear-gradient(to right, ${theme.beadGradient.stop25}, ${theme.previewColor}, ${theme.accentColor})`
                    }}
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* 1.D مؤثرات السبحة (صوت واهتزاز) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          
          {/* صوت نقرات المسبحة */}
          <div className="bg-[#F7F7FC] p-4 rounded-2xl border border-[#E6E6F0] flex flex-col justify-between gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${isRosarySoundActive ? 'bg-[#4CAF82]/12 text-[#4CAF82]' : 'bg-gray-200 text-[#77798C]'}`}>
                  {isRosarySoundActive ? <Volume2 className="w-4.5 h-4.5" /> : <VolumeX className="w-4.5 h-4.5" />}
                </div>
                <div>
                  <span className="text-xs font-black text-[#25263A] block">صوت نقر خرز المسبحة</span>
                  <span className="text-[11px] font-bold text-[#4145C7]">
                    {isRosarySoundActive ? 'الصوت مفعّل: نقرة خرز طبيعية' : 'صوت المسبحة مكتوم'}
                  </span>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={isRosarySoundActive}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    onUpdateSettings({ 
                      rosarySoundEnabled: checked,
                      soundEnabled: checked
                    });
                    showSaved(checked ? 'تم تفعيل صوت المسبحة' : 'تم إيقاف صوت المسبحة');
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]" />
              </label>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#E6E6F0]/60">
              <span className="text-[10px] text-[#77798C]">
                {isRosarySoundActive ? 'يصدر نقرة صوتية مع كل خرزة تمررها' : 'التسبيح يتم بصمت وهدوء تام'}
              </span>
              {isRosarySoundActive && (
                <button
                  onClick={() => soundManager.playBeadClick(settings.soundVolume, settings.soundType)}
                  className="px-2.5 py-1 bg-white border border-[#E6E6F0] rounded-xl text-[10px] font-bold text-[#4145C7] hover:bg-[#EEEEFF] transition-colors cursor-pointer shadow-2xs flex items-center gap-1"
                  title="تجربة صوت النقر"
                >
                  <span>تجربة النقر</span>
                  <span>🔊</span>
                </button>
              )}
            </div>
          </div>

          {/* اهتزاز المسبحة */}
          <div className="bg-[#F7F7FC] p-4 rounded-2xl border border-[#E6E6F0] flex flex-col justify-between gap-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${isRosaryVibrationActive ? 'bg-[#EEEEFF] text-[#4145C7]' : 'bg-gray-200 text-[#77798C]'}`}>
                  <Smartphone className="w-4.5 h-4.5" />
                </div>
                <div>
                  <span className="text-xs font-black text-[#25263A] block">اهتزاز خرز المسبحة (Haptic)</span>
                  <span className="text-[11px] font-bold text-[#4145C7]">
                    {isRosaryVibrationActive ? 'الاهتزاز مفعّل: نبضة لمسية خفيفة' : 'الاهتزاز معطّل'}
                  </span>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={isRosaryVibrationActive}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    onUpdateSettings({ 
                      rosaryVibrationEnabled: checked,
                      vibrationEnabled: checked
                    });
                    if (checked) {
                      soundManager.triggerHaptic([40]);
                    }
                    showSaved(checked ? 'تم تفعيل اهتزاز المسبحة' : 'تم إيقاف اهتزاز المسبحة');
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]" />
              </label>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#E6E6F0]/60">
              <span className="text-[10px] text-[#77798C]">
                {isRosaryVibrationActive ? 'نبضة لكل خرزة واهتزاز مميز عند إتمام الدورة' : 'استجابة بصرية فقط بدون هزاز'}
              </span>
              {isRosaryVibrationActive && (
                <button
                  onClick={() => soundManager.triggerHaptic([35])}
                  className="px-2.5 py-1 bg-white border border-[#E6E6F0] rounded-xl text-[10px] font-bold text-[#4145C7] hover:bg-[#EEEEFF] transition-colors cursor-pointer shadow-2xs flex items-center gap-1"
                  title="تجربة الاهتزاز"
                >
                  <span>تجربة الهزاز</span>
                  <span>📳</span>
                </button>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* ─── 2. Card: المؤثرات الصوتية العامة ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#4CAF82]/12 text-[#4145C7] flex items-center justify-center border border-[#4CAF82]/40/50">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#4145C7]">المؤثرات الصوتية العامة</h3>
              <p className="text-xs font-bold text-[#4145C7] mt-0.5">
                {settings.soundEnabled 
                  ? `الصوت الحالي: مفعّل بنسبة ${Math.round(settings.soundVolume * 100)}% - بنمط (${getSoundLabel(settings.soundType)})`
                  : 'الصوت الحالي: مكتوم في كافة شاشات الأذكار والمسبحة'}
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.soundEnabled}
              onChange={(e) => {
                onUpdateSettings({ soundEnabled: e.target.checked });
                showSaved(e.target.checked ? 'تم تفعيل المؤثرات الصوتية' : 'تم كتم المؤثرات الصوتية');
              }}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]" />
          </label>
        </div>

        {settings.soundEnabled && (
          <div className="space-y-4 pt-3 border-t border-[#E6E6F0] animate-fade-in">
            {/* اختيار نغمة النقر */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-gray-700">نوع صوت النقر:</span>
                <span className="text-[11px] text-[#4145C7] font-bold">
                  الصوت المحدد: {getSoundLabel(settings.soundType)}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { id: 'wooden_bead', label: 'حبة خشبية 📿', desc: 'نقر الخشب الهادئ' },
                  { id: 'crystal_click', label: 'نقرة كريستال 💎', desc: 'صوت نقي وواضح' },
                  { id: 'soft_chime', label: 'رنين هادئ 🔔', desc: 'نغمة مهدئة للقلب' },
                ].map((s) => {
                  const isSelected = settings.soundType === s.id;
                  return (
                    <button
                      key={s.id}
                      onClick={() => handleTestSound(s.id as typeof settings.soundType)}
                      className={`py-2.5 px-2 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                        isSelected
                          ? 'bg-gradient-to-b from-emerald-50 to-amber-50/70 border-[#5B5FEF] text-[#4145C7] ring-2 ring-[#5B5FEF]/30 shadow-xs'
                          : 'bg-[#F7F7FC] border-[#E6E6F0] text-gray-700 hover:bg-gray-100 hover:border-gray-300'
                      }`}
                    >
                      <span className="text-xs font-black">{s.label}</span>
                      <span className="text-[10px] text-gray-400">{s.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* مستوى الصوت */}
            <div className="bg-[#F7F7FC] p-3.5 rounded-2xl border border-[#E6E6F0]">
              <div className="flex justify-between items-center text-xs font-bold text-gray-700 mb-2">
                <span>مستوى الصوت العام:</span>
                <span className="text-[#4145C7] font-mono font-bold bg-white px-2 py-0.5 rounded-md border border-[#E6E6F0]">
                  {Math.round(settings.soundVolume * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={settings.soundVolume}
                onChange={(e) => {
                  const vol = parseFloat(e.target.value);
                  onUpdateSettings({ soundVolume: vol });
                }}
                className="w-full accent-[#E8B84A] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                <span>هادئ جداً (10%)</span>
                <span>متوسط (50%)</span>
                <span>واضح ومرتفع (100%)</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ─── 3. Card: الاهتزاز اللمسي العام ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#EEEEFF] text-[#4145C7] flex items-center justify-center border border-[#E6E6F0]/50">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-[#4145C7]">الاهتزاز اللمسي العام (Haptic Feedback)</h3>
            <p className="text-xs font-bold text-[#4145C7] mt-0.5">
              {settings.vibrationEnabled 
                ? 'الاهتزاز الحالي: مفعّل لجميع الأزرار وإتمام الأوراد'
                : 'الاهتزاز الحالي: معطّل في جميع أرجاء التطبيق'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {settings.vibrationEnabled && (
            <button
              onClick={() => soundManager.triggerHaptic([40])}
              className="px-3 py-1.5 bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white rounded-xl text-xs font-bold shadow-xs shadow-[#E8B84A]/30 border border-[#E6E6F0] cursor-pointer transition-all hover:brightness-105"
              title="تجربة الاهتزاز"
            >
              تجربة 📳
            </button>
          )}
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.vibrationEnabled}
              onChange={(e) => {
                onUpdateSettings({ vibrationEnabled: e.target.checked });
                if (e.target.checked) soundManager.triggerHaptic([40]);
                showSaved(e.target.checked ? 'تم تفعيل الاهتزاز' : 'تم إيقاف الاهتزاز');
              }}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]" />
          </label>
        </div>
      </div>

      {/* ─── 4. Card: نوع الخط والمظهر العربي ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-sky-50 text-sky-700 flex items-center justify-center border border-sky-200/50">
            <Type className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-[#4145C7]">نوع الخط العربي للأذكار والقرآن</h3>
            <p className="text-xs font-bold text-[#4145C7] mt-0.5">
              الخط الحالي: {settings.themeFont === 'amiri' ? 'خط أميري التراثي الكلاسيكي' : 'خط تجوال الحديث الأنيق'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          {[
            { 
              id: 'tajawal', 
              label: 'خط تجوال الحديث (Tajawal)', 
              desc: 'وضوح فائق ومريح جداً للعين عند القراءة اليومية السريعة',
              preview: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ سُبْحَانَ اللَّهِ الْعَظِيمِ' 
            },
            { 
              id: 'amiri', 
              label: 'خط أميري التراثي (Amiri)', 
              desc: 'رسم المصاحف العثمانية بأصالة تراثية وروحانية عالية',
              preview: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ سُبْحَانَ اللَّهِ الْعَظِيمِ' 
            },
          ].map((f) => {
            const isSelected = settings.themeFont === f.id;
            return (
              <button
                key={f.id}
                onClick={() => {
                  onUpdateSettings({ themeFont: f.id as typeof settings.themeFont });
                  showSaved(`تم اعتماد: ${f.label}`);
                }}
                className={`p-4 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                  isSelected
                    ? 'bg-gradient-to-b from-amber-50/90 to-emerald-50/50 border-[#5B5FEF] text-[#4145C7] ring-2 ring-[#5B5FEF]/30 shadow-xs'
                    : 'bg-[#F7F7FC] border-[#E6E6F0] text-gray-700 hover:bg-gray-100 hover:border-gray-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-[#4145C7]">{f.label}</span>
                    {isSelected && (
                      <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] text-[10px] font-extrabold">
                        الخط النشط ✓
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-[#77798C] mt-1">{f.desc}</p>
                </div>

                <div className={`text-sm font-bold text-[#25263A] pt-2 border-t border-[#E6E6F0]/60 leading-relaxed ${f.id === 'amiri' ? 'font-amiri text-base' : 'font-tajawal'}`}>
                  {f.preview}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ─── 5. Card: الهدف اليومي العام للتسبيح ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#E8B84A]/20 to-amber-100 text-[#4145C7] flex items-center justify-center border border-[#E6E6F0] shadow-2xs">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#4145C7]">الهدف اليومي العام الموصى به</h3>
              <p className="text-xs font-bold text-[#4145C7] mt-0.5">
                الهدف الحالي: {settings.dailyGoal} تسبيحة يومياً (للحفاظ على سلسلة استمرارك ورتبتك)
              </p>
            </div>
          </div>

          <span className="text-xs font-black font-mono text-[#4145C7] bg-[#F7F7FC] px-3 py-1 rounded-xl border border-[#E6E6F0] shadow-2xs">
            {settings.dailyGoal} تسبيحة / اليوم
          </span>
        </div>

        <div className="grid grid-cols-4 gap-2 pt-1">
          {[33, 100, 500, 1000].map((t) => (
            <button
              key={t}
              onClick={() => {
                onUpdateSettings({ dailyGoal: t });
                showSaved(`تم تحديد الهدف اليومي: ${t} تسبيحة`);
              }}
              className={`py-3 rounded-2xl font-bold text-xs transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                settings.dailyGoal === t
                  ? 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white shadow-sm shadow-emerald-900/30 border border-[#5B5FEF]'
                  : 'bg-[#F7F7FC] text-gray-700 border border-[#E6E6F0] hover:bg-gray-100 hover:border-gray-300'
              }`}
            >
              <span className="text-sm font-black font-mono">{t}</span>
              <span className="text-[10px] opacity-80">تسبيحة</span>
            </button>
          ))}
        </div>
      </div>

      {/* ─── 6. Card: التذكيرات وإشعارات الدفع ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-700 flex items-center justify-center border border-purple-200/50">
              <BellRing className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-[#4145C7]">تذكيرات الأوراد وإشعارات الدفع</h3>
              <p className="text-xs font-bold text-[#4145C7] mt-0.5">
                {settings.remindersEnabled 
                  ? `التذكيرات الحالية: مفعّلة (الصباح: ${settings.morningReminderTime} | المساء: ${settings.eveningReminderTime})`
                  : 'التذكيرات الحالية: متوقفة حالياً'}
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.remindersEnabled}
              onChange={(e) => {
                onUpdateSettings({ remindersEnabled: e.target.checked });
                showSaved(e.target.checked ? 'تم تفعيل التذكيرات اليومية' : 'تم إيقاف التذكيرات');
              }}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]" />
          </label>
        </div>

        {settings.remindersEnabled && (
          <div className="space-y-4 pt-3 border-t border-[#E6E6F0] text-xs">
            
            {/* حالة الإشعارات الحقيقية من النظام + القنوات الأربع */}
            <div className="space-y-3">
              <div
                className={`p-4 rounded-2xl bg-white border flex items-center gap-3 ${
                  permissionStatus === 'granted'
                    ? 'border-[#4CAF82]'
                    : 'border-[#D95C6A]'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    permissionStatus === 'granted'
                      ? 'bg-[#4CAF82]/12 text-[#4CAF82]'
                      : 'bg-[#D95C6A]/10 text-[#D95C6A]'
                  }`}
                >
                  <Bell className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <div className="font-black text-sm text-[#25263A]">
                    {permissionStatus === 'granted'
                      ? '🔔 إشعارات الجهاز: مفعلة'
                      : 'إشعارات الجهاز متوقفة'}
                  </div>
                  <div className="text-xs text-[#77798C] mt-0.5">
                    {permissionStatus === 'granted'
                      ? 'ستستقبل الإشعارات الحقيقية من رِفْق في شريط الإشعارات ومركز التذكيرات'
                      : 'اسمح لرِفْق بإرسال التذكيرات حتى تصلك أوقات الأذكار والمواقيت والتنبيهات المهمة.'}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => openSystemNotificationSettings()}
                  className="px-3 py-1.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] text-[11px] font-bold transition-colors cursor-pointer shrink-0"
                >
                  فتح إعدادات الإشعارات
                </button>
              </div>

              {/* Toggles للقنوات الأربع */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {[
                  {
                    key: 'adhan' as const,
                    label: 'تنبيهات الأذان',
                    channelId: RIFQ_NOTIFICATION_CHANNELS.adhan,
                  },
                  {
                    key: 'quran' as const,
                    label: 'تذكير القرآن',
                    channelId: RIFQ_NOTIFICATION_CHANNELS.quran,
                  },
                  {
                    key: 'azkar' as const,
                    label: 'الأذكار',
                    channelId: RIFQ_NOTIFICATION_CHANNELS.azkar,
                  },
                  {
                    key: 'reminders' as const,
                    label: 'التذكيرات',
                    channelId: RIFQ_NOTIFICATION_CHANNELS.reminders,
                  },
                ].map((ch) => {
                  const isEnabled =
                    permissionStatus === 'granted' && channelStates[ch.key];
                  return (
                    <div
                      key={ch.key}
                      className="flex items-center justify-between px-4 py-2.5 bg-[#F7F7FC] rounded-xl border border-[#E6E6F0]"
                    >
                      <span className="font-bold text-xs text-[#25263A]">
                        {ch.label}
                      </span>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          disabled={permissionStatus !== 'granted'}
                          checked={isEnabled}
                          onChange={(e) =>
                            handleToggleChannel(
                              ch.key,
                              ch.channelId,
                              e.target.checked
                            )
                          }
                          className="sr-only peer"
                        />
                        <div className="w-10 h-5 bg-gray-200 peer-disabled:opacity-50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                      </label>
                    </div>
                  );
                })}
              </div>

              {permissionStatus !== 'granted' && (
                <button
                  onClick={handleRequestPermission}
                  className="w-full py-3 px-4 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs transition-all cursor-pointer"
                >
                  السماح بالإشعارات
                </button>
              )}
            </div>

            {/* أوقات أذكار الصباح والمساء */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              
              {/* موعد أذكار الصباح */}
              <div className="bg-[#F7F7FC] p-4 rounded-2xl border border-[#E6E6F0] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-[#25263A]">
                    <Sun className="w-4 h-4 text-amber-500" />
                    <span>موعد أذكار الصباح:</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#4145C7] bg-white px-2.5 py-0.5 rounded-lg border border-[#E6E6F0] shadow-2xs">
                    {settings.morningReminderTime}
                  </span>
                </div>

                <input
                  type="time"
                  value={settings.morningReminderTime}
                  onChange={(e) => {
                    onUpdateSettings({ morningReminderTime: e.target.value });
                    saveUnifiedNotificationSettings({ morningAthkarTime: e.target.value });
                    showSaved(`تم ضبط موعد الصباح على ${e.target.value}`);
                  }}
                  className="w-full bg-white border border-gray-300 rounded-xl p-2.5 font-bold text-[#25263A] text-center text-sm shadow-2xs focus:border-[#5B5FEF] focus:outline-hidden"
                />

                {/* أوقات سريعة مقترحة للصباح */}
                <div className="flex items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-[#77798C]">أوقات شائعة:</span>
                  {[
                    { time: '05:30', label: 'الفجر' },
                    { time: '06:30', label: 'الشروق' },
                    { time: '07:30', label: 'الضحى' },
                  ].map((p) => (
                    <button
                      key={p.time}
                      onClick={() => {
                        onUpdateSettings({ morningReminderTime: p.time });
                        saveUnifiedNotificationSettings({ morningAthkarTime: p.time });
                        showSaved(`تم ضبط تذكير الصباح على ${p.time}`);
                      }}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                        settings.morningReminderTime === p.time
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-white text-gray-700 border-[#E6E6F0] hover:bg-gray-100'
                      }`}
                    >
                      {p.time} ({p.label})
                    </button>
                  ))}
                </div>
              </div>

              {/* موعد أذكار المساء */}
              <div className="bg-[#F7F7FC] p-4 rounded-2xl border border-[#E6E6F0] space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-[#25263A]">
                    <Moon className="w-4 h-4 text-indigo-600" />
                    <span>موعد أذكار المساء:</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-[#4145C7] bg-white px-2.5 py-0.5 rounded-lg border border-[#E6E6F0] shadow-2xs">
                    {settings.eveningReminderTime}
                  </span>
                </div>

                <input
                  type="time"
                  value={settings.eveningReminderTime}
                  onChange={(e) => {
                    onUpdateSettings({ eveningReminderTime: e.target.value });
                    saveUnifiedNotificationSettings({ eveningAthkarTime: e.target.value });
                    showSaved(`تم ضبط موعد المساء على ${e.target.value}`);
                  }}
                  className="w-full bg-white border border-gray-300 rounded-xl p-2.5 font-bold text-[#25263A] text-center text-sm shadow-2xs focus:border-[#5B5FEF] focus:outline-hidden"
                />

                {/* أوقات سريعة مقترحة للمساء */}
                <div className="flex items-center gap-1.5 pt-1">
                  <span className="text-[10px] text-[#77798C]">أوقات شائعة:</span>
                  {[
                    { time: '16:30', label: 'العصر' },
                    { time: '17:30', label: 'المغرب' },
                    { time: '19:30', label: 'العشاء' },
                  ].map((p) => (
                    <button
                      key={p.time}
                      onClick={() => {
                        onUpdateSettings({ eveningReminderTime: p.time });
                        saveUnifiedNotificationSettings({ eveningAthkarTime: p.time });
                        showSaved(`تم ضبط تذكير المساء على ${p.time}`);
                      }}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                        settings.eveningReminderTime === p.time
                          ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                          : 'bg-white text-gray-700 border-[#E6E6F0] hover:bg-gray-100'
                      }`}
                    >
                      {p.time} ({p.label})
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* أزرار تجربة إشعار فوري وصوت الأذان */}
            <div className="pt-1 space-y-2">
              <button
                onClick={handleTriggerTestNotification}
                disabled={isTestingNotification}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-[#E8B84A] via-[#E8B84A] to-[#E8B84A] hover:from-[#E8B84A] hover:to-[#E8B84A] text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm shadow-[#E8B84A]/40 border border-[#E6E6F0] transition-all cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{isTestingNotification ? 'جارٍ إرسال الإشعار التجريبي...' : 'إرسال إشعار تجريبي الآن للتأكد من عمله'}</span>
              </button>

              <button
                onClick={handleTestAdhanAudio}
                disabled={isTestingAdhan}
                className="w-full py-2.5 px-4 rounded-2xl bg-[#4CAF82]/12 hover:bg-[#4CAF82]/12 text-[#4145C7] font-extrabold text-xs flex items-center justify-center gap-2 border border-[#4CAF82]/40 transition-all cursor-pointer disabled:opacity-50"
              >
                <Volume2 className="w-4 h-4 text-[#4145C7]" />
                <span>{isTestingAdhan ? 'جارٍ تشغيل صوت الأذان...' : 'تشغيل تجربة صوت الأذان الفعلي'}</span>
              </button>

              {testStatusMsg && (
                <div
                  className={`mt-2.5 p-3 rounded-xl text-xs leading-relaxed flex items-center gap-2 animate-fade-in ${
                    testStatusMsg.type === 'success'
                      ? 'bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40'
                      : testStatusMsg.type === 'error'
                      ? 'bg-red-50 text-red-800 border border-red-200'
                      : 'bg-blue-50 text-blue-800 border border-blue-200'
                  }`}
                >
                  {testStatusMsg.type === 'success' && <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />}
                  {testStatusMsg.type === 'error' && <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />}
                  {testStatusMsg.type === 'info' && <HelpCircle className="w-4 h-4 text-blue-600 shrink-0" />}
                  <span>{testStatusMsg.text}</span>
                </div>
              )}
            </div>

          </div>
        )}
      </div>

      {/* ─── 6.5. Card: إشعارات الذكر اليومية (5 إشعارات حقيقية دورية) ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] space-y-4">
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#F7F7FC] to-amber-100 text-[#4145C7] flex items-center justify-center border border-[#E6E6F0] shadow-xs">
              <Sparkles className="w-5 h-5 text-[#5B5FEF]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-[#4145C7]">إشعارات الذكر الدورية (5 مرات يومياً)</h3>
                <span className="px-2 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] border border-[#5B5FEF]/20 text-[10px] font-bold">
                  إشعارات حقيقية
                </span>
              </div>
              <p className="text-xs font-bold text-[#4145C7] mt-0.5">
                {dhikrSettings.enabled
                  ? 'الميزة مفعّلة: يصلك 5 إشعارات حقيقية يومياً بمحتوى ذكر متغير من السنة النبوية والقرآن'
                  : 'الميزة متوقفة حالياً'}
              </p>
            </div>
          </div>

          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={dhikrSettings.enabled}
              onChange={(e) => updateDhikrSettings({ enabled: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#5B5FEF]" />
          </label>
        </div>

        {dhikrSettings.enabled && (
          <div className="space-y-4 pt-3 border-t border-[#E6E6F0] text-xs animate-fade-in">
            
            {/* Note & Explanation */}
            <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-50 to-emerald-50/50 border border-[#E6E6F0] text-[11px] text-[#25263A] leading-relaxed">
              <span className="font-bold text-[#4145C7]">🎯 آلية الإشعارات: </span>
              تصلك التنبيهات في المواعيد المحددة أدناه بدون تكرار في نفس اليوم، مع الصوت الهادئ، والاهتزاز الخفيف، والأيقونة الذهبية المخصصة للتطبيق. بالضغط على الإشعار تنتقل فوراً إلى شاشة <strong>«ذكر اللحظة»</strong>.
            </div>

            {/* Sound & Vibration Sub-Toggles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              
              <div className="p-3 bg-[#F7F7FC] rounded-xl border border-[#E6E6F0] flex items-center justify-between">
                <span className="font-bold text-gray-700 flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-[#5B5FEF]" />
                  <span>نغمة هادئة مخصصة</span>
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dhikrSettings.soundEnabled}
                    onChange={(e) => updateDhikrSettings({ soundEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>

              <div className="p-3 bg-[#F7F7FC] rounded-xl border border-[#E6E6F0] flex items-center justify-between">
                <span className="font-bold text-gray-700 flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-[#5B5FEF]" />
                  <span>نمط اهتزاز خفيف</span>
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={dhikrSettings.vibrationEnabled}
                    onChange={(e) => updateDhikrSettings({ vibrationEnabled: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-gray-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#5B5FEF]" />
                </label>
              </div>

            </div>

            {/* The 5 Time Slot Selectors */}
            <div className="space-y-2 pt-1">
              <span className="text-xs font-black text-[#4145C7] block">
                مواعيد الإشعارات الخمسة اليومية:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                
                {/* 1. Fajr */}
                <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0] space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#25263A]">
                    <span>🌅 إشعار الفجر</span>
                    <span className="text-gray-400 font-mono text-[10px]">بداية يومك</span>
                  </div>
                  <input
                    type="time"
                    value={dhikrSettings.fajrTime}
                    onChange={(e) => updateDhikrSettings({ fajrTime: e.target.value })}
                    className="w-full bg-white border border-gray-300 rounded-xl p-2 font-mono font-bold text-[#25263A] text-center text-xs shadow-2xs focus:border-[#5B5FEF] focus:outline-hidden"
                  />
                </div>

                {/* 2. Duha */}
                <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0] space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#25263A]">
                    <span>☀️ إشعار الضحى</span>
                    <span className="text-gray-400 font-mono text-[10px]">لا تنسَ ذكر الله</span>
                  </div>
                  <input
                    type="time"
                    value={dhikrSettings.duhaTime}
                    onChange={(e) => updateDhikrSettings({ duhaTime: e.target.value })}
                    className="w-full bg-white border border-gray-300 rounded-xl p-2 font-mono font-bold text-[#25263A] text-center text-xs shadow-2xs focus:border-[#5B5FEF] focus:outline-hidden"
                  />
                </div>

                {/* 3. Dhuhr */}
                <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0] space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#25263A]">
                    <span>🕛 إشعار الظهر</span>
                    <span className="text-gray-400 font-mono text-[10px]">وقت الذكر</span>
                  </div>
                  <input
                    type="time"
                    value={dhikrSettings.dhuhrTime}
                    onChange={(e) => updateDhikrSettings({ dhuhrTime: e.target.value })}
                    className="w-full bg-white border border-gray-300 rounded-xl p-2 font-mono font-bold text-[#25263A] text-center text-xs shadow-2xs focus:border-[#5B5FEF] focus:outline-hidden"
                  />
                </div>

                {/* 4. Asr */}
                <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0] space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#25263A]">
                    <span>🌇 إشعار العصر</span>
                    <span className="text-gray-400 font-mono text-[10px]">ذكر المساء</span>
                  </div>
                  <input
                    type="time"
                    value={dhikrSettings.asrTime}
                    onChange={(e) => updateDhikrSettings({ asrTime: e.target.value })}
                    className="w-full bg-white border border-gray-300 rounded-xl p-2 font-mono font-bold text-[#25263A] text-center text-xs shadow-2xs focus:border-[#5B5FEF] focus:outline-hidden"
                  />
                </div>

                {/* 5. Night */}
                <div className="bg-[#F7F7FC] p-3 rounded-2xl border border-[#E6E6F0] space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-bold text-[#25263A]">
                    <span>🌙 إشعار الليل</span>
                    <span className="text-gray-400 font-mono text-[10px]">قبل النوم</span>
                  </div>
                  <input
                    type="time"
                    value={dhikrSettings.nightTime}
                    onChange={(e) => updateDhikrSettings({ nightTime: e.target.value })}
                    className="w-full bg-white border border-gray-300 rounded-xl p-2 font-mono font-bold text-[#25263A] text-center text-xs shadow-2xs focus:border-[#5B5FEF] focus:outline-hidden"
                  />
                </div>

                {/* Direct Moment Screen Link Button */}
                <div className="bg-gradient-to-br from-amber-50 to-amber-100/60 p-3 rounded-2xl border border-[#E6E6F0] flex flex-col justify-between">
                  <div className="text-[11px] font-bold text-[#4145C7]">
                    شاشة ذكر اللحظة
                  </div>
                  <button
                    onClick={() => onNavigate('moment_dhikr')}
                    className="w-full py-2 bg-white hover:bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] rounded-xl text-xs font-bold transition-all shadow-2xs active:scale-95 cursor-pointer mt-1"
                  >
                    عرض شاشة الذكر 🌅
                  </button>
                </div>

              </div>
            </div>

            {/* Test Real Dhikr Notification Button */}
            <div className="pt-2">
              <button
                onClick={handleTestDhikrNotification}
                disabled={isTestingDhikrNotif}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] via-[#4D51DF] to-[#4145C7] hover:brightness-105 text-white font-extrabold text-xs flex items-center justify-center gap-2 shadow-sm border border-[#4CAF82]/40 transition-all cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{isTestingDhikrNotif ? 'جارٍ إرسال إشعار الذكر الحقيقي...' : '🔔 إرسال إشعار ذكر حقيقي الآن (تجربة الصوت والاهتزاز والأيقونة)'}</span>
              </button>

              {dhikrTestMsg && (
                <div
                  className={`mt-2.5 p-3 rounded-xl text-xs leading-relaxed flex items-center gap-2 animate-fade-in ${
                    dhikrTestMsg.type === 'success'
                      ? 'bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40'
                      : 'bg-red-50 text-red-800 border border-red-200'
                  }`}
                >
                  {dhikrTestMsg.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-[#4CAF82] shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                  )}
                  <span>{dhikrTestMsg.text}</span>
                </div>
              )}
            </div>

          </div>
        )}

      </div>
      <PermissionsSettingsCard onRestartFirstRunFlow={onRestartFirstRunFlow} />

      {/* ─── 8. Card: النسخ الاحتياطي واستعادة البيانات ─── */}
      <div className="bg-white rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#4CAF82]/12 text-[#4CAF82] flex items-center justify-center border border-[#4CAF82]/40/50">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-[#4145C7]">النسخ الاحتياطي ومزامنة البيانات</h3>
            <p className="text-xs font-bold text-[#4145C7] mt-0.5">
              البيانات الحالية: محفوظة محلياً بأمان على جهازك (الأذكار المفضلة، وسجلات الختمات، وسلسلة الأيام)
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <button
            onClick={handleExportBackup}
            className="py-3 px-4 rounded-2xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:from-[#E8B84A] hover:to-[#E8B84A] text-white font-black text-xs border border-[#E6E6F0] flex items-center justify-center gap-2 shadow-sm shadow-[#E8B84A]/30 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>تصدير نسخة احتياطية (JSON)</span>
          </button>

          <label className="py-3 px-4 rounded-2xl bg-[#F7F7FC] hover:bg-[#EEEEFF] text-[#4145C7] font-black text-xs border border-[#E6E6F0] flex items-center justify-center gap-2 transition-all cursor-pointer text-center">
            <Upload className="w-4 h-4 text-[#4CAF82]" />
            <span>استعادة نسخة سابقة من جهازك</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportBackup}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* ─── 8. Card: حقوق وتواصل المطور ─── */}
      <DeveloperCredits onOpenFullCredits={() => onNavigate('credits')} />

      {/* ─── 9. Card: تصفير البيانات وإعادة التعيين ─── */}
      <div className="bg-red-50/40 rounded-3xl p-6 border border-red-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Trash2 className="w-4 h-4 text-red-600" />
            <h4 className="text-sm font-black text-red-900">إعادة ضبط المصنع ومسح البيانات</h4>
          </div>
          <p className="text-xs font-bold text-red-700/80 mt-1">
            الحالة: يمكنك تصفير كافة السجلات والإحصائيات الحالية في حال رغبت بالبدء من الصفر
          </p>
        </div>

        <button
          onClick={() => setShowConfirmReset(true)}
          className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-2xl shadow-sm transition-all flex items-center gap-2 cursor-pointer shrink-0"
        >
          <Trash2 className="w-4 h-4" />
          <span>مسح كافة البيانات</span>
        </button>
      </div>

      {/* Confirm Reset Dialog */}
      {showConfirmReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-[#E6E6F0] text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center mx-auto text-2xl">
              ⚠️
            </div>
            <h3 className="text-lg font-black text-[#25263A]">تأكيد مسح البيانات</h3>
            <p className="text-xs text-[#77798C] leading-relaxed">
              سيتم حذف جميع سجلات التسبيح والإحصائيات وسلاسل الاستمرار نهائياً. هل أنت متأكد من رغبتك بالبدء من جديد؟
            </p>
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  onResetAllData();
                  setShowConfirmReset(false);
                  showSaved('تمت إعادة ضبط البيانات بنجاح');
                }}
                className="flex-1 py-2.5 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                تأكيد المسح
              </button>
              <button
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 py-2.5 rounded-2xl bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-xs transition-colors cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
