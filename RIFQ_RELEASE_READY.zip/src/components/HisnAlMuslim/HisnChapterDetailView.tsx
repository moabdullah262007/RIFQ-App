import React, { useState } from 'react';
import { ArrowRight, Star, Share2, Copy, Check, Eye } from 'lucide-react';
import { HisnChapter, HisnDhikrItem } from '../../data/hisnAlMuslimData';
import { HisnDhikrModal } from './HisnDhikrModal';

interface HisnChapterDetailViewProps {
  chapter: HisnChapter;
  onBack: () => void;
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  chapterFavorites: number[];
  onToggleChapterFavorite: (chapterId: number) => void;
}

export const HisnChapterDetailView: React.FC<HisnChapterDetailViewProps> = ({
  chapter,
  onBack,
  favorites,
  onToggleFavorite,
  chapterFavorites,
  onToggleChapterFavorite,
}) => {
  const [selectedDhikr, setSelectedDhikr] = useState<HisnDhikrItem | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const isChapterFav = chapterFavorites.includes(chapter.id);

  const handleCopySingle = (dhikr: HisnDhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const copyText = `«${dhikr.text}»\n\n📖 المصدر: ${dhikr.source}\nمن كتاب حصن المسلم — تطبيق رِفْق | RIFQ`;
    navigator.clipboard.writeText(copyText);
    setCopiedId(dhikr.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShareSingle = async (dhikr: HisnDhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const shareText = `«${dhikr.text}»\n\n📖 المصدر: ${dhikr.source}\n\nمن كتاب حصن المسلم — تطبيق رِفْق | RIFQ`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: chapter.title,
          text: shareText,
        });
      } catch {
        // user cancelled or fallback
      }
    } else {
      navigator.clipboard.writeText(shareText);
      setCopiedId(dhikr.id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const handleShareChapter = async () => {
    const header = `🛡️ حصن المسلم — ${chapter.title}\n━━━━━━━━━━━━━━━━━━━━\n\n`;
    const athkarText = chapter.athkar
      .map((d, index) => `${index + 1}. «${d.text}»\n📖 ${d.source}\n`)
      .join('\n');
    const footer = `\nتطبيق رِفْق | RIFQ — أذكار موثقة`;

    const fullShare = header + athkarText + footer;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `حصن المسلم — ${chapter.title}`,
          text: fullShare,
        });
      } catch {
        // ignore
      }
    } else {
      navigator.clipboard.writeText(fullShare);
      alert('تم نسخ جميع أذكار هذا الباب إلى الحافظة');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200" dir="rtl">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-white border border-[#E6E6F0] shadow-sm">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl text-[#25263A] hover:bg-[#F7F7FC] transition-colors"
            title="رجوع"
            aria-label="رجوع"
          >
            <ArrowRight className="w-5 h-5" />
          </button>

          {/* Real PNG Icon badge */}
          <div className="w-12 h-12 rounded-full bg-white border-2 border-[#5B5FEF] p-1 flex items-center justify-center shadow-xs shrink-0 overflow-hidden">
            <img
              src={`/assets/hisn_almuslim/icons/${chapter.iconName}`}
              alt={chapter.title}
              className="w-full h-full object-contain"
              onError={(e) => {
                // Fallback to default PNG if needed
                (e.target as HTMLImageElement).src = '/assets/hisn_almuslim/icons/default.png';
              }}
            />
          </div>

          <div>
            <h1 className="font-cairo font-bold text-lg sm:text-xl text-[#25263A] leading-tight">
              {chapter.title}
            </h1>
            <p className="font-cairo text-xs text-[#77798C] mt-0.5">
              {chapter.athkar.length} أذكار موثقة • {chapter.category}
            </p>
          </div>
        </div>

        {/* Chapter Header Actions: Favorite Chapter & Share Chapter */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onToggleChapterFavorite(chapter.id)}
            className="p-2 rounded-xl border border-[#E6E6F0] hover:bg-[#F7F7FC] transition-colors"
            title={isChapterFav ? 'إزالة الباب من المفضلة' : 'إضافة الباب للمفضلة'}
          >
            <Star
              className={`w-5 h-5 ${
                isChapterFav ? 'fill-amber-500 text-amber-500' : 'text-[#77798C]'
              }`}
            />
          </button>

          <button
            onClick={handleShareChapter}
            className="p-2 rounded-xl border border-[#E6E6F0] hover:bg-[#EEEEFF] text-[#4145C7] transition-colors"
            title="مشاركة كل أذكار الباب"
          >
            <Share2 className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Athkar Cards List */}
      <div className="space-y-4">
        {chapter.athkar.map((dhikr, idx) => {
          const isFav = favorites.includes(dhikr.id);
          const isCopied = copiedId === dhikr.id;

          return (
            <div
              key={dhikr.id}
              onClick={() => setSelectedDhikr(dhikr)}
              className="group relative p-5 sm:p-6 rounded-2xl bg-white border border-[#E6E6F0] shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer overflow-hidden"
            >
              {/* Top Row: Index number and Favorite toggle */}
              <div className="flex items-center justify-between mb-3.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-[#F7F7FC] border border-[#E6E6F0] flex items-center justify-center font-cairo font-bold text-xs text-[#25263A]">
                    {idx + 1}
                  </span>
                  {dhikr.repetition > 1 && (
                    <span className="px-2.5 py-0.5 rounded-full bg-[#EEEEFF] text-[#4145C7] border border-[#E6E6F0] font-cairo text-xs font-semibold">
                      التكرار: {dhikr.repetition} مرات
                    </span>
                  )}
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(dhikr.id);
                  }}
                  className="p-1.5 rounded-lg hover:bg-[#F7F7FC] transition-colors"
                  title="المفضلة"
                >
                  <Star
                    className={`w-5 h-5 ${
                      isFav ? 'fill-amber-500 text-amber-500' : 'text-[#77798C]'
                    }`}
                  />
                </button>
              </div>

              {/* Dhikr text in Amiri font */}
              <div className="font-amiri font-bold text-xl sm:text-2xl text-[#25263A] leading-loose text-center my-4">
                «{dhikr.text}»
              </div>

              {/* Source in Cairo font */}
              <div className="mt-3 pt-3 border-t border-[#E6E6F0] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-right">
                <p className="font-cairo text-xs text-[#77798C] line-clamp-1">
                  📖 المصدر: <span className="text-[#25263A] font-semibold">{dhikr.source}</span>
                </p>

                {dhikr.grade && (
                  <span className="text-[11px] font-cairo px-2 py-0.5 rounded-md bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/40 w-fit">
                    {dhikr.grade}
                  </span>
                )}
              </div>

              {/* Action Buttons: [📋 نسخ] [📤 مشاركة] [👁️ تفاصيل] */}
              <div className="mt-4 flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={(e) => handleCopySingle(dhikr, e)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#5B5FEF] text-white font-cairo font-bold text-xs shadow-xs hover:brightness-105 transition-transform active:scale-95"
                >
                  {isCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-white" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ</span>
                    </>
                  )}
                </button>

                <button
                  onClick={(e) => handleShareSingle(dhikr, e)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-[#E6E6F0] text-[#25263A] font-cairo font-bold text-xs shadow-xs hover:bg-[#F7F7FC] transition-transform active:scale-95"
                >
                  <Share2 className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>مشاركة</span>
                </button>

                <button
                  onClick={() => setSelectedDhikr(dhikr)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#F7F7FC] text-[#25263A] font-cairo font-bold text-xs hover:bg-[#EEEEFF] transition-transform active:scale-95"
                >
                  <Eye className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>التفاصيل</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Screen 3: Dhikr Detail Modal */}
      {selectedDhikr && (
        <HisnDhikrModal
          dhikr={selectedDhikr}
          chapterTitle={chapter.title}
          isFavorite={favorites.includes(selectedDhikr.id)}
          onToggleFavorite={onToggleFavorite}
          onClose={() => setSelectedDhikr(null)}
        />
      )}
    </div>
  );
};
