import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  Copy, 
  Check, 
  Share2, 
  Star, 
  Shuffle, 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  BookOpen, 
  Clock, 
  History,
  Info
} from 'lucide-react';
import { 
  MOMENT_DHIKR_DATABASE, 
  MomentDhikrItem, 
  MomentDhikrCategory 
} from '../../data/momentDhikrData';
import { 
  loadMomentFavorites, 
  toggleMomentFavorite, 
  loadNotificationLogs, 
  NotificationLogItem,
  markNotificationLogOpened
} from '../../utils/momentDhikrService';
import { DhikrShareModal } from '../DhikrShareModal';

interface MomentDhikrScreenProps {
  initialDhikrId?: string | null;
  onBack: () => void;
}

export const MomentDhikrScreen: React.FC<MomentDhikrScreenProps> = ({
  initialDhikrId,
  onBack,
}) => {
  // Find initial dhikr or fallback to first
  const [currentDhikr, setCurrentDhikr] = useState<MomentDhikrItem>(() => {
    if (initialDhikrId) {
      const match = MOMENT_DHIKR_DATABASE.find(d => d.id === initialDhikrId);
      if (match) return match;
    }
    return MOMENT_DHIKR_DATABASE[0];
  });

  const [copied, setCopied] = useState(false);
  const [favorites, setFavorites] = useState<string[]>(() => loadMomentFavorites());
  const [selectedCategory, setSelectedCategory] = useState<MomentDhikrCategory | 'all'>('all');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [logs, setLogs] = useState<NotificationLogItem[]>([]);

  useEffect(() => {
    if (initialDhikrId) {
      const match = MOMENT_DHIKR_DATABASE.find(d => d.id === initialDhikrId);
      if (match) {
        setCurrentDhikr(match);
        markNotificationLogOpened(match.id);
      }
    }
  }, [initialDhikrId]);

  useEffect(() => {
    setLogs(loadNotificationLogs());
  }, [showHistoryModal]);

  const isFavorite = favorites.includes(currentDhikr.id);

  const handleToggleFavorite = () => {
    toggleMomentFavorite(currentDhikr.id);
    setFavorites(loadMomentFavorites());
  };

  const handleCopy = () => {
    const formatted = `«${currentDhikr.text}»\n\n📖 المصدر: ${currentDhikr.source}${
      currentDhikr.virtue ? `\n✨ الفضل: ${currentDhikr.virtue}` : ''
    }\n\n[منقول من تطبيق «رِفْق | RIFQ» - رفيقك اليومي للأذكار والقرآن والسنة 🌿]`;
    navigator.clipboard.writeText(formatted);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const changeDhikr = (dhikr: MomentDhikrItem) => {
    setCurrentDhikr(dhikr);
  };

  // Filtered pool
  const filteredPool = MOMENT_DHIKR_DATABASE.filter(
    d => selectedCategory === 'all' || d.category === selectedCategory
  );

  const currentIndex = filteredPool.findIndex(d => d.id === currentDhikr.id);

  const handleNext = () => {
    if (filteredPool.length === 0) return;
    const nextIdx = (currentIndex + 1) % filteredPool.length;
    changeDhikr(filteredPool[nextIdx]);
  };

  const handlePrev = () => {
    if (filteredPool.length === 0) return;
    const prevIdx = (currentIndex - 1 + filteredPool.length) % filteredPool.length;
    changeDhikr(filteredPool[prevIdx]);
  };

  const handleRandom = () => {
    if (filteredPool.length <= 1) return;
    let nextIdx = Math.floor(Math.random() * filteredPool.length);
    if (nextIdx === currentIndex) {
      nextIdx = (nextIdx + 1) % filteredPool.length;
    }
    changeDhikr(filteredPool[nextIdx]);
  };

  return (
    <div className="min-h-screen bg-[#F7F7FC] pb-24 font-tajawal select-none" dir="rtl">
      
      {/* ─── Top Navigation Header ─── */}
      <div className="sticky top-0 z-30 bg-[#F7F7FC]/95 backdrop-blur-md border-b border-[#E6E6F0] px-4 py-3.5 shadow-2xs">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-2xl bg-white border border-[#E6E6F0] text-[#25263A] hover:bg-[#EEEEFF] active:scale-95 transition-all shadow-2xs cursor-pointer"
              title="العودة للرئيسية"
            >
              <ArrowRight className="w-5 h-5 text-[#4145C7]" />
            </button>
            <div>
              <h1 className="text-lg font-black text-[#25263A] flex items-center gap-1.5">
                <span>🌅</span>
                <span>ذكر اللحظة</span>
              </h1>
              <p className="text-[11px] font-bold text-[#4145C7]">
                نفحات روحانية متجددة 5 مرات يومياً
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Notification History Log Button */}
            <button
              onClick={() => setShowHistoryModal(true)}
              className="p-2 rounded-2xl bg-white border border-[#E6E6F0] text-[#4145C7] hover:bg-[#EEEEFF] active:scale-95 transition-all shadow-2xs cursor-pointer relative"
              title="سجل الإشعارات السابقة"
            >
              <History className="w-4 h-4 text-[#5B5FEF]" />
              {logs.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#5B5FEF] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                  {Math.min(logs.length, 9)}
                </span>
              )}
            </button>

            {/* Favorite Star */}
            <button
              onClick={handleToggleFavorite}
              className="p-2 rounded-2xl bg-white border border-[#E6E6F0] text-[#5B5FEF] hover:bg-[#EEEEFF] active:scale-95 transition-all shadow-2xs cursor-pointer"
              title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
            >
              <Star className={`w-4 h-4 ${isFavorite ? 'fill-[#72B7E8] text-[#5B5FEF]' : 'text-gray-400'}`} />
            </button>
          </div>

        </div>
      </div>

      {/* ─── Category Filter Chips ─── */}
      <div className="max-w-2xl mx-auto px-4 mt-3">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'morning', label: '🌅 الصباح' },
            { id: 'evening', label: '🌇 المساء' },
            { id: 'sleep', label: '🌙 النوم' },
            { id: 'general', label: '✨ متفرقة' },
            { id: 'quran', label: '📖 آيات' },
            { id: 'hadith_virtue', label: '📜 أحاديث' },
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id as MomentDhikrCategory | 'all');
                if (cat.id !== 'all') {
                  const firstOfCat = MOMENT_DHIKR_DATABASE.find(d => d.category === cat.id);
                  if (firstOfCat) changeDhikr(firstOfCat);
                }
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white shadow-2xs'
                  : 'bg-white text-[#25263A] border border-[#E6E6F0] hover:bg-[#EEEEFF]/60'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* ─── Main Dhikr Card (Strict User Specs) ─── */}
      <div className="max-w-xl mx-auto px-4 mt-4">
        <div 
          className="relative rounded-[20px] p-6 sm:p-8 border-2 border-[#5B5FEF] shadow-[0_10px_35px_rgba(201,168,76,0.18)] transition-all duration-300 animate-fade-in"
          style={{ backgroundColor: '#F7F7FC' }}
        >
          {/* Subtle Corner Arabesque Ornaments */}
          <div className="absolute top-3 right-3 text-[#5B5FEF]/40 text-sm select-none">❖</div>
          <div className="absolute top-3 left-3 text-[#5B5FEF]/40 text-sm select-none">❖</div>
          <div className="absolute bottom-3 right-3 text-[#5B5FEF]/40 text-sm select-none">❖</div>
          <div className="absolute bottom-3 left-3 text-[#5B5FEF]/40 text-sm select-none">❖</div>

          {/* Header Row: Title & Badge */}
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-[#E6E6F0] mb-5">
            <div className="flex items-center gap-2">
              <span className="text-xl">🌅</span>
              <h2 className="text-sm font-extrabold text-[#4145C7] tracking-wide">
                {currentDhikr.title}
              </h2>
            </div>
            
            <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-white/80 border border-[#E6E6F0] text-[#25263A]">
              {currentDhikr.categoryAr}
            </span>
          </div>

          {/* Central Divider */}
          <div className="flex items-center justify-center gap-2 my-2 opacity-60">
            <div className="h-[1px] w-12 bg-gradient-to-r from-transparent to-[#72B7E8]" />
            <span className="text-[#5B5FEF] text-xs">﷽</span>
            <div className="h-[1px] w-12 bg-gradient-to-l from-transparent to-[#72B7E8]" />
          </div>

          {/* The Dhikr Text: Amiri font 26px, dark brown #25263A */}
          <div className="my-6 text-center">
            <p 
              className="text-[#25263A] leading-loose text-center font-amiri font-bold selection:bg-[#EEEEFF]"
              style={{ 
                fontFamily: 'Amiri, Tajawal, serif',
                fontSize: '26px',
                lineHeight: '1.9',
              }}
            >
              {currentDhikr.text}
            </p>

            {/* Repetition Badge if applicable */}
            {currentDhikr.repetition && currentDhikr.repetition > 1 && (
              <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EEEEFF] border border-[#5B5FEF]/25 text-[#4145C7] text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>يُكرر: {currentDhikr.repetition} مرات</span>
              </div>
            )}
          </div>

          {/* Divider */}
          <div className="flex items-center justify-center gap-2 my-2 opacity-60">
            <div className="h-[1px] w-16 bg-gradient-to-r from-transparent to-[#72B7E8]" />
            <div className="w-1.5 h-1.5 rotate-45 bg-[#5B5FEF]" />
            <div className="h-[1px] w-16 bg-gradient-to-l from-transparent to-[#72B7E8]" />
          </div>

          {/* Source in Cairo/Tajawal 14px gray */}
          <div className="mt-4 text-center">
            <p className="text-xs sm:text-[13px] font-bold text-[#77798C] flex items-center justify-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-[#5B5FEF]" />
              <span>المصدر:</span>
              <span className="text-[#25263A] font-semibold">{currentDhikr.source}</span>
            </p>

            {/* Virtue details */}
            {currentDhikr.virtue && (
              <p className="mt-2 text-[12px] text-[#25263A]/90 leading-relaxed bg-white/60 p-2.5 rounded-xl border border-[#E6E6F0] inline-block text-center max-w-md mx-auto">
                <span className="font-bold text-[#4145C7]">✨ الفضل: </span>
                <span>{currentDhikr.virtue}</span>
              </p>
            )}
          </div>

          {/* ─── Golden Action Buttons: [📋 نسخ] [📤 مشاركة] ─── */}
          <div className="mt-6 pt-4 border-t border-[#E6E6F0] flex flex-wrap items-center justify-between gap-3">
            
            <div className="flex items-center gap-2">
              {/* Golden Copy Button */}
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] hover:from-[#B38F3A] hover:to-[#4145C7] text-white font-bold text-xs shadow-2xs active:scale-95 transition-all cursor-pointer"
                title="نسخ الذكر مع التوثيق وبصمة التطبيق"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-white" />
                    <span>تم النسخ بنجاح! ✓</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-white" />
                    <span>📋 نسخ</span>
                  </>
                )}
              </button>

              {/* Golden Share Button */}
              <button
                onClick={() => setIsShareModalOpen(true)}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#4145C7] to-[#25263A] hover:from-[#4145C7] hover:to-[#4145C7] text-white font-bold text-xs shadow-2xs active:scale-95 transition-all cursor-pointer"
                title="مشاركة الذكر كصورة مصممة أو نص منسق"
              >
                <Share2 className="w-4 h-4 text-white" />
                <span>📤 مشاركة</span>
              </button>
            </div>
          </div>
        </div>

        {/* ─── Bottom Navigation Carousel Controls ─── */}
        <div className="mt-4 flex items-center justify-between gap-2 px-2">
          
          <button
            onClick={handlePrev}
            className="flex items-center gap-1 px-3.5 py-2 rounded-xl bg-white border border-[#E6E6F0] text-[#25263A] hover:bg-[#EEEEFF] text-xs font-bold shadow-2xs active:scale-95 transition-all cursor-pointer"
            title="الذكر السابق"
          >
            <ChevronRight className="w-4 h-4 text-[#4145C7]" />
            <span>السابق</span>
          </button>

          {/* Random Dhikr Button */}
          <button
            onClick={handleRandom}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white border border-[#E6E6F0] text-[#4145C7] hover:bg-[#EEEEFF] text-xs font-extrabold shadow-2xs active:scale-95 transition-all cursor-pointer"
            title="اختيار ذكر عشوائي مبارك"
          >
            <Shuffle className="w-3.5 h-3.5 text-[#5B5FEF]" />
            <span>ذكر عشوائي</span>
          </button>

          <button
            onClick={handleNext}
            className="flex items-center gap-1 px-3.5 py-2 rounded-xl bg-white border border-[#E6E6F0] text-[#25263A] hover:bg-[#EEEEFF] text-xs font-bold shadow-2xs active:scale-95 transition-all cursor-pointer"
            title="الذكر التالي"
          >
            <span>التالي</span>
            <ChevronLeft className="w-4 h-4 text-[#4145C7]" />
          </button>

        </div>

        {/* Informative Tip Box */}
        <div className="mt-6 bg-[#EEEEFF]/80 rounded-2xl p-4 border border-[#E6E6F0] text-xs text-[#25263A] flex items-start gap-2.5">
          <Info className="w-4 h-4 text-[#5B5FEF] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold text-[#4145C7]">نظام إشعارات الذكر التلقائي:</p>
            <p className="text-[11px] text-[#77798C] leading-relaxed">
              يقوم التطبيق بإرسال 5 إشعارات حقيقية يومياً في مواعيدها المحددة (الفجر، الضحى، الظهر، العصر، وقبل النوم) مع تنويع الأذكار المباركة.
            </p>
          </div>
        </div>

      </div>

      {/* ─── Share Modal Integration (Canvas Image + Formatted Text) ─── */}
      <DhikrShareModal
        dhikr={currentDhikr}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        wardTitle={`🌅 ذكر اللحظة • ${currentDhikr.categoryAr}`}
      />

      {/* ─── History / Notifications Log Modal ─── */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-fade-in" dir="rtl">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 shadow-2xl border border-[#E6E6F0] max-h-[80vh] flex flex-col">
            
            <div className="flex items-center justify-between pb-3 border-b border-[#E6E6F0]">
              <div className="flex items-center gap-2 text-[#25263A]">
                <Clock className="w-5 h-5 text-[#5B5FEF]" />
                <h3 className="font-extrabold text-sm sm:text-base">سجل إشعارات الذكر السابقة</h3>
              </div>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="p-1.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-[#77798C] cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto mt-3 space-y-2.5 pr-1">
              {logs.length === 0 ? (
                <div className="text-center py-8 text-gray-400 text-xs">
                  لم يتم تسجيل إشعارات سابقة حتى الآن. ستظهر هنا فور إرسالها.
                </div>
              ) : (
                logs.map(log => (
                  <div
                    key={log.id}
                    onClick={() => {
                      const match = MOMENT_DHIKR_DATABASE.find(d => d.id === log.dhikrId);
                      if (match) {
                        changeDhikr(match);
                        setShowHistoryModal(false);
                      }
                    }}
                    className="p-3 rounded-2xl bg-[#EEEEFF]/50 hover:bg-[#EEEEFF]/60 border border-[#E6E6F0] cursor-pointer transition-all"
                  >
                    <div className="flex items-center justify-between text-[11px] text-[#4145C7] font-bold mb-1">
                      <span>{log.slotLabel}</span>
                      <span className="text-gray-400 text-[10px]">
                        {new Date(log.sentAt).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-xs font-amiri text-[#25263A] line-clamp-2 leading-relaxed">
                      {log.dhikrText}
                    </p>
                    <p className="text-[10px] text-gray-400 mt-1">📖 {log.source}</p>
                  </div>
                ))
              )}
            </div>

            <div className="mt-3 pt-3 border-t border-[#E6E6F0] text-center">
              <button
                onClick={() => setShowHistoryModal(false)}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-bold text-xs cursor-pointer shadow-2xs"
              >
                إغلاق
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
