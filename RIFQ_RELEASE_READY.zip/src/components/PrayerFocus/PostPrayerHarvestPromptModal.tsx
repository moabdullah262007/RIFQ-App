import React from 'react';
import { Check, Clock } from 'lucide-react';
import {
  PendingPrayerHarvestPrompt,
  savePrayerTrackerStatus,
  savePendingHarvestPrompt,
  dismissCurrentFocusWindow,
} from '../../utils/prayerFocusService';
import { triggerHaptic } from '../../utils/prayerAudio';

interface PostPrayerHarvestPromptModalProps {
  prompt: PendingPrayerHarvestPrompt | null;
  onClose: () => void;
  onPrayerLogged?: (prayerNameAr: string) => void;
}

/**
 * Requirement 12: الدمج مع حصاد العبادات
 * When Prayer Focus Mode ends, displays:
 * «هل أديت صلاة الظهر؟»
 * [ نعم، صليت ]
 * [ لاحقًا ]
 * Never logs the prayer automatically—only logs when the user clicks «نعم، صليت».
 */
export const PostPrayerHarvestPromptModal: React.FC<PostPrayerHarvestPromptModalProps> = ({
  prompt,
  onClose,
  onPrayerLogged,
}) => {
  if (!prompt) return null;

  const handleConfirmPrayed = () => {
    triggerHaptic(35);
    // Record in the primary Prayer Tracker & Worship Harvest storage (`rafiq_prayer_tracker_history`)
    savePrayerTrackerStatus(prompt.dateStr, prompt.prayerKey, 'on_time');
    dismissCurrentFocusWindow(prompt.dateStr, prompt.prayerKey);
    savePendingHarvestPrompt(null);
    if (onPrayerLogged) {
      onPrayerLogged(prompt.prayerNameAr);
    }
    onClose();
  };

  const handleLater = () => {
    savePendingHarvestPrompt(null);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in font-tajawal"
      dir="rtl"
      onClick={handleLater}
    >
      <div
        className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-[#E6E6F0] text-center space-y-5 relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-16 h-16 rounded-full bg-[#EEEEFF] border border-[#E6E6F0] flex items-center justify-center mx-auto text-3xl">
          🕌
        </div>

        <div className="space-y-1.5">
          <h3 className="text-xl font-black text-[#25263A]">
            هل أديت صلاة {prompt.prayerNameAr}؟
          </h3>
          <p className="text-xs text-[#77798C] leading-relaxed">
            انتهى وضع الصلاة والتركيز. بتأكيدك تُسجَّل الصلاة في سجل حصاد العبادات وتحدي رحلتك اليومية.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            type="button"
            onClick={handleConfirmPrayed}
            className="py-3 px-4 rounded-2xl bg-[#4CAF82] hover:brightness-95 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>نعم، صليت</span>
          </button>

          <button
            type="button"
            onClick={handleLater}
            className="py-3 px-4 rounded-2xl bg-[#F7F7FC] hover:bg-gray-100 text-[#77798C] hover:text-[#25263A] border border-[#E6E6F0] font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Clock className="w-4 h-4" />
            <span>لاحقًا</span>
          </button>
        </div>
      </div>
    </div>
  );
};
