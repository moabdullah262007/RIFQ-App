import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Camera,
  X,
  Lock,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sparkles,
  Clock,
  ShieldCheck,
  SwitchCamera,
  Info,
  Smartphone,
  Eye,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  InAppPrayerModeState,
  getInAppPrayerModeState,
  getMihrabVerificationTiming,
  completeMihrabVerificationSuccess,
  stopInAppPrayerMode,
} from '../../utils/prayerFocusService';
import {
  CameraVerificationNativeBridge,
  VerificationSession,
} from '../../utils/cameraVerificationNativeBridge';
import {
  MihrabDetectionProcessor,
  MihrabDetectionResult,
  MIHRAB_CONFIDENCE_THRESHOLD,
} from '../../utils/mihrabDetectionProcessor';
import { playIslamicChime, triggerHaptic } from '../../utils/prayerAudio';
import { Capacitor } from '@capacitor/core';

interface MihrabVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (response: MihrabDetectionResult) => void;
}

export const MihrabVerificationModal: React.FC<MihrabVerificationModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [state, setState] = useState<InAppPrayerModeState>(getInAppPrayerModeState);
  const [nowMs, setNowMs] = useState<number>(Date.now());
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraFacing, setCameraFacing] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [verificationResult, setVerificationResult] = useState<MihrabDetectionResult | null>(null);
  const [activeSession, setActiveSession] = useState<VerificationSession | null>(null);
  
  // Developer override / fast-forward for instant testing of the 20-min rule
  const [devSimulate20MinPassed, setDevSimulate20MinPassed] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Sync state
  useEffect(() => {
    if (!isOpen) return;
    const handleSync = () => {
      setState(getInAppPrayerModeState());
    };
    window.addEventListener('rifq-in-app-prayer-mode-changed', handleSync);
    window.addEventListener('storage', handleSync);
    return () => {
      window.removeEventListener('rifq-in-app-prayer-mode-changed', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, [isOpen]);

  // Live second ticker
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  // Compute timing rules: 20 min lock & 45 min deadline
  const timing = React.useMemo(() => {
    const effectiveNow = devSimulate20MinPassed
      ? (state.prayerStartTimeMs || nowMs) + 21 * 60 * 1000
      : nowMs;
    return getMihrabVerificationTiming(state, effectiveNow);
  }, [state, nowMs, devSimulate20MinPassed]);

  // Stop camera stream safely
  const stopCameraStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  }, []);

  // Clean up camera on unmount or close
  useEffect(() => {
    if (!isOpen) {
      stopCameraStream();
      setCapturedImage(null);
      setVerificationResult(null);
      setIsAnalyzing(false);
      setActiveSession(null);
    }
  }, [isOpen, stopCameraStream]);

  // Start WebRTC camera stream (for in-browser live capture)
  const startCameraStream = useCallback(async () => {
    stopCameraStream();
    setCameraError(null);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError('المتصفح أو البيئة الحالية لا تدعم تشغيل الكاميرا المباشرة.');
      return;
    }

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: cameraFacing },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setIsCameraActive(true);

      // Create new fresh SESSION_ID for this capture window
      const session = CameraVerificationNativeBridge.createVerificationSession(state.prayerKey);
      setActiveSession(session);
    } catch (err: any) {
      console.warn('Camera access issue:', err);
      setCameraError(
        'تعذر تشغيل الكاميرا المباشرة. يرجى السماح بصلاحية الكاميرا الحية لمنع اختيار الصور القديمة.'
      );
    }
  }, [cameraFacing, state.prayerKey, stopCameraStream]);

  // Switch between back & front cameras
  const handleToggleCameraFacing = () => {
    triggerHaptic(20);
    setCameraFacing((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Re-start camera when facing changes if it was active
  useEffect(() => {
    if (isOpen && timing.isAvailable && !capturedImage && !verificationResult?.isMosqueMihrab) {
      startCameraStream();
    }
    return () => {
      stopCameraStream();
    };
  }, [cameraFacing, isOpen, timing.isAvailable, capturedImage, verificationResult]);

  // Capture frame from live WebRTC stream with EXIF & Session verification
  const handleCaptureWebStream = async () => {
    if (!videoRef.current) return;
    triggerHaptic(40);

    const captureResult = CameraVerificationNativeBridge.captureFromLiveWebStream(
      videoRef.current,
      state.prayerKey
    );

    if (!captureResult.success) {
      setCameraError(captureResult.error || 'فشل فحص EXIF للجلسة الملتقطة.');
      return;
    }

    setCapturedImage(captureResult.base64Data);
    stopCameraStream();
    await performVisionVerification(captureResult.base64Data, captureResult.sessionId);
  };

  // Native Capacitor Live Camera Intent Capture (strictly prohibits gallery)
  const handleNativeCameraIntentCapture = async () => {
    triggerHaptic(40);
    stopCameraStream();

    const captureResult = await CameraVerificationNativeBridge.captureLiveWithNativeIntent(
      state.prayerKey
    );

    if (!captureResult.success) {
      setCameraError(captureResult.error || 'تعذر تشغيل الكاميرا بنمط Native Intent.');
      startCameraStream();
      return;
    }

    setCapturedImage(captureResult.base64Data);
    await performVisionVerification(captureResult.base64Data, captureResult.sessionId);
  };

  // Perform AI Vision verification via Gemini Vision API with 0.85 threshold
  const performVisionVerification = async (base64Img: string, sessionId: string) => {
    setIsAnalyzing(true);
    setVerificationResult(null);

    const result = await MihrabDetectionProcessor.processVerification(
      base64Img,
      sessionId,
      state.prayerKey,
      state.prayerNameAr
    );

    setIsAnalyzing(false);
    setVerificationResult(result);

    if (result.isMosqueMihrab && result.passedThreshold) {
      triggerHaptic([60, 60, 100]);
      playIslamicChime();

      try {
        confetti({
          particleCount: 85,
          spread: 75,
          origin: { y: 0.6 },
          colors: ['#4CAF82', '#E8B84A', '#5B5FEF', '#ffffff'],
        });
      } catch {
        // ignore
      }

      completeMihrabVerificationSuccess({
        reasonAr: result.reasonAr,
        confidence: result.confidence,
        detectedFeatures: result.detectedFeatures,
      });

      if (onSuccess) {
        onSuccess(result);
      }
    } else {
      triggerHaptic([50, 80]);
    }
  };

  // Retry verification
  const handleRetry = () => {
    triggerHaptic(25);
    setCapturedImage(null);
    setVerificationResult(null);
    setCameraError(null);
    startCameraStream();
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#070815]/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-fade-in font-tajawal select-none"
      dir="rtl"
    >
      <div className="bg-gradient-to-b from-[#181938] via-[#14152D] to-[#0F1023] rounded-3xl w-full max-w-xl max-h-[94vh] flex flex-col shadow-2xl border border-amber-400/40 overflow-hidden text-white relative">
        {/* Golden Arch accent bar */}
        <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-[#E8B84A] via-[#4CAF82] to-[#E8B84A]" />

        {/* ── HEADER ── */}
        <div className="p-4 sm:p-5 pb-3 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-2xl shrink-0 shadow-inner">
              🕌
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-cairo font-black text-base sm:text-lg text-amber-200">
                  نظام التحقق من المحراب الذكي
                </h3>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                  صلاة {state.prayerNameAr}
                </span>
              </div>
              <p className="text-xs text-indigo-200 mt-0.5 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>الرؤية الحاسوبية (Gemini Vision) • فحص EXIF و Native Intent الحصري</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-indigo-200 hover:text-white transition-colors cursor-pointer"
            title="إغلاق النافذة"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* ── TIMING STATUS BANNER ── */}
        <div
          className={`px-4 py-2.5 border-b text-xs flex items-center justify-between flex-wrap gap-2 ${
            timing.isLocked
              ? 'bg-amber-950/40 border-amber-500/30 text-amber-200'
              : timing.isAvailable
              ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
              : 'bg-red-950/40 border-red-500/30 text-red-200'
          }`}
        >
          <div className="flex items-center gap-2 font-bold">
            {timing.isLocked ? (
              <>
                <Lock className="w-4 h-4 text-amber-400" />
                <span>التحقق بالمحراب مغلق • يفتح بعد مضي 20 دقيقة من الأذان</span>
              </>
            ) : timing.isAvailable ? (
              <>
                <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
                <span>التصوير متاح الآن • ينتهي وضع الصلاة تلقائياً عند الدقيقة 45</span>
              </>
            ) : (
              <>
                <Clock className="w-4 h-4 text-red-400" />
                <span>انتهى وقت الصلاة والتركيز (مرور 45 دقيقة)</span>
              </>
            )}
          </div>

          <div className="text-[11px] font-mono font-black flex items-center gap-1.5 bg-black/30 px-2.5 py-1 rounded-lg">
            <Clock className="w-3.5 h-3.5" />
            {timing.isLocked && (
              <span>يفتح خلال: {timing.lockedCountdownFormatted}</span>
            )}
            {timing.isAvailable && (
              <span>المتبقي للإغلاق: {timing.deadlineCountdownFormatted}</span>
            )}
            {timing.isExpired && <span>انتهى الوقت</span>}
          </div>
        </div>

        {/* ── SECURITY CONSTRAINTS BADGES ── */}
        {timing.isAvailable && (
          <div className="px-4 py-1.5 bg-white/5 border-b border-white/5 flex items-center justify-between text-[10px] text-gray-300 flex-wrap gap-1">
            <div className="flex items-center gap-2">
              <span className="text-emerald-400 font-bold">🔒 منع المعرض مفعّل</span>
              <span>•</span>
              <span className="text-amber-300 font-bold">🎯 حد الثقة: 85%</span>
            </div>
            {activeSession && (
              <span className="font-mono text-[9px] text-indigo-300 bg-white/5 px-2 py-0.5 rounded">
                SESSION: {activeSession.sessionId.slice(-10)}
              </span>
            )}
          </div>
        )}

        {/* ── BODY CONTENT ── */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* CASE 1: LOCKED (Before 20 Minutes from Prayer Start) */}
          {timing.isLocked && (
            <div className="space-y-4 animate-fade-in text-center py-2">
              <div className="w-20 h-20 rounded-3xl bg-amber-400/15 border-2 border-amber-400/40 text-amber-300 flex items-center justify-center mx-auto text-3xl shadow-lg relative">
                <Lock className="w-9 h-9" />
                <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-indigo-900 border border-amber-400 text-[10px] font-black flex items-center justify-center text-amber-200">
                  20د
                </span>
              </div>

              <div className="space-y-1.5 max-w-md mx-auto">
                <h4 className="text-lg font-black text-amber-200">
                  التصوير غير متاح قبل انقضاء 20 دقيقة كاملة
                </h4>
                <p className="text-xs text-indigo-200 leading-relaxed">
                  مضى من وقت الأذان <span className="font-bold text-amber-300">{timing.elapsedMinutesSinceAdhan} دقيقة</span>. لا يمكن فتح الكاميرا أو التحقق بالمحراب قبل مرور 20 دقيقة لضمان الخشوع والتركيز في الصلاة.
                </p>
              </div>

              {/* Progress to Unlock */}
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 max-w-sm mx-auto space-y-2 text-right">
                <div className="flex items-center justify-between text-xs font-bold text-indigo-200">
                  <span>التقدم نحو فتح التحقق:</span>
                  <span className="text-amber-300 font-mono">
                    {timing.progressPercentToUnlock}% ({timing.lockedCountdownFormatted} متبقية)
                  </span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-1000 rounded-full"
                    style={{ width: `${timing.progressPercentToUnlock}%` }}
                  />
                </div>
              </div>

              {/* Spiritual & Fiqh Wisdom Card */}
              <div className="p-4 rounded-2xl bg-indigo-950/50 border border-indigo-500/30 text-xs text-indigo-200 text-right leading-relaxed space-y-2 max-w-md mx-auto">
                <div className="flex items-center gap-1.5 font-bold text-amber-300">
                  <Info className="w-4 h-4" />
                  <span>الحكمة الشرعية والتقنية لقاعدة الـ 20 دقيقة:</span>
                </div>
                <p className="text-[11px] text-gray-300">
                  • تهدف صلاة الجماعة إلى الخشوع التام لله دون استعجال أو تصوير أثناء أداء الركعات.
                  <br />
                  • إتاحة وقت كافٍ لسنة ما قبل الصلاة، وإدراك الركعات مع الإمام، وأذكار ما بعد السلام.
                  <br />
                  • فور انتهاء الـ 20 دقيقة، سيُفتح زر الكاميرا تلقائياً لتتمكن من تصوير محراب المسجد وإنهاء وضع الحظر.
                </p>
              </div>

              {/* Developer Fast-Forward Simulator (strictly for testing convenience) */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic(20);
                    setDevSimulate20MinPassed(true);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/40 text-[11px] font-bold transition-all cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>محاكاة مرور 20 دقيقة للاختبار الفوري للكاميرا والذكاء الاصطناعي ⚡</span>
                </button>
              </div>
            </div>
          )}

          {/* CASE 2: AVAILABLE (Between 20 and 45 Minutes from Prayer Start) */}
          {timing.isAvailable && !capturedImage && (
            <div className="space-y-4 animate-fade-in">
              {/* Viewfinder Card */}
              <div className="relative rounded-3xl overflow-hidden bg-black aspect-4/3 sm:aspect-16/10 border-2 border-amber-400/50 flex items-center justify-center shadow-xl">
                {isCameraActive ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform scale-x-1"
                  />
                ) : (
                  <div className="p-6 text-center space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center mx-auto text-amber-300">
                      <Camera className="w-7 h-7" />
                    </div>
                    <p className="text-xs text-gray-300 max-w-xs">
                      {cameraError || 'جارٍ تشغيل الكاميرا المباشرة الحصرية...'}
                    </p>
                    <button
                      type="button"
                      onClick={startCameraStream}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer inline-flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>إعادة محاولة فتح الكاميرا</span>
                    </button>
                  </div>
                )}

                {/* SVG Islamic Arch Reticle Overlay (إطار المحراب التوجيهي) */}
                {isCameraActive && (
                  <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-between p-4">
                    {/* Arch Header guide */}
                    <div className="bg-black/60 backdrop-blur-xs px-3.5 py-1.5 rounded-full border border-amber-400/40 text-[11px] text-amber-200 font-bold flex items-center gap-1.5 shadow-sm">
                      <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                      <span>وجّه الكاميرا نحو محراب المسجد أو تجويف القبلة</span>
                    </div>

                    {/* Islamic Pointed Arch Visual Guide */}
                    <div className="w-56 h-56 sm:w-64 sm:h-64 border-2 border-dashed border-amber-300/70 rounded-t-full relative flex items-center justify-center shadow-inner">
                      <div className="absolute top-3 text-[10px] text-amber-200 bg-black/50 px-2 py-0.5 rounded-full">
                        محراب المسجد
                      </div>
                      <div className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                    </div>

                    {/* Footer Guide text */}
                    <div className="bg-black/60 backdrop-blur-xs px-3 py-1 rounded-xl text-[10px] text-gray-300">
                      ممنوع اختيار صور من المعرض • الكاميرا الحية فقط
                    </div>
                  </div>
                )}

                {/* Flip camera button */}
                {isCameraActive && (
                  <button
                    type="button"
                    onClick={handleToggleCameraFacing}
                    className="absolute top-3 left-3 p-2.5 rounded-xl bg-black/60 hover:bg-black/80 text-white border border-white/20 transition-all cursor-pointer"
                    title="تبديل الكاميرا (أمامية / خلفية)"
                  >
                    <SwitchCamera className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Shutter Action Controls */}
              <div className="space-y-3">
                <div className="flex items-center justify-center gap-3">
                  {/* Big Primary Shutter Button for WebRTC Live Stream */}
                  <button
                    type="button"
                    onClick={handleCaptureWebStream}
                    disabled={!isCameraActive}
                    className={`px-8 py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-xl transition-all cursor-pointer ${
                      isCameraActive
                        ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-500 hover:brightness-110 active:scale-95 text-slate-900 border-2 border-amber-300'
                        : 'bg-white/10 text-gray-400 cursor-not-allowed border border-white/10'
                    }`}
                  >
                    <Camera className="w-5 h-5" />
                    <span>التقاط صورة المحراب مباشرة 📷</span>
                  </button>

                  {/* Native Capacitor Camera Intent Button */}
                  {Capacitor.isNativePlatform() && (
                    <button
                      type="button"
                      onClick={handleNativeCameraIntentCapture}
                      className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/15 text-indigo-200 border border-white/15 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold"
                      title="فتح كاميرا النظام الأصلية (Native Intent)"
                    >
                      <Smartphone className="w-4 h-4 text-emerald-400" />
                      <span>كاميرا النظام</span>
                    </button>
                  )}
                </div>

                <div className="bg-amber-950/30 border border-amber-400/20 rounded-xl p-2.5 text-center text-[11px] text-amber-200/90 leading-relaxed max-w-md mx-auto">
                  🛡️ <strong>فحص الأمان:</strong> تُرفض أي صورة تحتوي على شاشات أو سجاد منزلي أو مصابيح عادية. يُشترط وجود بناء المحراب المعماري بنسبة تطابق لا تقل عن 85%.
                </div>
              </div>
            </div>
          )}

          {/* CASE 3: ANALYZING STATE */}
          {isAnalyzing && (
            <div className="space-y-5 animate-fade-in text-center py-6">
              {capturedImage && (
                <div className="relative w-48 h-48 mx-auto rounded-2xl overflow-hidden border-2 border-amber-400/60 shadow-xl">
                  <img
                    src={capturedImage}
                    alt="Captured Mihrab"
                    className="w-full h-full object-cover"
                  />
                  {/* Scanning Laser Beam Effect */}
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent via-amber-400/30 to-transparent h-6 w-full animate-bounce" />
                </div>
              )}

              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-400/20 text-amber-200 font-bold text-xs border border-amber-400/40 animate-pulse">
                  <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
                  <span>معالجة الرؤية الحاسوبية والتحقق المعماري (Gemini Vision)...</span>
                </div>
                <h4 className="text-base font-black text-white">
                  فحص تجويف القبلة، الأقواس الإسلامية، والتأكد من خلو العناصر المحظورة
                </h4>
                <p className="text-xs text-indigo-200 max-w-sm mx-auto leading-relaxed">
                  الحد الأدنى لثقة المحراب: 85% • فحص EXIF للجلسة الملتقطة • رفض الشاشات والغرف المنزلية.
                </p>
              </div>
            </div>
          )}

          {/* CASE 4: VERIFICATION RESULT - SUCCESS */}
          {verificationResult && verificationResult.isMosqueMihrab && verificationResult.passedThreshold && (
            <div className="space-y-5 animate-fade-in text-center py-4">
              <div className="w-20 h-20 rounded-3xl bg-emerald-500/20 border-2 border-emerald-400 text-emerald-300 flex items-center justify-center mx-auto text-4xl shadow-xl shadow-emerald-950/50">
                <CheckCircle2 className="w-12 h-12" />
              </div>

              <div className="space-y-1.5 max-w-md mx-auto">
                <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/25 text-emerald-300 text-xs font-black border border-emerald-400/40">
                  تم التحقق بنجاح • صلاة في المسجد (جماعة) 🕌
                </span>
                <h4 className="text-xl font-black text-amber-200">
                  تأكيد أداء صلاة {state.prayerNameAr} في جماعة المسجد
                </h4>
                <p className="text-xs text-gray-200 leading-relaxed">
                  {verificationResult.reasonAr}
                </p>
              </div>

              {/* Confidence and Detected Features */}
              <div className="p-4 rounded-2xl bg-white/5 border border-emerald-500/30 text-right space-y-2.5 max-w-md mx-auto text-xs">
                <div className="flex items-center justify-between font-bold">
                  <span className="text-indigo-200">درجة الثقة المعمارية:</span>
                  <span className="text-emerald-300 font-mono font-black text-sm">
                    {Math.round(verificationResult.confidence * 100)}% (مقبول &gt;= 85%)
                  </span>
                </div>

                {verificationResult.detectedFeatures && verificationResult.detectedFeatures.length > 0 && (
                  <div className="space-y-1.5">
                    <span className="text-amber-300 font-bold block text-[11px]">
                      المعالم المرصودة في المحراب:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {verificationResult.detectedFeatures.map((feat, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 rounded-lg bg-emerald-900/40 border border-emerald-400/30 text-emerald-200 text-[10px] font-bold"
                        >
                          ✓ {feat}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-2 border-t border-white/10 text-[11px] text-gray-300">
                  ✨ تم تسجيل الصلاة كـ <strong className="text-emerald-300 font-black">صلاة في المسجد (جماعة)</strong> في حصادك اليومي، ورُفع وضع حظر التطبيقات فوراً.
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full max-w-xs mx-auto py-3 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 text-white font-black text-sm shadow-lg hover:brightness-110 active:scale-95 transition-all cursor-pointer"
              >
                الحمد لله، إتمام والعودة للرئيسية
              </button>
            </div>
          )}

          {/* CASE 5: VERIFICATION RESULT - FAILED (NOT A MOSQUE MIHRAB OR PROHIBITED ELEMENTS) */}
          {verificationResult && (!verificationResult.isMosqueMihrab || !verificationResult.passedThreshold) && !isAnalyzing && (
            <div className="space-y-4 animate-fade-in text-center py-4">
              <div className="w-16 h-16 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-300 flex items-center justify-center mx-auto text-3xl">
                <AlertCircle className="w-8 h-8" />
              </div>

              <div className="space-y-1 max-w-md mx-auto">
                <h4 className="text-lg font-black text-red-200">
                  لم يتم قبول التحقق بالمحراب
                </h4>
                <p className="text-xs text-gray-300 leading-relaxed px-2">
                  {verificationResult.reasonAr || 'الصورة لا تظهر معالم محراب المسجد وتجويف القبلة.'}
                </p>
              </div>

              {/* Show Prohibited Elements if detected */}
              {verificationResult.prohibitedElementsDetected && verificationResult.prohibitedElementsDetected.length > 0 && (
                <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/40 text-right text-xs max-w-md mx-auto space-y-1.5">
                  <span className="font-bold text-red-300 block">عناصر محظورة تم رصدها:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {verificationResult.prohibitedElementsDetected.map((item, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-red-900/40 border border-red-400/40 text-red-200 text-[10px] font-bold"
                      >
                        ✕ {item}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs text-right leading-relaxed max-w-md mx-auto space-y-1">
                <span className="font-bold block">شروط قبول المحراب:</span>
                <p className="text-[11px] text-gray-300">
                  • قف داخل مصلى المسجد ووجّه الكاميرا مباشرة نحو تجويف المحراب في جدار القبلة.
                  <br />
                  • لا يُقبل تصوير السجاد المنزلي المنفصل، ولا المصابيح العادية، ولا الشاشات الرقمية.
                  <br />
                  • يُشترط أن تكون نسبة التطابق المعماري 85% فما فوق.
                </p>
              </div>

              <div className="flex items-center justify-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleRetry}
                  className="py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:brightness-110 active:scale-95 text-slate-900 font-black text-xs flex items-center gap-2 shadow-md cursor-pointer transition-all"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>إعادة المحاولة والتصوير 🔄</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="py-3 px-4 rounded-2xl bg-white/10 hover:bg-white/15 text-indigo-200 text-xs font-bold border border-white/10 cursor-pointer"
                >
                  <span>إغلاق مؤقتاً</span>
                </button>
              </div>
            </div>
          )}

          {/* CASE 6: EXPIRED (> 45 Minutes) */}
          {timing.isExpired && (
            <div className="space-y-4 animate-fade-in text-center py-6">
              <div className="w-16 h-16 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 flex items-center justify-center mx-auto text-3xl">
                <Clock className="w-8 h-8" />
              </div>

              <div className="space-y-1 max-w-md mx-auto">
                <h4 className="text-lg font-black text-indigo-200">
                  انتهى وقت وضع الصلاة والتركيز تلقائياً
                </h4>
                <p className="text-xs text-gray-300 leading-relaxed">
                  انقضت 45 دقيقة من وقت أذان {state.prayerNameAr}. انتهى قفل التطبيقات تلقائياً وفق القواعد المعتمدة.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  stopInAppPrayerMode(false);
                  onClose();
                }}
                className="py-2.5 px-6 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs cursor-pointer"
              >
                حسناً، تم
              </button>
            </div>
          )}
        </div>

        {/* ── FOOTER ── */}
        <div className="p-3 sm:p-4 bg-white/5 border-t border-white/10 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-indigo-300 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>نظام رِفْق المعتمد للتحقق من أداء الفريضة</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-gray-300 hover:text-white transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
