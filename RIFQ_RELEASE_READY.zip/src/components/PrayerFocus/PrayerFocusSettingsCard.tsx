import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Lock,
  Check,
  Clock,
  ShieldCheck,
  ShieldAlert,
  MapPin,
  ExternalLink,
  RefreshCw,
  X,
  Play,
  Square,
  PhoneCall,
  Terminal,
  Smartphone,
} from 'lucide-react';
import {
  PrayerFocusSettings,
  FocusPrayerKey,
  PrayerFocusDuration,
  PrayerDeviceLockState,
  FOCUS_PRAYER_LIST,
  FOCUS_DURATION_OPTIONS,
  PROTECTED_SYSTEM_APPS,
  loadPrayerFocusSettings,
  savePrayerFocusSettings,
  calculateFocusWindowsForDate,
  isPrayerFocusServiceEnabled,
  openAccessibilitySettings,
  openDeviceAdminSettings,
  getPrayerFocusStatus,
  setPrayerFocusEnabled,
  setPrayerFocusDuration,
  startPrayerFocus,
  stopPrayerFocus,
} from '../../utils/prayerFocusService';
import { getCurrentCity, getPrayerSettings } from '../../utils/prayerScheduler';

interface PrayerFocusSettingsCardProps {
  onShowToast?: (msg: string) => void;
  onNavigateToPrayers?: () => void;
}

export const PrayerFocusSettingsCard: React.FC<PrayerFocusSettingsCardProps> = ({
  onShowToast,
  onNavigateToPrayers,
}) => {
  const [focusSettings, setFocusSettings] = useState<PrayerFocusSettings>(
    loadPrayerFocusSettings
  );
  const [serviceEnabled, setServiceEnabled] = useState<boolean>(false);
  const [nativeStatus, setNativeStatus] = useState<PrayerDeviceLockState | null>(null);
  const [isCheckingStatus, setIsCheckingStatus] = useState<boolean>(false);
  const [showAccessibilityModal, setShowAccessibilityModal] = useState<boolean>(false);
  const [showProvisioningModal, setShowProvisioningModal] = useState<boolean>(false);
  const [accessibilityError, setAccessibilityError] = useState<string | null>(null);

  const city = useMemo(() => getCurrentCity(), [focusSettings]);
  const prayerSettings = useMemo(() => getPrayerSettings(), [focusSettings]);

  const todayWindows = useMemo(() => {
    return calculateFocusWindowsForDate(new Date(), focusSettings);
  }, [focusSettings]);

  const refreshRealNativeState = useCallback(async () => {
    setIsCheckingStatus(true);
    try {
      const [realServiceEnabled, status] = await Promise.all([
        isPrayerFocusServiceEnabled(),
        getPrayerFocusStatus(),
      ]);
      setServiceEnabled(realServiceEnabled || Boolean(status?.deviceOwnerActive));
      setNativeStatus(status);
      setFocusSettings(loadPrayerFocusSettings());
    } finally {
      setIsCheckingStatus(false);
    }
  }, []);

  useEffect(() => {
    refreshRealNativeState();

    const handleSync = () => {
      setFocusSettings(loadPrayerFocusSettings());
    };

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        refreshRealNativeState();
      }
    };

    window.addEventListener('rifq-prayer-focus-changed', handleSync);
    window.addEventListener('focus', handleVisibilityOrFocus);
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);

    return () => {
      window.removeEventListener('rifq-prayer-focus-changed', handleSync);
      window.removeEventListener('focus', handleVisibilityOrFocus);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
    };
  }, [refreshRealNativeState]);

  const isDeviceOwnerActive = Boolean(nativeStatus?.deviceOwnerActive);
  const isDeviceAdminActive = Boolean(nativeStatus?.deviceAdminActive);
  const isLockTaskActive = Boolean(nativeStatus?.lockTaskActive);

  /**
   * Critical Rule: Never claim Prayer Device Lock is active if native protection is not actually enabled!
   */
  const isEffectivelyActive =
    focusSettings.enabled && (serviceEnabled || isDeviceOwnerActive);

  const updateConfig = (partial: Partial<PrayerFocusSettings>, toastMsg?: string) => {
    const next = savePrayerFocusSettings(partial);
    setFocusSettings(next);
    if (toastMsg && onShowToast) {
      onShowToast(toastMsg);
    }
  };

  const handleToggleMasterEnabled = async () => {
    setAccessibilityError(null);
    const [currentlyGranted, status] = await Promise.all([
      isPrayerFocusServiceEnabled(),
      getPrayerFocusStatus(),
    ]);
    const canProtect = currentlyGranted || Boolean(status?.deviceOwnerActive);
    setServiceEnabled(canProtect);
    setNativeStatus(status);

    if (!isEffectivelyActive) {
      if (!canProtect) {
        setShowAccessibilityModal(true);
        return;
      }
      await setPrayerFocusEnabled(true);
      setFocusSettings(loadPrayerFocusSettings());
      if (onShowToast) {
        onShowToast('تم تفعيل وضع قفل الجهاز وقت الصلاة (20 دقيقة منذ الأذان) 🔒');
      }
    } else {
      await setPrayerFocusEnabled(false);
      setFocusSettings(loadPrayerFocusSettings());
      if (onShowToast) {
        onShowToast('تم إيقاف وضع قفل الجهاز وقت الصلاة');
      }
    }
    await refreshRealNativeState();
  };

  const handleOpenAndroidAccessibilitySettings = async () => {
    setAccessibilityError(null);
    const res = await openAccessibilitySettings();
    if (!res.openedNative) {
      setAccessibilityError(
        'فتح إعدادات إمكانية الوصول المباشر يتطلب تشغيل التطبيق على هاتف Android وتفعيل خدمة «رِفْق - وضع قفل الجهاز وقت الصلاة» من إعدادات النظام.'
      );
    }
  };

  const handleOpenAndroidDeviceAdminSettings = async () => {
    setAccessibilityError(null);
    const res = await openDeviceAdminSettings();
    if (!res.openedNative) {
      setAccessibilityError(
        'فتح إعدادات مسؤول الجهاز (DevicePolicyManager) يتطلب تشغيل التطبيق على هاتف Android حقيقي.'
      );
    }
  };

  const handleVerifyAccessibilityAndEnable = async () => {
    setAccessibilityError(null);
    const [reallyGranted, status] = await Promise.all([
      isPrayerFocusServiceEnabled(),
      getPrayerFocusStatus(),
    ]);
    const canProtect = reallyGranted || Boolean(status?.deviceOwnerActive);
    setServiceEnabled(canProtect);
    setNativeStatus(status);

    if (!canProtect) {
      setAccessibilityError(
        'لم يتم تفعيل خدمة الحماية في Android حتى الآن. يرجى تفعيل خدمة إمكانية الوصول أو تهيئة الجهاز كـ Device Owner أولاً.'
      );
      return;
    }

    await setPrayerFocusEnabled(true);
    updateConfig(
      {
        accessibilityGranted: true,
        hasSeenAccessibilityExplanation: true,
        enabled: true,
      },
      'تم التحقق من صلاحيات Android وتشغيل وضع قفل الجهاز وقت الصلاة 🔒'
    );
    setShowAccessibilityModal(false);
    await refreshRealNativeState();
  };

  const handleTogglePrayer = (prayerKey: FocusPrayerKey, nameAr: string) => {
    const currentVal = Boolean(focusSettings.prayers[prayerKey]);
    const nextVal = !currentVal;
    updateConfig(
      {
        prayers: {
          ...focusSettings.prayers,
          [prayerKey]: nextVal,
        },
      },
      nextVal
        ? `تم تفعيل قفل الجهاز وقت صلاة ${nameAr}`
        : `تم إيقاف قفل الجهاز في صلاة ${nameAr}`
    );
  };

  const handleSelectDuration = async (
    duration: PrayerFocusDuration,
    labelAr: string
  ) => {
    await setPrayerFocusDuration(duration);
    setFocusSettings(loadPrayerFocusSettings());
    if (onShowToast) {
      onShowToast(`تم ضبط مدة قفل الجهاز وقت الصلاة: ${labelAr}`);
    }
  };

  const handleStartImmediateFocus = async () => {
    const [granted, status] = await Promise.all([
      isPrayerFocusServiceEnabled(),
      getPrayerFocusStatus(),
    ]);
    const canProtect = granted || Boolean(status?.deviceOwnerActive);
    setServiceEnabled(canProtect);
    setNativeStatus(status);
    if (!canProtect) {
      setShowAccessibilityModal(true);
      return;
    }
    const started = await startPrayerFocus();
    if (started && onShowToast) {
      onShowToast('تم بدء جلسة قفل الجهاز وقت الصلاة الآن 🔒');
    }
    await refreshRealNativeState();
  };

  const handleStopActiveFocus = async () => {
    await stopPrayerFocus();
    if (onShowToast) {
      onShowToast('تم إيقاف جلسة قفل الجهاز الحالية والعودة للوضع الطبيعي');
    }
    await refreshRealNativeState();
  };

  return (
    <>
      <div
        id="prayer-focus-settings-section"
        className="bg-white dark:bg-[#1C1D2B] rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow border border-[#E6E6F0] dark:border-white/10 space-y-5 relative overflow-hidden font-tajawal"
        dir="rtl"
      >
        {/* Top Accent Line */}
        <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-[#5B5FEF] via-[#4CAF82] to-[#E8B84A]" />

        {/* 1. Section Header & Master Toggle */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E6E6F0] dark:border-white/10">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#EEEEFF] dark:bg-[#5B5FEF]/20 text-[#5B5FEF] flex items-center justify-center text-2xl shrink-0 border border-[#E6E6F0] dark:border-white/10">
              🔒
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-lg font-black text-[#25263A] dark:text-white">
                  🔒 قفل الجهاز وقت الصلاة (Prayer Device Lock)
                </h3>
                <span
                  className={`text-xs font-black px-2.5 py-0.5 rounded-full ${
                    isEffectivelyActive
                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                      : focusSettings.enabled && !serviceEnabled
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                      : 'bg-[#F7F7FC] text-[#77798C] dark:bg-[#222436] dark:text-gray-400'
                  }`}
                >
                  {isEffectivelyActive
                    ? isDeviceOwnerActive
                      ? 'مفعّل • Kiosk / Device Owner'
                      : 'مفعّل • حماية فورية عند فتح الهاتف'
                    : focusSettings.enabled && !serviceEnabled
                    ? 'يتطلب تفعيل الصلاحيات النظامية'
                    : 'متوقف'}
                </span>
              </div>
              <p className="text-xs text-[#77798C] dark:text-gray-400 mt-1 leading-relaxed">
                يبدأ قفل الجهاز من وقت الأذان الحقيقي ويستمر لمدة <strong>20 دقيقة بالضبط</strong> (<code className="font-mono">adhanTimestamp → adhanTimestamp + 20m</code>). إذا تم فتح قفل الهاتف (PIN / بصمة / نمط) أثناء فترة الـ20 دقيقة، يعيد النظام تطبيق حماية وضع الصلاة فورًا دون بدء 20 دقيقة جديدة، مع السماح الدائم بمكالمات الطوارئ (SOS).
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleToggleMasterEnabled}
            className={`px-5 py-2.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 ${
              isEffectivelyActive
                ? 'bg-[#4CAF82] text-white shadow-sm'
                : 'bg-[#5B5FEF] hover:bg-[#4145C7] text-white shadow-sm'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>
              {isEffectivelyActive
                ? 'قفل الجهاز وقت الصلاة مفعّل ✓'
                : 'تفعيل قفل الجهاز وقت الصلاة'}
            </span>
          </button>
        </div>

        {/* 2. Honest Android Device Owner / Kiosk Lock Task Mode Status Card (Requirement 10, 26, 30, 31) */}
        <div
          className={`p-4 rounded-2xl border space-y-3 ${
            isDeviceOwnerActive
              ? 'bg-emerald-50/70 dark:bg-emerald-950/25 border-emerald-200 dark:border-emerald-800/50'
              : 'bg-[#F7F7FC] dark:bg-[#222436] border-[#E6E6F0] dark:border-white/10'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              {isDeviceOwnerActive ? (
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <Smartphone className="w-5 h-5 text-[#5B5FEF] shrink-0 mt-0.5" />
              )}
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black text-[#25263A] dark:text-white">
                    حالة القفل الكامل للجهاز (Device Owner / Kiosk Lock Task Mode):
                  </span>
                  <span
                    className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${
                      isDeviceOwnerActive
                        ? 'bg-emerald-600 text-white'
                        : 'bg-amber-600 text-white'
                    }`}
                  >
                    {isDeviceOwnerActive
                      ? '• مفعّل (Device Owner / Kiosk)'
                      : '• غير مهيأ كـ Device Owner'}
                  </span>
                </div>
                <p className="text-[11px] text-[#77798C] dark:text-gray-300 mt-1 leading-relaxed">
                  {isDeviceOwnerActive
                    ? 'الجهاز مهيأ رسمياً كـ Device Owner / Dedicated Device. عند دخول وقت الصلاة أو فور فتح قفل الشاشة، يتم تفعيل startLockTask() وحجب زر Home وRecent Apps والتطبيقات الأخرى من مستوى نظام Android.'
                    : 'القفل الكامل للجهاز غير مفعّل لأن الجهاز ليس في وضع Device Owner / Dedicated Device. في وضع التثبيت العادي يعتمد رِفْق على اعتراض حدث فتح القفل (USER_PRESENT) وخدمة إمكانية الوصول لإعادة شاشة وضع الصلاة فورًا.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <button
                type="button"
                onClick={() => setShowProvisioningModal(true)}
                className="px-3.5 py-2 rounded-xl bg-white dark:bg-[#1C1D2B] hover:bg-[#EEEEFF] text-[#4145C7] dark:text-[#8C90FF] border border-[#E6E6F0] dark:border-white/10 text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>خطوات تهيئة Device Owner</span>
              </button>

              {!isDeviceAdminActive && (
                <button
                  type="button"
                  onClick={handleOpenAndroidDeviceAdminSettings}
                  className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>تفعيل مسؤول الجهاز</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* 2.5. Android AccessibilityService & Immediate Unlock Interception Status Card */}
        <div
          className={`p-4 rounded-2xl border space-y-3 ${
            serviceEnabled
              ? 'bg-emerald-50/70 dark:bg-emerald-950/25 border-emerald-200 dark:border-emerald-800/50'
              : 'bg-amber-50/80 dark:bg-amber-950/25 border-amber-200 dark:border-amber-800/50'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              {serviceEnabled ? (
                <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              )}
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-black text-[#25263A] dark:text-white">
                    حالة خدمة الاعتراض الفوري عند فتح الهاتف (Accessibility + Unlock Receiver):
                  </span>
                  <span
                    className={`text-xs font-black px-2.5 py-0.5 rounded-full ${
                      serviceEnabled
                        ? 'bg-emerald-600 text-white'
                        : 'bg-amber-600 text-white'
                    }`}
                  >
                    {serviceEnabled ? '• مفعلة' : '• غير مفعلة'}
                  </span>
                </div>
                <p className="text-[11px] text-[#77798C] dark:text-gray-300 mt-1 leading-relaxed">
                  {serviceEnabled
                    ? 'خدمة رِفْق مفعّلة في نظام Android وتلتقط لحظة فتح قفل الشاشة (ACTION_USER_PRESENT) في أجزاء من الثانية لإعادة تطبيق وضع قفل الصلاة فورًا طالما الوقت داخل فترة الـ20 دقيقة.'
                    : 'يرجى تفعيل خدمة «رِفْق - وضع قفل الجهاز وقت الصلاة» من إعدادات إمكانية الوصول في Android لالتقاط لحظة فتح الهاتف ومنع الخروج إلى الشاشة الرئيسية أو التطبيقات أثناء الـ20 دقيقة.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              {!serviceEnabled && (
                <button
                  type="button"
                  onClick={handleOpenAndroidAccessibilitySettings}
                  className="px-4 py-2.5 rounded-xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white text-xs font-black flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح إعدادات إمكانية الوصول</span>
                </button>
              )}
              <button
                type="button"
                onClick={refreshRealNativeState}
                disabled={isCheckingStatus}
                className="px-3 py-2.5 rounded-xl bg-white dark:bg-[#222436] hover:bg-[#F7F7FC] text-[#25263A] dark:text-white border border-[#E6E6F0] dark:border-white/10 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${isCheckingStatus ? 'animate-spin' : ''}`}
                />
                <span>تحديث الحالة</span>
              </button>
            </div>
          </div>

          {/* Live Native PrayerDeviceLockState Inspector & Controls */}
          {nativeStatus && (serviceEnabled || isDeviceOwnerActive) && (
            <div className="pt-2.5 border-t border-emerald-200/70 dark:border-emerald-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="text-[#25263A] dark:text-gray-200 font-bold flex items-center gap-2 flex-wrap">
                <span>
                  حالة <code className="font-mono">PrayerDeviceLockState</code> الآن:{' '}
                  <strong
                    className={
                      nativeStatus.isActive
                        ? 'text-emerald-700 dark:text-emerald-300'
                        : 'text-[#77798C]'
                    }
                  >
                    {nativeStatus.isActive
                      ? `نشط لصلاة ${nativeStatus.prayerNameAr || 'الصلاة'} (${
                          nativeStatus.lockStartTime || ''
                        } → ${nativeStatus.lockEndTime || ''} • متبقي ${
                          nativeStatus.remainingMinutes || 1
                        } د)${isLockTaskActive ? ' [Kiosk Lock Task]' : ''}`
                      : 'غير نشط حالياً (في انتظار وقت الأذان القادم)'}
                  </strong>
                </span>
              </div>
              <div className="flex items-center gap-2">
                {nativeStatus.isActive ? (
                  <button
                    type="button"
                    onClick={handleStopActiveFocus}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black flex items-center gap-1 cursor-pointer"
                  >
                    <Square className="w-3 h-3 fill-current" />
                    <span>إنهاء القفل الحالي</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleStartImmediateFocus}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black flex items-center gap-1 cursor-pointer"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>اختبار قفل الجهاز الآن</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Connected to RIFQ Prayer Calculation Service Info */}
        <div className="p-3.5 rounded-2xl bg-[#F7F7FC] dark:bg-[#222436] border border-[#E6E6F0] dark:border-white/10 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2.5 text-xs">
            <MapPin className="w-4 h-4 text-[#5B5FEF] shrink-0" />
            <span className="text-[#25263A] dark:text-white font-bold">
              مرتبط تلقائياً بمواقيت رِفْق الفلكية المحلية (يعمل بدون إنترنت):{' '}
              <strong className="text-[#4145C7] dark:text-[#8C90FF]">{city.nameAr}</strong> · المذهب:{' '}
              {prayerSettings.madhab === 'hanafi'
                ? 'الحنفي'
                : 'الجمهور (الشافعي/المالكي/الحنبلي)'}
            </span>
          </div>
          {onNavigateToPrayers && (
            <button
              type="button"
              onClick={onNavigateToPrayers}
              className="text-xs font-bold text-[#5B5FEF] dark:text-[#8C90FF] hover:underline cursor-pointer"
            >
              إعدادات المواقيت ←
            </button>
          )}
        </div>

        {/* 3. Choose Prayers */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-black text-[#25263A] dark:text-white">
              الصلوات المشمولة بقفل الجهاز وقت الصلاة:
            </h4>
            <span className="text-xs text-[#77798C] dark:text-gray-400">
              يبدأ القفل تلقائياً مع الأذان ويستمر حتى انتهاء فترة القفل المحددة
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2.5">
            {FOCUS_PRAYER_LIST.map((prayer) => {
              const isChecked = Boolean(focusSettings.prayers[prayer.key]);
              const win = todayWindows.find((w) => w.prayerKey === prayer.key);

              return (
                <button
                  key={prayer.key}
                  type="button"
                  onClick={() => handleTogglePrayer(prayer.key, prayer.nameAr)}
                  className={`p-3 rounded-2xl border text-right transition-all cursor-pointer flex sm:flex-col items-center sm:items-start justify-between gap-2 ${
                    isChecked
                      ? 'bg-[#EEEEFF]/80 dark:bg-[#5B5FEF]/20 border-[#5B5FEF] shadow-2xs'
                      : 'bg-[#F7F7FC] dark:bg-[#222436] border-[#E6E6F0] dark:border-white/10 opacity-75 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-center justify-between w-full">
                    <span className="text-lg">{prayer.icon}</span>
                    <div
                      className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                        isChecked
                          ? 'bg-[#5B5FEF] border-[#5B5FEF] text-white'
                          : 'bg-white dark:bg-[#151621] border-gray-300 dark:border-gray-600'
                      }`}
                    >
                      {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>

                  <div>
                    <div className="font-black text-sm text-[#25263A] dark:text-white">
                      {prayer.nameAr}
                    </div>
                    {win && (
                      <div className="text-[10px] text-[#77798C] dark:text-gray-400 font-mono mt-0.5">
                        {win.startFormatted} – {win.endFormatted}
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 4. Focus Duration (Default 20 Minutes Exact) */}
        <div className="space-y-3 pt-1">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#5B5FEF]" />
            <h4 className="text-sm font-black text-[#25263A] dark:text-white">
              مدة قفل الجهاز منذ لحظة الأذان (<code className="font-mono">endTimestamp = adhanTimestamp + 20m</code>):
            </h4>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {FOCUS_DURATION_OPTIONS.map((opt) => {
              const isSelected = focusSettings.duration === opt.value;
              return (
                <button
                  key={String(opt.value)}
                  type="button"
                  onClick={() => handleSelectDuration(opt.value, opt.labelAr)}
                  className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    isSelected
                      ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                      : 'bg-[#F7F7FC] dark:bg-[#222436] text-[#25263A] dark:text-white border-[#E6E6F0] dark:border-white/10 hover:bg-[#EEEEFF]/50'
                  }`}
                >
                  <span className="text-xs font-black">{opt.labelAr}</span>
                  {opt.value === 20 && (
                    <span
                      className={`text-[10px] ${
                        isSelected ? 'text-white/85' : 'text-[#4CAF82] font-bold'
                      }`}
                    >
                      الافتراضي الرسمي (20 دقيقة)
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* 5. Emergency / SOS Safety Guarantee */}
        <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-[#222436] border border-[#E6E6F0] dark:border-white/10 space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white dark:bg-[#1C1D2B] border border-[#E6E6F0] dark:border-white/10 flex items-center justify-center text-[#4CAF82] shrink-0">
              <PhoneCall className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="text-sm font-black text-[#25263A] dark:text-white">
                حماية قفل الجهاز وقت الصلاة + استثناءات الطوارئ والنجدة (SOS)
              </h4>
              <p className="text-xs text-[#77798C] dark:text-gray-400 leading-relaxed">
                أثناء فترة الـ20 دقيقة يتم منع الخروج إلى الشاشة الرئيسية (Home) والتطبيقات الحديثة (Recent Apps) والتطبيقات الأخرى، مع إبقاء وظائف الطوارئ والنجدة متاحة دائماً:
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
            {PROTECTED_SYSTEM_APPS.map((item) => (
              <div
                key={item.packageName}
                className="p-2.5 rounded-xl bg-white dark:bg-[#1C1D2B] border border-[#E6E6F0] dark:border-white/10 flex items-start gap-2"
              >
                <ShieldCheck className="w-4 h-4 text-[#4CAF82] shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-black text-[#25263A] dark:text-white">
                    {item.nameAr}
                  </div>
                  <div className="text-[11px] text-[#77798C] dark:text-gray-400">
                    {item.reasonAr}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Device Owner / Dedicated Device Provisioning Instructions Modal (Requirement 30) */}
      {showProvisioningModal && (
        <div
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in font-tajawal"
          dir="rtl"
          onClick={() => setShowProvisioningModal(false)}
        >
          <div
            className="bg-white dark:bg-[#1C1D2B] rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-[#E6E6F0] dark:border-white/10 space-y-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setShowProvisioningModal(false)}
              className="w-8 h-8 rounded-full bg-[#F7F7FC] dark:bg-[#222436] hover:bg-[#E6E6F0] text-[#77798C] flex items-center justify-center absolute top-5 left-5 cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#EEEEFF] dark:bg-[#5B5FEF]/20 text-[#5B5FEF] flex items-center justify-center shrink-0">
                <Terminal className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-[#25263A] dark:text-white">
                  تهيئة وضع القفل الكامل (Device Owner / Kiosk Mode)
                </h3>
                <span className="text-xs text-[#5B5FEF] dark:text-[#8C90FF] font-bold">
                  متطلبات نظام Android الرسمية لتشغيل Lock Task Mode بدون استثناء
                </span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-[#222436] border border-[#E6E6F0] dark:border-white/10 space-y-2.5 text-xs text-[#25263A] dark:text-gray-200 leading-relaxed">
              <p className="font-bold">
                يمنع نظام Android أي تطبيق عادي من تعيين نفسه <code className="font-mono">Device Owner</code> من زر داخلي لأسباب أمنية. لتفعيل وضع <code className="font-mono">Lock Task Mode</code> الكامل عبر <code className="font-mono">DevicePolicyManager</code>، يتم تهيئة الجهاز مرة واحدة فقط عبر ADB أو Enterprise Provisioning:
              </p>
              <div
                className="p-3 rounded-xl bg-[#141522] text-emerald-300 font-mono text-[11px] overflow-x-auto select-all"
                dir="ltr"
              >
                adb shell dpm set-device-owner com.rifq.app/.prayerfocus.PrayerDeviceAdminReceiver
              </div>
              <ul className="space-y-1 text-[#77798C] dark:text-gray-400 list-disc pr-4">
                <li>
                  عند تفعيل <code className="font-mono">Device Owner</code> يقوم رِفْق تلقائياً باستدعاء <code className="font-mono">setLockTaskPackages()</code> و<code className="font-mono">startLockTask()</code> لقفل زر Home وRecent Apps والتطبيقات الأخرى طوال الـ20 دقيقة.
                </li>
                <li>
                  إذا لم يكن الجهاز مهيأً كـ <code className="font-mono">Device Owner</code>، يعمل رِفْق عبر مستقبل فتح القفل (<code className="font-mono">ACTION_USER_PRESENT</code>) وخدمة إمكانية الوصول لإعادة شاشة وضع الصلاة فور فتح الهاتف.
                </li>
              </ul>
            </div>

            <button
              type="button"
              onClick={() => setShowProvisioningModal(false)}
              className="w-full py-3 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs cursor-pointer"
            >
              حسناً، فهمت
            </button>
          </div>
        </div>
      )}

      {/* Accessibility Permission Explanation & Activation Modal */}
      {showAccessibilityModal && (
        <div
          className="fixed inset-0 z-50 bg-black/65 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in font-tajawal"
          dir="rtl"
          onClick={() => setShowAccessibilityModal(false)}
        >
          <div
            className="bg-white dark:bg-[#1C1D2B] rounded-3xl p-6 max-w-md w-full shadow-2xl border border-[#E6E6F0] dark:border-white/10 space-y-5 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setShowAccessibilityModal(false)}
              className="w-8 h-8 rounded-full bg-[#F7F7FC] dark:bg-[#222436] hover:bg-[#E6E6F0] text-[#77798C] flex items-center justify-center absolute top-5 left-5 cursor-pointer"
              aria-label="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#EEEEFF] dark:bg-[#5B5FEF]/20 text-[#5B5FEF] flex items-center justify-center text-2xl shrink-0">
                🔒
              </div>
              <div>
                <h3 className="text-base font-black text-[#25263A] dark:text-white">
                  تفعيل خدمة قفل الجهاز وقت الصلاة
                </h3>
                <span className="text-xs text-[#5B5FEF] dark:text-[#8C90FF] font-bold">
                  الخطوة الضرورية لالتقاط لحظة فتح الهاتف أثناء فترة الـ20 دقيقة
                </span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#F7F7FC] dark:bg-[#222436] border border-[#E6E6F0] dark:border-white/10 space-y-2.5 text-xs text-[#25263A] dark:text-gray-200 leading-relaxed">
              <p className="font-bold">
                يستخدم تطبيق «رِفْق» خدمة الحماية النظامية لاكتشاف لحظة فتح قفل الشاشة (<code className="font-mono">LOCKED → UNLOCKED</code>) أثناء فترة الـ20 دقيقة وإعادة تطبيق وضع قفل الصلاة فورًا، ولا يجمع أو يقرأ أي كلمات مرور أو بيانات شخصية.
              </p>
              <p className="text-[#77798C] dark:text-gray-400">
                • لا يتم تغيير رمز PIN أو كلمة المرور الخاصة بجهازك مطلقاً.
                <br />• تبقى مكالمات الطوارئ (SOS) والنجدة متاحة ومسموحة دائماً.
              </p>
            </div>

            {accessibilityError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/50 text-xs font-bold text-rose-700 dark:text-rose-300 leading-relaxed">
                {accessibilityError}
              </div>
            )}

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={handleOpenAndroidAccessibilitySettings}
                className="w-full py-3 px-4 rounded-2xl bg-[#5B5FEF] hover:bg-[#4145C7] text-white font-black text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
              >
                <ExternalLink className="w-4 h-4" />
                <span>فتح إعدادات إمكانية الوصول في Android</span>
              </button>

              <button
                type="button"
                onClick={handleVerifyAccessibilityAndEnable}
                className="w-full py-3 px-4 rounded-2xl bg-[#4CAF82] hover:brightness-95 text-white font-black text-xs flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>قمت بالتفعيل • تحقق وشغّل قفل الجهاز وقت الصلاة</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
