import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  BellOff,
  Clock,
  Check,
  CheckCircle2,
  Minimize2,
  Maximize2,
  X,
  Plus,
  RotateCcw,
  Sparkles,
  BookOpen,
  Volume2,
  ChevronDown,
  Compass,
  Camera,
  Lock,
} from 'lucide-react';
import {
  InAppPrayerModeState,
  getInAppPrayerModeState,
  stopInAppPrayerMode,
  extendInAppPrayerMode,
  toggleInAppPrayerModeMinimized,
  getMihrabVerificationTiming,
  FOCUS_PRAYER_LIST,
} from '../../utils/prayerFocusService';
import { PRAYERS_METADATA, POST_PRAYER_ATHKAR } from '../../data/prayersData';
import { playIslamicChime, triggerHaptic } from '../../utils/prayerAudio';
import { MihrabVerificationModal } from './MihrabVerificationModal';

interface PrayerFocusModeOverlayProps {
  onOpenFullAthkarModal?: () => void;
}

export const PrayerFocusModeOverlay: React.FC<PrayerFocusModeOverlayProps> = ({
  onOpenFullAthkarModal,
}) => {
  const [state, setState] = useState<InAppPrayerModeState>(getInAppPrayerModeState);
  const [activeTab, setActiveTab] = useState<'timer' | 'athkar'>('timer');
  const [hasConfirmedPrayed, setHasConfirmedPrayed] = useState(false);
  const [isMihrabModalOpen, setIsMihrabModalOpen] = useState(false);

  // Interactive Post-Prayer Rosary (المسبحة التفاعلية دبر الصلاة: 33-33-33-1)
  const [rosaryPhase, setRosaryPhase] = useState<0 | 1 | 2 | 3>(0);
  const [rosaryCount, setRosaryCount] = useState<number>(0);

  // Sync state with storage and custom events
  useEffect(() => {
    const handleSync = (e?: Event) => {
      const customEvent = e as CustomEvent<InAppPrayerModeState> | undefined;
      setState(customEvent?.detail || getInAppPrayerModeState());
    };

    window.addEventListener('rifq-in-app-prayer-mode-changed', handleSync);
    window.addEventListener('storage', handleSync);

    return () => {
      window.removeEventListener('rifq-in-app-prayer-mode-changed', handleSync);
      window.removeEventListener('storage', handleSync);
    };
  }, []);

  // Live 1-second countdown ticker
  const [nowMs, setNowMs] = useState<number>(Date.now());
  useEffect(() => {
    if (!state.isActive) return;
    const interval = setInterval(() => {
      const current = Date.now();
      setNowMs(current);
      if (state.endTimeMs && current >= state.endTimeMs) {
        // Natural end of prayer window
        stopInAppPrayerMode(false);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [state.isActive, state.endTimeMs]);

  const remainingMs = useMemo(() => {
    if (!state.isActive || !state.endTimeMs) return 0;
    return Math.max(0, state.endTimeMs - nowMs);
  }, [state.isActive, state.endTimeMs, nowMs]);

  const totalDurationMs = useMemo(() => {
    return (state.durationMinutes || 20) * 60 * 1000;
  }, [state.durationMinutes]);

  const percentRemaining = useMemo(() => {
    if (totalDurationMs <= 0) return 0;
    return Math.min(100, Math.max(0, (remainingMs / totalDurationMs) * 100));
  }, [remainingMs, totalDurationMs]);

  const formattedCountdown = useMemo(() => {
    const totalSeconds = Math.floor(remainingMs / 1000);
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }, [remainingMs]);

  const prayerMeta = useMemo(() => {
    return PRAYERS_METADATA[state.prayerKey] || PRAYERS_METADATA.dhuhr;
  }, [state.prayerKey]);

  // Mihrab timing rules calculation
  const timing = useMemo(() => {
    return getMihrabVerificationTiming(state, nowMs);
  }, [state, nowMs]);

  // Handlers
  const handleConfirmPrayed = useCallback(() => {
    triggerHaptic([40, 60, 80]);
    playIslamicChime();
    setHasConfirmedPrayed(true);
    stopInAppPrayerMode(true);
    // Smoothly transition to post-prayer athkar suggestions
    setActiveTab('athkar');
  }, []);

  const handleExtend = useCallback(() => {
    triggerHaptic(30);
    extendInAppPrayerMode(5);
  }, []);

  const handleClose = useCallback(() => {
    triggerHaptic(25);
    stopInAppPrayerMode(false);
  }, []);

  const handleToggleMinimize = useCallback(() => {
    triggerHaptic(25);
    toggleInAppPrayerModeMinimized();
  }, []);

  // Rosary phases
  const rosaryPhases = [
    { title: 'سُبْحَانَ اللهِ', target: 33, label: 'التسبيح' },
    { title: 'الحَمْدُ للهِ', target: 33, label: 'التحميد' },
    { title: 'اللهُ أَكْبَرُ', target: 33, label: 'التكبير' },
    {
      title: 'لاَ إِلَهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ',
      target: 1,
      label: 'تمام المائة',
    },
  ];

  const handleRosaryTap = () => {
    const currentPhase = rosaryPhases[rosaryPhase];
    const nextCount = rosaryCount + 1;

    if (nextCount < currentPhase.target) {
      triggerHaptic(30);
      setRosaryCount(nextCount);
    } else {
      triggerHaptic([50, 50, 100]);
      playIslamicChime();
      if (rosaryPhase < 3) {
        setRosaryPhase((prev) => (prev + 1) as 0 | 1 | 2 | 3);
        setRosaryCount(0);
      } else {
        // Finished all 100
        setRosaryCount(1);
      }
    }
  };

  const handleResetRosary = () => {
    triggerHaptic(30);
    setRosaryPhase(0);
    setRosaryCount(0);
  };

  // If mode is not active, render nothing
  if (!state.isActive) {
    return null;
  }

  // ═════════════════════════════════════════════════════════════════════════
  // A. MINIMIZED FLOATING PILL (الشريط العائم المصغر)
  // ═════════════════════════════════════════════════════════════════════════
  if (state.isMinimized) {
    return (
      <aside
        aria-label="وضع الصلاة والخشوع المصغر"
        onClick={handleToggleMinimize}
        className="fixed top-3 left-3 right-3 sm:left-auto sm:right-6 sm:w-auto z-50 bg-gradient-to-r from-[#1E1B4B] via-[#2E1065] to-[#1E1B4B] text-white py-2.5 px-4 rounded-2xl shadow-xl border border-amber-400/40 flex items-center justify-between gap-3 animate-fade-in cursor-pointer select-none font-tajawal hover:border-amber-300 transition-all active:scale-[0.99] group"
        dir="rtl"
        title="انقر للتوسيع وعرض المؤقت وأذكار ما بعد الصلاة"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-base shrink-0 animate-pulse">
            🕌
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-xs text-amber-200">
                وضع الصلاة • {state.prayerNameAr}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-400/30 flex items-center gap-1">
                <BellOff className="w-3 h-3" />
                <span>الإشعارات محجوبة</span>
              </span>
            </div>
            <p className="text-[11px] text-indigo-200 font-mono font-bold mt-0.5 flex items-center gap-1.5">
              <Clock className="w-3 h-3 text-amber-300" />
              <span>المتبقي: {formattedCountdown}</span>
              {state.blockedCount > 0 && (
                <span className="text-amber-300 font-normal">
                  (حُجب {state.blockedCount})
                </span>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsMihrabModalOpen(true);
            }}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1 ${
              timing.isAvailable
                ? 'bg-gradient-to-r from-amber-500 to-emerald-500 text-slate-900 border border-amber-300 animate-pulse'
                : 'bg-white/10 text-amber-200 border border-amber-400/30'
            }`}
            title={
              timing.isAvailable
                ? 'التحقق بالمحراب متاح الآن'
                : `التحقق بالمحراب مغلق (يفتح بعد ${timing.lockedCountdownFormatted})`
            }
          >
            <Camera className="w-3 h-3" />
            <span>{timing.isAvailable ? 'المحراب 📷' : 'المحراب 🔒'}</span>
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleConfirmPrayed();
            }}
            className="px-2.5 py-1 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-[11px] font-black transition-all shadow-xs cursor-pointer flex items-center gap-1"
            title="تسجيل إتمام الصلاة"
          >
            <Check className="w-3 h-3 stroke-[3]" />
            <span>صليت</span>
          </button>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleToggleMinimize();
            }}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
            title="توسيع للواجهة الكاملة"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </aside>
    );
  }

  // ═════════════════════════════════════════════════════════════════════════
  // B. FULL PRAYER FOCUS OVERLAY (الواجهة الكاملة لوضع الصلاة والخشوع)
  // ═════════════════════════════════════════════════════════════════════════
  return (
    <div
      className="fixed inset-0 z-50 bg-[#0B0C1E]/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-fade-in font-tajawal overflow-y-auto"
      dir="rtl"
    >
      <div className="bg-gradient-to-b from-[#181935] via-[#15162C] to-[#121324] rounded-3xl w-full max-w-xl max-h-[92vh] flex flex-col shadow-2xl border border-amber-400/30 overflow-hidden text-white relative">
        {/* Subtle Islamic Arch & Golden Glow Accents */}
        <div className="absolute top-0 right-0 left-0 h-1.5 bg-gradient-to-r from-[#E8B84A] via-[#5B5FEF] to-[#4CAF82]" />

        {/* ── TOP HEADER ── */}
        <div className="p-4 sm:p-5 pb-3 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400/25 to-indigo-500/25 border border-amber-300/40 flex items-center justify-center text-2xl shrink-0 shadow-inner">
              {prayerMeta.icon || '🕌'}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-cairo font-black text-base sm:text-lg text-amber-200">
                  وضع الصلاة والخشوع • صلاة {state.prayerNameAr}
                </h3>
              </div>
              <p className="text-xs text-indigo-200 flex items-center gap-1.5 mt-0.5">
                <BellOff className="w-3.5 h-3.5 text-emerald-400" />
                <span>حجب الإشعارات غير الهامة مفعّل للسكينة والإقبال</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleToggleMinimize}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-indigo-200 hover:text-white transition-colors cursor-pointer"
              title="تصغير للشريط العائم لمتابعة التصفح في رِفْق"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-indigo-200 hover:text-white transition-colors cursor-pointer"
              title="إنهاء وضع الصلاة"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ── NOTIFICATION SILENCE STATUS BANNER ── */}
        <div className="bg-emerald-950/40 border-b border-emerald-500/20 px-4 py-2 flex items-center justify-between text-xs">
          <span className="text-emerald-300 flex items-center gap-1.5 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>
              {state.blockedCount > 0
                ? `تم حجب ${state.blockedCount} تنبيهات هاتفية أثناء الصلاة 🔕`
                : 'جميع التنبيهات غير الهامة محجوبة حتى انتهاء الصلاة 🔕'}
            </span>
          </span>
          <span className="text-[11px] text-emerald-200/80">الأذان والطوارئ مسموحة دائماً</span>
        </div>

        {/* ── TABS NAVIGATION BAR ── */}
        <div className="flex items-center gap-1 px-4 pt-3 bg-white/5 border-b border-white/10 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('timer')}
            className={`flex-1 py-2 px-3 rounded-t-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 border-b-2 ${
              activeTab === 'timer'
                ? 'border-amber-400 text-amber-300 bg-white/5 font-black'
                : 'border-transparent text-indigo-200 hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>المؤقت والمتابعة</span>
          </button>

          <button
            type="button"
            onClick={() => setIsMihrabModalOpen(true)}
            className={`flex-1 py-2 px-3 rounded-t-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 border-b-2 border-transparent ${
              timing.isAvailable
                ? 'text-emerald-300 hover:text-emerald-200 font-black animate-pulse'
                : 'text-amber-300 hover:text-white'
            }`}
          >
            <Camera className="w-3.5 h-3.5 text-amber-400" />
            <span>{timing.isAvailable ? 'التحقق بالمحراب (متاح) 📷' : 'التحقق بالمحراب 🔒'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('athkar')}
            className={`flex-1 py-2 px-3 rounded-t-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 border-b-2 ${
              activeTab === 'athkar'
                ? 'border-amber-400 text-amber-300 bg-white/5 font-black'
                : 'border-transparent text-indigo-200 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>أذكار بعد الصلاة 📿</span>
          </button>
        </div>

        {/* ── TAB CONTENT ── */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* TAB 1: COUNTDOWN TIMER & CONTROLS */}
          {activeTab === 'timer' && (
            <div className="space-y-5 animate-fade-in text-center">
              {/* Circular Animated Countdown Ring */}
              <div className="relative w-44 h-44 mx-auto flex items-center justify-center my-2">
                <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 120 120">
                  <circle
                    cx="60"
                    cy="60"
                    r="52"
                    className="text-white/10 stroke-current"
                    strokeWidth="7"
                    fill="transparent"
                  />
                  <circle
                    cx="60"
                    cy="60"
                    r="52"
                    className="text-amber-400 stroke-current transition-all duration-1000 ease-linear"
                    strokeWidth="7"
                    strokeDasharray={326.7}
                    strokeDashoffset={326.7 - (326.7 * percentRemaining) / 100}
                    strokeLinecap="round"
                    fill="transparent"
                  />
                </svg>

                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-[11px] text-emerald-300 font-bold tracking-wide">
                    الوقت المتبقي
                  </span>
                  <span className="text-3xl sm:text-4xl font-mono font-black text-amber-200 tracking-tight mt-0.5">
                    {formattedCountdown}
                  </span>
                  <span className="text-[10px] text-indigo-300 mt-0.5">
                    {state.durationMinutes} دقيقة مخصصة
                  </span>
                </div>
              </div>

              {/* Action Buttons: Confirm Prayed & Extend */}
              <div className="space-y-2.5 max-w-sm mx-auto">
                <button
                  type="button"
                  onClick={handleConfirmPrayed}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:brightness-110 active:scale-95 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 cursor-pointer transition-all"
                >
                  <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                  <span>أتممتُ صلاتي تقبّل الله 🤍</span>
                </button>

                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={handleExtend}
                    className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 active:scale-95 text-xs font-bold text-amber-200 border border-amber-400/30 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>تمديد 5 دقائق</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActiveTab('athkar')}
                    className="py-2.5 px-3 rounded-xl bg-[#5B5FEF]/30 hover:bg-[#5B5FEF]/40 active:scale-95 text-xs font-bold text-indigo-200 border border-[#5B5FEF]/40 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>أذكار بعد الصلاة</span>
                  </button>
                </div>
              </div>

              {/* ── MIHRAB VERIFICATION CARD ── */}
              <div
                className={`p-4 rounded-2xl border text-right transition-all max-w-sm mx-auto space-y-2.5 ${
                  timing.isAvailable
                    ? 'bg-gradient-to-r from-emerald-950/70 via-amber-950/50 to-emerald-950/70 border-emerald-400/60 shadow-lg shadow-emerald-950/40'
                    : 'bg-white/5 border-white/10'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-base shrink-0 ${
                        timing.isAvailable
                          ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-400/50 animate-pulse'
                          : 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                      }`}
                    >
                      {timing.isAvailable ? '📷' : '🔒'}
                    </div>
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-amber-200">
                        التحقق من الصلاة بالمحراب
                      </h4>
                      <p className="text-[11px] text-gray-300">
                        {timing.isLocked
                          ? `مغلق حتى مرور 20 دقيقة (متبقي ${timing.lockedCountdownFormatted})`
                          : timing.isAvailable
                          ? `متاح الآن للتصوير! (ينتهي بعد ${timing.deadlineCountdownFormatted})`
                          : 'انتهت فترة وضع الصلاة'}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsMihrabModalOpen(true)}
                    className={`px-3 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                      timing.isAvailable
                        ? 'bg-gradient-to-r from-amber-500 to-emerald-500 hover:brightness-110 active:scale-95 text-slate-900 border border-amber-300 shadow-md'
                        : 'bg-white/10 text-amber-200 hover:bg-white/15 border border-amber-400/30'
                    }`}
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>{timing.isAvailable ? 'فتح الكاميرا 📷' : 'تفاصيل التحقق'}</span>
                  </button>
                </div>

                <p className="text-[11px] text-indigo-200 leading-relaxed">
                  {timing.isLocked
                    ? 'لضمان إدراك الصلاة مع الجماعة في المسجد وأداء الأذكار والسنن، لا يُسمح بفتح الكاميرا قبل مضي 20 دقيقة كاملة من الأذان.'
                    : 'التقط صورة لمحراب المسجد بواسطة AI Vision لإنهاء وضع الصلاة وتأكيد صلاة الجماعة في رحلتك الإيمانية.'}
                </p>
              </div>

              {/* Hadith & Spiritual Reflection */}
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-indigo-200 leading-relaxed text-right space-y-1">
                <span className="font-bold text-amber-300 block">فضل صلاة {state.prayerNameAr}:</span>
                <p className="text-[11px] text-gray-300">{prayerMeta.hadithVirtue}</p>
                <span className="text-[10px] text-indigo-400 block text-left">
                  {prayerMeta.hadithSource}
                </span>
              </div>
            </div>
          )}

          {/* TAB 2: POST-PRAYER ATHKAR SUGGESTIONS */}
          {activeTab === 'athkar' && (
            <div className="space-y-4 animate-fade-in">
              {/* Interactive Rosary Card (المسبحة التفاعلية السريعة) */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-[#201C4E] to-[#161436] border border-amber-400/35 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">📿</span>
                    <div>
                      <h4 className="font-black text-sm text-amber-200">
                        التسبيح والتحميد والتكبير بعد السلام
                      </h4>
                      <p className="text-[11px] text-indigo-200">
                        {rosaryPhases[rosaryPhase].label} ({rosaryCount} /{' '}
                        {rosaryPhases[rosaryPhase].target})
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleResetRosary}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-indigo-300 hover:text-white transition-colors cursor-pointer"
                    title="إعادة ضبط المسبحة"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Big Interactive Tap Bead Button */}
                <div className="text-center py-2">
                  <button
                    type="button"
                    onClick={handleRosaryTap}
                    className="w-full py-5 px-4 rounded-2xl bg-gradient-to-r from-amber-500/20 via-indigo-600/30 to-amber-500/20 border-2 border-amber-400/50 hover:border-amber-300 active:scale-98 transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 shadow-md group"
                  >
                    <span className="text-lg sm:text-xl font-black text-amber-100 font-serif leading-relaxed px-2">
                      {rosaryPhases[rosaryPhase].title}
                    </span>
                    <span className="text-xs px-3 py-1 rounded-full bg-amber-400/25 text-amber-200 font-bold border border-amber-400/40">
                      اضغط للتسبيح • {rosaryCount} / {rosaryPhases[rosaryPhase].target}
                    </span>
                  </button>
                </div>

                {/* Progress Indicators */}
                <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] font-bold">
                  {rosaryPhases.map((p, idx) => (
                    <div
                      key={p.label}
                      className={`p-1.5 rounded-lg border transition-all ${
                        rosaryPhase === idx
                          ? 'bg-amber-400/20 border-amber-400 text-amber-200'
                          : rosaryPhase > idx
                          ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                          : 'bg-white/5 border-white/10 text-gray-400'
                      }`}
                    >
                      {rosaryPhase > idx ? '✓ ' : ''}
                      {p.label}
                    </div>
                  ))}
                </div>
              </div>

              {/* Top Authentic Post-Prayer Athkar Cards */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold text-amber-300 px-1">
                  <span>الأدعية المأثورة دبر الصلاة المكتوبة</span>
                  {onOpenFullAthkarModal && (
                    <button
                      type="button"
                      onClick={onOpenFullAthkarModal}
                      className="text-emerald-300 hover:underline cursor-pointer flex items-center gap-1 text-[11px]"
                    >
                      <span>عرض الكتيب الكامل</span>
                      <BookOpen className="w-3 h-3" />
                    </button>
                  )}
                </div>

                {POST_PRAYER_ATHKAR.slice(0, 4).map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/30 transition-all text-xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-black text-amber-200 text-xs sm:text-sm">
                        {item.title}
                      </span>
                      <span className="text-[10px] text-indigo-300">{item.source}</span>
                    </div>

                    <p className="text-sm sm:text-base text-gray-100 font-serif leading-relaxed pr-2 border-r-2 border-amber-400/60">
                      {item.text}
                    </p>

                    {item.virtue && (
                      <p className="text-[11px] text-emerald-300/90 bg-emerald-950/30 p-2 rounded-xl">
                        {item.virtue}
                      </p>
                    )}
                  </div>
                ))}
              </div>

              {/* Complete Athkar Button */}
              {onOpenFullAthkarModal && (
                <button
                  type="button"
                  onClick={onOpenFullAthkarModal}
                  className="w-full py-3 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-bold border border-white/15 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <BookOpen className="w-4 h-4 text-amber-300" />
                  <span>فتح كافة أذكار ما بعد الصلاة والسنن الرواتب</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* ── FOOTER ── */}
        <div className="p-3 sm:p-4 bg-white/5 border-t border-white/10 flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={handleToggleMinimize}
            className="text-indigo-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Minimize2 className="w-3.5 h-3.5" />
            <span>تصغير للشريط العائم</span>
          </button>

          <button
            type="button"
            onClick={handleConfirmPrayed}
            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1"
          >
            <Check className="w-3.5 h-3.5 stroke-[3]" />
            <span>صليتُ الحمد لله</span>
          </button>
        </div>
      </div>

      {/* ── MIHRAB VERIFICATION MODAL (AI VISION) ── */}
      <MihrabVerificationModal
        isOpen={isMihrabModalOpen}
        onClose={() => setIsMihrabModalOpen(false)}
        onSuccess={() => {
          setIsMihrabModalOpen(false);
        }}
      />
    </div>
  );
};
