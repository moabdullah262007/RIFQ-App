import React, { useState, useMemo, useEffect } from 'react';
import {
  ArrowRight,
  RotateCcw,
  Star,
  Check,
  EyeOff,
  Keyboard,
  Hand,
} from 'lucide-react';
import { soundManager } from '../../utils/audio';
import { SURAH_LIST } from '../../data/quranData';
import {
  normalizeArabicForComparison,
  isWordHiddenAtLevel,
} from './DailyMemorizationView';
import { InteractiveBrowsingQuiz } from './InteractiveBrowsingQuiz';
import {
  InteractiveMushafSvg,
  CompleteAyahSvg,
  ReorderAyahsSvg,
  ChoiceAyahSvg,
  TrophyMedalSvg,
  ArrowUpSvg,
  ArrowDownSvg,
} from './InteractiveQuizIcons';
import { ensureSurahInQuranTables, QuranAyahRow } from '../../utils/interactiveQuranQuizDb';

interface QuizViewProps {
  onBack: () => void;
  onShowToast: (msg: string) => void;
  initialQuizType?: QuizType;
  initialSurahId?: number;
}

export type QuizType =
  | 'interactive_browsing'
  | 'progressive_recite'
  | 'complete'
  | 'reorder'
  | 'choice';

export const QuizView: React.FC<QuizViewProps> = ({
  onBack,
  onShowToast,
  initialQuizType = 'interactive_browsing',
  initialSurahId = 67,
}) => {
  const [activeQuizType, setActiveQuizType] = useState<QuizType>(initialQuizType);
  const [selectedSurahId, setSelectedSurahId] = useState<number>(initialSurahId);
  const [loadedAyahs, setLoadedAyahs] = useState<QuranAyahRow[]>([]);

  useEffect(() => {
    let active = true;
    ensureSurahInQuranTables(selectedSurahId).then(({ ayahs }) => {
      if (active) {
        setLoadedAyahs(ayahs);
      }
    });
    return () => {
      active = false;
    };
  }, [selectedSurahId]);

  const surahMeta = useMemo(
    () => SURAH_LIST.find((s) => s.number === selectedSurahId) || SURAH_LIST[66],
    [selectedSurahId]
  );

  // Progressive Recite / Written Test State
  const [reciteSubMode, setReciteSubMode] = useState<'hide' | 'write'>('hide');
  const [hideLevel, setHideLevel] = useState<0 | 25 | 50 | 75 | 100>(50);
  const [maskStyle, setMaskStyle] = useState<'blur' | 'hidden'>('blur');
  const [revealedKeys, setRevealedKeys] = useState<Set<string>>(new Set());
  const [typedText, setTypedText] = useState<string>('');
  const [writeChecked, setWriteChecked] = useState<boolean>(false);

  const passageAyahs = useMemo(() => loadedAyahs.slice(0, 5), [loadedAyahs]);

  const toggleRevealWord = (key: string) => {
    soundManager.triggerHaptic(15);
    setRevealedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const writtenCheckResult = useMemo(() => {
    const fullTarget = passageAyahs.map((a) => a.ayah_text).join(' ');
    const origWords = fullTarget.trim().split(/\s+/).filter(Boolean);
    const userWords = typedText.trim().split(/\s+/).filter(Boolean);

    const items = origWords.map((orig, i) => {
      const typed = userWords[i] || '';
      const isMatch =
        typed.length > 0 &&
        normalizeArabicForComparison(orig) === normalizeArabicForComparison(typed);
      return { orig, typed, isMatch };
    });

    const matchedCount = items.filter((it) => it.isMatch).length;
    const accuracy = origWords.length > 0 ? Math.round((matchedCount / origWords.length) * 100) : 0;
    return { items, matchedCount, total: origWords.length, accuracy };
  }, [passageAyahs, typedText]);

  // Dynamic Real Questions from quran_ayahs for Complete, Choice, and Reorder
  const dynamicCompleteQuestions = useMemo(() => {
    if (loadedAyahs.length === 0) return [];
    const allLastWords = loadedAyahs
      .map((a) => {
        const w = a.ayah_text.trim().split(/\s+/).filter(Boolean);
        return w[w.length - 1] || '';
      })
      .filter(Boolean);

    return loadedAyahs.slice(0, Math.min(5, loadedAyahs.length)).map((ayah, idx) => {
      const words = ayah.ayah_text.trim().split(/\s+/).filter(Boolean);
      const correctFinish = words[words.length - 1] || '';
      const startText = words.slice(0, -1).join(' ');
      const distractors = allLastWords.filter((w) => w !== correctFinish).slice(0, 3);
      while (distractors.length < 3) {
        const fallbackPool = ['قَدِيرٌ', 'عَلِيمٌ', 'حَكِيمٌ', 'بَصِيرٌ', 'غَفُورٌ'];
        const cand = fallbackPool[distractors.length % fallbackPool.length];
        if (cand !== correctFinish && !distractors.includes(cand)) distractors.push(cand);
        else break;
      }
      const options = [correctFinish, ...distractors].sort((a, b) =>
        (a + idx).localeCompare(b + idx)
      );
      return {
        surah: surahMeta.name,
        ayahNumber: ayah.ayah_number,
        startText: `«${startText} ...»`,
        correctFinish,
        options,
      };
    });
  }, [loadedAyahs, surahMeta.name]);

  const dynamicChoiceQuestions = useMemo(() => {
    if (loadedAyahs.length < 2) return [];
    const list = [];
    const maxQ = Math.min(5, loadedAyahs.length - 1);
    for (let i = 0; i < maxQ; i++) {
      const current = loadedAyahs[i];
      const next = loadedAyahs[i + 1];
      const otherOptions = loadedAyahs
        .filter((a) => a.ayah_number !== current.ayah_number && a.ayah_number !== next.ayah_number)
        .slice(0, 3)
        .map((a) => `«${a.ayah_text}»`);
      const correctOption = `«${next.ayah_text}»`;
      const options = [correctOption, ...otherOptions].sort((a, b) =>
        (a + i).localeCompare(b + i)
      );
      list.push({
        surah: surahMeta.name,
        prompt: `ما هي الآية التالية لقوله تعالى (الآية ${current.ayah_number}): «${current.ayah_text}»؟`,
        correctOption,
        options,
      });
    }
    return list;
  }, [loadedAyahs, surahMeta.name]);

  const dynamicReorderTarget = useMemo(() => {
    return loadedAyahs.slice(0, Math.min(4, loadedAyahs.length)).map((a) => a.ayah_text);
  }, [loadedAyahs]);

  // Complete Quiz State
  const [completeIdx, setCompleteIdx] = useState<number>(0);
  const [completeSelected, setCompleteSelected] = useState<string | null>(null);
  const [completeScore, setCompleteScore] = useState<number>(0);
  const [completeFinished, setCompleteFinished] = useState<boolean>(false);

  // Choice Quiz State
  const [choiceIdx, setChoiceIdx] = useState<number>(0);
  const [choiceSelected, setChoiceSelected] = useState<string | null>(null);
  const [choiceScore, setChoiceScore] = useState<number>(0);
  const [choiceFinished, setChoiceFinished] = useState<boolean>(false);

  // Reorder Quiz State
  const [reorderItems, setReorderItems] = useState<string[]>([]);
  const [reorderChecked, setReorderChecked] = useState<boolean>(false);
  const [reorderSuccess, setReorderSuccess] = useState<boolean>(false);

  useEffect(() => {
    if (dynamicReorderTarget.length > 0) {
      const copy = [...dynamicReorderTarget];
      if (copy.length > 1) {
        const first = copy.shift()!;
        copy.push(first);
      }
      setReorderItems(copy);
      setReorderChecked(false);
      setReorderSuccess(false);
    }
  }, [dynamicReorderTarget]);

  const handleAnswerComplete = (opt: string) => {
    if (completeSelected || dynamicCompleteQuestions.length === 0) return;
    setCompleteSelected(opt);
    const q = dynamicCompleteQuestions[completeIdx];
    const isCorrect = opt === q.correctFinish;

    if (isCorrect) {
      setCompleteScore((prev) => prev + 1);
      soundManager.triggerHaptic(50);
      onShowToast('إجابة صحيحة! أحسنت بارك الله فيك');
    } else {
      soundManager.triggerHaptic(30);
      onShowToast('إجابة غير دقيقة! راجع الآية الكريمة');
    }

    setTimeout(() => {
      if (completeIdx < dynamicCompleteQuestions.length - 1) {
        setCompleteIdx((prev) => prev + 1);
        setCompleteSelected(null);
      } else {
        setCompleteFinished(true);
      }
    }, 1100);
  };

  const handleAnswerChoice = (opt: string) => {
    if (choiceSelected || dynamicChoiceQuestions.length === 0) return;
    setChoiceSelected(opt);
    const q = dynamicChoiceQuestions[choiceIdx];
    const isCorrect = opt === q.correctOption;

    if (isCorrect) {
      setChoiceScore((prev) => prev + 1);
      soundManager.triggerHaptic(50);
      onShowToast('ممتاز! إجابة صحيحة');
    } else {
      soundManager.triggerHaptic(30);
    }

    setTimeout(() => {
      if (choiceIdx < dynamicChoiceQuestions.length - 1) {
        setChoiceIdx((prev) => prev + 1);
        setChoiceSelected(null);
      } else {
        setChoiceFinished(true);
      }
    }, 1100);
  };

  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const next = [...reorderItems];
    const temp = next[index - 1];
    next[index - 1] = next[index];
    next[index] = temp;
    setReorderItems(next);
  };

  const handleMoveDown = (index: number) => {
    if (index === reorderItems.length - 1) return;
    const next = [...reorderItems];
    const temp = next[index + 1];
    next[index + 1] = next[index];
    next[index] = temp;
    setReorderItems(next);
  };

  const checkReorder = () => {
    const isExact = reorderItems.every((item, idx) => item === dynamicReorderTarget[idx]);
    setReorderChecked(true);
    setReorderSuccess(isExact);
    if (isExact) {
      soundManager.triggerHaptic(60);
      onShowToast('ما شاء الله! رتبت الآيات بالشكل الصحيح');
    } else {
      soundManager.triggerHaptic(30);
      onShowToast('الترتيب غير مكتمل الدقة، حاول مرة أخرى');
    }
  };

  const resetComplete = () => {
    setCompleteIdx(0);
    setCompleteSelected(null);
    setCompleteScore(0);
    setCompleteFinished(false);
  };

  const resetChoice = () => {
    setChoiceIdx(0);
    setChoiceSelected(null);
    setChoiceScore(0);
    setChoiceFinished(false);
  };

  const resetReorder = () => {
    const copy = [...dynamicReorderTarget];
    if (copy.length > 1) {
      const first = copy.shift()!;
      copy.push(first);
    }
    setReorderItems(copy);
    setReorderChecked(false);
    setReorderSuccess(false);
  };

  return (
    <div className="space-y-4 select-none text-right font-cairo" dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between bg-white px-4 py-3 rounded-2xl border border-[#E6E6F0] shadow-2xs">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-[#25263A] hover:text-[#5B5FEF] font-bold text-sm transition-colors cursor-pointer"
        >
          <ArrowRight className="w-4 h-4 text-[#5B5FEF]" />
          <span>رجوع للتحفيظ</span>
        </button>

        <div className="flex items-center gap-2">
          <InteractiveMushafSvg size={22} color="#E8B84A" />
          <div className="text-center">
            <h2 className="text-base font-black text-[#25263A]">اختبر حفظك</h2>
            <span className="text-[11px] text-[#4145C7] font-bold block">
              التصفح التفاعلي واختبارات تثبيت القرآن الكريم
            </span>
          </div>
        </div>

        <div className="w-10" />
      </div>

      {/* 5 Quiz Types Nav (مع إبراز التصفح التفاعلي كنوع رئيسي) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {[
          {
            id: 'interactive_browsing' as QuizType,
            label: 'التصفح التفاعلي',
            icon: <InteractiveMushafSvg size={16} color="currentColor" />,
          },
          {
            id: 'progressive_recite' as QuizType,
            label: 'إخفاء وتسميع كتابي',
            icon: <EyeOff className="w-4 h-4" />,
          },
          {
            id: 'complete' as QuizType,
            label: 'إكمال الآية',
            icon: <CompleteAyahSvg size={16} color="currentColor" />,
          },
          {
            id: 'reorder' as QuizType,
            label: 'ترتيب الآيات',
            icon: <ReorderAyahsSvg size={16} color="currentColor" />,
          },
          {
            id: 'choice' as QuizType,
            label: 'اختيار الآية',
            icon: <ChoiceAyahSvg size={16} color="currentColor" />,
          },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveQuizType(tab.id)}
            className={`py-2.5 px-2.5 rounded-2xl border text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeQuizType === tab.id
                ? 'bg-[#5B5FEF] text-white border-[#5B5FEF] shadow-xs'
                : 'bg-white border-[#E6E6F0] text-[#25263A] hover:bg-[#F7F7FC]'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* ── Type 0 (Featured): التصفح التفاعلي (إكمال الآيات بالضغط على الحروف الناقصة) ── */}
      {activeQuizType === 'interactive_browsing' && (
        <InteractiveBrowsingQuiz
          onShowToast={onShowToast}
          initialSurahId={selectedSurahId}
          embedded
        />
      )}

      {/* شريط اختيار السورة لبقية الاختبارات */}
      {activeQuizType !== 'interactive_browsing' && (
        <div className="bg-white rounded-2xl px-4 py-3 border border-[#E6E6F0] flex items-center justify-between gap-2">
          <span className="text-xs font-black text-[#25263A]">السورة المختارة للاختبار:</span>
          <select
            value={selectedSurahId}
            onChange={(e) => {
              setSelectedSurahId(Number(e.target.value));
              setRevealedKeys(new Set());
              setTypedText('');
              setWriteChecked(false);
              resetComplete();
              resetChoice();
            }}
            className="bg-[#F7F7FC] border border-[#E6E6F0] rounded-xl px-3 py-1.5 text-xs font-bold text-[#25263A] focus:outline-none"
          >
            {SURAH_LIST.map((s) => (
              <option key={s.number} value={s.number}>
                {s.number}. سورة {s.name} ({s.numberOfAyahs} آية)
              </option>
            ))}
          </select>
        </div>
      )}

      {/* ── Type 1: إخفاء الآيات تدريجياً والتسميع بالكتابة ── */}
      {activeQuizType === 'progressive_recite' && (
        <div className="bg-white rounded-3xl p-5 sm:p-6 border-2 border-[#E6E6F0] shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#E6E6F0]">
            <span className="text-xs font-black text-[#25263A]">
              سورة {surahMeta.name} (أول {passageAyahs.length} آيات)
            </span>

            <div className="grid grid-cols-2 gap-1.5 bg-[#F7F7FC] p-1 rounded-xl border border-[#E6E6F0]">
              <button
                type="button"
                onClick={() => setReciteSubMode('hide')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  reciteSubMode === 'hide'
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'text-[#25263A] hover:bg-white/60'
                }`}
              >
                <EyeOff className="w-3.5 h-3.5" />
                <span>إخفاء تدريجي (لمس)</span>
              </button>
              <button
                type="button"
                onClick={() => setReciteSubMode('write')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  reciteSubMode === 'write'
                    ? 'bg-[#5B5FEF] text-white shadow-2xs'
                    : 'text-[#25263A] hover:bg-white/60'
                }`}
              >
                <Keyboard className="w-3.5 h-3.5" />
                <span>التسميع بالكتابة</span>
              </button>
            </div>
          </div>

          {reciteSubMode === 'hide' ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-xs font-bold text-[#25263A] flex items-center gap-1.5">
                  <Hand className="w-3.5 h-3.5 text-[#5B5FEF]" />
                  <span>وضع التسميع: اختر نسبة الإخفاء واضغط على النص لإظهاره:</span>
                </span>

                <div className="flex items-center gap-1.5">
                  <div className="flex items-center bg-[#F7F7FC] p-0.5 rounded-lg border border-[#E6E6F0]">
                    <button
                      type="button"
                      onClick={() => setMaskStyle('blur')}
                      className={`px-2 py-1 rounded-md text-[11px] font-bold cursor-pointer ${
                        maskStyle === 'blur'
                          ? 'bg-white text-[#25263A] shadow-2xs'
                          : 'text-[#77798C]'
                      }`}
                    >
                      نص مموه
                    </button>
                    <button
                      type="button"
                      onClick={() => setMaskStyle('hidden')}
                      className={`px-2 py-1 rounded-md text-[11px] font-bold cursor-pointer ${
                        maskStyle === 'hidden'
                          ? 'bg-white text-[#25263A] shadow-2xs'
                          : 'text-[#77798C]'
                      }`}
                    >
                      نص مخفي
                    </button>
                  </div>

                  {revealedKeys.size > 0 && (
                    <button
                      type="button"
                      onClick={() => setRevealedKeys(new Set())}
                      className="px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 text-[#25263A] text-[11px] font-bold cursor-pointer"
                    >
                      إعادة الإخفاء
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-5 gap-1.5">
                {([0, 25, 50, 75, 100] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => {
                      setHideLevel(lvl);
                      setRevealedKeys(new Set());
                    }}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                      hideLevel === lvl
                        ? 'bg-[#5B5FEF] text-white border-[#5B5FEF]'
                        : 'bg-[#F7F7FC] text-[#25263A] border-[#E6E6F0]'
                    }`}
                  >
                    {lvl === 0 ? 'إظهار الكل' : `إخفاء ${lvl}%`}
                  </button>
                ))}
              </div>

              <div className="p-4 sm:p-6 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] font-amiri text-2xl sm:text-3xl leading-[2.6] text-[#25263A]">
                {passageAyahs.map((ayah, aIdx) => {
                  const ayahNumber = ayah.ayah_number;
                  const words = (ayah.ayah_text || '').trim().split(/\s+/).filter(Boolean);
                  return (
                    <React.Fragment key={ayahNumber}>
                      {words.map((word, wIdx) => {
                        const key = `${ayahNumber}-${wIdx}`;
                        const hidden = isWordHiddenAtLevel(wIdx, words.length, aIdx, hideLevel);
                        const revealed = revealedKeys.has(key);

                        if (!hidden) {
                          return (
                            <span key={key} className="inline-block mx-1">
                              {word}
                            </span>
                          );
                        }

                        if (revealed) {
                          return (
                            <button
                              key={key}
                              type="button"
                              onClick={() => toggleRevealWord(key)}
                              className="inline-block mx-1 px-2 py-0.5 rounded-xl bg-[#4CAF82]/12 border border-[#4CAF82]/40 text-[#4CAF82] font-bold cursor-pointer"
                            >
                              {word}
                            </button>
                          );
                        }

                        if (maskStyle === 'blur') {
                          return (
                            <button
                              key={key}
                              type="button"
                              onClick={() => toggleRevealWord(key)}
                              className="inline-block mx-1 px-2 py-0.5 rounded-xl bg-[#F7F7FC] hover:bg-[#EEEEFF]/70 border border-dashed border-[#5B5FEF]/70 text-[#25263A] cursor-pointer align-middle"
                            >
                              <span
                                className="inline-block select-none pointer-events-none"
                                style={{
                                  filter: 'blur(5.5px)',
                                  WebkitFilter: 'blur(5.5px)',
                                  opacity: 0.75,
                                }}
                              >
                                {word}
                              </span>
                            </button>
                          );
                        }

                        return (
                          <button
                            key={key}
                            type="button"
                            onClick={() => toggleRevealWord(key)}
                            className="inline-flex items-center justify-center mx-1 px-3 py-0.5 rounded-xl bg-[#EEEEFF] hover:bg-[#EEEEFF] border-2 border-dashed border-[#5B5FEF] text-[#4145C7] font-cairo text-sm font-bold align-middle cursor-pointer"
                          >
                            ••••
                          </button>
                        );
                      })}
                      <span className="inline-flex items-center justify-center w-7 h-7 mx-1.5 text-xs font-bold rounded-full border border-[#E6E6F0] text-[#5B5FEF] align-middle">
                        ﴿{ayahNumber}﴾
                      </span>
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-[#25263A]">اكتب آيات سورة {surahMeta.name} من حفظك:</span>
                <span className="text-[#4CAF82]">
                  الدقة: {writtenCheckResult.matchedCount} / {writtenCheckResult.total} (
                  {writtenCheckResult.accuracy}%)
                </span>
              </div>

              <textarea
                rows={4}
                value={typedText}
                onChange={(e) => setTypedText(e.target.value)}
                placeholder="اكتب الآيات هنا بدون الحاجة للتشكيل..."
                className="w-full p-3.5 rounded-xl bg-[#F7F7FC] border-2 border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none font-amiri text-xl text-[#25263A]"
              />

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setWriteChecked(true)}
                  className="px-4 py-2 rounded-xl bg-[#5B5FEF] text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>تحقق من التسميع</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTypedText('');
                    setWriteChecked(false);
                  }}
                  className="px-3 py-2 rounded-xl bg-stone-100 text-[#25263A] font-bold text-xs cursor-pointer"
                >
                  إعادة الضبط
                </button>
              </div>

              <div className="p-4 rounded-2xl bg-[#F7F7FC] border border-[#E6E6F0] font-amiri text-xl leading-[2.4]">
                {writtenCheckResult.items.map((it, idx) => {
                  const key = `quiz-w-${idx}`;
                  const revealed = revealedKeys.has(key);
                  if (it.isMatch) {
                    return (
                      <span
                        key={idx}
                        className="inline-block mx-1 px-2 py-0.5 rounded-lg bg-[#4CAF82]/12 text-[#4CAF82] border border-[#4CAF82]/30 font-bold"
                      >
                        {it.orig}
                      </span>
                    );
                  }
                  if (writeChecked && it.typed) {
                    return (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 mx-1 px-2 py-0.5 rounded-lg bg-[#D95C6A]/10 text-[#D95C6A] border border-[#D95C6A]/30 font-bold"
                      >
                        <span className="line-through opacity-75">{it.typed}</span>
                        <span className="text-[#4CAF82]">{it.orig}</span>
                      </span>
                    );
                  }
                  if (revealed) {
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => toggleRevealWord(key)}
                        className="inline-block mx-1 px-2 py-0.5 rounded-lg bg-[#F7F7FC] text-[#4145C7] border border-[#5B5FEF] font-bold cursor-pointer"
                      >
                        {it.orig}
                      </button>
                    );
                  }
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => toggleRevealWord(key)}
                      className="inline-block mx-1 px-2.5 py-0.5 rounded-lg bg-[#EEEEFF] text-[#4145C7] border border-dashed border-[#5B5FEF] font-cairo text-xs font-bold cursor-pointer"
                    >
                      ••••
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Type 2: إكمال الآية ── */}
      {activeQuizType === 'complete' && dynamicCompleteQuestions.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border-2 border-[#E6E6F0] shadow-xs text-center space-y-4">
          {!completeFinished ? (
            <>
              <div className="flex items-center justify-between text-xs font-bold text-[#77798C] border-b border-[#E6E6F0] pb-2">
                <span>سورة {dynamicCompleteQuestions[completeIdx].surah}</span>
                <span>
                  سؤال {completeIdx + 1} من {dynamicCompleteQuestions.length}
                </span>
              </div>

              <div className="p-4 bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0] min-h-[100px] flex items-center justify-center">
                <p className="font-amiri text-xl sm:text-2xl text-[#25263A] leading-relaxed">
                  {dynamicCompleteQuestions[completeIdx].startText}
                </p>
              </div>

              <p className="text-xs font-bold text-[#25263A]">
                اختر الكلمة الصحيحة لإكمال الآية الكريمة:
              </p>

              <div className="grid grid-cols-2 gap-2.5 pt-2">
                {dynamicCompleteQuestions[completeIdx].options.map((opt) => {
                  const isCorrect = opt === dynamicCompleteQuestions[completeIdx].correctFinish;
                  const isSelected = completeSelected === opt;

                  let btnClass = 'bg-[#F7F7FC] border-[#E6E6F0] hover:bg-[#F7F7FC] text-[#25263A]';
                  if (completeSelected) {
                    if (isCorrect) btnClass = 'bg-[#5B5FEF] text-white border-[#4CAF82]';
                    else if (isSelected) btnClass = 'bg-[#D95C6A] text-white border-[#D95C6A]';
                  }

                  return (
                    <button
                      key={opt}
                      type="button"
                      disabled={!!completeSelected}
                      onClick={() => handleAnswerComplete(opt)}
                      className={`py-3 px-4 rounded-xl border font-amiri text-lg font-bold transition-all cursor-pointer ${btnClass}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="py-6 space-y-3">
              <div className="w-14 h-14 mx-auto rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                <TrophyMedalSvg size={30} color="#E8B84A" />
              </div>
              <h3 className="text-lg font-black text-[#25263A]">اكتمل اختبار إكمال الآية!</h3>
              <p className="text-sm text-[#4145C7] font-bold">
                نتيجتك: {completeScore} من {dynamicCompleteQuestions.length}
              </p>
              <div className="flex items-center justify-center gap-1 text-[#5B5FEF]">
                {Array.from({ length: dynamicCompleteQuestions.length }).map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${i < completeScore ? 'fill-[#E8B84A]' : 'text-stone-300'}`}
                  />
                ))}
              </div>
              <button
                type="button"
                onClick={resetComplete}
                className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#5B5FEF] text-white font-bold text-xs shadow-xs hover:brightness-105 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة الاختبار</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* ── Type 3: ترتيب الآيات ── */}
      {activeQuizType === 'reorder' && (
        <div className="bg-white rounded-3xl p-6 border-2 border-[#E6E6F0] shadow-xs space-y-4">
          <div className="flex items-center justify-between text-xs font-bold text-[#77798C] border-b border-[#E6E6F0] pb-2">
            <span>سورة {surahMeta.name}</span>
            <span>رتّب الآيات ترتيباً صحيحاً</span>
          </div>

          <p className="text-xs text-[#25263A] font-bold">
            استخدم أزرار الرفع والخفض لوضع كل آية في موضعها الصحيح حسب المصحف:
          </p>

          <div className="space-y-2">
            {reorderItems.map((verse, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 rounded-xl bg-[#F7F7FC] border border-[#E6E6F0]"
              >
                <span className="w-6 h-6 rounded-full bg-[#EEEEFF] text-[#4145C7] text-xs font-black flex items-center justify-center">
                  {idx + 1}
                </span>

                <p className="font-amiri text-base sm:text-lg text-[#25263A] font-bold flex-1 px-3">
                  «{verse}»
                </p>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleMoveUp(idx)}
                    disabled={idx === 0}
                    className="p-1.5 rounded-lg border border-[#E6E6F0] text-[#25263A] hover:bg-[#F7F7FC] disabled:opacity-20 cursor-pointer"
                    title="تحريك لأعلى"
                  >
                    <ArrowUpSvg size={14} />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMoveDown(idx)}
                    disabled={idx === reorderItems.length - 1}
                    className="p-1.5 rounded-lg border border-[#E6E6F0] text-[#25263A] hover:bg-[#F7F7FC] disabled:opacity-20 cursor-pointer"
                    title="تحريك لأسفل"
                  >
                    <ArrowDownSvg size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {reorderChecked && (
            <div
              className={`p-3 rounded-2xl text-center text-xs font-black ${
                reorderSuccess
                  ? 'bg-[#4CAF82]/12 text-[#4145C7]'
                  : 'bg-[#D95C6A]/15 text-[#D95C6A]'
              }`}
            >
              {reorderSuccess
                ? 'ما شاء الله! الترتيب مطابق للمصحف الشريف 100%'
                : 'الترتيب يحتوي على خطأ، حاول تصحيح المواضع'}
            </div>
          )}

          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={checkReorder}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-[#5B5FEF] to-[#4145C7] text-white font-black text-xs shadow-xs hover:brightness-105 cursor-pointer"
            >
              تحقق من الترتيب
            </button>
            <button
              type="button"
              onClick={resetReorder}
              className="px-4 py-3 rounded-xl bg-[#F7F7FC] hover:bg-stone-200 text-[#25263A] font-bold text-xs cursor-pointer"
            >
              إعادة ضبط
            </button>
          </div>
        </div>
      )}

      {/* ── Type 4: اختيار الآية الصحيحة ── */}
      {activeQuizType === 'choice' && dynamicChoiceQuestions.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border-2 border-[#E6E6F0] shadow-xs space-y-4">
          {!choiceFinished ? (
            <>
              <div className="flex items-center justify-between text-xs font-bold text-[#77798C] border-b border-[#E6E6F0] pb-2">
                <span>سورة {dynamicChoiceQuestions[choiceIdx].surah}</span>
                <span>
                  سؤال {choiceIdx + 1} من {dynamicChoiceQuestions.length}
                </span>
              </div>

              <div className="p-4 bg-[#F7F7FC] rounded-2xl border border-[#E6E6F0] text-center">
                <p className="font-amiri text-base sm:text-lg font-bold text-[#25263A] leading-relaxed">
                  {dynamicChoiceQuestions[choiceIdx].prompt}
                </p>
              </div>

              <div className="space-y-2 pt-2">
                {dynamicChoiceQuestions[choiceIdx].options.map((opt) => {
                  const isCorrect = opt === dynamicChoiceQuestions[choiceIdx].correctOption;
                  const isSelected = choiceSelected === opt;

                  let btnClass = 'bg-[#F7F7FC] border-[#E6E6F0] hover:bg-[#F7F7FC] text-[#25263A]';
                  if (choiceSelected) {
                    if (isCorrect) btnClass = 'bg-[#5B5FEF] text-white border-[#4CAF82]';
                    else if (isSelected) btnClass = 'bg-[#D95C6A] text-white border-[#D95C6A]';
                  }

                  return (
                    <button
                      key={opt}
                      type="button"
                      disabled={!!choiceSelected}
                      onClick={() => handleAnswerChoice(opt)}
                      className={`w-full py-3 px-4 rounded-xl border font-amiri text-base sm:text-lg font-bold text-right transition-all cursor-pointer ${btnClass}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="py-6 text-center space-y-3">
              <div className="w-14 h-14 mx-auto rounded-full bg-[#F7F7FC] border border-[#5B5FEF] flex items-center justify-center">
                <TrophyMedalSvg size={30} color="#E8B84A" />
              </div>
              <h3 className="text-lg font-black text-[#25263A]">اكتمل اختبار اختيار الآية!</h3>
              <p className="text-sm text-[#4145C7] font-bold">
                نتيجتك: {choiceScore} من {dynamicChoiceQuestions.length}
              </p>
              <button
                type="button"
                onClick={resetChoice}
                className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#5B5FEF] text-white font-bold text-xs shadow-xs hover:brightness-105 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة الاختبار</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
