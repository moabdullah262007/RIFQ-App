import React, { useState, useMemo, useEffect, useCallback } from 'react';
import {
  ArbainHadithItem,
  ArbainThemeCategory,
  ARBAIN_THEMES,
} from '../../data/arbainNawawiyaData';
import {
  initArbainNawawiyaSqliteTables,
  loadArbainHadithsFromStorage,
  loadArbainFavorites,
  toggleArbainFavoriteInStorage,
  loadArbainMemorized,
  toggleArbainMemorizedInStorage,
  loadArbainReadCounts,
  incrementArbainReadCount,
  resetArbainReadCount,
  searchArbainHadithsInStorage,
} from '../../utils/arbainNawawiyaSqlite';

type ArbainSubScreen = 'home' | 'detail' | 'search' | 'favorites';

interface ArbainNawawiyaViewProps {
  onBack: () => void;
  initialHadithNumber?: number | null;
}

/**
 * أيقونة القسم الرئيسية: كتاب + رقم 40 (SVG ذهبي #E8B84A و #E8B84A مع الأخضر #4CAF82 بدون أي لون بني)
 */
export const ArbainBook40Svg: React.FC<{ size?: number; className?: string }> = ({
  size = 48,
  className = '',
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 48 48"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="arbainGoldGrad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#E8B84A" />
        <stop offset="100%" stopColor="#E8B84A" />
      </linearGradient>
    </defs>
    {/* إطار دائري ذهبي مزدوج وخلفية بيج */}
    <circle cx="24" cy="24" r="22" fill="#F7F7FC" stroke="url(#arbainGoldGrad)" strokeWidth="2" />
    <circle cx="24" cy="24" r="19" stroke="#5B5FEF" strokeWidth="0.8" strokeDasharray="2 2" />

    {/* وسام الرقم 40 الذهبي أعلى الكتاب */}
    <rect
      x="14"
      y="8"
      width="20"
      height="11"
      rx="5.5"
      fill="#FFFFFF"
      stroke="url(#arbainGoldGrad)"
      strokeWidth="1.6"
    />
    <text
      x="24"
      y="16.2"
      textAnchor="middle"
      fill="#E8B84A"
      fontSize="8.5"
      fontWeight="800"
      fontFamily="Cairo, sans-serif"
    >
      40
    </text>

    {/* الكتاب الإسلامي المفتوح */}
    <path
      d="M10 23.5C10 22.4 10.9 21.5 12 21.5H22C23.1 21.5 24 22.4 24 23.5V36.5C24 35.5 23.1 34.8 21.8 34.8H11.8C10.8 34.8 10 34 10 33V23.5Z"
      fill="#FFFFFF"
      stroke="url(#arbainGoldGrad)"
      strokeWidth="1.9"
      strokeLinejoin="round"
    />
    <path
      d="M38 23.5C38 22.4 37.1 21.5 36 21.5H26C24.9 21.5 24 22.4 24 23.5V36.5C24 35.5 24.9 34.8 26.2 34.8H36.2C37.2 34.8 38 34 38 33V23.5Z"
      fill="#FFFFFF"
      stroke="url(#arbainGoldGrad)"
      strokeWidth="1.9"
      strokeLinejoin="round"
    />
    {/* سطور الحديث الخضراء والذهبية داخل الكتاب */}
    <path d="M13 26H21M27 26H35" stroke="#4CAF82" strokeWidth="1.5" strokeLinecap="round" />
    <path d="M13 29.5H20.5M27.5 29.5H35" stroke="#5B5FEF" strokeWidth="1.4" strokeLinecap="round" />
    {/* حامل المصحف / الكتاب السفلي */}
    <path d="M14 38.5L24 35.8L34 38.5" stroke="#4CAF82" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/**
 * وسام رقم الحديث الذهبي (SVG 1..42) بدون أي لون بني
 */
const HadithNumberMedallionSvg: React.FC<{ number: number; size?: number }> = ({
  number,
  size = 44,
}) => (
  <svg width={size} height={size} viewBox="0 0 44 44" fill="none" className="shrink-0">
    <circle cx="22" cy="22" r="20" fill="#F7F7FC" stroke="#5B5FEF" strokeWidth="1.6" />
    <polygon
      points="22,4 26.5,9.5 33.5,8.5 34.5,15.5 40,20 35.5,25.5 36.5,32.5 29.5,33.5 25,39 19,39 14.5,33.5 7.5,32.5 8.5,25.5 4,20 9.5,15.5 10.5,8.5 17.5,9.5"
      fill="#FFFFFF"
      stroke="#E8B84A"
      strokeWidth="1.1"
    />
    <circle cx="22" cy="22" r="12.5" fill="#F7F7FC" stroke="#4CAF82" strokeWidth="0.9" strokeDasharray="2 1.5" />
    <text
      x="22"
      y="25.5"
      textAnchor="middle"
      fill="#4CAF82"
      fontSize="12.5"
      fontWeight="800"
      fontFamily="Cairo, sans-serif"
    >
      {number}
    </text>
  </svg>
);

/**
 * أيقونات الأزرار والعمليات بصيغة SVG ذهبية وخضراء (بدون إيموجي وبدون لون بني)
 */
const ActionSvgIcon: React.FC<{
  name:
    | 'back'
    | 'search'
    | 'bookmark'
    | 'bookmark_filled'
    | 'copy'
    | 'share'
    | 'check'
    | 'book'
    | 'vocab'
    | 'benefits'
    | 'narrator'
    | 'reference'
    | 'chevron_down'
    | 'chevron_left'
    | 'chevron_right'
    | 'moon'
    | 'sun'
    | 'repeat'
    | 'close';
  size?: number;
  color?: string;
}> = ({ name, size = 18, color = '#E8B84A' }) => {
  switch (name) {
    case 'back':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M9 18L15 12L9 6" stroke={color} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'search':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <circle cx="11" cy="11" r="7" stroke={color} strokeWidth="2" />
          <path d="M20 20L16.5 16.5" stroke={color} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    case 'bookmark':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path
            d="M19 21L12 16L5 21V5C5 3.9 5.9 3 7 3H17C18.1 3 19 3.9 19 5V21Z"
            stroke={color}
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'bookmark_filled':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path
            d="M19 21L12 16L5 21V5C5 3.9 5.9 3 7 3H17C18.1 3 19 3.9 19 5V21Z"
            fill={color}
            stroke={color}
            strokeWidth="2"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'copy':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <rect x="9" y="9" width="11" height="11" rx="2" stroke={color} strokeWidth="1.9" />
          <path
            d="M5 15H4C2.9 15 2 14.1 2 13V4C2 2.9 2.9 2 4 2H13C14.1 2 15 2.9 15 4V5"
            stroke={color}
            strokeWidth="1.9"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'share':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <circle cx="18" cy="5" r="3" stroke={color} strokeWidth="1.9" />
          <circle cx="6" cy="12" r="3" stroke={color} strokeWidth="1.9" />
          <circle cx="18" cy="19" r="3" stroke={color} strokeWidth="1.9" />
          <path d="M8.6 13.5L15.4 17.5M15.4 6.5L8.6 10.5" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
        </svg>
      );
    case 'check':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M20 6L9 17L4 12" stroke={color} strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'book':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path
            d="M4 19.5C4 18.1 5.1 17 6.5 17H20V4H6.5C5.1 4 4 5.1 4 6.5V19.5Z"
            stroke={color}
            strokeWidth="1.9"
            strokeLinejoin="round"
          />
          <path d="M8 8H16M8 12H14" stroke="#4CAF82" strokeWidth="1.7" strokeLinecap="round" />
        </svg>
      );
    case 'vocab':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <rect x="3" y="4" width="18" height="16" rx="3" stroke={color} strokeWidth="1.9" />
          <path d="M7 9H17M7 13H13M7 16.5H11" stroke="#4CAF82" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      );
    case 'benefits':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.9" />
          <path d="M8.5 12.5L11 15L15.5 9.5" stroke="#4CAF82" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'narrator':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="8" r="4" stroke={color} strokeWidth="1.9" />
          <path d="M5 20C5 16.7 8.1 14 12 14C15.9 14 19 16.7 19 20" stroke="#4CAF82" strokeWidth="1.9" strokeLinecap="round" />
        </svg>
      );
    case 'reference':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M12 3L4 7V17L12 21L20 17V7L12 3Z" stroke={color} strokeWidth="1.9" strokeLinejoin="round" />
          <path d="M12 11V21M4 7L12 11L20 7" stroke="#4CAF82" strokeWidth="1.7" />
        </svg>
      );
    case 'chevron_down':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M6 9L12 15L18 9" stroke={color} strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'chevron_left':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M15 18L9 12L15 6" stroke={color} strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'chevron_right':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M9 18L15 12L9 6" stroke={color} strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case 'moon':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path
            d="M20.4 14.8C19.2 15.3 17.9 15.5 16.5 15.5C11.3 15.5 7 11.2 7 6C7 4.6 7.3 3.3 7.8 2.1C4.4 3.5 2 6.9 2 10.9C2 16.2 6.3 20.5 11.6 20.5C15.6 20.5 19 18.1 20.4 14.8Z"
            stroke={color}
            strokeWidth="1.9"
            strokeLinejoin="round"
          />
        </svg>
      );
    case 'sun':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="4.5" stroke={color} strokeWidth="1.9" />
          <path
            d="M12 2V4.5M12 19.5V22M4.9 4.9L6.7 6.7M17.3 17.3L19.1 19.1M2 12H4.5M19.5 12H22M4.9 19.1L6.7 17.3M17.3 6.7L19.1 4.9"
            stroke={color}
            strokeWidth="1.9"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'repeat':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M17 2L21 6L17 10" stroke={color} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M3 11V9C3 6.8 4.8 5 7 5H21" stroke={color} strokeWidth="1.9" strokeLinecap="round" />
          <path d="M7 22L3 18L7 14" stroke="#4CAF82" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M21 13V15C21 17.2 19.2 19 17 19H3" stroke="#4CAF82" strokeWidth="1.9" strokeLinecap="round" />
        </svg>
      );
    case 'close':
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
          <path d="M18 6L6 18M6 6L18 18" stroke={color} strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
  }
};

export const ArbainNawawiyaView: React.FC<ArbainNawawiyaViewProps> = ({
  onBack,
  initialHadithNumber = null,
}) => {
  const [subScreen, setSubScreen] = useState<ArbainSubScreen>('home');
  const [previousScreen, setPreviousScreen] = useState<ArbainSubScreen>('home');
  const [hadiths, setHadiths] = useState<ArbainHadithItem[]>(() => loadArbainHadithsFromStorage());
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => loadArbainFavorites());
  const [memorizedIds, setMemorizedIds] = useState<string[]>(() => loadArbainMemorized());
  const [readCounts, setReadCounts] = useState<Record<string, number>>(() => loadArbainReadCounts());

  const [selectedTheme, setSelectedTheme] = useState<ArbainThemeCategory | 'all'>('all');
  const [selectedHadithNumber, setSelectedHadithNumber] = useState<number>(
    initialHadithNumber || 1
  );

  // Search filters
  const [searchQuery, setSearchQuery] = useState('');
  const [searchThemeFilter, setSearchThemeFilter] = useState<ArbainThemeCategory | 'all'>('all');
  const [searchSourceFilter, setSearchSourceFilter] = useState<string>('all');

  // Favorites tab: 'favorites' | 'memorized'
  const [savedTab, setSavedTab] = useState<'favorites' | 'memorized'>('favorites');

  // Detail screen collapsible sections
  const [openVocab, setOpenVocab] = useState(true);
  const [openExplanation, setOpenExplanation] = useState(true);
  const [openBenefits, setOpenBenefits] = useState(true);
  const [openNarrator, setOpenNarrator] = useState(true);
  const [openReference, setOpenReference] = useState(true);

  // Font scale & dark mode
  const [fontScale, setFontScale] = useState<number>(() => {
    const saved = localStorage.getItem('rifq_arbain_font_scale');
    return saved ? parseFloat(saved) : 1;
  });
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('rifq_arbain_dark_mode') === '1';
  });

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2500);
  }, []);

  useEffect(() => {
    initArbainNawawiyaSqliteTables();
    setHadiths(loadArbainHadithsFromStorage());
    setFavoriteIds(loadArbainFavorites());
    setMemorizedIds(loadArbainMemorized());
    setReadCounts(loadArbainReadCounts());
  }, []);

  useEffect(() => {
    if (initialHadithNumber) {
      setSelectedHadithNumber(initialHadithNumber);
      setSubScreen('detail');
    }
  }, [initialHadithNumber]);

  const toggleDarkMode = () => {
    const next = !isDarkMode;
    setIsDarkMode(next);
    localStorage.setItem('rifq_arbain_dark_mode', next ? '1' : '0');
  };

  const changeFontScale = (delta: number) => {
    const next = Math.min(1.35, Math.max(0.85, Number((fontScale + delta).toFixed(2))));
    setFontScale(next);
    localStorage.setItem('rifq_arbain_font_scale', String(next));
  };

  const handleToggleFavorite = (hadithId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = toggleArbainFavoriteInStorage(hadithId);
    setFavoriteIds(updated);
    showToast(
      updated.includes(hadithId)
        ? 'تم حفظ الحديث في المفضلة'
        : 'تمت إزالة الحديث من المفضلة'
    );
  };

  const handleToggleMemorized = (hadithId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = toggleArbainMemorizedInStorage(hadithId);
    setMemorizedIds(updated);
    showToast(
      updated.includes(hadithId)
        ? 'ما شاء الله! تم تسجيل الحديث في قائمة المحفوظات'
        : 'تم إلغاء تأشير الحفظ عن الحديث'
    );
  };

  const handleIncrementRead = (hadithId: string) => {
    const updated = incrementArbainReadCount(hadithId);
    setReadCounts(updated);
    const count = updated[hadithId] || 1;
    if (count === 7 && !memorizedIds.includes(hadithId)) {
      showToast('أتممت 7 قراءات للحديث! يمكنك تأشيره كمحفوظ');
    }
  };

  const handleResetRead = (hadithId: string) => {
    const updated = resetArbainReadCount(hadithId);
    setReadCounts(updated);
  };

  const formatHadithForShare = (item: ArbainHadithItem): string => {
    const vocabLines = item.vocabulary
      .map((v) => `• ${v.word}: ${v.meaning}`)
      .join('\n');
    const benefitLines = item.benefits
      .map((b, i) => `${i + 1}. ${b}`)
      .join('\n');

    return [
      `«الأربعون النووية» — ${item.arabicOrderLabel} (${item.number})`,
      `العنوان: ${item.title}`,
      `الراوي: ${item.narrator}`,
      '',
      `${item.hadithText}`,
      '',
      `التخريج: ${item.fullTakhrij}`,
      '',
      `معاني المفردات:`,
      vocabLines,
      '',
      `الشرح المختصر:`,
      item.explanation,
      '',
      `من فوائد الحديث:`,
      benefitLines,
      '',
      `المرجع: ${item.reference}`,
      `تطبيق رِفْق | RIFQ`,
    ].join('\n');
  };

  const handleCopyHadith = async (item: ArbainHadithItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = formatHadithForShare(item);
    try {
      await navigator.clipboard.writeText(text);
      showToast(`تم نسخ «${item.title}» مع الشرح والفوائد`);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      showToast(`تم نسخ «${item.title}» مع الشرح والفوائد`);
    }
  };

  const handleShareHadith = async (item: ArbainHadithItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = formatHadithForShare(item);
    if (navigator.share) {
      try {
        await navigator.share({
          title: `الأربعون النووية — ${item.title}`,
          text,
        });
        return;
      } catch {
        // Fallback to copy if share cancelled
      }
    }
    await handleCopyHadith(item);
  };

  const openHadithDetail = (hadithNumber: number, fromScreen: ArbainSubScreen) => {
    setPreviousScreen(fromScreen);
    setSelectedHadithNumber(hadithNumber);
    setSubScreen('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentHadith = useMemo(() => {
    return (
      hadiths.find((h) => h.number === selectedHadithNumber) || hadiths[0]
    );
  }, [hadiths, selectedHadithNumber]);

  const homeFilteredHadiths = useMemo(() => {
    if (selectedTheme === 'all') return hadiths;
    return hadiths.filter((h) => h.theme === selectedTheme);
  }, [hadiths, selectedTheme]);

  const searchResults = useMemo(() => {
    return searchArbainHadithsInStorage(
      hadiths,
      searchQuery,
      searchThemeFilter,
      searchSourceFilter
    );
  }, [hadiths, searchQuery, searchThemeFilter, searchSourceFilter]);

  const favoriteHadiths = useMemo(() => {
    return hadiths.filter((h) => favoriteIds.includes(h.id));
  }, [hadiths, favoriteIds]);

  const memorizedHadiths = useMemo(() => {
    return hadiths.filter((h) => memorizedIds.includes(h.id));
  }, [hadiths, memorizedIds]);

  const memorizedPercentage = Math.round((memorizedIds.length / hadiths.length) * 100);

  // Theme colors according to Rifq specification
  const bgMain = isDarkMode ? 'bg-[#25263A]' : 'bg-[#F7F7FC]';
  const cardBg = isDarkMode ? 'bg-[#25263A] border-[#E6E6F0]' : 'bg-[#FFFFFF] border-[#E6E6F0]';
  const textPrimary = isDarkMode ? 'text-[#F7F7FC]' : 'text-[#25263A]';
  const textSecondary = isDarkMode ? 'text-[#BDB5A8]' : 'text-[#77798C]';
  const softBeigeBg = isDarkMode ? 'bg-[#25263A]' : 'bg-[#F7F7FC]';

  return (
    <div
      dir="rtl"
      className={`min-h-screen ${bgMain} font-cairo pb-28 transition-colors duration-200 select-none`}
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-[#25263A] text-[#FFFFFF] border border-[#5B5FEF] px-5 py-2.5 rounded-xl shadow-lg flex items-center gap-2.5 text-sm font-bold animate-fade-in">
          <ActionSvgIcon name="check" size={18} color="#E8B84A" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          الشريط العلوي الموحد (رجوع + الأربعون النووية + بحث + مفضلة)
         ══════════════════════════════════════════════════════════════════ */}
      <header
        className={`sticky top-0 z-30 ${
          isDarkMode ? 'bg-[#25263A]/95' : 'bg-[#FFFFFF]/95'
        } backdrop-blur-md border-b border-[#E6E6F0] px-4 py-3 shadow-sm`}
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                if (subScreen === 'home') {
                  onBack();
                } else if (subScreen === 'detail') {
                  setSubScreen(previousScreen);
                } else {
                  setSubScreen('home');
                }
              }}
              aria-label="رجوع"
              className={`w-10 h-10 rounded-full ${softBeigeBg} border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] active:scale-95 transition-all cursor-pointer`}
            >
              <ActionSvgIcon name="back" size={20} color="#E8B84A" />
            </button>

            <div className="flex items-center gap-2.5">
              <ArbainBook40Svg size={38} />
              <div>
                <h1 className={`font-cairo font-bold text-lg md:text-xl ${textPrimary} leading-tight`}>
                  {subScreen === 'home' && 'الأربعون النووية'}
                  {subScreen === 'detail' && `${currentHadith.arabicOrderLabel}`}
                  {subScreen === 'search' && 'البحث في الأربعين النووية'}
                  {subScreen === 'favorites' && 'المفضلة والمحفوظات'}
                </h1>
                <p className={`text-xs ${textSecondary}`}>
                  {subScreen === 'home' && 'متن الأربعين النووية وتتمة ابن رجب (42 حديثًا موثقًا)'}
                  {subScreen === 'detail' && `${currentHadith.title} · ${currentHadith.shortSource}`}
                  {subScreen === 'search' && 'بحث فوري في المتن والرواة والشرح والفوائد'}
                  {subScreen === 'favorites' && `المفضلة (${favoriteIds.length}) · المحفوظات (${memorizedIds.length}/42)`}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSubScreen(subScreen === 'search' ? 'home' : 'search')}
              aria-label="بحث في الأحاديث"
              className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                subScreen === 'search'
                  ? 'bg-[#5B5FEF] border-[#5B5FEF]'
                  : `${softBeigeBg} border-[#E6E6F0] hover:border-[#5B5FEF]`
              }`}
            >
              <ActionSvgIcon
                name="search"
                size={18}
                color={subScreen === 'search' ? '#FFFFFF' : '#E8B84A'}
              />
            </button>

            <button
              type="button"
              onClick={() => setSubScreen(subScreen === 'favorites' ? 'home' : 'favorites')}
              aria-label="المفضلة والمحفوظات"
              className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                subScreen === 'favorites'
                  ? 'bg-[#5B5FEF] border-[#5B5FEF]'
                  : `${softBeigeBg} border-[#E6E6F0] hover:border-[#5B5FEF]`
              }`}
            >
              <ActionSvgIcon
                name={favoriteIds.length > 0 ? 'bookmark_filled' : 'bookmark'}
                size={18}
                color={subScreen === 'favorites' ? '#FFFFFF' : '#E8B84A'}
              />
            </button>

            <button
              type="button"
              onClick={toggleDarkMode}
              aria-label="تبديل الوضع الليلي"
              className={`w-10 h-10 rounded-full ${softBeigeBg} border border-[#E6E6F0] flex items-center justify-center hover:border-[#5B5FEF] transition-all cursor-pointer`}
            >
              <ActionSvgIcon name={isDarkMode ? 'sun' : 'moon'} size={18} color="#E8B84A" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 pt-4">
        {/* ══════════════════════════════════════════════════════════════════
            الشاشة 1: الرئيسية (بطاقة ترحيبية + تصفية + قائمة الـ 42 حديثًا)
           ══════════════════════════════════════════════════════════════════ */}
        {subScreen === 'home' && (
          <div className="space-y-5">
            {/* البطاقة الترحيبية */}
            <section
              className={`rounded-2xl border-2 border-[#5B5FEF] ${
                isDarkMode
                  ? 'bg-gradient-to-br from-[#25263A] via-[#25263A] to-[#25263A]'
                  : 'bg-gradient-to-br from-[#FFFFFF] via-[#F7F7FC] to-[#FFFFFF]'
              } p-5 shadow-sm relative overflow-hidden`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#4CAF82]">
                    <ActionSvgIcon name="book" size={16} color="#E8B84A" />
                    <span>الإمام يحيى بن شرف النووي (ت 676 هـ) وتتمة الحافظ ابن رجب (ت 795 هـ)</span>
                  </div>

                  <p className={`font-amiri text-lg md:text-xl leading-relaxed ${textPrimary}`}>
                    «مَنْ حَفِظَ عَلَى أُمَّتِي أَرْبَعِينَ حَدِيثًا مِنْ أَمْرِ دِينِهَا بَعَثَهُ اللَّهُ يَوْمَ الْقِيَامَةِ فِي زُمْرَةِ الْفُقَهَاءِ وَالْعُلَمَاءِ»
                  </p>

                  <p className={`text-xs md:text-sm ${textSecondary} leading-relaxed`}>
                    قال الإمام النووي رحمه الله في مقدمة الأربعين: «وقد اتفق العلماء على جواز العمل بالحديث الضعيف في فضائل الأعمال، ومع هذا فليس اعتمادي على هذا الحديث، بل على قوله صلى الله عليه وسلم في الأحاديث الصحيحة: لِيُبَلِّغِ الشَّاهِدُ مِنْكُمُ الْغَائِبَ، وقوله: نَضَّرَ اللَّهُ امْرَأً سَمِعَ مَقَالَتِي فَوَعَاهَا فَأَدَّاهَا كَمَا سَمِعَهَا».
                  </p>
                </div>

                {/* بطاقة إنجاز الحفظ */}
                <div
                  className={`shrink-0 md:w-56 rounded-xl ${softBeigeBg} border border-[#E6E6F0] p-3.5 flex flex-col justify-between gap-2`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold ${textPrimary}`}>متابعة حفظ الأربعين</span>
                    <span className="text-xs font-bold text-[#4CAF82]">
                      {memorizedIds.length} / {hadiths.length}
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-[#EEEEFF] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#4CAF82] rounded-full transition-all duration-300"
                      style={{ width: `${memorizedPercentage}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#77798C]">
                    <span>نسبة الإتمام: {memorizedPercentage}%</span>
                    <button
                      type="button"
                      onClick={() => {
                        setSavedTab('memorized');
                        setSubScreen('favorites');
                      }}
                      className="text-[#5B5FEF] font-bold hover:underline cursor-pointer"
                    >
                      عرض المحفوظات
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* أزرار التصفية الموضوعية التفاعلية */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
              {ARBAIN_THEMES.map((themeItem) => {
                const isSelected = selectedTheme === themeItem.id;
                const count =
                  themeItem.id === 'all'
                    ? hadiths.length
                    : hadiths.filter((h) => h.theme === themeItem.id).length;
                return (
                  <button
                    key={themeItem.id}
                    type="button"
                    onClick={() => setSelectedTheme(themeItem.id)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#5B5FEF] text-[#FFFFFF] border-[#5B5FEF] shadow-sm'
                        : `${cardBg} ${textPrimary} hover:border-[#5B5FEF]`
                    }`}
                  >
                    {themeItem.id === 'all' ? themeItem.label : `${themeItem.label} (${count})`}
                  </button>
                );
              })}
            </div>

            {/* شبكة / قائمة الأحاديث الأربعين (42 حديثاً) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {homeFilteredHadiths.map((item) => {
                const isFav = favoriteIds.includes(item.id);
                const isMem = memorizedIds.includes(item.id);
                return (
                  <article
                    key={item.id}
                    onClick={() => openHadithDetail(item.number, 'home')}
                    className={`rounded-2xl border ${cardBg} p-4 shadow-sm hover:border-[#5B5FEF] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between gap-3`}
                  >
                    <div className="space-y-2.5">
                      {/* رأس البطاقة: رقم الحديث + العنوان + المصدر */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <HadithNumberMedallionSvg number={item.number} size={44} />
                          <div>
                            <div className="flex items-center gap-1.5 text-[11px] text-[#77798C]">
                              <span>{item.arabicOrderLabel}</span>
                              <span aria-hidden="true">·</span>
                              <span className="text-[#4CAF82] font-bold">{item.shortSource}</span>
                            </div>
                            <h2 className={`font-cairo font-bold text-base ${textPrimary} mt-0.5`}>
                              {item.title}
                            </h2>
                          </div>
                        </div>

                        {/* أزرار سريعة: حفظ + مفضلة */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={(e) => handleToggleMemorized(item.id, e)}
                            title={isMem ? 'محفوظ' : 'تأشير كمحفوظ'}
                            aria-label={isMem ? 'محفوظ' : 'تأشير كمحفوظ'}
                            className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-all cursor-pointer ${
                              isMem
                                ? 'bg-[#4CAF82] border-[#4CAF82]'
                                : `${softBeigeBg} border-[#E6E6F0] hover:border-[#5B5FEF]`
                            }`}
                          >
                            <ActionSvgIcon
                              name="check"
                              size={15}
                              color={isMem ? '#FFFFFF' : '#4CAF82'}
                            />
                          </button>

                          <button
                            type="button"
                            onClick={(e) => handleToggleFavorite(item.id, e)}
                            title={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                            aria-label={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                            className={`w-8 h-8 rounded-lg border ${softBeigeBg} border-[#E6E6F0] hover:border-[#5B5FEF] flex items-center justify-center transition-all cursor-pointer`}
                          >
                            <ActionSvgIcon
                              name={isFav ? 'bookmark_filled' : 'bookmark'}
                              size={15}
                              color="#E8B84A"
                            />
                          </button>
                        </div>
                      </div>

                      {/* الراوي (بدون أي نجمة بجانب الاسم) */}
                      <div className="text-xs text-[#77798C] flex items-center gap-1.5">
                        <ActionSvgIcon name="narrator" size={14} color="#E8B84A" />
                        <span className="truncate">{item.narrator}</span>
                      </div>

                      {/* مقتطف متن الحديث بخط Amiri */}
                      <div
                        className={`rounded-xl ${softBeigeBg} border border-[#E6E6F0] p-3 font-amiri text-[16px] leading-[1.95] ${textPrimary} line-clamp-3`}
                      >
                        {item.hadithText}
                      </div>
                    </div>

                    {/* شريط الأزرار السفلي للبطاقة */}
                    <div className="pt-2 border-t border-[#E6E6F0] flex items-center justify-between gap-2">
                      <span className="text-[11px] text-[#77798C] truncate">
                        {item.theme} · {item.vocabulary.length} مفردات · {item.benefits.length} فوائد
                      </span>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={(e) => handleCopyHadith(item, e)}
                          className={`px-2.5 py-1.5 rounded-lg ${softBeigeBg} border border-[#E6E6F0] hover:border-[#5B5FEF] flex items-center gap-1 text-xs font-bold ${textPrimary} cursor-pointer`}
                        >
                          <ActionSvgIcon name="copy" size={13} color="#E8B84A" />
                          <span>نسخ</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => handleShareHadith(item, e)}
                          className={`px-2.5 py-1.5 rounded-lg ${softBeigeBg} border border-[#E6E6F0] hover:border-[#5B5FEF] flex items-center gap-1 text-xs font-bold ${textPrimary} cursor-pointer`}
                        >
                          <ActionSvgIcon name="share" size={13} color="#E8B84A" />
                          <span>مشاركة</span>
                        </button>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            openHadithDetail(item.number, 'home');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-[#5B5FEF] text-[#FFFFFF] flex items-center gap-1 text-xs font-bold hover:bg-[#4145C7] transition-colors cursor-pointer"
                        >
                          <span>الشرح</span>
                          <ActionSvgIcon name="chevron_left" size={14} color="#FFFFFF" />
                        </button>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            الشاشة 2: تفاصيل الحديث (المتن + المفردات + الشرح + الفوائد + الراوي + المرجع)
           ══════════════════════════════════════════════════════════════════ */}
        {subScreen === 'detail' && currentHadith && (
          <div className="space-y-4">
            {/* البطاقة الرئيسية للحديث الشريف */}
            <section
              className={`rounded-2xl border-2 border-[#5B5FEF] ${cardBg} p-5 md:p-6 shadow-sm space-y-4`}
            >
              {/* ترويسة الحديث */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#E6E6F0]">
                <div className="flex items-center gap-3">
                  <HadithNumberMedallionSvg number={currentHadith.number} size={50} />
                  <div>
                    <div className="flex items-center gap-2 text-xs text-[#77798C]">
                      <span>{currentHadith.arabicOrderLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span>{currentHadith.theme}</span>
                    </div>
                    <h2 className={`font-cairo font-bold text-xl md:text-2xl ${textPrimary} mt-0.5`}>
                      {currentHadith.title}
                    </h2>
                  </div>
                </div>

                {/* أزرار حجم الخط وتأشير الحفظ */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => changeFontScale(-0.08)}
                    aria-label="تصغير الخط"
                    className={`px-2.5 py-1.5 rounded-lg ${softBeigeBg} border border-[#E6E6F0] text-xs font-bold ${textPrimary} hover:border-[#5B5FEF] cursor-pointer`}
                  >
                    A-
                  </button>
                  <button
                    type="button"
                    onClick={() => changeFontScale(0.08)}
                    aria-label="تكبير الخط"
                    className={`px-2.5 py-1.5 rounded-lg ${softBeigeBg} border border-[#E6E6F0] text-xs font-bold ${textPrimary} hover:border-[#5B5FEF] cursor-pointer`}
                  >
                    A+
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleMemorized(currentHadith.id)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                      memorizedIds.includes(currentHadith.id)
                        ? 'bg-[#4CAF82] text-[#FFFFFF] border-[#4CAF82]'
                        : `${softBeigeBg} text-[#4CAF82] border-[#4CAF82]`
                    }`}
                  >
                    <ActionSvgIcon
                      name="check"
                      size={15}
                      color={memorizedIds.includes(currentHadith.id) ? '#FFFFFF' : '#4CAF82'}
                    />
                    <span>
                      {memorizedIds.includes(currentHadith.id) ? 'تم حفظ الحديث' : 'تأشير كمحفوظ'}
                    </span>
                  </button>
                </div>
              </div>

              {/* اسم الصحابي الراوي */}
              <div className={`flex items-center gap-2 text-xs md:text-sm ${textSecondary}`}>
                <ActionSvgIcon name="narrator" size={16} color="#E8B84A" />
                <span>الراوي:</span>
                <span className={`font-bold ${textPrimary}`}>{currentHadith.narrator}</span>
              </div>

              {/* نص الحديث الشريف بخط Amiri */}
              <div
                className={`rounded-2xl ${softBeigeBg} border border-[#E6E6F0] p-5 md:p-6 shadow-inner`}
              >
                <p
                  style={{ fontSize: `${Math.round(21 * fontScale)}px` }}
                  className={`font-amiri leading-[2.25] ${textPrimary} text-justify`}
                >
                  {currentHadith.hadithText}
                </p>
              </div>

              {/* التخريج والمصدر + عداد التكرار للحفظ */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                <div className="flex items-center gap-2 text-xs md:text-sm">
                  <ActionSvgIcon name="book" size={16} color="#E8B84A" />
                  <span className="text-[#77798C]">التخريج:</span>
                  <span className="font-bold text-[#4CAF82]">{currentHadith.fullTakhrij}</span>
                </div>

                {/* عداد تكرار قراءة الحديث لتثبيت الحفظ */}
                <div
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl ${softBeigeBg} border border-[#E6E6F0] self-start sm:self-auto`}
                >
                  <ActionSvgIcon name="repeat" size={16} color="#E8B84A" />
                  <span className={`text-xs ${textSecondary}`}>تكرار القراءة:</span>
                  <span className="text-xs font-bold text-[#4CAF82]">
                    {readCounts[currentHadith.id] || 0} / 7
                  </span>
                  <button
                    type="button"
                    onClick={() => handleIncrementRead(currentHadith.id)}
                    className="px-2.5 py-1 rounded-lg bg-[#5B5FEF] text-[#FFFFFF] text-xs font-bold hover:bg-[#4145C7] cursor-pointer"
                  >
                    + قراءة
                  </button>
                  {(readCounts[currentHadith.id] || 0) > 0 && (
                    <button
                      type="button"
                      onClick={() => handleResetRead(currentHadith.id)}
                      className="text-[11px] text-[#77798C] hover:underline cursor-pointer"
                    >
                      تصفير
                    </button>
                  )}
                </div>
              </div>
            </section>

            {/* القسم 1: معاني المفردات الغريبة */}
            <section className={`rounded-2xl border ${cardBg} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenVocab(!openVocab)}
                className="w-full px-5 py-4 flex items-center justify-between text-right cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <ActionSvgIcon name="vocab" size={20} color="#E8B84A" />
                  <h3 className={`font-cairo font-bold text-base ${textPrimary}`}>
                    معاني المفردات والكلمات الغريبة ({currentHadith.vocabulary.length})
                  </h3>
                </div>
                <span
                  className={`transition-transform duration-200 ${
                    openVocab ? 'rotate-180' : ''
                  }`}
                >
                  <ActionSvgIcon name="chevron_down" size={18} color="#E8B84A" />
                </span>
              </button>

              {openVocab && (
                <div className="px-5 pb-5 pt-1 border-t border-[#E6E6F0] grid grid-cols-1 md:grid-cols-2 gap-3">
                  {currentHadith.vocabulary.map((v, idx) => (
                    <div
                      key={idx}
                      className={`rounded-xl ${softBeigeBg} border border-[#E6E6F0] p-3.5 space-y-1`}
                    >
                      <div className="font-amiri font-bold text-base text-[#4CAF82]">
                        «{v.word}»
                      </div>
                      <p
                        style={{ fontSize: `${Math.round(14 * fontScale)}px` }}
                        className={`${textPrimary} leading-relaxed`}
                      >
                        {v.meaning}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* القسم 2: الشرح الوافي للحديث */}
            <section className={`rounded-2xl border ${cardBg} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenExplanation(!openExplanation)}
                className="w-full px-5 py-4 flex items-center justify-between text-right cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <ActionSvgIcon name="book" size={20} color="#E8B84A" />
                  <h3 className={`font-cairo font-bold text-base ${textPrimary}`}>
                    الشرح الوافي للحديث
                  </h3>
                </div>
                <span
                  className={`transition-transform duration-200 ${
                    openExplanation ? 'rotate-180' : ''
                  }`}
                >
                  <ActionSvgIcon name="chevron_down" size={18} color="#E8B84A" />
                </span>
              </button>

              {openExplanation && (
                <div className="px-5 pb-5 pt-2 border-t border-[#E6E6F0]">
                  <p
                    style={{ fontSize: `${Math.round(15.5 * fontScale)}px` }}
                    className={`${textPrimary} leading-[2] text-justify`}
                  >
                    {currentHadith.explanation}
                  </p>
                </div>
              )}
            </section>

            {/* القسم 3: الفوائد والأحكام المستنبطة */}
            <section className={`rounded-2xl border ${cardBg} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenBenefits(!openBenefits)}
                className="w-full px-5 py-4 flex items-center justify-between text-right cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <ActionSvgIcon name="benefits" size={20} color="#E8B84A" />
                  <h3 className={`font-cairo font-bold text-base ${textPrimary}`}>
                    ما يستفاد من الحديث ({currentHadith.benefits.length} فوائد)
                  </h3>
                </div>
                <span
                  className={`transition-transform duration-200 ${
                    openBenefits ? 'rotate-180' : ''
                  }`}
                >
                  <ActionSvgIcon name="chevron_down" size={18} color="#E8B84A" />
                </span>
              </button>

              {openBenefits && (
                <div className="px-5 pb-5 pt-2 border-t border-[#E6E6F0] space-y-2.5">
                  {currentHadith.benefits.map((benefit, idx) => (
                    <div
                      key={idx}
                      className={`rounded-xl ${softBeigeBg} border border-[#E6E6F0] p-3.5 flex items-start gap-3`}
                    >
                      <span className="w-6 h-6 rounded-full bg-[#4CAF82] text-[#FFFFFF] text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p
                        style={{ fontSize: `${Math.round(14.5 * fontScale)}px` }}
                        className={`${textPrimary} leading-relaxed flex-1`}
                      >
                        {benefit}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* القسم 4: ترجمة راوي الحديث */}
            <section className={`rounded-2xl border ${cardBg} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenNarrator(!openNarrator)}
                className="w-full px-5 py-4 flex items-center justify-between text-right cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <ActionSvgIcon name="narrator" size={20} color="#E8B84A" />
                  <h3 className={`font-cairo font-bold text-base ${textPrimary}`}>
                    ترجمة راوي الحديث
                  </h3>
                </div>
                <span
                  className={`transition-transform duration-200 ${
                    openNarrator ? 'rotate-180' : ''
                  }`}
                >
                  <ActionSvgIcon name="chevron_down" size={18} color="#E8B84A" />
                </span>
              </button>

              {openNarrator && (
                <div className="px-5 pb-5 pt-2 border-t border-[#E6E6F0] space-y-1.5">
                  <div className="font-bold text-sm text-[#4CAF82]">{currentHadith.narrator}</div>
                  <p
                    style={{ fontSize: `${Math.round(14.5 * fontScale)}px` }}
                    className={`${textPrimary} leading-relaxed`}
                  >
                    {currentHadith.narratorBio}
                  </p>
                </div>
              )}
            </section>

            {/* القسم 5: المرجع المعتمد في الشرح والتخريج */}
            <section className={`rounded-2xl border ${cardBg} overflow-hidden shadow-sm`}>
              <button
                type="button"
                onClick={() => setOpenReference(!openReference)}
                className="w-full px-5 py-4 flex items-center justify-between text-right cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <ActionSvgIcon name="reference" size={20} color="#E8B84A" />
                  <h3 className={`font-cairo font-bold text-base ${textPrimary}`}>
                    المراجع المعتمدة في الشرح والتخريج
                  </h3>
                </div>
                <span
                  className={`transition-transform duration-200 ${
                    openReference ? 'rotate-180' : ''
                  }`}
                >
                  <ActionSvgIcon name="chevron_down" size={18} color="#E8B84A" />
                </span>
              </button>

              {openReference && (
                <div className="px-5 pb-5 pt-2 border-t border-[#E6E6F0] space-y-2 text-sm">
                  <div className={`rounded-xl ${softBeigeBg} border border-[#E6E6F0] p-3.5 space-y-1.5`}>
                    <div>
                      <span className="text-[#77798C]">مصدر الحديث وتخريجه: </span>
                      <span className={`font-bold ${textPrimary}`}>{currentHadith.fullTakhrij}</span>
                    </div>
                    <div>
                      <span className="text-[#77798C]">مرجع الشرح والفوائد: </span>
                      <span className="font-bold text-[#4CAF82]">{currentHadith.reference}</span>
                    </div>
                  </div>
                </div>
              )}
            </section>

            {/* شريط الأدوات والتنقل السفلي في صفحة تفاصيل الحديث */}
            <div
              className={`sticky bottom-3 z-20 rounded-2xl border-2 border-[#5B5FEF] ${
                isDarkMode ? 'bg-[#25263A]/95' : 'bg-[#FFFFFF]/95'
              } backdrop-blur-md p-3 shadow-lg flex flex-wrap items-center justify-between gap-2`}
            >
              {/* الحديث السابق */}
              <button
                type="button"
                disabled={currentHadith.number <= 1}
                onClick={() => {
                  if (currentHadith.number > 1) {
                    setSelectedHadithNumber(currentHadith.number - 1);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }}
                className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                  currentHadith.number <= 1
                    ? 'opacity-40 cursor-not-allowed border-[#E6E6F0] text-[#77798C]'
                    : `${softBeigeBg} border-[#E6E6F0] ${textPrimary} hover:border-[#5B5FEF] cursor-pointer`
                }`}
              >
                <ActionSvgIcon name="chevron_right" size={16} color="#E8B84A" />
                <span>الحديث السابق</span>
              </button>

              {/* أزرار النسخ والمشاركة والمفضلة */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopyHadith(currentHadith)}
                  className={`px-3.5 py-2 rounded-xl ${softBeigeBg} border border-[#E6E6F0] hover:border-[#5B5FEF] flex items-center gap-1.5 text-xs font-bold ${textPrimary} cursor-pointer`}
                >
                  <ActionSvgIcon name="copy" size={15} color="#E8B84A" />
                  <span>نسخ</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleShareHadith(currentHadith)}
                  className="px-3.5 py-2 rounded-xl bg-[#5B5FEF] text-[#FFFFFF] hover:bg-[#4145C7] flex items-center gap-1.5 text-xs font-bold cursor-pointer"
                >
                  <ActionSvgIcon name="share" size={15} color="#FFFFFF" />
                  <span>مشاركة</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleToggleFavorite(currentHadith.id)}
                  aria-label="المفضلة"
                  className={`w-9 h-9 rounded-xl ${softBeigeBg} border border-[#E6E6F0] hover:border-[#5B5FEF] flex items-center justify-center cursor-pointer`}
                >
                  <ActionSvgIcon
                    name={favoriteIds.includes(currentHadith.id) ? 'bookmark_filled' : 'bookmark'}
                    size={16}
                    color="#E8B84A"
                  />
                </button>
              </div>

              {/* الحديث التالي */}
              <button
                type="button"
                disabled={currentHadith.number >= hadiths.length}
                onClick={() => {
                  if (currentHadith.number < hadiths.length) {
                    setSelectedHadithNumber(currentHadith.number + 1);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }}
                className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all ${
                  currentHadith.number >= hadiths.length
                    ? 'opacity-40 cursor-not-allowed border-[#E6E6F0] text-[#77798C]'
                    : `${softBeigeBg} border-[#E6E6F0] ${textPrimary} hover:border-[#5B5FEF] cursor-pointer`
                }`}
              >
                <span>الحديث التالي</span>
                <ActionSvgIcon name="chevron_left" size={16} color="#E8B84A" />
              </button>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            الشاشة 3: البحث الفوري في الأربعين النووية
           ══════════════════════════════════════════════════════════════════ */}
        {subScreen === 'search' && (
          <div className="space-y-4">
            <div className={`rounded-2xl border ${cardBg} p-4 space-y-3 shadow-sm`}>
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث برقم الحديث، العنوان، كلمة من المتن، اسم الصحابي، أو الفوائد..."
                  className={`w-full rounded-xl ${softBeigeBg} border border-[#E6E6F0] focus:border-[#5B5FEF] focus:outline-none pr-10 pl-10 py-3 text-sm ${textPrimary}`}
                />
                <span className="absolute right-3.5 top-1/2 -translate-y-1/2">
                  <ActionSvgIcon name="search" size={18} color="#E8B84A" />
                </span>
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    aria-label="مسح البحث"
                    className="absolute left-3 top-1/2 -translate-y-1/2 cursor-pointer"
                  >
                    <ActionSvgIcon name="close" size={16} color="#77798C" />
                  </button>
                )}
              </div>

              {/* تصفية حسب كتاب التخريج */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {['all', 'البخاري', 'مسلم', 'الترمذي', 'أبو داود', 'ابن ماجه', 'الدارقطني', 'البيهقي'].map(
                  (src) => (
                    <button
                      key={src}
                      type="button"
                      onClick={() => setSearchSourceFilter(src)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap border transition-all cursor-pointer ${
                        searchSourceFilter === src
                          ? 'bg-[#4CAF82] text-[#FFFFFF] border-[#4CAF82]'
                          : `${softBeigeBg} ${textPrimary} border-[#E6E6F0]`
                      }`}
                    >
                      {src === 'all' ? 'كل المصادر' : `رواه ${src}`}
                    </button>
                  )
                )}
              </div>

              {/* تصفية حسب الموضوع */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {ARBAIN_THEMES.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setSearchThemeFilter(t.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap border transition-all cursor-pointer ${
                      searchThemeFilter === t.id
                        ? 'bg-[#5B5FEF] text-[#FFFFFF] border-[#5B5FEF]'
                        : `${softBeigeBg} ${textPrimary} border-[#E6E6F0]`
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-[#77798C] px-1">
              <span>نتائج البحث المطابقة: {searchResults.length} حديثًا</span>
              {(searchQuery || searchThemeFilter !== 'all' || searchSourceFilter !== 'all') && (
                <button
                  type="button"
                  onClick={() => {
                    setSearchQuery('');
                    setSearchThemeFilter('all');
                    setSearchSourceFilter('all');
                  }}
                  className="text-[#5B5FEF] font-bold hover:underline cursor-pointer"
                >
                  إعادة ضبط الفلاتر
                </button>
              )}
            </div>

            {searchResults.length === 0 ? (
              <div className={`rounded-2xl border ${cardBg} p-8 text-center space-y-3`}>
                <div className="flex justify-center">
                  <ArbainBook40Svg size={56} />
                </div>
                <p className={`font-bold text-base ${textPrimary}`}>
                  لا توجد أحاديث مطابقة لعبارة البحث الحالية
                </p>
                <p className={`text-xs ${textSecondary}`}>
                  جرّب البحث بكلمة أخرى مثل «النية»، «جبريل»، «الظلم»، «الخلق»، أو رقم الحديث من 1 إلى 42.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {searchResults.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => openHadithDetail(item.number, 'search')}
                    className={`rounded-2xl border ${cardBg} p-4 hover:border-[#5B5FEF] transition-all cursor-pointer space-y-2`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <HadithNumberMedallionSvg number={item.number} size={38} />
                        <div>
                          <h3 className={`font-bold text-base ${textPrimary}`}>{item.title}</h3>
                          <p className="text-xs text-[#77798C]">
                            {item.narrator} · <span className="text-[#4CAF82] font-bold">{item.shortSource}</span>
                          </p>
                        </div>
                      </div>
                      <ActionSvgIcon name="chevron_left" size={18} color="#E8B84A" />
                    </div>
                    <p className={`font-amiri text-sm ${textPrimary} line-clamp-2 leading-relaxed`}>
                      {item.hadithText}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════════════════════
            الشاشة 4: المفضلة والمحفوظات
           ══════════════════════════════════════════════════════════════════ */}
        {subScreen === 'favorites' && (
          <div className="space-y-4">
            {/* تبويب المفضلة / المحفوظات */}
            <div className={`grid grid-cols-2 gap-2 p-1.5 rounded-2xl border ${cardBg}`}>
              <button
                type="button"
                onClick={() => setSavedTab('favorites')}
                className={`py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer ${
                  savedTab === 'favorites'
                    ? 'bg-[#5B5FEF] text-[#FFFFFF] shadow-sm'
                    : `${textPrimary} hover:bg-[#F7F7FC]/60`
                }`}
              >
                الأحاديث المفضلة ({favoriteHadiths.length})
              </button>
              <button
                type="button"
                onClick={() => setSavedTab('memorized')}
                className={`py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer ${
                  savedTab === 'memorized'
                    ? 'bg-[#4CAF82] text-[#FFFFFF] shadow-sm'
                    : `${textPrimary} hover:bg-[#F7F7FC]/60`
                }`}
              >
                الأحاديث المحفوظة ({memorizedHadiths.length} / 42)
              </button>
            </div>

            {savedTab === 'favorites' ? (
              favoriteHadiths.length === 0 ? (
                <div className={`rounded-2xl border ${cardBg} p-8 text-center space-y-3`}>
                  <div className="flex justify-center">
                    <ArbainBook40Svg size={56} />
                  </div>
                  <h3 className={`font-bold text-base ${textPrimary}`}>
                    قائمة الأحاديث المفضلة فارغة حالياً
                  </h3>
                  <p className={`text-xs ${textSecondary} max-w-md mx-auto leading-relaxed`}>
                    يمكنك الضغط على أيقونة الحفظ الذهبية بجانب أي حديث من الأحاديث الاثنين والأربعين لإضافته إلى مفضلتك والرجوع إليه بسرعة.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubScreen('home')}
                    className="px-5 py-2.5 rounded-xl bg-[#5B5FEF] text-[#FFFFFF] text-xs font-bold cursor-pointer"
                  >
                    استعراض الأحاديث الأربعين
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {favoriteHadiths.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => openHadithDetail(item.number, 'favorites')}
                      className={`rounded-2xl border ${cardBg} p-4 hover:border-[#5B5FEF] transition-all cursor-pointer space-y-2.5`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <HadithNumberMedallionSvg number={item.number} size={40} />
                          <div>
                            <h3 className={`font-bold text-base ${textPrimary}`}>{item.title}</h3>
                            <p className="text-xs text-[#77798C]">
                              {item.arabicOrderLabel} · <span className="text-[#4CAF82] font-bold">{item.shortSource}</span>
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => handleCopyHadith(item, e)}
                            className={`px-2.5 py-1.5 rounded-lg ${softBeigeBg} border border-[#E6E6F0] text-xs font-bold ${textPrimary} cursor-pointer`}
                          >
                            نسخ
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleToggleFavorite(item.id, e)}
                            className="px-2.5 py-1.5 rounded-lg bg-[#EEEEFF] text-[#5B5FEF] text-xs font-bold cursor-pointer"
                          >
                            إزالة
                          </button>
                        </div>
                      </div>
                      <p className={`font-amiri text-base ${textPrimary} line-clamp-2 leading-relaxed`}>
                        {item.hadithText}
                      </p>
                    </div>
                  ))}
                </div>
              )
            ) : memorizedHadiths.length === 0 ? (
              <div className={`rounded-2xl border ${cardBg} p-8 text-center space-y-3`}>
                <div className="flex justify-center">
                  <ArbainBook40Svg size={56} />
                </div>
                <h3 className={`font-bold text-base ${textPrimary}`}>
                  ابدأ رحلة حفظ الأربعين النووية
                </h3>
                <p className={`text-xs ${textSecondary} max-w-md mx-auto leading-relaxed`}>
                  اقرأ الحديث وكرّره بمساعدة عداد القراءة داخل صفحة الحديث، ثم اضغط على «تأشير كمحفوظ» لمتابعة تقدمك في حفظ الأربعين النووية كاملة.
                </p>
                <button
                  type="button"
                  onClick={() => openHadithDetail(1, 'favorites')}
                  className="px-5 py-2.5 rounded-xl bg-[#4CAF82] text-[#FFFFFF] text-xs font-bold cursor-pointer"
                >
                  البدء بالحديث الأول: إنما الأعمال بالنيات
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {memorizedHadiths.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => openHadithDetail(item.number, 'favorites')}
                    className={`rounded-2xl border ${cardBg} p-4 hover:border-[#5B5FEF] transition-all cursor-pointer space-y-2.5`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <HadithNumberMedallionSvg number={item.number} size={40} />
                        <div>
                          <h3 className={`font-bold text-base ${textPrimary}`}>{item.title}</h3>
                          <p className="text-xs text-[#4CAF82] font-bold">
                            تم الحفظ · {item.shortSource}
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => handleToggleMemorized(item.id, e)}
                        className={`px-3 py-1.5 rounded-lg ${softBeigeBg} border border-[#E6E6F0] text-xs ${textSecondary} cursor-pointer`}
                      >
                        إلغاء التأشير
                      </button>
                    </div>
                    <p className={`font-amiri text-base ${textPrimary} line-clamp-2 leading-relaxed`}>
                      {item.hadithText}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
};
